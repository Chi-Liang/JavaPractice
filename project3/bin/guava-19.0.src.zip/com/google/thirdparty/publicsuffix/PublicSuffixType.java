/*  1:   */ package com.google.thirdparty.publicsuffix;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ 
/*  5:   */ @GwtCompatible
/*  6:   */  enum PublicSuffixType
/*  7:   */ {
/*  8:28 */   PRIVATE(':', ','),  ICANN('!', '?');
/*  9:   */   
/* 10:   */   private final char innerNodeCode;
/* 11:   */   private final char leafNodeCode;
/* 12:   */   
/* 13:   */   private PublicSuffixType(char innerNodeCode, char leafNodeCode)
/* 14:   */   {
/* 15:39 */     this.innerNodeCode = innerNodeCode;
/* 16:40 */     this.leafNodeCode = leafNodeCode;
/* 17:   */   }
/* 18:   */   
/* 19:   */   char getLeafNodeCode()
/* 20:   */   {
/* 21:44 */     return this.leafNodeCode;
/* 22:   */   }
/* 23:   */   
/* 24:   */   char getInnerNodeCode()
/* 25:   */   {
/* 26:48 */     return this.innerNodeCode;
/* 27:   */   }
/* 28:   */   
/* 29:   */   static PublicSuffixType fromCode(char code)
/* 30:   */   {
/* 31:53 */     for (PublicSuffixType value : ) {
/* 32:54 */       if ((value.getInnerNodeCode() == code) || (value.getLeafNodeCode() == code)) {
/* 33:55 */         return value;
/* 34:   */       }
/* 35:   */     }
/* 36:58 */     throw new IllegalArgumentException("No enum corresponding to given code: " + code);
/* 37:   */   }
/* 38:   */   
/* 39:   */   static PublicSuffixType fromIsPrivate(boolean isPrivate)
/* 40:   */   {
/* 41:62 */     return isPrivate ? PRIVATE : ICANN;
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.thirdparty.publicsuffix.PublicSuffixType
 * JD-Core Version:    0.7.0.1
 */