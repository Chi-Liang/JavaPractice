/*   1:    */ package com.google.thirdparty.publicsuffix;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Joiner;
/*   5:    */ import com.google.common.collect.ImmutableMap;
/*   6:    */ import com.google.common.collect.ImmutableMap.Builder;
/*   7:    */ import com.google.common.collect.Lists;
/*   8:    */ import java.util.List;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ class TrieParser
/*  12:    */ {
/*  13: 32 */   private static final Joiner PREFIX_JOINER = Joiner.on("");
/*  14:    */   
/*  15:    */   static ImmutableMap<String, PublicSuffixType> parseTrie(CharSequence encoded)
/*  16:    */   {
/*  17: 39 */     ImmutableMap.Builder<String, PublicSuffixType> builder = ImmutableMap.builder();
/*  18: 40 */     int encodedLen = encoded.length();
/*  19: 41 */     int idx = 0;
/*  20: 42 */     while (idx < encodedLen) {
/*  21: 43 */       idx += doParseTrieToBuilder(Lists.newLinkedList(), encoded.subSequence(idx, encodedLen), builder);
/*  22:    */     }
/*  23: 48 */     return builder.build();
/*  24:    */   }
/*  25:    */   
/*  26:    */   private static int doParseTrieToBuilder(List<CharSequence> stack, CharSequence encoded, ImmutableMap.Builder<String, PublicSuffixType> builder)
/*  27:    */   {
/*  28: 65 */     int encodedLen = encoded.length();
/*  29: 66 */     int idx = 0;
/*  30: 67 */     char c = '\000';
/*  31: 70 */     for (; idx < encodedLen; idx++)
/*  32:    */     {
/*  33: 71 */       c = encoded.charAt(idx);
/*  34: 72 */       if ((c == '&') || (c == '?') || (c == '!') || (c == ':') || (c == ',')) {
/*  35:    */         break;
/*  36:    */       }
/*  37:    */     }
/*  38: 77 */     stack.add(0, reverse(encoded.subSequence(0, idx)));
/*  39: 79 */     if ((c == '!') || (c == '?') || (c == ':') || (c == ','))
/*  40:    */     {
/*  41: 84 */       String domain = PREFIX_JOINER.join(stack);
/*  42: 85 */       if (domain.length() > 0) {
/*  43: 86 */         builder.put(domain, PublicSuffixType.fromCode(c));
/*  44:    */       }
/*  45:    */     }
/*  46: 89 */     idx++;
/*  47: 91 */     while ((c != '?') && (c != ',') && 
/*  48: 92 */       (idx < encodedLen))
/*  49:    */     {
/*  50: 94 */       idx += doParseTrieToBuilder(stack, encoded.subSequence(idx, encodedLen), builder);
/*  51: 95 */       if ((encoded.charAt(idx) == '?') || (encoded.charAt(idx) == ',')) {
/*  52: 97 */         idx++;
/*  53:    */       }
/*  54:    */     }
/*  55:102 */     stack.remove(0);
/*  56:103 */     return idx;
/*  57:    */   }
/*  58:    */   
/*  59:    */   private static CharSequence reverse(CharSequence s)
/*  60:    */   {
/*  61:112 */     int length = s.length();
/*  62:113 */     if (length <= 1) {
/*  63:114 */       return s;
/*  64:    */     }
/*  65:117 */     char[] buffer = new char[length];
/*  66:118 */     buffer[0] = s.charAt(length - 1);
/*  67:120 */     for (int i = 1; i < length; i++)
/*  68:    */     {
/*  69:121 */       buffer[i] = s.charAt(length - 1 - i);
/*  70:122 */       if (Character.isSurrogatePair(buffer[i], buffer[(i - 1)])) {
/*  71:123 */         swap(buffer, i - 1, i);
/*  72:    */       }
/*  73:    */     }
/*  74:127 */     return new String(buffer);
/*  75:    */   }
/*  76:    */   
/*  77:    */   private static void swap(char[] buffer, int f, int s)
/*  78:    */   {
/*  79:131 */     char tmp = buffer[f];
/*  80:132 */     buffer[f] = buffer[s];
/*  81:133 */     buffer[s] = tmp;
/*  82:    */   }
/*  83:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.thirdparty.publicsuffix.TrieParser
 * JD-Core Version:    0.7.0.1
 */