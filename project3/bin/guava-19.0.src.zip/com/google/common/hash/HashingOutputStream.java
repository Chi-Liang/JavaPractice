/*  1:   */ package com.google.common.hash;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.FilterOutputStream;
/*  6:   */ import java.io.IOException;
/*  7:   */ import java.io.OutputStream;
/*  8:   */ import javax.annotation.CheckReturnValue;
/*  9:   */ 
/* 10:   */ @Beta
/* 11:   */ public final class HashingOutputStream
/* 12:   */   extends FilterOutputStream
/* 13:   */ {
/* 14:   */   private final Hasher hasher;
/* 15:   */   
/* 16:   */   public HashingOutputStream(HashFunction hashFunction, OutputStream out)
/* 17:   */   {
/* 18:48 */     super((OutputStream)Preconditions.checkNotNull(out));
/* 19:49 */     this.hasher = ((Hasher)Preconditions.checkNotNull(hashFunction.newHasher()));
/* 20:   */   }
/* 21:   */   
/* 22:   */   public void write(int b)
/* 23:   */     throws IOException
/* 24:   */   {
/* 25:54 */     this.hasher.putByte((byte)b);
/* 26:55 */     this.out.write(b);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public void write(byte[] bytes, int off, int len)
/* 30:   */     throws IOException
/* 31:   */   {
/* 32:60 */     this.hasher.putBytes(bytes, off, len);
/* 33:61 */     this.out.write(bytes, off, len);
/* 34:   */   }
/* 35:   */   
/* 36:   */   @CheckReturnValue
/* 37:   */   public HashCode hash()
/* 38:   */   {
/* 39:70 */     return this.hasher.hash();
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void close()
/* 43:   */     throws IOException
/* 44:   */   {
/* 45:78 */     this.out.close();
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.HashingOutputStream
 * JD-Core Version:    0.7.0.1
 */