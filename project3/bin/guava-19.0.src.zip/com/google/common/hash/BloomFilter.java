/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Predicate;
/*   8:    */ import com.google.common.primitives.SignedBytes;
/*   9:    */ import com.google.common.primitives.UnsignedBytes;
/*  10:    */ import java.io.DataInputStream;
/*  11:    */ import java.io.DataOutputStream;
/*  12:    */ import java.io.IOException;
/*  13:    */ import java.io.InputStream;
/*  14:    */ import java.io.OutputStream;
/*  15:    */ import java.io.Serializable;
/*  16:    */ import javax.annotation.CheckReturnValue;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @Beta
/*  20:    */ public final class BloomFilter<T>
/*  21:    */   implements Predicate<T>, Serializable
/*  22:    */ {
/*  23:    */   private final BloomFilterStrategies.BitArray bits;
/*  24:    */   private final int numHashFunctions;
/*  25:    */   private final Funnel<? super T> funnel;
/*  26:    */   private final Strategy strategy;
/*  27:    */   
/*  28:    */   private BloomFilter(BloomFilterStrategies.BitArray bits, int numHashFunctions, Funnel<? super T> funnel, Strategy strategy)
/*  29:    */   {
/*  30:114 */     Preconditions.checkArgument(numHashFunctions > 0, "numHashFunctions (%s) must be > 0", new Object[] { Integer.valueOf(numHashFunctions) });
/*  31:115 */     Preconditions.checkArgument(numHashFunctions <= 255, "numHashFunctions (%s) must be <= 255", new Object[] { Integer.valueOf(numHashFunctions) });
/*  32:    */     
/*  33:117 */     this.bits = ((BloomFilterStrategies.BitArray)Preconditions.checkNotNull(bits));
/*  34:118 */     this.numHashFunctions = numHashFunctions;
/*  35:119 */     this.funnel = ((Funnel)Preconditions.checkNotNull(funnel));
/*  36:120 */     this.strategy = ((Strategy)Preconditions.checkNotNull(strategy));
/*  37:    */   }
/*  38:    */   
/*  39:    */   @CheckReturnValue
/*  40:    */   public BloomFilter<T> copy()
/*  41:    */   {
/*  42:131 */     return new BloomFilter(this.bits.copy(), this.numHashFunctions, this.funnel, this.strategy);
/*  43:    */   }
/*  44:    */   
/*  45:    */   @CheckReturnValue
/*  46:    */   public boolean mightContain(T object)
/*  47:    */   {
/*  48:140 */     return this.strategy.mightContain(object, this.funnel, this.numHashFunctions, this.bits);
/*  49:    */   }
/*  50:    */   
/*  51:    */   @Deprecated
/*  52:    */   @CheckReturnValue
/*  53:    */   public boolean apply(T input)
/*  54:    */   {
/*  55:151 */     return mightContain(input);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public boolean put(T object)
/*  59:    */   {
/*  60:167 */     return this.strategy.put(object, this.funnel, this.numHashFunctions, this.bits);
/*  61:    */   }
/*  62:    */   
/*  63:    */   @CheckReturnValue
/*  64:    */   public double expectedFpp()
/*  65:    */   {
/*  66:184 */     return Math.pow(this.bits.bitCount() / bitSize(), this.numHashFunctions);
/*  67:    */   }
/*  68:    */   
/*  69:    */   @VisibleForTesting
/*  70:    */   long bitSize()
/*  71:    */   {
/*  72:192 */     return this.bits.bitSize();
/*  73:    */   }
/*  74:    */   
/*  75:    */   @CheckReturnValue
/*  76:    */   public boolean isCompatible(BloomFilter<T> that)
/*  77:    */   {
/*  78:212 */     Preconditions.checkNotNull(that);
/*  79:213 */     return (this != that) && (this.numHashFunctions == that.numHashFunctions) && (bitSize() == that.bitSize()) && (this.strategy.equals(that.strategy)) && (this.funnel.equals(that.funnel));
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void putAll(BloomFilter<T> that)
/*  83:    */   {
/*  84:231 */     Preconditions.checkNotNull(that);
/*  85:232 */     Preconditions.checkArgument(this != that, "Cannot combine a BloomFilter with itself.");
/*  86:233 */     Preconditions.checkArgument(this.numHashFunctions == that.numHashFunctions, "BloomFilters must have the same number of hash functions (%s != %s)", new Object[] { Integer.valueOf(this.numHashFunctions), Integer.valueOf(that.numHashFunctions) });
/*  87:    */     
/*  88:    */ 
/*  89:    */ 
/*  90:    */ 
/*  91:238 */     Preconditions.checkArgument(bitSize() == that.bitSize(), "BloomFilters must have the same size underlying bit arrays (%s != %s)", new Object[] { Long.valueOf(bitSize()), Long.valueOf(that.bitSize()) });
/*  92:    */     
/*  93:    */ 
/*  94:    */ 
/*  95:    */ 
/*  96:243 */     Preconditions.checkArgument(this.strategy.equals(that.strategy), "BloomFilters must have equal strategies (%s != %s)", new Object[] { this.strategy, that.strategy });
/*  97:    */     
/*  98:    */ 
/*  99:    */ 
/* 100:    */ 
/* 101:248 */     Preconditions.checkArgument(this.funnel.equals(that.funnel), "BloomFilters must have equal funnels (%s != %s)", new Object[] { this.funnel, that.funnel });
/* 102:    */     
/* 103:    */ 
/* 104:    */ 
/* 105:    */ 
/* 106:253 */     this.bits.putAll(that.bits);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public boolean equals(@Nullable Object object)
/* 110:    */   {
/* 111:258 */     if (object == this) {
/* 112:259 */       return true;
/* 113:    */     }
/* 114:261 */     if ((object instanceof BloomFilter))
/* 115:    */     {
/* 116:262 */       BloomFilter<?> that = (BloomFilter)object;
/* 117:263 */       return (this.numHashFunctions == that.numHashFunctions) && (this.funnel.equals(that.funnel)) && (this.bits.equals(that.bits)) && (this.strategy.equals(that.strategy));
/* 118:    */     }
/* 119:268 */     return false;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public int hashCode()
/* 123:    */   {
/* 124:273 */     return Objects.hashCode(new Object[] { Integer.valueOf(this.numHashFunctions), this.funnel, this.strategy, this.bits });
/* 125:    */   }
/* 126:    */   
/* 127:    */   @CheckReturnValue
/* 128:    */   public static <T> BloomFilter<T> create(Funnel<? super T> funnel, int expectedInsertions, double fpp)
/* 129:    */   {
/* 130:300 */     return create(funnel, expectedInsertions, fpp);
/* 131:    */   }
/* 132:    */   
/* 133:    */   @CheckReturnValue
/* 134:    */   public static <T> BloomFilter<T> create(Funnel<? super T> funnel, long expectedInsertions, double fpp)
/* 135:    */   {
/* 136:328 */     return create(funnel, expectedInsertions, fpp, BloomFilterStrategies.MURMUR128_MITZ_64);
/* 137:    */   }
/* 138:    */   
/* 139:    */   @VisibleForTesting
/* 140:    */   static <T> BloomFilter<T> create(Funnel<? super T> funnel, long expectedInsertions, double fpp, Strategy strategy)
/* 141:    */   {
/* 142:334 */     Preconditions.checkNotNull(funnel);
/* 143:335 */     Preconditions.checkArgument(expectedInsertions >= 0L, "Expected insertions (%s) must be >= 0", new Object[] { Long.valueOf(expectedInsertions) });
/* 144:    */     
/* 145:337 */     Preconditions.checkArgument(fpp > 0.0D, "False positive probability (%s) must be > 0.0", new Object[] { Double.valueOf(fpp) });
/* 146:338 */     Preconditions.checkArgument(fpp < 1.0D, "False positive probability (%s) must be < 1.0", new Object[] { Double.valueOf(fpp) });
/* 147:339 */     Preconditions.checkNotNull(strategy);
/* 148:341 */     if (expectedInsertions == 0L) {
/* 149:342 */       expectedInsertions = 1L;
/* 150:    */     }
/* 151:350 */     long numBits = optimalNumOfBits(expectedInsertions, fpp);
/* 152:351 */     int numHashFunctions = optimalNumOfHashFunctions(expectedInsertions, numBits);
/* 153:    */     try
/* 154:    */     {
/* 155:353 */       return new BloomFilter(new BloomFilterStrategies.BitArray(numBits), numHashFunctions, funnel, strategy);
/* 156:    */     }
/* 157:    */     catch (IllegalArgumentException e)
/* 158:    */     {
/* 159:355 */       throw new IllegalArgumentException("Could not create BloomFilter of " + numBits + " bits", e);
/* 160:    */     }
/* 161:    */   }
/* 162:    */   
/* 163:    */   @CheckReturnValue
/* 164:    */   public static <T> BloomFilter<T> create(Funnel<? super T> funnel, int expectedInsertions)
/* 165:    */   {
/* 166:381 */     return create(funnel, expectedInsertions);
/* 167:    */   }
/* 168:    */   
/* 169:    */   @CheckReturnValue
/* 170:    */   public static <T> BloomFilter<T> create(Funnel<? super T> funnel, long expectedInsertions)
/* 171:    */   {
/* 172:407 */     return create(funnel, expectedInsertions, 0.03D);
/* 173:    */   }
/* 174:    */   
/* 175:    */   @VisibleForTesting
/* 176:    */   static int optimalNumOfHashFunctions(long n, long m)
/* 177:    */   {
/* 178:436 */     return Math.max(1, (int)Math.round(m / n * Math.log(2.0D)));
/* 179:    */   }
/* 180:    */   
/* 181:    */   @VisibleForTesting
/* 182:    */   static long optimalNumOfBits(long n, double p)
/* 183:    */   {
/* 184:450 */     if (p == 0.0D) {
/* 185:451 */       p = 4.9E-324D;
/* 186:    */     }
/* 187:453 */     return (-n * Math.log(p) / (Math.log(2.0D) * Math.log(2.0D)));
/* 188:    */   }
/* 189:    */   
/* 190:    */   private Object writeReplace()
/* 191:    */   {
/* 192:457 */     return new SerialForm(this);
/* 193:    */   }
/* 194:    */   
/* 195:    */   private static class SerialForm<T>
/* 196:    */     implements Serializable
/* 197:    */   {
/* 198:    */     final long[] data;
/* 199:    */     final int numHashFunctions;
/* 200:    */     final Funnel<? super T> funnel;
/* 201:    */     final BloomFilter.Strategy strategy;
/* 202:    */     private static final long serialVersionUID = 1L;
/* 203:    */     
/* 204:    */     SerialForm(BloomFilter<T> bf)
/* 205:    */     {
/* 206:467 */       this.data = bf.bits.data;
/* 207:468 */       this.numHashFunctions = bf.numHashFunctions;
/* 208:469 */       this.funnel = bf.funnel;
/* 209:470 */       this.strategy = bf.strategy;
/* 210:    */     }
/* 211:    */     
/* 212:    */     Object readResolve()
/* 213:    */     {
/* 214:474 */       return new BloomFilter(new BloomFilterStrategies.BitArray(this.data), this.numHashFunctions, this.funnel, this.strategy, null);
/* 215:    */     }
/* 216:    */   }
/* 217:    */   
/* 218:    */   public void writeTo(OutputStream out)
/* 219:    */     throws IOException
/* 220:    */   {
/* 221:495 */     DataOutputStream dout = new DataOutputStream(out);
/* 222:496 */     dout.writeByte(SignedBytes.checkedCast(this.strategy.ordinal()));
/* 223:497 */     dout.writeByte(UnsignedBytes.checkedCast(this.numHashFunctions));
/* 224:498 */     dout.writeInt(this.bits.data.length);
/* 225:499 */     for (long value : this.bits.data) {
/* 226:500 */       dout.writeLong(value);
/* 227:    */     }
/* 228:    */   }
/* 229:    */   
/* 230:    */   @CheckReturnValue
/* 231:    */   public static <T> BloomFilter<T> readFrom(InputStream in, Funnel<T> funnel)
/* 232:    */     throws IOException
/* 233:    */   {
/* 234:518 */     Preconditions.checkNotNull(in, "InputStream");
/* 235:519 */     Preconditions.checkNotNull(funnel, "Funnel");
/* 236:520 */     int strategyOrdinal = -1;
/* 237:521 */     int numHashFunctions = -1;
/* 238:522 */     int dataLength = -1;
/* 239:    */     try
/* 240:    */     {
/* 241:524 */       DataInputStream din = new DataInputStream(in);
/* 242:    */       
/* 243:    */ 
/* 244:    */ 
/* 245:528 */       strategyOrdinal = din.readByte();
/* 246:529 */       numHashFunctions = UnsignedBytes.toInt(din.readByte());
/* 247:530 */       dataLength = din.readInt();
/* 248:    */       
/* 249:532 */       Strategy strategy = BloomFilterStrategies.values()[strategyOrdinal];
/* 250:533 */       long[] data = new long[dataLength];
/* 251:534 */       for (int i = 0; i < data.length; i++) {
/* 252:535 */         data[i] = din.readLong();
/* 253:    */       }
/* 254:537 */       return new BloomFilter(new BloomFilterStrategies.BitArray(data), numHashFunctions, funnel, strategy);
/* 255:    */     }
/* 256:    */     catch (RuntimeException e)
/* 257:    */     {
/* 258:539 */       IOException ioException = new IOException("Unable to deserialize BloomFilter from InputStream. strategyOrdinal: " + strategyOrdinal + " numHashFunctions: " + numHashFunctions + " dataLength: " + dataLength);
/* 259:    */       
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:544 */       ioException.initCause(e);
/* 264:545 */       throw ioException;
/* 265:    */     }
/* 266:    */   }
/* 267:    */   
/* 268:    */   static abstract interface Strategy
/* 269:    */     extends Serializable
/* 270:    */   {
/* 271:    */     public abstract <T> boolean put(T paramT, Funnel<? super T> paramFunnel, int paramInt, BloomFilterStrategies.BitArray paramBitArray);
/* 272:    */     
/* 273:    */     public abstract <T> boolean mightContain(T paramT, Funnel<? super T> paramFunnel, int paramInt, BloomFilterStrategies.BitArray paramBitArray);
/* 274:    */     
/* 275:    */     public abstract int ordinal();
/* 276:    */   }
/* 277:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.BloomFilter
 * JD-Core Version:    0.7.0.1
 */