/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.FilterInputStream;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import javax.annotation.CheckReturnValue;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ public final class HashingInputStream
/*  12:    */   extends FilterInputStream
/*  13:    */ {
/*  14:    */   private final Hasher hasher;
/*  15:    */   
/*  16:    */   public HashingInputStream(HashFunction hashFunction, InputStream in)
/*  17:    */   {
/*  18: 44 */     super((InputStream)Preconditions.checkNotNull(in));
/*  19: 45 */     this.hasher = ((Hasher)Preconditions.checkNotNull(hashFunction.newHasher()));
/*  20:    */   }
/*  21:    */   
/*  22:    */   public int read()
/*  23:    */     throws IOException
/*  24:    */   {
/*  25: 54 */     int b = this.in.read();
/*  26: 55 */     if (b != -1) {
/*  27: 56 */       this.hasher.putByte((byte)b);
/*  28:    */     }
/*  29: 58 */     return b;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public int read(byte[] bytes, int off, int len)
/*  33:    */     throws IOException
/*  34:    */   {
/*  35: 67 */     int numOfBytesRead = this.in.read(bytes, off, len);
/*  36: 68 */     if (numOfBytesRead != -1) {
/*  37: 69 */       this.hasher.putBytes(bytes, off, numOfBytesRead);
/*  38:    */     }
/*  39: 71 */     return numOfBytesRead;
/*  40:    */   }
/*  41:    */   
/*  42:    */   @CheckReturnValue
/*  43:    */   public boolean markSupported()
/*  44:    */   {
/*  45: 81 */     return false;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void mark(int readlimit) {}
/*  49:    */   
/*  50:    */   public void reset()
/*  51:    */     throws IOException
/*  52:    */   {
/*  53: 96 */     throw new IOException("reset not supported");
/*  54:    */   }
/*  55:    */   
/*  56:    */   @CheckReturnValue
/*  57:    */   public HashCode hash()
/*  58:    */   {
/*  59:105 */     return this.hasher.hash();
/*  60:    */   }
/*  61:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.HashingInputStream
 * JD-Core Version:    0.7.0.1
 */