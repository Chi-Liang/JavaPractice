/*  1:   */ package com.google.common.hash;
/*  2:   */ 
/*  3:   */ import java.nio.charset.Charset;
/*  4:   */ 
/*  5:   */ abstract class AbstractHasher
/*  6:   */   implements Hasher
/*  7:   */ {
/*  8:   */   public final Hasher putBoolean(boolean b)
/*  9:   */   {
/* 10:29 */     return putByte((byte)(b ? 1 : 0));
/* 11:   */   }
/* 12:   */   
/* 13:   */   public final Hasher putDouble(double d)
/* 14:   */   {
/* 15:34 */     return putLong(Double.doubleToRawLongBits(d));
/* 16:   */   }
/* 17:   */   
/* 18:   */   public final Hasher putFloat(float f)
/* 19:   */   {
/* 20:39 */     return putInt(Float.floatToRawIntBits(f));
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Hasher putUnencodedChars(CharSequence charSequence)
/* 24:   */   {
/* 25:44 */     int i = 0;
/* 26:44 */     for (int len = charSequence.length(); i < len; i++) {
/* 27:45 */       putChar(charSequence.charAt(i));
/* 28:   */     }
/* 29:47 */     return this;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public Hasher putString(CharSequence charSequence, Charset charset)
/* 33:   */   {
/* 34:52 */     return putBytes(charSequence.toString().getBytes(charset));
/* 35:   */   }
/* 36:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.AbstractHasher
 * JD-Core Version:    0.7.0.1
 */