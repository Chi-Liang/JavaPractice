/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.base.Supplier;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.zip.Adler32;
/*  11:    */ import java.util.zip.CRC32;
/*  12:    */ import java.util.zip.Checksum;
/*  13:    */ import javax.annotation.CheckReturnValue;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @CheckReturnValue
/*  17:    */ @Beta
/*  18:    */ public final class Hashing
/*  19:    */ {
/*  20:    */   public static HashFunction goodFastHash(int minimumBits)
/*  21:    */   {
/*  22: 66 */     int bits = checkPositiveAndMakeMultipleOf32(minimumBits);
/*  23: 68 */     if (bits == 32) {
/*  24: 69 */       return Murmur3_32Holder.GOOD_FAST_HASH_FUNCTION_32;
/*  25:    */     }
/*  26: 71 */     if (bits <= 128) {
/*  27: 72 */       return Murmur3_128Holder.GOOD_FAST_HASH_FUNCTION_128;
/*  28:    */     }
/*  29: 76 */     int hashFunctionsNeeded = (bits + 127) / 128;
/*  30: 77 */     HashFunction[] hashFunctions = new HashFunction[hashFunctionsNeeded];
/*  31: 78 */     hashFunctions[0] = Murmur3_128Holder.GOOD_FAST_HASH_FUNCTION_128;
/*  32: 79 */     int seed = GOOD_FAST_HASH_SEED;
/*  33: 80 */     for (int i = 1; i < hashFunctionsNeeded; i++)
/*  34:    */     {
/*  35: 81 */       seed += 1500450271;
/*  36: 82 */       hashFunctions[i] = murmur3_128(seed);
/*  37:    */     }
/*  38: 84 */     return new ConcatenatedHashFunction(hashFunctions, null);
/*  39:    */   }
/*  40:    */   
/*  41: 91 */   private static final int GOOD_FAST_HASH_SEED = (int)System.currentTimeMillis();
/*  42:    */   
/*  43:    */   public static HashFunction murmur3_32(int seed)
/*  44:    */   {
/*  45:102 */     return new Murmur3_32HashFunction(seed);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static HashFunction murmur3_32()
/*  49:    */   {
/*  50:114 */     return Murmur3_32Holder.MURMUR3_32;
/*  51:    */   }
/*  52:    */   
/*  53:    */   private static class Murmur3_32Holder
/*  54:    */   {
/*  55:118 */     static final HashFunction MURMUR3_32 = new Murmur3_32HashFunction(0);
/*  56:121 */     static final HashFunction GOOD_FAST_HASH_FUNCTION_32 = Hashing.murmur3_32(Hashing.GOOD_FAST_HASH_SEED);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static HashFunction murmur3_128(int seed)
/*  60:    */   {
/*  61:133 */     return new Murmur3_128HashFunction(seed);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static HashFunction murmur3_128()
/*  65:    */   {
/*  66:145 */     return Murmur3_128Holder.MURMUR3_128;
/*  67:    */   }
/*  68:    */   
/*  69:    */   private static class Murmur3_128Holder
/*  70:    */   {
/*  71:149 */     static final HashFunction MURMUR3_128 = new Murmur3_128HashFunction(0);
/*  72:152 */     static final HashFunction GOOD_FAST_HASH_FUNCTION_128 = Hashing.murmur3_128(Hashing.GOOD_FAST_HASH_SEED);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static HashFunction sipHash24()
/*  76:    */   {
/*  77:163 */     return SipHash24Holder.SIP_HASH_24;
/*  78:    */   }
/*  79:    */   
/*  80:    */   private static class SipHash24Holder
/*  81:    */   {
/*  82:167 */     static final HashFunction SIP_HASH_24 = new SipHashFunction(2, 4, 506097522914230528L, 1084818905618843912L);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static HashFunction sipHash24(long k0, long k1)
/*  86:    */   {
/*  87:179 */     return new SipHashFunction(2, 4, k0, k1);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static HashFunction md5()
/*  91:    */   {
/*  92:187 */     return Md5Holder.MD5;
/*  93:    */   }
/*  94:    */   
/*  95:    */   private static class Md5Holder
/*  96:    */   {
/*  97:191 */     static final HashFunction MD5 = new MessageDigestHashFunction("MD5", "Hashing.md5()");
/*  98:    */   }
/*  99:    */   
/* 100:    */   public static HashFunction sha1()
/* 101:    */   {
/* 102:199 */     return Sha1Holder.SHA_1;
/* 103:    */   }
/* 104:    */   
/* 105:    */   private static class Sha1Holder
/* 106:    */   {
/* 107:203 */     static final HashFunction SHA_1 = new MessageDigestHashFunction("SHA-1", "Hashing.sha1()");
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static HashFunction sha256()
/* 111:    */   {
/* 112:211 */     return Sha256Holder.SHA_256;
/* 113:    */   }
/* 114:    */   
/* 115:    */   private static class Sha256Holder
/* 116:    */   {
/* 117:215 */     static final HashFunction SHA_256 = new MessageDigestHashFunction("SHA-256", "Hashing.sha256()");
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static HashFunction sha384()
/* 121:    */   {
/* 122:226 */     return Sha384Holder.SHA_384;
/* 123:    */   }
/* 124:    */   
/* 125:    */   private static class Sha384Holder
/* 126:    */   {
/* 127:230 */     static final HashFunction SHA_384 = new MessageDigestHashFunction("SHA-384", "Hashing.sha384()");
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static HashFunction sha512()
/* 131:    */   {
/* 132:239 */     return Sha512Holder.SHA_512;
/* 133:    */   }
/* 134:    */   
/* 135:    */   private static class Sha512Holder
/* 136:    */   {
/* 137:243 */     static final HashFunction SHA_512 = new MessageDigestHashFunction("SHA-512", "Hashing.sha512()");
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static HashFunction crc32c()
/* 141:    */   {
/* 142:254 */     return Crc32cHolder.CRC_32_C;
/* 143:    */   }
/* 144:    */   
/* 145:    */   private static final class Crc32cHolder
/* 146:    */   {
/* 147:258 */     static final HashFunction CRC_32_C = new Crc32cHashFunction();
/* 148:    */   }
/* 149:    */   
/* 150:    */   public static HashFunction crc32()
/* 151:    */   {
/* 152:271 */     return Crc32Holder.CRC_32;
/* 153:    */   }
/* 154:    */   
/* 155:    */   private static class Crc32Holder
/* 156:    */   {
/* 157:275 */     static final HashFunction CRC_32 = Hashing.checksumHashFunction(Hashing.ChecksumType.CRC_32, "Hashing.crc32()");
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static HashFunction adler32()
/* 161:    */   {
/* 162:288 */     return Adler32Holder.ADLER_32;
/* 163:    */   }
/* 164:    */   
/* 165:    */   private static class Adler32Holder
/* 166:    */   {
/* 167:292 */     static final HashFunction ADLER_32 = Hashing.checksumHashFunction(Hashing.ChecksumType.ADLER_32, "Hashing.adler32()");
/* 168:    */   }
/* 169:    */   
/* 170:    */   private static HashFunction checksumHashFunction(ChecksumType type, String toString)
/* 171:    */   {
/* 172:297 */     return new ChecksumHashFunction(type, type.bits, toString);
/* 173:    */   }
/* 174:    */   
/* 175:    */   static abstract enum ChecksumType
/* 176:    */     implements Supplier<Checksum>
/* 177:    */   {
/* 178:301 */     CRC_32(32),  ADLER_32(32);
/* 179:    */     
/* 180:    */     private final int bits;
/* 181:    */     
/* 182:    */     private ChecksumType(int bits)
/* 183:    */     {
/* 184:317 */       this.bits = bits;
/* 185:    */     }
/* 186:    */     
/* 187:    */     public abstract Checksum get();
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static int consistentHash(HashCode hashCode, int buckets)
/* 191:    */   {
/* 192:356 */     return consistentHash(hashCode.padToLong(), buckets);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static int consistentHash(long input, int buckets)
/* 196:    */   {
/* 197:391 */     Preconditions.checkArgument(buckets > 0, "buckets must be positive: %s", new Object[] { Integer.valueOf(buckets) });
/* 198:392 */     LinearCongruentialGenerator generator = new LinearCongruentialGenerator(input);
/* 199:393 */     int candidate = 0;
/* 200:    */     for (;;)
/* 201:    */     {
/* 202:398 */       int next = (int)((candidate + 1) / generator.nextDouble());
/* 203:399 */       if ((next < 0) || (next >= buckets)) {
/* 204:    */         break;
/* 205:    */       }
/* 206:400 */       candidate = next;
/* 207:    */     }
/* 208:402 */     return candidate;
/* 209:    */   }
/* 210:    */   
/* 211:    */   public static HashCode combineOrdered(Iterable<HashCode> hashCodes)
/* 212:    */   {
/* 213:418 */     Iterator<HashCode> iterator = hashCodes.iterator();
/* 214:419 */     Preconditions.checkArgument(iterator.hasNext(), "Must be at least 1 hash code to combine.");
/* 215:420 */     int bits = ((HashCode)iterator.next()).bits();
/* 216:421 */     byte[] resultBytes = new byte[bits / 8];
/* 217:422 */     for (HashCode hashCode : hashCodes)
/* 218:    */     {
/* 219:423 */       byte[] nextBytes = hashCode.asBytes();
/* 220:424 */       Preconditions.checkArgument(nextBytes.length == resultBytes.length, "All hashcodes must have the same bit length.");
/* 221:426 */       for (int i = 0; i < nextBytes.length; i++) {
/* 222:427 */         resultBytes[i] = ((byte)(resultBytes[i] * 37 ^ nextBytes[i]));
/* 223:    */       }
/* 224:    */     }
/* 225:430 */     return HashCode.fromBytesNoCopy(resultBytes);
/* 226:    */   }
/* 227:    */   
/* 228:    */   public static HashCode combineUnordered(Iterable<HashCode> hashCodes)
/* 229:    */   {
/* 230:444 */     Iterator<HashCode> iterator = hashCodes.iterator();
/* 231:445 */     Preconditions.checkArgument(iterator.hasNext(), "Must be at least 1 hash code to combine.");
/* 232:446 */     byte[] resultBytes = new byte[((HashCode)iterator.next()).bits() / 8];
/* 233:447 */     for (HashCode hashCode : hashCodes)
/* 234:    */     {
/* 235:448 */       byte[] nextBytes = hashCode.asBytes();
/* 236:449 */       Preconditions.checkArgument(nextBytes.length == resultBytes.length, "All hashcodes must have the same bit length.");
/* 237:451 */       for (int i = 0; i < nextBytes.length; tmp102_100++)
/* 238:    */       {
/* 239:452 */         int tmp102_100 = i; byte[] tmp102_99 = resultBytes;tmp102_99[tmp102_100] = ((byte)(tmp102_99[tmp102_100] + nextBytes[tmp102_100]));
/* 240:    */       }
/* 241:    */     }
/* 242:455 */     return HashCode.fromBytesNoCopy(resultBytes);
/* 243:    */   }
/* 244:    */   
/* 245:    */   static int checkPositiveAndMakeMultipleOf32(int bits)
/* 246:    */   {
/* 247:462 */     Preconditions.checkArgument(bits > 0, "Number of bits must be positive");
/* 248:463 */     return bits + 31 & 0xFFFFFFE0;
/* 249:    */   }
/* 250:    */   
/* 251:    */   public static HashFunction concatenating(HashFunction first, HashFunction second, HashFunction... rest)
/* 252:    */   {
/* 253:479 */     List<HashFunction> list = new ArrayList();
/* 254:480 */     list.add(first);
/* 255:481 */     list.add(second);
/* 256:482 */     for (HashFunction hashFunc : rest) {
/* 257:483 */       list.add(hashFunc);
/* 258:    */     }
/* 259:485 */     return new ConcatenatedHashFunction((HashFunction[])list.toArray(new HashFunction[0]), null);
/* 260:    */   }
/* 261:    */   
/* 262:    */   public static HashFunction concatenating(Iterable<HashFunction> hashFunctions)
/* 263:    */   {
/* 264:499 */     Preconditions.checkNotNull(hashFunctions);
/* 265:    */     
/* 266:501 */     List<HashFunction> list = new ArrayList();
/* 267:502 */     for (HashFunction hashFunction : hashFunctions) {
/* 268:503 */       list.add(hashFunction);
/* 269:    */     }
/* 270:505 */     Preconditions.checkArgument(list.size() > 0, "number of hash functions (%s) must be > 0", new Object[] { Integer.valueOf(list.size()) });
/* 271:506 */     return new ConcatenatedHashFunction((HashFunction[])list.toArray(new HashFunction[0]), null);
/* 272:    */   }
/* 273:    */   
/* 274:    */   private static final class ConcatenatedHashFunction
/* 275:    */     extends AbstractCompositeHashFunction
/* 276:    */   {
/* 277:    */     private final int bits;
/* 278:    */     
/* 279:    */     private ConcatenatedHashFunction(HashFunction... functions)
/* 280:    */     {
/* 281:513 */       super();
/* 282:514 */       int bitSum = 0;
/* 283:515 */       for (HashFunction function : functions)
/* 284:    */       {
/* 285:516 */         bitSum += function.bits();
/* 286:517 */         Preconditions.checkArgument(function.bits() % 8 == 0, "the number of bits (%s) in hashFunction (%s) must be divisible by 8", new Object[] { Integer.valueOf(function.bits()), function });
/* 287:    */       }
/* 288:523 */       this.bits = bitSum;
/* 289:    */     }
/* 290:    */     
/* 291:    */     HashCode makeHash(Hasher[] hashers)
/* 292:    */     {
/* 293:528 */       byte[] bytes = new byte[this.bits / 8];
/* 294:529 */       int i = 0;
/* 295:530 */       for (Hasher hasher : hashers)
/* 296:    */       {
/* 297:531 */         HashCode newHash = hasher.hash();
/* 298:532 */         i += newHash.writeBytesTo(bytes, i, newHash.bits() / 8);
/* 299:    */       }
/* 300:534 */       return HashCode.fromBytesNoCopy(bytes);
/* 301:    */     }
/* 302:    */     
/* 303:    */     public int bits()
/* 304:    */     {
/* 305:539 */       return this.bits;
/* 306:    */     }
/* 307:    */     
/* 308:    */     public boolean equals(@Nullable Object object)
/* 309:    */     {
/* 310:544 */       if ((object instanceof ConcatenatedHashFunction))
/* 311:    */       {
/* 312:545 */         ConcatenatedHashFunction other = (ConcatenatedHashFunction)object;
/* 313:546 */         return Arrays.equals(this.functions, other.functions);
/* 314:    */       }
/* 315:548 */       return false;
/* 316:    */     }
/* 317:    */     
/* 318:    */     public int hashCode()
/* 319:    */     {
/* 320:553 */       return Arrays.hashCode(this.functions) * 31 + this.bits;
/* 321:    */     }
/* 322:    */   }
/* 323:    */   
/* 324:    */   private static final class LinearCongruentialGenerator
/* 325:    */   {
/* 326:    */     private long state;
/* 327:    */     
/* 328:    */     public LinearCongruentialGenerator(long seed)
/* 329:    */     {
/* 330:565 */       this.state = seed;
/* 331:    */     }
/* 332:    */     
/* 333:    */     public double nextDouble()
/* 334:    */     {
/* 335:569 */       this.state = (2862933555777941757L * this.state + 1L);
/* 336:570 */       return ((int)(this.state >>> 33) + 1) / 2147483648.0D;
/* 337:    */     }
/* 338:    */   }
/* 339:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.Hashing
 * JD-Core Version:    0.7.0.1
 */