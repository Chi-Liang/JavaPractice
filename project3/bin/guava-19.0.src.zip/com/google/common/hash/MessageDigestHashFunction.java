/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.security.MessageDigest;
/*   6:    */ import java.security.NoSuchAlgorithmException;
/*   7:    */ import java.util.Arrays;
/*   8:    */ 
/*   9:    */ final class MessageDigestHashFunction
/*  10:    */   extends AbstractStreamingHashFunction
/*  11:    */   implements Serializable
/*  12:    */ {
/*  13:    */   private final MessageDigest prototype;
/*  14:    */   private final int bytes;
/*  15:    */   private final boolean supportsClone;
/*  16:    */   private final String toString;
/*  17:    */   
/*  18:    */   MessageDigestHashFunction(String algorithmName, String toString)
/*  19:    */   {
/*  20: 40 */     this.prototype = getMessageDigest(algorithmName);
/*  21: 41 */     this.bytes = this.prototype.getDigestLength();
/*  22: 42 */     this.toString = ((String)Preconditions.checkNotNull(toString));
/*  23: 43 */     this.supportsClone = supportsClone();
/*  24:    */   }
/*  25:    */   
/*  26:    */   MessageDigestHashFunction(String algorithmName, int bytes, String toString)
/*  27:    */   {
/*  28: 47 */     this.toString = ((String)Preconditions.checkNotNull(toString));
/*  29: 48 */     this.prototype = getMessageDigest(algorithmName);
/*  30: 49 */     int maxLength = this.prototype.getDigestLength();
/*  31: 50 */     Preconditions.checkArgument((bytes >= 4) && (bytes <= maxLength), "bytes (%s) must be >= 4 and < %s", new Object[] { Integer.valueOf(bytes), Integer.valueOf(maxLength) });
/*  32:    */     
/*  33: 52 */     this.bytes = bytes;
/*  34: 53 */     this.supportsClone = supportsClone();
/*  35:    */   }
/*  36:    */   
/*  37:    */   private boolean supportsClone()
/*  38:    */   {
/*  39:    */     try
/*  40:    */     {
/*  41: 58 */       this.prototype.clone();
/*  42: 59 */       return true;
/*  43:    */     }
/*  44:    */     catch (CloneNotSupportedException e) {}
/*  45: 61 */     return false;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public int bits()
/*  49:    */   {
/*  50: 67 */     return this.bytes * 8;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public String toString()
/*  54:    */   {
/*  55: 72 */     return this.toString;
/*  56:    */   }
/*  57:    */   
/*  58:    */   private static MessageDigest getMessageDigest(String algorithmName)
/*  59:    */   {
/*  60:    */     try
/*  61:    */     {
/*  62: 77 */       return MessageDigest.getInstance(algorithmName);
/*  63:    */     }
/*  64:    */     catch (NoSuchAlgorithmException e)
/*  65:    */     {
/*  66: 79 */       throw new AssertionError(e);
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Hasher newHasher()
/*  71:    */   {
/*  72: 85 */     if (this.supportsClone) {
/*  73:    */       try
/*  74:    */       {
/*  75: 87 */         return new MessageDigestHasher((MessageDigest)this.prototype.clone(), this.bytes, null);
/*  76:    */       }
/*  77:    */       catch (CloneNotSupportedException e) {}
/*  78:    */     }
/*  79: 92 */     return new MessageDigestHasher(getMessageDigest(this.prototype.getAlgorithm()), this.bytes, null);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private static final class SerializedForm
/*  83:    */     implements Serializable
/*  84:    */   {
/*  85:    */     private final String algorithmName;
/*  86:    */     private final int bytes;
/*  87:    */     private final String toString;
/*  88:    */     private static final long serialVersionUID = 0L;
/*  89:    */     
/*  90:    */     private SerializedForm(String algorithmName, int bytes, String toString)
/*  91:    */     {
/*  92:101 */       this.algorithmName = algorithmName;
/*  93:102 */       this.bytes = bytes;
/*  94:103 */       this.toString = toString;
/*  95:    */     }
/*  96:    */     
/*  97:    */     private Object readResolve()
/*  98:    */     {
/*  99:107 */       return new MessageDigestHashFunction(this.algorithmName, this.bytes, this.toString);
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   Object writeReplace()
/* 104:    */   {
/* 105:114 */     return new SerializedForm(this.prototype.getAlgorithm(), this.bytes, this.toString, null);
/* 106:    */   }
/* 107:    */   
/* 108:    */   private static final class MessageDigestHasher
/* 109:    */     extends AbstractByteHasher
/* 110:    */   {
/* 111:    */     private final MessageDigest digest;
/* 112:    */     private final int bytes;
/* 113:    */     private boolean done;
/* 114:    */     
/* 115:    */     private MessageDigestHasher(MessageDigest digest, int bytes)
/* 116:    */     {
/* 117:126 */       this.digest = digest;
/* 118:127 */       this.bytes = bytes;
/* 119:    */     }
/* 120:    */     
/* 121:    */     protected void update(byte b)
/* 122:    */     {
/* 123:132 */       checkNotDone();
/* 124:133 */       this.digest.update(b);
/* 125:    */     }
/* 126:    */     
/* 127:    */     protected void update(byte[] b)
/* 128:    */     {
/* 129:138 */       checkNotDone();
/* 130:139 */       this.digest.update(b);
/* 131:    */     }
/* 132:    */     
/* 133:    */     protected void update(byte[] b, int off, int len)
/* 134:    */     {
/* 135:144 */       checkNotDone();
/* 136:145 */       this.digest.update(b, off, len);
/* 137:    */     }
/* 138:    */     
/* 139:    */     private void checkNotDone()
/* 140:    */     {
/* 141:149 */       Preconditions.checkState(!this.done, "Cannot re-use a Hasher after calling hash() on it");
/* 142:    */     }
/* 143:    */     
/* 144:    */     public HashCode hash()
/* 145:    */     {
/* 146:154 */       checkNotDone();
/* 147:155 */       this.done = true;
/* 148:156 */       return this.bytes == this.digest.getDigestLength() ? HashCode.fromBytesNoCopy(this.digest.digest()) : HashCode.fromBytesNoCopy(Arrays.copyOf(this.digest.digest(), this.bytes));
/* 149:    */     }
/* 150:    */   }
/* 151:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.MessageDigestHashFunction
 * JD-Core Version:    0.7.0.1
 */