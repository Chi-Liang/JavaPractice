/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.OutputStream;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.nio.charset.Charset;
/*   8:    */ import javax.annotation.CheckReturnValue;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @CheckReturnValue
/*  12:    */ @Beta
/*  13:    */ public final class Funnels
/*  14:    */ {
/*  15:    */   public static Funnel<byte[]> byteArrayFunnel()
/*  16:    */   {
/*  17: 42 */     return ByteArrayFunnel.INSTANCE;
/*  18:    */   }
/*  19:    */   
/*  20:    */   private static enum ByteArrayFunnel
/*  21:    */     implements Funnel<byte[]>
/*  22:    */   {
/*  23: 46 */     INSTANCE;
/*  24:    */     
/*  25:    */     private ByteArrayFunnel() {}
/*  26:    */     
/*  27:    */     public void funnel(byte[] from, PrimitiveSink into)
/*  28:    */     {
/*  29: 49 */       into.putBytes(from);
/*  30:    */     }
/*  31:    */     
/*  32:    */     public String toString()
/*  33:    */     {
/*  34: 54 */       return "Funnels.byteArrayFunnel()";
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static Funnel<CharSequence> unencodedCharsFunnel()
/*  39:    */   {
/*  40: 66 */     return UnencodedCharsFunnel.INSTANCE;
/*  41:    */   }
/*  42:    */   
/*  43:    */   private static enum UnencodedCharsFunnel
/*  44:    */     implements Funnel<CharSequence>
/*  45:    */   {
/*  46: 70 */     INSTANCE;
/*  47:    */     
/*  48:    */     private UnencodedCharsFunnel() {}
/*  49:    */     
/*  50:    */     public void funnel(CharSequence from, PrimitiveSink into)
/*  51:    */     {
/*  52: 73 */       into.putUnencodedChars(from);
/*  53:    */     }
/*  54:    */     
/*  55:    */     public String toString()
/*  56:    */     {
/*  57: 78 */       return "Funnels.unencodedCharsFunnel()";
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static Funnel<CharSequence> stringFunnel(Charset charset)
/*  62:    */   {
/*  63: 89 */     return new StringCharsetFunnel(charset);
/*  64:    */   }
/*  65:    */   
/*  66:    */   private static class StringCharsetFunnel
/*  67:    */     implements Funnel<CharSequence>, Serializable
/*  68:    */   {
/*  69:    */     private final Charset charset;
/*  70:    */     
/*  71:    */     StringCharsetFunnel(Charset charset)
/*  72:    */     {
/*  73: 96 */       this.charset = ((Charset)Preconditions.checkNotNull(charset));
/*  74:    */     }
/*  75:    */     
/*  76:    */     public void funnel(CharSequence from, PrimitiveSink into)
/*  77:    */     {
/*  78:100 */       into.putString(from, this.charset);
/*  79:    */     }
/*  80:    */     
/*  81:    */     public String toString()
/*  82:    */     {
/*  83:105 */       return "Funnels.stringFunnel(" + this.charset.name() + ")";
/*  84:    */     }
/*  85:    */     
/*  86:    */     public boolean equals(@Nullable Object o)
/*  87:    */     {
/*  88:110 */       if ((o instanceof StringCharsetFunnel))
/*  89:    */       {
/*  90:111 */         StringCharsetFunnel funnel = (StringCharsetFunnel)o;
/*  91:112 */         return this.charset.equals(funnel.charset);
/*  92:    */       }
/*  93:114 */       return false;
/*  94:    */     }
/*  95:    */     
/*  96:    */     public int hashCode()
/*  97:    */     {
/*  98:119 */       return StringCharsetFunnel.class.hashCode() ^ this.charset.hashCode();
/*  99:    */     }
/* 100:    */     
/* 101:    */     Object writeReplace()
/* 102:    */     {
/* 103:123 */       return new SerializedForm(this.charset);
/* 104:    */     }
/* 105:    */     
/* 106:    */     private static class SerializedForm
/* 107:    */       implements Serializable
/* 108:    */     {
/* 109:    */       private final String charsetCanonicalName;
/* 110:    */       private static final long serialVersionUID = 0L;
/* 111:    */       
/* 112:    */       SerializedForm(Charset charset)
/* 113:    */       {
/* 114:130 */         this.charsetCanonicalName = charset.name();
/* 115:    */       }
/* 116:    */       
/* 117:    */       private Object readResolve()
/* 118:    */       {
/* 119:134 */         return Funnels.stringFunnel(Charset.forName(this.charsetCanonicalName));
/* 120:    */       }
/* 121:    */     }
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static Funnel<Integer> integerFunnel()
/* 125:    */   {
/* 126:147 */     return IntegerFunnel.INSTANCE;
/* 127:    */   }
/* 128:    */   
/* 129:    */   private static enum IntegerFunnel
/* 130:    */     implements Funnel<Integer>
/* 131:    */   {
/* 132:151 */     INSTANCE;
/* 133:    */     
/* 134:    */     private IntegerFunnel() {}
/* 135:    */     
/* 136:    */     public void funnel(Integer from, PrimitiveSink into)
/* 137:    */     {
/* 138:154 */       into.putInt(from.intValue());
/* 139:    */     }
/* 140:    */     
/* 141:    */     public String toString()
/* 142:    */     {
/* 143:159 */       return "Funnels.integerFunnel()";
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static <E> Funnel<Iterable<? extends E>> sequentialFunnel(Funnel<E> elementFunnel)
/* 148:    */   {
/* 149:170 */     return new SequentialFunnel(elementFunnel);
/* 150:    */   }
/* 151:    */   
/* 152:    */   private static class SequentialFunnel<E>
/* 153:    */     implements Funnel<Iterable<? extends E>>, Serializable
/* 154:    */   {
/* 155:    */     private final Funnel<E> elementFunnel;
/* 156:    */     
/* 157:    */     SequentialFunnel(Funnel<E> elementFunnel)
/* 158:    */     {
/* 159:177 */       this.elementFunnel = ((Funnel)Preconditions.checkNotNull(elementFunnel));
/* 160:    */     }
/* 161:    */     
/* 162:    */     public void funnel(Iterable<? extends E> from, PrimitiveSink into)
/* 163:    */     {
/* 164:181 */       for (E e : from) {
/* 165:182 */         this.elementFunnel.funnel(e, into);
/* 166:    */       }
/* 167:    */     }
/* 168:    */     
/* 169:    */     public String toString()
/* 170:    */     {
/* 171:188 */       return "Funnels.sequentialFunnel(" + this.elementFunnel + ")";
/* 172:    */     }
/* 173:    */     
/* 174:    */     public boolean equals(@Nullable Object o)
/* 175:    */     {
/* 176:193 */       if ((o instanceof SequentialFunnel))
/* 177:    */       {
/* 178:194 */         SequentialFunnel<?> funnel = (SequentialFunnel)o;
/* 179:195 */         return this.elementFunnel.equals(funnel.elementFunnel);
/* 180:    */       }
/* 181:197 */       return false;
/* 182:    */     }
/* 183:    */     
/* 184:    */     public int hashCode()
/* 185:    */     {
/* 186:202 */       return SequentialFunnel.class.hashCode() ^ this.elementFunnel.hashCode();
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static Funnel<Long> longFunnel()
/* 191:    */   {
/* 192:212 */     return LongFunnel.INSTANCE;
/* 193:    */   }
/* 194:    */   
/* 195:    */   private static enum LongFunnel
/* 196:    */     implements Funnel<Long>
/* 197:    */   {
/* 198:216 */     INSTANCE;
/* 199:    */     
/* 200:    */     private LongFunnel() {}
/* 201:    */     
/* 202:    */     public void funnel(Long from, PrimitiveSink into)
/* 203:    */     {
/* 204:219 */       into.putLong(from.longValue());
/* 205:    */     }
/* 206:    */     
/* 207:    */     public String toString()
/* 208:    */     {
/* 209:224 */       return "Funnels.longFunnel()";
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   public static OutputStream asOutputStream(PrimitiveSink sink)
/* 214:    */   {
/* 215:239 */     return new SinkAsStream(sink);
/* 216:    */   }
/* 217:    */   
/* 218:    */   private static class SinkAsStream
/* 219:    */     extends OutputStream
/* 220:    */   {
/* 221:    */     final PrimitiveSink sink;
/* 222:    */     
/* 223:    */     SinkAsStream(PrimitiveSink sink)
/* 224:    */     {
/* 225:246 */       this.sink = ((PrimitiveSink)Preconditions.checkNotNull(sink));
/* 226:    */     }
/* 227:    */     
/* 228:    */     public void write(int b)
/* 229:    */     {
/* 230:251 */       this.sink.putByte((byte)b);
/* 231:    */     }
/* 232:    */     
/* 233:    */     public void write(byte[] bytes)
/* 234:    */     {
/* 235:256 */       this.sink.putBytes(bytes);
/* 236:    */     }
/* 237:    */     
/* 238:    */     public void write(byte[] bytes, int off, int len)
/* 239:    */     {
/* 240:261 */       this.sink.putBytes(bytes, off, len);
/* 241:    */     }
/* 242:    */     
/* 243:    */     public String toString()
/* 244:    */     {
/* 245:266 */       return "Funnels.asOutputStream(" + this.sink + ")";
/* 246:    */     }
/* 247:    */   }
/* 248:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.Funnels
 * JD-Core Version:    0.7.0.1
 */