/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.math.LongMath;
/*   5:    */ import com.google.common.primitives.Ints;
/*   6:    */ import com.google.common.primitives.Longs;
/*   7:    */ import java.math.RoundingMode;
/*   8:    */ import java.util.Arrays;
/*   9:    */ 
/*  10:    */  enum BloomFilterStrategies
/*  11:    */   implements BloomFilter.Strategy
/*  12:    */ {
/*  13: 44 */   MURMUR128_MITZ_32,  MURMUR128_MITZ_64;
/*  14:    */   
/*  15:    */   private BloomFilterStrategies() {}
/*  16:    */   
/*  17:    */   static final class BitArray
/*  18:    */   {
/*  19:    */     final long[] data;
/*  20:    */     long bitCount;
/*  21:    */     
/*  22:    */     BitArray(long bits)
/*  23:    */     {
/*  24:147 */       this(new long[Ints.checkedCast(LongMath.divide(bits, 64L, RoundingMode.CEILING))]);
/*  25:    */     }
/*  26:    */     
/*  27:    */     BitArray(long[] data)
/*  28:    */     {
/*  29:152 */       Preconditions.checkArgument(data.length > 0, "data length is zero!");
/*  30:153 */       this.data = data;
/*  31:154 */       long bitCount = 0L;
/*  32:155 */       for (long value : data) {
/*  33:156 */         bitCount += Long.bitCount(value);
/*  34:    */       }
/*  35:158 */       this.bitCount = bitCount;
/*  36:    */     }
/*  37:    */     
/*  38:    */     boolean set(long index)
/*  39:    */     {
/*  40:163 */       if (!get(index))
/*  41:    */       {
/*  42:164 */         this.data[((int)(index >>> 6))] |= 1L << (int)index;
/*  43:165 */         this.bitCount += 1L;
/*  44:166 */         return true;
/*  45:    */       }
/*  46:168 */       return false;
/*  47:    */     }
/*  48:    */     
/*  49:    */     boolean get(long index)
/*  50:    */     {
/*  51:172 */       return (this.data[((int)(index >>> 6))] & 1L << (int)index) != 0L;
/*  52:    */     }
/*  53:    */     
/*  54:    */     long bitSize()
/*  55:    */     {
/*  56:177 */       return this.data.length * 64L;
/*  57:    */     }
/*  58:    */     
/*  59:    */     long bitCount()
/*  60:    */     {
/*  61:182 */       return this.bitCount;
/*  62:    */     }
/*  63:    */     
/*  64:    */     BitArray copy()
/*  65:    */     {
/*  66:186 */       return new BitArray((long[])this.data.clone());
/*  67:    */     }
/*  68:    */     
/*  69:    */     void putAll(BitArray array)
/*  70:    */     {
/*  71:191 */       Preconditions.checkArgument(this.data.length == array.data.length, "BitArrays must be of equal length (%s != %s)", new Object[] { Integer.valueOf(this.data.length), Integer.valueOf(array.data.length) });
/*  72:    */       
/*  73:    */ 
/*  74:    */ 
/*  75:    */ 
/*  76:196 */       this.bitCount = 0L;
/*  77:197 */       for (int i = 0; i < this.data.length; i++)
/*  78:    */       {
/*  79:198 */         this.data[i] |= array.data[i];
/*  80:199 */         this.bitCount += Long.bitCount(this.data[i]);
/*  81:    */       }
/*  82:    */     }
/*  83:    */     
/*  84:    */     public boolean equals(Object o)
/*  85:    */     {
/*  86:205 */       if ((o instanceof BitArray))
/*  87:    */       {
/*  88:206 */         BitArray bitArray = (BitArray)o;
/*  89:207 */         return Arrays.equals(this.data, bitArray.data);
/*  90:    */       }
/*  91:209 */       return false;
/*  92:    */     }
/*  93:    */     
/*  94:    */     public int hashCode()
/*  95:    */     {
/*  96:214 */       return Arrays.hashCode(this.data);
/*  97:    */     }
/*  98:    */   }
/*  99:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.BloomFilterStrategies
 * JD-Core Version:    0.7.0.1
 */