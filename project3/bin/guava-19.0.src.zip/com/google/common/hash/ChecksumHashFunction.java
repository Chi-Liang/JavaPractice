/*  1:   */ package com.google.common.hash;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import com.google.common.base.Supplier;
/*  5:   */ import java.io.Serializable;
/*  6:   */ import java.util.zip.Checksum;
/*  7:   */ 
/*  8:   */ final class ChecksumHashFunction
/*  9:   */   extends AbstractStreamingHashFunction
/* 10:   */   implements Serializable
/* 11:   */ {
/* 12:   */   private final Supplier<? extends Checksum> checksumSupplier;
/* 13:   */   private final int bits;
/* 14:   */   private final String toString;
/* 15:   */   private static final long serialVersionUID = 0L;
/* 16:   */   
/* 17:   */   ChecksumHashFunction(Supplier<? extends Checksum> checksumSupplier, int bits, String toString)
/* 18:   */   {
/* 19:36 */     this.checksumSupplier = ((Supplier)Preconditions.checkNotNull(checksumSupplier));
/* 20:37 */     Preconditions.checkArgument((bits == 32) || (bits == 64), "bits (%s) must be either 32 or 64", new Object[] { Integer.valueOf(bits) });
/* 21:38 */     this.bits = bits;
/* 22:39 */     this.toString = ((String)Preconditions.checkNotNull(toString));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public int bits()
/* 26:   */   {
/* 27:44 */     return this.bits;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Hasher newHasher()
/* 31:   */   {
/* 32:49 */     return new ChecksumHasher((Checksum)this.checksumSupplier.get(), null);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public String toString()
/* 36:   */   {
/* 37:54 */     return this.toString;
/* 38:   */   }
/* 39:   */   
/* 40:   */   private final class ChecksumHasher
/* 41:   */     extends AbstractByteHasher
/* 42:   */   {
/* 43:   */     private final Checksum checksum;
/* 44:   */     
/* 45:   */     private ChecksumHasher(Checksum checksum)
/* 46:   */     {
/* 47:64 */       this.checksum = ((Checksum)Preconditions.checkNotNull(checksum));
/* 48:   */     }
/* 49:   */     
/* 50:   */     protected void update(byte b)
/* 51:   */     {
/* 52:69 */       this.checksum.update(b);
/* 53:   */     }
/* 54:   */     
/* 55:   */     protected void update(byte[] bytes, int off, int len)
/* 56:   */     {
/* 57:74 */       this.checksum.update(bytes, off, len);
/* 58:   */     }
/* 59:   */     
/* 60:   */     public HashCode hash()
/* 61:   */     {
/* 62:79 */       long value = this.checksum.getValue();
/* 63:80 */       if (ChecksumHashFunction.this.bits == 32) {
/* 64:86 */         return HashCode.fromInt((int)value);
/* 65:   */       }
/* 66:88 */       return HashCode.fromLong(value);
/* 67:   */     }
/* 68:   */   }
/* 69:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.ChecksumHashFunction
 * JD-Core Version:    0.7.0.1
 */