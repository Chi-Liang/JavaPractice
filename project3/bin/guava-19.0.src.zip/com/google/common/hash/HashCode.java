/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.primitives.Ints;
/*   6:    */ import com.google.common.primitives.UnsignedInts;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import javax.annotation.CheckReturnValue;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @Beta
/*  12:    */ public abstract class HashCode
/*  13:    */ {
/*  14:    */   @CheckReturnValue
/*  15:    */   public abstract int bits();
/*  16:    */   
/*  17:    */   @CheckReturnValue
/*  18:    */   public abstract int asInt();
/*  19:    */   
/*  20:    */   @CheckReturnValue
/*  21:    */   public abstract long asLong();
/*  22:    */   
/*  23:    */   @CheckReturnValue
/*  24:    */   public abstract long padToLong();
/*  25:    */   
/*  26:    */   @CheckReturnValue
/*  27:    */   public abstract byte[] asBytes();
/*  28:    */   
/*  29:    */   public int writeBytesTo(byte[] dest, int offset, int maxLength)
/*  30:    */   {
/*  31: 95 */     maxLength = Ints.min(new int[] { maxLength, bits() / 8 });
/*  32: 96 */     Preconditions.checkPositionIndexes(offset, offset + maxLength, dest.length);
/*  33: 97 */     writeBytesToImpl(dest, offset, maxLength);
/*  34: 98 */     return maxLength;
/*  35:    */   }
/*  36:    */   
/*  37:    */   abstract void writeBytesToImpl(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
/*  38:    */   
/*  39:    */   byte[] getBytesInternal()
/*  40:    */   {
/*  41:109 */     return asBytes();
/*  42:    */   }
/*  43:    */   
/*  44:    */   abstract boolean equalsSameBits(HashCode paramHashCode);
/*  45:    */   
/*  46:    */   @CheckReturnValue
/*  47:    */   public static HashCode fromInt(int hash)
/*  48:    */   {
/*  49:126 */     return new IntHashCode(hash);
/*  50:    */   }
/*  51:    */   
/*  52:    */   private static final class IntHashCode
/*  53:    */     extends HashCode
/*  54:    */     implements Serializable
/*  55:    */   {
/*  56:    */     final int hash;
/*  57:    */     private static final long serialVersionUID = 0L;
/*  58:    */     
/*  59:    */     IntHashCode(int hash)
/*  60:    */     {
/*  61:133 */       this.hash = hash;
/*  62:    */     }
/*  63:    */     
/*  64:    */     public int bits()
/*  65:    */     {
/*  66:138 */       return 32;
/*  67:    */     }
/*  68:    */     
/*  69:    */     public byte[] asBytes()
/*  70:    */     {
/*  71:143 */       return new byte[] { (byte)this.hash, (byte)(this.hash >> 8), (byte)(this.hash >> 16), (byte)(this.hash >> 24) };
/*  72:    */     }
/*  73:    */     
/*  74:    */     public int asInt()
/*  75:    */     {
/*  76:153 */       return this.hash;
/*  77:    */     }
/*  78:    */     
/*  79:    */     public long asLong()
/*  80:    */     {
/*  81:158 */       throw new IllegalStateException("this HashCode only has 32 bits; cannot create a long");
/*  82:    */     }
/*  83:    */     
/*  84:    */     public long padToLong()
/*  85:    */     {
/*  86:163 */       return UnsignedInts.toLong(this.hash);
/*  87:    */     }
/*  88:    */     
/*  89:    */     void writeBytesToImpl(byte[] dest, int offset, int maxLength)
/*  90:    */     {
/*  91:168 */       for (int i = 0; i < maxLength; i++) {
/*  92:169 */         dest[(offset + i)] = ((byte)(this.hash >> i * 8));
/*  93:    */       }
/*  94:    */     }
/*  95:    */     
/*  96:    */     boolean equalsSameBits(HashCode that)
/*  97:    */     {
/*  98:175 */       return this.hash == that.asInt();
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   @CheckReturnValue
/* 103:    */   public static HashCode fromLong(long hash)
/* 104:    */   {
/* 105:189 */     return new LongHashCode(hash);
/* 106:    */   }
/* 107:    */   
/* 108:    */   private static final class LongHashCode
/* 109:    */     extends HashCode
/* 110:    */     implements Serializable
/* 111:    */   {
/* 112:    */     final long hash;
/* 113:    */     private static final long serialVersionUID = 0L;
/* 114:    */     
/* 115:    */     LongHashCode(long hash)
/* 116:    */     {
/* 117:196 */       this.hash = hash;
/* 118:    */     }
/* 119:    */     
/* 120:    */     public int bits()
/* 121:    */     {
/* 122:201 */       return 64;
/* 123:    */     }
/* 124:    */     
/* 125:    */     public byte[] asBytes()
/* 126:    */     {
/* 127:206 */       return new byte[] { (byte)(int)this.hash, (byte)(int)(this.hash >> 8), (byte)(int)(this.hash >> 16), (byte)(int)(this.hash >> 24), (byte)(int)(this.hash >> 32), (byte)(int)(this.hash >> 40), (byte)(int)(this.hash >> 48), (byte)(int)(this.hash >> 56) };
/* 128:    */     }
/* 129:    */     
/* 130:    */     public int asInt()
/* 131:    */     {
/* 132:220 */       return (int)this.hash;
/* 133:    */     }
/* 134:    */     
/* 135:    */     public long asLong()
/* 136:    */     {
/* 137:225 */       return this.hash;
/* 138:    */     }
/* 139:    */     
/* 140:    */     public long padToLong()
/* 141:    */     {
/* 142:230 */       return this.hash;
/* 143:    */     }
/* 144:    */     
/* 145:    */     void writeBytesToImpl(byte[] dest, int offset, int maxLength)
/* 146:    */     {
/* 147:235 */       for (int i = 0; i < maxLength; i++) {
/* 148:236 */         dest[(offset + i)] = ((byte)(int)(this.hash >> i * 8));
/* 149:    */       }
/* 150:    */     }
/* 151:    */     
/* 152:    */     boolean equalsSameBits(HashCode that)
/* 153:    */     {
/* 154:242 */       return this.hash == that.asLong();
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   @CheckReturnValue
/* 159:    */   public static HashCode fromBytes(byte[] bytes)
/* 160:    */   {
/* 161:256 */     Preconditions.checkArgument(bytes.length >= 1, "A HashCode must contain at least 1 byte.");
/* 162:257 */     return fromBytesNoCopy((byte[])bytes.clone());
/* 163:    */   }
/* 164:    */   
/* 165:    */   static HashCode fromBytesNoCopy(byte[] bytes)
/* 166:    */   {
/* 167:265 */     return new BytesHashCode(bytes);
/* 168:    */   }
/* 169:    */   
/* 170:    */   private static final class BytesHashCode
/* 171:    */     extends HashCode
/* 172:    */     implements Serializable
/* 173:    */   {
/* 174:    */     final byte[] bytes;
/* 175:    */     private static final long serialVersionUID = 0L;
/* 176:    */     
/* 177:    */     BytesHashCode(byte[] bytes)
/* 178:    */     {
/* 179:272 */       this.bytes = ((byte[])Preconditions.checkNotNull(bytes));
/* 180:    */     }
/* 181:    */     
/* 182:    */     public int bits()
/* 183:    */     {
/* 184:277 */       return this.bytes.length * 8;
/* 185:    */     }
/* 186:    */     
/* 187:    */     public byte[] asBytes()
/* 188:    */     {
/* 189:282 */       return (byte[])this.bytes.clone();
/* 190:    */     }
/* 191:    */     
/* 192:    */     public int asInt()
/* 193:    */     {
/* 194:287 */       Preconditions.checkState(this.bytes.length >= 4, "HashCode#asInt() requires >= 4 bytes (it only has %s bytes).", new Object[] { Integer.valueOf(this.bytes.length) });
/* 195:    */       
/* 196:    */ 
/* 197:    */ 
/* 198:291 */       return this.bytes[0] & 0xFF | (this.bytes[1] & 0xFF) << 8 | (this.bytes[2] & 0xFF) << 16 | (this.bytes[3] & 0xFF) << 24;
/* 199:    */     }
/* 200:    */     
/* 201:    */     public long asLong()
/* 202:    */     {
/* 203:299 */       Preconditions.checkState(this.bytes.length >= 8, "HashCode#asLong() requires >= 8 bytes (it only has %s bytes).", new Object[] { Integer.valueOf(this.bytes.length) });
/* 204:    */       
/* 205:    */ 
/* 206:    */ 
/* 207:303 */       return padToLong();
/* 208:    */     }
/* 209:    */     
/* 210:    */     public long padToLong()
/* 211:    */     {
/* 212:308 */       long retVal = this.bytes[0] & 0xFF;
/* 213:309 */       for (int i = 1; i < Math.min(this.bytes.length, 8); i++) {
/* 214:310 */         retVal |= (this.bytes[i] & 0xFF) << i * 8;
/* 215:    */       }
/* 216:312 */       return retVal;
/* 217:    */     }
/* 218:    */     
/* 219:    */     void writeBytesToImpl(byte[] dest, int offset, int maxLength)
/* 220:    */     {
/* 221:317 */       System.arraycopy(this.bytes, 0, dest, offset, maxLength);
/* 222:    */     }
/* 223:    */     
/* 224:    */     byte[] getBytesInternal()
/* 225:    */     {
/* 226:322 */       return this.bytes;
/* 227:    */     }
/* 228:    */     
/* 229:    */     boolean equalsSameBits(HashCode that)
/* 230:    */     {
/* 231:329 */       if (this.bytes.length != that.getBytesInternal().length) {
/* 232:330 */         return false;
/* 233:    */       }
/* 234:333 */       boolean areEqual = true;
/* 235:334 */       for (int i = 0; i < this.bytes.length; i++) {
/* 236:335 */         areEqual &= this.bytes[i] == that.getBytesInternal()[i];
/* 237:    */       }
/* 238:337 */       return areEqual;
/* 239:    */     }
/* 240:    */   }
/* 241:    */   
/* 242:    */   @CheckReturnValue
/* 243:    */   public static HashCode fromString(String string)
/* 244:    */   {
/* 245:355 */     Preconditions.checkArgument(string.length() >= 2, "input string (%s) must have at least 2 characters", new Object[] { string });
/* 246:    */     
/* 247:357 */     Preconditions.checkArgument(string.length() % 2 == 0, "input string (%s) must have an even number of characters", new Object[] { string });
/* 248:    */     
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:362 */     byte[] bytes = new byte[string.length() / 2];
/* 253:363 */     for (int i = 0; i < string.length(); i += 2)
/* 254:    */     {
/* 255:364 */       int ch1 = decode(string.charAt(i)) << 4;
/* 256:365 */       int ch2 = decode(string.charAt(i + 1));
/* 257:366 */       bytes[(i / 2)] = ((byte)(ch1 + ch2));
/* 258:    */     }
/* 259:368 */     return fromBytesNoCopy(bytes);
/* 260:    */   }
/* 261:    */   
/* 262:    */   private static int decode(char ch)
/* 263:    */   {
/* 264:372 */     if ((ch >= '0') && (ch <= '9')) {
/* 265:373 */       return ch - '0';
/* 266:    */     }
/* 267:375 */     if ((ch >= 'a') && (ch <= 'f')) {
/* 268:376 */       return ch - 'a' + 10;
/* 269:    */     }
/* 270:378 */     throw new IllegalArgumentException("Illegal hexadecimal character: " + ch);
/* 271:    */   }
/* 272:    */   
/* 273:    */   public final boolean equals(@Nullable Object object)
/* 274:    */   {
/* 275:390 */     if ((object instanceof HashCode))
/* 276:    */     {
/* 277:391 */       HashCode that = (HashCode)object;
/* 278:392 */       return (bits() == that.bits()) && (equalsSameBits(that));
/* 279:    */     }
/* 280:394 */     return false;
/* 281:    */   }
/* 282:    */   
/* 283:    */   public final int hashCode()
/* 284:    */   {
/* 285:406 */     if (bits() >= 32) {
/* 286:407 */       return asInt();
/* 287:    */     }
/* 288:410 */     byte[] bytes = getBytesInternal();
/* 289:411 */     int val = bytes[0] & 0xFF;
/* 290:412 */     for (int i = 1; i < bytes.length; i++) {
/* 291:413 */       val |= (bytes[i] & 0xFF) << i * 8;
/* 292:    */     }
/* 293:415 */     return val;
/* 294:    */   }
/* 295:    */   
/* 296:    */   public final String toString()
/* 297:    */   {
/* 298:431 */     byte[] bytes = getBytesInternal();
/* 299:432 */     StringBuilder sb = new StringBuilder(2 * bytes.length);
/* 300:433 */     for (byte b : bytes) {
/* 301:434 */       sb.append(hexDigits[(b >> 4 & 0xF)]).append(hexDigits[(b & 0xF)]);
/* 302:    */     }
/* 303:436 */     return sb.toString();
/* 304:    */   }
/* 305:    */   
/* 306:439 */   private static final char[] hexDigits = "0123456789abcdef".toCharArray();
/* 307:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.HashCode
 * JD-Core Version:    0.7.0.1
 */