/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.primitives.UnsignedBytes;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import java.nio.ByteOrder;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ final class Murmur3_128HashFunction
/*  10:    */   extends AbstractStreamingHashFunction
/*  11:    */   implements Serializable
/*  12:    */ {
/*  13:    */   private final int seed;
/*  14:    */   private static final long serialVersionUID = 0L;
/*  15:    */   
/*  16:    */   Murmur3_128HashFunction(int seed)
/*  17:    */   {
/*  18: 48 */     this.seed = seed;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public int bits()
/*  22:    */   {
/*  23: 53 */     return 128;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public Hasher newHasher()
/*  27:    */   {
/*  28: 58 */     return new Murmur3_128Hasher(this.seed);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public String toString()
/*  32:    */   {
/*  33: 63 */     return "Hashing.murmur3_128(" + this.seed + ")";
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean equals(@Nullable Object object)
/*  37:    */   {
/*  38: 68 */     if ((object instanceof Murmur3_128HashFunction))
/*  39:    */     {
/*  40: 69 */       Murmur3_128HashFunction other = (Murmur3_128HashFunction)object;
/*  41: 70 */       return this.seed == other.seed;
/*  42:    */     }
/*  43: 72 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public int hashCode()
/*  47:    */   {
/*  48: 77 */     return getClass().hashCode() ^ this.seed;
/*  49:    */   }
/*  50:    */   
/*  51:    */   private static final class Murmur3_128Hasher
/*  52:    */     extends AbstractStreamingHashFunction.AbstractStreamingHasher
/*  53:    */   {
/*  54:    */     private static final int CHUNK_SIZE = 16;
/*  55:    */     private static final long C1 = -8663945395140668459L;
/*  56:    */     private static final long C2 = 5545529020109919103L;
/*  57:    */     private long h1;
/*  58:    */     private long h2;
/*  59:    */     private int length;
/*  60:    */     
/*  61:    */     Murmur3_128Hasher(int seed)
/*  62:    */     {
/*  63: 89 */       super();
/*  64: 90 */       this.h1 = seed;
/*  65: 91 */       this.h2 = seed;
/*  66: 92 */       this.length = 0;
/*  67:    */     }
/*  68:    */     
/*  69:    */     protected void process(ByteBuffer bb)
/*  70:    */     {
/*  71: 97 */       long k1 = bb.getLong();
/*  72: 98 */       long k2 = bb.getLong();
/*  73: 99 */       bmix64(k1, k2);
/*  74:100 */       this.length += 16;
/*  75:    */     }
/*  76:    */     
/*  77:    */     private void bmix64(long k1, long k2)
/*  78:    */     {
/*  79:104 */       this.h1 ^= mixK1(k1);
/*  80:    */       
/*  81:106 */       this.h1 = Long.rotateLeft(this.h1, 27);
/*  82:107 */       this.h1 += this.h2;
/*  83:108 */       this.h1 = (this.h1 * 5L + 1390208809L);
/*  84:    */       
/*  85:110 */       this.h2 ^= mixK2(k2);
/*  86:    */       
/*  87:112 */       this.h2 = Long.rotateLeft(this.h2, 31);
/*  88:113 */       this.h2 += this.h1;
/*  89:114 */       this.h2 = (this.h2 * 5L + 944331445L);
/*  90:    */     }
/*  91:    */     
/*  92:    */     protected void processRemaining(ByteBuffer bb)
/*  93:    */     {
/*  94:119 */       long k1 = 0L;
/*  95:120 */       long k2 = 0L;
/*  96:121 */       this.length += bb.remaining();
/*  97:122 */       switch (bb.remaining())
/*  98:    */       {
/*  99:    */       case 15: 
/* 100:124 */         k2 ^= UnsignedBytes.toInt(bb.get(14)) << 48;
/* 101:    */       case 14: 
/* 102:126 */         k2 ^= UnsignedBytes.toInt(bb.get(13)) << 40;
/* 103:    */       case 13: 
/* 104:128 */         k2 ^= UnsignedBytes.toInt(bb.get(12)) << 32;
/* 105:    */       case 12: 
/* 106:130 */         k2 ^= UnsignedBytes.toInt(bb.get(11)) << 24;
/* 107:    */       case 11: 
/* 108:132 */         k2 ^= UnsignedBytes.toInt(bb.get(10)) << 16;
/* 109:    */       case 10: 
/* 110:134 */         k2 ^= UnsignedBytes.toInt(bb.get(9)) << 8;
/* 111:    */       case 9: 
/* 112:136 */         k2 ^= UnsignedBytes.toInt(bb.get(8));
/* 113:    */       case 8: 
/* 114:138 */         k1 ^= bb.getLong();
/* 115:139 */         break;
/* 116:    */       case 7: 
/* 117:141 */         k1 ^= UnsignedBytes.toInt(bb.get(6)) << 48;
/* 118:    */       case 6: 
/* 119:143 */         k1 ^= UnsignedBytes.toInt(bb.get(5)) << 40;
/* 120:    */       case 5: 
/* 121:145 */         k1 ^= UnsignedBytes.toInt(bb.get(4)) << 32;
/* 122:    */       case 4: 
/* 123:147 */         k1 ^= UnsignedBytes.toInt(bb.get(3)) << 24;
/* 124:    */       case 3: 
/* 125:149 */         k1 ^= UnsignedBytes.toInt(bb.get(2)) << 16;
/* 126:    */       case 2: 
/* 127:151 */         k1 ^= UnsignedBytes.toInt(bb.get(1)) << 8;
/* 128:    */       case 1: 
/* 129:153 */         k1 ^= UnsignedBytes.toInt(bb.get(0));
/* 130:154 */         break;
/* 131:    */       default: 
/* 132:156 */         throw new AssertionError("Should never get here.");
/* 133:    */       }
/* 134:158 */       this.h1 ^= mixK1(k1);
/* 135:159 */       this.h2 ^= mixK2(k2);
/* 136:    */     }
/* 137:    */     
/* 138:    */     public HashCode makeHash()
/* 139:    */     {
/* 140:164 */       this.h1 ^= this.length;
/* 141:165 */       this.h2 ^= this.length;
/* 142:    */       
/* 143:167 */       this.h1 += this.h2;
/* 144:168 */       this.h2 += this.h1;
/* 145:    */       
/* 146:170 */       this.h1 = fmix64(this.h1);
/* 147:171 */       this.h2 = fmix64(this.h2);
/* 148:    */       
/* 149:173 */       this.h1 += this.h2;
/* 150:174 */       this.h2 += this.h1;
/* 151:    */       
/* 152:176 */       return HashCode.fromBytesNoCopy(ByteBuffer.wrap(new byte[16]).order(ByteOrder.LITTLE_ENDIAN).putLong(this.h1).putLong(this.h2).array());
/* 153:    */     }
/* 154:    */     
/* 155:    */     private static long fmix64(long k)
/* 156:    */     {
/* 157:185 */       k ^= k >>> 33;
/* 158:186 */       k *= -49064778989728563L;
/* 159:187 */       k ^= k >>> 33;
/* 160:188 */       k *= -4265267296055464877L;
/* 161:189 */       k ^= k >>> 33;
/* 162:190 */       return k;
/* 163:    */     }
/* 164:    */     
/* 165:    */     private static long mixK1(long k1)
/* 166:    */     {
/* 167:194 */       k1 *= -8663945395140668459L;
/* 168:195 */       k1 = Long.rotateLeft(k1, 31);
/* 169:196 */       k1 *= 5545529020109919103L;
/* 170:197 */       return k1;
/* 171:    */     }
/* 172:    */     
/* 173:    */     private static long mixK2(long k2)
/* 174:    */     {
/* 175:201 */       k2 *= 5545529020109919103L;
/* 176:202 */       k2 = Long.rotateLeft(k2, 33);
/* 177:203 */       k2 *= -8663945395140668459L;
/* 178:204 */       return k2;
/* 179:    */     }
/* 180:    */   }
/* 181:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.Murmur3_128HashFunction
 * JD-Core Version:    0.7.0.1
 */