/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.nio.ByteBuffer;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ final class SipHashFunction
/*   9:    */   extends AbstractStreamingHashFunction
/*  10:    */   implements Serializable
/*  11:    */ {
/*  12:    */   private final int c;
/*  13:    */   private final int d;
/*  14:    */   private final long k0;
/*  15:    */   private final long k1;
/*  16:    */   private static final long serialVersionUID = 0L;
/*  17:    */   
/*  18:    */   SipHashFunction(int c, int d, long k0, long k1)
/*  19:    */   {
/*  20: 53 */     Preconditions.checkArgument(c > 0, "The number of SipRound iterations (c=%s) during Compression must be positive.", new Object[] { Integer.valueOf(c) });
/*  21:    */     
/*  22: 55 */     Preconditions.checkArgument(d > 0, "The number of SipRound iterations (d=%s) during Finalization must be positive.", new Object[] { Integer.valueOf(d) });
/*  23:    */     
/*  24: 57 */     this.c = c;
/*  25: 58 */     this.d = d;
/*  26: 59 */     this.k0 = k0;
/*  27: 60 */     this.k1 = k1;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public int bits()
/*  31:    */   {
/*  32: 65 */     return 64;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public Hasher newHasher()
/*  36:    */   {
/*  37: 70 */     return new SipHasher(this.c, this.d, this.k0, this.k1);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public String toString()
/*  41:    */   {
/*  42: 77 */     return "Hashing.sipHash" + this.c + "" + this.d + "(" + this.k0 + ", " + this.k1 + ")";
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean equals(@Nullable Object object)
/*  46:    */   {
/*  47: 82 */     if ((object instanceof SipHashFunction))
/*  48:    */     {
/*  49: 83 */       SipHashFunction other = (SipHashFunction)object;
/*  50: 84 */       return (this.c == other.c) && (this.d == other.d) && (this.k0 == other.k0) && (this.k1 == other.k1);
/*  51:    */     }
/*  52: 89 */     return false;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public int hashCode()
/*  56:    */   {
/*  57: 94 */     return (int)(getClass().hashCode() ^ this.c ^ this.d ^ this.k0 ^ this.k1);
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static final class SipHasher
/*  61:    */     extends AbstractStreamingHashFunction.AbstractStreamingHasher
/*  62:    */   {
/*  63:    */     private static final int CHUNK_SIZE = 8;
/*  64:    */     private final int c;
/*  65:    */     private final int d;
/*  66:109 */     private long v0 = 8317987319222330741L;
/*  67:110 */     private long v1 = 7237128888997146477L;
/*  68:111 */     private long v2 = 7816392313619706465L;
/*  69:112 */     private long v3 = 8387220255154660723L;
/*  70:115 */     private long b = 0L;
/*  71:119 */     private long finalM = 0L;
/*  72:    */     
/*  73:    */     SipHasher(int c, int d, long k0, long k1)
/*  74:    */     {
/*  75:122 */       super();
/*  76:123 */       this.c = c;
/*  77:124 */       this.d = d;
/*  78:125 */       this.v0 ^= k0;
/*  79:126 */       this.v1 ^= k1;
/*  80:127 */       this.v2 ^= k0;
/*  81:128 */       this.v3 ^= k1;
/*  82:    */     }
/*  83:    */     
/*  84:    */     protected void process(ByteBuffer buffer)
/*  85:    */     {
/*  86:133 */       this.b += 8L;
/*  87:134 */       processM(buffer.getLong());
/*  88:    */     }
/*  89:    */     
/*  90:    */     protected void processRemaining(ByteBuffer buffer)
/*  91:    */     {
/*  92:139 */       this.b += buffer.remaining();
/*  93:140 */       for (int i = 0; buffer.hasRemaining(); i += 8) {
/*  94:141 */         this.finalM ^= (buffer.get() & 0xFF) << i;
/*  95:    */       }
/*  96:    */     }
/*  97:    */     
/*  98:    */     public HashCode makeHash()
/*  99:    */     {
/* 100:148 */       this.finalM ^= this.b << 56;
/* 101:149 */       processM(this.finalM);
/* 102:    */       
/* 103:    */ 
/* 104:152 */       this.v2 ^= 0xFF;
/* 105:153 */       sipRound(this.d);
/* 106:154 */       return HashCode.fromLong(this.v0 ^ this.v1 ^ this.v2 ^ this.v3);
/* 107:    */     }
/* 108:    */     
/* 109:    */     private void processM(long m)
/* 110:    */     {
/* 111:158 */       this.v3 ^= m;
/* 112:159 */       sipRound(this.c);
/* 113:160 */       this.v0 ^= m;
/* 114:    */     }
/* 115:    */     
/* 116:    */     private void sipRound(int iterations)
/* 117:    */     {
/* 118:164 */       for (int i = 0; i < iterations; i++)
/* 119:    */       {
/* 120:165 */         this.v0 += this.v1;
/* 121:166 */         this.v2 += this.v3;
/* 122:167 */         this.v1 = Long.rotateLeft(this.v1, 13);
/* 123:168 */         this.v3 = Long.rotateLeft(this.v3, 16);
/* 124:169 */         this.v1 ^= this.v0;
/* 125:170 */         this.v3 ^= this.v2;
/* 126:171 */         this.v0 = Long.rotateLeft(this.v0, 32);
/* 127:172 */         this.v2 += this.v1;
/* 128:173 */         this.v0 += this.v3;
/* 129:174 */         this.v1 = Long.rotateLeft(this.v1, 17);
/* 130:175 */         this.v3 = Long.rotateLeft(this.v3, 21);
/* 131:176 */         this.v1 ^= this.v2;
/* 132:177 */         this.v3 ^= this.v0;
/* 133:178 */         this.v2 = Long.rotateLeft(this.v2, 32);
/* 134:    */       }
/* 135:    */     }
/* 136:    */   }
/* 137:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.SipHashFunction
 * JD-Core Version:    0.7.0.1
 */