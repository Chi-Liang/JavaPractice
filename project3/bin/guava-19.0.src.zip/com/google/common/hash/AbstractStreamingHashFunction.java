/*   1:    */ package com.google.common.hash;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.nio.ByteBuffer;
/*   5:    */ import java.nio.ByteOrder;
/*   6:    */ import java.nio.charset.Charset;
/*   7:    */ 
/*   8:    */ abstract class AbstractStreamingHashFunction
/*   9:    */   implements HashFunction
/*  10:    */ {
/*  11:    */   public <T> HashCode hashObject(T instance, Funnel<? super T> funnel)
/*  12:    */   {
/*  13: 38 */     return newHasher().putObject(instance, funnel).hash();
/*  14:    */   }
/*  15:    */   
/*  16:    */   public HashCode hashUnencodedChars(CharSequence input)
/*  17:    */   {
/*  18: 43 */     return newHasher().putUnencodedChars(input).hash();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public HashCode hashString(CharSequence input, Charset charset)
/*  22:    */   {
/*  23: 48 */     return newHasher().putString(input, charset).hash();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public HashCode hashInt(int input)
/*  27:    */   {
/*  28: 53 */     return newHasher().putInt(input).hash();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public HashCode hashLong(long input)
/*  32:    */   {
/*  33: 58 */     return newHasher().putLong(input).hash();
/*  34:    */   }
/*  35:    */   
/*  36:    */   public HashCode hashBytes(byte[] input)
/*  37:    */   {
/*  38: 63 */     return newHasher().putBytes(input).hash();
/*  39:    */   }
/*  40:    */   
/*  41:    */   public HashCode hashBytes(byte[] input, int off, int len)
/*  42:    */   {
/*  43: 68 */     return newHasher().putBytes(input, off, len).hash();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public Hasher newHasher(int expectedInputSize)
/*  47:    */   {
/*  48: 73 */     Preconditions.checkArgument(expectedInputSize >= 0);
/*  49: 74 */     return newHasher();
/*  50:    */   }
/*  51:    */   
/*  52:    */   protected static abstract class AbstractStreamingHasher
/*  53:    */     extends AbstractHasher
/*  54:    */   {
/*  55:    */     private final ByteBuffer buffer;
/*  56:    */     private final int bufferSize;
/*  57:    */     private final int chunkSize;
/*  58:    */     
/*  59:    */     protected AbstractStreamingHasher(int chunkSize)
/*  60:    */     {
/*  61:103 */       this(chunkSize, chunkSize);
/*  62:    */     }
/*  63:    */     
/*  64:    */     protected AbstractStreamingHasher(int chunkSize, int bufferSize)
/*  65:    */     {
/*  66:117 */       Preconditions.checkArgument(bufferSize % chunkSize == 0);
/*  67:    */       
/*  68:    */ 
/*  69:    */ 
/*  70:121 */       this.buffer = ByteBuffer.allocate(bufferSize + 7).order(ByteOrder.LITTLE_ENDIAN);
/*  71:122 */       this.bufferSize = bufferSize;
/*  72:123 */       this.chunkSize = chunkSize;
/*  73:    */     }
/*  74:    */     
/*  75:    */     protected abstract void process(ByteBuffer paramByteBuffer);
/*  76:    */     
/*  77:    */     protected void processRemaining(ByteBuffer bb)
/*  78:    */     {
/*  79:140 */       bb.position(bb.limit());
/*  80:141 */       bb.limit(this.chunkSize + 7);
/*  81:142 */       while (bb.position() < this.chunkSize) {
/*  82:143 */         bb.putLong(0L);
/*  83:    */       }
/*  84:145 */       bb.limit(this.chunkSize);
/*  85:146 */       bb.flip();
/*  86:147 */       process(bb);
/*  87:    */     }
/*  88:    */     
/*  89:    */     public final Hasher putBytes(byte[] bytes)
/*  90:    */     {
/*  91:152 */       return putBytes(bytes, 0, bytes.length);
/*  92:    */     }
/*  93:    */     
/*  94:    */     public final Hasher putBytes(byte[] bytes, int off, int len)
/*  95:    */     {
/*  96:157 */       return putBytes(ByteBuffer.wrap(bytes, off, len).order(ByteOrder.LITTLE_ENDIAN));
/*  97:    */     }
/*  98:    */     
/*  99:    */     private Hasher putBytes(ByteBuffer readBuffer)
/* 100:    */     {
/* 101:162 */       if (readBuffer.remaining() <= this.buffer.remaining())
/* 102:    */       {
/* 103:163 */         this.buffer.put(readBuffer);
/* 104:164 */         munchIfFull();
/* 105:165 */         return this;
/* 106:    */       }
/* 107:169 */       int bytesToCopy = this.bufferSize - this.buffer.position();
/* 108:170 */       for (int i = 0; i < bytesToCopy; i++) {
/* 109:171 */         this.buffer.put(readBuffer.get());
/* 110:    */       }
/* 111:173 */       munch();
/* 112:176 */       while (readBuffer.remaining() >= this.chunkSize) {
/* 113:177 */         process(readBuffer);
/* 114:    */       }
/* 115:181 */       this.buffer.put(readBuffer);
/* 116:182 */       return this;
/* 117:    */     }
/* 118:    */     
/* 119:    */     public final Hasher putUnencodedChars(CharSequence charSequence)
/* 120:    */     {
/* 121:187 */       for (int i = 0; i < charSequence.length(); i++) {
/* 122:188 */         putChar(charSequence.charAt(i));
/* 123:    */       }
/* 124:190 */       return this;
/* 125:    */     }
/* 126:    */     
/* 127:    */     public final Hasher putByte(byte b)
/* 128:    */     {
/* 129:205 */       this.buffer.put(b);
/* 130:206 */       munchIfFull();
/* 131:207 */       return this;
/* 132:    */     }
/* 133:    */     
/* 134:    */     public final Hasher putShort(short s)
/* 135:    */     {
/* 136:212 */       this.buffer.putShort(s);
/* 137:213 */       munchIfFull();
/* 138:214 */       return this;
/* 139:    */     }
/* 140:    */     
/* 141:    */     public final Hasher putChar(char c)
/* 142:    */     {
/* 143:219 */       this.buffer.putChar(c);
/* 144:220 */       munchIfFull();
/* 145:221 */       return this;
/* 146:    */     }
/* 147:    */     
/* 148:    */     public final Hasher putInt(int i)
/* 149:    */     {
/* 150:226 */       this.buffer.putInt(i);
/* 151:227 */       munchIfFull();
/* 152:228 */       return this;
/* 153:    */     }
/* 154:    */     
/* 155:    */     public final Hasher putLong(long l)
/* 156:    */     {
/* 157:233 */       this.buffer.putLong(l);
/* 158:234 */       munchIfFull();
/* 159:235 */       return this;
/* 160:    */     }
/* 161:    */     
/* 162:    */     public final <T> Hasher putObject(T instance, Funnel<? super T> funnel)
/* 163:    */     {
/* 164:240 */       funnel.funnel(instance, this);
/* 165:241 */       return this;
/* 166:    */     }
/* 167:    */     
/* 168:    */     public final HashCode hash()
/* 169:    */     {
/* 170:246 */       munch();
/* 171:247 */       this.buffer.flip();
/* 172:248 */       if (this.buffer.remaining() > 0) {
/* 173:249 */         processRemaining(this.buffer);
/* 174:    */       }
/* 175:251 */       return makeHash();
/* 176:    */     }
/* 177:    */     
/* 178:    */     abstract HashCode makeHash();
/* 179:    */     
/* 180:    */     private void munchIfFull()
/* 181:    */     {
/* 182:258 */       if (this.buffer.remaining() < 8) {
/* 183:260 */         munch();
/* 184:    */       }
/* 185:    */     }
/* 186:    */     
/* 187:    */     private void munch()
/* 188:    */     {
/* 189:265 */       this.buffer.flip();
/* 190:266 */       while (this.buffer.remaining() >= this.chunkSize) {
/* 191:269 */         process(this.buffer);
/* 192:    */       }
/* 193:271 */       this.buffer.compact();
/* 194:    */     }
/* 195:    */   }
/* 196:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.AbstractStreamingHashFunction
 * JD-Core Version:    0.7.0.1
 */