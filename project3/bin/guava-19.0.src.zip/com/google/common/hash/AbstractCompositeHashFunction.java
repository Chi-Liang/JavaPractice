/*  1:   */ package com.google.common.hash;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import java.nio.charset.Charset;
/*  5:   */ 
/*  6:   */ abstract class AbstractCompositeHashFunction
/*  7:   */   extends AbstractStreamingHashFunction
/*  8:   */ {
/*  9:   */   final HashFunction[] functions;
/* 10:   */   private static final long serialVersionUID = 0L;
/* 11:   */   
/* 12:   */   AbstractCompositeHashFunction(HashFunction... functions)
/* 13:   */   {
/* 14:34 */     for (HashFunction function : functions) {
/* 15:35 */       Preconditions.checkNotNull(function);
/* 16:   */     }
/* 17:37 */     this.functions = functions;
/* 18:   */   }
/* 19:   */   
/* 20:   */   abstract HashCode makeHash(Hasher[] paramArrayOfHasher);
/* 21:   */   
/* 22:   */   public Hasher newHasher()
/* 23:   */   {
/* 24:50 */     final Hasher[] hashers = new Hasher[this.functions.length];
/* 25:51 */     for (int i = 0; i < hashers.length; i++) {
/* 26:52 */       hashers[i] = this.functions[i].newHasher();
/* 27:   */     }
/* 28:54 */     new Hasher()
/* 29:   */     {
/* 30:   */       public Hasher putByte(byte b)
/* 31:   */       {
/* 32:57 */         for (Hasher hasher : hashers) {
/* 33:58 */           hasher.putByte(b);
/* 34:   */         }
/* 35:60 */         return this;
/* 36:   */       }
/* 37:   */       
/* 38:   */       public Hasher putBytes(byte[] bytes)
/* 39:   */       {
/* 40:65 */         for (Hasher hasher : hashers) {
/* 41:66 */           hasher.putBytes(bytes);
/* 42:   */         }
/* 43:68 */         return this;
/* 44:   */       }
/* 45:   */       
/* 46:   */       public Hasher putBytes(byte[] bytes, int off, int len)
/* 47:   */       {
/* 48:73 */         for (Hasher hasher : hashers) {
/* 49:74 */           hasher.putBytes(bytes, off, len);
/* 50:   */         }
/* 51:76 */         return this;
/* 52:   */       }
/* 53:   */       
/* 54:   */       public Hasher putShort(short s)
/* 55:   */       {
/* 56:81 */         for (Hasher hasher : hashers) {
/* 57:82 */           hasher.putShort(s);
/* 58:   */         }
/* 59:84 */         return this;
/* 60:   */       }
/* 61:   */       
/* 62:   */       public Hasher putInt(int i)
/* 63:   */       {
/* 64:89 */         for (Hasher hasher : hashers) {
/* 65:90 */           hasher.putInt(i);
/* 66:   */         }
/* 67:92 */         return this;
/* 68:   */       }
/* 69:   */       
/* 70:   */       public Hasher putLong(long l)
/* 71:   */       {
/* 72:97 */         for (Hasher hasher : hashers) {
/* 73:98 */           hasher.putLong(l);
/* 74:   */         }
/* 75::0 */         return this;
/* 76:   */       }
/* 77:   */       
/* 78:   */       public Hasher putFloat(float f)
/* 79:   */       {
/* 80::5 */         for (Hasher hasher : hashers) {
/* 81::6 */           hasher.putFloat(f);
/* 82:   */         }
/* 83::8 */         return this;
/* 84:   */       }
/* 85:   */       
/* 86:   */       public Hasher putDouble(double d)
/* 87:   */       {
/* 88:;3 */         for (Hasher hasher : hashers) {
/* 89:;4 */           hasher.putDouble(d);
/* 90:   */         }
/* 91:;6 */         return this;
/* 92:   */       }
/* 93:   */       
/* 94:   */       public Hasher putBoolean(boolean b)
/* 95:   */       {
/* 96:<1 */         for (Hasher hasher : hashers) {
/* 97:<2 */           hasher.putBoolean(b);
/* 98:   */         }
/* 99:<4 */         return this;
/* :0:   */       }
/* :1:   */       
/* :2:   */       public Hasher putChar(char c)
/* :3:   */       {
/* :4:<9 */         for (Hasher hasher : hashers) {
/* :5:=0 */           hasher.putChar(c);
/* :6:   */         }
/* :7:=2 */         return this;
/* :8:   */       }
/* :9:   */       
/* ;0:   */       public Hasher putUnencodedChars(CharSequence chars)
/* ;1:   */       {
/* ;2:=7 */         for (Hasher hasher : hashers) {
/* ;3:=8 */           hasher.putUnencodedChars(chars);
/* ;4:   */         }
/* ;5:>0 */         return this;
/* ;6:   */       }
/* ;7:   */       
/* ;8:   */       public Hasher putString(CharSequence chars, Charset charset)
/* ;9:   */       {
/* <0:>5 */         for (Hasher hasher : hashers) {
/* <1:>6 */           hasher.putString(chars, charset);
/* <2:   */         }
/* <3:>8 */         return this;
/* <4:   */       }
/* <5:   */       
/* <6:   */       public <T> Hasher putObject(T instance, Funnel<? super T> funnel)
/* <7:   */       {
/* <8:?3 */         for (Hasher hasher : hashers) {
/* <9:?4 */           hasher.putObject(instance, funnel);
/* =0:   */         }
/* =1:?6 */         return this;
/* =2:   */       }
/* =3:   */       
/* =4:   */       public HashCode hash()
/* =5:   */       {
/* =6:@1 */         return AbstractCompositeHashFunction.this.makeHash(hashers);
/* =7:   */       }
/* =8:   */     };
/* =9:   */   }
/* >0:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.hash.AbstractCompositeHashFunction
 * JD-Core Version:    0.7.0.1
 */