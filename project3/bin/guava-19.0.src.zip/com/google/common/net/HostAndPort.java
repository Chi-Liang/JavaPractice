/*   1:    */ package com.google.common.net;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Strings;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ import javax.annotation.concurrent.Immutable;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ @Immutable
/*  14:    */ @GwtCompatible
/*  15:    */ public final class HostAndPort
/*  16:    */   implements Serializable
/*  17:    */ {
/*  18:    */   private static final int NO_PORT = -1;
/*  19:    */   private final String host;
/*  20:    */   private final int port;
/*  21:    */   private final boolean hasBracketlessColons;
/*  22:    */   private static final long serialVersionUID = 0L;
/*  23:    */   
/*  24:    */   private HostAndPort(String host, int port, boolean hasBracketlessColons)
/*  25:    */   {
/*  26: 81 */     this.host = host;
/*  27: 82 */     this.port = port;
/*  28: 83 */     this.hasBracketlessColons = hasBracketlessColons;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public String getHostText()
/*  32:    */   {
/*  33: 94 */     return this.host;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean hasPort()
/*  37:    */   {
/*  38: 99 */     return this.port >= 0;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public int getPort()
/*  42:    */   {
/*  43:110 */     Preconditions.checkState(hasPort());
/*  44:111 */     return this.port;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int getPortOrDefault(int defaultPort)
/*  48:    */   {
/*  49:118 */     return hasPort() ? this.port : defaultPort;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static HostAndPort fromParts(String host, int port)
/*  53:    */   {
/*  54:134 */     Preconditions.checkArgument(isValidPort(port), "Port out of range: %s", new Object[] { Integer.valueOf(port) });
/*  55:135 */     HostAndPort parsedHost = fromString(host);
/*  56:136 */     Preconditions.checkArgument(!parsedHost.hasPort(), "Host has a port: %s", new Object[] { host });
/*  57:137 */     return new HostAndPort(parsedHost.host, port, parsedHost.hasBracketlessColons);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static HostAndPort fromHost(String host)
/*  61:    */   {
/*  62:152 */     HostAndPort parsedHost = fromString(host);
/*  63:153 */     Preconditions.checkArgument(!parsedHost.hasPort(), "Host has a port: %s", new Object[] { host });
/*  64:154 */     return parsedHost;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static HostAndPort fromString(String hostPortString)
/*  68:    */   {
/*  69:168 */     Preconditions.checkNotNull(hostPortString);
/*  70:    */     
/*  71:170 */     String portString = null;
/*  72:171 */     boolean hasBracketlessColons = false;
/*  73:    */     String host;
/*  74:173 */     if (hostPortString.startsWith("["))
/*  75:    */     {
/*  76:174 */       String[] hostAndPort = getHostAndPortFromBracketedHost(hostPortString);
/*  77:175 */       String host = hostAndPort[0];
/*  78:176 */       portString = hostAndPort[1];
/*  79:    */     }
/*  80:    */     else
/*  81:    */     {
/*  82:178 */       int colonPos = hostPortString.indexOf(':');
/*  83:179 */       if ((colonPos >= 0) && (hostPortString.indexOf(':', colonPos + 1) == -1))
/*  84:    */       {
/*  85:181 */         String host = hostPortString.substring(0, colonPos);
/*  86:182 */         portString = hostPortString.substring(colonPos + 1);
/*  87:    */       }
/*  88:    */       else
/*  89:    */       {
/*  90:185 */         host = hostPortString;
/*  91:186 */         hasBracketlessColons = colonPos >= 0;
/*  92:    */       }
/*  93:    */     }
/*  94:190 */     int port = -1;
/*  95:191 */     if (!Strings.isNullOrEmpty(portString))
/*  96:    */     {
/*  97:194 */       Preconditions.checkArgument(!portString.startsWith("+"), "Unparseable port number: %s", new Object[] { hostPortString });
/*  98:    */       try
/*  99:    */       {
/* 100:196 */         port = Integer.parseInt(portString);
/* 101:    */       }
/* 102:    */       catch (NumberFormatException e)
/* 103:    */       {
/* 104:198 */         throw new IllegalArgumentException("Unparseable port number: " + hostPortString);
/* 105:    */       }
/* 106:200 */       Preconditions.checkArgument(isValidPort(port), "Port number out of range: %s", new Object[] { hostPortString });
/* 107:    */     }
/* 108:203 */     return new HostAndPort(host, port, hasBracketlessColons);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static String[] getHostAndPortFromBracketedHost(String hostPortString)
/* 112:    */   {
/* 113:214 */     int colonIndex = 0;
/* 114:215 */     int closeBracketIndex = 0;
/* 115:216 */     Preconditions.checkArgument(hostPortString.charAt(0) == '[', "Bracketed host-port string must start with a bracket: %s", new Object[] { hostPortString });
/* 116:    */     
/* 117:218 */     colonIndex = hostPortString.indexOf(':');
/* 118:219 */     closeBracketIndex = hostPortString.lastIndexOf(']');
/* 119:220 */     Preconditions.checkArgument((colonIndex > -1) && (closeBracketIndex > colonIndex), "Invalid bracketed host/port: %s", new Object[] { hostPortString });
/* 120:    */     
/* 121:    */ 
/* 122:223 */     String host = hostPortString.substring(1, closeBracketIndex);
/* 123:224 */     if (closeBracketIndex + 1 == hostPortString.length()) {
/* 124:225 */       return new String[] { host, "" };
/* 125:    */     }
/* 126:227 */     Preconditions.checkArgument(hostPortString.charAt(closeBracketIndex + 1) == ':', "Only a colon may follow a close bracket: %s", new Object[] { hostPortString });
/* 127:229 */     for (int i = closeBracketIndex + 2; i < hostPortString.length(); i++) {
/* 128:230 */       Preconditions.checkArgument(Character.isDigit(hostPortString.charAt(i)), "Port must be numeric: %s", new Object[] { hostPortString });
/* 129:    */     }
/* 130:233 */     return new String[] { host, hostPortString.substring(closeBracketIndex + 2) };
/* 131:    */   }
/* 132:    */   
/* 133:    */   public HostAndPort withDefaultPort(int defaultPort)
/* 134:    */   {
/* 135:248 */     Preconditions.checkArgument(isValidPort(defaultPort));
/* 136:249 */     if ((hasPort()) || (this.port == defaultPort)) {
/* 137:250 */       return this;
/* 138:    */     }
/* 139:252 */     return new HostAndPort(this.host, defaultPort, this.hasBracketlessColons);
/* 140:    */   }
/* 141:    */   
/* 142:    */   public HostAndPort requireBracketsForIPv6()
/* 143:    */   {
/* 144:271 */     Preconditions.checkArgument(!this.hasBracketlessColons, "Possible bracketless IPv6 literal: %s", new Object[] { this.host });
/* 145:272 */     return this;
/* 146:    */   }
/* 147:    */   
/* 148:    */   public boolean equals(@Nullable Object other)
/* 149:    */   {
/* 150:277 */     if (this == other) {
/* 151:278 */       return true;
/* 152:    */     }
/* 153:280 */     if ((other instanceof HostAndPort))
/* 154:    */     {
/* 155:281 */       HostAndPort that = (HostAndPort)other;
/* 156:282 */       return (Objects.equal(this.host, that.host)) && (this.port == that.port) && (this.hasBracketlessColons == that.hasBracketlessColons);
/* 157:    */     }
/* 158:286 */     return false;
/* 159:    */   }
/* 160:    */   
/* 161:    */   public int hashCode()
/* 162:    */   {
/* 163:291 */     return Objects.hashCode(new Object[] { this.host, Integer.valueOf(this.port), Boolean.valueOf(this.hasBracketlessColons) });
/* 164:    */   }
/* 165:    */   
/* 166:    */   public String toString()
/* 167:    */   {
/* 168:298 */     StringBuilder builder = new StringBuilder(this.host.length() + 8);
/* 169:299 */     if (this.host.indexOf(':') >= 0) {
/* 170:300 */       builder.append('[').append(this.host).append(']');
/* 171:    */     } else {
/* 172:302 */       builder.append(this.host);
/* 173:    */     }
/* 174:304 */     if (hasPort()) {
/* 175:305 */       builder.append(':').append(this.port);
/* 176:    */     }
/* 177:307 */     return builder.toString();
/* 178:    */   }
/* 179:    */   
/* 180:    */   private static boolean isValidPort(int port)
/* 181:    */   {
/* 182:312 */     return (port >= 0) && (port <= 65535);
/* 183:    */   }
/* 184:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.net.HostAndPort
 * JD-Core Version:    0.7.0.1
 */