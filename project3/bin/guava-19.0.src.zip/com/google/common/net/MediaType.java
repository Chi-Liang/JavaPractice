/*   1:    */ package com.google.common.net;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Ascii;
/*   6:    */ import com.google.common.base.CharMatcher;
/*   7:    */ import com.google.common.base.Charsets;
/*   8:    */ import com.google.common.base.Function;
/*   9:    */ import com.google.common.base.Joiner;
/*  10:    */ import com.google.common.base.Joiner.MapJoiner;
/*  11:    */ import com.google.common.base.MoreObjects;
/*  12:    */ import com.google.common.base.Objects;
/*  13:    */ import com.google.common.base.Optional;
/*  14:    */ import com.google.common.base.Preconditions;
/*  15:    */ import com.google.common.collect.ImmutableCollection;
/*  16:    */ import com.google.common.collect.ImmutableListMultimap;
/*  17:    */ import com.google.common.collect.ImmutableListMultimap.Builder;
/*  18:    */ import com.google.common.collect.ImmutableMultiset;
/*  19:    */ import com.google.common.collect.ImmutableSet;
/*  20:    */ import com.google.common.collect.Iterables;
/*  21:    */ import com.google.common.collect.Maps;
/*  22:    */ import com.google.common.collect.Multimap;
/*  23:    */ import com.google.common.collect.Multimaps;
/*  24:    */ import java.nio.charset.Charset;
/*  25:    */ import java.util.Collection;
/*  26:    */ import java.util.Map;
/*  27:    */ import java.util.Map.Entry;
/*  28:    */ import javax.annotation.Nullable;
/*  29:    */ import javax.annotation.concurrent.Immutable;
/*  30:    */ 
/*  31:    */ @Beta
/*  32:    */ @GwtCompatible
/*  33:    */ @Immutable
/*  34:    */ public final class MediaType
/*  35:    */ {
/*  36:    */   private static final String CHARSET_ATTRIBUTE = "charset";
/*  37: 85 */   private static final ImmutableListMultimap<String, String> UTF_8_CONSTANT_PARAMETERS = ImmutableListMultimap.of("charset", Ascii.toLowerCase(Charsets.UTF_8.name()));
/*  38: 89 */   private static final CharMatcher TOKEN_MATCHER = CharMatcher.ASCII.and(CharMatcher.JAVA_ISO_CONTROL.negate()).and(CharMatcher.isNot(' ')).and(CharMatcher.noneOf("()<>@,;:\\\"/[]?="));
/*  39: 92 */   private static final CharMatcher QUOTED_TEXT_MATCHER = CharMatcher.ASCII.and(CharMatcher.noneOf("\"\\\r"));
/*  40: 98 */   private static final CharMatcher LINEAR_WHITE_SPACE = CharMatcher.anyOf(" \t\r\n");
/*  41:    */   private static final String APPLICATION_TYPE = "application";
/*  42:    */   private static final String AUDIO_TYPE = "audio";
/*  43:    */   private static final String IMAGE_TYPE = "image";
/*  44:    */   private static final String TEXT_TYPE = "text";
/*  45:    */   private static final String VIDEO_TYPE = "video";
/*  46:    */   private static final String WILDCARD = "*";
/*  47:109 */   private static final Map<MediaType, MediaType> KNOWN_TYPES = Maps.newHashMap();
/*  48:    */   
/*  49:    */   private static MediaType createConstant(String type, String subtype)
/*  50:    */   {
/*  51:112 */     return addKnownType(new MediaType(type, subtype, ImmutableListMultimap.of()));
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static MediaType createConstantUtf8(String type, String subtype)
/*  55:    */   {
/*  56:116 */     return addKnownType(new MediaType(type, subtype, UTF_8_CONSTANT_PARAMETERS));
/*  57:    */   }
/*  58:    */   
/*  59:    */   private static MediaType addKnownType(MediaType mediaType)
/*  60:    */   {
/*  61:120 */     KNOWN_TYPES.put(mediaType, mediaType);
/*  62:121 */     return mediaType;
/*  63:    */   }
/*  64:    */   
/*  65:134 */   public static final MediaType ANY_TYPE = createConstant("*", "*");
/*  66:135 */   public static final MediaType ANY_TEXT_TYPE = createConstant("text", "*");
/*  67:136 */   public static final MediaType ANY_IMAGE_TYPE = createConstant("image", "*");
/*  68:137 */   public static final MediaType ANY_AUDIO_TYPE = createConstant("audio", "*");
/*  69:138 */   public static final MediaType ANY_VIDEO_TYPE = createConstant("video", "*");
/*  70:139 */   public static final MediaType ANY_APPLICATION_TYPE = createConstant("application", "*");
/*  71:142 */   public static final MediaType CACHE_MANIFEST_UTF_8 = createConstantUtf8("text", "cache-manifest");
/*  72:144 */   public static final MediaType CSS_UTF_8 = createConstantUtf8("text", "css");
/*  73:145 */   public static final MediaType CSV_UTF_8 = createConstantUtf8("text", "csv");
/*  74:146 */   public static final MediaType HTML_UTF_8 = createConstantUtf8("text", "html");
/*  75:147 */   public static final MediaType I_CALENDAR_UTF_8 = createConstantUtf8("text", "calendar");
/*  76:148 */   public static final MediaType PLAIN_TEXT_UTF_8 = createConstantUtf8("text", "plain");
/*  77:154 */   public static final MediaType TEXT_JAVASCRIPT_UTF_8 = createConstantUtf8("text", "javascript");
/*  78:161 */   public static final MediaType TSV_UTF_8 = createConstantUtf8("text", "tab-separated-values");
/*  79:162 */   public static final MediaType VCARD_UTF_8 = createConstantUtf8("text", "vcard");
/*  80:163 */   public static final MediaType WML_UTF_8 = createConstantUtf8("text", "vnd.wap.wml");
/*  81:169 */   public static final MediaType XML_UTF_8 = createConstantUtf8("text", "xml");
/*  82:172 */   public static final MediaType BMP = createConstant("image", "bmp");
/*  83:182 */   public static final MediaType CRW = createConstant("image", "x-canon-crw");
/*  84:183 */   public static final MediaType GIF = createConstant("image", "gif");
/*  85:184 */   public static final MediaType ICO = createConstant("image", "vnd.microsoft.icon");
/*  86:185 */   public static final MediaType JPEG = createConstant("image", "jpeg");
/*  87:186 */   public static final MediaType PNG = createConstant("image", "png");
/*  88:203 */   public static final MediaType PSD = createConstant("image", "vnd.adobe.photoshop");
/*  89:204 */   public static final MediaType SVG_UTF_8 = createConstantUtf8("image", "svg+xml");
/*  90:205 */   public static final MediaType TIFF = createConstant("image", "tiff");
/*  91:206 */   public static final MediaType WEBP = createConstant("image", "webp");
/*  92:209 */   public static final MediaType MP4_AUDIO = createConstant("audio", "mp4");
/*  93:210 */   public static final MediaType MPEG_AUDIO = createConstant("audio", "mpeg");
/*  94:211 */   public static final MediaType OGG_AUDIO = createConstant("audio", "ogg");
/*  95:212 */   public static final MediaType WEBM_AUDIO = createConstant("audio", "webm");
/*  96:215 */   public static final MediaType MP4_VIDEO = createConstant("video", "mp4");
/*  97:216 */   public static final MediaType MPEG_VIDEO = createConstant("video", "mpeg");
/*  98:217 */   public static final MediaType OGG_VIDEO = createConstant("video", "ogg");
/*  99:218 */   public static final MediaType QUICKTIME = createConstant("video", "quicktime");
/* 100:219 */   public static final MediaType WEBM_VIDEO = createConstant("video", "webm");
/* 101:220 */   public static final MediaType WMV = createConstant("video", "x-ms-wmv");
/* 102:228 */   public static final MediaType APPLICATION_XML_UTF_8 = createConstantUtf8("application", "xml");
/* 103:229 */   public static final MediaType ATOM_UTF_8 = createConstantUtf8("application", "atom+xml");
/* 104:230 */   public static final MediaType BZIP2 = createConstant("application", "x-bzip2");
/* 105:237 */   public static final MediaType DART_UTF_8 = createConstantUtf8("application", "dart");
/* 106:244 */   public static final MediaType APPLE_PASSBOOK = createConstant("application", "vnd.apple.pkpass");
/* 107:255 */   public static final MediaType EOT = createConstant("application", "vnd.ms-fontobject");
/* 108:265 */   public static final MediaType EPUB = createConstant("application", "epub+zip");
/* 109:266 */   public static final MediaType FORM_DATA = createConstant("application", "x-www-form-urlencoded");
/* 110:275 */   public static final MediaType KEY_ARCHIVE = createConstant("application", "pkcs12");
/* 111:287 */   public static final MediaType APPLICATION_BINARY = createConstant("application", "binary");
/* 112:288 */   public static final MediaType GZIP = createConstant("application", "x-gzip");
/* 113:294 */   public static final MediaType JAVASCRIPT_UTF_8 = createConstantUtf8("application", "javascript");
/* 114:296 */   public static final MediaType JSON_UTF_8 = createConstantUtf8("application", "json");
/* 115:303 */   public static final MediaType MANIFEST_JSON_UTF_8 = createConstantUtf8("application", "manifest+json");
/* 116:305 */   public static final MediaType KML = createConstant("application", "vnd.google-earth.kml+xml");
/* 117:306 */   public static final MediaType KMZ = createConstant("application", "vnd.google-earth.kmz");
/* 118:307 */   public static final MediaType MBOX = createConstant("application", "mbox");
/* 119:315 */   public static final MediaType APPLE_MOBILE_CONFIG = createConstant("application", "x-apple-aspen-config");
/* 120:317 */   public static final MediaType MICROSOFT_EXCEL = createConstant("application", "vnd.ms-excel");
/* 121:318 */   public static final MediaType MICROSOFT_POWERPOINT = createConstant("application", "vnd.ms-powerpoint");
/* 122:320 */   public static final MediaType MICROSOFT_WORD = createConstant("application", "msword");
/* 123:321 */   public static final MediaType OCTET_STREAM = createConstant("application", "octet-stream");
/* 124:322 */   public static final MediaType OGG_CONTAINER = createConstant("application", "ogg");
/* 125:323 */   public static final MediaType OOXML_DOCUMENT = createConstant("application", "vnd.openxmlformats-officedocument.wordprocessingml.document");
/* 126:325 */   public static final MediaType OOXML_PRESENTATION = createConstant("application", "vnd.openxmlformats-officedocument.presentationml.presentation");
/* 127:327 */   public static final MediaType OOXML_SHEET = createConstant("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet");
/* 128:329 */   public static final MediaType OPENDOCUMENT_GRAPHICS = createConstant("application", "vnd.oasis.opendocument.graphics");
/* 129:331 */   public static final MediaType OPENDOCUMENT_PRESENTATION = createConstant("application", "vnd.oasis.opendocument.presentation");
/* 130:333 */   public static final MediaType OPENDOCUMENT_SPREADSHEET = createConstant("application", "vnd.oasis.opendocument.spreadsheet");
/* 131:335 */   public static final MediaType OPENDOCUMENT_TEXT = createConstant("application", "vnd.oasis.opendocument.text");
/* 132:337 */   public static final MediaType PDF = createConstant("application", "pdf");
/* 133:338 */   public static final MediaType POSTSCRIPT = createConstant("application", "postscript");
/* 134:344 */   public static final MediaType PROTOBUF = createConstant("application", "protobuf");
/* 135:345 */   public static final MediaType RDF_XML_UTF_8 = createConstantUtf8("application", "rdf+xml");
/* 136:346 */   public static final MediaType RTF_UTF_8 = createConstantUtf8("application", "rtf");
/* 137:356 */   public static final MediaType SFNT = createConstant("application", "font-sfnt");
/* 138:357 */   public static final MediaType SHOCKWAVE_FLASH = createConstant("application", "x-shockwave-flash");
/* 139:359 */   public static final MediaType SKETCHUP = createConstant("application", "vnd.sketchup.skp");
/* 140:360 */   public static final MediaType TAR = createConstant("application", "x-tar");
/* 141:370 */   public static final MediaType WOFF = createConstant("application", "font-woff");
/* 142:371 */   public static final MediaType XHTML_UTF_8 = createConstantUtf8("application", "xhtml+xml");
/* 143:379 */   public static final MediaType XRD_UTF_8 = createConstantUtf8("application", "xrd+xml");
/* 144:380 */   public static final MediaType ZIP = createConstant("application", "zip");
/* 145:    */   private final String type;
/* 146:    */   private final String subtype;
/* 147:    */   private final ImmutableListMultimap<String, String> parameters;
/* 148:    */   private String toString;
/* 149:    */   private int hashCode;
/* 150:    */   
/* 151:    */   private MediaType(String type, String subtype, ImmutableListMultimap<String, String> parameters)
/* 152:    */   {
/* 153:392 */     this.type = type;
/* 154:393 */     this.subtype = subtype;
/* 155:394 */     this.parameters = parameters;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public String type()
/* 159:    */   {
/* 160:399 */     return this.type;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public String subtype()
/* 164:    */   {
/* 165:404 */     return this.subtype;
/* 166:    */   }
/* 167:    */   
/* 168:    */   public ImmutableListMultimap<String, String> parameters()
/* 169:    */   {
/* 170:409 */     return this.parameters;
/* 171:    */   }
/* 172:    */   
/* 173:    */   private Map<String, ImmutableMultiset<String>> parametersAsMap()
/* 174:    */   {
/* 175:413 */     Maps.transformValues(this.parameters.asMap(), new Function()
/* 176:    */     {
/* 177:    */       public ImmutableMultiset<String> apply(Collection<String> input)
/* 178:    */       {
/* 179:416 */         return ImmutableMultiset.copyOf(input);
/* 180:    */       }
/* 181:    */     });
/* 182:    */   }
/* 183:    */   
/* 184:    */   public Optional<Charset> charset()
/* 185:    */   {
/* 186:430 */     ImmutableSet<String> charsetValues = ImmutableSet.copyOf(this.parameters.get("charset"));
/* 187:431 */     switch (charsetValues.size())
/* 188:    */     {
/* 189:    */     case 0: 
/* 190:433 */       return Optional.absent();
/* 191:    */     case 1: 
/* 192:435 */       return Optional.of(Charset.forName((String)Iterables.getOnlyElement(charsetValues)));
/* 193:    */     }
/* 194:437 */     throw new IllegalStateException("Multiple charset values defined: " + charsetValues);
/* 195:    */   }
/* 196:    */   
/* 197:    */   public MediaType withoutParameters()
/* 198:    */   {
/* 199:446 */     return this.parameters.isEmpty() ? this : create(this.type, this.subtype);
/* 200:    */   }
/* 201:    */   
/* 202:    */   public MediaType withParameters(Multimap<String, String> parameters)
/* 203:    */   {
/* 204:455 */     return create(this.type, this.subtype, parameters);
/* 205:    */   }
/* 206:    */   
/* 207:    */   public MediaType withParameter(String attribute, String value)
/* 208:    */   {
/* 209:467 */     Preconditions.checkNotNull(attribute);
/* 210:468 */     Preconditions.checkNotNull(value);
/* 211:469 */     String normalizedAttribute = normalizeToken(attribute);
/* 212:470 */     ImmutableListMultimap.Builder<String, String> builder = ImmutableListMultimap.builder();
/* 213:471 */     for (Map.Entry<String, String> entry : this.parameters.entries())
/* 214:    */     {
/* 215:472 */       String key = (String)entry.getKey();
/* 216:473 */       if (!normalizedAttribute.equals(key)) {
/* 217:474 */         builder.put(key, entry.getValue());
/* 218:    */       }
/* 219:    */     }
/* 220:477 */     builder.put(normalizedAttribute, normalizeParameterValue(normalizedAttribute, value));
/* 221:478 */     MediaType mediaType = new MediaType(this.type, this.subtype, builder.build());
/* 222:    */     
/* 223:480 */     return (MediaType)MoreObjects.firstNonNull(KNOWN_TYPES.get(mediaType), mediaType);
/* 224:    */   }
/* 225:    */   
/* 226:    */   public MediaType withCharset(Charset charset)
/* 227:    */   {
/* 228:493 */     Preconditions.checkNotNull(charset);
/* 229:494 */     return withParameter("charset", charset.name());
/* 230:    */   }
/* 231:    */   
/* 232:    */   public boolean hasWildcard()
/* 233:    */   {
/* 234:499 */     return ("*".equals(this.type)) || ("*".equals(this.subtype));
/* 235:    */   }
/* 236:    */   
/* 237:    */   public boolean is(MediaType mediaTypeRange)
/* 238:    */   {
/* 239:529 */     return ((mediaTypeRange.type.equals("*")) || (mediaTypeRange.type.equals(this.type))) && ((mediaTypeRange.subtype.equals("*")) || (mediaTypeRange.subtype.equals(this.subtype))) && (this.parameters.entries().containsAll(mediaTypeRange.parameters.entries()));
/* 240:    */   }
/* 241:    */   
/* 242:    */   public static MediaType create(String type, String subtype)
/* 243:    */   {
/* 244:541 */     return create(type, subtype, ImmutableListMultimap.of());
/* 245:    */   }
/* 246:    */   
/* 247:    */   static MediaType createApplicationType(String subtype)
/* 248:    */   {
/* 249:550 */     return create("application", subtype);
/* 250:    */   }
/* 251:    */   
/* 252:    */   static MediaType createAudioType(String subtype)
/* 253:    */   {
/* 254:559 */     return create("audio", subtype);
/* 255:    */   }
/* 256:    */   
/* 257:    */   static MediaType createImageType(String subtype)
/* 258:    */   {
/* 259:568 */     return create("image", subtype);
/* 260:    */   }
/* 261:    */   
/* 262:    */   static MediaType createTextType(String subtype)
/* 263:    */   {
/* 264:577 */     return create("text", subtype);
/* 265:    */   }
/* 266:    */   
/* 267:    */   static MediaType createVideoType(String subtype)
/* 268:    */   {
/* 269:586 */     return create("video", subtype);
/* 270:    */   }
/* 271:    */   
/* 272:    */   private static MediaType create(String type, String subtype, Multimap<String, String> parameters)
/* 273:    */   {
/* 274:591 */     Preconditions.checkNotNull(type);
/* 275:592 */     Preconditions.checkNotNull(subtype);
/* 276:593 */     Preconditions.checkNotNull(parameters);
/* 277:594 */     String normalizedType = normalizeToken(type);
/* 278:595 */     String normalizedSubtype = normalizeToken(subtype);
/* 279:596 */     Preconditions.checkArgument((!"*".equals(normalizedType)) || ("*".equals(normalizedSubtype)), "A wildcard type cannot be used with a non-wildcard subtype");
/* 280:    */     
/* 281:598 */     ImmutableListMultimap.Builder<String, String> builder = ImmutableListMultimap.builder();
/* 282:599 */     for (Map.Entry<String, String> entry : parameters.entries())
/* 283:    */     {
/* 284:600 */       String attribute = normalizeToken((String)entry.getKey());
/* 285:601 */       builder.put(attribute, normalizeParameterValue(attribute, (String)entry.getValue()));
/* 286:    */     }
/* 287:603 */     MediaType mediaType = new MediaType(normalizedType, normalizedSubtype, builder.build());
/* 288:    */     
/* 289:605 */     return (MediaType)MoreObjects.firstNonNull(KNOWN_TYPES.get(mediaType), mediaType);
/* 290:    */   }
/* 291:    */   
/* 292:    */   private static String normalizeToken(String token)
/* 293:    */   {
/* 294:609 */     Preconditions.checkArgument(TOKEN_MATCHER.matchesAllOf(token));
/* 295:610 */     return Ascii.toLowerCase(token);
/* 296:    */   }
/* 297:    */   
/* 298:    */   private static String normalizeParameterValue(String attribute, String value)
/* 299:    */   {
/* 300:614 */     return "charset".equals(attribute) ? Ascii.toLowerCase(value) : value;
/* 301:    */   }
/* 302:    */   
/* 303:    */   public static MediaType parse(String input)
/* 304:    */   {
/* 305:623 */     Preconditions.checkNotNull(input);
/* 306:624 */     Tokenizer tokenizer = new Tokenizer(input);
/* 307:    */     try
/* 308:    */     {
/* 309:626 */       String type = tokenizer.consumeToken(TOKEN_MATCHER);
/* 310:627 */       tokenizer.consumeCharacter('/');
/* 311:628 */       String subtype = tokenizer.consumeToken(TOKEN_MATCHER);
/* 312:629 */       ImmutableListMultimap.Builder<String, String> parameters = ImmutableListMultimap.builder();
/* 313:630 */       while (tokenizer.hasMore())
/* 314:    */       {
/* 315:631 */         tokenizer.consumeCharacter(';');
/* 316:632 */         tokenizer.consumeTokenIfPresent(LINEAR_WHITE_SPACE);
/* 317:633 */         String attribute = tokenizer.consumeToken(TOKEN_MATCHER);
/* 318:634 */         tokenizer.consumeCharacter('=');
/* 319:    */         String value;
/* 320:636 */         if ('"' == tokenizer.previewChar())
/* 321:    */         {
/* 322:637 */           tokenizer.consumeCharacter('"');
/* 323:638 */           StringBuilder valueBuilder = new StringBuilder();
/* 324:639 */           while ('"' != tokenizer.previewChar()) {
/* 325:640 */             if ('\\' == tokenizer.previewChar())
/* 326:    */             {
/* 327:641 */               tokenizer.consumeCharacter('\\');
/* 328:642 */               valueBuilder.append(tokenizer.consumeCharacter(CharMatcher.ASCII));
/* 329:    */             }
/* 330:    */             else
/* 331:    */             {
/* 332:644 */               valueBuilder.append(tokenizer.consumeToken(QUOTED_TEXT_MATCHER));
/* 333:    */             }
/* 334:    */           }
/* 335:647 */           String value = valueBuilder.toString();
/* 336:648 */           tokenizer.consumeCharacter('"');
/* 337:    */         }
/* 338:    */         else
/* 339:    */         {
/* 340:650 */           value = tokenizer.consumeToken(TOKEN_MATCHER);
/* 341:    */         }
/* 342:652 */         parameters.put(attribute, value);
/* 343:    */       }
/* 344:654 */       return create(type, subtype, parameters.build());
/* 345:    */     }
/* 346:    */     catch (IllegalStateException e)
/* 347:    */     {
/* 348:656 */       throw new IllegalArgumentException("Could not parse '" + input + "'", e);
/* 349:    */     }
/* 350:    */   }
/* 351:    */   
/* 352:    */   private static final class Tokenizer
/* 353:    */   {
/* 354:    */     final String input;
/* 355:662 */     int position = 0;
/* 356:    */     
/* 357:    */     Tokenizer(String input)
/* 358:    */     {
/* 359:665 */       this.input = input;
/* 360:    */     }
/* 361:    */     
/* 362:    */     String consumeTokenIfPresent(CharMatcher matcher)
/* 363:    */     {
/* 364:669 */       Preconditions.checkState(hasMore());
/* 365:670 */       int startPosition = this.position;
/* 366:671 */       this.position = matcher.negate().indexIn(this.input, startPosition);
/* 367:672 */       return hasMore() ? this.input.substring(startPosition, this.position) : this.input.substring(startPosition);
/* 368:    */     }
/* 369:    */     
/* 370:    */     String consumeToken(CharMatcher matcher)
/* 371:    */     {
/* 372:676 */       int startPosition = this.position;
/* 373:677 */       String token = consumeTokenIfPresent(matcher);
/* 374:678 */       Preconditions.checkState(this.position != startPosition);
/* 375:679 */       return token;
/* 376:    */     }
/* 377:    */     
/* 378:    */     char consumeCharacter(CharMatcher matcher)
/* 379:    */     {
/* 380:683 */       Preconditions.checkState(hasMore());
/* 381:684 */       char c = previewChar();
/* 382:685 */       Preconditions.checkState(matcher.matches(c));
/* 383:686 */       this.position += 1;
/* 384:687 */       return c;
/* 385:    */     }
/* 386:    */     
/* 387:    */     char consumeCharacter(char c)
/* 388:    */     {
/* 389:691 */       Preconditions.checkState(hasMore());
/* 390:692 */       Preconditions.checkState(previewChar() == c);
/* 391:693 */       this.position += 1;
/* 392:694 */       return c;
/* 393:    */     }
/* 394:    */     
/* 395:    */     char previewChar()
/* 396:    */     {
/* 397:698 */       Preconditions.checkState(hasMore());
/* 398:699 */       return this.input.charAt(this.position);
/* 399:    */     }
/* 400:    */     
/* 401:    */     boolean hasMore()
/* 402:    */     {
/* 403:703 */       return (this.position >= 0) && (this.position < this.input.length());
/* 404:    */     }
/* 405:    */   }
/* 406:    */   
/* 407:    */   public boolean equals(@Nullable Object obj)
/* 408:    */   {
/* 409:708 */     if (obj == this) {
/* 410:709 */       return true;
/* 411:    */     }
/* 412:710 */     if ((obj instanceof MediaType))
/* 413:    */     {
/* 414:711 */       MediaType that = (MediaType)obj;
/* 415:712 */       return (this.type.equals(that.type)) && (this.subtype.equals(that.subtype)) && (parametersAsMap().equals(that.parametersAsMap()));
/* 416:    */     }
/* 417:717 */     return false;
/* 418:    */   }
/* 419:    */   
/* 420:    */   public int hashCode()
/* 421:    */   {
/* 422:723 */     int h = this.hashCode;
/* 423:724 */     if (h == 0)
/* 424:    */     {
/* 425:725 */       h = Objects.hashCode(new Object[] { this.type, this.subtype, parametersAsMap() });
/* 426:726 */       this.hashCode = h;
/* 427:    */     }
/* 428:728 */     return h;
/* 429:    */   }
/* 430:    */   
/* 431:731 */   private static final Joiner.MapJoiner PARAMETER_JOINER = Joiner.on("; ").withKeyValueSeparator("=");
/* 432:    */   
/* 433:    */   public String toString()
/* 434:    */   {
/* 435:739 */     String result = this.toString;
/* 436:740 */     if (result == null)
/* 437:    */     {
/* 438:741 */       result = computeToString();
/* 439:742 */       this.toString = result;
/* 440:    */     }
/* 441:744 */     return result;
/* 442:    */   }
/* 443:    */   
/* 444:    */   private String computeToString()
/* 445:    */   {
/* 446:748 */     StringBuilder builder = new StringBuilder().append(this.type).append('/').append(this.subtype);
/* 447:749 */     if (!this.parameters.isEmpty())
/* 448:    */     {
/* 449:750 */       builder.append("; ");
/* 450:751 */       Multimap<String, String> quotedParameters = Multimaps.transformValues(this.parameters, new Function()
/* 451:    */       {
/* 452:    */         public String apply(String value)
/* 453:    */         {
/* 454:754 */           return MediaType.TOKEN_MATCHER.matchesAllOf(value) ? value : MediaType.escapeAndQuote(value);
/* 455:    */         }
/* 456:756 */       });
/* 457:757 */       PARAMETER_JOINER.appendTo(builder, quotedParameters.entries());
/* 458:    */     }
/* 459:759 */     return builder.toString();
/* 460:    */   }
/* 461:    */   
/* 462:    */   private static String escapeAndQuote(String value)
/* 463:    */   {
/* 464:763 */     StringBuilder escaped = new StringBuilder(value.length() + 16).append('"');
/* 465:764 */     for (int i = 0; i < value.length(); i++)
/* 466:    */     {
/* 467:765 */       char ch = value.charAt(i);
/* 468:766 */       if ((ch == '\r') || (ch == '\\') || (ch == '"')) {
/* 469:767 */         escaped.append('\\');
/* 470:    */       }
/* 471:769 */       escaped.append(ch);
/* 472:    */     }
/* 473:771 */     return '"';
/* 474:    */   }
/* 475:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.net.MediaType
 * JD-Core Version:    0.7.0.1
 */