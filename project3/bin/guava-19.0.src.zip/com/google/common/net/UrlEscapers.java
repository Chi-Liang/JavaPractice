/*   1:    */ package com.google.common.net;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.escape.Escaper;
/*   6:    */ 
/*   7:    */ @Beta
/*   8:    */ @GwtCompatible
/*   9:    */ public final class UrlEscapers
/*  10:    */ {
/*  11:    */   static final String URL_FORM_PARAMETER_OTHER_SAFE_CHARS = "-_.*";
/*  12:    */   static final String URL_PATH_OTHER_SAFE_CHARS_LACKING_PLUS = "-._~!$'()*,;&=@:";
/*  13:    */   
/*  14:    */   public static Escaper urlFormParameterEscaper()
/*  15:    */   {
/*  16: 85 */     return URL_FORM_PARAMETER_ESCAPER;
/*  17:    */   }
/*  18:    */   
/*  19: 88 */   private static final Escaper URL_FORM_PARAMETER_ESCAPER = new PercentEscaper("-_.*", true);
/*  20:    */   
/*  21:    */   public static Escaper urlPathSegmentEscaper()
/*  22:    */   {
/*  23:126 */     return URL_PATH_SEGMENT_ESCAPER;
/*  24:    */   }
/*  25:    */   
/*  26:129 */   private static final Escaper URL_PATH_SEGMENT_ESCAPER = new PercentEscaper("-._~!$'()*,;&=@:+", false);
/*  27:    */   
/*  28:    */   public static Escaper urlFragmentEscaper()
/*  29:    */   {
/*  30:164 */     return URL_FRAGMENT_ESCAPER;
/*  31:    */   }
/*  32:    */   
/*  33:167 */   private static final Escaper URL_FRAGMENT_ESCAPER = new PercentEscaper("-._~!$'()*,;&=@:+/?", false);
/*  34:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.net.UrlEscapers
 * JD-Core Version:    0.7.0.1
 */