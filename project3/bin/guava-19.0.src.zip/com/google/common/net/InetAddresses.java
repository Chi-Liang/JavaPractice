/*    1:     */ package com.google.common.net;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.base.MoreObjects;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.hash.HashCode;
/*    7:     */ import com.google.common.hash.HashFunction;
/*    8:     */ import com.google.common.hash.Hashing;
/*    9:     */ import com.google.common.io.ByteArrayDataInput;
/*   10:     */ import com.google.common.io.ByteStreams;
/*   11:     */ import com.google.common.primitives.Ints;
/*   12:     */ import java.net.Inet4Address;
/*   13:     */ import java.net.Inet6Address;
/*   14:     */ import java.net.InetAddress;
/*   15:     */ import java.net.UnknownHostException;
/*   16:     */ import java.nio.ByteBuffer;
/*   17:     */ import java.util.Arrays;
/*   18:     */ import java.util.Locale;
/*   19:     */ import javax.annotation.Nullable;
/*   20:     */ 
/*   21:     */ @Beta
/*   22:     */ public final class InetAddresses
/*   23:     */ {
/*   24:     */   private static final int IPV4_PART_COUNT = 4;
/*   25:     */   private static final int IPV6_PART_COUNT = 8;
/*   26: 118 */   private static final Inet4Address LOOPBACK4 = (Inet4Address)forString("127.0.0.1");
/*   27: 119 */   private static final Inet4Address ANY4 = (Inet4Address)forString("0.0.0.0");
/*   28:     */   
/*   29:     */   private static Inet4Address getInet4Address(byte[] bytes)
/*   30:     */   {
/*   31: 131 */     Preconditions.checkArgument(bytes.length == 4, "Byte array has invalid length for an IPv4 address: %s != 4.", new Object[] { Integer.valueOf(bytes.length) });
/*   32:     */     
/*   33:     */ 
/*   34:     */ 
/*   35:     */ 
/*   36: 136 */     return (Inet4Address)bytesToInetAddress(bytes);
/*   37:     */   }
/*   38:     */   
/*   39:     */   public static InetAddress forString(String ipString)
/*   40:     */   {
/*   41: 150 */     byte[] addr = ipStringToBytes(ipString);
/*   42: 153 */     if (addr == null) {
/*   43: 154 */       throw formatIllegalArgumentException("'%s' is not an IP string literal.", new Object[] { ipString });
/*   44:     */     }
/*   45: 157 */     return bytesToInetAddress(addr);
/*   46:     */   }
/*   47:     */   
/*   48:     */   public static boolean isInetAddress(String ipString)
/*   49:     */   {
/*   50: 168 */     return ipStringToBytes(ipString) != null;
/*   51:     */   }
/*   52:     */   
/*   53:     */   private static byte[] ipStringToBytes(String ipString)
/*   54:     */   {
/*   55: 173 */     boolean hasColon = false;
/*   56: 174 */     boolean hasDot = false;
/*   57: 175 */     for (int i = 0; i < ipString.length(); i++)
/*   58:     */     {
/*   59: 176 */       char c = ipString.charAt(i);
/*   60: 177 */       if (c == '.')
/*   61:     */       {
/*   62: 178 */         hasDot = true;
/*   63:     */       }
/*   64: 179 */       else if (c == ':')
/*   65:     */       {
/*   66: 180 */         if (hasDot) {
/*   67: 181 */           return null;
/*   68:     */         }
/*   69: 183 */         hasColon = true;
/*   70:     */       }
/*   71: 184 */       else if (Character.digit(c, 16) == -1)
/*   72:     */       {
/*   73: 185 */         return null;
/*   74:     */       }
/*   75:     */     }
/*   76: 190 */     if (hasColon)
/*   77:     */     {
/*   78: 191 */       if (hasDot)
/*   79:     */       {
/*   80: 192 */         ipString = convertDottedQuadToHex(ipString);
/*   81: 193 */         if (ipString == null) {
/*   82: 194 */           return null;
/*   83:     */         }
/*   84:     */       }
/*   85: 197 */       return textToNumericFormatV6(ipString);
/*   86:     */     }
/*   87: 198 */     if (hasDot) {
/*   88: 199 */       return textToNumericFormatV4(ipString);
/*   89:     */     }
/*   90: 201 */     return null;
/*   91:     */   }
/*   92:     */   
/*   93:     */   private static byte[] textToNumericFormatV4(String ipString)
/*   94:     */   {
/*   95: 205 */     String[] address = ipString.split("\\.", 5);
/*   96: 206 */     if (address.length != 4) {
/*   97: 207 */       return null;
/*   98:     */     }
/*   99: 210 */     byte[] bytes = new byte[4];
/*  100:     */     try
/*  101:     */     {
/*  102: 212 */       for (int i = 0; i < bytes.length; i++) {
/*  103: 213 */         bytes[i] = parseOctet(address[i]);
/*  104:     */       }
/*  105:     */     }
/*  106:     */     catch (NumberFormatException ex)
/*  107:     */     {
/*  108: 216 */       return null;
/*  109:     */     }
/*  110: 219 */     return bytes;
/*  111:     */   }
/*  112:     */   
/*  113:     */   private static byte[] textToNumericFormatV6(String ipString)
/*  114:     */   {
/*  115: 224 */     String[] parts = ipString.split(":", 10);
/*  116: 225 */     if ((parts.length < 3) || (parts.length > 9)) {
/*  117: 226 */       return null;
/*  118:     */     }
/*  119: 231 */     int skipIndex = -1;
/*  120: 232 */     for (int i = 1; i < parts.length - 1; i++) {
/*  121: 233 */       if (parts[i].length() == 0)
/*  122:     */       {
/*  123: 234 */         if (skipIndex >= 0) {
/*  124: 235 */           return null;
/*  125:     */         }
/*  126: 237 */         skipIndex = i;
/*  127:     */       }
/*  128:     */     }
/*  129:     */     int partsHi;
/*  130:     */     int partsLo;
/*  131: 243 */     if (skipIndex >= 0)
/*  132:     */     {
/*  133: 245 */       int partsHi = skipIndex;
/*  134: 246 */       int partsLo = parts.length - skipIndex - 1;
/*  135: 247 */       if (parts[0].length() == 0)
/*  136:     */       {
/*  137: 247 */         partsHi--;
/*  138: 247 */         if (partsHi != 0) {
/*  139: 248 */           return null;
/*  140:     */         }
/*  141:     */       }
/*  142: 250 */       if (parts[(parts.length - 1)].length() == 0)
/*  143:     */       {
/*  144: 250 */         partsLo--;
/*  145: 250 */         if (partsLo != 0) {
/*  146: 251 */           return null;
/*  147:     */         }
/*  148:     */       }
/*  149:     */     }
/*  150:     */     else
/*  151:     */     {
/*  152: 256 */       partsHi = parts.length;
/*  153: 257 */       partsLo = 0;
/*  154:     */     }
/*  155: 262 */     int partsSkipped = 8 - (partsHi + partsLo);
/*  156: 263 */     if (skipIndex >= 0 ? partsSkipped < 1 : partsSkipped != 0) {
/*  157: 264 */       return null;
/*  158:     */     }
/*  159: 268 */     ByteBuffer rawBytes = ByteBuffer.allocate(16);
/*  160:     */     try
/*  161:     */     {
/*  162: 270 */       for (int i = 0; i < partsHi; i++) {
/*  163: 271 */         rawBytes.putShort(parseHextet(parts[i]));
/*  164:     */       }
/*  165: 273 */       for (int i = 0; i < partsSkipped; i++) {
/*  166: 274 */         rawBytes.putShort((short)0);
/*  167:     */       }
/*  168: 276 */       for (int i = partsLo; i > 0; i--) {
/*  169: 277 */         rawBytes.putShort(parseHextet(parts[(parts.length - i)]));
/*  170:     */       }
/*  171:     */     }
/*  172:     */     catch (NumberFormatException ex)
/*  173:     */     {
/*  174: 280 */       return null;
/*  175:     */     }
/*  176: 282 */     return rawBytes.array();
/*  177:     */   }
/*  178:     */   
/*  179:     */   private static String convertDottedQuadToHex(String ipString)
/*  180:     */   {
/*  181: 286 */     int lastColon = ipString.lastIndexOf(':');
/*  182: 287 */     String initialPart = ipString.substring(0, lastColon + 1);
/*  183: 288 */     String dottedQuad = ipString.substring(lastColon + 1);
/*  184: 289 */     byte[] quad = textToNumericFormatV4(dottedQuad);
/*  185: 290 */     if (quad == null) {
/*  186: 291 */       return null;
/*  187:     */     }
/*  188: 293 */     String penultimate = Integer.toHexString((quad[0] & 0xFF) << 8 | quad[1] & 0xFF);
/*  189: 294 */     String ultimate = Integer.toHexString((quad[2] & 0xFF) << 8 | quad[3] & 0xFF);
/*  190: 295 */     return initialPart + penultimate + ":" + ultimate;
/*  191:     */   }
/*  192:     */   
/*  193:     */   private static byte parseOctet(String ipPart)
/*  194:     */   {
/*  195: 300 */     int octet = Integer.parseInt(ipPart);
/*  196: 303 */     if ((octet > 255) || ((ipPart.startsWith("0")) && (ipPart.length() > 1))) {
/*  197: 304 */       throw new NumberFormatException();
/*  198:     */     }
/*  199: 306 */     return (byte)octet;
/*  200:     */   }
/*  201:     */   
/*  202:     */   private static short parseHextet(String ipPart)
/*  203:     */   {
/*  204: 311 */     int hextet = Integer.parseInt(ipPart, 16);
/*  205: 312 */     if (hextet > 65535) {
/*  206: 313 */       throw new NumberFormatException();
/*  207:     */     }
/*  208: 315 */     return (short)hextet;
/*  209:     */   }
/*  210:     */   
/*  211:     */   private static InetAddress bytesToInetAddress(byte[] addr)
/*  212:     */   {
/*  213:     */     try
/*  214:     */     {
/*  215: 331 */       return InetAddress.getByAddress(addr);
/*  216:     */     }
/*  217:     */     catch (UnknownHostException e)
/*  218:     */     {
/*  219: 333 */       throw new AssertionError(e);
/*  220:     */     }
/*  221:     */   }
/*  222:     */   
/*  223:     */   public static String toAddrString(InetAddress ip)
/*  224:     */   {
/*  225: 355 */     Preconditions.checkNotNull(ip);
/*  226: 356 */     if ((ip instanceof Inet4Address)) {
/*  227: 358 */       return ip.getHostAddress();
/*  228:     */     }
/*  229: 360 */     Preconditions.checkArgument(ip instanceof Inet6Address);
/*  230: 361 */     byte[] bytes = ip.getAddress();
/*  231: 362 */     int[] hextets = new int[8];
/*  232: 363 */     for (int i = 0; i < hextets.length; i++) {
/*  233: 364 */       hextets[i] = Ints.fromBytes(0, 0, bytes[(2 * i)], bytes[(2 * i + 1)]);
/*  234:     */     }
/*  235: 367 */     compressLongestRunOfZeroes(hextets);
/*  236: 368 */     return hextetsToIPv6String(hextets);
/*  237:     */   }
/*  238:     */   
/*  239:     */   private static void compressLongestRunOfZeroes(int[] hextets)
/*  240:     */   {
/*  241: 381 */     int bestRunStart = -1;
/*  242: 382 */     int bestRunLength = -1;
/*  243: 383 */     int runStart = -1;
/*  244: 384 */     for (int i = 0; i < hextets.length + 1; i++) {
/*  245: 385 */       if ((i < hextets.length) && (hextets[i] == 0))
/*  246:     */       {
/*  247: 386 */         if (runStart < 0) {
/*  248: 387 */           runStart = i;
/*  249:     */         }
/*  250:     */       }
/*  251: 389 */       else if (runStart >= 0)
/*  252:     */       {
/*  253: 390 */         int runLength = i - runStart;
/*  254: 391 */         if (runLength > bestRunLength)
/*  255:     */         {
/*  256: 392 */           bestRunStart = runStart;
/*  257: 393 */           bestRunLength = runLength;
/*  258:     */         }
/*  259: 395 */         runStart = -1;
/*  260:     */       }
/*  261:     */     }
/*  262: 398 */     if (bestRunLength >= 2) {
/*  263: 399 */       Arrays.fill(hextets, bestRunStart, bestRunStart + bestRunLength, -1);
/*  264:     */     }
/*  265:     */   }
/*  266:     */   
/*  267:     */   private static String hextetsToIPv6String(int[] hextets)
/*  268:     */   {
/*  269: 418 */     StringBuilder buf = new StringBuilder(39);
/*  270: 419 */     boolean lastWasNumber = false;
/*  271: 420 */     for (int i = 0; i < hextets.length; i++)
/*  272:     */     {
/*  273: 421 */       boolean thisIsNumber = hextets[i] >= 0;
/*  274: 422 */       if (thisIsNumber)
/*  275:     */       {
/*  276: 423 */         if (lastWasNumber) {
/*  277: 424 */           buf.append(':');
/*  278:     */         }
/*  279: 426 */         buf.append(Integer.toHexString(hextets[i]));
/*  280:     */       }
/*  281: 428 */       else if ((i == 0) || (lastWasNumber))
/*  282:     */       {
/*  283: 429 */         buf.append("::");
/*  284:     */       }
/*  285: 432 */       lastWasNumber = thisIsNumber;
/*  286:     */     }
/*  287: 434 */     return buf.toString();
/*  288:     */   }
/*  289:     */   
/*  290:     */   public static String toUriString(InetAddress ip)
/*  291:     */   {
/*  292: 463 */     if ((ip instanceof Inet6Address)) {
/*  293: 464 */       return "[" + toAddrString(ip) + "]";
/*  294:     */     }
/*  295: 466 */     return toAddrString(ip);
/*  296:     */   }
/*  297:     */   
/*  298:     */   public static InetAddress forUriString(String hostAddr)
/*  299:     */   {
/*  300: 485 */     Preconditions.checkNotNull(hostAddr);
/*  301:     */     int expectBytes;
/*  302:     */     String ipString;
/*  303:     */     int expectBytes;
/*  304: 490 */     if ((hostAddr.startsWith("[")) && (hostAddr.endsWith("]")))
/*  305:     */     {
/*  306: 491 */       String ipString = hostAddr.substring(1, hostAddr.length() - 1);
/*  307: 492 */       expectBytes = 16;
/*  308:     */     }
/*  309:     */     else
/*  310:     */     {
/*  311: 494 */       ipString = hostAddr;
/*  312: 495 */       expectBytes = 4;
/*  313:     */     }
/*  314: 499 */     byte[] addr = ipStringToBytes(ipString);
/*  315: 500 */     if ((addr == null) || (addr.length != expectBytes)) {
/*  316: 501 */       throw formatIllegalArgumentException("Not a valid URI IP literal: '%s'", new Object[] { hostAddr });
/*  317:     */     }
/*  318: 504 */     return bytesToInetAddress(addr);
/*  319:     */   }
/*  320:     */   
/*  321:     */   public static boolean isUriInetAddress(String ipString)
/*  322:     */   {
/*  323:     */     try
/*  324:     */     {
/*  325: 516 */       forUriString(ipString);
/*  326: 517 */       return true;
/*  327:     */     }
/*  328:     */     catch (IllegalArgumentException e) {}
/*  329: 519 */     return false;
/*  330:     */   }
/*  331:     */   
/*  332:     */   public static boolean isCompatIPv4Address(Inet6Address ip)
/*  333:     */   {
/*  334: 548 */     if (!ip.isIPv4CompatibleAddress()) {
/*  335: 549 */       return false;
/*  336:     */     }
/*  337: 552 */     byte[] bytes = ip.getAddress();
/*  338: 553 */     if ((bytes[12] == 0) && (bytes[13] == 0) && (bytes[14] == 0) && ((bytes[15] == 0) || (bytes[15] == 1))) {
/*  339: 555 */       return false;
/*  340:     */     }
/*  341: 558 */     return true;
/*  342:     */   }
/*  343:     */   
/*  344:     */   public static Inet4Address getCompatIPv4Address(Inet6Address ip)
/*  345:     */   {
/*  346: 569 */     Preconditions.checkArgument(isCompatIPv4Address(ip), "Address '%s' is not IPv4-compatible.", new Object[] { toAddrString(ip) });
/*  347:     */     
/*  348:     */ 
/*  349: 572 */     return getInet4Address(Arrays.copyOfRange(ip.getAddress(), 12, 16));
/*  350:     */   }
/*  351:     */   
/*  352:     */   public static boolean is6to4Address(Inet6Address ip)
/*  353:     */   {
/*  354: 590 */     byte[] bytes = ip.getAddress();
/*  355: 591 */     return (bytes[0] == 32) && (bytes[1] == 2);
/*  356:     */   }
/*  357:     */   
/*  358:     */   public static Inet4Address get6to4IPv4Address(Inet6Address ip)
/*  359:     */   {
/*  360: 602 */     Preconditions.checkArgument(is6to4Address(ip), "Address '%s' is not a 6to4 address.", new Object[] { toAddrString(ip) });
/*  361:     */     
/*  362:     */ 
/*  363: 605 */     return getInet4Address(Arrays.copyOfRange(ip.getAddress(), 2, 6));
/*  364:     */   }
/*  365:     */   
/*  366:     */   @Beta
/*  367:     */   public static final class TeredoInfo
/*  368:     */   {
/*  369:     */     private final Inet4Address server;
/*  370:     */     private final Inet4Address client;
/*  371:     */     private final int port;
/*  372:     */     private final int flags;
/*  373:     */     
/*  374:     */     public TeredoInfo(@Nullable Inet4Address server, @Nullable Inet4Address client, int port, int flags)
/*  375:     */     {
/*  376: 643 */       Preconditions.checkArgument((port >= 0) && (port <= 65535), "port '%s' is out of range (0 <= port <= 0xffff)", new Object[] { Integer.valueOf(port) });
/*  377:     */       
/*  378: 645 */       Preconditions.checkArgument((flags >= 0) && (flags <= 65535), "flags '%s' is out of range (0 <= flags <= 0xffff)", new Object[] { Integer.valueOf(flags) });
/*  379:     */       
/*  380:     */ 
/*  381: 648 */       this.server = ((Inet4Address)MoreObjects.firstNonNull(server, InetAddresses.ANY4));
/*  382: 649 */       this.client = ((Inet4Address)MoreObjects.firstNonNull(client, InetAddresses.ANY4));
/*  383: 650 */       this.port = port;
/*  384: 651 */       this.flags = flags;
/*  385:     */     }
/*  386:     */     
/*  387:     */     public Inet4Address getServer()
/*  388:     */     {
/*  389: 655 */       return this.server;
/*  390:     */     }
/*  391:     */     
/*  392:     */     public Inet4Address getClient()
/*  393:     */     {
/*  394: 659 */       return this.client;
/*  395:     */     }
/*  396:     */     
/*  397:     */     public int getPort()
/*  398:     */     {
/*  399: 663 */       return this.port;
/*  400:     */     }
/*  401:     */     
/*  402:     */     public int getFlags()
/*  403:     */     {
/*  404: 667 */       return this.flags;
/*  405:     */     }
/*  406:     */   }
/*  407:     */   
/*  408:     */   public static boolean isTeredoAddress(Inet6Address ip)
/*  409:     */   {
/*  410: 680 */     byte[] bytes = ip.getAddress();
/*  411: 681 */     return (bytes[0] == 32) && (bytes[1] == 1) && (bytes[2] == 0) && (bytes[3] == 0);
/*  412:     */   }
/*  413:     */   
/*  414:     */   public static TeredoInfo getTeredoInfo(Inet6Address ip)
/*  415:     */   {
/*  416: 693 */     Preconditions.checkArgument(isTeredoAddress(ip), "Address '%s' is not a Teredo address.", new Object[] { toAddrString(ip) });
/*  417:     */     
/*  418:     */ 
/*  419: 696 */     byte[] bytes = ip.getAddress();
/*  420: 697 */     Inet4Address server = getInet4Address(Arrays.copyOfRange(bytes, 4, 8));
/*  421:     */     
/*  422: 699 */     int flags = ByteStreams.newDataInput(bytes, 8).readShort() & 0xFFFF;
/*  423:     */     
/*  424:     */ 
/*  425: 702 */     int port = (ByteStreams.newDataInput(bytes, 10).readShort() ^ 0xFFFFFFFF) & 0xFFFF;
/*  426:     */     
/*  427: 704 */     byte[] clientBytes = Arrays.copyOfRange(bytes, 12, 16);
/*  428: 705 */     for (int i = 0; i < clientBytes.length; i++) {
/*  429: 707 */       clientBytes[i] = ((byte)(clientBytes[i] ^ 0xFFFFFFFF));
/*  430:     */     }
/*  431: 709 */     Inet4Address client = getInet4Address(clientBytes);
/*  432:     */     
/*  433: 711 */     return new TeredoInfo(server, client, port, flags);
/*  434:     */   }
/*  435:     */   
/*  436:     */   public static boolean isIsatapAddress(Inet6Address ip)
/*  437:     */   {
/*  438: 733 */     if (isTeredoAddress(ip)) {
/*  439: 734 */       return false;
/*  440:     */     }
/*  441: 737 */     byte[] bytes = ip.getAddress();
/*  442: 739 */     if ((bytes[8] | 0x3) != 3) {
/*  443: 743 */       return false;
/*  444:     */     }
/*  445: 746 */     return (bytes[9] == 0) && (bytes[10] == 94) && (bytes[11] == -2);
/*  446:     */   }
/*  447:     */   
/*  448:     */   public static Inet4Address getIsatapIPv4Address(Inet6Address ip)
/*  449:     */   {
/*  450: 758 */     Preconditions.checkArgument(isIsatapAddress(ip), "Address '%s' is not an ISATAP address.", new Object[] { toAddrString(ip) });
/*  451:     */     
/*  452:     */ 
/*  453: 761 */     return getInet4Address(Arrays.copyOfRange(ip.getAddress(), 12, 16));
/*  454:     */   }
/*  455:     */   
/*  456:     */   public static boolean hasEmbeddedIPv4ClientAddress(Inet6Address ip)
/*  457:     */   {
/*  458: 777 */     return (isCompatIPv4Address(ip)) || (is6to4Address(ip)) || (isTeredoAddress(ip));
/*  459:     */   }
/*  460:     */   
/*  461:     */   public static Inet4Address getEmbeddedIPv4ClientAddress(Inet6Address ip)
/*  462:     */   {
/*  463: 794 */     if (isCompatIPv4Address(ip)) {
/*  464: 795 */       return getCompatIPv4Address(ip);
/*  465:     */     }
/*  466: 798 */     if (is6to4Address(ip)) {
/*  467: 799 */       return get6to4IPv4Address(ip);
/*  468:     */     }
/*  469: 802 */     if (isTeredoAddress(ip)) {
/*  470: 803 */       return getTeredoInfo(ip).getClient();
/*  471:     */     }
/*  472: 806 */     throw formatIllegalArgumentException("'%s' has no embedded IPv4 address.", new Object[] { toAddrString(ip) });
/*  473:     */   }
/*  474:     */   
/*  475:     */   public static boolean isMappedIPv4Address(String ipString)
/*  476:     */   {
/*  477: 832 */     byte[] bytes = ipStringToBytes(ipString);
/*  478: 833 */     if ((bytes != null) && (bytes.length == 16))
/*  479:     */     {
/*  480: 834 */       for (int i = 0; i < 10; i++) {
/*  481: 835 */         if (bytes[i] != 0) {
/*  482: 836 */           return false;
/*  483:     */         }
/*  484:     */       }
/*  485: 839 */       for (int i = 10; i < 12; i++) {
/*  486: 840 */         if (bytes[i] != -1) {
/*  487: 841 */           return false;
/*  488:     */         }
/*  489:     */       }
/*  490: 844 */       return true;
/*  491:     */     }
/*  492: 846 */     return false;
/*  493:     */   }
/*  494:     */   
/*  495:     */   public static Inet4Address getCoercedIPv4Address(InetAddress ip)
/*  496:     */   {
/*  497: 870 */     if ((ip instanceof Inet4Address)) {
/*  498: 871 */       return (Inet4Address)ip;
/*  499:     */     }
/*  500: 875 */     byte[] bytes = ip.getAddress();
/*  501: 876 */     boolean leadingBytesOfZero = true;
/*  502: 877 */     for (int i = 0; i < 15; i++) {
/*  503: 878 */       if (bytes[i] != 0)
/*  504:     */       {
/*  505: 879 */         leadingBytesOfZero = false;
/*  506: 880 */         break;
/*  507:     */       }
/*  508:     */     }
/*  509: 883 */     if ((leadingBytesOfZero) && (bytes[15] == 1)) {
/*  510: 884 */       return LOOPBACK4;
/*  511:     */     }
/*  512: 885 */     if ((leadingBytesOfZero) && (bytes[15] == 0)) {
/*  513: 886 */       return ANY4;
/*  514:     */     }
/*  515: 889 */     Inet6Address ip6 = (Inet6Address)ip;
/*  516: 890 */     long addressAsLong = 0L;
/*  517: 891 */     if (hasEmbeddedIPv4ClientAddress(ip6)) {
/*  518: 892 */       addressAsLong = getEmbeddedIPv4ClientAddress(ip6).hashCode();
/*  519:     */     } else {
/*  520: 896 */       addressAsLong = ByteBuffer.wrap(ip6.getAddress(), 0, 8).getLong();
/*  521:     */     }
/*  522: 900 */     int coercedHash = Hashing.murmur3_32().hashLong(addressAsLong).asInt();
/*  523:     */     
/*  524:     */ 
/*  525: 903 */     coercedHash |= 0xE0000000;
/*  526: 907 */     if (coercedHash == -1) {
/*  527: 908 */       coercedHash = -2;
/*  528:     */     }
/*  529: 911 */     return getInet4Address(Ints.toByteArray(coercedHash));
/*  530:     */   }
/*  531:     */   
/*  532:     */   public static int coerceToInteger(InetAddress ip)
/*  533:     */   {
/*  534: 936 */     return ByteStreams.newDataInput(getCoercedIPv4Address(ip).getAddress()).readInt();
/*  535:     */   }
/*  536:     */   
/*  537:     */   public static Inet4Address fromInteger(int address)
/*  538:     */   {
/*  539: 947 */     return getInet4Address(Ints.toByteArray(address));
/*  540:     */   }
/*  541:     */   
/*  542:     */   public static InetAddress fromLittleEndianByteArray(byte[] addr)
/*  543:     */     throws UnknownHostException
/*  544:     */   {
/*  545: 962 */     byte[] reversed = new byte[addr.length];
/*  546: 963 */     for (int i = 0; i < addr.length; i++) {
/*  547: 964 */       reversed[i] = addr[(addr.length - i - 1)];
/*  548:     */     }
/*  549: 966 */     return InetAddress.getByAddress(reversed);
/*  550:     */   }
/*  551:     */   
/*  552:     */   public static InetAddress decrement(InetAddress address)
/*  553:     */   {
/*  554: 979 */     byte[] addr = address.getAddress();
/*  555: 980 */     int i = addr.length - 1;
/*  556: 981 */     while ((i >= 0) && (addr[i] == 0))
/*  557:     */     {
/*  558: 982 */       addr[i] = -1;
/*  559: 983 */       i--;
/*  560:     */     }
/*  561: 986 */     Preconditions.checkArgument(i >= 0, "Decrementing %s would wrap.", new Object[] { address }); int 
/*  562:     */     
/*  563: 988 */       tmp54_53 = i; byte[] tmp54_52 = addr;tmp54_52[tmp54_53] = ((byte)(tmp54_52[tmp54_53] - 1));
/*  564: 989 */     return bytesToInetAddress(addr);
/*  565:     */   }
/*  566:     */   
/*  567:     */   public static InetAddress increment(InetAddress address)
/*  568:     */   {
/*  569:1002 */     byte[] addr = address.getAddress();
/*  570:1003 */     int i = addr.length - 1;
/*  571:1004 */     while ((i >= 0) && (addr[i] == -1))
/*  572:     */     {
/*  573:1005 */       addr[i] = 0;
/*  574:1006 */       i--;
/*  575:     */     }
/*  576:1009 */     Preconditions.checkArgument(i >= 0, "Incrementing %s would wrap.", new Object[] { address }); int 
/*  577:     */     
/*  578:1011 */       tmp55_54 = i; byte[] tmp55_53 = addr;tmp55_53[tmp55_54] = ((byte)(tmp55_53[tmp55_54] + 1));
/*  579:1012 */     return bytesToInetAddress(addr);
/*  580:     */   }
/*  581:     */   
/*  582:     */   public static boolean isMaximum(InetAddress address)
/*  583:     */   {
/*  584:1024 */     byte[] addr = address.getAddress();
/*  585:1025 */     for (int i = 0; i < addr.length; i++) {
/*  586:1026 */       if (addr[i] != -1) {
/*  587:1027 */         return false;
/*  588:     */       }
/*  589:     */     }
/*  590:1030 */     return true;
/*  591:     */   }
/*  592:     */   
/*  593:     */   private static IllegalArgumentException formatIllegalArgumentException(String format, Object... args)
/*  594:     */   {
/*  595:1035 */     return new IllegalArgumentException(String.format(Locale.ROOT, format, args));
/*  596:     */   }
/*  597:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.net.InetAddresses
 * JD-Core Version:    0.7.0.1
 */