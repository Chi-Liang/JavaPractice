/*   1:    */ package com.google.common.net;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.escape.UnicodeEscaper;
/*   7:    */ 
/*   8:    */ @Beta
/*   9:    */ @GwtCompatible
/*  10:    */ public final class PercentEscaper
/*  11:    */   extends UnicodeEscaper
/*  12:    */ {
/*  13: 62 */   private static final char[] PLUS_SIGN = { '+' };
/*  14: 65 */   private static final char[] UPPER_HEX_DIGITS = "0123456789ABCDEF".toCharArray();
/*  15:    */   private final boolean plusForSpace;
/*  16:    */   private final boolean[] safeOctets;
/*  17:    */   
/*  18:    */   public PercentEscaper(String safeChars, boolean plusForSpace)
/*  19:    */   {
/*  20: 98 */     Preconditions.checkNotNull(safeChars);
/*  21:100 */     if (safeChars.matches(".*[0-9A-Za-z].*")) {
/*  22:101 */       throw new IllegalArgumentException("Alphanumeric characters are always 'safe' and should not be explicitly specified");
/*  23:    */     }
/*  24:105 */     safeChars = safeChars + "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
/*  25:110 */     if ((plusForSpace) && (safeChars.contains(" "))) {
/*  26:111 */       throw new IllegalArgumentException("plusForSpace cannot be specified when space is a 'safe' character");
/*  27:    */     }
/*  28:114 */     this.plusForSpace = plusForSpace;
/*  29:115 */     this.safeOctets = createSafeOctets(safeChars);
/*  30:    */   }
/*  31:    */   
/*  32:    */   private static boolean[] createSafeOctets(String safeChars)
/*  33:    */   {
/*  34:124 */     int maxChar = -1;
/*  35:125 */     char[] safeCharArray = safeChars.toCharArray();
/*  36:126 */     for (char c : safeCharArray) {
/*  37:127 */       maxChar = Math.max(c, maxChar);
/*  38:    */     }
/*  39:129 */     boolean[] octets = new boolean[maxChar + 1];
/*  40:130 */     for (char c : safeCharArray) {
/*  41:131 */       octets[c] = true;
/*  42:    */     }
/*  43:133 */     return octets;
/*  44:    */   }
/*  45:    */   
/*  46:    */   protected int nextEscapeIndex(CharSequence csq, int index, int end)
/*  47:    */   {
/*  48:143 */     Preconditions.checkNotNull(csq);
/*  49:144 */     for (; index < end; index++)
/*  50:    */     {
/*  51:145 */       char c = csq.charAt(index);
/*  52:146 */       if ((c >= this.safeOctets.length) || (this.safeOctets[c] == 0)) {
/*  53:    */         break;
/*  54:    */       }
/*  55:    */     }
/*  56:150 */     return index;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public String escape(String s)
/*  60:    */   {
/*  61:160 */     Preconditions.checkNotNull(s);
/*  62:161 */     int slen = s.length();
/*  63:162 */     for (int index = 0; index < slen; index++)
/*  64:    */     {
/*  65:163 */       char c = s.charAt(index);
/*  66:164 */       if ((c >= this.safeOctets.length) || (this.safeOctets[c] == 0)) {
/*  67:165 */         return escapeSlow(s, index);
/*  68:    */       }
/*  69:    */     }
/*  70:168 */     return s;
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected char[] escape(int cp)
/*  74:    */   {
/*  75:178 */     if ((cp < this.safeOctets.length) && (this.safeOctets[cp] != 0)) {
/*  76:179 */       return null;
/*  77:    */     }
/*  78:180 */     if ((cp == 32) && (this.plusForSpace)) {
/*  79:181 */       return PLUS_SIGN;
/*  80:    */     }
/*  81:182 */     if (cp <= 127)
/*  82:    */     {
/*  83:185 */       char[] dest = new char[3];
/*  84:186 */       dest[0] = '%';
/*  85:187 */       dest[2] = UPPER_HEX_DIGITS[(cp & 0xF)];
/*  86:188 */       dest[1] = UPPER_HEX_DIGITS[(cp >>> 4)];
/*  87:189 */       return dest;
/*  88:    */     }
/*  89:190 */     if (cp <= 2047)
/*  90:    */     {
/*  91:193 */       char[] dest = new char[6];
/*  92:194 */       dest[0] = '%';
/*  93:195 */       dest[3] = '%';
/*  94:196 */       dest[5] = UPPER_HEX_DIGITS[(cp & 0xF)];
/*  95:197 */       cp >>>= 4;
/*  96:198 */       dest[4] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/*  97:199 */       cp >>>= 2;
/*  98:200 */       dest[2] = UPPER_HEX_DIGITS[(cp & 0xF)];
/*  99:201 */       cp >>>= 4;
/* 100:202 */       dest[1] = UPPER_HEX_DIGITS[(0xC | cp)];
/* 101:203 */       return dest;
/* 102:    */     }
/* 103:204 */     if (cp <= 65535)
/* 104:    */     {
/* 105:207 */       char[] dest = new char[9];
/* 106:208 */       dest[0] = '%';
/* 107:209 */       dest[1] = 'E';
/* 108:210 */       dest[3] = '%';
/* 109:211 */       dest[6] = '%';
/* 110:212 */       dest[8] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 111:213 */       cp >>>= 4;
/* 112:214 */       dest[7] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 113:215 */       cp >>>= 2;
/* 114:216 */       dest[5] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 115:217 */       cp >>>= 4;
/* 116:218 */       dest[4] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 117:219 */       cp >>>= 2;
/* 118:220 */       dest[2] = UPPER_HEX_DIGITS[cp];
/* 119:221 */       return dest;
/* 120:    */     }
/* 121:222 */     if (cp <= 1114111)
/* 122:    */     {
/* 123:223 */       char[] dest = new char[12];
/* 124:    */       
/* 125:    */ 
/* 126:226 */       dest[0] = '%';
/* 127:227 */       dest[1] = 'F';
/* 128:228 */       dest[3] = '%';
/* 129:229 */       dest[6] = '%';
/* 130:230 */       dest[9] = '%';
/* 131:231 */       dest[11] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 132:232 */       cp >>>= 4;
/* 133:233 */       dest[10] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 134:234 */       cp >>>= 2;
/* 135:235 */       dest[8] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 136:236 */       cp >>>= 4;
/* 137:237 */       dest[7] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 138:238 */       cp >>>= 2;
/* 139:239 */       dest[5] = UPPER_HEX_DIGITS[(cp & 0xF)];
/* 140:240 */       cp >>>= 4;
/* 141:241 */       dest[4] = UPPER_HEX_DIGITS[(0x8 | cp & 0x3)];
/* 142:242 */       cp >>>= 2;
/* 143:243 */       dest[2] = UPPER_HEX_DIGITS[(cp & 0x7)];
/* 144:244 */       return dest;
/* 145:    */     }
/* 146:247 */     throw new IllegalArgumentException("Invalid unicode character value " + cp);
/* 147:    */   }
/* 148:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.net.PercentEscaper
 * JD-Core Version:    0.7.0.1
 */