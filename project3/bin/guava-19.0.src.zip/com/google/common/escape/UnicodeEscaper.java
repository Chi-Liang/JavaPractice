/*   1:    */ package com.google.common.escape;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ 
/*   7:    */ @Beta
/*   8:    */ @GwtCompatible
/*   9:    */ public abstract class UnicodeEscaper
/*  10:    */   extends Escaper
/*  11:    */ {
/*  12:    */   private static final int DEST_PAD = 32;
/*  13:    */   
/*  14:    */   protected abstract char[] escape(int paramInt);
/*  15:    */   
/*  16:    */   protected int nextEscapeIndex(CharSequence csq, int start, int end)
/*  17:    */   {
/*  18:116 */     int index = start;
/*  19:117 */     while (index < end)
/*  20:    */     {
/*  21:118 */       int cp = codePointAt(csq, index, end);
/*  22:119 */       if ((cp < 0) || (escape(cp) != null)) {
/*  23:    */         break;
/*  24:    */       }
/*  25:122 */       index += (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/*  26:    */     }
/*  27:124 */     return index;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public String escape(String string)
/*  31:    */   {
/*  32:152 */     Preconditions.checkNotNull(string);
/*  33:153 */     int end = string.length();
/*  34:154 */     int index = nextEscapeIndex(string, 0, end);
/*  35:155 */     return index == end ? string : escapeSlow(string, index);
/*  36:    */   }
/*  37:    */   
/*  38:    */   protected final String escapeSlow(String s, int index)
/*  39:    */   {
/*  40:176 */     int end = s.length();
/*  41:    */     
/*  42:    */ 
/*  43:179 */     char[] dest = Platform.charBufferFromThreadLocal();
/*  44:180 */     int destIndex = 0;
/*  45:181 */     int unescapedChunkStart = 0;
/*  46:183 */     while (index < end)
/*  47:    */     {
/*  48:184 */       int cp = codePointAt(s, index, end);
/*  49:185 */       if (cp < 0) {
/*  50:186 */         throw new IllegalArgumentException("Trailing high surrogate at end of input");
/*  51:    */       }
/*  52:192 */       char[] escaped = escape(cp);
/*  53:193 */       int nextIndex = index + (Character.isSupplementaryCodePoint(cp) ? 2 : 1);
/*  54:194 */       if (escaped != null)
/*  55:    */       {
/*  56:195 */         int charsSkipped = index - unescapedChunkStart;
/*  57:    */         
/*  58:    */ 
/*  59:    */ 
/*  60:199 */         int sizeNeeded = destIndex + charsSkipped + escaped.length;
/*  61:200 */         if (dest.length < sizeNeeded)
/*  62:    */         {
/*  63:201 */           int destLength = sizeNeeded + (end - index) + 32;
/*  64:202 */           dest = growBuffer(dest, destIndex, destLength);
/*  65:    */         }
/*  66:205 */         if (charsSkipped > 0)
/*  67:    */         {
/*  68:206 */           s.getChars(unescapedChunkStart, index, dest, destIndex);
/*  69:207 */           destIndex += charsSkipped;
/*  70:    */         }
/*  71:209 */         if (escaped.length > 0)
/*  72:    */         {
/*  73:210 */           System.arraycopy(escaped, 0, dest, destIndex, escaped.length);
/*  74:211 */           destIndex += escaped.length;
/*  75:    */         }
/*  76:214 */         unescapedChunkStart = nextIndex;
/*  77:    */       }
/*  78:216 */       index = nextEscapeIndex(s, nextIndex, end);
/*  79:    */     }
/*  80:221 */     int charsSkipped = end - unescapedChunkStart;
/*  81:222 */     if (charsSkipped > 0)
/*  82:    */     {
/*  83:223 */       int endIndex = destIndex + charsSkipped;
/*  84:224 */       if (dest.length < endIndex) {
/*  85:225 */         dest = growBuffer(dest, destIndex, endIndex);
/*  86:    */       }
/*  87:227 */       s.getChars(unescapedChunkStart, end, dest, destIndex);
/*  88:228 */       destIndex = endIndex;
/*  89:    */     }
/*  90:230 */     return new String(dest, 0, destIndex);
/*  91:    */   }
/*  92:    */   
/*  93:    */   protected static int codePointAt(CharSequence seq, int index, int end)
/*  94:    */   {
/*  95:266 */     Preconditions.checkNotNull(seq);
/*  96:267 */     if (index < end)
/*  97:    */     {
/*  98:268 */       char c1 = seq.charAt(index++);
/*  99:269 */       if ((c1 < 55296) || (c1 > 57343)) {
/* 100:272 */         return c1;
/* 101:    */       }
/* 102:273 */       if (c1 <= 56319)
/* 103:    */       {
/* 104:275 */         if (index == end) {
/* 105:276 */           return -c1;
/* 106:    */         }
/* 107:279 */         char c2 = seq.charAt(index);
/* 108:280 */         if (Character.isLowSurrogate(c2)) {
/* 109:281 */           return Character.toCodePoint(c1, c2);
/* 110:    */         }
/* 111:283 */         throw new IllegalArgumentException("Expected low surrogate but got char '" + c2 + "' with value " + c2 + " at index " + index + " in '" + seq + "'");
/* 112:    */       }
/* 113:288 */       throw new IllegalArgumentException("Unexpected low surrogate character '" + c1 + "' with value " + c1 + " at index " + (index - 1) + " in '" + seq + "'");
/* 114:    */     }
/* 115:294 */     throw new IndexOutOfBoundsException("Index exceeds specified range");
/* 116:    */   }
/* 117:    */   
/* 118:    */   private static char[] growBuffer(char[] dest, int index, int size)
/* 119:    */   {
/* 120:303 */     char[] copy = new char[size];
/* 121:304 */     if (index > 0) {
/* 122:305 */       System.arraycopy(dest, 0, copy, 0, index);
/* 123:    */     }
/* 124:307 */     return copy;
/* 125:    */   }
/* 126:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.escape.UnicodeEscaper
 * JD-Core Version:    0.7.0.1
 */