/*   1:    */ package com.google.common.escape;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Map;
/*   7:    */ 
/*   8:    */ @Beta
/*   9:    */ @GwtCompatible
/*  10:    */ public abstract class ArrayBasedCharEscaper
/*  11:    */   extends CharEscaper
/*  12:    */ {
/*  13:    */   private final char[][] replacements;
/*  14:    */   private final int replacementsLength;
/*  15:    */   private final char safeMin;
/*  16:    */   private final char safeMax;
/*  17:    */   
/*  18:    */   protected ArrayBasedCharEscaper(Map<Character, String> replacementMap, char safeMin, char safeMax)
/*  19:    */   {
/*  20: 77 */     this(ArrayBasedEscaperMap.create(replacementMap), safeMin, safeMax);
/*  21:    */   }
/*  22:    */   
/*  23:    */   protected ArrayBasedCharEscaper(ArrayBasedEscaperMap escaperMap, char safeMin, char safeMax)
/*  24:    */   {
/*  25: 98 */     Preconditions.checkNotNull(escaperMap);
/*  26: 99 */     this.replacements = escaperMap.getReplacementArray();
/*  27:100 */     this.replacementsLength = this.replacements.length;
/*  28:101 */     if (safeMax < safeMin)
/*  29:    */     {
/*  30:104 */       safeMax = '\000';
/*  31:105 */       safeMin = 65535;
/*  32:    */     }
/*  33:107 */     this.safeMin = safeMin;
/*  34:108 */     this.safeMax = safeMax;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public final String escape(String s)
/*  38:    */   {
/*  39:118 */     Preconditions.checkNotNull(s);
/*  40:119 */     for (int i = 0; i < s.length(); i++)
/*  41:    */     {
/*  42:120 */       char c = s.charAt(i);
/*  43:121 */       if (((c < this.replacementsLength) && (this.replacements[c] != null)) || (c > this.safeMax) || (c < this.safeMin)) {
/*  44:123 */         return escapeSlow(s, i);
/*  45:    */       }
/*  46:    */     }
/*  47:126 */     return s;
/*  48:    */   }
/*  49:    */   
/*  50:    */   protected final char[] escape(char c)
/*  51:    */   {
/*  52:135 */     if (c < this.replacementsLength)
/*  53:    */     {
/*  54:136 */       char[] chars = this.replacements[c];
/*  55:137 */       if (chars != null) {
/*  56:138 */         return chars;
/*  57:    */       }
/*  58:    */     }
/*  59:141 */     if ((c >= this.safeMin) && (c <= this.safeMax)) {
/*  60:142 */       return null;
/*  61:    */     }
/*  62:144 */     return escapeUnsafe(c);
/*  63:    */   }
/*  64:    */   
/*  65:    */   protected abstract char[] escapeUnsafe(char paramChar);
/*  66:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.escape.ArrayBasedCharEscaper
 * JD-Core Version:    0.7.0.1
 */