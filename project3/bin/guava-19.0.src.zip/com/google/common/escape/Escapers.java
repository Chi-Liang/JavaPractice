/*   1:    */ package com.google.common.escape;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ @GwtCompatible
/*  12:    */ public final class Escapers
/*  13:    */ {
/*  14:    */   public static Escaper nullEscaper()
/*  15:    */   {
/*  16: 46 */     return NULL_ESCAPER;
/*  17:    */   }
/*  18:    */   
/*  19: 51 */   private static final Escaper NULL_ESCAPER = new CharEscaper()
/*  20:    */   {
/*  21:    */     public String escape(String string)
/*  22:    */     {
/*  23: 53 */       return (String)Preconditions.checkNotNull(string);
/*  24:    */     }
/*  25:    */     
/*  26:    */     protected char[] escape(char c)
/*  27:    */     {
/*  28: 58 */       return null;
/*  29:    */     }
/*  30:    */   };
/*  31:    */   
/*  32:    */   public static Builder builder()
/*  33:    */   {
/*  34: 78 */     return new Builder(null);
/*  35:    */   }
/*  36:    */   
/*  37:    */   @Beta
/*  38:    */   public static final class Builder
/*  39:    */   {
/*  40: 95 */     private final Map<Character, String> replacementMap = new HashMap();
/*  41: 97 */     private char safeMin = '\000';
/*  42: 98 */     private char safeMax = 65535;
/*  43: 99 */     private String unsafeReplacement = null;
/*  44:    */     
/*  45:    */     public Builder setSafeRange(char safeMin, char safeMax)
/*  46:    */     {
/*  47:115 */       this.safeMin = safeMin;
/*  48:116 */       this.safeMax = safeMax;
/*  49:117 */       return this;
/*  50:    */     }
/*  51:    */     
/*  52:    */     public Builder setUnsafeReplacement(@Nullable String unsafeReplacement)
/*  53:    */     {
/*  54:130 */       this.unsafeReplacement = unsafeReplacement;
/*  55:131 */       return this;
/*  56:    */     }
/*  57:    */     
/*  58:    */     public Builder addEscape(char c, String replacement)
/*  59:    */     {
/*  60:146 */       Preconditions.checkNotNull(replacement);
/*  61:    */       
/*  62:148 */       this.replacementMap.put(Character.valueOf(c), replacement);
/*  63:149 */       return this;
/*  64:    */     }
/*  65:    */     
/*  66:    */     public Escaper build()
/*  67:    */     {
/*  68:156 */       new ArrayBasedCharEscaper(this.replacementMap, this.safeMin, this.safeMax)
/*  69:    */       {
/*  70:157 */         private final char[] replacementChars = Escapers.Builder.this.unsafeReplacement != null ? Escapers.Builder.this.unsafeReplacement.toCharArray() : null;
/*  71:    */         
/*  72:    */         protected char[] escapeUnsafe(char c)
/*  73:    */         {
/*  74:160 */           return this.replacementChars;
/*  75:    */         }
/*  76:    */       };
/*  77:    */     }
/*  78:    */   }
/*  79:    */   
/*  80:    */   static UnicodeEscaper asUnicodeEscaper(Escaper escaper)
/*  81:    */   {
/*  82:183 */     Preconditions.checkNotNull(escaper);
/*  83:184 */     if ((escaper instanceof UnicodeEscaper)) {
/*  84:185 */       return (UnicodeEscaper)escaper;
/*  85:    */     }
/*  86:186 */     if ((escaper instanceof CharEscaper)) {
/*  87:187 */       return wrap((CharEscaper)escaper);
/*  88:    */     }
/*  89:191 */     throw new IllegalArgumentException("Cannot create a UnicodeEscaper from: " + escaper.getClass().getName());
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static String computeReplacement(CharEscaper escaper, char c)
/*  93:    */   {
/*  94:206 */     return stringOrNull(escaper.escape(c));
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static String computeReplacement(UnicodeEscaper escaper, int cp)
/*  98:    */   {
/*  99:220 */     return stringOrNull(escaper.escape(cp));
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static String stringOrNull(char[] in)
/* 103:    */   {
/* 104:224 */     return in == null ? null : new String(in);
/* 105:    */   }
/* 106:    */   
/* 107:    */   private static UnicodeEscaper wrap(CharEscaper escaper)
/* 108:    */   {
/* 109:229 */     new UnicodeEscaper()
/* 110:    */     {
/* 111:    */       protected char[] escape(int cp)
/* 112:    */       {
/* 113:232 */         if (cp < 65536) {
/* 114:233 */           return this.val$escaper.escape((char)cp);
/* 115:    */         }
/* 116:239 */         char[] surrogateChars = new char[2];
/* 117:240 */         Character.toChars(cp, surrogateChars, 0);
/* 118:241 */         char[] hiChars = this.val$escaper.escape(surrogateChars[0]);
/* 119:242 */         char[] loChars = this.val$escaper.escape(surrogateChars[1]);
/* 120:248 */         if ((hiChars == null) && (loChars == null)) {
/* 121:250 */           return null;
/* 122:    */         }
/* 123:253 */         int hiCount = hiChars != null ? hiChars.length : 1;
/* 124:254 */         int loCount = loChars != null ? loChars.length : 1;
/* 125:255 */         char[] output = new char[hiCount + loCount];
/* 126:256 */         if (hiChars != null) {
/* 127:258 */           for (int n = 0; n < hiChars.length; n++) {
/* 128:259 */             output[n] = hiChars[n];
/* 129:    */           }
/* 130:    */         } else {
/* 131:262 */           output[0] = surrogateChars[0];
/* 132:    */         }
/* 133:264 */         if (loChars != null) {
/* 134:265 */           for (int n = 0; n < loChars.length; n++) {
/* 135:266 */             output[(hiCount + n)] = loChars[n];
/* 136:    */           }
/* 137:    */         } else {
/* 138:269 */           output[hiCount] = surrogateChars[1];
/* 139:    */         }
/* 140:271 */         return output;
/* 141:    */       }
/* 142:    */     };
/* 143:    */   }
/* 144:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.escape.Escapers
 * JD-Core Version:    0.7.0.1
 */