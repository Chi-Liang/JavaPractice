/*   1:    */ package com.google.common.escape;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ 
/*   7:    */ @Beta
/*   8:    */ @GwtCompatible
/*   9:    */ public abstract class Escaper
/*  10:    */ {
/*  11: 89 */   private final Function<String, String> asFunction = new Function()
/*  12:    */   {
/*  13:    */     public String apply(String from)
/*  14:    */     {
/*  15: 93 */       return Escaper.this.escape(from);
/*  16:    */     }
/*  17:    */   };
/*  18:    */   
/*  19:    */   public abstract String escape(String paramString);
/*  20:    */   
/*  21:    */   public final Function<String, String> asFunction()
/*  22:    */   {
/*  23:101 */     return this.asFunction;
/*  24:    */   }
/*  25:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.escape.Escaper
 * JD-Core Version:    0.7.0.1
 */