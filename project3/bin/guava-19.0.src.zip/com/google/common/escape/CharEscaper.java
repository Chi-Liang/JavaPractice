/*   1:    */ package com.google.common.escape;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ 
/*   7:    */ @Beta
/*   8:    */ @GwtCompatible
/*   9:    */ public abstract class CharEscaper
/*  10:    */   extends Escaper
/*  11:    */ {
/*  12:    */   private static final int DEST_PAD_MULTIPLIER = 2;
/*  13:    */   
/*  14:    */   public String escape(String string)
/*  15:    */   {
/*  16: 59 */     Preconditions.checkNotNull(string);
/*  17:    */     
/*  18: 61 */     int length = string.length();
/*  19: 62 */     for (int index = 0; index < length; index++) {
/*  20: 63 */       if (escape(string.charAt(index)) != null) {
/*  21: 64 */         return escapeSlow(string, index);
/*  22:    */       }
/*  23:    */     }
/*  24: 67 */     return string;
/*  25:    */   }
/*  26:    */   
/*  27:    */   protected final String escapeSlow(String s, int index)
/*  28:    */   {
/*  29: 82 */     int slen = s.length();
/*  30:    */     
/*  31:    */ 
/*  32: 85 */     char[] dest = Platform.charBufferFromThreadLocal();
/*  33: 86 */     int destSize = dest.length;
/*  34: 87 */     int destIndex = 0;
/*  35: 88 */     int lastEscape = 0;
/*  36: 92 */     for (; index < slen; index++)
/*  37:    */     {
/*  38: 95 */       char[] r = escape(s.charAt(index));
/*  39: 98 */       if (r != null)
/*  40:    */       {
/*  41:100 */         int rlen = r.length;
/*  42:101 */         int charsSkipped = index - lastEscape;
/*  43:    */         
/*  44:    */ 
/*  45:    */ 
/*  46:    */ 
/*  47:106 */         int sizeNeeded = destIndex + charsSkipped + rlen;
/*  48:107 */         if (destSize < sizeNeeded)
/*  49:    */         {
/*  50:108 */           destSize = sizeNeeded + 2 * (slen - index);
/*  51:109 */           dest = growBuffer(dest, destIndex, destSize);
/*  52:    */         }
/*  53:113 */         if (charsSkipped > 0)
/*  54:    */         {
/*  55:114 */           s.getChars(lastEscape, index, dest, destIndex);
/*  56:115 */           destIndex += charsSkipped;
/*  57:    */         }
/*  58:119 */         if (rlen > 0)
/*  59:    */         {
/*  60:120 */           System.arraycopy(r, 0, dest, destIndex, rlen);
/*  61:121 */           destIndex += rlen;
/*  62:    */         }
/*  63:123 */         lastEscape = index + 1;
/*  64:    */       }
/*  65:    */     }
/*  66:127 */     int charsLeft = slen - lastEscape;
/*  67:128 */     if (charsLeft > 0)
/*  68:    */     {
/*  69:129 */       int sizeNeeded = destIndex + charsLeft;
/*  70:130 */       if (destSize < sizeNeeded) {
/*  71:133 */         dest = growBuffer(dest, destIndex, sizeNeeded);
/*  72:    */       }
/*  73:135 */       s.getChars(lastEscape, slen, dest, destIndex);
/*  74:136 */       destIndex = sizeNeeded;
/*  75:    */     }
/*  76:138 */     return new String(dest, 0, destIndex);
/*  77:    */   }
/*  78:    */   
/*  79:    */   protected abstract char[] escape(char paramChar);
/*  80:    */   
/*  81:    */   private static char[] growBuffer(char[] dest, int index, int size)
/*  82:    */   {
/*  83:163 */     char[] copy = new char[size];
/*  84:164 */     if (index > 0) {
/*  85:165 */       System.arraycopy(dest, 0, copy, 0, index);
/*  86:    */     }
/*  87:167 */     return copy;
/*  88:    */   }
/*  89:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.escape.CharEscaper
 * JD-Core Version:    0.7.0.1
 */