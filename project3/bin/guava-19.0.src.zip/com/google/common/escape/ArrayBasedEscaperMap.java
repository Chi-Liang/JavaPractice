/*  1:   */ package com.google.common.escape;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ import com.google.common.annotations.VisibleForTesting;
/*  6:   */ import com.google.common.base.Preconditions;
/*  7:   */ import java.util.Collections;
/*  8:   */ import java.util.Iterator;
/*  9:   */ import java.util.Map;
/* 10:   */ import java.util.Set;
/* 11:   */ 
/* 12:   */ @Beta
/* 13:   */ @GwtCompatible
/* 14:   */ public final class ArrayBasedEscaperMap
/* 15:   */ {
/* 16:   */   private final char[][] replacementArray;
/* 17:   */   
/* 18:   */   public static ArrayBasedEscaperMap create(Map<Character, String> replacements)
/* 19:   */   {
/* 20:56 */     return new ArrayBasedEscaperMap(createReplacementArray(replacements));
/* 21:   */   }
/* 22:   */   
/* 23:   */   private ArrayBasedEscaperMap(char[][] replacementArray)
/* 24:   */   {
/* 25:64 */     this.replacementArray = replacementArray;
/* 26:   */   }
/* 27:   */   
/* 28:   */   char[][] getReplacementArray()
/* 29:   */   {
/* 30:69 */     return this.replacementArray;
/* 31:   */   }
/* 32:   */   
/* 33:   */   @VisibleForTesting
/* 34:   */   static char[][] createReplacementArray(Map<Character, String> map)
/* 35:   */   {
/* 36:77 */     Preconditions.checkNotNull(map);
/* 37:78 */     if (map.isEmpty()) {
/* 38:79 */       return EMPTY_REPLACEMENT_ARRAY;
/* 39:   */     }
/* 40:81 */     char max = ((Character)Collections.max(map.keySet())).charValue();
/* 41:82 */     char[][] replacements = new char[max + '\001'][];
/* 42:83 */     for (Iterator i$ = map.keySet().iterator(); i$.hasNext();)
/* 43:   */     {
/* 44:83 */       char c = ((Character)i$.next()).charValue();
/* 45:84 */       replacements[c] = ((String)map.get(Character.valueOf(c))).toCharArray();
/* 46:   */     }
/* 47:86 */     return replacements;
/* 48:   */   }
/* 49:   */   
/* 50:90 */   private static final char[][] EMPTY_REPLACEMENT_ARRAY = new char[0][0];
/* 51:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.escape.ArrayBasedEscaperMap
 * JD-Core Version:    0.7.0.1
 */