/*  1:   */ package com.google.common.cache;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import com.google.common.collect.ImmutableMap;
/*  5:   */ import java.util.concurrent.ExecutionException;
/*  6:   */ 
/*  7:   */ public abstract class ForwardingLoadingCache<K, V>
/*  8:   */   extends ForwardingCache<K, V>
/*  9:   */   implements LoadingCache<K, V>
/* 10:   */ {
/* 11:   */   protected abstract LoadingCache<K, V> delegate();
/* 12:   */   
/* 13:   */   public V get(K key)
/* 14:   */     throws ExecutionException
/* 15:   */   {
/* 16:46 */     return delegate().get(key);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public V getUnchecked(K key)
/* 20:   */   {
/* 21:51 */     return delegate().getUnchecked(key);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 25:   */     throws ExecutionException
/* 26:   */   {
/* 27:56 */     return delegate().getAll(keys);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public V apply(K key)
/* 31:   */   {
/* 32:61 */     return delegate().apply(key);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void refresh(K key)
/* 36:   */   {
/* 37:66 */     delegate().refresh(key);
/* 38:   */   }
/* 39:   */   
/* 40:   */   public static abstract class SimpleForwardingLoadingCache<K, V>
/* 41:   */     extends ForwardingLoadingCache<K, V>
/* 42:   */   {
/* 43:   */     private final LoadingCache<K, V> delegate;
/* 44:   */     
/* 45:   */     protected SimpleForwardingLoadingCache(LoadingCache<K, V> delegate)
/* 46:   */     {
/* 47:80 */       this.delegate = ((LoadingCache)Preconditions.checkNotNull(delegate));
/* 48:   */     }
/* 49:   */     
/* 50:   */     protected final LoadingCache<K, V> delegate()
/* 51:   */     {
/* 52:85 */       return this.delegate;
/* 53:   */     }
/* 54:   */   }
/* 55:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.ForwardingLoadingCache
 * JD-Core Version:    0.7.0.1
 */