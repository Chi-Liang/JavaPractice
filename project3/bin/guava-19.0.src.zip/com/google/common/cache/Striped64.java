/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import java.lang.reflect.Field;
/*   4:    */ import java.security.AccessController;
/*   5:    */ import java.security.PrivilegedActionException;
/*   6:    */ import java.security.PrivilegedExceptionAction;
/*   7:    */ import java.util.Random;
/*   8:    */ import sun.misc.Unsafe;
/*   9:    */ 
/*  10:    */ abstract class Striped64
/*  11:    */   extends Number
/*  12:    */ {
/*  13:    */   static final class Cell
/*  14:    */   {
/*  15:    */     volatile long p0;
/*  16:    */     volatile long p1;
/*  17:    */     volatile long p2;
/*  18:    */     volatile long p3;
/*  19:    */     volatile long p4;
/*  20:    */     volatile long p5;
/*  21:    */     volatile long p6;
/*  22:    */     volatile long value;
/*  23:    */     volatile long q0;
/*  24:    */     volatile long q1;
/*  25:    */     volatile long q2;
/*  26:    */     volatile long q3;
/*  27:    */     volatile long q4;
/*  28:    */     volatile long q5;
/*  29:    */     volatile long q6;
/*  30:    */     private static final Unsafe UNSAFE;
/*  31:    */     private static final long valueOffset;
/*  32:    */     
/*  33:    */     Cell(long x)
/*  34:    */     {
/*  35: 97 */       this.value = x;
/*  36:    */     }
/*  37:    */     
/*  38:    */     final boolean cas(long cmp, long val)
/*  39:    */     {
/*  40:100 */       return UNSAFE.compareAndSwapLong(this, valueOffset, cmp, val);
/*  41:    */     }
/*  42:    */     
/*  43:    */     static
/*  44:    */     {
/*  45:    */       try
/*  46:    */       {
/*  47:108 */         UNSAFE = Striped64.access$000();
/*  48:109 */         Class<?> ak = Cell.class;
/*  49:110 */         valueOffset = UNSAFE.objectFieldOffset(ak.getDeclaredField("value"));
/*  50:    */       }
/*  51:    */       catch (Exception e)
/*  52:    */       {
/*  53:113 */         throw new Error(e);
/*  54:    */       }
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:125 */   static final ThreadLocal<int[]> threadHashCode = new ThreadLocal();
/*  59:130 */   static final Random rng = new Random();
/*  60:133 */   static final int NCPU = Runtime.getRuntime().availableProcessors();
/*  61:    */   volatile transient Cell[] cells;
/*  62:    */   volatile transient long base;
/*  63:    */   volatile transient int busy;
/*  64:    */   private static final Unsafe UNSAFE;
/*  65:    */   private static final long baseOffset;
/*  66:    */   private static final long busyOffset;
/*  67:    */   
/*  68:    */   final boolean casBase(long cmp, long val)
/*  69:    */   {
/*  70:161 */     return UNSAFE.compareAndSwapLong(this, baseOffset, cmp, val);
/*  71:    */   }
/*  72:    */   
/*  73:    */   final boolean casBusy()
/*  74:    */   {
/*  75:168 */     return UNSAFE.compareAndSwapInt(this, busyOffset, 0, 1);
/*  76:    */   }
/*  77:    */   
/*  78:    */   final void retryUpdate(long x, int[] hc, boolean wasUncontended)
/*  79:    */   {
/*  80:    */     int h;
/*  81:    */     int h;
/*  82:195 */     if (hc == null)
/*  83:    */     {
/*  84:196 */       threadHashCode.set(hc = new int[1]);
/*  85:197 */       int r = rng.nextInt();
/*  86:198 */       h = hc[0] = r == 0 ? 1 : r;
/*  87:    */     }
/*  88:    */     else
/*  89:    */     {
/*  90:201 */       h = hc[0];
/*  91:    */     }
/*  92:202 */     boolean collide = false;
/*  93:    */     for (;;)
/*  94:    */     {
/*  95:    */       Cell[] as;
/*  96:    */       int n;
/*  97:205 */       if (((as = this.cells) != null) && ((n = as.length) > 0))
/*  98:    */       {
/*  99:    */         Cell a;
/* 100:206 */         if ((a = as[(n - 1 & h)]) == null)
/* 101:    */         {
/* 102:207 */           if (this.busy == 0)
/* 103:    */           {
/* 104:208 */             Cell r = new Cell(x);
/* 105:209 */             if ((this.busy == 0) && (casBusy()))
/* 106:    */             {
/* 107:210 */               boolean created = false;
/* 108:    */               try
/* 109:    */               {
/* 110:    */                 Cell[] rs;
/* 111:    */                 int m;
/* 112:    */                 int j;
/* 113:213 */                 if (((rs = this.cells) != null) && ((m = rs.length) > 0) && (rs[(j = m - 1 & h)] == null))
/* 114:    */                 {
/* 115:216 */                   rs[j] = r;
/* 116:217 */                   created = true;
/* 117:    */                 }
/* 118:    */               }
/* 119:    */               finally
/* 120:    */               {
/* 121:220 */                 this.busy = 0;
/* 122:    */               }
/* 123:222 */               if (!created) {
/* 124:    */                 continue;
/* 125:    */               }
/* 126:223 */               break;
/* 127:    */             }
/* 128:    */           }
/* 129:227 */           collide = false;
/* 130:    */         }
/* 131:229 */         else if (!wasUncontended)
/* 132:    */         {
/* 133:230 */           wasUncontended = true;
/* 134:    */         }
/* 135:    */         else
/* 136:    */         {
/* 137:    */           long v;
/* 138:231 */           if (a.cas(v = a.value, fn(v, x))) {
/* 139:    */             break;
/* 140:    */           }
/* 141:233 */           if ((n >= NCPU) || (this.cells != as))
/* 142:    */           {
/* 143:234 */             collide = false;
/* 144:    */           }
/* 145:235 */           else if (!collide)
/* 146:    */           {
/* 147:236 */             collide = true;
/* 148:    */           }
/* 149:237 */           else if ((this.busy == 0) && (casBusy()))
/* 150:    */           {
/* 151:    */             try
/* 152:    */             {
/* 153:239 */               if (this.cells == as)
/* 154:    */               {
/* 155:240 */                 Cell[] rs = new Cell[n << 1];
/* 156:241 */                 for (int i = 0; i < n; i++) {
/* 157:242 */                   rs[i] = as[i];
/* 158:    */                 }
/* 159:243 */                 this.cells = rs;
/* 160:    */               }
/* 161:    */             }
/* 162:    */             finally
/* 163:    */             {
/* 164:246 */               this.busy = 0;
/* 165:    */             }
/* 166:248 */             collide = false;
/* 167:249 */             continue;
/* 168:    */           }
/* 169:    */         }
/* 170:251 */         h ^= h << 13;
/* 171:252 */         h ^= h >>> 17;
/* 172:253 */         h ^= h << 5;
/* 173:254 */         hc[0] = h;
/* 174:    */       }
/* 175:256 */       else if ((this.busy == 0) && (this.cells == as) && (casBusy()))
/* 176:    */       {
/* 177:257 */         boolean init = false;
/* 178:    */         try
/* 179:    */         {
/* 180:259 */           if (this.cells == as)
/* 181:    */           {
/* 182:260 */             Cell[] rs = new Cell[2];
/* 183:261 */             rs[(h & 0x1)] = new Cell(x);
/* 184:262 */             this.cells = rs;
/* 185:263 */             init = true;
/* 186:    */           }
/* 187:    */         }
/* 188:    */         finally
/* 189:    */         {
/* 190:266 */           this.busy = 0;
/* 191:    */         }
/* 192:268 */         if (init) {
/* 193:    */           break;
/* 194:    */         }
/* 195:    */       }
/* 196:    */       else
/* 197:    */       {
/* 198:    */         long v;
/* 199:271 */         if (casBase(v = this.base, fn(v, x))) {
/* 200:    */           break;
/* 201:    */         }
/* 202:    */       }
/* 203:    */     }
/* 204:    */   }
/* 205:    */   
/* 206:    */   final void internalReset(long initialValue)
/* 207:    */   {
/* 208:280 */     Cell[] as = this.cells;
/* 209:281 */     this.base = initialValue;
/* 210:282 */     if (as != null)
/* 211:    */     {
/* 212:283 */       int n = as.length;
/* 213:284 */       for (int i = 0; i < n; i++)
/* 214:    */       {
/* 215:285 */         Cell a = as[i];
/* 216:286 */         if (a != null) {
/* 217:287 */           a.value = initialValue;
/* 218:    */         }
/* 219:    */       }
/* 220:    */     }
/* 221:    */   }
/* 222:    */   
/* 223:    */   static
/* 224:    */   {
/* 225:    */     try
/* 226:    */     {
/* 227:298 */       UNSAFE = getUnsafe();
/* 228:299 */       Class<?> sk = Striped64.class;
/* 229:300 */       baseOffset = UNSAFE.objectFieldOffset(sk.getDeclaredField("base"));
/* 230:    */       
/* 231:302 */       busyOffset = UNSAFE.objectFieldOffset(sk.getDeclaredField("busy"));
/* 232:    */     }
/* 233:    */     catch (Exception e)
/* 234:    */     {
/* 235:305 */       throw new Error(e);
/* 236:    */     }
/* 237:    */   }
/* 238:    */   
/* 239:    */   private static Unsafe getUnsafe()
/* 240:    */   {
/* 241:    */     try
/* 242:    */     {
/* 243:318 */       return Unsafe.getUnsafe();
/* 244:    */     }
/* 245:    */     catch (SecurityException tryReflectionInstead)
/* 246:    */     {
/* 247:    */       try
/* 248:    */       {
/* 249:321 */         (Unsafe)AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 250:    */         {
/* 251:    */           public Unsafe run()
/* 252:    */             throws Exception
/* 253:    */           {
/* 254:324 */             Class<Unsafe> k = Unsafe.class;
/* 255:325 */             for (Field f : k.getDeclaredFields())
/* 256:    */             {
/* 257:326 */               f.setAccessible(true);
/* 258:327 */               Object x = f.get(null);
/* 259:328 */               if (k.isInstance(x)) {
/* 260:329 */                 return (Unsafe)k.cast(x);
/* 261:    */               }
/* 262:    */             }
/* 263:331 */             throw new NoSuchFieldError("the Unsafe");
/* 264:    */           }
/* 265:    */         });
/* 266:    */       }
/* 267:    */       catch (PrivilegedActionException e)
/* 268:    */       {
/* 269:334 */         throw new RuntimeException("Could not initialize intrinsics", e.getCause());
/* 270:    */       }
/* 271:    */     }
/* 272:    */   }
/* 273:    */   
/* 274:    */   abstract long fn(long paramLong1, long paramLong2);
/* 275:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.Striped64
 * JD-Core Version:    0.7.0.1
 */