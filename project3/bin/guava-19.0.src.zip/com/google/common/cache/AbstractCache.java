/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.collect.ImmutableMap;
/*   5:    */ import com.google.common.collect.Maps;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import java.util.concurrent.Callable;
/*   9:    */ import java.util.concurrent.ConcurrentMap;
/*  10:    */ import java.util.concurrent.ExecutionException;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ public abstract class AbstractCache<K, V>
/*  14:    */   implements Cache<K, V>
/*  15:    */ {
/*  16:    */   public V get(K key, Callable<? extends V> valueLoader)
/*  17:    */     throws ExecutionException
/*  18:    */   {
/*  19: 53 */     throw new UnsupportedOperationException();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public ImmutableMap<K, V> getAllPresent(Iterable<?> keys)
/*  23:    */   {
/*  24: 67 */     Map<K, V> result = Maps.newLinkedHashMap();
/*  25: 68 */     for (Object key : keys) {
/*  26: 69 */       if (!result.containsKey(key))
/*  27:    */       {
/*  28: 71 */         K castKey = key;
/*  29: 72 */         V value = getIfPresent(key);
/*  30: 73 */         if (value != null) {
/*  31: 74 */           result.put(castKey, value);
/*  32:    */         }
/*  33:    */       }
/*  34:    */     }
/*  35: 78 */     return ImmutableMap.copyOf(result);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void put(K key, V value)
/*  39:    */   {
/*  40: 86 */     throw new UnsupportedOperationException();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void putAll(Map<? extends K, ? extends V> m)
/*  44:    */   {
/*  45: 94 */     for (Map.Entry<? extends K, ? extends V> entry : m.entrySet()) {
/*  46: 95 */       put(entry.getKey(), entry.getValue());
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void cleanUp() {}
/*  51:    */   
/*  52:    */   public long size()
/*  53:    */   {
/*  54:104 */     throw new UnsupportedOperationException();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public void invalidate(Object key)
/*  58:    */   {
/*  59:109 */     throw new UnsupportedOperationException();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public void invalidateAll(Iterable<?> keys)
/*  63:    */   {
/*  64:117 */     for (Object key : keys) {
/*  65:118 */       invalidate(key);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void invalidateAll()
/*  70:    */   {
/*  71:124 */     throw new UnsupportedOperationException();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public CacheStats stats()
/*  75:    */   {
/*  76:129 */     throw new UnsupportedOperationException();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public ConcurrentMap<K, V> asMap()
/*  80:    */   {
/*  81:134 */     throw new UnsupportedOperationException();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static final class SimpleStatsCounter
/*  85:    */     implements AbstractCache.StatsCounter
/*  86:    */   {
/*  87:205 */     private final LongAddable hitCount = LongAddables.create();
/*  88:206 */     private final LongAddable missCount = LongAddables.create();
/*  89:207 */     private final LongAddable loadSuccessCount = LongAddables.create();
/*  90:208 */     private final LongAddable loadExceptionCount = LongAddables.create();
/*  91:209 */     private final LongAddable totalLoadTime = LongAddables.create();
/*  92:210 */     private final LongAddable evictionCount = LongAddables.create();
/*  93:    */     
/*  94:    */     public void recordHits(int count)
/*  95:    */     {
/*  96:222 */       this.hitCount.add(count);
/*  97:    */     }
/*  98:    */     
/*  99:    */     public void recordMisses(int count)
/* 100:    */     {
/* 101:230 */       this.missCount.add(count);
/* 102:    */     }
/* 103:    */     
/* 104:    */     public void recordLoadSuccess(long loadTime)
/* 105:    */     {
/* 106:235 */       this.loadSuccessCount.increment();
/* 107:236 */       this.totalLoadTime.add(loadTime);
/* 108:    */     }
/* 109:    */     
/* 110:    */     public void recordLoadException(long loadTime)
/* 111:    */     {
/* 112:241 */       this.loadExceptionCount.increment();
/* 113:242 */       this.totalLoadTime.add(loadTime);
/* 114:    */     }
/* 115:    */     
/* 116:    */     public void recordEviction()
/* 117:    */     {
/* 118:247 */       this.evictionCount.increment();
/* 119:    */     }
/* 120:    */     
/* 121:    */     public CacheStats snapshot()
/* 122:    */     {
/* 123:252 */       return new CacheStats(this.hitCount.sum(), this.missCount.sum(), this.loadSuccessCount.sum(), this.loadExceptionCount.sum(), this.totalLoadTime.sum(), this.evictionCount.sum());
/* 124:    */     }
/* 125:    */     
/* 126:    */     public void incrementBy(AbstractCache.StatsCounter other)
/* 127:    */     {
/* 128:265 */       CacheStats otherStats = other.snapshot();
/* 129:266 */       this.hitCount.add(otherStats.hitCount());
/* 130:267 */       this.missCount.add(otherStats.missCount());
/* 131:268 */       this.loadSuccessCount.add(otherStats.loadSuccessCount());
/* 132:269 */       this.loadExceptionCount.add(otherStats.loadExceptionCount());
/* 133:270 */       this.totalLoadTime.add(otherStats.totalLoadTime());
/* 134:271 */       this.evictionCount.add(otherStats.evictionCount());
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static abstract interface StatsCounter
/* 139:    */   {
/* 140:    */     public abstract void recordHits(int paramInt);
/* 141:    */     
/* 142:    */     public abstract void recordMisses(int paramInt);
/* 143:    */     
/* 144:    */     public abstract void recordLoadSuccess(long paramLong);
/* 145:    */     
/* 146:    */     public abstract void recordLoadException(long paramLong);
/* 147:    */     
/* 148:    */     public abstract void recordEviction();
/* 149:    */     
/* 150:    */     public abstract CacheStats snapshot();
/* 151:    */   }
/* 152:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.AbstractCache
 * JD-Core Version:    0.7.0.1
 */