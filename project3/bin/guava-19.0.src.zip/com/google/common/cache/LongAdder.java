/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.ObjectInputStream;
/*   6:    */ import java.io.ObjectOutputStream;
/*   7:    */ import java.io.Serializable;
/*   8:    */ 
/*   9:    */ @GwtCompatible(emulated=true)
/*  10:    */ final class LongAdder
/*  11:    */   extends Striped64
/*  12:    */   implements Serializable, LongAddable
/*  13:    */ {
/*  14:    */   private static final long serialVersionUID = 7249069246863182397L;
/*  15:    */   
/*  16:    */   final long fn(long v, long x)
/*  17:    */   {
/*  18: 56 */     return v + x;
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void add(long x)
/*  22:    */   {
/*  23:    */     Striped64.Cell[] as;
/*  24:    */     long b;
/*  25: 71 */     if (((as = this.cells) != null) || (!casBase(b = this.base, b + x)))
/*  26:    */     {
/*  27: 72 */       boolean uncontended = true;
/*  28:    */       int[] hc;
/*  29:    */       int n;
/*  30:    */       Striped64.Cell a;
/*  31:    */       long v;
/*  32: 73 */       if (((hc = (int[])threadHashCode.get()) == null) || (as == null) || ((n = as.length) < 1) || ((a = as[(n - 1 & hc[0])]) == null) || (!(uncontended = a.cas(v = a.value, v + x)))) {
/*  33: 77 */         retryUpdate(x, hc, uncontended);
/*  34:    */       }
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void increment()
/*  39:    */   {
/*  40: 85 */     add(1L);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public void decrement()
/*  44:    */   {
/*  45: 92 */     add(-1L);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public long sum()
/*  49:    */   {
/*  50:105 */     long sum = this.base;
/*  51:106 */     Striped64.Cell[] as = this.cells;
/*  52:107 */     if (as != null)
/*  53:    */     {
/*  54:108 */       int n = as.length;
/*  55:109 */       for (int i = 0; i < n; i++)
/*  56:    */       {
/*  57:110 */         Striped64.Cell a = as[i];
/*  58:111 */         if (a != null) {
/*  59:112 */           sum += a.value;
/*  60:    */         }
/*  61:    */       }
/*  62:    */     }
/*  63:115 */     return sum;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void reset()
/*  67:    */   {
/*  68:126 */     internalReset(0L);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public long sumThenReset()
/*  72:    */   {
/*  73:140 */     long sum = this.base;
/*  74:141 */     Striped64.Cell[] as = this.cells;
/*  75:142 */     this.base = 0L;
/*  76:143 */     if (as != null)
/*  77:    */     {
/*  78:144 */       int n = as.length;
/*  79:145 */       for (int i = 0; i < n; i++)
/*  80:    */       {
/*  81:146 */         Striped64.Cell a = as[i];
/*  82:147 */         if (a != null)
/*  83:    */         {
/*  84:148 */           sum += a.value;
/*  85:149 */           a.value = 0L;
/*  86:    */         }
/*  87:    */       }
/*  88:    */     }
/*  89:153 */     return sum;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public String toString()
/*  93:    */   {
/*  94:161 */     return Long.toString(sum());
/*  95:    */   }
/*  96:    */   
/*  97:    */   public long longValue()
/*  98:    */   {
/*  99:170 */     return sum();
/* 100:    */   }
/* 101:    */   
/* 102:    */   public int intValue()
/* 103:    */   {
/* 104:178 */     return (int)sum();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public float floatValue()
/* 108:    */   {
/* 109:186 */     return (float)sum();
/* 110:    */   }
/* 111:    */   
/* 112:    */   public double doubleValue()
/* 113:    */   {
/* 114:194 */     return sum();
/* 115:    */   }
/* 116:    */   
/* 117:    */   private void writeObject(ObjectOutputStream s)
/* 118:    */     throws IOException
/* 119:    */   {
/* 120:198 */     s.defaultWriteObject();
/* 121:199 */     s.writeLong(sum());
/* 122:    */   }
/* 123:    */   
/* 124:    */   private void readObject(ObjectInputStream s)
/* 125:    */     throws IOException, ClassNotFoundException
/* 126:    */   {
/* 127:204 */     s.defaultReadObject();
/* 128:205 */     this.busy = 0;
/* 129:206 */     this.cells = null;
/* 130:207 */     this.base = s.readLong();
/* 131:    */   }
/* 132:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.LongAdder
 * JD-Core Version:    0.7.0.1
 */