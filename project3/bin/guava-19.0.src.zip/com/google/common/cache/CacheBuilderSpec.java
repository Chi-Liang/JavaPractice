/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.MoreObjects;
/*   5:    */ import com.google.common.base.MoreObjects.ToStringHelper;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Splitter;
/*   9:    */ import com.google.common.collect.ImmutableList;
/*  10:    */ import com.google.common.collect.ImmutableMap;
/*  11:    */ import com.google.common.collect.ImmutableMap.Builder;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Locale;
/*  14:    */ import java.util.concurrent.TimeUnit;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ public final class CacheBuilderSpec
/*  18:    */ {
/*  19: 89 */   private static final Splitter KEYS_SPLITTER = Splitter.on(',').trimResults();
/*  20: 92 */   private static final Splitter KEY_VALUE_SPLITTER = Splitter.on('=').trimResults();
/*  21: 95 */   private static final ImmutableMap<String, ValueParser> VALUE_PARSERS = ImmutableMap.builder().put("initialCapacity", new InitialCapacityParser()).put("maximumSize", new MaximumSizeParser()).put("maximumWeight", new MaximumWeightParser()).put("concurrencyLevel", new ConcurrencyLevelParser()).put("weakKeys", new KeyStrengthParser(LocalCache.Strength.WEAK)).put("softValues", new ValueStrengthParser(LocalCache.Strength.SOFT)).put("weakValues", new ValueStrengthParser(LocalCache.Strength.WEAK)).put("recordStats", new RecordStatsParser()).put("expireAfterAccess", new AccessDurationParser()).put("expireAfterWrite", new WriteDurationParser()).put("refreshAfterWrite", new RefreshDurationParser()).put("refreshInterval", new RefreshDurationParser()).build();
/*  22:    */   @VisibleForTesting
/*  23:    */   Integer initialCapacity;
/*  24:    */   @VisibleForTesting
/*  25:    */   Long maximumSize;
/*  26:    */   @VisibleForTesting
/*  27:    */   Long maximumWeight;
/*  28:    */   @VisibleForTesting
/*  29:    */   Integer concurrencyLevel;
/*  30:    */   @VisibleForTesting
/*  31:    */   LocalCache.Strength keyStrength;
/*  32:    */   @VisibleForTesting
/*  33:    */   LocalCache.Strength valueStrength;
/*  34:    */   @VisibleForTesting
/*  35:    */   Boolean recordStats;
/*  36:    */   @VisibleForTesting
/*  37:    */   long writeExpirationDuration;
/*  38:    */   @VisibleForTesting
/*  39:    */   TimeUnit writeExpirationTimeUnit;
/*  40:    */   @VisibleForTesting
/*  41:    */   long accessExpirationDuration;
/*  42:    */   @VisibleForTesting
/*  43:    */   TimeUnit accessExpirationTimeUnit;
/*  44:    */   @VisibleForTesting
/*  45:    */   long refreshDuration;
/*  46:    */   @VisibleForTesting
/*  47:    */   TimeUnit refreshTimeUnit;
/*  48:    */   private final String specification;
/*  49:    */   
/*  50:    */   private CacheBuilderSpec(String specification)
/*  51:    */   {
/*  52:128 */     this.specification = specification;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static CacheBuilderSpec parse(String cacheBuilderSpecification)
/*  56:    */   {
/*  57:137 */     CacheBuilderSpec spec = new CacheBuilderSpec(cacheBuilderSpecification);
/*  58:138 */     if (!cacheBuilderSpecification.isEmpty()) {
/*  59:139 */       for (String keyValuePair : KEYS_SPLITTER.split(cacheBuilderSpecification))
/*  60:    */       {
/*  61:140 */         List<String> keyAndValue = ImmutableList.copyOf(KEY_VALUE_SPLITTER.split(keyValuePair));
/*  62:141 */         Preconditions.checkArgument(!keyAndValue.isEmpty(), "blank key-value pair");
/*  63:142 */         Preconditions.checkArgument(keyAndValue.size() <= 2, "key-value pair %s with more than one equals sign", new Object[] { keyValuePair });
/*  64:    */         
/*  65:    */ 
/*  66:    */ 
/*  67:146 */         String key = (String)keyAndValue.get(0);
/*  68:147 */         ValueParser valueParser = (ValueParser)VALUE_PARSERS.get(key);
/*  69:148 */         Preconditions.checkArgument(valueParser != null, "unknown key %s", new Object[] { key });
/*  70:    */         
/*  71:150 */         String value = keyAndValue.size() == 1 ? null : (String)keyAndValue.get(1);
/*  72:151 */         valueParser.parse(spec, key, value);
/*  73:    */       }
/*  74:    */     }
/*  75:155 */     return spec;
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static CacheBuilderSpec disableCaching()
/*  79:    */   {
/*  80:163 */     return parse("maximumSize=0");
/*  81:    */   }
/*  82:    */   
/*  83:    */   CacheBuilder<Object, Object> toCacheBuilder()
/*  84:    */   {
/*  85:170 */     CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder();
/*  86:171 */     if (this.initialCapacity != null) {
/*  87:172 */       builder.initialCapacity(this.initialCapacity.intValue());
/*  88:    */     }
/*  89:174 */     if (this.maximumSize != null) {
/*  90:175 */       builder.maximumSize(this.maximumSize.longValue());
/*  91:    */     }
/*  92:177 */     if (this.maximumWeight != null) {
/*  93:178 */       builder.maximumWeight(this.maximumWeight.longValue());
/*  94:    */     }
/*  95:180 */     if (this.concurrencyLevel != null) {
/*  96:181 */       builder.concurrencyLevel(this.concurrencyLevel.intValue());
/*  97:    */     }
/*  98:183 */     if (this.keyStrength != null) {
/*  99:184 */       switch (1.$SwitchMap$com$google$common$cache$LocalCache$Strength[this.keyStrength.ordinal()])
/* 100:    */       {
/* 101:    */       case 1: 
/* 102:186 */         builder.weakKeys();
/* 103:187 */         break;
/* 104:    */       default: 
/* 105:189 */         throw new AssertionError();
/* 106:    */       }
/* 107:    */     }
/* 108:192 */     if (this.valueStrength != null) {
/* 109:193 */       switch (1.$SwitchMap$com$google$common$cache$LocalCache$Strength[this.valueStrength.ordinal()])
/* 110:    */       {
/* 111:    */       case 2: 
/* 112:195 */         builder.softValues();
/* 113:196 */         break;
/* 114:    */       case 1: 
/* 115:198 */         builder.weakValues();
/* 116:199 */         break;
/* 117:    */       default: 
/* 118:201 */         throw new AssertionError();
/* 119:    */       }
/* 120:    */     }
/* 121:204 */     if ((this.recordStats != null) && (this.recordStats.booleanValue())) {
/* 122:205 */       builder.recordStats();
/* 123:    */     }
/* 124:207 */     if (this.writeExpirationTimeUnit != null) {
/* 125:208 */       builder.expireAfterWrite(this.writeExpirationDuration, this.writeExpirationTimeUnit);
/* 126:    */     }
/* 127:210 */     if (this.accessExpirationTimeUnit != null) {
/* 128:211 */       builder.expireAfterAccess(this.accessExpirationDuration, this.accessExpirationTimeUnit);
/* 129:    */     }
/* 130:213 */     if (this.refreshTimeUnit != null) {
/* 131:214 */       builder.refreshAfterWrite(this.refreshDuration, this.refreshTimeUnit);
/* 132:    */     }
/* 133:217 */     return builder;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public String toParsableString()
/* 137:    */   {
/* 138:227 */     return this.specification;
/* 139:    */   }
/* 140:    */   
/* 141:    */   public String toString()
/* 142:    */   {
/* 143:236 */     return MoreObjects.toStringHelper(this).addValue(toParsableString()).toString();
/* 144:    */   }
/* 145:    */   
/* 146:    */   public int hashCode()
/* 147:    */   {
/* 148:241 */     return Objects.hashCode(new Object[] { this.initialCapacity, this.maximumSize, this.maximumWeight, this.concurrencyLevel, this.keyStrength, this.valueStrength, this.recordStats, durationInNanos(this.writeExpirationDuration, this.writeExpirationTimeUnit), durationInNanos(this.accessExpirationDuration, this.accessExpirationTimeUnit), durationInNanos(this.refreshDuration, this.refreshTimeUnit) });
/* 149:    */   }
/* 150:    */   
/* 151:    */   public boolean equals(@Nullable Object obj)
/* 152:    */   {
/* 153:256 */     if (this == obj) {
/* 154:257 */       return true;
/* 155:    */     }
/* 156:259 */     if (!(obj instanceof CacheBuilderSpec)) {
/* 157:260 */       return false;
/* 158:    */     }
/* 159:262 */     CacheBuilderSpec that = (CacheBuilderSpec)obj;
/* 160:263 */     return (Objects.equal(this.initialCapacity, that.initialCapacity)) && (Objects.equal(this.maximumSize, that.maximumSize)) && (Objects.equal(this.maximumWeight, that.maximumWeight)) && (Objects.equal(this.concurrencyLevel, that.concurrencyLevel)) && (Objects.equal(this.keyStrength, that.keyStrength)) && (Objects.equal(this.valueStrength, that.valueStrength)) && (Objects.equal(this.recordStats, that.recordStats)) && (Objects.equal(durationInNanos(this.writeExpirationDuration, this.writeExpirationTimeUnit), durationInNanos(that.writeExpirationDuration, that.writeExpirationTimeUnit))) && (Objects.equal(durationInNanos(this.accessExpirationDuration, this.accessExpirationTimeUnit), durationInNanos(that.accessExpirationDuration, that.accessExpirationTimeUnit))) && (Objects.equal(durationInNanos(this.refreshDuration, this.refreshTimeUnit), durationInNanos(that.refreshDuration, that.refreshTimeUnit)));
/* 161:    */   }
/* 162:    */   
/* 163:    */   @Nullable
/* 164:    */   private static Long durationInNanos(long duration, @Nullable TimeUnit unit)
/* 165:    */   {
/* 166:283 */     return unit == null ? null : Long.valueOf(unit.toNanos(duration));
/* 167:    */   }
/* 168:    */   
/* 169:    */   private static abstract interface ValueParser
/* 170:    */   {
/* 171:    */     public abstract void parse(CacheBuilderSpec paramCacheBuilderSpec, String paramString1, @Nullable String paramString2);
/* 172:    */   }
/* 173:    */   
/* 174:    */   static abstract class IntegerParser
/* 175:    */     implements CacheBuilderSpec.ValueParser
/* 176:    */   {
/* 177:    */     protected abstract void parseInteger(CacheBuilderSpec paramCacheBuilderSpec, int paramInt);
/* 178:    */     
/* 179:    */     public void parse(CacheBuilderSpec spec, String key, String value)
/* 180:    */     {
/* 181:292 */       Preconditions.checkArgument((value != null) && (!value.isEmpty()), "value of key %s omitted", new Object[] { key });
/* 182:    */       try
/* 183:    */       {
/* 184:294 */         parseInteger(spec, Integer.parseInt(value));
/* 185:    */       }
/* 186:    */       catch (NumberFormatException e)
/* 187:    */       {
/* 188:296 */         throw new IllegalArgumentException(CacheBuilderSpec.format("key %s value set to %s, must be integer", new Object[] { key, value }), e);
/* 189:    */       }
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   static abstract class LongParser
/* 194:    */     implements CacheBuilderSpec.ValueParser
/* 195:    */   {
/* 196:    */     protected abstract void parseLong(CacheBuilderSpec paramCacheBuilderSpec, long paramLong);
/* 197:    */     
/* 198:    */     public void parse(CacheBuilderSpec spec, String key, String value)
/* 199:    */     {
/* 200:308 */       Preconditions.checkArgument((value != null) && (!value.isEmpty()), "value of key %s omitted", new Object[] { key });
/* 201:    */       try
/* 202:    */       {
/* 203:310 */         parseLong(spec, Long.parseLong(value));
/* 204:    */       }
/* 205:    */       catch (NumberFormatException e)
/* 206:    */       {
/* 207:312 */         throw new IllegalArgumentException(CacheBuilderSpec.format("key %s value set to %s, must be integer", new Object[] { key, value }), e);
/* 208:    */       }
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   static class InitialCapacityParser
/* 213:    */     extends CacheBuilderSpec.IntegerParser
/* 214:    */   {
/* 215:    */     protected void parseInteger(CacheBuilderSpec spec, int value)
/* 216:    */     {
/* 217:322 */       Preconditions.checkArgument(spec.initialCapacity == null, "initial capacity was already set to ", new Object[] { spec.initialCapacity });
/* 218:    */       
/* 219:324 */       spec.initialCapacity = Integer.valueOf(value);
/* 220:    */     }
/* 221:    */   }
/* 222:    */   
/* 223:    */   static class MaximumSizeParser
/* 224:    */     extends CacheBuilderSpec.LongParser
/* 225:    */   {
/* 226:    */     protected void parseLong(CacheBuilderSpec spec, long value)
/* 227:    */     {
/* 228:332 */       Preconditions.checkArgument(spec.maximumSize == null, "maximum size was already set to ", new Object[] { spec.maximumSize });
/* 229:    */       
/* 230:334 */       Preconditions.checkArgument(spec.maximumWeight == null, "maximum weight was already set to ", new Object[] { spec.maximumWeight });
/* 231:    */       
/* 232:336 */       spec.maximumSize = Long.valueOf(value);
/* 233:    */     }
/* 234:    */   }
/* 235:    */   
/* 236:    */   static class MaximumWeightParser
/* 237:    */     extends CacheBuilderSpec.LongParser
/* 238:    */   {
/* 239:    */     protected void parseLong(CacheBuilderSpec spec, long value)
/* 240:    */     {
/* 241:344 */       Preconditions.checkArgument(spec.maximumWeight == null, "maximum weight was already set to ", new Object[] { spec.maximumWeight });
/* 242:    */       
/* 243:346 */       Preconditions.checkArgument(spec.maximumSize == null, "maximum size was already set to ", new Object[] { spec.maximumSize });
/* 244:    */       
/* 245:348 */       spec.maximumWeight = Long.valueOf(value);
/* 246:    */     }
/* 247:    */   }
/* 248:    */   
/* 249:    */   static class ConcurrencyLevelParser
/* 250:    */     extends CacheBuilderSpec.IntegerParser
/* 251:    */   {
/* 252:    */     protected void parseInteger(CacheBuilderSpec spec, int value)
/* 253:    */     {
/* 254:356 */       Preconditions.checkArgument(spec.concurrencyLevel == null, "concurrency level was already set to ", new Object[] { spec.concurrencyLevel });
/* 255:    */       
/* 256:358 */       spec.concurrencyLevel = Integer.valueOf(value);
/* 257:    */     }
/* 258:    */   }
/* 259:    */   
/* 260:    */   static class KeyStrengthParser
/* 261:    */     implements CacheBuilderSpec.ValueParser
/* 262:    */   {
/* 263:    */     private final LocalCache.Strength strength;
/* 264:    */     
/* 265:    */     public KeyStrengthParser(LocalCache.Strength strength)
/* 266:    */     {
/* 267:367 */       this.strength = strength;
/* 268:    */     }
/* 269:    */     
/* 270:    */     public void parse(CacheBuilderSpec spec, String key, @Nullable String value)
/* 271:    */     {
/* 272:372 */       Preconditions.checkArgument(value == null, "key %s does not take values", new Object[] { key });
/* 273:373 */       Preconditions.checkArgument(spec.keyStrength == null, "%s was already set to %s", new Object[] { key, spec.keyStrength });
/* 274:374 */       spec.keyStrength = this.strength;
/* 275:    */     }
/* 276:    */   }
/* 277:    */   
/* 278:    */   static class ValueStrengthParser
/* 279:    */     implements CacheBuilderSpec.ValueParser
/* 280:    */   {
/* 281:    */     private final LocalCache.Strength strength;
/* 282:    */     
/* 283:    */     public ValueStrengthParser(LocalCache.Strength strength)
/* 284:    */     {
/* 285:383 */       this.strength = strength;
/* 286:    */     }
/* 287:    */     
/* 288:    */     public void parse(CacheBuilderSpec spec, String key, @Nullable String value)
/* 289:    */     {
/* 290:388 */       Preconditions.checkArgument(value == null, "key %s does not take values", new Object[] { key });
/* 291:389 */       Preconditions.checkArgument(spec.valueStrength == null, "%s was already set to %s", new Object[] { key, spec.valueStrength });
/* 292:    */       
/* 293:    */ 
/* 294:392 */       spec.valueStrength = this.strength;
/* 295:    */     }
/* 296:    */   }
/* 297:    */   
/* 298:    */   static class RecordStatsParser
/* 299:    */     implements CacheBuilderSpec.ValueParser
/* 300:    */   {
/* 301:    */     public void parse(CacheBuilderSpec spec, String key, @Nullable String value)
/* 302:    */     {
/* 303:401 */       Preconditions.checkArgument(value == null, "recordStats does not take values");
/* 304:402 */       Preconditions.checkArgument(spec.recordStats == null, "recordStats already set");
/* 305:403 */       spec.recordStats = Boolean.valueOf(true);
/* 306:    */     }
/* 307:    */   }
/* 308:    */   
/* 309:    */   static abstract class DurationParser
/* 310:    */     implements CacheBuilderSpec.ValueParser
/* 311:    */   {
/* 312:    */     protected abstract void parseDuration(CacheBuilderSpec paramCacheBuilderSpec, long paramLong, TimeUnit paramTimeUnit);
/* 313:    */     
/* 314:    */     public void parse(CacheBuilderSpec spec, String key, String value)
/* 315:    */     {
/* 316:416 */       Preconditions.checkArgument((value != null) && (!value.isEmpty()), "value of key %s omitted", new Object[] { key });
/* 317:    */       try
/* 318:    */       {
/* 319:418 */         char lastChar = value.charAt(value.length() - 1);
/* 320:    */         TimeUnit timeUnit;
/* 321:420 */         switch (lastChar)
/* 322:    */         {
/* 323:    */         case 'd': 
/* 324:422 */           timeUnit = TimeUnit.DAYS;
/* 325:423 */           break;
/* 326:    */         case 'h': 
/* 327:425 */           timeUnit = TimeUnit.HOURS;
/* 328:426 */           break;
/* 329:    */         case 'm': 
/* 330:428 */           timeUnit = TimeUnit.MINUTES;
/* 331:429 */           break;
/* 332:    */         case 's': 
/* 333:431 */           timeUnit = TimeUnit.SECONDS;
/* 334:432 */           break;
/* 335:    */         default: 
/* 336:434 */           throw new IllegalArgumentException(CacheBuilderSpec.format("key %s invalid format.  was %s, must end with one of [dDhHmMsS]", new Object[] { key, value }));
/* 337:    */         }
/* 338:439 */         long duration = Long.parseLong(value.substring(0, value.length() - 1));
/* 339:440 */         parseDuration(spec, duration, timeUnit);
/* 340:    */       }
/* 341:    */       catch (NumberFormatException e)
/* 342:    */       {
/* 343:442 */         throw new IllegalArgumentException(CacheBuilderSpec.format("key %s value set to %s, must be integer", new Object[] { key, value }));
/* 344:    */       }
/* 345:    */     }
/* 346:    */   }
/* 347:    */   
/* 348:    */   static class AccessDurationParser
/* 349:    */     extends CacheBuilderSpec.DurationParser
/* 350:    */   {
/* 351:    */     protected void parseDuration(CacheBuilderSpec spec, long duration, TimeUnit unit)
/* 352:    */     {
/* 353:451 */       Preconditions.checkArgument(spec.accessExpirationTimeUnit == null, "expireAfterAccess already set");
/* 354:452 */       spec.accessExpirationDuration = duration;
/* 355:453 */       spec.accessExpirationTimeUnit = unit;
/* 356:    */     }
/* 357:    */   }
/* 358:    */   
/* 359:    */   static class WriteDurationParser
/* 360:    */     extends CacheBuilderSpec.DurationParser
/* 361:    */   {
/* 362:    */     protected void parseDuration(CacheBuilderSpec spec, long duration, TimeUnit unit)
/* 363:    */     {
/* 364:460 */       Preconditions.checkArgument(spec.writeExpirationTimeUnit == null, "expireAfterWrite already set");
/* 365:461 */       spec.writeExpirationDuration = duration;
/* 366:462 */       spec.writeExpirationTimeUnit = unit;
/* 367:    */     }
/* 368:    */   }
/* 369:    */   
/* 370:    */   static class RefreshDurationParser
/* 371:    */     extends CacheBuilderSpec.DurationParser
/* 372:    */   {
/* 373:    */     protected void parseDuration(CacheBuilderSpec spec, long duration, TimeUnit unit)
/* 374:    */     {
/* 375:469 */       Preconditions.checkArgument(spec.refreshTimeUnit == null, "refreshAfterWrite already set");
/* 376:470 */       spec.refreshDuration = duration;
/* 377:471 */       spec.refreshTimeUnit = unit;
/* 378:    */     }
/* 379:    */   }
/* 380:    */   
/* 381:    */   private static String format(String format, Object... args)
/* 382:    */   {
/* 383:476 */     return String.format(Locale.ROOT, format, args);
/* 384:    */   }
/* 385:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.CacheBuilderSpec
 * JD-Core Version:    0.7.0.1
 */