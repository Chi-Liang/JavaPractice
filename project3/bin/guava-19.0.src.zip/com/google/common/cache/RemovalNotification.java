/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @GwtCompatible
/*  10:    */ public final class RemovalNotification<K, V>
/*  11:    */   implements Map.Entry<K, V>
/*  12:    */ {
/*  13:    */   @Nullable
/*  14:    */   private final K key;
/*  15:    */   @Nullable
/*  16:    */   private final V value;
/*  17:    */   private final RemovalCause cause;
/*  18:    */   private static final long serialVersionUID = 0L;
/*  19:    */   
/*  20:    */   public static <K, V> RemovalNotification<K, V> create(@Nullable K key, @Nullable V value, RemovalCause cause)
/*  21:    */   {
/*  22: 54 */     return new RemovalNotification(key, value, cause);
/*  23:    */   }
/*  24:    */   
/*  25:    */   private RemovalNotification(@Nullable K key, @Nullable V value, RemovalCause cause)
/*  26:    */   {
/*  27: 58 */     this.key = key;
/*  28: 59 */     this.value = value;
/*  29: 60 */     this.cause = ((RemovalCause)Preconditions.checkNotNull(cause));
/*  30:    */   }
/*  31:    */   
/*  32:    */   public RemovalCause getCause()
/*  33:    */   {
/*  34: 67 */     return this.cause;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean wasEvicted()
/*  38:    */   {
/*  39: 75 */     return this.cause.wasEvicted();
/*  40:    */   }
/*  41:    */   
/*  42:    */   @Nullable
/*  43:    */   public K getKey()
/*  44:    */   {
/*  45: 79 */     return this.key;
/*  46:    */   }
/*  47:    */   
/*  48:    */   @Nullable
/*  49:    */   public V getValue()
/*  50:    */   {
/*  51: 83 */     return this.value;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public final V setValue(V value)
/*  55:    */   {
/*  56: 87 */     throw new UnsupportedOperationException();
/*  57:    */   }
/*  58:    */   
/*  59:    */   public boolean equals(@Nullable Object object)
/*  60:    */   {
/*  61: 91 */     if ((object instanceof Map.Entry))
/*  62:    */     {
/*  63: 92 */       Map.Entry<?, ?> that = (Map.Entry)object;
/*  64: 93 */       return (Objects.equal(getKey(), that.getKey())) && (Objects.equal(getValue(), that.getValue()));
/*  65:    */     }
/*  66: 96 */     return false;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public int hashCode()
/*  70:    */   {
/*  71:100 */     K k = getKey();
/*  72:101 */     V v = getValue();
/*  73:102 */     return (k == null ? 0 : k.hashCode()) ^ (v == null ? 0 : v.hashCode());
/*  74:    */   }
/*  75:    */   
/*  76:    */   public String toString()
/*  77:    */   {
/*  78:109 */     return getKey() + "=" + getValue();
/*  79:    */   }
/*  80:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.RemovalNotification
 * JD-Core Version:    0.7.0.1
 */