/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.MoreObjects;
/*   5:    */ import com.google.common.base.MoreObjects.ToStringHelper;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ public final class CacheStats
/*  12:    */ {
/*  13:    */   private final long hitCount;
/*  14:    */   private final long missCount;
/*  15:    */   private final long loadSuccessCount;
/*  16:    */   private final long loadExceptionCount;
/*  17:    */   private final long totalLoadTime;
/*  18:    */   private final long evictionCount;
/*  19:    */   
/*  20:    */   public CacheStats(long hitCount, long missCount, long loadSuccessCount, long loadExceptionCount, long totalLoadTime, long evictionCount)
/*  21:    */   {
/*  22: 77 */     Preconditions.checkArgument(hitCount >= 0L);
/*  23: 78 */     Preconditions.checkArgument(missCount >= 0L);
/*  24: 79 */     Preconditions.checkArgument(loadSuccessCount >= 0L);
/*  25: 80 */     Preconditions.checkArgument(loadExceptionCount >= 0L);
/*  26: 81 */     Preconditions.checkArgument(totalLoadTime >= 0L);
/*  27: 82 */     Preconditions.checkArgument(evictionCount >= 0L);
/*  28:    */     
/*  29: 84 */     this.hitCount = hitCount;
/*  30: 85 */     this.missCount = missCount;
/*  31: 86 */     this.loadSuccessCount = loadSuccessCount;
/*  32: 87 */     this.loadExceptionCount = loadExceptionCount;
/*  33: 88 */     this.totalLoadTime = totalLoadTime;
/*  34: 89 */     this.evictionCount = evictionCount;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public long requestCount()
/*  38:    */   {
/*  39: 97 */     return this.hitCount + this.missCount;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public long hitCount()
/*  43:    */   {
/*  44:104 */     return this.hitCount;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public double hitRate()
/*  48:    */   {
/*  49:113 */     long requestCount = requestCount();
/*  50:114 */     return requestCount == 0L ? 1.0D : this.hitCount / requestCount;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public long missCount()
/*  54:    */   {
/*  55:124 */     return this.missCount;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public double missRate()
/*  59:    */   {
/*  60:137 */     long requestCount = requestCount();
/*  61:138 */     return requestCount == 0L ? 0.0D : this.missCount / requestCount;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public long loadCount()
/*  65:    */   {
/*  66:147 */     return this.loadSuccessCount + this.loadExceptionCount;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public long loadSuccessCount()
/*  70:    */   {
/*  71:158 */     return this.loadSuccessCount;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public long loadExceptionCount()
/*  75:    */   {
/*  76:169 */     return this.loadExceptionCount;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public double loadExceptionRate()
/*  80:    */   {
/*  81:178 */     long totalLoadCount = this.loadSuccessCount + this.loadExceptionCount;
/*  82:179 */     return totalLoadCount == 0L ? 0.0D : this.loadExceptionCount / totalLoadCount;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public long totalLoadTime()
/*  86:    */   {
/*  87:190 */     return this.totalLoadTime;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public double averageLoadPenalty()
/*  91:    */   {
/*  92:198 */     long totalLoadCount = this.loadSuccessCount + this.loadExceptionCount;
/*  93:199 */     return totalLoadCount == 0L ? 0.0D : this.totalLoadTime / totalLoadCount;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public long evictionCount()
/*  97:    */   {
/*  98:209 */     return this.evictionCount;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public CacheStats minus(CacheStats other)
/* 102:    */   {
/* 103:218 */     return new CacheStats(Math.max(0L, this.hitCount - other.hitCount), Math.max(0L, this.missCount - other.missCount), Math.max(0L, this.loadSuccessCount - other.loadSuccessCount), Math.max(0L, this.loadExceptionCount - other.loadExceptionCount), Math.max(0L, this.totalLoadTime - other.totalLoadTime), Math.max(0L, this.evictionCount - other.evictionCount));
/* 104:    */   }
/* 105:    */   
/* 106:    */   public CacheStats plus(CacheStats other)
/* 107:    */   {
/* 108:234 */     return new CacheStats(this.hitCount + other.hitCount, this.missCount + other.missCount, this.loadSuccessCount + other.loadSuccessCount, this.loadExceptionCount + other.loadExceptionCount, this.totalLoadTime + other.totalLoadTime, this.evictionCount + other.evictionCount);
/* 109:    */   }
/* 110:    */   
/* 111:    */   public int hashCode()
/* 112:    */   {
/* 113:245 */     return Objects.hashCode(new Object[] { Long.valueOf(this.hitCount), Long.valueOf(this.missCount), Long.valueOf(this.loadSuccessCount), Long.valueOf(this.loadExceptionCount), Long.valueOf(this.totalLoadTime), Long.valueOf(this.evictionCount) });
/* 114:    */   }
/* 115:    */   
/* 116:    */   public boolean equals(@Nullable Object object)
/* 117:    */   {
/* 118:251 */     if ((object instanceof CacheStats))
/* 119:    */     {
/* 120:252 */       CacheStats other = (CacheStats)object;
/* 121:253 */       return (this.hitCount == other.hitCount) && (this.missCount == other.missCount) && (this.loadSuccessCount == other.loadSuccessCount) && (this.loadExceptionCount == other.loadExceptionCount) && (this.totalLoadTime == other.totalLoadTime) && (this.evictionCount == other.evictionCount);
/* 122:    */     }
/* 123:260 */     return false;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public String toString()
/* 127:    */   {
/* 128:265 */     return MoreObjects.toStringHelper(this).add("hitCount", this.hitCount).add("missCount", this.missCount).add("loadSuccessCount", this.loadSuccessCount).add("loadExceptionCount", this.loadExceptionCount).add("totalLoadTime", this.totalLoadTime).add("evictionCount", this.evictionCount).toString();
/* 129:    */   }
/* 130:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.CacheStats
 * JD-Core Version:    0.7.0.1
 */