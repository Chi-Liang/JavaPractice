/*    1:     */ package com.google.common.cache;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.GwtCompatible;
/*    4:     */ import com.google.common.annotations.GwtIncompatible;
/*    5:     */ import com.google.common.annotations.VisibleForTesting;
/*    6:     */ import com.google.common.base.Equivalence;
/*    7:     */ import com.google.common.base.Function;
/*    8:     */ import com.google.common.base.Preconditions;
/*    9:     */ import com.google.common.base.Stopwatch;
/*   10:     */ import com.google.common.base.Supplier;
/*   11:     */ import com.google.common.base.Ticker;
/*   12:     */ import com.google.common.collect.AbstractSequentialIterator;
/*   13:     */ import com.google.common.collect.ImmutableMap;
/*   14:     */ import com.google.common.collect.ImmutableSet;
/*   15:     */ import com.google.common.collect.Iterators;
/*   16:     */ import com.google.common.collect.Maps;
/*   17:     */ import com.google.common.collect.Sets;
/*   18:     */ import com.google.common.primitives.Ints;
/*   19:     */ import com.google.common.util.concurrent.ExecutionError;
/*   20:     */ import com.google.common.util.concurrent.Futures;
/*   21:     */ import com.google.common.util.concurrent.ListenableFuture;
/*   22:     */ import com.google.common.util.concurrent.MoreExecutors;
/*   23:     */ import com.google.common.util.concurrent.SettableFuture;
/*   24:     */ import com.google.common.util.concurrent.UncheckedExecutionException;
/*   25:     */ import com.google.common.util.concurrent.Uninterruptibles;
/*   26:     */ import com.google.j2objc.annotations.Weak;
/*   27:     */ import java.io.IOException;
/*   28:     */ import java.io.ObjectInputStream;
/*   29:     */ import java.io.Serializable;
/*   30:     */ import java.lang.ref.Reference;
/*   31:     */ import java.lang.ref.ReferenceQueue;
/*   32:     */ import java.lang.ref.SoftReference;
/*   33:     */ import java.lang.ref.WeakReference;
/*   34:     */ import java.util.AbstractCollection;
/*   35:     */ import java.util.AbstractMap;
/*   36:     */ import java.util.AbstractQueue;
/*   37:     */ import java.util.AbstractSet;
/*   38:     */ import java.util.ArrayList;
/*   39:     */ import java.util.Collection;
/*   40:     */ import java.util.Iterator;
/*   41:     */ import java.util.Map;
/*   42:     */ import java.util.Map.Entry;
/*   43:     */ import java.util.NoSuchElementException;
/*   44:     */ import java.util.Queue;
/*   45:     */ import java.util.Set;
/*   46:     */ import java.util.concurrent.Callable;
/*   47:     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*   48:     */ import java.util.concurrent.ConcurrentMap;
/*   49:     */ import java.util.concurrent.ExecutionException;
/*   50:     */ import java.util.concurrent.TimeUnit;
/*   51:     */ import java.util.concurrent.atomic.AtomicInteger;
/*   52:     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*   53:     */ import java.util.concurrent.locks.ReentrantLock;
/*   54:     */ import java.util.logging.Level;
/*   55:     */ import java.util.logging.Logger;
/*   56:     */ import javax.annotation.Nullable;
/*   57:     */ import javax.annotation.concurrent.GuardedBy;
/*   58:     */ 
/*   59:     */ @GwtCompatible(emulated=true)
/*   60:     */ class LocalCache<K, V>
/*   61:     */   extends AbstractMap<K, V>
/*   62:     */   implements ConcurrentMap<K, V>
/*   63:     */ {
/*   64:     */   static final int MAXIMUM_CAPACITY = 1073741824;
/*   65:     */   static final int MAX_SEGMENTS = 65536;
/*   66:     */   static final int CONTAINS_VALUE_RETRIES = 3;
/*   67:     */   static final int DRAIN_THRESHOLD = 63;
/*   68:     */   static final int DRAIN_MAX = 16;
/*   69: 161 */   static final Logger logger = Logger.getLogger(LocalCache.class.getName());
/*   70:     */   final int segmentMask;
/*   71:     */   final int segmentShift;
/*   72:     */   final Segment<K, V>[] segments;
/*   73:     */   final int concurrencyLevel;
/*   74:     */   final Equivalence<Object> keyEquivalence;
/*   75:     */   final Equivalence<Object> valueEquivalence;
/*   76:     */   final Strength keyStrength;
/*   77:     */   final Strength valueStrength;
/*   78:     */   final long maxWeight;
/*   79:     */   final Weigher<K, V> weigher;
/*   80:     */   final long expireAfterAccessNanos;
/*   81:     */   final long expireAfterWriteNanos;
/*   82:     */   final long refreshNanos;
/*   83:     */   final Queue<RemovalNotification<K, V>> removalNotificationQueue;
/*   84:     */   final RemovalListener<K, V> removalListener;
/*   85:     */   final Ticker ticker;
/*   86:     */   final EntryFactory entryFactory;
/*   87:     */   final AbstractCache.StatsCounter globalStatsCounter;
/*   88:     */   @Nullable
/*   89:     */   final CacheLoader<? super K, V> defaultLoader;
/*   90:     */   
/*   91:     */   LocalCache(CacheBuilder<? super K, ? super V> builder, @Nullable CacheLoader<? super K, V> loader)
/*   92:     */   {
/*   93: 241 */     this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
/*   94:     */     
/*   95: 243 */     this.keyStrength = builder.getKeyStrength();
/*   96: 244 */     this.valueStrength = builder.getValueStrength();
/*   97:     */     
/*   98: 246 */     this.keyEquivalence = builder.getKeyEquivalence();
/*   99: 247 */     this.valueEquivalence = builder.getValueEquivalence();
/*  100:     */     
/*  101: 249 */     this.maxWeight = builder.getMaximumWeight();
/*  102: 250 */     this.weigher = builder.getWeigher();
/*  103: 251 */     this.expireAfterAccessNanos = builder.getExpireAfterAccessNanos();
/*  104: 252 */     this.expireAfterWriteNanos = builder.getExpireAfterWriteNanos();
/*  105: 253 */     this.refreshNanos = builder.getRefreshNanos();
/*  106:     */     
/*  107: 255 */     this.removalListener = builder.getRemovalListener();
/*  108: 256 */     this.removalNotificationQueue = (this.removalListener == CacheBuilder.NullListener.INSTANCE ? discardingQueue() : new ConcurrentLinkedQueue());
/*  109:     */     
/*  110:     */ 
/*  111:     */ 
/*  112: 260 */     this.ticker = builder.getTicker(recordsTime());
/*  113: 261 */     this.entryFactory = EntryFactory.getFactory(this.keyStrength, usesAccessEntries(), usesWriteEntries());
/*  114: 262 */     this.globalStatsCounter = ((AbstractCache.StatsCounter)builder.getStatsCounterSupplier().get());
/*  115: 263 */     this.defaultLoader = loader;
/*  116:     */     
/*  117: 265 */     int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
/*  118: 266 */     if ((evictsBySize()) && (!customWeigher())) {
/*  119: 267 */       initialCapacity = Math.min(initialCapacity, (int)this.maxWeight);
/*  120:     */     }
/*  121: 275 */     int segmentShift = 0;
/*  122: 276 */     int segmentCount = 1;
/*  123: 278 */     while ((segmentCount < this.concurrencyLevel) && ((!evictsBySize()) || (segmentCount * 20 <= this.maxWeight)))
/*  124:     */     {
/*  125: 279 */       segmentShift++;
/*  126: 280 */       segmentCount <<= 1;
/*  127:     */     }
/*  128: 282 */     this.segmentShift = (32 - segmentShift);
/*  129: 283 */     this.segmentMask = (segmentCount - 1);
/*  130:     */     
/*  131: 285 */     this.segments = newSegmentArray(segmentCount);
/*  132:     */     
/*  133: 287 */     int segmentCapacity = initialCapacity / segmentCount;
/*  134: 288 */     if (segmentCapacity * segmentCount < initialCapacity) {
/*  135: 289 */       segmentCapacity++;
/*  136:     */     }
/*  137: 292 */     int segmentSize = 1;
/*  138: 293 */     while (segmentSize < segmentCapacity) {
/*  139: 294 */       segmentSize <<= 1;
/*  140:     */     }
/*  141: 297 */     if (evictsBySize())
/*  142:     */     {
/*  143: 299 */       long maxSegmentWeight = this.maxWeight / segmentCount + 1L;
/*  144: 300 */       long remainder = this.maxWeight % segmentCount;
/*  145: 301 */       for (int i = 0; i < this.segments.length; i++)
/*  146:     */       {
/*  147: 302 */         if (i == remainder) {
/*  148: 303 */           maxSegmentWeight -= 1L;
/*  149:     */         }
/*  150: 305 */         this.segments[i] = createSegment(segmentSize, maxSegmentWeight, (AbstractCache.StatsCounter)builder.getStatsCounterSupplier().get());
/*  151:     */       }
/*  152:     */     }
/*  153:     */     else
/*  154:     */     {
/*  155: 309 */       for (int i = 0; i < this.segments.length; i++) {
/*  156: 310 */         this.segments[i] = createSegment(segmentSize, -1L, (AbstractCache.StatsCounter)builder.getStatsCounterSupplier().get());
/*  157:     */       }
/*  158:     */     }
/*  159:     */   }
/*  160:     */   
/*  161:     */   boolean evictsBySize()
/*  162:     */   {
/*  163: 317 */     return this.maxWeight >= 0L;
/*  164:     */   }
/*  165:     */   
/*  166:     */   boolean customWeigher()
/*  167:     */   {
/*  168: 321 */     return this.weigher != CacheBuilder.OneWeigher.INSTANCE;
/*  169:     */   }
/*  170:     */   
/*  171:     */   boolean expires()
/*  172:     */   {
/*  173: 325 */     return (expiresAfterWrite()) || (expiresAfterAccess());
/*  174:     */   }
/*  175:     */   
/*  176:     */   boolean expiresAfterWrite()
/*  177:     */   {
/*  178: 329 */     return this.expireAfterWriteNanos > 0L;
/*  179:     */   }
/*  180:     */   
/*  181:     */   boolean expiresAfterAccess()
/*  182:     */   {
/*  183: 333 */     return this.expireAfterAccessNanos > 0L;
/*  184:     */   }
/*  185:     */   
/*  186:     */   boolean refreshes()
/*  187:     */   {
/*  188: 337 */     return this.refreshNanos > 0L;
/*  189:     */   }
/*  190:     */   
/*  191:     */   boolean usesAccessQueue()
/*  192:     */   {
/*  193: 341 */     return (expiresAfterAccess()) || (evictsBySize());
/*  194:     */   }
/*  195:     */   
/*  196:     */   boolean usesWriteQueue()
/*  197:     */   {
/*  198: 345 */     return expiresAfterWrite();
/*  199:     */   }
/*  200:     */   
/*  201:     */   boolean recordsWrite()
/*  202:     */   {
/*  203: 349 */     return (expiresAfterWrite()) || (refreshes());
/*  204:     */   }
/*  205:     */   
/*  206:     */   boolean recordsAccess()
/*  207:     */   {
/*  208: 353 */     return expiresAfterAccess();
/*  209:     */   }
/*  210:     */   
/*  211:     */   boolean recordsTime()
/*  212:     */   {
/*  213: 357 */     return (recordsWrite()) || (recordsAccess());
/*  214:     */   }
/*  215:     */   
/*  216:     */   boolean usesWriteEntries()
/*  217:     */   {
/*  218: 361 */     return (usesWriteQueue()) || (recordsWrite());
/*  219:     */   }
/*  220:     */   
/*  221:     */   boolean usesAccessEntries()
/*  222:     */   {
/*  223: 365 */     return (usesAccessQueue()) || (recordsAccess());
/*  224:     */   }
/*  225:     */   
/*  226:     */   boolean usesKeyReferences()
/*  227:     */   {
/*  228: 369 */     return this.keyStrength != Strength.STRONG;
/*  229:     */   }
/*  230:     */   
/*  231:     */   boolean usesValueReferences()
/*  232:     */   {
/*  233: 373 */     return this.valueStrength != Strength.STRONG;
/*  234:     */   }
/*  235:     */   
/*  236:     */   static abstract enum Strength
/*  237:     */   {
/*  238: 382 */     STRONG,  SOFT,  WEAK;
/*  239:     */     
/*  240:     */     private Strength() {}
/*  241:     */     
/*  242:     */     abstract <K, V> LocalCache.ValueReference<K, V> referenceValue(LocalCache.Segment<K, V> paramSegment, LocalCache.ReferenceEntry<K, V> paramReferenceEntry, V paramV, int paramInt);
/*  243:     */     
/*  244:     */     abstract Equivalence<Object> defaultEquivalence();
/*  245:     */   }
/*  246:     */   
/*  247:     */   static abstract enum EntryFactory
/*  248:     */   {
/*  249: 447 */     STRONG,  STRONG_ACCESS,  STRONG_WRITE,  STRONG_ACCESS_WRITE,  WEAK,  WEAK_ACCESS,  WEAK_WRITE,  WEAK_ACCESS_WRITE;
/*  250:     */     
/*  251:     */     static final int ACCESS_MASK = 1;
/*  252:     */     static final int WRITE_MASK = 2;
/*  253:     */     static final int WEAK_MASK = 4;
/*  254: 565 */     static final EntryFactory[] factories = { STRONG, STRONG_ACCESS, STRONG_WRITE, STRONG_ACCESS_WRITE, WEAK, WEAK_ACCESS, WEAK_WRITE, WEAK_ACCESS_WRITE };
/*  255:     */     
/*  256:     */     private EntryFactory() {}
/*  257:     */     
/*  258:     */     static EntryFactory getFactory(LocalCache.Strength keyStrength, boolean usesAccessQueue, boolean usesWriteQueue)
/*  259:     */     {
/*  260: 572 */       int flags = (keyStrength == LocalCache.Strength.WEAK ? 4 : 0) | (usesAccessQueue ? 1 : 0) | (usesWriteQueue ? 2 : 0);
/*  261:     */       
/*  262:     */ 
/*  263: 575 */       return factories[flags];
/*  264:     */     }
/*  265:     */     
/*  266:     */     abstract <K, V> LocalCache.ReferenceEntry<K, V> newEntry(LocalCache.Segment<K, V> paramSegment, K paramK, int paramInt, @Nullable LocalCache.ReferenceEntry<K, V> paramReferenceEntry);
/*  267:     */     
/*  268:     */     <K, V> LocalCache.ReferenceEntry<K, V> copyEntry(LocalCache.Segment<K, V> segment, LocalCache.ReferenceEntry<K, V> original, LocalCache.ReferenceEntry<K, V> newNext)
/*  269:     */     {
/*  270: 598 */       return newEntry(segment, original.getKey(), original.getHash(), newNext);
/*  271:     */     }
/*  272:     */     
/*  273:     */     <K, V> void copyAccessEntry(LocalCache.ReferenceEntry<K, V> original, LocalCache.ReferenceEntry<K, V> newEntry)
/*  274:     */     {
/*  275: 605 */       newEntry.setAccessTime(original.getAccessTime());
/*  276:     */       
/*  277: 607 */       LocalCache.connectAccessOrder(original.getPreviousInAccessQueue(), newEntry);
/*  278: 608 */       LocalCache.connectAccessOrder(newEntry, original.getNextInAccessQueue());
/*  279:     */       
/*  280: 610 */       LocalCache.nullifyAccessOrder(original);
/*  281:     */     }
/*  282:     */     
/*  283:     */     <K, V> void copyWriteEntry(LocalCache.ReferenceEntry<K, V> original, LocalCache.ReferenceEntry<K, V> newEntry)
/*  284:     */     {
/*  285: 617 */       newEntry.setWriteTime(original.getWriteTime());
/*  286:     */       
/*  287: 619 */       LocalCache.connectWriteOrder(original.getPreviousInWriteQueue(), newEntry);
/*  288: 620 */       LocalCache.connectWriteOrder(newEntry, original.getNextInWriteQueue());
/*  289:     */       
/*  290: 622 */       LocalCache.nullifyWriteOrder(original);
/*  291:     */     }
/*  292:     */   }
/*  293:     */   
/*  294: 691 */   static final ValueReference<Object, Object> UNSET = new ValueReference()
/*  295:     */   {
/*  296:     */     public Object get()
/*  297:     */     {
/*  298: 694 */       return null;
/*  299:     */     }
/*  300:     */     
/*  301:     */     public int getWeight()
/*  302:     */     {
/*  303: 699 */       return 0;
/*  304:     */     }
/*  305:     */     
/*  306:     */     public LocalCache.ReferenceEntry<Object, Object> getEntry()
/*  307:     */     {
/*  308: 704 */       return null;
/*  309:     */     }
/*  310:     */     
/*  311:     */     public LocalCache.ValueReference<Object, Object> copyFor(ReferenceQueue<Object> queue, @Nullable Object value, LocalCache.ReferenceEntry<Object, Object> entry)
/*  312:     */     {
/*  313: 710 */       return this;
/*  314:     */     }
/*  315:     */     
/*  316:     */     public boolean isLoading()
/*  317:     */     {
/*  318: 715 */       return false;
/*  319:     */     }
/*  320:     */     
/*  321:     */     public boolean isActive()
/*  322:     */     {
/*  323: 720 */       return false;
/*  324:     */     }
/*  325:     */     
/*  326:     */     public Object waitForValue()
/*  327:     */     {
/*  328: 725 */       return null;
/*  329:     */     }
/*  330:     */     
/*  331:     */     public void notifyNewValue(Object newValue) {}
/*  332:     */   };
/*  333:     */   
/*  334:     */   static <K, V> ValueReference<K, V> unset()
/*  335:     */   {
/*  336: 737 */     return UNSET;
/*  337:     */   }
/*  338:     */   
/*  339:     */   static abstract interface ValueReference<K, V>
/*  340:     */   {
/*  341:     */     @Nullable
/*  342:     */     public abstract V get();
/*  343:     */     
/*  344:     */     public abstract V waitForValue()
/*  345:     */       throws ExecutionException;
/*  346:     */     
/*  347:     */     public abstract int getWeight();
/*  348:     */     
/*  349:     */     @Nullable
/*  350:     */     public abstract LocalCache.ReferenceEntry<K, V> getEntry();
/*  351:     */     
/*  352:     */     public abstract ValueReference<K, V> copyFor(ReferenceQueue<V> paramReferenceQueue, @Nullable V paramV, LocalCache.ReferenceEntry<K, V> paramReferenceEntry);
/*  353:     */     
/*  354:     */     public abstract void notifyNewValue(@Nullable V paramV);
/*  355:     */     
/*  356:     */     public abstract boolean isLoading();
/*  357:     */     
/*  358:     */     public abstract boolean isActive();
/*  359:     */   }
/*  360:     */   
/*  361:     */   static abstract interface ReferenceEntry<K, V>
/*  362:     */   {
/*  363:     */     public abstract LocalCache.ValueReference<K, V> getValueReference();
/*  364:     */     
/*  365:     */     public abstract void setValueReference(LocalCache.ValueReference<K, V> paramValueReference);
/*  366:     */     
/*  367:     */     @Nullable
/*  368:     */     public abstract ReferenceEntry<K, V> getNext();
/*  369:     */     
/*  370:     */     public abstract int getHash();
/*  371:     */     
/*  372:     */     @Nullable
/*  373:     */     public abstract K getKey();
/*  374:     */     
/*  375:     */     public abstract long getAccessTime();
/*  376:     */     
/*  377:     */     public abstract void setAccessTime(long paramLong);
/*  378:     */     
/*  379:     */     public abstract ReferenceEntry<K, V> getNextInAccessQueue();
/*  380:     */     
/*  381:     */     public abstract void setNextInAccessQueue(ReferenceEntry<K, V> paramReferenceEntry);
/*  382:     */     
/*  383:     */     public abstract ReferenceEntry<K, V> getPreviousInAccessQueue();
/*  384:     */     
/*  385:     */     public abstract void setPreviousInAccessQueue(ReferenceEntry<K, V> paramReferenceEntry);
/*  386:     */     
/*  387:     */     public abstract long getWriteTime();
/*  388:     */     
/*  389:     */     public abstract void setWriteTime(long paramLong);
/*  390:     */     
/*  391:     */     public abstract ReferenceEntry<K, V> getNextInWriteQueue();
/*  392:     */     
/*  393:     */     public abstract void setNextInWriteQueue(ReferenceEntry<K, V> paramReferenceEntry);
/*  394:     */     
/*  395:     */     public abstract ReferenceEntry<K, V> getPreviousInWriteQueue();
/*  396:     */     
/*  397:     */     public abstract void setPreviousInWriteQueue(ReferenceEntry<K, V> paramReferenceEntry);
/*  398:     */   }
/*  399:     */   
/*  400:     */   private static enum NullEntry
/*  401:     */     implements LocalCache.ReferenceEntry<Object, Object>
/*  402:     */   {
/*  403: 856 */     INSTANCE;
/*  404:     */     
/*  405:     */     private NullEntry() {}
/*  406:     */     
/*  407:     */     public LocalCache.ValueReference<Object, Object> getValueReference()
/*  408:     */     {
/*  409: 860 */       return null;
/*  410:     */     }
/*  411:     */     
/*  412:     */     public void setValueReference(LocalCache.ValueReference<Object, Object> valueReference) {}
/*  413:     */     
/*  414:     */     public LocalCache.ReferenceEntry<Object, Object> getNext()
/*  415:     */     {
/*  416: 868 */       return null;
/*  417:     */     }
/*  418:     */     
/*  419:     */     public int getHash()
/*  420:     */     {
/*  421: 873 */       return 0;
/*  422:     */     }
/*  423:     */     
/*  424:     */     public Object getKey()
/*  425:     */     {
/*  426: 878 */       return null;
/*  427:     */     }
/*  428:     */     
/*  429:     */     public long getAccessTime()
/*  430:     */     {
/*  431: 883 */       return 0L;
/*  432:     */     }
/*  433:     */     
/*  434:     */     public void setAccessTime(long time) {}
/*  435:     */     
/*  436:     */     public LocalCache.ReferenceEntry<Object, Object> getNextInAccessQueue()
/*  437:     */     {
/*  438: 891 */       return this;
/*  439:     */     }
/*  440:     */     
/*  441:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<Object, Object> next) {}
/*  442:     */     
/*  443:     */     public LocalCache.ReferenceEntry<Object, Object> getPreviousInAccessQueue()
/*  444:     */     {
/*  445: 899 */       return this;
/*  446:     */     }
/*  447:     */     
/*  448:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<Object, Object> previous) {}
/*  449:     */     
/*  450:     */     public long getWriteTime()
/*  451:     */     {
/*  452: 907 */       return 0L;
/*  453:     */     }
/*  454:     */     
/*  455:     */     public void setWriteTime(long time) {}
/*  456:     */     
/*  457:     */     public LocalCache.ReferenceEntry<Object, Object> getNextInWriteQueue()
/*  458:     */     {
/*  459: 915 */       return this;
/*  460:     */     }
/*  461:     */     
/*  462:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<Object, Object> next) {}
/*  463:     */     
/*  464:     */     public LocalCache.ReferenceEntry<Object, Object> getPreviousInWriteQueue()
/*  465:     */     {
/*  466: 923 */       return this;
/*  467:     */     }
/*  468:     */     
/*  469:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<Object, Object> previous) {}
/*  470:     */   }
/*  471:     */   
/*  472:     */   static abstract class AbstractReferenceEntry<K, V>
/*  473:     */     implements LocalCache.ReferenceEntry<K, V>
/*  474:     */   {
/*  475:     */     public LocalCache.ValueReference<K, V> getValueReference()
/*  476:     */     {
/*  477: 933 */       throw new UnsupportedOperationException();
/*  478:     */     }
/*  479:     */     
/*  480:     */     public void setValueReference(LocalCache.ValueReference<K, V> valueReference)
/*  481:     */     {
/*  482: 938 */       throw new UnsupportedOperationException();
/*  483:     */     }
/*  484:     */     
/*  485:     */     public LocalCache.ReferenceEntry<K, V> getNext()
/*  486:     */     {
/*  487: 943 */       throw new UnsupportedOperationException();
/*  488:     */     }
/*  489:     */     
/*  490:     */     public int getHash()
/*  491:     */     {
/*  492: 948 */       throw new UnsupportedOperationException();
/*  493:     */     }
/*  494:     */     
/*  495:     */     public K getKey()
/*  496:     */     {
/*  497: 953 */       throw new UnsupportedOperationException();
/*  498:     */     }
/*  499:     */     
/*  500:     */     public long getAccessTime()
/*  501:     */     {
/*  502: 958 */       throw new UnsupportedOperationException();
/*  503:     */     }
/*  504:     */     
/*  505:     */     public void setAccessTime(long time)
/*  506:     */     {
/*  507: 963 */       throw new UnsupportedOperationException();
/*  508:     */     }
/*  509:     */     
/*  510:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  511:     */     {
/*  512: 968 */       throw new UnsupportedOperationException();
/*  513:     */     }
/*  514:     */     
/*  515:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  516:     */     {
/*  517: 973 */       throw new UnsupportedOperationException();
/*  518:     */     }
/*  519:     */     
/*  520:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  521:     */     {
/*  522: 978 */       throw new UnsupportedOperationException();
/*  523:     */     }
/*  524:     */     
/*  525:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  526:     */     {
/*  527: 983 */       throw new UnsupportedOperationException();
/*  528:     */     }
/*  529:     */     
/*  530:     */     public long getWriteTime()
/*  531:     */     {
/*  532: 988 */       throw new UnsupportedOperationException();
/*  533:     */     }
/*  534:     */     
/*  535:     */     public void setWriteTime(long time)
/*  536:     */     {
/*  537: 993 */       throw new UnsupportedOperationException();
/*  538:     */     }
/*  539:     */     
/*  540:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  541:     */     {
/*  542: 998 */       throw new UnsupportedOperationException();
/*  543:     */     }
/*  544:     */     
/*  545:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  546:     */     {
/*  547:1003 */       throw new UnsupportedOperationException();
/*  548:     */     }
/*  549:     */     
/*  550:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  551:     */     {
/*  552:1008 */       throw new UnsupportedOperationException();
/*  553:     */     }
/*  554:     */     
/*  555:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  556:     */     {
/*  557:1013 */       throw new UnsupportedOperationException();
/*  558:     */     }
/*  559:     */   }
/*  560:     */   
/*  561:     */   static <K, V> ReferenceEntry<K, V> nullEntry()
/*  562:     */   {
/*  563:1019 */     return NullEntry.INSTANCE;
/*  564:     */   }
/*  565:     */   
/*  566:1022 */   static final Queue<? extends Object> DISCARDING_QUEUE = new AbstractQueue()
/*  567:     */   {
/*  568:     */     public boolean offer(Object o)
/*  569:     */     {
/*  570:1025 */       return true;
/*  571:     */     }
/*  572:     */     
/*  573:     */     public Object peek()
/*  574:     */     {
/*  575:1030 */       return null;
/*  576:     */     }
/*  577:     */     
/*  578:     */     public Object poll()
/*  579:     */     {
/*  580:1035 */       return null;
/*  581:     */     }
/*  582:     */     
/*  583:     */     public int size()
/*  584:     */     {
/*  585:1040 */       return 0;
/*  586:     */     }
/*  587:     */     
/*  588:     */     public Iterator<Object> iterator()
/*  589:     */     {
/*  590:1045 */       return ImmutableSet.of().iterator();
/*  591:     */     }
/*  592:     */   };
/*  593:     */   Set<K> keySet;
/*  594:     */   Collection<V> values;
/*  595:     */   Set<Map.Entry<K, V>> entrySet;
/*  596:     */   
/*  597:     */   static <E> Queue<E> discardingQueue()
/*  598:     */   {
/*  599:1054 */     return DISCARDING_QUEUE;
/*  600:     */   }
/*  601:     */   
/*  602:     */   static class StrongEntry<K, V>
/*  603:     */     extends LocalCache.AbstractReferenceEntry<K, V>
/*  604:     */   {
/*  605:     */     final K key;
/*  606:     */     final int hash;
/*  607:     */     final LocalCache.ReferenceEntry<K, V> next;
/*  608:     */     
/*  609:     */     StrongEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  610:     */     {
/*  611:1072 */       this.key = key;
/*  612:1073 */       this.hash = hash;
/*  613:1074 */       this.next = next;
/*  614:     */     }
/*  615:     */     
/*  616:     */     public K getKey()
/*  617:     */     {
/*  618:1079 */       return this.key;
/*  619:     */     }
/*  620:     */     
/*  621:1086 */     volatile LocalCache.ValueReference<K, V> valueReference = LocalCache.unset();
/*  622:     */     
/*  623:     */     public LocalCache.ValueReference<K, V> getValueReference()
/*  624:     */     {
/*  625:1090 */       return this.valueReference;
/*  626:     */     }
/*  627:     */     
/*  628:     */     public void setValueReference(LocalCache.ValueReference<K, V> valueReference)
/*  629:     */     {
/*  630:1095 */       this.valueReference = valueReference;
/*  631:     */     }
/*  632:     */     
/*  633:     */     public int getHash()
/*  634:     */     {
/*  635:1100 */       return this.hash;
/*  636:     */     }
/*  637:     */     
/*  638:     */     public LocalCache.ReferenceEntry<K, V> getNext()
/*  639:     */     {
/*  640:1105 */       return this.next;
/*  641:     */     }
/*  642:     */   }
/*  643:     */   
/*  644:     */   static final class StrongAccessEntry<K, V>
/*  645:     */     extends LocalCache.StrongEntry<K, V>
/*  646:     */   {
/*  647:     */     StrongAccessEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  648:     */     {
/*  649:1111 */       super(hash, next);
/*  650:     */     }
/*  651:     */     
/*  652:1116 */     volatile long accessTime = 9223372036854775807L;
/*  653:     */     
/*  654:     */     public long getAccessTime()
/*  655:     */     {
/*  656:1120 */       return this.accessTime;
/*  657:     */     }
/*  658:     */     
/*  659:     */     public void setAccessTime(long time)
/*  660:     */     {
/*  661:1125 */       this.accessTime = time;
/*  662:     */     }
/*  663:     */     
/*  664:1129 */     LocalCache.ReferenceEntry<K, V> nextAccess = LocalCache.nullEntry();
/*  665:     */     
/*  666:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  667:     */     {
/*  668:1133 */       return this.nextAccess;
/*  669:     */     }
/*  670:     */     
/*  671:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  672:     */     {
/*  673:1138 */       this.nextAccess = next;
/*  674:     */     }
/*  675:     */     
/*  676:1142 */     LocalCache.ReferenceEntry<K, V> previousAccess = LocalCache.nullEntry();
/*  677:     */     
/*  678:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  679:     */     {
/*  680:1146 */       return this.previousAccess;
/*  681:     */     }
/*  682:     */     
/*  683:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  684:     */     {
/*  685:1151 */       this.previousAccess = previous;
/*  686:     */     }
/*  687:     */   }
/*  688:     */   
/*  689:     */   static final class StrongWriteEntry<K, V>
/*  690:     */     extends LocalCache.StrongEntry<K, V>
/*  691:     */   {
/*  692:     */     StrongWriteEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  693:     */     {
/*  694:1157 */       super(hash, next);
/*  695:     */     }
/*  696:     */     
/*  697:1162 */     volatile long writeTime = 9223372036854775807L;
/*  698:     */     
/*  699:     */     public long getWriteTime()
/*  700:     */     {
/*  701:1166 */       return this.writeTime;
/*  702:     */     }
/*  703:     */     
/*  704:     */     public void setWriteTime(long time)
/*  705:     */     {
/*  706:1171 */       this.writeTime = time;
/*  707:     */     }
/*  708:     */     
/*  709:1175 */     LocalCache.ReferenceEntry<K, V> nextWrite = LocalCache.nullEntry();
/*  710:     */     
/*  711:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  712:     */     {
/*  713:1179 */       return this.nextWrite;
/*  714:     */     }
/*  715:     */     
/*  716:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  717:     */     {
/*  718:1184 */       this.nextWrite = next;
/*  719:     */     }
/*  720:     */     
/*  721:1188 */     LocalCache.ReferenceEntry<K, V> previousWrite = LocalCache.nullEntry();
/*  722:     */     
/*  723:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  724:     */     {
/*  725:1192 */       return this.previousWrite;
/*  726:     */     }
/*  727:     */     
/*  728:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  729:     */     {
/*  730:1197 */       this.previousWrite = previous;
/*  731:     */     }
/*  732:     */   }
/*  733:     */   
/*  734:     */   static final class StrongAccessWriteEntry<K, V>
/*  735:     */     extends LocalCache.StrongEntry<K, V>
/*  736:     */   {
/*  737:     */     StrongAccessWriteEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  738:     */     {
/*  739:1203 */       super(hash, next);
/*  740:     */     }
/*  741:     */     
/*  742:1208 */     volatile long accessTime = 9223372036854775807L;
/*  743:     */     
/*  744:     */     public long getAccessTime()
/*  745:     */     {
/*  746:1212 */       return this.accessTime;
/*  747:     */     }
/*  748:     */     
/*  749:     */     public void setAccessTime(long time)
/*  750:     */     {
/*  751:1217 */       this.accessTime = time;
/*  752:     */     }
/*  753:     */     
/*  754:1221 */     LocalCache.ReferenceEntry<K, V> nextAccess = LocalCache.nullEntry();
/*  755:     */     
/*  756:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  757:     */     {
/*  758:1225 */       return this.nextAccess;
/*  759:     */     }
/*  760:     */     
/*  761:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  762:     */     {
/*  763:1230 */       this.nextAccess = next;
/*  764:     */     }
/*  765:     */     
/*  766:1234 */     LocalCache.ReferenceEntry<K, V> previousAccess = LocalCache.nullEntry();
/*  767:     */     
/*  768:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  769:     */     {
/*  770:1238 */       return this.previousAccess;
/*  771:     */     }
/*  772:     */     
/*  773:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  774:     */     {
/*  775:1243 */       this.previousAccess = previous;
/*  776:     */     }
/*  777:     */     
/*  778:1248 */     volatile long writeTime = 9223372036854775807L;
/*  779:     */     
/*  780:     */     public long getWriteTime()
/*  781:     */     {
/*  782:1252 */       return this.writeTime;
/*  783:     */     }
/*  784:     */     
/*  785:     */     public void setWriteTime(long time)
/*  786:     */     {
/*  787:1257 */       this.writeTime = time;
/*  788:     */     }
/*  789:     */     
/*  790:1261 */     LocalCache.ReferenceEntry<K, V> nextWrite = LocalCache.nullEntry();
/*  791:     */     
/*  792:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  793:     */     {
/*  794:1265 */       return this.nextWrite;
/*  795:     */     }
/*  796:     */     
/*  797:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  798:     */     {
/*  799:1270 */       this.nextWrite = next;
/*  800:     */     }
/*  801:     */     
/*  802:1274 */     LocalCache.ReferenceEntry<K, V> previousWrite = LocalCache.nullEntry();
/*  803:     */     
/*  804:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  805:     */     {
/*  806:1278 */       return this.previousWrite;
/*  807:     */     }
/*  808:     */     
/*  809:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  810:     */     {
/*  811:1283 */       this.previousWrite = previous;
/*  812:     */     }
/*  813:     */   }
/*  814:     */   
/*  815:     */   static class WeakEntry<K, V>
/*  816:     */     extends WeakReference<K>
/*  817:     */     implements LocalCache.ReferenceEntry<K, V>
/*  818:     */   {
/*  819:     */     final int hash;
/*  820:     */     final LocalCache.ReferenceEntry<K, V> next;
/*  821:     */     
/*  822:     */     WeakEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  823:     */     {
/*  824:1292 */       super(queue);
/*  825:1293 */       this.hash = hash;
/*  826:1294 */       this.next = next;
/*  827:     */     }
/*  828:     */     
/*  829:     */     public K getKey()
/*  830:     */     {
/*  831:1299 */       return get();
/*  832:     */     }
/*  833:     */     
/*  834:     */     public long getAccessTime()
/*  835:     */     {
/*  836:1311 */       throw new UnsupportedOperationException();
/*  837:     */     }
/*  838:     */     
/*  839:     */     public void setAccessTime(long time)
/*  840:     */     {
/*  841:1316 */       throw new UnsupportedOperationException();
/*  842:     */     }
/*  843:     */     
/*  844:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  845:     */     {
/*  846:1321 */       throw new UnsupportedOperationException();
/*  847:     */     }
/*  848:     */     
/*  849:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  850:     */     {
/*  851:1326 */       throw new UnsupportedOperationException();
/*  852:     */     }
/*  853:     */     
/*  854:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  855:     */     {
/*  856:1331 */       throw new UnsupportedOperationException();
/*  857:     */     }
/*  858:     */     
/*  859:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  860:     */     {
/*  861:1336 */       throw new UnsupportedOperationException();
/*  862:     */     }
/*  863:     */     
/*  864:     */     public long getWriteTime()
/*  865:     */     {
/*  866:1343 */       throw new UnsupportedOperationException();
/*  867:     */     }
/*  868:     */     
/*  869:     */     public void setWriteTime(long time)
/*  870:     */     {
/*  871:1348 */       throw new UnsupportedOperationException();
/*  872:     */     }
/*  873:     */     
/*  874:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  875:     */     {
/*  876:1353 */       throw new UnsupportedOperationException();
/*  877:     */     }
/*  878:     */     
/*  879:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  880:     */     {
/*  881:1358 */       throw new UnsupportedOperationException();
/*  882:     */     }
/*  883:     */     
/*  884:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  885:     */     {
/*  886:1363 */       throw new UnsupportedOperationException();
/*  887:     */     }
/*  888:     */     
/*  889:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  890:     */     {
/*  891:1368 */       throw new UnsupportedOperationException();
/*  892:     */     }
/*  893:     */     
/*  894:1375 */     volatile LocalCache.ValueReference<K, V> valueReference = LocalCache.unset();
/*  895:     */     
/*  896:     */     public LocalCache.ValueReference<K, V> getValueReference()
/*  897:     */     {
/*  898:1379 */       return this.valueReference;
/*  899:     */     }
/*  900:     */     
/*  901:     */     public void setValueReference(LocalCache.ValueReference<K, V> valueReference)
/*  902:     */     {
/*  903:1384 */       this.valueReference = valueReference;
/*  904:     */     }
/*  905:     */     
/*  906:     */     public int getHash()
/*  907:     */     {
/*  908:1389 */       return this.hash;
/*  909:     */     }
/*  910:     */     
/*  911:     */     public LocalCache.ReferenceEntry<K, V> getNext()
/*  912:     */     {
/*  913:1394 */       return this.next;
/*  914:     */     }
/*  915:     */   }
/*  916:     */   
/*  917:     */   static final class WeakAccessEntry<K, V>
/*  918:     */     extends LocalCache.WeakEntry<K, V>
/*  919:     */   {
/*  920:     */     WeakAccessEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  921:     */     {
/*  922:1401 */       super(key, hash, next);
/*  923:     */     }
/*  924:     */     
/*  925:1406 */     volatile long accessTime = 9223372036854775807L;
/*  926:     */     
/*  927:     */     public long getAccessTime()
/*  928:     */     {
/*  929:1410 */       return this.accessTime;
/*  930:     */     }
/*  931:     */     
/*  932:     */     public void setAccessTime(long time)
/*  933:     */     {
/*  934:1415 */       this.accessTime = time;
/*  935:     */     }
/*  936:     */     
/*  937:1419 */     LocalCache.ReferenceEntry<K, V> nextAccess = LocalCache.nullEntry();
/*  938:     */     
/*  939:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/*  940:     */     {
/*  941:1423 */       return this.nextAccess;
/*  942:     */     }
/*  943:     */     
/*  944:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/*  945:     */     {
/*  946:1428 */       this.nextAccess = next;
/*  947:     */     }
/*  948:     */     
/*  949:1432 */     LocalCache.ReferenceEntry<K, V> previousAccess = LocalCache.nullEntry();
/*  950:     */     
/*  951:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/*  952:     */     {
/*  953:1436 */       return this.previousAccess;
/*  954:     */     }
/*  955:     */     
/*  956:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/*  957:     */     {
/*  958:1441 */       this.previousAccess = previous;
/*  959:     */     }
/*  960:     */   }
/*  961:     */   
/*  962:     */   static final class WeakWriteEntry<K, V>
/*  963:     */     extends LocalCache.WeakEntry<K, V>
/*  964:     */   {
/*  965:     */     WeakWriteEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/*  966:     */     {
/*  967:1448 */       super(key, hash, next);
/*  968:     */     }
/*  969:     */     
/*  970:1453 */     volatile long writeTime = 9223372036854775807L;
/*  971:     */     
/*  972:     */     public long getWriteTime()
/*  973:     */     {
/*  974:1457 */       return this.writeTime;
/*  975:     */     }
/*  976:     */     
/*  977:     */     public void setWriteTime(long time)
/*  978:     */     {
/*  979:1462 */       this.writeTime = time;
/*  980:     */     }
/*  981:     */     
/*  982:1466 */     LocalCache.ReferenceEntry<K, V> nextWrite = LocalCache.nullEntry();
/*  983:     */     
/*  984:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/*  985:     */     {
/*  986:1470 */       return this.nextWrite;
/*  987:     */     }
/*  988:     */     
/*  989:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/*  990:     */     {
/*  991:1475 */       this.nextWrite = next;
/*  992:     */     }
/*  993:     */     
/*  994:1479 */     LocalCache.ReferenceEntry<K, V> previousWrite = LocalCache.nullEntry();
/*  995:     */     
/*  996:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/*  997:     */     {
/*  998:1483 */       return this.previousWrite;
/*  999:     */     }
/* 1000:     */     
/* 1001:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 1002:     */     {
/* 1003:1488 */       this.previousWrite = previous;
/* 1004:     */     }
/* 1005:     */   }
/* 1006:     */   
/* 1007:     */   static final class WeakAccessWriteEntry<K, V>
/* 1008:     */     extends LocalCache.WeakEntry<K, V>
/* 1009:     */   {
/* 1010:     */     WeakAccessWriteEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/* 1011:     */     {
/* 1012:1495 */       super(key, hash, next);
/* 1013:     */     }
/* 1014:     */     
/* 1015:1500 */     volatile long accessTime = 9223372036854775807L;
/* 1016:     */     
/* 1017:     */     public long getAccessTime()
/* 1018:     */     {
/* 1019:1504 */       return this.accessTime;
/* 1020:     */     }
/* 1021:     */     
/* 1022:     */     public void setAccessTime(long time)
/* 1023:     */     {
/* 1024:1509 */       this.accessTime = time;
/* 1025:     */     }
/* 1026:     */     
/* 1027:1513 */     LocalCache.ReferenceEntry<K, V> nextAccess = LocalCache.nullEntry();
/* 1028:     */     
/* 1029:     */     public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/* 1030:     */     {
/* 1031:1517 */       return this.nextAccess;
/* 1032:     */     }
/* 1033:     */     
/* 1034:     */     public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/* 1035:     */     {
/* 1036:1522 */       this.nextAccess = next;
/* 1037:     */     }
/* 1038:     */     
/* 1039:1526 */     LocalCache.ReferenceEntry<K, V> previousAccess = LocalCache.nullEntry();
/* 1040:     */     
/* 1041:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/* 1042:     */     {
/* 1043:1530 */       return this.previousAccess;
/* 1044:     */     }
/* 1045:     */     
/* 1046:     */     public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 1047:     */     {
/* 1048:1535 */       this.previousAccess = previous;
/* 1049:     */     }
/* 1050:     */     
/* 1051:1540 */     volatile long writeTime = 9223372036854775807L;
/* 1052:     */     
/* 1053:     */     public long getWriteTime()
/* 1054:     */     {
/* 1055:1544 */       return this.writeTime;
/* 1056:     */     }
/* 1057:     */     
/* 1058:     */     public void setWriteTime(long time)
/* 1059:     */     {
/* 1060:1549 */       this.writeTime = time;
/* 1061:     */     }
/* 1062:     */     
/* 1063:1553 */     LocalCache.ReferenceEntry<K, V> nextWrite = LocalCache.nullEntry();
/* 1064:     */     
/* 1065:     */     public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/* 1066:     */     {
/* 1067:1557 */       return this.nextWrite;
/* 1068:     */     }
/* 1069:     */     
/* 1070:     */     public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/* 1071:     */     {
/* 1072:1562 */       this.nextWrite = next;
/* 1073:     */     }
/* 1074:     */     
/* 1075:1566 */     LocalCache.ReferenceEntry<K, V> previousWrite = LocalCache.nullEntry();
/* 1076:     */     
/* 1077:     */     public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/* 1078:     */     {
/* 1079:1570 */       return this.previousWrite;
/* 1080:     */     }
/* 1081:     */     
/* 1082:     */     public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 1083:     */     {
/* 1084:1575 */       this.previousWrite = previous;
/* 1085:     */     }
/* 1086:     */   }
/* 1087:     */   
/* 1088:     */   static class WeakValueReference<K, V>
/* 1089:     */     extends WeakReference<V>
/* 1090:     */     implements LocalCache.ValueReference<K, V>
/* 1091:     */   {
/* 1092:     */     final LocalCache.ReferenceEntry<K, V> entry;
/* 1093:     */     
/* 1094:     */     WeakValueReference(ReferenceQueue<V> queue, V referent, LocalCache.ReferenceEntry<K, V> entry)
/* 1095:     */     {
/* 1096:1587 */       super(queue);
/* 1097:1588 */       this.entry = entry;
/* 1098:     */     }
/* 1099:     */     
/* 1100:     */     public int getWeight()
/* 1101:     */     {
/* 1102:1593 */       return 1;
/* 1103:     */     }
/* 1104:     */     
/* 1105:     */     public LocalCache.ReferenceEntry<K, V> getEntry()
/* 1106:     */     {
/* 1107:1598 */       return this.entry;
/* 1108:     */     }
/* 1109:     */     
/* 1110:     */     public void notifyNewValue(V newValue) {}
/* 1111:     */     
/* 1112:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1113:     */     {
/* 1114:1607 */       return new WeakValueReference(queue, value, entry);
/* 1115:     */     }
/* 1116:     */     
/* 1117:     */     public boolean isLoading()
/* 1118:     */     {
/* 1119:1612 */       return false;
/* 1120:     */     }
/* 1121:     */     
/* 1122:     */     public boolean isActive()
/* 1123:     */     {
/* 1124:1617 */       return true;
/* 1125:     */     }
/* 1126:     */     
/* 1127:     */     public V waitForValue()
/* 1128:     */     {
/* 1129:1622 */       return get();
/* 1130:     */     }
/* 1131:     */   }
/* 1132:     */   
/* 1133:     */   static class SoftValueReference<K, V>
/* 1134:     */     extends SoftReference<V>
/* 1135:     */     implements LocalCache.ValueReference<K, V>
/* 1136:     */   {
/* 1137:     */     final LocalCache.ReferenceEntry<K, V> entry;
/* 1138:     */     
/* 1139:     */     SoftValueReference(ReferenceQueue<V> queue, V referent, LocalCache.ReferenceEntry<K, V> entry)
/* 1140:     */     {
/* 1141:1634 */       super(queue);
/* 1142:1635 */       this.entry = entry;
/* 1143:     */     }
/* 1144:     */     
/* 1145:     */     public int getWeight()
/* 1146:     */     {
/* 1147:1640 */       return 1;
/* 1148:     */     }
/* 1149:     */     
/* 1150:     */     public LocalCache.ReferenceEntry<K, V> getEntry()
/* 1151:     */     {
/* 1152:1645 */       return this.entry;
/* 1153:     */     }
/* 1154:     */     
/* 1155:     */     public void notifyNewValue(V newValue) {}
/* 1156:     */     
/* 1157:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1158:     */     {
/* 1159:1654 */       return new SoftValueReference(queue, value, entry);
/* 1160:     */     }
/* 1161:     */     
/* 1162:     */     public boolean isLoading()
/* 1163:     */     {
/* 1164:1659 */       return false;
/* 1165:     */     }
/* 1166:     */     
/* 1167:     */     public boolean isActive()
/* 1168:     */     {
/* 1169:1664 */       return true;
/* 1170:     */     }
/* 1171:     */     
/* 1172:     */     public V waitForValue()
/* 1173:     */     {
/* 1174:1669 */       return get();
/* 1175:     */     }
/* 1176:     */   }
/* 1177:     */   
/* 1178:     */   static class StrongValueReference<K, V>
/* 1179:     */     implements LocalCache.ValueReference<K, V>
/* 1180:     */   {
/* 1181:     */     final V referent;
/* 1182:     */     
/* 1183:     */     StrongValueReference(V referent)
/* 1184:     */     {
/* 1185:1680 */       this.referent = referent;
/* 1186:     */     }
/* 1187:     */     
/* 1188:     */     public V get()
/* 1189:     */     {
/* 1190:1685 */       return this.referent;
/* 1191:     */     }
/* 1192:     */     
/* 1193:     */     public int getWeight()
/* 1194:     */     {
/* 1195:1690 */       return 1;
/* 1196:     */     }
/* 1197:     */     
/* 1198:     */     public LocalCache.ReferenceEntry<K, V> getEntry()
/* 1199:     */     {
/* 1200:1695 */       return null;
/* 1201:     */     }
/* 1202:     */     
/* 1203:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1204:     */     {
/* 1205:1701 */       return this;
/* 1206:     */     }
/* 1207:     */     
/* 1208:     */     public boolean isLoading()
/* 1209:     */     {
/* 1210:1706 */       return false;
/* 1211:     */     }
/* 1212:     */     
/* 1213:     */     public boolean isActive()
/* 1214:     */     {
/* 1215:1711 */       return true;
/* 1216:     */     }
/* 1217:     */     
/* 1218:     */     public V waitForValue()
/* 1219:     */     {
/* 1220:1716 */       return get();
/* 1221:     */     }
/* 1222:     */     
/* 1223:     */     public void notifyNewValue(V newValue) {}
/* 1224:     */   }
/* 1225:     */   
/* 1226:     */   static final class WeightedWeakValueReference<K, V>
/* 1227:     */     extends LocalCache.WeakValueReference<K, V>
/* 1228:     */   {
/* 1229:     */     final int weight;
/* 1230:     */     
/* 1231:     */     WeightedWeakValueReference(ReferenceQueue<V> queue, V referent, LocalCache.ReferenceEntry<K, V> entry, int weight)
/* 1232:     */     {
/* 1233:1731 */       super(referent, entry);
/* 1234:1732 */       this.weight = weight;
/* 1235:     */     }
/* 1236:     */     
/* 1237:     */     public int getWeight()
/* 1238:     */     {
/* 1239:1737 */       return this.weight;
/* 1240:     */     }
/* 1241:     */     
/* 1242:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1243:     */     {
/* 1244:1743 */       return new WeightedWeakValueReference(queue, value, entry, this.weight);
/* 1245:     */     }
/* 1246:     */   }
/* 1247:     */   
/* 1248:     */   static final class WeightedSoftValueReference<K, V>
/* 1249:     */     extends LocalCache.SoftValueReference<K, V>
/* 1250:     */   {
/* 1251:     */     final int weight;
/* 1252:     */     
/* 1253:     */     WeightedSoftValueReference(ReferenceQueue<V> queue, V referent, LocalCache.ReferenceEntry<K, V> entry, int weight)
/* 1254:     */     {
/* 1255:1755 */       super(referent, entry);
/* 1256:1756 */       this.weight = weight;
/* 1257:     */     }
/* 1258:     */     
/* 1259:     */     public int getWeight()
/* 1260:     */     {
/* 1261:1761 */       return this.weight;
/* 1262:     */     }
/* 1263:     */     
/* 1264:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, LocalCache.ReferenceEntry<K, V> entry)
/* 1265:     */     {
/* 1266:1766 */       return new WeightedSoftValueReference(queue, value, entry, this.weight);
/* 1267:     */     }
/* 1268:     */   }
/* 1269:     */   
/* 1270:     */   static final class WeightedStrongValueReference<K, V>
/* 1271:     */     extends LocalCache.StrongValueReference<K, V>
/* 1272:     */   {
/* 1273:     */     final int weight;
/* 1274:     */     
/* 1275:     */     WeightedStrongValueReference(V referent, int weight)
/* 1276:     */     {
/* 1277:1778 */       super();
/* 1278:1779 */       this.weight = weight;
/* 1279:     */     }
/* 1280:     */     
/* 1281:     */     public int getWeight()
/* 1282:     */     {
/* 1283:1784 */       return this.weight;
/* 1284:     */     }
/* 1285:     */   }
/* 1286:     */   
/* 1287:     */   static int rehash(int h)
/* 1288:     */   {
/* 1289:1800 */     h += (h << 15 ^ 0xFFFFCD7D);
/* 1290:1801 */     h ^= h >>> 10;
/* 1291:1802 */     h += (h << 3);
/* 1292:1803 */     h ^= h >>> 6;
/* 1293:1804 */     h += (h << 2) + (h << 14);
/* 1294:1805 */     return h ^ h >>> 16;
/* 1295:     */   }
/* 1296:     */   
/* 1297:     */   @VisibleForTesting
/* 1298:     */   ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable ReferenceEntry<K, V> next)
/* 1299:     */   {
/* 1300:1813 */     Segment<K, V> segment = segmentFor(hash);
/* 1301:1814 */     segment.lock();
/* 1302:     */     try
/* 1303:     */     {
/* 1304:1816 */       return segment.newEntry(key, hash, next);
/* 1305:     */     }
/* 1306:     */     finally
/* 1307:     */     {
/* 1308:1818 */       segment.unlock();
/* 1309:     */     }
/* 1310:     */   }
/* 1311:     */   
/* 1312:     */   @VisibleForTesting
/* 1313:     */   ReferenceEntry<K, V> copyEntry(ReferenceEntry<K, V> original, ReferenceEntry<K, V> newNext)
/* 1314:     */   {
/* 1315:1828 */     int hash = original.getHash();
/* 1316:1829 */     return segmentFor(hash).copyEntry(original, newNext);
/* 1317:     */   }
/* 1318:     */   
/* 1319:     */   @VisibleForTesting
/* 1320:     */   ValueReference<K, V> newValueReference(ReferenceEntry<K, V> entry, V value, int weight)
/* 1321:     */   {
/* 1322:1838 */     int hash = entry.getHash();
/* 1323:1839 */     return this.valueStrength.referenceValue(segmentFor(hash), entry, Preconditions.checkNotNull(value), weight);
/* 1324:     */   }
/* 1325:     */   
/* 1326:     */   int hash(@Nullable Object key)
/* 1327:     */   {
/* 1328:1843 */     int h = this.keyEquivalence.hash(key);
/* 1329:1844 */     return rehash(h);
/* 1330:     */   }
/* 1331:     */   
/* 1332:     */   void reclaimValue(ValueReference<K, V> valueReference)
/* 1333:     */   {
/* 1334:1848 */     ReferenceEntry<K, V> entry = valueReference.getEntry();
/* 1335:1849 */     int hash = entry.getHash();
/* 1336:1850 */     segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
/* 1337:     */   }
/* 1338:     */   
/* 1339:     */   void reclaimKey(ReferenceEntry<K, V> entry)
/* 1340:     */   {
/* 1341:1854 */     int hash = entry.getHash();
/* 1342:1855 */     segmentFor(hash).reclaimKey(entry, hash);
/* 1343:     */   }
/* 1344:     */   
/* 1345:     */   @VisibleForTesting
/* 1346:     */   boolean isLive(ReferenceEntry<K, V> entry, long now)
/* 1347:     */   {
/* 1348:1864 */     return segmentFor(entry.getHash()).getLiveValue(entry, now) != null;
/* 1349:     */   }
/* 1350:     */   
/* 1351:     */   Segment<K, V> segmentFor(int hash)
/* 1352:     */   {
/* 1353:1875 */     return this.segments[(hash >>> this.segmentShift & this.segmentMask)];
/* 1354:     */   }
/* 1355:     */   
/* 1356:     */   Segment<K, V> createSegment(int initialCapacity, long maxSegmentWeight, AbstractCache.StatsCounter statsCounter)
/* 1357:     */   {
/* 1358:1880 */     return new Segment(this, initialCapacity, maxSegmentWeight, statsCounter);
/* 1359:     */   }
/* 1360:     */   
/* 1361:     */   @Nullable
/* 1362:     */   V getLiveValue(ReferenceEntry<K, V> entry, long now)
/* 1363:     */   {
/* 1364:1891 */     if (entry.getKey() == null) {
/* 1365:1892 */       return null;
/* 1366:     */     }
/* 1367:1894 */     V value = entry.getValueReference().get();
/* 1368:1895 */     if (value == null) {
/* 1369:1896 */       return null;
/* 1370:     */     }
/* 1371:1899 */     if (isExpired(entry, now)) {
/* 1372:1900 */       return null;
/* 1373:     */     }
/* 1374:1902 */     return value;
/* 1375:     */   }
/* 1376:     */   
/* 1377:     */   boolean isExpired(ReferenceEntry<K, V> entry, long now)
/* 1378:     */   {
/* 1379:1911 */     Preconditions.checkNotNull(entry);
/* 1380:1912 */     if ((expiresAfterAccess()) && (now - entry.getAccessTime() >= this.expireAfterAccessNanos)) {
/* 1381:1914 */       return true;
/* 1382:     */     }
/* 1383:1916 */     if ((expiresAfterWrite()) && (now - entry.getWriteTime() >= this.expireAfterWriteNanos)) {
/* 1384:1918 */       return true;
/* 1385:     */     }
/* 1386:1920 */     return false;
/* 1387:     */   }
/* 1388:     */   
/* 1389:     */   static <K, V> void connectAccessOrder(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next)
/* 1390:     */   {
/* 1391:1927 */     previous.setNextInAccessQueue(next);
/* 1392:1928 */     next.setPreviousInAccessQueue(previous);
/* 1393:     */   }
/* 1394:     */   
/* 1395:     */   static <K, V> void nullifyAccessOrder(ReferenceEntry<K, V> nulled)
/* 1396:     */   {
/* 1397:1933 */     ReferenceEntry<K, V> nullEntry = nullEntry();
/* 1398:1934 */     nulled.setNextInAccessQueue(nullEntry);
/* 1399:1935 */     nulled.setPreviousInAccessQueue(nullEntry);
/* 1400:     */   }
/* 1401:     */   
/* 1402:     */   static <K, V> void connectWriteOrder(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next)
/* 1403:     */   {
/* 1404:1940 */     previous.setNextInWriteQueue(next);
/* 1405:1941 */     next.setPreviousInWriteQueue(previous);
/* 1406:     */   }
/* 1407:     */   
/* 1408:     */   static <K, V> void nullifyWriteOrder(ReferenceEntry<K, V> nulled)
/* 1409:     */   {
/* 1410:1946 */     ReferenceEntry<K, V> nullEntry = nullEntry();
/* 1411:1947 */     nulled.setNextInWriteQueue(nullEntry);
/* 1412:1948 */     nulled.setPreviousInWriteQueue(nullEntry);
/* 1413:     */   }
/* 1414:     */   
/* 1415:     */   void processPendingNotifications()
/* 1416:     */   {
/* 1417:     */     RemovalNotification<K, V> notification;
/* 1418:1958 */     while ((notification = (RemovalNotification)this.removalNotificationQueue.poll()) != null) {
/* 1419:     */       try
/* 1420:     */       {
/* 1421:1960 */         this.removalListener.onRemoval(notification);
/* 1422:     */       }
/* 1423:     */       catch (Throwable e)
/* 1424:     */       {
/* 1425:1962 */         logger.log(Level.WARNING, "Exception thrown by removal listener", e);
/* 1426:     */       }
/* 1427:     */     }
/* 1428:     */   }
/* 1429:     */   
/* 1430:     */   final Segment<K, V>[] newSegmentArray(int ssize)
/* 1431:     */   {
/* 1432:1969 */     return new Segment[ssize];
/* 1433:     */   }
/* 1434:     */   
/* 1435:     */   static class Segment<K, V>
/* 1436:     */     extends ReentrantLock
/* 1437:     */   {
/* 1438:     */     @Weak
/* 1439:     */     final LocalCache<K, V> map;
/* 1440:     */     volatile int count;
/* 1441:     */     @GuardedBy("this")
/* 1442:     */     long totalWeight;
/* 1443:     */     int modCount;
/* 1444:     */     int threshold;
/* 1445:     */     volatile AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table;
/* 1446:     */     final long maxSegmentWeight;
/* 1447:     */     final ReferenceQueue<K> keyReferenceQueue;
/* 1448:     */     final ReferenceQueue<V> valueReferenceQueue;
/* 1449:     */     final Queue<LocalCache.ReferenceEntry<K, V>> recencyQueue;
/* 1450:2074 */     final AtomicInteger readCount = new AtomicInteger();
/* 1451:     */     @GuardedBy("this")
/* 1452:     */     final Queue<LocalCache.ReferenceEntry<K, V>> writeQueue;
/* 1453:     */     @GuardedBy("this")
/* 1454:     */     final Queue<LocalCache.ReferenceEntry<K, V>> accessQueue;
/* 1455:     */     final AbstractCache.StatsCounter statsCounter;
/* 1456:     */     
/* 1457:     */     Segment(LocalCache<K, V> map, int initialCapacity, long maxSegmentWeight, AbstractCache.StatsCounter statsCounter)
/* 1458:     */     {
/* 1459:2095 */       this.map = map;
/* 1460:2096 */       this.maxSegmentWeight = maxSegmentWeight;
/* 1461:2097 */       this.statsCounter = ((AbstractCache.StatsCounter)Preconditions.checkNotNull(statsCounter));
/* 1462:2098 */       initTable(newEntryArray(initialCapacity));
/* 1463:     */       
/* 1464:2100 */       this.keyReferenceQueue = (map.usesKeyReferences() ? new ReferenceQueue() : null);
/* 1465:     */       
/* 1466:     */ 
/* 1467:2103 */       this.valueReferenceQueue = (map.usesValueReferences() ? new ReferenceQueue() : null);
/* 1468:     */       
/* 1469:     */ 
/* 1470:2106 */       this.recencyQueue = (map.usesAccessQueue() ? new ConcurrentLinkedQueue() : LocalCache.discardingQueue());
/* 1471:     */       
/* 1472:     */ 
/* 1473:     */ 
/* 1474:2110 */       this.writeQueue = (map.usesWriteQueue() ? new LocalCache.WriteQueue() : LocalCache.discardingQueue());
/* 1475:     */       
/* 1476:     */ 
/* 1477:     */ 
/* 1478:2114 */       this.accessQueue = (map.usesAccessQueue() ? new LocalCache.AccessQueue() : LocalCache.discardingQueue());
/* 1479:     */     }
/* 1480:     */     
/* 1481:     */     AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> newEntryArray(int size)
/* 1482:     */     {
/* 1483:2120 */       return new AtomicReferenceArray(size);
/* 1484:     */     }
/* 1485:     */     
/* 1486:     */     void initTable(AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> newTable)
/* 1487:     */     {
/* 1488:2124 */       this.threshold = (newTable.length() * 3 / 4);
/* 1489:2125 */       if ((!this.map.customWeigher()) && (this.threshold == this.maxSegmentWeight)) {
/* 1490:2127 */         this.threshold += 1;
/* 1491:     */       }
/* 1492:2129 */       this.table = newTable;
/* 1493:     */     }
/* 1494:     */     
/* 1495:     */     @GuardedBy("this")
/* 1496:     */     LocalCache.ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable LocalCache.ReferenceEntry<K, V> next)
/* 1497:     */     {
/* 1498:2134 */       return this.map.entryFactory.newEntry(this, Preconditions.checkNotNull(key), hash, next);
/* 1499:     */     }
/* 1500:     */     
/* 1501:     */     @GuardedBy("this")
/* 1502:     */     LocalCache.ReferenceEntry<K, V> copyEntry(LocalCache.ReferenceEntry<K, V> original, LocalCache.ReferenceEntry<K, V> newNext)
/* 1503:     */     {
/* 1504:2143 */       if (original.getKey() == null) {
/* 1505:2145 */         return null;
/* 1506:     */       }
/* 1507:2148 */       LocalCache.ValueReference<K, V> valueReference = original.getValueReference();
/* 1508:2149 */       V value = valueReference.get();
/* 1509:2150 */       if ((value == null) && (valueReference.isActive())) {
/* 1510:2152 */         return null;
/* 1511:     */       }
/* 1512:2155 */       LocalCache.ReferenceEntry<K, V> newEntry = this.map.entryFactory.copyEntry(this, original, newNext);
/* 1513:2156 */       newEntry.setValueReference(valueReference.copyFor(this.valueReferenceQueue, value, newEntry));
/* 1514:2157 */       return newEntry;
/* 1515:     */     }
/* 1516:     */     
/* 1517:     */     @GuardedBy("this")
/* 1518:     */     void setValue(LocalCache.ReferenceEntry<K, V> entry, K key, V value, long now)
/* 1519:     */     {
/* 1520:2165 */       LocalCache.ValueReference<K, V> previous = entry.getValueReference();
/* 1521:2166 */       int weight = this.map.weigher.weigh(key, value);
/* 1522:2167 */       Preconditions.checkState(weight >= 0, "Weights must be non-negative");
/* 1523:     */       
/* 1524:2169 */       LocalCache.ValueReference<K, V> valueReference = this.map.valueStrength.referenceValue(this, entry, value, weight);
/* 1525:     */       
/* 1526:2171 */       entry.setValueReference(valueReference);
/* 1527:2172 */       recordWrite(entry, weight, now);
/* 1528:2173 */       previous.notifyNewValue(value);
/* 1529:     */     }
/* 1530:     */     
/* 1531:     */     V get(K key, int hash, CacheLoader<? super K, V> loader)
/* 1532:     */       throws ExecutionException
/* 1533:     */     {
/* 1534:2179 */       Preconditions.checkNotNull(key);
/* 1535:2180 */       Preconditions.checkNotNull(loader);
/* 1536:     */       try
/* 1537:     */       {
/* 1538:     */         LocalCache.ReferenceEntry<K, V> e;
/* 1539:2182 */         if (this.count != 0)
/* 1540:     */         {
/* 1541:2184 */           e = getEntry(key, hash);
/* 1542:2185 */           if (e != null)
/* 1543:     */           {
/* 1544:2186 */             long now = this.map.ticker.read();
/* 1545:2187 */             V value = getLiveValue(e, now);
/* 1546:2188 */             if (value != null)
/* 1547:     */             {
/* 1548:2189 */               recordRead(e, now);
/* 1549:2190 */               this.statsCounter.recordHits(1);
/* 1550:2191 */               return scheduleRefresh(e, key, hash, value, now, loader);
/* 1551:     */             }
/* 1552:2193 */             Object valueReference = e.getValueReference();
/* 1553:2194 */             if (((LocalCache.ValueReference)valueReference).isLoading()) {
/* 1554:2195 */               return waitForLoadingValue(e, key, (LocalCache.ValueReference)valueReference);
/* 1555:     */             }
/* 1556:     */           }
/* 1557:     */         }
/* 1558:2201 */         return lockedGetOrLoad(key, hash, loader);
/* 1559:     */       }
/* 1560:     */       catch (ExecutionException ee)
/* 1561:     */       {
/* 1562:2203 */         Throwable cause = ee.getCause();
/* 1563:2204 */         if ((cause instanceof Error)) {
/* 1564:2205 */           throw new ExecutionError((Error)cause);
/* 1565:     */         }
/* 1566:2206 */         if ((cause instanceof RuntimeException)) {
/* 1567:2207 */           throw new UncheckedExecutionException(cause);
/* 1568:     */         }
/* 1569:2209 */         throw ee;
/* 1570:     */       }
/* 1571:     */       finally
/* 1572:     */       {
/* 1573:2211 */         postReadCleanup();
/* 1574:     */       }
/* 1575:     */     }
/* 1576:     */     
/* 1577:     */     V lockedGetOrLoad(K key, int hash, CacheLoader<? super K, V> loader)
/* 1578:     */       throws ExecutionException
/* 1579:     */     {
/* 1580:2218 */       valueReference = null;
/* 1581:2219 */       LocalCache.LoadingValueReference<K, V> loadingValueReference = null;
/* 1582:2220 */       boolean createNewEntry = true;
/* 1583:     */       
/* 1584:2222 */       lock();
/* 1585:     */       try
/* 1586:     */       {
/* 1587:2225 */         long now = this.map.ticker.read();
/* 1588:2226 */         preWriteCleanup(now);
/* 1589:     */         
/* 1590:2228 */         int newCount = this.count - 1;
/* 1591:2229 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 1592:2230 */         int index = hash & table.length() - 1;
/* 1593:2231 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 1594:2233 */         for (e = first; e != null; e = e.getNext())
/* 1595:     */         {
/* 1596:2234 */           K entryKey = e.getKey();
/* 1597:2235 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 1598:     */           {
/* 1599:2237 */             valueReference = e.getValueReference();
/* 1600:2238 */             if (valueReference.isLoading())
/* 1601:     */             {
/* 1602:2239 */               createNewEntry = false; break;
/* 1603:     */             }
/* 1604:2241 */             V value = valueReference.get();
/* 1605:2242 */             if (value == null)
/* 1606:     */             {
/* 1607:2243 */               enqueueNotification(entryKey, hash, valueReference, RemovalCause.COLLECTED);
/* 1608:     */             }
/* 1609:2244 */             else if (this.map.isExpired(e, now))
/* 1610:     */             {
/* 1611:2247 */               enqueueNotification(entryKey, hash, valueReference, RemovalCause.EXPIRED);
/* 1612:     */             }
/* 1613:     */             else
/* 1614:     */             {
/* 1615:2249 */               recordLockedRead(e, now);
/* 1616:2250 */               this.statsCounter.recordHits(1);
/* 1617:     */               
/* 1618:2252 */               return value;
/* 1619:     */             }
/* 1620:2256 */             this.writeQueue.remove(e);
/* 1621:2257 */             this.accessQueue.remove(e);
/* 1622:2258 */             this.count = newCount;
/* 1623:     */             
/* 1624:2260 */             break;
/* 1625:     */           }
/* 1626:     */         }
/* 1627:2264 */         if (createNewEntry)
/* 1628:     */         {
/* 1629:2265 */           loadingValueReference = new LocalCache.LoadingValueReference();
/* 1630:2267 */           if (e == null)
/* 1631:     */           {
/* 1632:2268 */             e = newEntry(key, hash, first);
/* 1633:2269 */             e.setValueReference(loadingValueReference);
/* 1634:2270 */             table.set(index, e);
/* 1635:     */           }
/* 1636:     */           else
/* 1637:     */           {
/* 1638:2272 */             e.setValueReference(loadingValueReference);
/* 1639:     */           }
/* 1640:     */         }
/* 1641:     */       }
/* 1642:     */       finally
/* 1643:     */       {
/* 1644:2276 */         unlock();
/* 1645:2277 */         postWriteCleanup();
/* 1646:     */       }
/* 1647:2280 */       if (createNewEntry) {
/* 1648:     */         try
/* 1649:     */         {
/* 1650:2285 */           synchronized (e)
/* 1651:     */           {
/* 1652:2286 */             return loadSync(key, hash, loadingValueReference, loader);
/* 1653:     */           }
/* 1654:2293 */           return waitForLoadingValue(e, key, valueReference);
/* 1655:     */         }
/* 1656:     */         finally
/* 1657:     */         {
/* 1658:2289 */           this.statsCounter.recordMisses(1);
/* 1659:     */         }
/* 1660:     */       }
/* 1661:     */     }
/* 1662:     */     
/* 1663:     */     V waitForLoadingValue(LocalCache.ReferenceEntry<K, V> e, K key, LocalCache.ValueReference<K, V> valueReference)
/* 1664:     */       throws ExecutionException
/* 1665:     */     {
/* 1666:2299 */       if (!valueReference.isLoading()) {
/* 1667:2300 */         throw new AssertionError();
/* 1668:     */       }
/* 1669:2303 */       Preconditions.checkState(!Thread.holdsLock(e), "Recursive load of: %s", new Object[] { key });
/* 1670:     */       try
/* 1671:     */       {
/* 1672:2306 */         V value = valueReference.waitForValue();
/* 1673:2307 */         if (value == null) {
/* 1674:2308 */           throw new CacheLoader.InvalidCacheLoadException("CacheLoader returned null for key " + key + ".");
/* 1675:     */         }
/* 1676:2311 */         long now = this.map.ticker.read();
/* 1677:2312 */         recordRead(e, now);
/* 1678:2313 */         return value;
/* 1679:     */       }
/* 1680:     */       finally
/* 1681:     */       {
/* 1682:2315 */         this.statsCounter.recordMisses(1);
/* 1683:     */       }
/* 1684:     */     }
/* 1685:     */     
/* 1686:     */     V loadSync(K key, int hash, LocalCache.LoadingValueReference<K, V> loadingValueReference, CacheLoader<? super K, V> loader)
/* 1687:     */       throws ExecutionException
/* 1688:     */     {
/* 1689:2323 */       ListenableFuture<V> loadingFuture = loadingValueReference.loadFuture(key, loader);
/* 1690:2324 */       return getAndRecordStats(key, hash, loadingValueReference, loadingFuture);
/* 1691:     */     }
/* 1692:     */     
/* 1693:     */     ListenableFuture<V> loadAsync(final K key, final int hash, final LocalCache.LoadingValueReference<K, V> loadingValueReference, CacheLoader<? super K, V> loader)
/* 1694:     */     {
/* 1695:2329 */       final ListenableFuture<V> loadingFuture = loadingValueReference.loadFuture(key, loader);
/* 1696:2330 */       loadingFuture.addListener(new Runnable()
/* 1697:     */       {
/* 1698:     */         public void run()
/* 1699:     */         {
/* 1700:     */           try
/* 1701:     */           {
/* 1702:2335 */             newValue = LocalCache.Segment.this.getAndRecordStats(key, hash, loadingValueReference, loadingFuture);
/* 1703:     */           }
/* 1704:     */           catch (Throwable t)
/* 1705:     */           {
/* 1706:     */             V newValue;
/* 1707:2337 */             LocalCache.logger.log(Level.WARNING, "Exception thrown during refresh", t);
/* 1708:2338 */             loadingValueReference.setException(t);
/* 1709:     */           }
/* 1710:     */         }
/* 1711:2338 */       }, MoreExecutors.directExecutor());
/* 1712:     */       
/* 1713:     */ 
/* 1714:     */ 
/* 1715:2342 */       return loadingFuture;
/* 1716:     */     }
/* 1717:     */     
/* 1718:     */     V getAndRecordStats(K key, int hash, LocalCache.LoadingValueReference<K, V> loadingValueReference, ListenableFuture<V> newValue)
/* 1719:     */       throws ExecutionException
/* 1720:     */     {
/* 1721:2350 */       V value = null;
/* 1722:     */       try
/* 1723:     */       {
/* 1724:2352 */         value = Uninterruptibles.getUninterruptibly(newValue);
/* 1725:2353 */         if (value == null) {
/* 1726:2354 */           throw new CacheLoader.InvalidCacheLoadException("CacheLoader returned null for key " + key + ".");
/* 1727:     */         }
/* 1728:2356 */         this.statsCounter.recordLoadSuccess(loadingValueReference.elapsedNanos());
/* 1729:2357 */         storeLoadedValue(key, hash, loadingValueReference, value);
/* 1730:2358 */         return value;
/* 1731:     */       }
/* 1732:     */       finally
/* 1733:     */       {
/* 1734:2360 */         if (value == null)
/* 1735:     */         {
/* 1736:2361 */           this.statsCounter.recordLoadException(loadingValueReference.elapsedNanos());
/* 1737:2362 */           removeLoadingValue(key, hash, loadingValueReference);
/* 1738:     */         }
/* 1739:     */       }
/* 1740:     */     }
/* 1741:     */     
/* 1742:     */     V scheduleRefresh(LocalCache.ReferenceEntry<K, V> entry, K key, int hash, V oldValue, long now, CacheLoader<? super K, V> loader)
/* 1743:     */     {
/* 1744:2369 */       if ((this.map.refreshes()) && (now - entry.getWriteTime() > this.map.refreshNanos) && (!entry.getValueReference().isLoading()))
/* 1745:     */       {
/* 1746:2371 */         V newValue = refresh(key, hash, loader, true);
/* 1747:2372 */         if (newValue != null) {
/* 1748:2373 */           return newValue;
/* 1749:     */         }
/* 1750:     */       }
/* 1751:2376 */       return oldValue;
/* 1752:     */     }
/* 1753:     */     
/* 1754:     */     @Nullable
/* 1755:     */     V refresh(K key, int hash, CacheLoader<? super K, V> loader, boolean checkTime)
/* 1756:     */     {
/* 1757:2387 */       LocalCache.LoadingValueReference<K, V> loadingValueReference = insertLoadingValueReference(key, hash, checkTime);
/* 1758:2389 */       if (loadingValueReference == null) {
/* 1759:2390 */         return null;
/* 1760:     */       }
/* 1761:2393 */       ListenableFuture<V> result = loadAsync(key, hash, loadingValueReference, loader);
/* 1762:2394 */       if (result.isDone()) {
/* 1763:     */         try
/* 1764:     */         {
/* 1765:2396 */           return Uninterruptibles.getUninterruptibly(result);
/* 1766:     */         }
/* 1767:     */         catch (Throwable t) {}
/* 1768:     */       }
/* 1769:2401 */       return null;
/* 1770:     */     }
/* 1771:     */     
/* 1772:     */     @Nullable
/* 1773:     */     LocalCache.LoadingValueReference<K, V> insertLoadingValueReference(K key, int hash, boolean checkTime)
/* 1774:     */     {
/* 1775:2411 */       LocalCache.ReferenceEntry<K, V> e = null;
/* 1776:2412 */       lock();
/* 1777:     */       try
/* 1778:     */       {
/* 1779:2414 */         long now = this.map.ticker.read();
/* 1780:2415 */         preWriteCleanup(now);
/* 1781:     */         
/* 1782:2417 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 1783:2418 */         int index = hash & table.length() - 1;
/* 1784:2419 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 1785:     */         LocalCache.ValueReference<K, V> valueReference;
/* 1786:2422 */         for (e = first; e != null; e = e.getNext())
/* 1787:     */         {
/* 1788:2423 */           K entryKey = e.getKey();
/* 1789:2424 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 1790:     */           {
/* 1791:2428 */             valueReference = e.getValueReference();
/* 1792:2429 */             if ((valueReference.isLoading()) || ((checkTime) && (now - e.getWriteTime() < this.map.refreshNanos))) {
/* 1793:2434 */               return null;
/* 1794:     */             }
/* 1795:2438 */             this.modCount += 1;
/* 1796:2439 */             Object loadingValueReference = new LocalCache.LoadingValueReference(valueReference);
/* 1797:     */             
/* 1798:2441 */             e.setValueReference((LocalCache.ValueReference)loadingValueReference);
/* 1799:2442 */             return loadingValueReference;
/* 1800:     */           }
/* 1801:     */         }
/* 1802:2446 */         this.modCount += 1;
/* 1803:2447 */         LocalCache.LoadingValueReference<K, V> loadingValueReference = new LocalCache.LoadingValueReference();
/* 1804:2448 */         e = newEntry(key, hash, first);
/* 1805:2449 */         e.setValueReference(loadingValueReference);
/* 1806:2450 */         table.set(index, e);
/* 1807:2451 */         return loadingValueReference;
/* 1808:     */       }
/* 1809:     */       finally
/* 1810:     */       {
/* 1811:2453 */         unlock();
/* 1812:2454 */         postWriteCleanup();
/* 1813:     */       }
/* 1814:     */     }
/* 1815:     */     
/* 1816:     */     void tryDrainReferenceQueues()
/* 1817:     */     {
/* 1818:2464 */       if (tryLock()) {
/* 1819:     */         try
/* 1820:     */         {
/* 1821:2466 */           drainReferenceQueues();
/* 1822:     */         }
/* 1823:     */         finally
/* 1824:     */         {
/* 1825:2468 */           unlock();
/* 1826:     */         }
/* 1827:     */       }
/* 1828:     */     }
/* 1829:     */     
/* 1830:     */     @GuardedBy("this")
/* 1831:     */     void drainReferenceQueues()
/* 1832:     */     {
/* 1833:2479 */       if (this.map.usesKeyReferences()) {
/* 1834:2480 */         drainKeyReferenceQueue();
/* 1835:     */       }
/* 1836:2482 */       if (this.map.usesValueReferences()) {
/* 1837:2483 */         drainValueReferenceQueue();
/* 1838:     */       }
/* 1839:     */     }
/* 1840:     */     
/* 1841:     */     @GuardedBy("this")
/* 1842:     */     void drainKeyReferenceQueue()
/* 1843:     */     {
/* 1844:2490 */       int i = 0;
/* 1845:     */       Reference<? extends K> ref;
/* 1846:2491 */       for (; (ref = this.keyReferenceQueue.poll()) != null; i == 16)
/* 1847:     */       {
/* 1848:2493 */         LocalCache.ReferenceEntry<K, V> entry = (LocalCache.ReferenceEntry)ref;
/* 1849:2494 */         this.map.reclaimKey(entry);
/* 1850:2495 */         i++;
/* 1851:     */       }
/* 1852:     */     }
/* 1853:     */     
/* 1854:     */     @GuardedBy("this")
/* 1855:     */     void drainValueReferenceQueue()
/* 1856:     */     {
/* 1857:2504 */       int i = 0;
/* 1858:     */       Reference<? extends V> ref;
/* 1859:2505 */       for (; (ref = this.valueReferenceQueue.poll()) != null; i == 16)
/* 1860:     */       {
/* 1861:2507 */         LocalCache.ValueReference<K, V> valueReference = (LocalCache.ValueReference)ref;
/* 1862:2508 */         this.map.reclaimValue(valueReference);
/* 1863:2509 */         i++;
/* 1864:     */       }
/* 1865:     */     }
/* 1866:     */     
/* 1867:     */     void clearReferenceQueues()
/* 1868:     */     {
/* 1869:2519 */       if (this.map.usesKeyReferences()) {
/* 1870:2520 */         clearKeyReferenceQueue();
/* 1871:     */       }
/* 1872:2522 */       if (this.map.usesValueReferences()) {
/* 1873:2523 */         clearValueReferenceQueue();
/* 1874:     */       }
/* 1875:     */     }
/* 1876:     */     
/* 1877:     */     void clearKeyReferenceQueue()
/* 1878:     */     {
/* 1879:2528 */       while (this.keyReferenceQueue.poll() != null) {}
/* 1880:     */     }
/* 1881:     */     
/* 1882:     */     void clearValueReferenceQueue()
/* 1883:     */     {
/* 1884:2532 */       while (this.valueReferenceQueue.poll() != null) {}
/* 1885:     */     }
/* 1886:     */     
/* 1887:     */     void recordRead(LocalCache.ReferenceEntry<K, V> entry, long now)
/* 1888:     */     {
/* 1889:2545 */       if (this.map.recordsAccess()) {
/* 1890:2546 */         entry.setAccessTime(now);
/* 1891:     */       }
/* 1892:2548 */       this.recencyQueue.add(entry);
/* 1893:     */     }
/* 1894:     */     
/* 1895:     */     @GuardedBy("this")
/* 1896:     */     void recordLockedRead(LocalCache.ReferenceEntry<K, V> entry, long now)
/* 1897:     */     {
/* 1898:2560 */       if (this.map.recordsAccess()) {
/* 1899:2561 */         entry.setAccessTime(now);
/* 1900:     */       }
/* 1901:2563 */       this.accessQueue.add(entry);
/* 1902:     */     }
/* 1903:     */     
/* 1904:     */     @GuardedBy("this")
/* 1905:     */     void recordWrite(LocalCache.ReferenceEntry<K, V> entry, int weight, long now)
/* 1906:     */     {
/* 1907:2573 */       drainRecencyQueue();
/* 1908:2574 */       this.totalWeight += weight;
/* 1909:2576 */       if (this.map.recordsAccess()) {
/* 1910:2577 */         entry.setAccessTime(now);
/* 1911:     */       }
/* 1912:2579 */       if (this.map.recordsWrite()) {
/* 1913:2580 */         entry.setWriteTime(now);
/* 1914:     */       }
/* 1915:2582 */       this.accessQueue.add(entry);
/* 1916:2583 */       this.writeQueue.add(entry);
/* 1917:     */     }
/* 1918:     */     
/* 1919:     */     @GuardedBy("this")
/* 1920:     */     void drainRecencyQueue()
/* 1921:     */     {
/* 1922:     */       LocalCache.ReferenceEntry<K, V> e;
/* 1923:2595 */       while ((e = (LocalCache.ReferenceEntry)this.recencyQueue.poll()) != null) {
/* 1924:2600 */         if (this.accessQueue.contains(e)) {
/* 1925:2601 */           this.accessQueue.add(e);
/* 1926:     */         }
/* 1927:     */       }
/* 1928:     */     }
/* 1929:     */     
/* 1930:     */     void tryExpireEntries(long now)
/* 1931:     */     {
/* 1932:2612 */       if (tryLock()) {
/* 1933:     */         try
/* 1934:     */         {
/* 1935:2614 */           expireEntries(now);
/* 1936:     */         }
/* 1937:     */         finally
/* 1938:     */         {
/* 1939:2616 */           unlock();
/* 1940:     */         }
/* 1941:     */       }
/* 1942:     */     }
/* 1943:     */     
/* 1944:     */     @GuardedBy("this")
/* 1945:     */     void expireEntries(long now)
/* 1946:     */     {
/* 1947:2624 */       drainRecencyQueue();
/* 1948:     */       LocalCache.ReferenceEntry<K, V> e;
/* 1949:2627 */       while (((e = (LocalCache.ReferenceEntry)this.writeQueue.peek()) != null) && (this.map.isExpired(e, now))) {
/* 1950:2628 */         if (!removeEntry(e, e.getHash(), RemovalCause.EXPIRED)) {
/* 1951:2629 */           throw new AssertionError();
/* 1952:     */         }
/* 1953:     */       }
/* 1954:2632 */       while (((e = (LocalCache.ReferenceEntry)this.accessQueue.peek()) != null) && (this.map.isExpired(e, now))) {
/* 1955:2633 */         if (!removeEntry(e, e.getHash(), RemovalCause.EXPIRED)) {
/* 1956:2634 */           throw new AssertionError();
/* 1957:     */         }
/* 1958:     */       }
/* 1959:     */     }
/* 1960:     */     
/* 1961:     */     @GuardedBy("this")
/* 1962:     */     void enqueueNotification(LocalCache.ReferenceEntry<K, V> entry, RemovalCause cause)
/* 1963:     */     {
/* 1964:2643 */       enqueueNotification(entry.getKey(), entry.getHash(), entry.getValueReference(), cause);
/* 1965:     */     }
/* 1966:     */     
/* 1967:     */     @GuardedBy("this")
/* 1968:     */     void enqueueNotification(@Nullable K key, int hash, LocalCache.ValueReference<K, V> valueReference, RemovalCause cause)
/* 1969:     */     {
/* 1970:2649 */       this.totalWeight -= valueReference.getWeight();
/* 1971:2650 */       if (cause.wasEvicted()) {
/* 1972:2651 */         this.statsCounter.recordEviction();
/* 1973:     */       }
/* 1974:2653 */       if (this.map.removalNotificationQueue != LocalCache.DISCARDING_QUEUE)
/* 1975:     */       {
/* 1976:2654 */         V value = valueReference.get();
/* 1977:2655 */         RemovalNotification<K, V> notification = RemovalNotification.create(key, value, cause);
/* 1978:2656 */         this.map.removalNotificationQueue.offer(notification);
/* 1979:     */       }
/* 1980:     */     }
/* 1981:     */     
/* 1982:     */     @GuardedBy("this")
/* 1983:     */     void evictEntries(LocalCache.ReferenceEntry<K, V> newest)
/* 1984:     */     {
/* 1985:2668 */       if (!this.map.evictsBySize()) {
/* 1986:2669 */         return;
/* 1987:     */       }
/* 1988:2672 */       drainRecencyQueue();
/* 1989:2676 */       if ((newest.getValueReference().getWeight() > this.maxSegmentWeight) && 
/* 1990:2677 */         (!removeEntry(newest, newest.getHash(), RemovalCause.SIZE))) {
/* 1991:2678 */         throw new AssertionError();
/* 1992:     */       }
/* 1993:2682 */       while (this.totalWeight > this.maxSegmentWeight)
/* 1994:     */       {
/* 1995:2683 */         LocalCache.ReferenceEntry<K, V> e = getNextEvictable();
/* 1996:2684 */         if (!removeEntry(e, e.getHash(), RemovalCause.SIZE)) {
/* 1997:2685 */           throw new AssertionError();
/* 1998:     */         }
/* 1999:     */       }
/* 2000:     */     }
/* 2001:     */     
/* 2002:     */     @GuardedBy("this")
/* 2003:     */     LocalCache.ReferenceEntry<K, V> getNextEvictable()
/* 2004:     */     {
/* 2005:2693 */       for (LocalCache.ReferenceEntry<K, V> e : this.accessQueue)
/* 2006:     */       {
/* 2007:2694 */         int weight = e.getValueReference().getWeight();
/* 2008:2695 */         if (weight > 0) {
/* 2009:2696 */           return e;
/* 2010:     */         }
/* 2011:     */       }
/* 2012:2699 */       throw new AssertionError();
/* 2013:     */     }
/* 2014:     */     
/* 2015:     */     LocalCache.ReferenceEntry<K, V> getFirst(int hash)
/* 2016:     */     {
/* 2017:2707 */       AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2018:2708 */       return (LocalCache.ReferenceEntry)table.get(hash & table.length() - 1);
/* 2019:     */     }
/* 2020:     */     
/* 2021:     */     @Nullable
/* 2022:     */     LocalCache.ReferenceEntry<K, V> getEntry(Object key, int hash)
/* 2023:     */     {
/* 2024:2715 */       for (LocalCache.ReferenceEntry<K, V> e = getFirst(hash); e != null; e = e.getNext()) {
/* 2025:2716 */         if (e.getHash() == hash)
/* 2026:     */         {
/* 2027:2720 */           K entryKey = e.getKey();
/* 2028:2721 */           if (entryKey == null) {
/* 2029:2722 */             tryDrainReferenceQueues();
/* 2030:2726 */           } else if (this.map.keyEquivalence.equivalent(key, entryKey)) {
/* 2031:2727 */             return e;
/* 2032:     */           }
/* 2033:     */         }
/* 2034:     */       }
/* 2035:2731 */       return null;
/* 2036:     */     }
/* 2037:     */     
/* 2038:     */     @Nullable
/* 2039:     */     LocalCache.ReferenceEntry<K, V> getLiveEntry(Object key, int hash, long now)
/* 2040:     */     {
/* 2041:2736 */       LocalCache.ReferenceEntry<K, V> e = getEntry(key, hash);
/* 2042:2737 */       if (e == null) {
/* 2043:2738 */         return null;
/* 2044:     */       }
/* 2045:2739 */       if (this.map.isExpired(e, now))
/* 2046:     */       {
/* 2047:2740 */         tryExpireEntries(now);
/* 2048:2741 */         return null;
/* 2049:     */       }
/* 2050:2743 */       return e;
/* 2051:     */     }
/* 2052:     */     
/* 2053:     */     V getLiveValue(LocalCache.ReferenceEntry<K, V> entry, long now)
/* 2054:     */     {
/* 2055:2751 */       if (entry.getKey() == null)
/* 2056:     */       {
/* 2057:2752 */         tryDrainReferenceQueues();
/* 2058:2753 */         return null;
/* 2059:     */       }
/* 2060:2755 */       V value = entry.getValueReference().get();
/* 2061:2756 */       if (value == null)
/* 2062:     */       {
/* 2063:2757 */         tryDrainReferenceQueues();
/* 2064:2758 */         return null;
/* 2065:     */       }
/* 2066:2761 */       if (this.map.isExpired(entry, now))
/* 2067:     */       {
/* 2068:2762 */         tryExpireEntries(now);
/* 2069:2763 */         return null;
/* 2070:     */       }
/* 2071:2765 */       return value;
/* 2072:     */     }
/* 2073:     */     
/* 2074:     */     @Nullable
/* 2075:     */     V get(Object key, int hash)
/* 2076:     */     {
/* 2077:     */       try
/* 2078:     */       {
/* 2079:     */         long now;
/* 2080:2771 */         if (this.count != 0)
/* 2081:     */         {
/* 2082:2772 */           now = this.map.ticker.read();
/* 2083:2773 */           LocalCache.ReferenceEntry<K, V> e = getLiveEntry(key, hash, now);
/* 2084:2774 */           if (e == null) {
/* 2085:2775 */             return null;
/* 2086:     */           }
/* 2087:2778 */           Object value = e.getValueReference().get();
/* 2088:2779 */           if (value != null)
/* 2089:     */           {
/* 2090:2780 */             recordRead(e, now);
/* 2091:2781 */             return scheduleRefresh(e, e.getKey(), hash, value, now, this.map.defaultLoader);
/* 2092:     */           }
/* 2093:2783 */           tryDrainReferenceQueues();
/* 2094:     */         }
/* 2095:2785 */         return null;
/* 2096:     */       }
/* 2097:     */       finally
/* 2098:     */       {
/* 2099:2787 */         postReadCleanup();
/* 2100:     */       }
/* 2101:     */     }
/* 2102:     */     
/* 2103:     */     boolean containsKey(Object key, int hash)
/* 2104:     */     {
/* 2105:     */       try
/* 2106:     */       {
/* 2107:     */         long now;
/* 2108:2793 */         if (this.count != 0)
/* 2109:     */         {
/* 2110:2794 */           now = this.map.ticker.read();
/* 2111:2795 */           LocalCache.ReferenceEntry<K, V> e = getLiveEntry(key, hash, now);
/* 2112:     */           boolean bool;
/* 2113:2796 */           if (e == null) {
/* 2114:2797 */             return false;
/* 2115:     */           }
/* 2116:2799 */           return e.getValueReference().get() != null;
/* 2117:     */         }
/* 2118:2802 */         return 0;
/* 2119:     */       }
/* 2120:     */       finally
/* 2121:     */       {
/* 2122:2804 */         postReadCleanup();
/* 2123:     */       }
/* 2124:     */     }
/* 2125:     */     
/* 2126:     */     @VisibleForTesting
/* 2127:     */     boolean containsValue(Object value)
/* 2128:     */     {
/* 2129:     */       try
/* 2130:     */       {
/* 2131:     */         long now;
/* 2132:2815 */         if (this.count != 0)
/* 2133:     */         {
/* 2134:2816 */           now = this.map.ticker.read();
/* 2135:2817 */           AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2136:2818 */           int length = table.length();
/* 2137:2819 */           for (int i = 0; i < length; i++) {
/* 2138:2820 */             for (LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)table.get(i); e != null; e = e.getNext())
/* 2139:     */             {
/* 2140:2821 */               V entryValue = getLiveValue(e, now);
/* 2141:2822 */               if (entryValue != null) {
/* 2142:2825 */                 if (this.map.valueEquivalence.equivalent(value, entryValue)) {
/* 2143:2826 */                   return true;
/* 2144:     */                 }
/* 2145:     */               }
/* 2146:     */             }
/* 2147:     */           }
/* 2148:     */         }
/* 2149:2832 */         return 0;
/* 2150:     */       }
/* 2151:     */       finally
/* 2152:     */       {
/* 2153:2834 */         postReadCleanup();
/* 2154:     */       }
/* 2155:     */     }
/* 2156:     */     
/* 2157:     */     @Nullable
/* 2158:     */     V put(K key, int hash, V value, boolean onlyIfAbsent)
/* 2159:     */     {
/* 2160:2840 */       lock();
/* 2161:     */       try
/* 2162:     */       {
/* 2163:2842 */         long now = this.map.ticker.read();
/* 2164:2843 */         preWriteCleanup(now);
/* 2165:     */         
/* 2166:2845 */         int newCount = this.count + 1;
/* 2167:2846 */         if (newCount > this.threshold)
/* 2168:     */         {
/* 2169:2847 */           expand();
/* 2170:2848 */           newCount = this.count + 1;
/* 2171:     */         }
/* 2172:2851 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2173:2852 */         int index = hash & table.length() - 1;
/* 2174:2853 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2175:     */         K entryKey;
/* 2176:2856 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2177:     */         {
/* 2178:2857 */           entryKey = e.getKey();
/* 2179:2858 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2180:     */           {
/* 2181:2862 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2182:2863 */             V entryValue = valueReference.get();
/* 2183:     */             V ?;
/* 2184:2865 */             if (entryValue == null)
/* 2185:     */             {
/* 2186:2866 */               this.modCount += 1;
/* 2187:2867 */               if (valueReference.isActive())
/* 2188:     */               {
/* 2189:2868 */                 enqueueNotification(key, hash, valueReference, RemovalCause.COLLECTED);
/* 2190:2869 */                 setValue(e, key, value, now);
/* 2191:2870 */                 newCount = this.count;
/* 2192:     */               }
/* 2193:     */               else
/* 2194:     */               {
/* 2195:2872 */                 setValue(e, key, value, now);
/* 2196:2873 */                 newCount = this.count + 1;
/* 2197:     */               }
/* 2198:2875 */               this.count = newCount;
/* 2199:2876 */               evictEntries(e);
/* 2200:2877 */               return null;
/* 2201:     */             }
/* 2202:2878 */             if (onlyIfAbsent)
/* 2203:     */             {
/* 2204:2882 */               recordLockedRead(e, now);
/* 2205:2883 */               return entryValue;
/* 2206:     */             }
/* 2207:2886 */             this.modCount += 1;
/* 2208:2887 */             enqueueNotification(key, hash, valueReference, RemovalCause.REPLACED);
/* 2209:2888 */             setValue(e, key, value, now);
/* 2210:2889 */             evictEntries(e);
/* 2211:2890 */             return entryValue;
/* 2212:     */           }
/* 2213:     */         }
/* 2214:2896 */         this.modCount += 1;
/* 2215:2897 */         LocalCache.ReferenceEntry<K, V> newEntry = newEntry(key, hash, first);
/* 2216:2898 */         setValue(newEntry, key, value, now);
/* 2217:2899 */         table.set(index, newEntry);
/* 2218:2900 */         newCount = this.count + 1;
/* 2219:2901 */         this.count = newCount;
/* 2220:2902 */         evictEntries(newEntry);
/* 2221:2903 */         return null;
/* 2222:     */       }
/* 2223:     */       finally
/* 2224:     */       {
/* 2225:2905 */         unlock();
/* 2226:2906 */         postWriteCleanup();
/* 2227:     */       }
/* 2228:     */     }
/* 2229:     */     
/* 2230:     */     @GuardedBy("this")
/* 2231:     */     void expand()
/* 2232:     */     {
/* 2233:2915 */       AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> oldTable = this.table;
/* 2234:2916 */       int oldCapacity = oldTable.length();
/* 2235:2917 */       if (oldCapacity >= 1073741824) {
/* 2236:2918 */         return;
/* 2237:     */       }
/* 2238:2931 */       int newCount = this.count;
/* 2239:2932 */       AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> newTable = newEntryArray(oldCapacity << 1);
/* 2240:2933 */       this.threshold = (newTable.length() * 3 / 4);
/* 2241:2934 */       int newMask = newTable.length() - 1;
/* 2242:2935 */       for (int oldIndex = 0; oldIndex < oldCapacity; oldIndex++)
/* 2243:     */       {
/* 2244:2938 */         LocalCache.ReferenceEntry<K, V> head = (LocalCache.ReferenceEntry)oldTable.get(oldIndex);
/* 2245:2940 */         if (head != null)
/* 2246:     */         {
/* 2247:2941 */           LocalCache.ReferenceEntry<K, V> next = head.getNext();
/* 2248:2942 */           int headIndex = head.getHash() & newMask;
/* 2249:2945 */           if (next == null)
/* 2250:     */           {
/* 2251:2946 */             newTable.set(headIndex, head);
/* 2252:     */           }
/* 2253:     */           else
/* 2254:     */           {
/* 2255:2951 */             LocalCache.ReferenceEntry<K, V> tail = head;
/* 2256:2952 */             int tailIndex = headIndex;
/* 2257:2953 */             for (LocalCache.ReferenceEntry<K, V> e = next; e != null; e = e.getNext())
/* 2258:     */             {
/* 2259:2954 */               int newIndex = e.getHash() & newMask;
/* 2260:2955 */               if (newIndex != tailIndex)
/* 2261:     */               {
/* 2262:2957 */                 tailIndex = newIndex;
/* 2263:2958 */                 tail = e;
/* 2264:     */               }
/* 2265:     */             }
/* 2266:2961 */             newTable.set(tailIndex, tail);
/* 2267:2964 */             for (LocalCache.ReferenceEntry<K, V> e = head; e != tail; e = e.getNext())
/* 2268:     */             {
/* 2269:2965 */               int newIndex = e.getHash() & newMask;
/* 2270:2966 */               LocalCache.ReferenceEntry<K, V> newNext = (LocalCache.ReferenceEntry)newTable.get(newIndex);
/* 2271:2967 */               LocalCache.ReferenceEntry<K, V> newFirst = copyEntry(e, newNext);
/* 2272:2968 */               if (newFirst != null)
/* 2273:     */               {
/* 2274:2969 */                 newTable.set(newIndex, newFirst);
/* 2275:     */               }
/* 2276:     */               else
/* 2277:     */               {
/* 2278:2971 */                 removeCollectedEntry(e);
/* 2279:2972 */                 newCount--;
/* 2280:     */               }
/* 2281:     */             }
/* 2282:     */           }
/* 2283:     */         }
/* 2284:     */       }
/* 2285:2978 */       this.table = newTable;
/* 2286:2979 */       this.count = newCount;
/* 2287:     */     }
/* 2288:     */     
/* 2289:     */     boolean replace(K key, int hash, V oldValue, V newValue)
/* 2290:     */     {
/* 2291:2983 */       lock();
/* 2292:     */       try
/* 2293:     */       {
/* 2294:2985 */         long now = this.map.ticker.read();
/* 2295:2986 */         preWriteCleanup(now);
/* 2296:     */         
/* 2297:2988 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2298:2989 */         int index = hash & table.length() - 1;
/* 2299:2990 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2300:2992 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2301:     */         {
/* 2302:2993 */           K entryKey = e.getKey();
/* 2303:2994 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2304:     */           {
/* 2305:2996 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2306:2997 */             V entryValue = valueReference.get();
/* 2307:     */             int newCount;
/* 2308:2998 */             if (entryValue == null)
/* 2309:     */             {
/* 2310:2999 */               if (valueReference.isActive())
/* 2311:     */               {
/* 2312:3001 */                 newCount = this.count - 1;
/* 2313:3002 */                 this.modCount += 1;
/* 2314:3003 */                 LocalCache.ReferenceEntry<K, V> newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, RemovalCause.COLLECTED);
/* 2315:     */                 
/* 2316:3005 */                 newCount = this.count - 1;
/* 2317:3006 */                 table.set(index, newFirst);
/* 2318:3007 */                 this.count = newCount;
/* 2319:     */               }
/* 2320:3009 */               return 0;
/* 2321:     */             }
/* 2322:3012 */             if (this.map.valueEquivalence.equivalent(oldValue, entryValue))
/* 2323:     */             {
/* 2324:3013 */               this.modCount += 1;
/* 2325:3014 */               enqueueNotification(key, hash, valueReference, RemovalCause.REPLACED);
/* 2326:3015 */               setValue(e, key, newValue, now);
/* 2327:3016 */               evictEntries(e);
/* 2328:3017 */               return 1;
/* 2329:     */             }
/* 2330:3021 */             recordLockedRead(e, now);
/* 2331:3022 */             return 0;
/* 2332:     */           }
/* 2333:     */         }
/* 2334:3027 */         return 0;
/* 2335:     */       }
/* 2336:     */       finally
/* 2337:     */       {
/* 2338:3029 */         unlock();
/* 2339:3030 */         postWriteCleanup();
/* 2340:     */       }
/* 2341:     */     }
/* 2342:     */     
/* 2343:     */     @Nullable
/* 2344:     */     V replace(K key, int hash, V newValue)
/* 2345:     */     {
/* 2346:3036 */       lock();
/* 2347:     */       try
/* 2348:     */       {
/* 2349:3038 */         long now = this.map.ticker.read();
/* 2350:3039 */         preWriteCleanup(now);
/* 2351:     */         
/* 2352:3041 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2353:3042 */         int index = hash & table.length() - 1;
/* 2354:3043 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2355:3045 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2356:     */         {
/* 2357:3046 */           K entryKey = e.getKey();
/* 2358:3047 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2359:     */           {
/* 2360:3049 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2361:3050 */             V entryValue = valueReference.get();
/* 2362:     */             int newCount;
/* 2363:3051 */             if (entryValue == null)
/* 2364:     */             {
/* 2365:3052 */               if (valueReference.isActive())
/* 2366:     */               {
/* 2367:3054 */                 newCount = this.count - 1;
/* 2368:3055 */                 this.modCount += 1;
/* 2369:3056 */                 LocalCache.ReferenceEntry<K, V> newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, RemovalCause.COLLECTED);
/* 2370:     */                 
/* 2371:3058 */                 newCount = this.count - 1;
/* 2372:3059 */                 table.set(index, newFirst);
/* 2373:3060 */                 this.count = newCount;
/* 2374:     */               }
/* 2375:3062 */               return null;
/* 2376:     */             }
/* 2377:3065 */             this.modCount += 1;
/* 2378:3066 */             enqueueNotification(key, hash, valueReference, RemovalCause.REPLACED);
/* 2379:3067 */             setValue(e, key, newValue, now);
/* 2380:3068 */             evictEntries(e);
/* 2381:3069 */             return entryValue;
/* 2382:     */           }
/* 2383:     */         }
/* 2384:3073 */         return null;
/* 2385:     */       }
/* 2386:     */       finally
/* 2387:     */       {
/* 2388:3075 */         unlock();
/* 2389:3076 */         postWriteCleanup();
/* 2390:     */       }
/* 2391:     */     }
/* 2392:     */     
/* 2393:     */     @Nullable
/* 2394:     */     V remove(Object key, int hash)
/* 2395:     */     {
/* 2396:3082 */       lock();
/* 2397:     */       try
/* 2398:     */       {
/* 2399:3084 */         long now = this.map.ticker.read();
/* 2400:3085 */         preWriteCleanup(now);
/* 2401:     */         
/* 2402:3087 */         int newCount = this.count - 1;
/* 2403:3088 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2404:3089 */         int index = hash & table.length() - 1;
/* 2405:3090 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2406:3092 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2407:     */         {
/* 2408:3093 */           K entryKey = e.getKey();
/* 2409:3094 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2410:     */           {
/* 2411:3096 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2412:3097 */             V entryValue = valueReference.get();
/* 2413:     */             RemovalCause cause;
/* 2414:3100 */             if (entryValue != null)
/* 2415:     */             {
/* 2416:3101 */               cause = RemovalCause.EXPLICIT;
/* 2417:     */             }
/* 2418:     */             else
/* 2419:     */             {
/* 2420:     */               RemovalCause cause;
/* 2421:3102 */               if (valueReference.isActive()) {
/* 2422:3103 */                 cause = RemovalCause.COLLECTED;
/* 2423:     */               } else {
/* 2424:3106 */                 return null;
/* 2425:     */               }
/* 2426:     */             }
/* 2427:     */             RemovalCause cause;
/* 2428:3109 */             this.modCount += 1;
/* 2429:3110 */             Object newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, cause);
/* 2430:     */             
/* 2431:3112 */             newCount = this.count - 1;
/* 2432:3113 */             table.set(index, newFirst);
/* 2433:3114 */             this.count = newCount;
/* 2434:3115 */             return entryValue;
/* 2435:     */           }
/* 2436:     */         }
/* 2437:3119 */         return null;
/* 2438:     */       }
/* 2439:     */       finally
/* 2440:     */       {
/* 2441:3121 */         unlock();
/* 2442:3122 */         postWriteCleanup();
/* 2443:     */       }
/* 2444:     */     }
/* 2445:     */     
/* 2446:     */     boolean storeLoadedValue(K key, int hash, LocalCache.LoadingValueReference<K, V> oldValueReference, V newValue)
/* 2447:     */     {
/* 2448:3128 */       lock();
/* 2449:     */       try
/* 2450:     */       {
/* 2451:3130 */         long now = this.map.ticker.read();
/* 2452:3131 */         preWriteCleanup(now);
/* 2453:     */         
/* 2454:3133 */         int newCount = this.count + 1;
/* 2455:3134 */         if (newCount > this.threshold)
/* 2456:     */         {
/* 2457:3135 */           expand();
/* 2458:3136 */           newCount = this.count + 1;
/* 2459:     */         }
/* 2460:3139 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2461:3140 */         int index = hash & table.length() - 1;
/* 2462:3141 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2463:     */         K entryKey;
/* 2464:3143 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2465:     */         {
/* 2466:3144 */           entryKey = e.getKey();
/* 2467:3145 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2468:     */           {
/* 2469:3147 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2470:3148 */             V entryValue = valueReference.get();
/* 2471:     */             RemovalCause cause;
/* 2472:3151 */             if ((oldValueReference == valueReference) || ((entryValue == null) && (valueReference != LocalCache.UNSET)))
/* 2473:     */             {
/* 2474:3153 */               this.modCount += 1;
/* 2475:3154 */               if (oldValueReference.isActive())
/* 2476:     */               {
/* 2477:3155 */                 cause = entryValue == null ? RemovalCause.COLLECTED : RemovalCause.REPLACED;
/* 2478:     */                 
/* 2479:3157 */                 enqueueNotification(key, hash, oldValueReference, cause);
/* 2480:3158 */                 newCount--;
/* 2481:     */               }
/* 2482:3160 */               setValue(e, key, newValue, now);
/* 2483:3161 */               this.count = newCount;
/* 2484:3162 */               evictEntries(e);
/* 2485:3163 */               return 1;
/* 2486:     */             }
/* 2487:3167 */             valueReference = new LocalCache.WeightedStrongValueReference(newValue, 0);
/* 2488:3168 */             enqueueNotification(key, hash, valueReference, RemovalCause.REPLACED);
/* 2489:3169 */             return 0;
/* 2490:     */           }
/* 2491:     */         }
/* 2492:3173 */         this.modCount += 1;
/* 2493:3174 */         LocalCache.ReferenceEntry<K, V> newEntry = newEntry(key, hash, first);
/* 2494:3175 */         setValue(newEntry, key, newValue, now);
/* 2495:3176 */         table.set(index, newEntry);
/* 2496:3177 */         this.count = newCount;
/* 2497:3178 */         evictEntries(newEntry);
/* 2498:3179 */         return 1;
/* 2499:     */       }
/* 2500:     */       finally
/* 2501:     */       {
/* 2502:3181 */         unlock();
/* 2503:3182 */         postWriteCleanup();
/* 2504:     */       }
/* 2505:     */     }
/* 2506:     */     
/* 2507:     */     boolean remove(Object key, int hash, Object value)
/* 2508:     */     {
/* 2509:3187 */       lock();
/* 2510:     */       try
/* 2511:     */       {
/* 2512:3189 */         long now = this.map.ticker.read();
/* 2513:3190 */         preWriteCleanup(now);
/* 2514:     */         
/* 2515:3192 */         int newCount = this.count - 1;
/* 2516:3193 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2517:3194 */         int index = hash & table.length() - 1;
/* 2518:3195 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2519:3197 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2520:     */         {
/* 2521:3198 */           K entryKey = e.getKey();
/* 2522:3199 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2523:     */           {
/* 2524:3201 */             LocalCache.ValueReference<K, V> valueReference = e.getValueReference();
/* 2525:3202 */             V entryValue = valueReference.get();
/* 2526:     */             RemovalCause cause;
/* 2527:3205 */             if (this.map.valueEquivalence.equivalent(value, entryValue))
/* 2528:     */             {
/* 2529:3206 */               cause = RemovalCause.EXPLICIT;
/* 2530:     */             }
/* 2531:     */             else
/* 2532:     */             {
/* 2533:     */               RemovalCause cause;
/* 2534:3207 */               if ((entryValue == null) && (valueReference.isActive())) {
/* 2535:3208 */                 cause = RemovalCause.COLLECTED;
/* 2536:     */               } else {
/* 2537:3211 */                 return false;
/* 2538:     */               }
/* 2539:     */             }
/* 2540:     */             RemovalCause cause;
/* 2541:3214 */             this.modCount += 1;
/* 2542:3215 */             Object newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, cause);
/* 2543:     */             
/* 2544:3217 */             newCount = this.count - 1;
/* 2545:3218 */             table.set(index, newFirst);
/* 2546:3219 */             this.count = newCount;
/* 2547:3220 */             return cause == RemovalCause.EXPLICIT;
/* 2548:     */           }
/* 2549:     */         }
/* 2550:3224 */         return 0;
/* 2551:     */       }
/* 2552:     */       finally
/* 2553:     */       {
/* 2554:3226 */         unlock();
/* 2555:3227 */         postWriteCleanup();
/* 2556:     */       }
/* 2557:     */     }
/* 2558:     */     
/* 2559:     */     void clear()
/* 2560:     */     {
/* 2561:3232 */       if (this.count != 0)
/* 2562:     */       {
/* 2563:3233 */         lock();
/* 2564:     */         try
/* 2565:     */         {
/* 2566:3235 */           AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2567:3236 */           for (int i = 0; i < table.length(); i++) {
/* 2568:3237 */             for (LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)table.get(i); e != null; e = e.getNext()) {
/* 2569:3239 */               if (e.getValueReference().isActive()) {
/* 2570:3240 */                 enqueueNotification(e, RemovalCause.EXPLICIT);
/* 2571:     */               }
/* 2572:     */             }
/* 2573:     */           }
/* 2574:3244 */           for (int i = 0; i < table.length(); i++) {
/* 2575:3245 */             table.set(i, null);
/* 2576:     */           }
/* 2577:3247 */           clearReferenceQueues();
/* 2578:3248 */           this.writeQueue.clear();
/* 2579:3249 */           this.accessQueue.clear();
/* 2580:3250 */           this.readCount.set(0);
/* 2581:     */           
/* 2582:3252 */           this.modCount += 1;
/* 2583:3253 */           this.count = 0;
/* 2584:     */         }
/* 2585:     */         finally
/* 2586:     */         {
/* 2587:3255 */           unlock();
/* 2588:3256 */           postWriteCleanup();
/* 2589:     */         }
/* 2590:     */       }
/* 2591:     */     }
/* 2592:     */     
/* 2593:     */     @Nullable
/* 2594:     */     @GuardedBy("this")
/* 2595:     */     LocalCache.ReferenceEntry<K, V> removeValueFromChain(LocalCache.ReferenceEntry<K, V> first, LocalCache.ReferenceEntry<K, V> entry, @Nullable K key, int hash, LocalCache.ValueReference<K, V> valueReference, RemovalCause cause)
/* 2596:     */     {
/* 2597:3266 */       enqueueNotification(key, hash, valueReference, cause);
/* 2598:3267 */       this.writeQueue.remove(entry);
/* 2599:3268 */       this.accessQueue.remove(entry);
/* 2600:3270 */       if (valueReference.isLoading())
/* 2601:     */       {
/* 2602:3271 */         valueReference.notifyNewValue(null);
/* 2603:3272 */         return first;
/* 2604:     */       }
/* 2605:3274 */       return removeEntryFromChain(first, entry);
/* 2606:     */     }
/* 2607:     */     
/* 2608:     */     @Nullable
/* 2609:     */     @GuardedBy("this")
/* 2610:     */     LocalCache.ReferenceEntry<K, V> removeEntryFromChain(LocalCache.ReferenceEntry<K, V> first, LocalCache.ReferenceEntry<K, V> entry)
/* 2611:     */     {
/* 2612:3282 */       int newCount = this.count;
/* 2613:3283 */       LocalCache.ReferenceEntry<K, V> newFirst = entry.getNext();
/* 2614:3284 */       for (LocalCache.ReferenceEntry<K, V> e = first; e != entry; e = e.getNext())
/* 2615:     */       {
/* 2616:3285 */         LocalCache.ReferenceEntry<K, V> next = copyEntry(e, newFirst);
/* 2617:3286 */         if (next != null)
/* 2618:     */         {
/* 2619:3287 */           newFirst = next;
/* 2620:     */         }
/* 2621:     */         else
/* 2622:     */         {
/* 2623:3289 */           removeCollectedEntry(e);
/* 2624:3290 */           newCount--;
/* 2625:     */         }
/* 2626:     */       }
/* 2627:3293 */       this.count = newCount;
/* 2628:3294 */       return newFirst;
/* 2629:     */     }
/* 2630:     */     
/* 2631:     */     @GuardedBy("this")
/* 2632:     */     void removeCollectedEntry(LocalCache.ReferenceEntry<K, V> entry)
/* 2633:     */     {
/* 2634:3299 */       enqueueNotification(entry, RemovalCause.COLLECTED);
/* 2635:3300 */       this.writeQueue.remove(entry);
/* 2636:3301 */       this.accessQueue.remove(entry);
/* 2637:     */     }
/* 2638:     */     
/* 2639:     */     boolean reclaimKey(LocalCache.ReferenceEntry<K, V> entry, int hash)
/* 2640:     */     {
/* 2641:3308 */       lock();
/* 2642:     */       try
/* 2643:     */       {
/* 2644:3310 */         int newCount = this.count - 1;
/* 2645:3311 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2646:3312 */         int index = hash & table.length() - 1;
/* 2647:3313 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2648:3315 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext()) {
/* 2649:3316 */           if (e == entry)
/* 2650:     */           {
/* 2651:3317 */             this.modCount += 1;
/* 2652:3318 */             LocalCache.ReferenceEntry<K, V> newFirst = removeValueFromChain(first, e, e.getKey(), hash, e.getValueReference(), RemovalCause.COLLECTED);
/* 2653:     */             
/* 2654:3320 */             newCount = this.count - 1;
/* 2655:3321 */             table.set(index, newFirst);
/* 2656:3322 */             this.count = newCount;
/* 2657:3323 */             return true;
/* 2658:     */           }
/* 2659:     */         }
/* 2660:3327 */         return 0;
/* 2661:     */       }
/* 2662:     */       finally
/* 2663:     */       {
/* 2664:3329 */         unlock();
/* 2665:3330 */         postWriteCleanup();
/* 2666:     */       }
/* 2667:     */     }
/* 2668:     */     
/* 2669:     */     boolean reclaimValue(K key, int hash, LocalCache.ValueReference<K, V> valueReference)
/* 2670:     */     {
/* 2671:3338 */       lock();
/* 2672:     */       try
/* 2673:     */       {
/* 2674:3340 */         int newCount = this.count - 1;
/* 2675:3341 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2676:3342 */         int index = hash & table.length() - 1;
/* 2677:3343 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2678:3345 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2679:     */         {
/* 2680:3346 */           K entryKey = e.getKey();
/* 2681:3347 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2682:     */           {
/* 2683:3349 */             LocalCache.ValueReference<K, V> v = e.getValueReference();
/* 2684:     */             LocalCache.ReferenceEntry<K, V> newFirst;
/* 2685:3350 */             if (v == valueReference)
/* 2686:     */             {
/* 2687:3351 */               this.modCount += 1;
/* 2688:3352 */               newFirst = removeValueFromChain(first, e, entryKey, hash, valueReference, RemovalCause.COLLECTED);
/* 2689:     */               
/* 2690:3354 */               newCount = this.count - 1;
/* 2691:3355 */               table.set(index, newFirst);
/* 2692:3356 */               this.count = newCount;
/* 2693:3357 */               return true;
/* 2694:     */             }
/* 2695:3359 */             return 0;
/* 2696:     */           }
/* 2697:     */         }
/* 2698:3363 */         return 0;
/* 2699:     */       }
/* 2700:     */       finally
/* 2701:     */       {
/* 2702:3365 */         unlock();
/* 2703:3366 */         if (!isHeldByCurrentThread()) {
/* 2704:3367 */           postWriteCleanup();
/* 2705:     */         }
/* 2706:     */       }
/* 2707:     */     }
/* 2708:     */     
/* 2709:     */     boolean removeLoadingValue(K key, int hash, LocalCache.LoadingValueReference<K, V> valueReference)
/* 2710:     */     {
/* 2711:3373 */       lock();
/* 2712:     */       try
/* 2713:     */       {
/* 2714:3375 */         AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2715:3376 */         int index = hash & table.length() - 1;
/* 2716:3377 */         LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2717:3379 */         for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2718:     */         {
/* 2719:3380 */           K entryKey = e.getKey();
/* 2720:3381 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2721:     */           {
/* 2722:3383 */             LocalCache.ValueReference<K, V> v = e.getValueReference();
/* 2723:     */             LocalCache.ReferenceEntry<K, V> newFirst;
/* 2724:3384 */             if (v == valueReference)
/* 2725:     */             {
/* 2726:3385 */               if (valueReference.isActive())
/* 2727:     */               {
/* 2728:3386 */                 e.setValueReference(valueReference.getOldValue());
/* 2729:     */               }
/* 2730:     */               else
/* 2731:     */               {
/* 2732:3388 */                 newFirst = removeEntryFromChain(first, e);
/* 2733:3389 */                 table.set(index, newFirst);
/* 2734:     */               }
/* 2735:3391 */               return 1;
/* 2736:     */             }
/* 2737:3393 */             return 0;
/* 2738:     */           }
/* 2739:     */         }
/* 2740:3397 */         return 0;
/* 2741:     */       }
/* 2742:     */       finally
/* 2743:     */       {
/* 2744:3399 */         unlock();
/* 2745:3400 */         postWriteCleanup();
/* 2746:     */       }
/* 2747:     */     }
/* 2748:     */     
/* 2749:     */     @GuardedBy("this")
/* 2750:     */     boolean removeEntry(LocalCache.ReferenceEntry<K, V> entry, int hash, RemovalCause cause)
/* 2751:     */     {
/* 2752:3406 */       int newCount = this.count - 1;
/* 2753:3407 */       AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> table = this.table;
/* 2754:3408 */       int index = hash & table.length() - 1;
/* 2755:3409 */       LocalCache.ReferenceEntry<K, V> first = (LocalCache.ReferenceEntry)table.get(index);
/* 2756:3411 */       for (LocalCache.ReferenceEntry<K, V> e = first; e != null; e = e.getNext()) {
/* 2757:3412 */         if (e == entry)
/* 2758:     */         {
/* 2759:3413 */           this.modCount += 1;
/* 2760:3414 */           LocalCache.ReferenceEntry<K, V> newFirst = removeValueFromChain(first, e, e.getKey(), hash, e.getValueReference(), cause);
/* 2761:     */           
/* 2762:3416 */           newCount = this.count - 1;
/* 2763:3417 */           table.set(index, newFirst);
/* 2764:3418 */           this.count = newCount;
/* 2765:3419 */           return true;
/* 2766:     */         }
/* 2767:     */       }
/* 2768:3423 */       return false;
/* 2769:     */     }
/* 2770:     */     
/* 2771:     */     void postReadCleanup()
/* 2772:     */     {
/* 2773:3431 */       if ((this.readCount.incrementAndGet() & 0x3F) == 0) {
/* 2774:3432 */         cleanUp();
/* 2775:     */       }
/* 2776:     */     }
/* 2777:     */     
/* 2778:     */     @GuardedBy("this")
/* 2779:     */     void preWriteCleanup(long now)
/* 2780:     */     {
/* 2781:3444 */       runLockedCleanup(now);
/* 2782:     */     }
/* 2783:     */     
/* 2784:     */     void postWriteCleanup()
/* 2785:     */     {
/* 2786:3451 */       runUnlockedCleanup();
/* 2787:     */     }
/* 2788:     */     
/* 2789:     */     void cleanUp()
/* 2790:     */     {
/* 2791:3455 */       long now = this.map.ticker.read();
/* 2792:3456 */       runLockedCleanup(now);
/* 2793:3457 */       runUnlockedCleanup();
/* 2794:     */     }
/* 2795:     */     
/* 2796:     */     void runLockedCleanup(long now)
/* 2797:     */     {
/* 2798:3461 */       if (tryLock()) {
/* 2799:     */         try
/* 2800:     */         {
/* 2801:3463 */           drainReferenceQueues();
/* 2802:3464 */           expireEntries(now);
/* 2803:3465 */           this.readCount.set(0);
/* 2804:     */         }
/* 2805:     */         finally
/* 2806:     */         {
/* 2807:3467 */           unlock();
/* 2808:     */         }
/* 2809:     */       }
/* 2810:     */     }
/* 2811:     */     
/* 2812:     */     void runUnlockedCleanup()
/* 2813:     */     {
/* 2814:3474 */       if (!isHeldByCurrentThread()) {
/* 2815:3475 */         this.map.processPendingNotifications();
/* 2816:     */       }
/* 2817:     */     }
/* 2818:     */   }
/* 2819:     */   
/* 2820:     */   static class LoadingValueReference<K, V>
/* 2821:     */     implements LocalCache.ValueReference<K, V>
/* 2822:     */   {
/* 2823:     */     volatile LocalCache.ValueReference<K, V> oldValue;
/* 2824:3485 */     final SettableFuture<V> futureValue = SettableFuture.create();
/* 2825:3486 */     final Stopwatch stopwatch = Stopwatch.createUnstarted();
/* 2826:     */     
/* 2827:     */     public LoadingValueReference()
/* 2828:     */     {
/* 2829:3489 */       this(LocalCache.unset());
/* 2830:     */     }
/* 2831:     */     
/* 2832:     */     public LoadingValueReference(LocalCache.ValueReference<K, V> oldValue)
/* 2833:     */     {
/* 2834:3493 */       this.oldValue = oldValue;
/* 2835:     */     }
/* 2836:     */     
/* 2837:     */     public boolean isLoading()
/* 2838:     */     {
/* 2839:3498 */       return true;
/* 2840:     */     }
/* 2841:     */     
/* 2842:     */     public boolean isActive()
/* 2843:     */     {
/* 2844:3503 */       return this.oldValue.isActive();
/* 2845:     */     }
/* 2846:     */     
/* 2847:     */     public int getWeight()
/* 2848:     */     {
/* 2849:3508 */       return this.oldValue.getWeight();
/* 2850:     */     }
/* 2851:     */     
/* 2852:     */     public boolean set(@Nullable V newValue)
/* 2853:     */     {
/* 2854:3512 */       return this.futureValue.set(newValue);
/* 2855:     */     }
/* 2856:     */     
/* 2857:     */     public boolean setException(Throwable t)
/* 2858:     */     {
/* 2859:3516 */       return this.futureValue.setException(t);
/* 2860:     */     }
/* 2861:     */     
/* 2862:     */     private ListenableFuture<V> fullyFailedFuture(Throwable t)
/* 2863:     */     {
/* 2864:3520 */       return Futures.immediateFailedFuture(t);
/* 2865:     */     }
/* 2866:     */     
/* 2867:     */     public void notifyNewValue(@Nullable V newValue)
/* 2868:     */     {
/* 2869:3525 */       if (newValue != null) {
/* 2870:3528 */         set(newValue);
/* 2871:     */       } else {
/* 2872:3531 */         this.oldValue = LocalCache.unset();
/* 2873:     */       }
/* 2874:     */     }
/* 2875:     */     
/* 2876:     */     public ListenableFuture<V> loadFuture(K key, CacheLoader<? super K, V> loader)
/* 2877:     */     {
/* 2878:     */       try
/* 2879:     */       {
/* 2880:3539 */         this.stopwatch.start();
/* 2881:3540 */         V previousValue = this.oldValue.get();
/* 2882:3541 */         if (previousValue == null)
/* 2883:     */         {
/* 2884:3542 */           V newValue = loader.load(key);
/* 2885:3543 */           return set(newValue) ? this.futureValue : Futures.immediateFuture(newValue);
/* 2886:     */         }
/* 2887:3545 */         ListenableFuture<V> newValue = loader.reload(key, previousValue);
/* 2888:3546 */         if (newValue == null) {
/* 2889:3547 */           return Futures.immediateFuture(null);
/* 2890:     */         }
/* 2891:3551 */         Futures.transform(newValue, new Function()
/* 2892:     */         {
/* 2893:     */           public V apply(V newValue)
/* 2894:     */           {
/* 2895:3554 */             LocalCache.LoadingValueReference.this.set(newValue);
/* 2896:3555 */             return newValue;
/* 2897:     */           }
/* 2898:     */         });
/* 2899:     */       }
/* 2900:     */       catch (Throwable t)
/* 2901:     */       {
/* 2902:3559 */         ListenableFuture<V> result = setException(t) ? this.futureValue : fullyFailedFuture(t);
/* 2903:3560 */         if ((t instanceof InterruptedException)) {
/* 2904:3561 */           Thread.currentThread().interrupt();
/* 2905:     */         }
/* 2906:3563 */         return result;
/* 2907:     */       }
/* 2908:     */     }
/* 2909:     */     
/* 2910:     */     public long elapsedNanos()
/* 2911:     */     {
/* 2912:3568 */       return this.stopwatch.elapsed(TimeUnit.NANOSECONDS);
/* 2913:     */     }
/* 2914:     */     
/* 2915:     */     public V waitForValue()
/* 2916:     */       throws ExecutionException
/* 2917:     */     {
/* 2918:3573 */       return Uninterruptibles.getUninterruptibly(this.futureValue);
/* 2919:     */     }
/* 2920:     */     
/* 2921:     */     public V get()
/* 2922:     */     {
/* 2923:3578 */       return this.oldValue.get();
/* 2924:     */     }
/* 2925:     */     
/* 2926:     */     public LocalCache.ValueReference<K, V> getOldValue()
/* 2927:     */     {
/* 2928:3582 */       return this.oldValue;
/* 2929:     */     }
/* 2930:     */     
/* 2931:     */     public LocalCache.ReferenceEntry<K, V> getEntry()
/* 2932:     */     {
/* 2933:3587 */       return null;
/* 2934:     */     }
/* 2935:     */     
/* 2936:     */     public LocalCache.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, @Nullable V value, LocalCache.ReferenceEntry<K, V> entry)
/* 2937:     */     {
/* 2938:3593 */       return this;
/* 2939:     */     }
/* 2940:     */   }
/* 2941:     */   
/* 2942:     */   static final class WriteQueue<K, V>
/* 2943:     */     extends AbstractQueue<LocalCache.ReferenceEntry<K, V>>
/* 2944:     */   {
/* 2945:3611 */     final LocalCache.ReferenceEntry<K, V> head = new LocalCache.AbstractReferenceEntry()
/* 2946:     */     {
/* 2947:     */       public long getWriteTime()
/* 2948:     */       {
/* 2949:3615 */         return 9223372036854775807L;
/* 2950:     */       }
/* 2951:     */       
/* 2952:3621 */       LocalCache.ReferenceEntry<K, V> nextWrite = this;
/* 2953:     */       
/* 2954:     */       public void setWriteTime(long time) {}
/* 2955:     */       
/* 2956:     */       public LocalCache.ReferenceEntry<K, V> getNextInWriteQueue()
/* 2957:     */       {
/* 2958:3625 */         return this.nextWrite;
/* 2959:     */       }
/* 2960:     */       
/* 2961:     */       public void setNextInWriteQueue(LocalCache.ReferenceEntry<K, V> next)
/* 2962:     */       {
/* 2963:3630 */         this.nextWrite = next;
/* 2964:     */       }
/* 2965:     */       
/* 2966:3633 */       LocalCache.ReferenceEntry<K, V> previousWrite = this;
/* 2967:     */       
/* 2968:     */       public LocalCache.ReferenceEntry<K, V> getPreviousInWriteQueue()
/* 2969:     */       {
/* 2970:3637 */         return this.previousWrite;
/* 2971:     */       }
/* 2972:     */       
/* 2973:     */       public void setPreviousInWriteQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 2974:     */       {
/* 2975:3642 */         this.previousWrite = previous;
/* 2976:     */       }
/* 2977:     */     };
/* 2978:     */     
/* 2979:     */     public boolean offer(LocalCache.ReferenceEntry<K, V> entry)
/* 2980:     */     {
/* 2981:3651 */       LocalCache.connectWriteOrder(entry.getPreviousInWriteQueue(), entry.getNextInWriteQueue());
/* 2982:     */       
/* 2983:     */ 
/* 2984:3654 */       LocalCache.connectWriteOrder(this.head.getPreviousInWriteQueue(), entry);
/* 2985:3655 */       LocalCache.connectWriteOrder(entry, this.head);
/* 2986:     */       
/* 2987:3657 */       return true;
/* 2988:     */     }
/* 2989:     */     
/* 2990:     */     public LocalCache.ReferenceEntry<K, V> peek()
/* 2991:     */     {
/* 2992:3662 */       LocalCache.ReferenceEntry<K, V> next = this.head.getNextInWriteQueue();
/* 2993:3663 */       return next == this.head ? null : next;
/* 2994:     */     }
/* 2995:     */     
/* 2996:     */     public LocalCache.ReferenceEntry<K, V> poll()
/* 2997:     */     {
/* 2998:3668 */       LocalCache.ReferenceEntry<K, V> next = this.head.getNextInWriteQueue();
/* 2999:3669 */       if (next == this.head) {
/* 3000:3670 */         return null;
/* 3001:     */       }
/* 3002:3673 */       remove(next);
/* 3003:3674 */       return next;
/* 3004:     */     }
/* 3005:     */     
/* 3006:     */     public boolean remove(Object o)
/* 3007:     */     {
/* 3008:3680 */       LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)o;
/* 3009:3681 */       LocalCache.ReferenceEntry<K, V> previous = e.getPreviousInWriteQueue();
/* 3010:3682 */       LocalCache.ReferenceEntry<K, V> next = e.getNextInWriteQueue();
/* 3011:3683 */       LocalCache.connectWriteOrder(previous, next);
/* 3012:3684 */       LocalCache.nullifyWriteOrder(e);
/* 3013:     */       
/* 3014:3686 */       return next != LocalCache.NullEntry.INSTANCE;
/* 3015:     */     }
/* 3016:     */     
/* 3017:     */     public boolean contains(Object o)
/* 3018:     */     {
/* 3019:3692 */       LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)o;
/* 3020:3693 */       return e.getNextInWriteQueue() != LocalCache.NullEntry.INSTANCE;
/* 3021:     */     }
/* 3022:     */     
/* 3023:     */     public boolean isEmpty()
/* 3024:     */     {
/* 3025:3698 */       return this.head.getNextInWriteQueue() == this.head;
/* 3026:     */     }
/* 3027:     */     
/* 3028:     */     public int size()
/* 3029:     */     {
/* 3030:3703 */       int size = 0;
/* 3031:3704 */       for (LocalCache.ReferenceEntry<K, V> e = this.head.getNextInWriteQueue(); e != this.head; e = e.getNextInWriteQueue()) {
/* 3032:3706 */         size++;
/* 3033:     */       }
/* 3034:3708 */       return size;
/* 3035:     */     }
/* 3036:     */     
/* 3037:     */     public void clear()
/* 3038:     */     {
/* 3039:3713 */       LocalCache.ReferenceEntry<K, V> e = this.head.getNextInWriteQueue();
/* 3040:3714 */       while (e != this.head)
/* 3041:     */       {
/* 3042:3715 */         LocalCache.ReferenceEntry<K, V> next = e.getNextInWriteQueue();
/* 3043:3716 */         LocalCache.nullifyWriteOrder(e);
/* 3044:3717 */         e = next;
/* 3045:     */       }
/* 3046:3720 */       this.head.setNextInWriteQueue(this.head);
/* 3047:3721 */       this.head.setPreviousInWriteQueue(this.head);
/* 3048:     */     }
/* 3049:     */     
/* 3050:     */     public Iterator<LocalCache.ReferenceEntry<K, V>> iterator()
/* 3051:     */     {
/* 3052:3726 */       new AbstractSequentialIterator(peek())
/* 3053:     */       {
/* 3054:     */         protected LocalCache.ReferenceEntry<K, V> computeNext(LocalCache.ReferenceEntry<K, V> previous)
/* 3055:     */         {
/* 3056:3729 */           LocalCache.ReferenceEntry<K, V> next = previous.getNextInWriteQueue();
/* 3057:3730 */           return next == LocalCache.WriteQueue.this.head ? null : next;
/* 3058:     */         }
/* 3059:     */       };
/* 3060:     */     }
/* 3061:     */   }
/* 3062:     */   
/* 3063:     */   static final class AccessQueue<K, V>
/* 3064:     */     extends AbstractQueue<LocalCache.ReferenceEntry<K, V>>
/* 3065:     */   {
/* 3066:3748 */     final LocalCache.ReferenceEntry<K, V> head = new LocalCache.AbstractReferenceEntry()
/* 3067:     */     {
/* 3068:     */       public long getAccessTime()
/* 3069:     */       {
/* 3070:3752 */         return 9223372036854775807L;
/* 3071:     */       }
/* 3072:     */       
/* 3073:3758 */       LocalCache.ReferenceEntry<K, V> nextAccess = this;
/* 3074:     */       
/* 3075:     */       public void setAccessTime(long time) {}
/* 3076:     */       
/* 3077:     */       public LocalCache.ReferenceEntry<K, V> getNextInAccessQueue()
/* 3078:     */       {
/* 3079:3762 */         return this.nextAccess;
/* 3080:     */       }
/* 3081:     */       
/* 3082:     */       public void setNextInAccessQueue(LocalCache.ReferenceEntry<K, V> next)
/* 3083:     */       {
/* 3084:3767 */         this.nextAccess = next;
/* 3085:     */       }
/* 3086:     */       
/* 3087:3770 */       LocalCache.ReferenceEntry<K, V> previousAccess = this;
/* 3088:     */       
/* 3089:     */       public LocalCache.ReferenceEntry<K, V> getPreviousInAccessQueue()
/* 3090:     */       {
/* 3091:3774 */         return this.previousAccess;
/* 3092:     */       }
/* 3093:     */       
/* 3094:     */       public void setPreviousInAccessQueue(LocalCache.ReferenceEntry<K, V> previous)
/* 3095:     */       {
/* 3096:3779 */         this.previousAccess = previous;
/* 3097:     */       }
/* 3098:     */     };
/* 3099:     */     
/* 3100:     */     public boolean offer(LocalCache.ReferenceEntry<K, V> entry)
/* 3101:     */     {
/* 3102:3788 */       LocalCache.connectAccessOrder(entry.getPreviousInAccessQueue(), entry.getNextInAccessQueue());
/* 3103:     */       
/* 3104:     */ 
/* 3105:3791 */       LocalCache.connectAccessOrder(this.head.getPreviousInAccessQueue(), entry);
/* 3106:3792 */       LocalCache.connectAccessOrder(entry, this.head);
/* 3107:     */       
/* 3108:3794 */       return true;
/* 3109:     */     }
/* 3110:     */     
/* 3111:     */     public LocalCache.ReferenceEntry<K, V> peek()
/* 3112:     */     {
/* 3113:3799 */       LocalCache.ReferenceEntry<K, V> next = this.head.getNextInAccessQueue();
/* 3114:3800 */       return next == this.head ? null : next;
/* 3115:     */     }
/* 3116:     */     
/* 3117:     */     public LocalCache.ReferenceEntry<K, V> poll()
/* 3118:     */     {
/* 3119:3805 */       LocalCache.ReferenceEntry<K, V> next = this.head.getNextInAccessQueue();
/* 3120:3806 */       if (next == this.head) {
/* 3121:3807 */         return null;
/* 3122:     */       }
/* 3123:3810 */       remove(next);
/* 3124:3811 */       return next;
/* 3125:     */     }
/* 3126:     */     
/* 3127:     */     public boolean remove(Object o)
/* 3128:     */     {
/* 3129:3817 */       LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)o;
/* 3130:3818 */       LocalCache.ReferenceEntry<K, V> previous = e.getPreviousInAccessQueue();
/* 3131:3819 */       LocalCache.ReferenceEntry<K, V> next = e.getNextInAccessQueue();
/* 3132:3820 */       LocalCache.connectAccessOrder(previous, next);
/* 3133:3821 */       LocalCache.nullifyAccessOrder(e);
/* 3134:     */       
/* 3135:3823 */       return next != LocalCache.NullEntry.INSTANCE;
/* 3136:     */     }
/* 3137:     */     
/* 3138:     */     public boolean contains(Object o)
/* 3139:     */     {
/* 3140:3829 */       LocalCache.ReferenceEntry<K, V> e = (LocalCache.ReferenceEntry)o;
/* 3141:3830 */       return e.getNextInAccessQueue() != LocalCache.NullEntry.INSTANCE;
/* 3142:     */     }
/* 3143:     */     
/* 3144:     */     public boolean isEmpty()
/* 3145:     */     {
/* 3146:3835 */       return this.head.getNextInAccessQueue() == this.head;
/* 3147:     */     }
/* 3148:     */     
/* 3149:     */     public int size()
/* 3150:     */     {
/* 3151:3840 */       int size = 0;
/* 3152:3841 */       for (LocalCache.ReferenceEntry<K, V> e = this.head.getNextInAccessQueue(); e != this.head; e = e.getNextInAccessQueue()) {
/* 3153:3843 */         size++;
/* 3154:     */       }
/* 3155:3845 */       return size;
/* 3156:     */     }
/* 3157:     */     
/* 3158:     */     public void clear()
/* 3159:     */     {
/* 3160:3850 */       LocalCache.ReferenceEntry<K, V> e = this.head.getNextInAccessQueue();
/* 3161:3851 */       while (e != this.head)
/* 3162:     */       {
/* 3163:3852 */         LocalCache.ReferenceEntry<K, V> next = e.getNextInAccessQueue();
/* 3164:3853 */         LocalCache.nullifyAccessOrder(e);
/* 3165:3854 */         e = next;
/* 3166:     */       }
/* 3167:3857 */       this.head.setNextInAccessQueue(this.head);
/* 3168:3858 */       this.head.setPreviousInAccessQueue(this.head);
/* 3169:     */     }
/* 3170:     */     
/* 3171:     */     public Iterator<LocalCache.ReferenceEntry<K, V>> iterator()
/* 3172:     */     {
/* 3173:3863 */       new AbstractSequentialIterator(peek())
/* 3174:     */       {
/* 3175:     */         protected LocalCache.ReferenceEntry<K, V> computeNext(LocalCache.ReferenceEntry<K, V> previous)
/* 3176:     */         {
/* 3177:3866 */           LocalCache.ReferenceEntry<K, V> next = previous.getNextInAccessQueue();
/* 3178:3867 */           return next == LocalCache.AccessQueue.this.head ? null : next;
/* 3179:     */         }
/* 3180:     */       };
/* 3181:     */     }
/* 3182:     */   }
/* 3183:     */   
/* 3184:     */   public void cleanUp()
/* 3185:     */   {
/* 3186:3876 */     for (Segment<?, ?> segment : this.segments) {
/* 3187:3877 */       segment.cleanUp();
/* 3188:     */     }
/* 3189:     */   }
/* 3190:     */   
/* 3191:     */   public boolean isEmpty()
/* 3192:     */   {
/* 3193:3892 */     long sum = 0L;
/* 3194:3893 */     Segment<K, V>[] segments = this.segments;
/* 3195:3894 */     for (int i = 0; i < segments.length; i++)
/* 3196:     */     {
/* 3197:3895 */       if (segments[i].count != 0) {
/* 3198:3896 */         return false;
/* 3199:     */       }
/* 3200:3898 */       sum += segments[i].modCount;
/* 3201:     */     }
/* 3202:3901 */     if (sum != 0L)
/* 3203:     */     {
/* 3204:3902 */       for (int i = 0; i < segments.length; i++)
/* 3205:     */       {
/* 3206:3903 */         if (segments[i].count != 0) {
/* 3207:3904 */           return false;
/* 3208:     */         }
/* 3209:3906 */         sum -= segments[i].modCount;
/* 3210:     */       }
/* 3211:3908 */       if (sum != 0L) {
/* 3212:3909 */         return false;
/* 3213:     */       }
/* 3214:     */     }
/* 3215:3912 */     return true;
/* 3216:     */   }
/* 3217:     */   
/* 3218:     */   long longSize()
/* 3219:     */   {
/* 3220:3916 */     Segment<K, V>[] segments = this.segments;
/* 3221:3917 */     long sum = 0L;
/* 3222:3918 */     for (int i = 0; i < segments.length; i++) {
/* 3223:3919 */       sum += Math.max(0, segments[i].count);
/* 3224:     */     }
/* 3225:3921 */     return sum;
/* 3226:     */   }
/* 3227:     */   
/* 3228:     */   public int size()
/* 3229:     */   {
/* 3230:3926 */     return Ints.saturatedCast(longSize());
/* 3231:     */   }
/* 3232:     */   
/* 3233:     */   @Nullable
/* 3234:     */   public V get(@Nullable Object key)
/* 3235:     */   {
/* 3236:3932 */     if (key == null) {
/* 3237:3933 */       return null;
/* 3238:     */     }
/* 3239:3935 */     int hash = hash(key);
/* 3240:3936 */     return segmentFor(hash).get(key, hash);
/* 3241:     */   }
/* 3242:     */   
/* 3243:     */   @Nullable
/* 3244:     */   public V getIfPresent(Object key)
/* 3245:     */   {
/* 3246:3941 */     int hash = hash(Preconditions.checkNotNull(key));
/* 3247:3942 */     V value = segmentFor(hash).get(key, hash);
/* 3248:3943 */     if (value == null) {
/* 3249:3944 */       this.globalStatsCounter.recordMisses(1);
/* 3250:     */     } else {
/* 3251:3946 */       this.globalStatsCounter.recordHits(1);
/* 3252:     */     }
/* 3253:3948 */     return value;
/* 3254:     */   }
/* 3255:     */   
/* 3256:     */   V get(K key, CacheLoader<? super K, V> loader)
/* 3257:     */     throws ExecutionException
/* 3258:     */   {
/* 3259:3952 */     int hash = hash(Preconditions.checkNotNull(key));
/* 3260:3953 */     return segmentFor(hash).get(key, hash, loader);
/* 3261:     */   }
/* 3262:     */   
/* 3263:     */   V getOrLoad(K key)
/* 3264:     */     throws ExecutionException
/* 3265:     */   {
/* 3266:3957 */     return get(key, this.defaultLoader);
/* 3267:     */   }
/* 3268:     */   
/* 3269:     */   ImmutableMap<K, V> getAllPresent(Iterable<?> keys)
/* 3270:     */   {
/* 3271:3961 */     int hits = 0;
/* 3272:3962 */     int misses = 0;
/* 3273:     */     
/* 3274:3964 */     Map<K, V> result = Maps.newLinkedHashMap();
/* 3275:3965 */     for (Object key : keys)
/* 3276:     */     {
/* 3277:3966 */       V value = get(key);
/* 3278:3967 */       if (value == null)
/* 3279:     */       {
/* 3280:3968 */         misses++;
/* 3281:     */       }
/* 3282:     */       else
/* 3283:     */       {
/* 3284:3972 */         K castKey = key;
/* 3285:3973 */         result.put(castKey, value);
/* 3286:3974 */         hits++;
/* 3287:     */       }
/* 3288:     */     }
/* 3289:3977 */     this.globalStatsCounter.recordHits(hits);
/* 3290:3978 */     this.globalStatsCounter.recordMisses(misses);
/* 3291:3979 */     return ImmutableMap.copyOf(result);
/* 3292:     */   }
/* 3293:     */   
/* 3294:     */   ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 3295:     */     throws ExecutionException
/* 3296:     */   {
/* 3297:3983 */     int hits = 0;
/* 3298:3984 */     int misses = 0;
/* 3299:     */     
/* 3300:3986 */     Map<K, V> result = Maps.newLinkedHashMap();
/* 3301:3987 */     Set<K> keysToLoad = Sets.newLinkedHashSet();
/* 3302:3988 */     for (K key : keys)
/* 3303:     */     {
/* 3304:3989 */       V value = get(key);
/* 3305:3990 */       if (!result.containsKey(key))
/* 3306:     */       {
/* 3307:3991 */         result.put(key, value);
/* 3308:3992 */         if (value == null)
/* 3309:     */         {
/* 3310:3993 */           misses++;
/* 3311:3994 */           keysToLoad.add(key);
/* 3312:     */         }
/* 3313:     */         else
/* 3314:     */         {
/* 3315:3996 */           hits++;
/* 3316:     */         }
/* 3317:     */       }
/* 3318:     */     }
/* 3319:     */     try
/* 3320:     */     {
/* 3321:4002 */       if (!keysToLoad.isEmpty())
/* 3322:     */       {
/* 3323:     */         Iterator i$;
/* 3324:     */         try
/* 3325:     */         {
/* 3326:4004 */           newEntries = loadAll(keysToLoad, this.defaultLoader);
/* 3327:4005 */           for (K key : keysToLoad)
/* 3328:     */           {
/* 3329:4006 */             V value = newEntries.get(key);
/* 3330:4007 */             if (value == null) {
/* 3331:4008 */               throw new CacheLoader.InvalidCacheLoadException("loadAll failed to return a value for " + key);
/* 3332:     */             }
/* 3333:4010 */             result.put(key, value);
/* 3334:     */           }
/* 3335:     */         }
/* 3336:     */         catch (CacheLoader.UnsupportedLoadingOperationException e)
/* 3337:     */         {
/* 3338:     */           Map<K, V> newEntries;
/* 3339:4014 */           i$ = keysToLoad.iterator();
/* 3340:     */         }
/* 3341:4014 */         while (i$.hasNext())
/* 3342:     */         {
/* 3343:4014 */           K key = i$.next();
/* 3344:4015 */           misses--;
/* 3345:4016 */           result.put(key, get(key, this.defaultLoader));
/* 3346:     */         }
/* 3347:     */       }
/* 3348:4020 */       return ImmutableMap.copyOf(result);
/* 3349:     */     }
/* 3350:     */     finally
/* 3351:     */     {
/* 3352:4022 */       this.globalStatsCounter.recordHits(hits);
/* 3353:4023 */       this.globalStatsCounter.recordMisses(misses);
/* 3354:     */     }
/* 3355:     */   }
/* 3356:     */   
/* 3357:     */   @Nullable
/* 3358:     */   Map<K, V> loadAll(Set<? extends K> keys, CacheLoader<? super K, V> loader)
/* 3359:     */     throws ExecutionException
/* 3360:     */   {
/* 3361:4034 */     Preconditions.checkNotNull(loader);
/* 3362:4035 */     Preconditions.checkNotNull(keys);
/* 3363:4036 */     Stopwatch stopwatch = Stopwatch.createStarted();
/* 3364:     */     
/* 3365:4038 */     boolean success = false;
/* 3366:     */     Map<K, V> result;
/* 3367:     */     try
/* 3368:     */     {
/* 3369:4041 */       Map<K, V> map = loader.loadAll(keys);
/* 3370:4042 */       result = map;
/* 3371:4043 */       success = true;
/* 3372:     */     }
/* 3373:     */     catch (CacheLoader.UnsupportedLoadingOperationException e)
/* 3374:     */     {
/* 3375:4045 */       success = true;
/* 3376:4046 */       throw e;
/* 3377:     */     }
/* 3378:     */     catch (InterruptedException e)
/* 3379:     */     {
/* 3380:4048 */       Thread.currentThread().interrupt();
/* 3381:4049 */       throw new ExecutionException(e);
/* 3382:     */     }
/* 3383:     */     catch (RuntimeException e)
/* 3384:     */     {
/* 3385:4051 */       throw new UncheckedExecutionException(e);
/* 3386:     */     }
/* 3387:     */     catch (Exception e)
/* 3388:     */     {
/* 3389:4053 */       throw new ExecutionException(e);
/* 3390:     */     }
/* 3391:     */     catch (Error e)
/* 3392:     */     {
/* 3393:4055 */       throw new ExecutionError(e);
/* 3394:     */     }
/* 3395:     */     finally
/* 3396:     */     {
/* 3397:4057 */       if (!success) {
/* 3398:4058 */         this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
/* 3399:     */       }
/* 3400:     */     }
/* 3401:4062 */     if (result == null)
/* 3402:     */     {
/* 3403:4063 */       this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
/* 3404:4064 */       throw new CacheLoader.InvalidCacheLoadException(loader + " returned null map from loadAll");
/* 3405:     */     }
/* 3406:4067 */     stopwatch.stop();
/* 3407:     */     
/* 3408:4069 */     boolean nullsPresent = false;
/* 3409:4070 */     for (Map.Entry<K, V> entry : result.entrySet())
/* 3410:     */     {
/* 3411:4071 */       K key = entry.getKey();
/* 3412:4072 */       V value = entry.getValue();
/* 3413:4073 */       if ((key == null) || (value == null)) {
/* 3414:4075 */         nullsPresent = true;
/* 3415:     */       } else {
/* 3416:4077 */         put(key, value);
/* 3417:     */       }
/* 3418:     */     }
/* 3419:4081 */     if (nullsPresent)
/* 3420:     */     {
/* 3421:4082 */       this.globalStatsCounter.recordLoadException(stopwatch.elapsed(TimeUnit.NANOSECONDS));
/* 3422:4083 */       throw new CacheLoader.InvalidCacheLoadException(loader + " returned null keys or values from loadAll");
/* 3423:     */     }
/* 3424:4087 */     this.globalStatsCounter.recordLoadSuccess(stopwatch.elapsed(TimeUnit.NANOSECONDS));
/* 3425:4088 */     return result;
/* 3426:     */   }
/* 3427:     */   
/* 3428:     */   ReferenceEntry<K, V> getEntry(@Nullable Object key)
/* 3429:     */   {
/* 3430:4097 */     if (key == null) {
/* 3431:4098 */       return null;
/* 3432:     */     }
/* 3433:4100 */     int hash = hash(key);
/* 3434:4101 */     return segmentFor(hash).getEntry(key, hash);
/* 3435:     */   }
/* 3436:     */   
/* 3437:     */   void refresh(K key)
/* 3438:     */   {
/* 3439:4105 */     int hash = hash(Preconditions.checkNotNull(key));
/* 3440:4106 */     segmentFor(hash).refresh(key, hash, this.defaultLoader, false);
/* 3441:     */   }
/* 3442:     */   
/* 3443:     */   public boolean containsKey(@Nullable Object key)
/* 3444:     */   {
/* 3445:4112 */     if (key == null) {
/* 3446:4113 */       return false;
/* 3447:     */     }
/* 3448:4115 */     int hash = hash(key);
/* 3449:4116 */     return segmentFor(hash).containsKey(key, hash);
/* 3450:     */   }
/* 3451:     */   
/* 3452:     */   public boolean containsValue(@Nullable Object value)
/* 3453:     */   {
/* 3454:4122 */     if (value == null) {
/* 3455:4123 */       return false;
/* 3456:     */     }
/* 3457:4131 */     long now = this.ticker.read();
/* 3458:4132 */     Segment<K, V>[] segments = this.segments;
/* 3459:4133 */     long last = -1L;
/* 3460:4134 */     for (int i = 0; i < 3; i++)
/* 3461:     */     {
/* 3462:4135 */       long sum = 0L;
/* 3463:4136 */       for (Segment<K, V> segment : segments)
/* 3464:     */       {
/* 3465:4138 */         int unused = segment.count;
/* 3466:     */         
/* 3467:4140 */         AtomicReferenceArray<ReferenceEntry<K, V>> table = segment.table;
/* 3468:4141 */         for (int j = 0; j < table.length(); j++) {
/* 3469:4142 */           for (ReferenceEntry<K, V> e = (ReferenceEntry)table.get(j); e != null; e = e.getNext())
/* 3470:     */           {
/* 3471:4143 */             V v = segment.getLiveValue(e, now);
/* 3472:4144 */             if ((v != null) && (this.valueEquivalence.equivalent(value, v))) {
/* 3473:4145 */               return true;
/* 3474:     */             }
/* 3475:     */           }
/* 3476:     */         }
/* 3477:4149 */         sum += segment.modCount;
/* 3478:     */       }
/* 3479:4151 */       if (sum == last) {
/* 3480:     */         break;
/* 3481:     */       }
/* 3482:4154 */       last = sum;
/* 3483:     */     }
/* 3484:4156 */     return false;
/* 3485:     */   }
/* 3486:     */   
/* 3487:     */   public V put(K key, V value)
/* 3488:     */   {
/* 3489:4161 */     Preconditions.checkNotNull(key);
/* 3490:4162 */     Preconditions.checkNotNull(value);
/* 3491:4163 */     int hash = hash(key);
/* 3492:4164 */     return segmentFor(hash).put(key, hash, value, false);
/* 3493:     */   }
/* 3494:     */   
/* 3495:     */   public V putIfAbsent(K key, V value)
/* 3496:     */   {
/* 3497:4169 */     Preconditions.checkNotNull(key);
/* 3498:4170 */     Preconditions.checkNotNull(value);
/* 3499:4171 */     int hash = hash(key);
/* 3500:4172 */     return segmentFor(hash).put(key, hash, value, true);
/* 3501:     */   }
/* 3502:     */   
/* 3503:     */   public void putAll(Map<? extends K, ? extends V> m)
/* 3504:     */   {
/* 3505:4177 */     for (Map.Entry<? extends K, ? extends V> e : m.entrySet()) {
/* 3506:4178 */       put(e.getKey(), e.getValue());
/* 3507:     */     }
/* 3508:     */   }
/* 3509:     */   
/* 3510:     */   public V remove(@Nullable Object key)
/* 3511:     */   {
/* 3512:4184 */     if (key == null) {
/* 3513:4185 */       return null;
/* 3514:     */     }
/* 3515:4187 */     int hash = hash(key);
/* 3516:4188 */     return segmentFor(hash).remove(key, hash);
/* 3517:     */   }
/* 3518:     */   
/* 3519:     */   public boolean remove(@Nullable Object key, @Nullable Object value)
/* 3520:     */   {
/* 3521:4193 */     if ((key == null) || (value == null)) {
/* 3522:4194 */       return false;
/* 3523:     */     }
/* 3524:4196 */     int hash = hash(key);
/* 3525:4197 */     return segmentFor(hash).remove(key, hash, value);
/* 3526:     */   }
/* 3527:     */   
/* 3528:     */   public boolean replace(K key, @Nullable V oldValue, V newValue)
/* 3529:     */   {
/* 3530:4202 */     Preconditions.checkNotNull(key);
/* 3531:4203 */     Preconditions.checkNotNull(newValue);
/* 3532:4204 */     if (oldValue == null) {
/* 3533:4205 */       return false;
/* 3534:     */     }
/* 3535:4207 */     int hash = hash(key);
/* 3536:4208 */     return segmentFor(hash).replace(key, hash, oldValue, newValue);
/* 3537:     */   }
/* 3538:     */   
/* 3539:     */   public V replace(K key, V value)
/* 3540:     */   {
/* 3541:4213 */     Preconditions.checkNotNull(key);
/* 3542:4214 */     Preconditions.checkNotNull(value);
/* 3543:4215 */     int hash = hash(key);
/* 3544:4216 */     return segmentFor(hash).replace(key, hash, value);
/* 3545:     */   }
/* 3546:     */   
/* 3547:     */   public void clear()
/* 3548:     */   {
/* 3549:4221 */     for (Segment<K, V> segment : this.segments) {
/* 3550:4222 */       segment.clear();
/* 3551:     */     }
/* 3552:     */   }
/* 3553:     */   
/* 3554:     */   void invalidateAll(Iterable<?> keys)
/* 3555:     */   {
/* 3556:4228 */     for (Object key : keys) {
/* 3557:4229 */       remove(key);
/* 3558:     */     }
/* 3559:     */   }
/* 3560:     */   
/* 3561:     */   public Set<K> keySet()
/* 3562:     */   {
/* 3563:4238 */     Set<K> ks = this.keySet;
/* 3564:4239 */     return this.keySet = new KeySet(this);
/* 3565:     */   }
/* 3566:     */   
/* 3567:     */   public Collection<V> values()
/* 3568:     */   {
/* 3569:4247 */     Collection<V> vs = this.values;
/* 3570:4248 */     return this.values = new Values(this);
/* 3571:     */   }
/* 3572:     */   
/* 3573:     */   @GwtIncompatible("Not supported.")
/* 3574:     */   public Set<Map.Entry<K, V>> entrySet()
/* 3575:     */   {
/* 3576:4257 */     Set<Map.Entry<K, V>> es = this.entrySet;
/* 3577:4258 */     return this.entrySet = new EntrySet(this);
/* 3578:     */   }
/* 3579:     */   
/* 3580:     */   abstract class HashIterator<T>
/* 3581:     */     implements Iterator<T>
/* 3582:     */   {
/* 3583:     */     int nextSegmentIndex;
/* 3584:     */     int nextTableIndex;
/* 3585:     */     LocalCache.Segment<K, V> currentSegment;
/* 3586:     */     AtomicReferenceArray<LocalCache.ReferenceEntry<K, V>> currentTable;
/* 3587:     */     LocalCache.ReferenceEntry<K, V> nextEntry;
/* 3588:     */     LocalCache<K, V>.WriteThroughEntry nextExternal;
/* 3589:     */     LocalCache<K, V>.WriteThroughEntry lastReturned;
/* 3590:     */     
/* 3591:     */     HashIterator()
/* 3592:     */     {
/* 3593:4274 */       this.nextSegmentIndex = (LocalCache.this.segments.length - 1);
/* 3594:4275 */       this.nextTableIndex = -1;
/* 3595:4276 */       advance();
/* 3596:     */     }
/* 3597:     */     
/* 3598:     */     public abstract T next();
/* 3599:     */     
/* 3600:     */     final void advance()
/* 3601:     */     {
/* 3602:4283 */       this.nextExternal = null;
/* 3603:4285 */       if (nextInChain()) {
/* 3604:4286 */         return;
/* 3605:     */       }
/* 3606:4289 */       if (nextInTable()) {
/* 3607:4290 */         return;
/* 3608:     */       }
/* 3609:4293 */       while (this.nextSegmentIndex >= 0)
/* 3610:     */       {
/* 3611:4294 */         this.currentSegment = LocalCache.this.segments[(this.nextSegmentIndex--)];
/* 3612:4295 */         if (this.currentSegment.count != 0)
/* 3613:     */         {
/* 3614:4296 */           this.currentTable = this.currentSegment.table;
/* 3615:4297 */           this.nextTableIndex = (this.currentTable.length() - 1);
/* 3616:4298 */           if (nextInTable()) {}
/* 3617:     */         }
/* 3618:     */       }
/* 3619:     */     }
/* 3620:     */     
/* 3621:     */     boolean nextInChain()
/* 3622:     */     {
/* 3623:4309 */       if (this.nextEntry != null) {
/* 3624:4310 */         for (this.nextEntry = this.nextEntry.getNext(); this.nextEntry != null; this.nextEntry = this.nextEntry.getNext()) {
/* 3625:4311 */           if (advanceTo(this.nextEntry)) {
/* 3626:4312 */             return true;
/* 3627:     */           }
/* 3628:     */         }
/* 3629:     */       }
/* 3630:4316 */       return false;
/* 3631:     */     }
/* 3632:     */     
/* 3633:     */     boolean nextInTable()
/* 3634:     */     {
/* 3635:4323 */       while (this.nextTableIndex >= 0) {
/* 3636:4324 */         if (((this.nextEntry = (LocalCache.ReferenceEntry)this.currentTable.get(this.nextTableIndex--)) != null) && (
/* 3637:4325 */           (advanceTo(this.nextEntry)) || (nextInChain()))) {
/* 3638:4326 */           return true;
/* 3639:     */         }
/* 3640:     */       }
/* 3641:4330 */       return false;
/* 3642:     */     }
/* 3643:     */     
/* 3644:     */     boolean advanceTo(LocalCache.ReferenceEntry<K, V> entry)
/* 3645:     */     {
/* 3646:     */       try
/* 3647:     */       {
/* 3648:4339 */         long now = LocalCache.this.ticker.read();
/* 3649:4340 */         K key = entry.getKey();
/* 3650:4341 */         V value = LocalCache.this.getLiveValue(entry, now);
/* 3651:     */         boolean bool;
/* 3652:4342 */         if (value != null)
/* 3653:     */         {
/* 3654:4343 */           this.nextExternal = new LocalCache.WriteThroughEntry(LocalCache.this, key, value);
/* 3655:4344 */           return true;
/* 3656:     */         }
/* 3657:4347 */         return false;
/* 3658:     */       }
/* 3659:     */       finally
/* 3660:     */       {
/* 3661:4350 */         this.currentSegment.postReadCleanup();
/* 3662:     */       }
/* 3663:     */     }
/* 3664:     */     
/* 3665:     */     public boolean hasNext()
/* 3666:     */     {
/* 3667:4356 */       return this.nextExternal != null;
/* 3668:     */     }
/* 3669:     */     
/* 3670:     */     LocalCache<K, V>.WriteThroughEntry nextEntry()
/* 3671:     */     {
/* 3672:4360 */       if (this.nextExternal == null) {
/* 3673:4361 */         throw new NoSuchElementException();
/* 3674:     */       }
/* 3675:4363 */       this.lastReturned = this.nextExternal;
/* 3676:4364 */       advance();
/* 3677:4365 */       return this.lastReturned;
/* 3678:     */     }
/* 3679:     */     
/* 3680:     */     public void remove()
/* 3681:     */     {
/* 3682:4370 */       Preconditions.checkState(this.lastReturned != null);
/* 3683:4371 */       LocalCache.this.remove(this.lastReturned.getKey());
/* 3684:4372 */       this.lastReturned = null;
/* 3685:     */     }
/* 3686:     */   }
/* 3687:     */   
/* 3688:     */   final class KeyIterator
/* 3689:     */     extends LocalCache<K, V>.HashIterator<K>
/* 3690:     */   {
/* 3691:     */     KeyIterator()
/* 3692:     */     {
/* 3693:4376 */       super();
/* 3694:     */     }
/* 3695:     */     
/* 3696:     */     public K next()
/* 3697:     */     {
/* 3698:4380 */       return nextEntry().getKey();
/* 3699:     */     }
/* 3700:     */   }
/* 3701:     */   
/* 3702:     */   final class ValueIterator
/* 3703:     */     extends LocalCache<K, V>.HashIterator<V>
/* 3704:     */   {
/* 3705:     */     ValueIterator()
/* 3706:     */     {
/* 3707:4384 */       super();
/* 3708:     */     }
/* 3709:     */     
/* 3710:     */     public V next()
/* 3711:     */     {
/* 3712:4388 */       return nextEntry().getValue();
/* 3713:     */     }
/* 3714:     */   }
/* 3715:     */   
/* 3716:     */   final class WriteThroughEntry
/* 3717:     */     implements Map.Entry<K, V>
/* 3718:     */   {
/* 3719:     */     final K key;
/* 3720:     */     V value;
/* 3721:     */     
/* 3722:     */     WriteThroughEntry(V key)
/* 3723:     */     {
/* 3724:4401 */       this.key = key;
/* 3725:4402 */       this.value = value;
/* 3726:     */     }
/* 3727:     */     
/* 3728:     */     public K getKey()
/* 3729:     */     {
/* 3730:4407 */       return this.key;
/* 3731:     */     }
/* 3732:     */     
/* 3733:     */     public V getValue()
/* 3734:     */     {
/* 3735:4412 */       return this.value;
/* 3736:     */     }
/* 3737:     */     
/* 3738:     */     public boolean equals(@Nullable Object object)
/* 3739:     */     {
/* 3740:4418 */       if ((object instanceof Map.Entry))
/* 3741:     */       {
/* 3742:4419 */         Map.Entry<?, ?> that = (Map.Entry)object;
/* 3743:4420 */         return (this.key.equals(that.getKey())) && (this.value.equals(that.getValue()));
/* 3744:     */       }
/* 3745:4422 */       return false;
/* 3746:     */     }
/* 3747:     */     
/* 3748:     */     public int hashCode()
/* 3749:     */     {
/* 3750:4428 */       return this.key.hashCode() ^ this.value.hashCode();
/* 3751:     */     }
/* 3752:     */     
/* 3753:     */     public V setValue(V newValue)
/* 3754:     */     {
/* 3755:4433 */       throw new UnsupportedOperationException();
/* 3756:     */     }
/* 3757:     */     
/* 3758:     */     public String toString()
/* 3759:     */     {
/* 3760:4440 */       return getKey() + "=" + getValue();
/* 3761:     */     }
/* 3762:     */   }
/* 3763:     */   
/* 3764:     */   final class EntryIterator
/* 3765:     */     extends LocalCache<K, V>.HashIterator<Map.Entry<K, V>>
/* 3766:     */   {
/* 3767:     */     EntryIterator()
/* 3768:     */     {
/* 3769:4444 */       super();
/* 3770:     */     }
/* 3771:     */     
/* 3772:     */     public Map.Entry<K, V> next()
/* 3773:     */     {
/* 3774:4448 */       return nextEntry();
/* 3775:     */     }
/* 3776:     */   }
/* 3777:     */   
/* 3778:     */   abstract class AbstractCacheSet<T>
/* 3779:     */     extends AbstractSet<T>
/* 3780:     */   {
/* 3781:     */     @Weak
/* 3782:     */     final ConcurrentMap<?, ?> map;
/* 3783:     */     
/* 3784:     */     AbstractCacheSet()
/* 3785:     */     {
/* 3786:4456 */       this.map = map;
/* 3787:     */     }
/* 3788:     */     
/* 3789:     */     public int size()
/* 3790:     */     {
/* 3791:4461 */       return this.map.size();
/* 3792:     */     }
/* 3793:     */     
/* 3794:     */     public boolean isEmpty()
/* 3795:     */     {
/* 3796:4466 */       return this.map.isEmpty();
/* 3797:     */     }
/* 3798:     */     
/* 3799:     */     public void clear()
/* 3800:     */     {
/* 3801:4471 */       this.map.clear();
/* 3802:     */     }
/* 3803:     */     
/* 3804:     */     public Object[] toArray()
/* 3805:     */     {
/* 3806:4479 */       return LocalCache.toArrayList(this).toArray();
/* 3807:     */     }
/* 3808:     */     
/* 3809:     */     public <E> E[] toArray(E[] a)
/* 3810:     */     {
/* 3811:4484 */       return LocalCache.toArrayList(this).toArray(a);
/* 3812:     */     }
/* 3813:     */   }
/* 3814:     */   
/* 3815:     */   private static <E> ArrayList<E> toArrayList(Collection<E> c)
/* 3816:     */   {
/* 3817:4490 */     ArrayList<E> result = new ArrayList(c.size());
/* 3818:4491 */     Iterators.addAll(result, c.iterator());
/* 3819:4492 */     return result;
/* 3820:     */   }
/* 3821:     */   
/* 3822:     */   final class KeySet
/* 3823:     */     extends LocalCache<K, V>.AbstractCacheSet<K>
/* 3824:     */   {
/* 3825:     */     KeySet()
/* 3826:     */     {
/* 3827:4499 */       super(map);
/* 3828:     */     }
/* 3829:     */     
/* 3830:     */     public Iterator<K> iterator()
/* 3831:     */     {
/* 3832:4504 */       return new LocalCache.KeyIterator(LocalCache.this);
/* 3833:     */     }
/* 3834:     */     
/* 3835:     */     public boolean contains(Object o)
/* 3836:     */     {
/* 3837:4509 */       return this.map.containsKey(o);
/* 3838:     */     }
/* 3839:     */     
/* 3840:     */     public boolean remove(Object o)
/* 3841:     */     {
/* 3842:4514 */       return this.map.remove(o) != null;
/* 3843:     */     }
/* 3844:     */   }
/* 3845:     */   
/* 3846:     */   final class Values
/* 3847:     */     extends AbstractCollection<V>
/* 3848:     */   {
/* 3849:     */     private final ConcurrentMap<?, ?> map;
/* 3850:     */     
/* 3851:     */     Values()
/* 3852:     */     {
/* 3853:4523 */       this.map = map;
/* 3854:     */     }
/* 3855:     */     
/* 3856:     */     public int size()
/* 3857:     */     {
/* 3858:4527 */       return this.map.size();
/* 3859:     */     }
/* 3860:     */     
/* 3861:     */     public boolean isEmpty()
/* 3862:     */     {
/* 3863:4531 */       return this.map.isEmpty();
/* 3864:     */     }
/* 3865:     */     
/* 3866:     */     public void clear()
/* 3867:     */     {
/* 3868:4535 */       this.map.clear();
/* 3869:     */     }
/* 3870:     */     
/* 3871:     */     public Iterator<V> iterator()
/* 3872:     */     {
/* 3873:4540 */       return new LocalCache.ValueIterator(LocalCache.this);
/* 3874:     */     }
/* 3875:     */     
/* 3876:     */     public boolean contains(Object o)
/* 3877:     */     {
/* 3878:4545 */       return this.map.containsValue(o);
/* 3879:     */     }
/* 3880:     */     
/* 3881:     */     public Object[] toArray()
/* 3882:     */     {
/* 3883:4553 */       return LocalCache.toArrayList(this).toArray();
/* 3884:     */     }
/* 3885:     */     
/* 3886:     */     public <E> E[] toArray(E[] a)
/* 3887:     */     {
/* 3888:4558 */       return LocalCache.toArrayList(this).toArray(a);
/* 3889:     */     }
/* 3890:     */   }
/* 3891:     */   
/* 3892:     */   final class EntrySet
/* 3893:     */     extends LocalCache<K, V>.AbstractCacheSet<Map.Entry<K, V>>
/* 3894:     */   {
/* 3895:     */     EntrySet()
/* 3896:     */     {
/* 3897:4566 */       super(map);
/* 3898:     */     }
/* 3899:     */     
/* 3900:     */     public Iterator<Map.Entry<K, V>> iterator()
/* 3901:     */     {
/* 3902:4571 */       return new LocalCache.EntryIterator(LocalCache.this);
/* 3903:     */     }
/* 3904:     */     
/* 3905:     */     public boolean contains(Object o)
/* 3906:     */     {
/* 3907:4576 */       if (!(o instanceof Map.Entry)) {
/* 3908:4577 */         return false;
/* 3909:     */       }
/* 3910:4579 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 3911:4580 */       Object key = e.getKey();
/* 3912:4581 */       if (key == null) {
/* 3913:4582 */         return false;
/* 3914:     */       }
/* 3915:4584 */       V v = LocalCache.this.get(key);
/* 3916:     */       
/* 3917:4586 */       return (v != null) && (LocalCache.this.valueEquivalence.equivalent(e.getValue(), v));
/* 3918:     */     }
/* 3919:     */     
/* 3920:     */     public boolean remove(Object o)
/* 3921:     */     {
/* 3922:4591 */       if (!(o instanceof Map.Entry)) {
/* 3923:4592 */         return false;
/* 3924:     */       }
/* 3925:4594 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 3926:4595 */       Object key = e.getKey();
/* 3927:4596 */       return (key != null) && (LocalCache.this.remove(key, e.getValue()));
/* 3928:     */     }
/* 3929:     */   }
/* 3930:     */   
/* 3931:     */   static class ManualSerializationProxy<K, V>
/* 3932:     */     extends ForwardingCache<K, V>
/* 3933:     */     implements Serializable
/* 3934:     */   {
/* 3935:     */     private static final long serialVersionUID = 1L;
/* 3936:     */     final LocalCache.Strength keyStrength;
/* 3937:     */     final LocalCache.Strength valueStrength;
/* 3938:     */     final Equivalence<Object> keyEquivalence;
/* 3939:     */     final Equivalence<Object> valueEquivalence;
/* 3940:     */     final long expireAfterWriteNanos;
/* 3941:     */     final long expireAfterAccessNanos;
/* 3942:     */     final long maxWeight;
/* 3943:     */     final Weigher<K, V> weigher;
/* 3944:     */     final int concurrencyLevel;
/* 3945:     */     final RemovalListener<? super K, ? super V> removalListener;
/* 3946:     */     final Ticker ticker;
/* 3947:     */     final CacheLoader<? super K, V> loader;
/* 3948:     */     transient Cache<K, V> delegate;
/* 3949:     */     
/* 3950:     */     ManualSerializationProxy(LocalCache<K, V> cache)
/* 3951:     */     {
/* 3952:4630 */       this(cache.keyStrength, cache.valueStrength, cache.keyEquivalence, cache.valueEquivalence, cache.expireAfterWriteNanos, cache.expireAfterAccessNanos, cache.maxWeight, cache.weigher, cache.concurrencyLevel, cache.removalListener, cache.ticker, cache.defaultLoader);
/* 3953:     */     }
/* 3954:     */     
/* 3955:     */     private ManualSerializationProxy(LocalCache.Strength keyStrength, LocalCache.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expireAfterWriteNanos, long expireAfterAccessNanos, long maxWeight, Weigher<K, V> weigher, int concurrencyLevel, RemovalListener<? super K, ? super V> removalListener, Ticker ticker, CacheLoader<? super K, V> loader)
/* 3956:     */     {
/* 3957:4652 */       this.keyStrength = keyStrength;
/* 3958:4653 */       this.valueStrength = valueStrength;
/* 3959:4654 */       this.keyEquivalence = keyEquivalence;
/* 3960:4655 */       this.valueEquivalence = valueEquivalence;
/* 3961:4656 */       this.expireAfterWriteNanos = expireAfterWriteNanos;
/* 3962:4657 */       this.expireAfterAccessNanos = expireAfterAccessNanos;
/* 3963:4658 */       this.maxWeight = maxWeight;
/* 3964:4659 */       this.weigher = weigher;
/* 3965:4660 */       this.concurrencyLevel = concurrencyLevel;
/* 3966:4661 */       this.removalListener = removalListener;
/* 3967:4662 */       this.ticker = ((ticker == Ticker.systemTicker()) || (ticker == CacheBuilder.NULL_TICKER) ? null : ticker);
/* 3968:     */       
/* 3969:4664 */       this.loader = loader;
/* 3970:     */     }
/* 3971:     */     
/* 3972:     */     CacheBuilder<K, V> recreateCacheBuilder()
/* 3973:     */     {
/* 3974:4668 */       CacheBuilder<K, V> builder = CacheBuilder.newBuilder().setKeyStrength(this.keyStrength).setValueStrength(this.valueStrength).keyEquivalence(this.keyEquivalence).valueEquivalence(this.valueEquivalence).concurrencyLevel(this.concurrencyLevel).removalListener(this.removalListener);
/* 3975:     */       
/* 3976:     */ 
/* 3977:     */ 
/* 3978:     */ 
/* 3979:     */ 
/* 3980:     */ 
/* 3981:4675 */       builder.strictParsing = false;
/* 3982:4676 */       if (this.expireAfterWriteNanos > 0L) {
/* 3983:4677 */         builder.expireAfterWrite(this.expireAfterWriteNanos, TimeUnit.NANOSECONDS);
/* 3984:     */       }
/* 3985:4679 */       if (this.expireAfterAccessNanos > 0L) {
/* 3986:4680 */         builder.expireAfterAccess(this.expireAfterAccessNanos, TimeUnit.NANOSECONDS);
/* 3987:     */       }
/* 3988:4682 */       if (this.weigher != CacheBuilder.OneWeigher.INSTANCE)
/* 3989:     */       {
/* 3990:4683 */         builder.weigher(this.weigher);
/* 3991:4684 */         if (this.maxWeight != -1L) {
/* 3992:4685 */           builder.maximumWeight(this.maxWeight);
/* 3993:     */         }
/* 3994:     */       }
/* 3995:4688 */       else if (this.maxWeight != -1L)
/* 3996:     */       {
/* 3997:4689 */         builder.maximumSize(this.maxWeight);
/* 3998:     */       }
/* 3999:4692 */       if (this.ticker != null) {
/* 4000:4693 */         builder.ticker(this.ticker);
/* 4001:     */       }
/* 4002:4695 */       return builder;
/* 4003:     */     }
/* 4004:     */     
/* 4005:     */     private void readObject(ObjectInputStream in)
/* 4006:     */       throws IOException, ClassNotFoundException
/* 4007:     */     {
/* 4008:4699 */       in.defaultReadObject();
/* 4009:4700 */       CacheBuilder<K, V> builder = recreateCacheBuilder();
/* 4010:4701 */       this.delegate = builder.build();
/* 4011:     */     }
/* 4012:     */     
/* 4013:     */     private Object readResolve()
/* 4014:     */     {
/* 4015:4705 */       return this.delegate;
/* 4016:     */     }
/* 4017:     */     
/* 4018:     */     protected Cache<K, V> delegate()
/* 4019:     */     {
/* 4020:4710 */       return this.delegate;
/* 4021:     */     }
/* 4022:     */   }
/* 4023:     */   
/* 4024:     */   static final class LoadingSerializationProxy<K, V>
/* 4025:     */     extends LocalCache.ManualSerializationProxy<K, V>
/* 4026:     */     implements LoadingCache<K, V>, Serializable
/* 4027:     */   {
/* 4028:     */     private static final long serialVersionUID = 1L;
/* 4029:     */     transient LoadingCache<K, V> autoDelegate;
/* 4030:     */     
/* 4031:     */     LoadingSerializationProxy(LocalCache<K, V> cache)
/* 4032:     */     {
/* 4033:4729 */       super();
/* 4034:     */     }
/* 4035:     */     
/* 4036:     */     private void readObject(ObjectInputStream in)
/* 4037:     */       throws IOException, ClassNotFoundException
/* 4038:     */     {
/* 4039:4733 */       in.defaultReadObject();
/* 4040:4734 */       CacheBuilder<K, V> builder = recreateCacheBuilder();
/* 4041:4735 */       this.autoDelegate = builder.build(this.loader);
/* 4042:     */     }
/* 4043:     */     
/* 4044:     */     public V get(K key)
/* 4045:     */       throws ExecutionException
/* 4046:     */     {
/* 4047:4740 */       return this.autoDelegate.get(key);
/* 4048:     */     }
/* 4049:     */     
/* 4050:     */     public V getUnchecked(K key)
/* 4051:     */     {
/* 4052:4745 */       return this.autoDelegate.getUnchecked(key);
/* 4053:     */     }
/* 4054:     */     
/* 4055:     */     public ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 4056:     */       throws ExecutionException
/* 4057:     */     {
/* 4058:4750 */       return this.autoDelegate.getAll(keys);
/* 4059:     */     }
/* 4060:     */     
/* 4061:     */     public final V apply(K key)
/* 4062:     */     {
/* 4063:4755 */       return this.autoDelegate.apply(key);
/* 4064:     */     }
/* 4065:     */     
/* 4066:     */     public void refresh(K key)
/* 4067:     */     {
/* 4068:4760 */       this.autoDelegate.refresh(key);
/* 4069:     */     }
/* 4070:     */     
/* 4071:     */     private Object readResolve()
/* 4072:     */     {
/* 4073:4764 */       return this.autoDelegate;
/* 4074:     */     }
/* 4075:     */   }
/* 4076:     */   
/* 4077:     */   static class LocalManualCache<K, V>
/* 4078:     */     implements Cache<K, V>, Serializable
/* 4079:     */   {
/* 4080:     */     final LocalCache<K, V> localCache;
/* 4081:     */     private static final long serialVersionUID = 1L;
/* 4082:     */     
/* 4083:     */     LocalManualCache(CacheBuilder<? super K, ? super V> builder)
/* 4084:     */     {
/* 4085:4772 */       this(new LocalCache(builder, null));
/* 4086:     */     }
/* 4087:     */     
/* 4088:     */     private LocalManualCache(LocalCache<K, V> localCache)
/* 4089:     */     {
/* 4090:4776 */       this.localCache = localCache;
/* 4091:     */     }
/* 4092:     */     
/* 4093:     */     @Nullable
/* 4094:     */     public V getIfPresent(Object key)
/* 4095:     */     {
/* 4096:4784 */       return this.localCache.getIfPresent(key);
/* 4097:     */     }
/* 4098:     */     
/* 4099:     */     public V get(K key, final Callable<? extends V> valueLoader)
/* 4100:     */       throws ExecutionException
/* 4101:     */     {
/* 4102:4789 */       Preconditions.checkNotNull(valueLoader);
/* 4103:4790 */       this.localCache.get(key, new CacheLoader()
/* 4104:     */       {
/* 4105:     */         public V load(Object key)
/* 4106:     */           throws Exception
/* 4107:     */         {
/* 4108:4793 */           return valueLoader.call();
/* 4109:     */         }
/* 4110:     */       });
/* 4111:     */     }
/* 4112:     */     
/* 4113:     */     public ImmutableMap<K, V> getAllPresent(Iterable<?> keys)
/* 4114:     */     {
/* 4115:4800 */       return this.localCache.getAllPresent(keys);
/* 4116:     */     }
/* 4117:     */     
/* 4118:     */     public void put(K key, V value)
/* 4119:     */     {
/* 4120:4805 */       this.localCache.put(key, value);
/* 4121:     */     }
/* 4122:     */     
/* 4123:     */     public void putAll(Map<? extends K, ? extends V> m)
/* 4124:     */     {
/* 4125:4810 */       this.localCache.putAll(m);
/* 4126:     */     }
/* 4127:     */     
/* 4128:     */     public void invalidate(Object key)
/* 4129:     */     {
/* 4130:4815 */       Preconditions.checkNotNull(key);
/* 4131:4816 */       this.localCache.remove(key);
/* 4132:     */     }
/* 4133:     */     
/* 4134:     */     public void invalidateAll(Iterable<?> keys)
/* 4135:     */     {
/* 4136:4821 */       this.localCache.invalidateAll(keys);
/* 4137:     */     }
/* 4138:     */     
/* 4139:     */     public void invalidateAll()
/* 4140:     */     {
/* 4141:4826 */       this.localCache.clear();
/* 4142:     */     }
/* 4143:     */     
/* 4144:     */     public long size()
/* 4145:     */     {
/* 4146:4831 */       return this.localCache.longSize();
/* 4147:     */     }
/* 4148:     */     
/* 4149:     */     public ConcurrentMap<K, V> asMap()
/* 4150:     */     {
/* 4151:4836 */       return this.localCache;
/* 4152:     */     }
/* 4153:     */     
/* 4154:     */     public CacheStats stats()
/* 4155:     */     {
/* 4156:4841 */       AbstractCache.SimpleStatsCounter aggregator = new AbstractCache.SimpleStatsCounter();
/* 4157:4842 */       aggregator.incrementBy(this.localCache.globalStatsCounter);
/* 4158:4843 */       for (LocalCache.Segment<K, V> segment : this.localCache.segments) {
/* 4159:4844 */         aggregator.incrementBy(segment.statsCounter);
/* 4160:     */       }
/* 4161:4846 */       return aggregator.snapshot();
/* 4162:     */     }
/* 4163:     */     
/* 4164:     */     public void cleanUp()
/* 4165:     */     {
/* 4166:4851 */       this.localCache.cleanUp();
/* 4167:     */     }
/* 4168:     */     
/* 4169:     */     Object writeReplace()
/* 4170:     */     {
/* 4171:4859 */       return new LocalCache.ManualSerializationProxy(this.localCache);
/* 4172:     */     }
/* 4173:     */   }
/* 4174:     */   
/* 4175:     */   static class LocalLoadingCache<K, V>
/* 4176:     */     extends LocalCache.LocalManualCache<K, V>
/* 4177:     */     implements LoadingCache<K, V>
/* 4178:     */   {
/* 4179:     */     private static final long serialVersionUID = 1L;
/* 4180:     */     
/* 4181:     */     LocalLoadingCache(CacheBuilder<? super K, ? super V> builder, CacheLoader<? super K, V> loader)
/* 4182:     */     {
/* 4183:4868 */       super(null);
/* 4184:     */     }
/* 4185:     */     
/* 4186:     */     public V get(K key)
/* 4187:     */       throws ExecutionException
/* 4188:     */     {
/* 4189:4875 */       return this.localCache.getOrLoad(key);
/* 4190:     */     }
/* 4191:     */     
/* 4192:     */     public V getUnchecked(K key)
/* 4193:     */     {
/* 4194:     */       try
/* 4195:     */       {
/* 4196:4881 */         return get(key);
/* 4197:     */       }
/* 4198:     */       catch (ExecutionException e)
/* 4199:     */       {
/* 4200:4883 */         throw new UncheckedExecutionException(e.getCause());
/* 4201:     */       }
/* 4202:     */     }
/* 4203:     */     
/* 4204:     */     public ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 4205:     */       throws ExecutionException
/* 4206:     */     {
/* 4207:4889 */       return this.localCache.getAll(keys);
/* 4208:     */     }
/* 4209:     */     
/* 4210:     */     public void refresh(K key)
/* 4211:     */     {
/* 4212:4894 */       this.localCache.refresh(key);
/* 4213:     */     }
/* 4214:     */     
/* 4215:     */     public final V apply(K key)
/* 4216:     */     {
/* 4217:4899 */       return getUnchecked(key);
/* 4218:     */     }
/* 4219:     */     
/* 4220:     */     Object writeReplace()
/* 4221:     */     {
/* 4222:4908 */       return new LocalCache.LoadingSerializationProxy(this.localCache);
/* 4223:     */     }
/* 4224:     */   }
/* 4225:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.LocalCache
 * JD-Core Version:    0.7.0.1
 */