/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Supplier;
/*   8:    */ import com.google.common.util.concurrent.Futures;
/*   9:    */ import com.google.common.util.concurrent.ListenableFuture;
/*  10:    */ import com.google.common.util.concurrent.ListenableFutureTask;
/*  11:    */ import java.io.Serializable;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.concurrent.Callable;
/*  14:    */ import java.util.concurrent.Executor;
/*  15:    */ 
/*  16:    */ @GwtCompatible(emulated=true)
/*  17:    */ public abstract class CacheLoader<K, V>
/*  18:    */ {
/*  19:    */   public abstract V load(K paramK)
/*  20:    */     throws Exception;
/*  21:    */   
/*  22:    */   @GwtIncompatible("Futures")
/*  23:    */   public ListenableFuture<V> reload(K key, V oldValue)
/*  24:    */     throws Exception
/*  25:    */   {
/*  26: 94 */     Preconditions.checkNotNull(key);
/*  27: 95 */     Preconditions.checkNotNull(oldValue);
/*  28: 96 */     return Futures.immediateFuture(load(key));
/*  29:    */   }
/*  30:    */   
/*  31:    */   public Map<K, V> loadAll(Iterable<? extends K> keys)
/*  32:    */     throws Exception
/*  33:    */   {
/*  34:124 */     throw new UnsupportedLoadingOperationException();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <K, V> CacheLoader<K, V> from(Function<K, V> function)
/*  38:    */   {
/*  39:136 */     return new FunctionToCacheLoader(function);
/*  40:    */   }
/*  41:    */   
/*  42:    */   private static final class FunctionToCacheLoader<K, V>
/*  43:    */     extends CacheLoader<K, V>
/*  44:    */     implements Serializable
/*  45:    */   {
/*  46:    */     private final Function<K, V> computingFunction;
/*  47:    */     private static final long serialVersionUID = 0L;
/*  48:    */     
/*  49:    */     public FunctionToCacheLoader(Function<K, V> computingFunction)
/*  50:    */     {
/*  51:144 */       this.computingFunction = ((Function)Preconditions.checkNotNull(computingFunction));
/*  52:    */     }
/*  53:    */     
/*  54:    */     public V load(K key)
/*  55:    */     {
/*  56:149 */       return this.computingFunction.apply(Preconditions.checkNotNull(key));
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static <V> CacheLoader<Object, V> from(Supplier<V> supplier)
/*  61:    */   {
/*  62:165 */     return new SupplierToCacheLoader(supplier);
/*  63:    */   }
/*  64:    */   
/*  65:    */   @GwtIncompatible("Executor + Futures")
/*  66:    */   public static <K, V> CacheLoader<K, V> asyncReloading(CacheLoader<K, V> loader, final Executor executor)
/*  67:    */   {
/*  68:180 */     Preconditions.checkNotNull(loader);
/*  69:181 */     Preconditions.checkNotNull(executor);
/*  70:182 */     new CacheLoader()
/*  71:    */     {
/*  72:    */       public V load(K key)
/*  73:    */         throws Exception
/*  74:    */       {
/*  75:185 */         return this.val$loader.load(key);
/*  76:    */       }
/*  77:    */       
/*  78:    */       public ListenableFuture<V> reload(final K key, final V oldValue)
/*  79:    */         throws Exception
/*  80:    */       {
/*  81:190 */         ListenableFutureTask<V> task = ListenableFutureTask.create(new Callable()
/*  82:    */         {
/*  83:    */           public V call()
/*  84:    */             throws Exception
/*  85:    */           {
/*  86:193 */             return CacheLoader.1.this.val$loader.reload(key, oldValue).get();
/*  87:    */           }
/*  88:195 */         });
/*  89:196 */         executor.execute(task);
/*  90:197 */         return task;
/*  91:    */       }
/*  92:    */       
/*  93:    */       public Map<K, V> loadAll(Iterable<? extends K> keys)
/*  94:    */         throws Exception
/*  95:    */       {
/*  96:202 */         return this.val$loader.loadAll(keys);
/*  97:    */       }
/*  98:    */     };
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static final class SupplierToCacheLoader<V>
/* 102:    */     extends CacheLoader<Object, V>
/* 103:    */     implements Serializable
/* 104:    */   {
/* 105:    */     private final Supplier<V> computingSupplier;
/* 106:    */     private static final long serialVersionUID = 0L;
/* 107:    */     
/* 108:    */     public SupplierToCacheLoader(Supplier<V> computingSupplier)
/* 109:    */     {
/* 110:212 */       this.computingSupplier = ((Supplier)Preconditions.checkNotNull(computingSupplier));
/* 111:    */     }
/* 112:    */     
/* 113:    */     public V load(Object key)
/* 114:    */     {
/* 115:217 */       Preconditions.checkNotNull(key);
/* 116:218 */       return this.computingSupplier.get();
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static final class UnsupportedLoadingOperationException
/* 121:    */     extends UnsupportedOperationException
/* 122:    */   {}
/* 123:    */   
/* 124:    */   public static final class InvalidCacheLoadException
/* 125:    */     extends RuntimeException
/* 126:    */   {
/* 127:    */     public InvalidCacheLoadException(String message)
/* 128:    */     {
/* 129:243 */       super();
/* 130:    */     }
/* 131:    */   }
/* 132:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.CacheLoader
 * JD-Core Version:    0.7.0.1
 */