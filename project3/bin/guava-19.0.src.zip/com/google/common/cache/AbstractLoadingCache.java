/*  1:   */ package com.google.common.cache;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.ImmutableMap;
/*  4:   */ import com.google.common.collect.Maps;
/*  5:   */ import com.google.common.util.concurrent.UncheckedExecutionException;
/*  6:   */ import java.util.Map;
/*  7:   */ import java.util.concurrent.ExecutionException;
/*  8:   */ 
/*  9:   */ public abstract class AbstractLoadingCache<K, V>
/* 10:   */   extends AbstractCache<K, V>
/* 11:   */   implements LoadingCache<K, V>
/* 12:   */ {
/* 13:   */   public V getUnchecked(K key)
/* 14:   */   {
/* 15:   */     try
/* 16:   */     {
/* 17:51 */       return get(key);
/* 18:   */     }
/* 19:   */     catch (ExecutionException e)
/* 20:   */     {
/* 21:53 */       throw new UncheckedExecutionException(e.getCause());
/* 22:   */     }
/* 23:   */   }
/* 24:   */   
/* 25:   */   public ImmutableMap<K, V> getAll(Iterable<? extends K> keys)
/* 26:   */     throws ExecutionException
/* 27:   */   {
/* 28:59 */     Map<K, V> result = Maps.newLinkedHashMap();
/* 29:60 */     for (K key : keys) {
/* 30:61 */       if (!result.containsKey(key)) {
/* 31:62 */         result.put(key, get(key));
/* 32:   */       }
/* 33:   */     }
/* 34:65 */     return ImmutableMap.copyOf(result);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public final V apply(K key)
/* 38:   */   {
/* 39:70 */     return getUnchecked(key);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public void refresh(K key)
/* 43:   */   {
/* 44:75 */     throw new UnsupportedOperationException();
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.AbstractLoadingCache
 * JD-Core Version:    0.7.0.1
 */