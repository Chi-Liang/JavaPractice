/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Ascii;
/*   6:    */ import com.google.common.base.Equivalence;
/*   7:    */ import com.google.common.base.MoreObjects;
/*   8:    */ import com.google.common.base.MoreObjects.ToStringHelper;
/*   9:    */ import com.google.common.base.Preconditions;
/*  10:    */ import com.google.common.base.Supplier;
/*  11:    */ import com.google.common.base.Suppliers;
/*  12:    */ import com.google.common.base.Ticker;
/*  13:    */ import java.util.concurrent.TimeUnit;
/*  14:    */ import java.util.logging.Level;
/*  15:    */ import java.util.logging.Logger;
/*  16:    */ import javax.annotation.CheckReturnValue;
/*  17:    */ 
/*  18:    */ @GwtCompatible(emulated=true)
/*  19:    */ public final class CacheBuilder<K, V>
/*  20:    */ {
/*  21:    */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*  22:    */   private static final int DEFAULT_CONCURRENCY_LEVEL = 4;
/*  23:    */   private static final int DEFAULT_EXPIRATION_NANOS = 0;
/*  24:    */   private static final int DEFAULT_REFRESH_NANOS = 0;
/*  25:158 */   static final Supplier<? extends AbstractCache.StatsCounter> NULL_STATS_COUNTER = Suppliers.ofInstance(new AbstractCache.StatsCounter()
/*  26:    */   {
/*  27:    */     public void recordHits(int count) {}
/*  28:    */     
/*  29:    */     public void recordMisses(int count) {}
/*  30:    */     
/*  31:    */     public void recordLoadSuccess(long loadTime) {}
/*  32:    */     
/*  33:    */     public void recordLoadException(long loadTime) {}
/*  34:    */     
/*  35:    */     public void recordEviction() {}
/*  36:    */     
/*  37:    */     public CacheStats snapshot()
/*  38:    */     {
/*  39:177 */       return CacheBuilder.EMPTY_STATS;
/*  40:    */     }
/*  41:158 */   });
/*  42:180 */   static final CacheStats EMPTY_STATS = new CacheStats(0L, 0L, 0L, 0L, 0L, 0L);
/*  43:182 */   static final Supplier<AbstractCache.StatsCounter> CACHE_STATS_COUNTER = new Supplier()
/*  44:    */   {
/*  45:    */     public AbstractCache.StatsCounter get()
/*  46:    */     {
/*  47:186 */       return new AbstractCache.SimpleStatsCounter();
/*  48:    */     }
/*  49:    */   };
/*  50:    */   
/*  51:    */   static enum NullListener
/*  52:    */     implements RemovalListener<Object, Object>
/*  53:    */   {
/*  54:191 */     INSTANCE;
/*  55:    */     
/*  56:    */     private NullListener() {}
/*  57:    */     
/*  58:    */     public void onRemoval(RemovalNotification<Object, Object> notification) {}
/*  59:    */   }
/*  60:    */   
/*  61:    */   static enum OneWeigher
/*  62:    */     implements Weigher<Object, Object>
/*  63:    */   {
/*  64:198 */     INSTANCE;
/*  65:    */     
/*  66:    */     private OneWeigher() {}
/*  67:    */     
/*  68:    */     public int weigh(Object key, Object value)
/*  69:    */     {
/*  70:202 */       return 1;
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:206 */   static final Ticker NULL_TICKER = new Ticker()
/*  75:    */   {
/*  76:    */     public long read()
/*  77:    */     {
/*  78:209 */       return 0L;
/*  79:    */     }
/*  80:    */   };
/*  81:213 */   private static final Logger logger = Logger.getLogger(CacheBuilder.class.getName());
/*  82:    */   static final int UNSET_INT = -1;
/*  83:217 */   boolean strictParsing = true;
/*  84:219 */   int initialCapacity = -1;
/*  85:220 */   int concurrencyLevel = -1;
/*  86:221 */   long maximumSize = -1L;
/*  87:222 */   long maximumWeight = -1L;
/*  88:    */   Weigher<? super K, ? super V> weigher;
/*  89:    */   LocalCache.Strength keyStrength;
/*  90:    */   LocalCache.Strength valueStrength;
/*  91:228 */   long expireAfterWriteNanos = -1L;
/*  92:229 */   long expireAfterAccessNanos = -1L;
/*  93:230 */   long refreshNanos = -1L;
/*  94:    */   Equivalence<Object> keyEquivalence;
/*  95:    */   Equivalence<Object> valueEquivalence;
/*  96:    */   RemovalListener<? super K, ? super V> removalListener;
/*  97:    */   Ticker ticker;
/*  98:238 */   Supplier<? extends AbstractCache.StatsCounter> statsCounterSupplier = NULL_STATS_COUNTER;
/*  99:    */   
/* 100:    */   public static CacheBuilder<Object, Object> newBuilder()
/* 101:    */   {
/* 102:248 */     return new CacheBuilder();
/* 103:    */   }
/* 104:    */   
/* 105:    */   @GwtIncompatible("To be supported")
/* 106:    */   public static CacheBuilder<Object, Object> from(CacheBuilderSpec spec)
/* 107:    */   {
/* 108:258 */     return spec.toCacheBuilder().lenientParsing();
/* 109:    */   }
/* 110:    */   
/* 111:    */   @GwtIncompatible("To be supported")
/* 112:    */   public static CacheBuilder<Object, Object> from(String spec)
/* 113:    */   {
/* 114:271 */     return from(CacheBuilderSpec.parse(spec));
/* 115:    */   }
/* 116:    */   
/* 117:    */   @GwtIncompatible("To be supported")
/* 118:    */   CacheBuilder<K, V> lenientParsing()
/* 119:    */   {
/* 120:279 */     this.strictParsing = false;
/* 121:280 */     return this;
/* 122:    */   }
/* 123:    */   
/* 124:    */   @GwtIncompatible("To be supported")
/* 125:    */   CacheBuilder<K, V> keyEquivalence(Equivalence<Object> equivalence)
/* 126:    */   {
/* 127:291 */     Preconditions.checkState(this.keyEquivalence == null, "key equivalence was already set to %s", new Object[] { this.keyEquivalence });
/* 128:292 */     this.keyEquivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/* 129:293 */     return this;
/* 130:    */   }
/* 131:    */   
/* 132:    */   Equivalence<Object> getKeyEquivalence()
/* 133:    */   {
/* 134:297 */     return (Equivalence)MoreObjects.firstNonNull(this.keyEquivalence, getKeyStrength().defaultEquivalence());
/* 135:    */   }
/* 136:    */   
/* 137:    */   @GwtIncompatible("To be supported")
/* 138:    */   CacheBuilder<K, V> valueEquivalence(Equivalence<Object> equivalence)
/* 139:    */   {
/* 140:309 */     Preconditions.checkState(this.valueEquivalence == null, "value equivalence was already set to %s", new Object[] { this.valueEquivalence });
/* 141:    */     
/* 142:311 */     this.valueEquivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/* 143:312 */     return this;
/* 144:    */   }
/* 145:    */   
/* 146:    */   Equivalence<Object> getValueEquivalence()
/* 147:    */   {
/* 148:316 */     return (Equivalence)MoreObjects.firstNonNull(this.valueEquivalence, getValueStrength().defaultEquivalence());
/* 149:    */   }
/* 150:    */   
/* 151:    */   public CacheBuilder<K, V> initialCapacity(int initialCapacity)
/* 152:    */   {
/* 153:330 */     Preconditions.checkState(this.initialCapacity == -1, "initial capacity was already set to %s", new Object[] { Integer.valueOf(this.initialCapacity) });
/* 154:    */     
/* 155:332 */     Preconditions.checkArgument(initialCapacity >= 0);
/* 156:333 */     this.initialCapacity = initialCapacity;
/* 157:334 */     return this;
/* 158:    */   }
/* 159:    */   
/* 160:    */   int getInitialCapacity()
/* 161:    */   {
/* 162:338 */     return this.initialCapacity == -1 ? 16 : this.initialCapacity;
/* 163:    */   }
/* 164:    */   
/* 165:    */   public CacheBuilder<K, V> concurrencyLevel(int concurrencyLevel)
/* 166:    */   {
/* 167:372 */     Preconditions.checkState(this.concurrencyLevel == -1, "concurrency level was already set to %s", new Object[] { Integer.valueOf(this.concurrencyLevel) });
/* 168:    */     
/* 169:374 */     Preconditions.checkArgument(concurrencyLevel > 0);
/* 170:375 */     this.concurrencyLevel = concurrencyLevel;
/* 171:376 */     return this;
/* 172:    */   }
/* 173:    */   
/* 174:    */   int getConcurrencyLevel()
/* 175:    */   {
/* 176:380 */     return this.concurrencyLevel == -1 ? 4 : this.concurrencyLevel;
/* 177:    */   }
/* 178:    */   
/* 179:    */   public CacheBuilder<K, V> maximumSize(long size)
/* 180:    */   {
/* 181:399 */     Preconditions.checkState(this.maximumSize == -1L, "maximum size was already set to %s", new Object[] { Long.valueOf(this.maximumSize) });
/* 182:    */     
/* 183:401 */     Preconditions.checkState(this.maximumWeight == -1L, "maximum weight was already set to %s", new Object[] { Long.valueOf(this.maximumWeight) });
/* 184:    */     
/* 185:403 */     Preconditions.checkState(this.weigher == null, "maximum size can not be combined with weigher");
/* 186:404 */     Preconditions.checkArgument(size >= 0L, "maximum size must not be negative");
/* 187:405 */     this.maximumSize = size;
/* 188:406 */     return this;
/* 189:    */   }
/* 190:    */   
/* 191:    */   @GwtIncompatible("To be supported")
/* 192:    */   public CacheBuilder<K, V> maximumWeight(long weight)
/* 193:    */   {
/* 194:435 */     Preconditions.checkState(this.maximumWeight == -1L, "maximum weight was already set to %s", new Object[] { Long.valueOf(this.maximumWeight) });
/* 195:    */     
/* 196:437 */     Preconditions.checkState(this.maximumSize == -1L, "maximum size was already set to %s", new Object[] { Long.valueOf(this.maximumSize) });
/* 197:    */     
/* 198:439 */     this.maximumWeight = weight;
/* 199:440 */     Preconditions.checkArgument(weight >= 0L, "maximum weight must not be negative");
/* 200:441 */     return this;
/* 201:    */   }
/* 202:    */   
/* 203:    */   @GwtIncompatible("To be supported")
/* 204:    */   public <K1 extends K, V1 extends V> CacheBuilder<K1, V1> weigher(Weigher<? super K1, ? super V1> weigher)
/* 205:    */   {
/* 206:475 */     Preconditions.checkState(this.weigher == null);
/* 207:476 */     if (this.strictParsing) {
/* 208:477 */       Preconditions.checkState(this.maximumSize == -1L, "weigher can not be combined with maximum size", new Object[] { Long.valueOf(this.maximumSize) });
/* 209:    */     }
/* 210:483 */     CacheBuilder<K1, V1> me = this;
/* 211:484 */     me.weigher = ((Weigher)Preconditions.checkNotNull(weigher));
/* 212:485 */     return me;
/* 213:    */   }
/* 214:    */   
/* 215:    */   long getMaximumWeight()
/* 216:    */   {
/* 217:489 */     if ((this.expireAfterWriteNanos == 0L) || (this.expireAfterAccessNanos == 0L)) {
/* 218:490 */       return 0L;
/* 219:    */     }
/* 220:492 */     return this.weigher == null ? this.maximumSize : this.maximumWeight;
/* 221:    */   }
/* 222:    */   
/* 223:    */   <K1 extends K, V1 extends V> Weigher<K1, V1> getWeigher()
/* 224:    */   {
/* 225:498 */     return (Weigher)MoreObjects.firstNonNull(this.weigher, OneWeigher.INSTANCE);
/* 226:    */   }
/* 227:    */   
/* 228:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/* 229:    */   public CacheBuilder<K, V> weakKeys()
/* 230:    */   {
/* 231:516 */     return setKeyStrength(LocalCache.Strength.WEAK);
/* 232:    */   }
/* 233:    */   
/* 234:    */   CacheBuilder<K, V> setKeyStrength(LocalCache.Strength strength)
/* 235:    */   {
/* 236:520 */     Preconditions.checkState(this.keyStrength == null, "Key strength was already set to %s", new Object[] { this.keyStrength });
/* 237:521 */     this.keyStrength = ((LocalCache.Strength)Preconditions.checkNotNull(strength));
/* 238:522 */     return this;
/* 239:    */   }
/* 240:    */   
/* 241:    */   LocalCache.Strength getKeyStrength()
/* 242:    */   {
/* 243:526 */     return (LocalCache.Strength)MoreObjects.firstNonNull(this.keyStrength, LocalCache.Strength.STRONG);
/* 244:    */   }
/* 245:    */   
/* 246:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/* 247:    */   public CacheBuilder<K, V> weakValues()
/* 248:    */   {
/* 249:547 */     return setValueStrength(LocalCache.Strength.WEAK);
/* 250:    */   }
/* 251:    */   
/* 252:    */   @GwtIncompatible("java.lang.ref.SoftReference")
/* 253:    */   public CacheBuilder<K, V> softValues()
/* 254:    */   {
/* 255:571 */     return setValueStrength(LocalCache.Strength.SOFT);
/* 256:    */   }
/* 257:    */   
/* 258:    */   CacheBuilder<K, V> setValueStrength(LocalCache.Strength strength)
/* 259:    */   {
/* 260:575 */     Preconditions.checkState(this.valueStrength == null, "Value strength was already set to %s", new Object[] { this.valueStrength });
/* 261:576 */     this.valueStrength = ((LocalCache.Strength)Preconditions.checkNotNull(strength));
/* 262:577 */     return this;
/* 263:    */   }
/* 264:    */   
/* 265:    */   LocalCache.Strength getValueStrength()
/* 266:    */   {
/* 267:581 */     return (LocalCache.Strength)MoreObjects.firstNonNull(this.valueStrength, LocalCache.Strength.STRONG);
/* 268:    */   }
/* 269:    */   
/* 270:    */   public CacheBuilder<K, V> expireAfterWrite(long duration, TimeUnit unit)
/* 271:    */   {
/* 272:604 */     Preconditions.checkState(this.expireAfterWriteNanos == -1L, "expireAfterWrite was already set to %s ns", new Object[] { Long.valueOf(this.expireAfterWriteNanos) });
/* 273:    */     
/* 274:606 */     Preconditions.checkArgument(duration >= 0L, "duration cannot be negative: %s %s", new Object[] { Long.valueOf(duration), unit });
/* 275:607 */     this.expireAfterWriteNanos = unit.toNanos(duration);
/* 276:608 */     return this;
/* 277:    */   }
/* 278:    */   
/* 279:    */   long getExpireAfterWriteNanos()
/* 280:    */   {
/* 281:612 */     return this.expireAfterWriteNanos == -1L ? 0L : this.expireAfterWriteNanos;
/* 282:    */   }
/* 283:    */   
/* 284:    */   public CacheBuilder<K, V> expireAfterAccess(long duration, TimeUnit unit)
/* 285:    */   {
/* 286:638 */     Preconditions.checkState(this.expireAfterAccessNanos == -1L, "expireAfterAccess was already set to %s ns", new Object[] { Long.valueOf(this.expireAfterAccessNanos) });
/* 287:    */     
/* 288:640 */     Preconditions.checkArgument(duration >= 0L, "duration cannot be negative: %s %s", new Object[] { Long.valueOf(duration), unit });
/* 289:641 */     this.expireAfterAccessNanos = unit.toNanos(duration);
/* 290:642 */     return this;
/* 291:    */   }
/* 292:    */   
/* 293:    */   long getExpireAfterAccessNanos()
/* 294:    */   {
/* 295:646 */     return this.expireAfterAccessNanos == -1L ? 0L : this.expireAfterAccessNanos;
/* 296:    */   }
/* 297:    */   
/* 298:    */   @GwtIncompatible("To be supported (synchronously).")
/* 299:    */   public CacheBuilder<K, V> refreshAfterWrite(long duration, TimeUnit unit)
/* 300:    */   {
/* 301:677 */     Preconditions.checkNotNull(unit);
/* 302:678 */     Preconditions.checkState(this.refreshNanos == -1L, "refresh was already set to %s ns", new Object[] { Long.valueOf(this.refreshNanos) });
/* 303:679 */     Preconditions.checkArgument(duration > 0L, "duration must be positive: %s %s", new Object[] { Long.valueOf(duration), unit });
/* 304:680 */     this.refreshNanos = unit.toNanos(duration);
/* 305:681 */     return this;
/* 306:    */   }
/* 307:    */   
/* 308:    */   long getRefreshNanos()
/* 309:    */   {
/* 310:685 */     return this.refreshNanos == -1L ? 0L : this.refreshNanos;
/* 311:    */   }
/* 312:    */   
/* 313:    */   public CacheBuilder<K, V> ticker(Ticker ticker)
/* 314:    */   {
/* 315:698 */     Preconditions.checkState(this.ticker == null);
/* 316:699 */     this.ticker = ((Ticker)Preconditions.checkNotNull(ticker));
/* 317:700 */     return this;
/* 318:    */   }
/* 319:    */   
/* 320:    */   Ticker getTicker(boolean recordsTime)
/* 321:    */   {
/* 322:704 */     if (this.ticker != null) {
/* 323:705 */       return this.ticker;
/* 324:    */     }
/* 325:707 */     return recordsTime ? Ticker.systemTicker() : NULL_TICKER;
/* 326:    */   }
/* 327:    */   
/* 328:    */   @CheckReturnValue
/* 329:    */   public <K1 extends K, V1 extends V> CacheBuilder<K1, V1> removalListener(RemovalListener<? super K1, ? super V1> listener)
/* 330:    */   {
/* 331:734 */     Preconditions.checkState(this.removalListener == null);
/* 332:    */     
/* 333:    */ 
/* 334:    */ 
/* 335:738 */     CacheBuilder<K1, V1> me = this;
/* 336:739 */     me.removalListener = ((RemovalListener)Preconditions.checkNotNull(listener));
/* 337:740 */     return me;
/* 338:    */   }
/* 339:    */   
/* 340:    */   <K1 extends K, V1 extends V> RemovalListener<K1, V1> getRemovalListener()
/* 341:    */   {
/* 342:746 */     return (RemovalListener)MoreObjects.firstNonNull(this.removalListener, NullListener.INSTANCE);
/* 343:    */   }
/* 344:    */   
/* 345:    */   public CacheBuilder<K, V> recordStats()
/* 346:    */   {
/* 347:759 */     this.statsCounterSupplier = CACHE_STATS_COUNTER;
/* 348:760 */     return this;
/* 349:    */   }
/* 350:    */   
/* 351:    */   boolean isRecordingStats()
/* 352:    */   {
/* 353:764 */     return this.statsCounterSupplier == CACHE_STATS_COUNTER;
/* 354:    */   }
/* 355:    */   
/* 356:    */   Supplier<? extends AbstractCache.StatsCounter> getStatsCounterSupplier()
/* 357:    */   {
/* 358:768 */     return this.statsCounterSupplier;
/* 359:    */   }
/* 360:    */   
/* 361:    */   public <K1 extends K, V1 extends V> LoadingCache<K1, V1> build(CacheLoader<? super K1, V1> loader)
/* 362:    */   {
/* 363:785 */     checkWeightWithWeigher();
/* 364:786 */     return new LocalCache.LocalLoadingCache(this, loader);
/* 365:    */   }
/* 366:    */   
/* 367:    */   public <K1 extends K, V1 extends V> Cache<K1, V1> build()
/* 368:    */   {
/* 369:802 */     checkWeightWithWeigher();
/* 370:803 */     checkNonLoadingCache();
/* 371:804 */     return new LocalCache.LocalManualCache(this);
/* 372:    */   }
/* 373:    */   
/* 374:    */   private void checkNonLoadingCache()
/* 375:    */   {
/* 376:808 */     Preconditions.checkState(this.refreshNanos == -1L, "refreshAfterWrite requires a LoadingCache");
/* 377:    */   }
/* 378:    */   
/* 379:    */   private void checkWeightWithWeigher()
/* 380:    */   {
/* 381:812 */     if (this.weigher == null) {
/* 382:813 */       Preconditions.checkState(this.maximumWeight == -1L, "maximumWeight requires weigher");
/* 383:815 */     } else if (this.strictParsing) {
/* 384:816 */       Preconditions.checkState(this.maximumWeight != -1L, "weigher requires maximumWeight");
/* 385:818 */     } else if (this.maximumWeight == -1L) {
/* 386:819 */       logger.log(Level.WARNING, "ignoring weigher specified without maximumWeight");
/* 387:    */     }
/* 388:    */   }
/* 389:    */   
/* 390:    */   public String toString()
/* 391:    */   {
/* 392:831 */     MoreObjects.ToStringHelper s = MoreObjects.toStringHelper(this);
/* 393:832 */     if (this.initialCapacity != -1) {
/* 394:833 */       s.add("initialCapacity", this.initialCapacity);
/* 395:    */     }
/* 396:835 */     if (this.concurrencyLevel != -1) {
/* 397:836 */       s.add("concurrencyLevel", this.concurrencyLevel);
/* 398:    */     }
/* 399:838 */     if (this.maximumSize != -1L) {
/* 400:839 */       s.add("maximumSize", this.maximumSize);
/* 401:    */     }
/* 402:841 */     if (this.maximumWeight != -1L) {
/* 403:842 */       s.add("maximumWeight", this.maximumWeight);
/* 404:    */     }
/* 405:844 */     if (this.expireAfterWriteNanos != -1L) {
/* 406:845 */       s.add("expireAfterWrite", this.expireAfterWriteNanos + "ns");
/* 407:    */     }
/* 408:847 */     if (this.expireAfterAccessNanos != -1L) {
/* 409:848 */       s.add("expireAfterAccess", this.expireAfterAccessNanos + "ns");
/* 410:    */     }
/* 411:850 */     if (this.keyStrength != null) {
/* 412:851 */       s.add("keyStrength", Ascii.toLowerCase(this.keyStrength.toString()));
/* 413:    */     }
/* 414:853 */     if (this.valueStrength != null) {
/* 415:854 */       s.add("valueStrength", Ascii.toLowerCase(this.valueStrength.toString()));
/* 416:    */     }
/* 417:856 */     if (this.keyEquivalence != null) {
/* 418:857 */       s.addValue("keyEquivalence");
/* 419:    */     }
/* 420:859 */     if (this.valueEquivalence != null) {
/* 421:860 */       s.addValue("valueEquivalence");
/* 422:    */     }
/* 423:862 */     if (this.removalListener != null) {
/* 424:863 */       s.addValue("removalListener");
/* 425:    */     }
/* 426:865 */     return s.toString();
/* 427:    */   }
/* 428:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.CacheBuilder
 * JD-Core Version:    0.7.0.1
 */