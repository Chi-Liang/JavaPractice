/*   1:    */ package com.google.common.cache;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.collect.ForwardingObject;
/*   5:    */ import com.google.common.collect.ImmutableMap;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.concurrent.Callable;
/*   8:    */ import java.util.concurrent.ConcurrentMap;
/*   9:    */ import java.util.concurrent.ExecutionException;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ public abstract class ForwardingCache<K, V>
/*  13:    */   extends ForwardingObject
/*  14:    */   implements Cache<K, V>
/*  15:    */ {
/*  16:    */   protected abstract Cache<K, V> delegate();
/*  17:    */   
/*  18:    */   @Nullable
/*  19:    */   public V getIfPresent(Object key)
/*  20:    */   {
/*  21: 52 */     return delegate().getIfPresent(key);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public V get(K key, Callable<? extends V> valueLoader)
/*  25:    */     throws ExecutionException
/*  26:    */   {
/*  27: 60 */     return delegate().get(key, valueLoader);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public ImmutableMap<K, V> getAllPresent(Iterable<?> keys)
/*  31:    */   {
/*  32: 68 */     return delegate().getAllPresent(keys);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void put(K key, V value)
/*  36:    */   {
/*  37: 76 */     delegate().put(key, value);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public void putAll(Map<? extends K, ? extends V> m)
/*  41:    */   {
/*  42: 84 */     delegate().putAll(m);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public void invalidate(Object key)
/*  46:    */   {
/*  47: 89 */     delegate().invalidate(key);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public void invalidateAll(Iterable<?> keys)
/*  51:    */   {
/*  52: 97 */     delegate().invalidateAll(keys);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void invalidateAll()
/*  56:    */   {
/*  57:102 */     delegate().invalidateAll();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public long size()
/*  61:    */   {
/*  62:107 */     return delegate().size();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public CacheStats stats()
/*  66:    */   {
/*  67:112 */     return delegate().stats();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public ConcurrentMap<K, V> asMap()
/*  71:    */   {
/*  72:117 */     return delegate().asMap();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public void cleanUp()
/*  76:    */   {
/*  77:122 */     delegate().cleanUp();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static abstract class SimpleForwardingCache<K, V>
/*  81:    */     extends ForwardingCache<K, V>
/*  82:    */   {
/*  83:    */     private final Cache<K, V> delegate;
/*  84:    */     
/*  85:    */     protected SimpleForwardingCache(Cache<K, V> delegate)
/*  86:    */     {
/*  87:135 */       this.delegate = ((Cache)Preconditions.checkNotNull(delegate));
/*  88:    */     }
/*  89:    */     
/*  90:    */     protected final Cache<K, V> delegate()
/*  91:    */     {
/*  92:140 */       return this.delegate;
/*  93:    */     }
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.ForwardingCache
 * JD-Core Version:    0.7.0.1
 */