/*  1:   */ package com.google.common.cache;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import java.util.concurrent.Executor;
/*  5:   */ 
/*  6:   */ public final class RemovalListeners
/*  7:   */ {
/*  8:   */   public static <K, V> RemovalListener<K, V> asynchronous(final RemovalListener<K, V> listener, Executor executor)
/*  9:   */   {
/* 10:43 */     Preconditions.checkNotNull(listener);
/* 11:44 */     Preconditions.checkNotNull(executor);
/* 12:45 */     new RemovalListener()
/* 13:   */     {
/* 14:   */       public void onRemoval(final RemovalNotification<K, V> notification)
/* 15:   */       {
/* 16:48 */         this.val$executor.execute(new Runnable()
/* 17:   */         {
/* 18:   */           public void run()
/* 19:   */           {
/* 20:51 */             RemovalListeners.1.this.val$listener.onRemoval(notification);
/* 21:   */           }
/* 22:   */         });
/* 23:   */       }
/* 24:   */     };
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.cache.RemovalListeners
 * JD-Core Version:    0.7.0.1
 */