/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import javax.annotation.CheckReturnValue;
/*   7:    */ 
/*   8:    */ @CheckReturnValue
/*   9:    */ @GwtCompatible
/*  10:    */ public final class SignedBytes
/*  11:    */ {
/*  12:    */   public static final byte MAX_POWER_OF_TWO = 64;
/*  13:    */   
/*  14:    */   public static byte checkedCast(long value)
/*  15:    */   {
/*  16: 64 */     byte result = (byte)(int)value;
/*  17: 65 */     if (result != value) {
/*  18: 67 */       throw new IllegalArgumentException("Out of range: " + value);
/*  19:    */     }
/*  20: 69 */     return result;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static byte saturatedCast(long value)
/*  24:    */   {
/*  25: 81 */     if (value > 127L) {
/*  26: 82 */       return 127;
/*  27:    */     }
/*  28: 84 */     if (value < -128L) {
/*  29: 85 */       return -128;
/*  30:    */     }
/*  31: 87 */     return (byte)(int)value;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static int compare(byte a, byte b)
/*  35:    */   {
/*  36:105 */     return a - b;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static byte min(byte... array)
/*  40:    */   {
/*  41:117 */     Preconditions.checkArgument(array.length > 0);
/*  42:118 */     byte min = array[0];
/*  43:119 */     for (int i = 1; i < array.length; i++) {
/*  44:120 */       if (array[i] < min) {
/*  45:121 */         min = array[i];
/*  46:    */       }
/*  47:    */     }
/*  48:124 */     return min;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static byte max(byte... array)
/*  52:    */   {
/*  53:136 */     Preconditions.checkArgument(array.length > 0);
/*  54:137 */     byte max = array[0];
/*  55:138 */     for (int i = 1; i < array.length; i++) {
/*  56:139 */       if (array[i] > max) {
/*  57:140 */         max = array[i];
/*  58:    */       }
/*  59:    */     }
/*  60:143 */     return max;
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static String join(String separator, byte... array)
/*  64:    */   {
/*  65:156 */     Preconditions.checkNotNull(separator);
/*  66:157 */     if (array.length == 0) {
/*  67:158 */       return "";
/*  68:    */     }
/*  69:162 */     StringBuilder builder = new StringBuilder(array.length * 5);
/*  70:163 */     builder.append(array[0]);
/*  71:164 */     for (int i = 1; i < array.length; i++) {
/*  72:165 */       builder.append(separator).append(array[i]);
/*  73:    */     }
/*  74:167 */     return builder.toString();
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static Comparator<byte[]> lexicographicalComparator()
/*  78:    */   {
/*  79:187 */     return LexicographicalComparator.INSTANCE;
/*  80:    */   }
/*  81:    */   
/*  82:    */   private static enum LexicographicalComparator
/*  83:    */     implements Comparator<byte[]>
/*  84:    */   {
/*  85:191 */     INSTANCE;
/*  86:    */     
/*  87:    */     private LexicographicalComparator() {}
/*  88:    */     
/*  89:    */     public int compare(byte[] left, byte[] right)
/*  90:    */     {
/*  91:195 */       int minLength = Math.min(left.length, right.length);
/*  92:196 */       for (int i = 0; i < minLength; i++)
/*  93:    */       {
/*  94:197 */         int result = SignedBytes.compare(left[i], right[i]);
/*  95:198 */         if (result != 0) {
/*  96:199 */           return result;
/*  97:    */         }
/*  98:    */       }
/*  99:202 */       return left.length - right.length;
/* 100:    */     }
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.SignedBytes
 * JD-Core Version:    0.7.0.1
 */