/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Converter;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.AbstractList;
/*   9:    */ import java.util.Arrays;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.RandomAccess;
/*  15:    */ import javax.annotation.CheckForNull;
/*  16:    */ import javax.annotation.CheckReturnValue;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @CheckReturnValue
/*  20:    */ @GwtCompatible
/*  21:    */ public final class Longs
/*  22:    */ {
/*  23:    */   public static final int BYTES = 8;
/*  24:    */   public static final long MAX_POWER_OF_TWO = 4611686018427387904L;
/*  25:    */   
/*  26:    */   public static int hashCode(long value)
/*  27:    */   {
/*  28: 83 */     return (int)(value ^ value >>> 32);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static int compare(long a, long b)
/*  32:    */   {
/*  33: 99 */     return a > b ? 1 : a < b ? -1 : 0;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static boolean contains(long[] array, long target)
/*  37:    */   {
/*  38:112 */     for (long value : array) {
/*  39:113 */       if (value == target) {
/*  40:114 */         return true;
/*  41:    */       }
/*  42:    */     }
/*  43:117 */     return false;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static int indexOf(long[] array, long target)
/*  47:    */   {
/*  48:130 */     return indexOf(array, target, 0, array.length);
/*  49:    */   }
/*  50:    */   
/*  51:    */   private static int indexOf(long[] array, long target, int start, int end)
/*  52:    */   {
/*  53:135 */     for (int i = start; i < end; i++) {
/*  54:136 */       if (array[i] == target) {
/*  55:137 */         return i;
/*  56:    */       }
/*  57:    */     }
/*  58:140 */     return -1;
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static int indexOf(long[] array, long[] target)
/*  62:    */   {
/*  63:155 */     Preconditions.checkNotNull(array, "array");
/*  64:156 */     Preconditions.checkNotNull(target, "target");
/*  65:157 */     if (target.length == 0) {
/*  66:158 */       return 0;
/*  67:    */     }
/*  68:    */     label65:
/*  69:162 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  70:    */     {
/*  71:163 */       for (int j = 0; j < target.length; j++) {
/*  72:164 */         if (array[(i + j)] != target[j]) {
/*  73:    */           break label65;
/*  74:    */         }
/*  75:    */       }
/*  76:168 */       return i;
/*  77:    */     }
/*  78:170 */     return -1;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static int lastIndexOf(long[] array, long target)
/*  82:    */   {
/*  83:183 */     return lastIndexOf(array, target, 0, array.length);
/*  84:    */   }
/*  85:    */   
/*  86:    */   private static int lastIndexOf(long[] array, long target, int start, int end)
/*  87:    */   {
/*  88:188 */     for (int i = end - 1; i >= start; i--) {
/*  89:189 */       if (array[i] == target) {
/*  90:190 */         return i;
/*  91:    */       }
/*  92:    */     }
/*  93:193 */     return -1;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static long min(long... array)
/*  97:    */   {
/*  98:205 */     Preconditions.checkArgument(array.length > 0);
/*  99:206 */     long min = array[0];
/* 100:207 */     for (int i = 1; i < array.length; i++) {
/* 101:208 */       if (array[i] < min) {
/* 102:209 */         min = array[i];
/* 103:    */       }
/* 104:    */     }
/* 105:212 */     return min;
/* 106:    */   }
/* 107:    */   
/* 108:    */   public static long max(long... array)
/* 109:    */   {
/* 110:224 */     Preconditions.checkArgument(array.length > 0);
/* 111:225 */     long max = array[0];
/* 112:226 */     for (int i = 1; i < array.length; i++) {
/* 113:227 */       if (array[i] > max) {
/* 114:228 */         max = array[i];
/* 115:    */       }
/* 116:    */     }
/* 117:231 */     return max;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static long[] concat(long[]... arrays)
/* 121:    */   {
/* 122:244 */     int length = 0;
/* 123:245 */     for (long[] array : arrays) {
/* 124:246 */       length += array.length;
/* 125:    */     }
/* 126:248 */     long[] result = new long[length];
/* 127:249 */     int pos = 0;
/* 128:250 */     for (long[] array : arrays)
/* 129:    */     {
/* 130:251 */       System.arraycopy(array, 0, result, pos, array.length);
/* 131:252 */       pos += array.length;
/* 132:    */     }
/* 133:254 */     return result;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static byte[] toByteArray(long value)
/* 137:    */   {
/* 138:271 */     byte[] result = new byte[8];
/* 139:272 */     for (int i = 7; i >= 0; i--)
/* 140:    */     {
/* 141:273 */       result[i] = ((byte)(int)(value & 0xFF));
/* 142:274 */       value >>= 8;
/* 143:    */     }
/* 144:276 */     return result;
/* 145:    */   }
/* 146:    */   
/* 147:    */   public static long fromByteArray(byte[] bytes)
/* 148:    */   {
/* 149:293 */     Preconditions.checkArgument(bytes.length >= 8, "array too small: %s < %s", new Object[] { Integer.valueOf(bytes.length), Integer.valueOf(8) });
/* 150:294 */     return fromBytes(bytes[0], bytes[1], bytes[2], bytes[3], bytes[4], bytes[5], bytes[6], bytes[7]);
/* 151:    */   }
/* 152:    */   
/* 153:    */   public static long fromBytes(byte b1, byte b2, byte b3, byte b4, byte b5, byte b6, byte b7, byte b8)
/* 154:    */   {
/* 155:307 */     return (b1 & 0xFF) << 56 | (b2 & 0xFF) << 48 | (b3 & 0xFF) << 40 | (b4 & 0xFF) << 32 | (b5 & 0xFF) << 24 | (b6 & 0xFF) << 16 | (b7 & 0xFF) << 8 | b8 & 0xFF;
/* 156:    */   }
/* 157:    */   
/* 158:317 */   private static final byte[] asciiDigits = ;
/* 159:    */   
/* 160:    */   private static byte[] createAsciiDigits()
/* 161:    */   {
/* 162:320 */     byte[] result = new byte[''];
/* 163:321 */     Arrays.fill(result, (byte)-1);
/* 164:322 */     for (int i = 0; i <= 9; i++) {
/* 165:323 */       result[(48 + i)] = ((byte)i);
/* 166:    */     }
/* 167:325 */     for (int i = 0; i <= 26; i++)
/* 168:    */     {
/* 169:326 */       result[(65 + i)] = ((byte)(10 + i));
/* 170:327 */       result[(97 + i)] = ((byte)(10 + i));
/* 171:    */     }
/* 172:329 */     return result;
/* 173:    */   }
/* 174:    */   
/* 175:    */   private static int digit(char c)
/* 176:    */   {
/* 177:333 */     return c < '' ? asciiDigits[c] : -1;
/* 178:    */   }
/* 179:    */   
/* 180:    */   @Nullable
/* 181:    */   @CheckForNull
/* 182:    */   @Beta
/* 183:    */   public static Long tryParse(String string)
/* 184:    */   {
/* 185:360 */     return tryParse(string, 10);
/* 186:    */   }
/* 187:    */   
/* 188:    */   @Nullable
/* 189:    */   @CheckForNull
/* 190:    */   @Beta
/* 191:    */   public static Long tryParse(String string, int radix)
/* 192:    */   {
/* 193:390 */     if (((String)Preconditions.checkNotNull(string)).isEmpty()) {
/* 194:391 */       return null;
/* 195:    */     }
/* 196:393 */     if ((radix < 2) || (radix > 36)) {
/* 197:394 */       throw new IllegalArgumentException("radix must be between MIN_RADIX and MAX_RADIX but was " + radix);
/* 198:    */     }
/* 199:397 */     boolean negative = string.charAt(0) == '-';
/* 200:398 */     int index = negative ? 1 : 0;
/* 201:399 */     if (index == string.length()) {
/* 202:400 */       return null;
/* 203:    */     }
/* 204:402 */     int digit = digit(string.charAt(index++));
/* 205:403 */     if ((digit < 0) || (digit >= radix)) {
/* 206:404 */       return null;
/* 207:    */     }
/* 208:406 */     long accum = -digit;
/* 209:    */     
/* 210:408 */     long cap = -9223372036854775808L / radix;
/* 211:410 */     while (index < string.length())
/* 212:    */     {
/* 213:411 */       digit = digit(string.charAt(index++));
/* 214:412 */       if ((digit < 0) || (digit >= radix) || (accum < cap)) {
/* 215:413 */         return null;
/* 216:    */       }
/* 217:415 */       accum *= radix;
/* 218:416 */       if (accum < -9223372036854775808L + digit) {
/* 219:417 */         return null;
/* 220:    */       }
/* 221:419 */       accum -= digit;
/* 222:    */     }
/* 223:422 */     if (negative) {
/* 224:423 */       return Long.valueOf(accum);
/* 225:    */     }
/* 226:424 */     if (accum == -9223372036854775808L) {
/* 227:425 */       return null;
/* 228:    */     }
/* 229:427 */     return Long.valueOf(-accum);
/* 230:    */   }
/* 231:    */   
/* 232:    */   private static final class LongConverter
/* 233:    */     extends Converter<String, Long>
/* 234:    */     implements Serializable
/* 235:    */   {
/* 236:432 */     static final LongConverter INSTANCE = new LongConverter();
/* 237:    */     private static final long serialVersionUID = 1L;
/* 238:    */     
/* 239:    */     protected Long doForward(String value)
/* 240:    */     {
/* 241:436 */       return Long.decode(value);
/* 242:    */     }
/* 243:    */     
/* 244:    */     protected String doBackward(Long value)
/* 245:    */     {
/* 246:441 */       return value.toString();
/* 247:    */     }
/* 248:    */     
/* 249:    */     public String toString()
/* 250:    */     {
/* 251:446 */       return "Longs.stringConverter()";
/* 252:    */     }
/* 253:    */     
/* 254:    */     private Object readResolve()
/* 255:    */     {
/* 256:450 */       return INSTANCE;
/* 257:    */     }
/* 258:    */   }
/* 259:    */   
/* 260:    */   @Beta
/* 261:    */   public static Converter<String, Long> stringConverter()
/* 262:    */   {
/* 263:464 */     return LongConverter.INSTANCE;
/* 264:    */   }
/* 265:    */   
/* 266:    */   public static long[] ensureCapacity(long[] array, int minLength, int padding)
/* 267:    */   {
/* 268:484 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 269:485 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 270:486 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 271:    */   }
/* 272:    */   
/* 273:    */   private static long[] copyOf(long[] original, int length)
/* 274:    */   {
/* 275:493 */     long[] copy = new long[length];
/* 276:494 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 277:495 */     return copy;
/* 278:    */   }
/* 279:    */   
/* 280:    */   public static String join(String separator, long... array)
/* 281:    */   {
/* 282:508 */     Preconditions.checkNotNull(separator);
/* 283:509 */     if (array.length == 0) {
/* 284:510 */       return "";
/* 285:    */     }
/* 286:514 */     StringBuilder builder = new StringBuilder(array.length * 10);
/* 287:515 */     builder.append(array[0]);
/* 288:516 */     for (int i = 1; i < array.length; i++) {
/* 289:517 */       builder.append(separator).append(array[i]);
/* 290:    */     }
/* 291:519 */     return builder.toString();
/* 292:    */   }
/* 293:    */   
/* 294:    */   public static Comparator<long[]> lexicographicalComparator()
/* 295:    */   {
/* 296:539 */     return LexicographicalComparator.INSTANCE;
/* 297:    */   }
/* 298:    */   
/* 299:    */   private static enum LexicographicalComparator
/* 300:    */     implements Comparator<long[]>
/* 301:    */   {
/* 302:543 */     INSTANCE;
/* 303:    */     
/* 304:    */     private LexicographicalComparator() {}
/* 305:    */     
/* 306:    */     public int compare(long[] left, long[] right)
/* 307:    */     {
/* 308:547 */       int minLength = Math.min(left.length, right.length);
/* 309:548 */       for (int i = 0; i < minLength; i++)
/* 310:    */       {
/* 311:549 */         int result = Longs.compare(left[i], right[i]);
/* 312:550 */         if (result != 0) {
/* 313:551 */           return result;
/* 314:    */         }
/* 315:    */       }
/* 316:554 */       return left.length - right.length;
/* 317:    */     }
/* 318:    */   }
/* 319:    */   
/* 320:    */   public static long[] toArray(Collection<? extends Number> collection)
/* 321:    */   {
/* 322:574 */     if ((collection instanceof LongArrayAsList)) {
/* 323:575 */       return ((LongArrayAsList)collection).toLongArray();
/* 324:    */     }
/* 325:578 */     Object[] boxedArray = collection.toArray();
/* 326:579 */     int len = boxedArray.length;
/* 327:580 */     long[] array = new long[len];
/* 328:581 */     for (int i = 0; i < len; i++) {
/* 329:583 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).longValue();
/* 330:    */     }
/* 331:585 */     return array;
/* 332:    */   }
/* 333:    */   
/* 334:    */   public static List<Long> asList(long... backingArray)
/* 335:    */   {
/* 336:603 */     if (backingArray.length == 0) {
/* 337:604 */       return Collections.emptyList();
/* 338:    */     }
/* 339:606 */     return new LongArrayAsList(backingArray);
/* 340:    */   }
/* 341:    */   
/* 342:    */   @GwtCompatible
/* 343:    */   private static class LongArrayAsList
/* 344:    */     extends AbstractList<Long>
/* 345:    */     implements RandomAccess, Serializable
/* 346:    */   {
/* 347:    */     final long[] array;
/* 348:    */     final int start;
/* 349:    */     final int end;
/* 350:    */     private static final long serialVersionUID = 0L;
/* 351:    */     
/* 352:    */     LongArrayAsList(long[] array)
/* 353:    */     {
/* 354:617 */       this(array, 0, array.length);
/* 355:    */     }
/* 356:    */     
/* 357:    */     LongArrayAsList(long[] array, int start, int end)
/* 358:    */     {
/* 359:621 */       this.array = array;
/* 360:622 */       this.start = start;
/* 361:623 */       this.end = end;
/* 362:    */     }
/* 363:    */     
/* 364:    */     public int size()
/* 365:    */     {
/* 366:628 */       return this.end - this.start;
/* 367:    */     }
/* 368:    */     
/* 369:    */     public boolean isEmpty()
/* 370:    */     {
/* 371:633 */       return false;
/* 372:    */     }
/* 373:    */     
/* 374:    */     public Long get(int index)
/* 375:    */     {
/* 376:638 */       Preconditions.checkElementIndex(index, size());
/* 377:639 */       return Long.valueOf(this.array[(this.start + index)]);
/* 378:    */     }
/* 379:    */     
/* 380:    */     public boolean contains(Object target)
/* 381:    */     {
/* 382:645 */       return ((target instanceof Long)) && (Longs.indexOf(this.array, ((Long)target).longValue(), this.start, this.end) != -1);
/* 383:    */     }
/* 384:    */     
/* 385:    */     public int indexOf(Object target)
/* 386:    */     {
/* 387:651 */       if ((target instanceof Long))
/* 388:    */       {
/* 389:652 */         int i = Longs.indexOf(this.array, ((Long)target).longValue(), this.start, this.end);
/* 390:653 */         if (i >= 0) {
/* 391:654 */           return i - this.start;
/* 392:    */         }
/* 393:    */       }
/* 394:657 */       return -1;
/* 395:    */     }
/* 396:    */     
/* 397:    */     public int lastIndexOf(Object target)
/* 398:    */     {
/* 399:663 */       if ((target instanceof Long))
/* 400:    */       {
/* 401:664 */         int i = Longs.lastIndexOf(this.array, ((Long)target).longValue(), this.start, this.end);
/* 402:665 */         if (i >= 0) {
/* 403:666 */           return i - this.start;
/* 404:    */         }
/* 405:    */       }
/* 406:669 */       return -1;
/* 407:    */     }
/* 408:    */     
/* 409:    */     public Long set(int index, Long element)
/* 410:    */     {
/* 411:674 */       Preconditions.checkElementIndex(index, size());
/* 412:675 */       long oldValue = this.array[(this.start + index)];
/* 413:    */       
/* 414:677 */       this.array[(this.start + index)] = ((Long)Preconditions.checkNotNull(element)).longValue();
/* 415:678 */       return Long.valueOf(oldValue);
/* 416:    */     }
/* 417:    */     
/* 418:    */     public List<Long> subList(int fromIndex, int toIndex)
/* 419:    */     {
/* 420:683 */       int size = size();
/* 421:684 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 422:685 */       if (fromIndex == toIndex) {
/* 423:686 */         return Collections.emptyList();
/* 424:    */       }
/* 425:688 */       return new LongArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 426:    */     }
/* 427:    */     
/* 428:    */     public boolean equals(@Nullable Object object)
/* 429:    */     {
/* 430:693 */       if (object == this) {
/* 431:694 */         return true;
/* 432:    */       }
/* 433:696 */       if ((object instanceof LongArrayAsList))
/* 434:    */       {
/* 435:697 */         LongArrayAsList that = (LongArrayAsList)object;
/* 436:698 */         int size = size();
/* 437:699 */         if (that.size() != size) {
/* 438:700 */           return false;
/* 439:    */         }
/* 440:702 */         for (int i = 0; i < size; i++) {
/* 441:703 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 442:704 */             return false;
/* 443:    */           }
/* 444:    */         }
/* 445:707 */         return true;
/* 446:    */       }
/* 447:709 */       return super.equals(object);
/* 448:    */     }
/* 449:    */     
/* 450:    */     public int hashCode()
/* 451:    */     {
/* 452:714 */       int result = 1;
/* 453:715 */       for (int i = this.start; i < this.end; i++) {
/* 454:716 */         result = 31 * result + Longs.hashCode(this.array[i]);
/* 455:    */       }
/* 456:718 */       return result;
/* 457:    */     }
/* 458:    */     
/* 459:    */     public String toString()
/* 460:    */     {
/* 461:723 */       StringBuilder builder = new StringBuilder(size() * 10);
/* 462:724 */       builder.append('[').append(this.array[this.start]);
/* 463:725 */       for (int i = this.start + 1; i < this.end; i++) {
/* 464:726 */         builder.append(", ").append(this.array[i]);
/* 465:    */       }
/* 466:728 */       return ']';
/* 467:    */     }
/* 468:    */     
/* 469:    */     long[] toLongArray()
/* 470:    */     {
/* 471:733 */       int size = size();
/* 472:734 */       long[] result = new long[size];
/* 473:735 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 474:736 */       return result;
/* 475:    */     }
/* 476:    */   }
/* 477:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Longs
 * JD-Core Version:    0.7.0.1
 */