/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Converter;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.RandomAccess;
/*  15:    */ import java.util.regex.Matcher;
/*  16:    */ import java.util.regex.Pattern;
/*  17:    */ import javax.annotation.CheckForNull;
/*  18:    */ import javax.annotation.CheckReturnValue;
/*  19:    */ import javax.annotation.Nullable;
/*  20:    */ 
/*  21:    */ @CheckReturnValue
/*  22:    */ @GwtCompatible(emulated=true)
/*  23:    */ public final class Doubles
/*  24:    */ {
/*  25:    */   public static final int BYTES = 8;
/*  26:    */   
/*  27:    */   public static int hashCode(double value)
/*  28:    */   {
/*  29: 77 */     return Double.valueOf(value).hashCode();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static int compare(double a, double b)
/*  33:    */   {
/*  34: 99 */     return Double.compare(a, b);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static boolean isFinite(double value)
/*  38:    */   {
/*  39:110 */     return ((-1.0D / 0.0D) < value ? 1 : 0) & (value < (1.0D / 0.0D) ? 1 : 0);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static boolean contains(double[] array, double target)
/*  43:    */   {
/*  44:124 */     for (double value : array) {
/*  45:125 */       if (value == target) {
/*  46:126 */         return true;
/*  47:    */       }
/*  48:    */     }
/*  49:129 */     return false;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static int indexOf(double[] array, double target)
/*  53:    */   {
/*  54:143 */     return indexOf(array, target, 0, array.length);
/*  55:    */   }
/*  56:    */   
/*  57:    */   private static int indexOf(double[] array, double target, int start, int end)
/*  58:    */   {
/*  59:148 */     for (int i = start; i < end; i++) {
/*  60:149 */       if (array[i] == target) {
/*  61:150 */         return i;
/*  62:    */       }
/*  63:    */     }
/*  64:153 */     return -1;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static int indexOf(double[] array, double[] target)
/*  68:    */   {
/*  69:171 */     Preconditions.checkNotNull(array, "array");
/*  70:172 */     Preconditions.checkNotNull(target, "target");
/*  71:173 */     if (target.length == 0) {
/*  72:174 */       return 0;
/*  73:    */     }
/*  74:    */     label65:
/*  75:178 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  76:    */     {
/*  77:179 */       for (int j = 0; j < target.length; j++) {
/*  78:180 */         if (array[(i + j)] != target[j]) {
/*  79:    */           break label65;
/*  80:    */         }
/*  81:    */       }
/*  82:184 */       return i;
/*  83:    */     }
/*  84:186 */     return -1;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static int lastIndexOf(double[] array, double target)
/*  88:    */   {
/*  89:200 */     return lastIndexOf(array, target, 0, array.length);
/*  90:    */   }
/*  91:    */   
/*  92:    */   private static int lastIndexOf(double[] array, double target, int start, int end)
/*  93:    */   {
/*  94:205 */     for (int i = end - 1; i >= start; i--) {
/*  95:206 */       if (array[i] == target) {
/*  96:207 */         return i;
/*  97:    */       }
/*  98:    */     }
/*  99:210 */     return -1;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static double min(double... array)
/* 103:    */   {
/* 104:223 */     Preconditions.checkArgument(array.length > 0);
/* 105:224 */     double min = array[0];
/* 106:225 */     for (int i = 1; i < array.length; i++) {
/* 107:226 */       min = Math.min(min, array[i]);
/* 108:    */     }
/* 109:228 */     return min;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static double max(double... array)
/* 113:    */   {
/* 114:241 */     Preconditions.checkArgument(array.length > 0);
/* 115:242 */     double max = array[0];
/* 116:243 */     for (int i = 1; i < array.length; i++) {
/* 117:244 */       max = Math.max(max, array[i]);
/* 118:    */     }
/* 119:246 */     return max;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static double[] concat(double[]... arrays)
/* 123:    */   {
/* 124:259 */     int length = 0;
/* 125:260 */     for (double[] array : arrays) {
/* 126:261 */       length += array.length;
/* 127:    */     }
/* 128:263 */     double[] result = new double[length];
/* 129:264 */     int pos = 0;
/* 130:265 */     for (double[] array : arrays)
/* 131:    */     {
/* 132:266 */       System.arraycopy(array, 0, result, pos, array.length);
/* 133:267 */       pos += array.length;
/* 134:    */     }
/* 135:269 */     return result;
/* 136:    */   }
/* 137:    */   
/* 138:    */   private static final class DoubleConverter
/* 139:    */     extends Converter<String, Double>
/* 140:    */     implements Serializable
/* 141:    */   {
/* 142:274 */     static final DoubleConverter INSTANCE = new DoubleConverter();
/* 143:    */     private static final long serialVersionUID = 1L;
/* 144:    */     
/* 145:    */     protected Double doForward(String value)
/* 146:    */     {
/* 147:278 */       return Double.valueOf(value);
/* 148:    */     }
/* 149:    */     
/* 150:    */     protected String doBackward(Double value)
/* 151:    */     {
/* 152:283 */       return value.toString();
/* 153:    */     }
/* 154:    */     
/* 155:    */     public String toString()
/* 156:    */     {
/* 157:288 */       return "Doubles.stringConverter()";
/* 158:    */     }
/* 159:    */     
/* 160:    */     private Object readResolve()
/* 161:    */     {
/* 162:292 */       return INSTANCE;
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   @Beta
/* 167:    */   public static Converter<String, Double> stringConverter()
/* 168:    */   {
/* 169:306 */     return DoubleConverter.INSTANCE;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static double[] ensureCapacity(double[] array, int minLength, int padding)
/* 173:    */   {
/* 174:326 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 175:327 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 176:328 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 177:    */   }
/* 178:    */   
/* 179:    */   private static double[] copyOf(double[] original, int length)
/* 180:    */   {
/* 181:335 */     double[] copy = new double[length];
/* 182:336 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 183:337 */     return copy;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static String join(String separator, double... array)
/* 187:    */   {
/* 188:355 */     Preconditions.checkNotNull(separator);
/* 189:356 */     if (array.length == 0) {
/* 190:357 */       return "";
/* 191:    */     }
/* 192:361 */     StringBuilder builder = new StringBuilder(array.length * 12);
/* 193:362 */     builder.append(array[0]);
/* 194:363 */     for (int i = 1; i < array.length; i++) {
/* 195:364 */       builder.append(separator).append(array[i]);
/* 196:    */     }
/* 197:366 */     return builder.toString();
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static Comparator<double[]> lexicographicalComparator()
/* 201:    */   {
/* 202:386 */     return LexicographicalComparator.INSTANCE;
/* 203:    */   }
/* 204:    */   
/* 205:    */   private static enum LexicographicalComparator
/* 206:    */     implements Comparator<double[]>
/* 207:    */   {
/* 208:390 */     INSTANCE;
/* 209:    */     
/* 210:    */     private LexicographicalComparator() {}
/* 211:    */     
/* 212:    */     public int compare(double[] left, double[] right)
/* 213:    */     {
/* 214:394 */       int minLength = Math.min(left.length, right.length);
/* 215:395 */       for (int i = 0; i < minLength; i++)
/* 216:    */       {
/* 217:396 */         int result = Double.compare(left[i], right[i]);
/* 218:397 */         if (result != 0) {
/* 219:398 */           return result;
/* 220:    */         }
/* 221:    */       }
/* 222:401 */       return left.length - right.length;
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   public static double[] toArray(Collection<? extends Number> collection)
/* 227:    */   {
/* 228:421 */     if ((collection instanceof DoubleArrayAsList)) {
/* 229:422 */       return ((DoubleArrayAsList)collection).toDoubleArray();
/* 230:    */     }
/* 231:425 */     Object[] boxedArray = collection.toArray();
/* 232:426 */     int len = boxedArray.length;
/* 233:427 */     double[] array = new double[len];
/* 234:428 */     for (int i = 0; i < len; i++) {
/* 235:430 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).doubleValue();
/* 236:    */     }
/* 237:432 */     return array;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public static List<Double> asList(double... backingArray)
/* 241:    */   {
/* 242:453 */     if (backingArray.length == 0) {
/* 243:454 */       return Collections.emptyList();
/* 244:    */     }
/* 245:456 */     return new DoubleArrayAsList(backingArray);
/* 246:    */   }
/* 247:    */   
/* 248:    */   @GwtCompatible
/* 249:    */   private static class DoubleArrayAsList
/* 250:    */     extends AbstractList<Double>
/* 251:    */     implements RandomAccess, Serializable
/* 252:    */   {
/* 253:    */     final double[] array;
/* 254:    */     final int start;
/* 255:    */     final int end;
/* 256:    */     private static final long serialVersionUID = 0L;
/* 257:    */     
/* 258:    */     DoubleArrayAsList(double[] array)
/* 259:    */     {
/* 260:467 */       this(array, 0, array.length);
/* 261:    */     }
/* 262:    */     
/* 263:    */     DoubleArrayAsList(double[] array, int start, int end)
/* 264:    */     {
/* 265:471 */       this.array = array;
/* 266:472 */       this.start = start;
/* 267:473 */       this.end = end;
/* 268:    */     }
/* 269:    */     
/* 270:    */     public int size()
/* 271:    */     {
/* 272:478 */       return this.end - this.start;
/* 273:    */     }
/* 274:    */     
/* 275:    */     public boolean isEmpty()
/* 276:    */     {
/* 277:483 */       return false;
/* 278:    */     }
/* 279:    */     
/* 280:    */     public Double get(int index)
/* 281:    */     {
/* 282:488 */       Preconditions.checkElementIndex(index, size());
/* 283:489 */       return Double.valueOf(this.array[(this.start + index)]);
/* 284:    */     }
/* 285:    */     
/* 286:    */     public boolean contains(Object target)
/* 287:    */     {
/* 288:495 */       return ((target instanceof Double)) && (Doubles.indexOf(this.array, ((Double)target).doubleValue(), this.start, this.end) != -1);
/* 289:    */     }
/* 290:    */     
/* 291:    */     public int indexOf(Object target)
/* 292:    */     {
/* 293:502 */       if ((target instanceof Double))
/* 294:    */       {
/* 295:503 */         int i = Doubles.indexOf(this.array, ((Double)target).doubleValue(), this.start, this.end);
/* 296:504 */         if (i >= 0) {
/* 297:505 */           return i - this.start;
/* 298:    */         }
/* 299:    */       }
/* 300:508 */       return -1;
/* 301:    */     }
/* 302:    */     
/* 303:    */     public int lastIndexOf(Object target)
/* 304:    */     {
/* 305:514 */       if ((target instanceof Double))
/* 306:    */       {
/* 307:515 */         int i = Doubles.lastIndexOf(this.array, ((Double)target).doubleValue(), this.start, this.end);
/* 308:516 */         if (i >= 0) {
/* 309:517 */           return i - this.start;
/* 310:    */         }
/* 311:    */       }
/* 312:520 */       return -1;
/* 313:    */     }
/* 314:    */     
/* 315:    */     public Double set(int index, Double element)
/* 316:    */     {
/* 317:525 */       Preconditions.checkElementIndex(index, size());
/* 318:526 */       double oldValue = this.array[(this.start + index)];
/* 319:    */       
/* 320:528 */       this.array[(this.start + index)] = ((Double)Preconditions.checkNotNull(element)).doubleValue();
/* 321:529 */       return Double.valueOf(oldValue);
/* 322:    */     }
/* 323:    */     
/* 324:    */     public List<Double> subList(int fromIndex, int toIndex)
/* 325:    */     {
/* 326:534 */       int size = size();
/* 327:535 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 328:536 */       if (fromIndex == toIndex) {
/* 329:537 */         return Collections.emptyList();
/* 330:    */       }
/* 331:539 */       return new DoubleArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 332:    */     }
/* 333:    */     
/* 334:    */     public boolean equals(@Nullable Object object)
/* 335:    */     {
/* 336:544 */       if (object == this) {
/* 337:545 */         return true;
/* 338:    */       }
/* 339:547 */       if ((object instanceof DoubleArrayAsList))
/* 340:    */       {
/* 341:548 */         DoubleArrayAsList that = (DoubleArrayAsList)object;
/* 342:549 */         int size = size();
/* 343:550 */         if (that.size() != size) {
/* 344:551 */           return false;
/* 345:    */         }
/* 346:553 */         for (int i = 0; i < size; i++) {
/* 347:554 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 348:555 */             return false;
/* 349:    */           }
/* 350:    */         }
/* 351:558 */         return true;
/* 352:    */       }
/* 353:560 */       return super.equals(object);
/* 354:    */     }
/* 355:    */     
/* 356:    */     public int hashCode()
/* 357:    */     {
/* 358:565 */       int result = 1;
/* 359:566 */       for (int i = this.start; i < this.end; i++) {
/* 360:567 */         result = 31 * result + Doubles.hashCode(this.array[i]);
/* 361:    */       }
/* 362:569 */       return result;
/* 363:    */     }
/* 364:    */     
/* 365:    */     public String toString()
/* 366:    */     {
/* 367:574 */       StringBuilder builder = new StringBuilder(size() * 12);
/* 368:575 */       builder.append('[').append(this.array[this.start]);
/* 369:576 */       for (int i = this.start + 1; i < this.end; i++) {
/* 370:577 */         builder.append(", ").append(this.array[i]);
/* 371:    */       }
/* 372:579 */       return ']';
/* 373:    */     }
/* 374:    */     
/* 375:    */     double[] toDoubleArray()
/* 376:    */     {
/* 377:584 */       int size = size();
/* 378:585 */       double[] result = new double[size];
/* 379:586 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 380:587 */       return result;
/* 381:    */     }
/* 382:    */   }
/* 383:    */   
/* 384:    */   @GwtIncompatible("regular expressions")
/* 385:600 */   static final Pattern FLOATING_POINT_PATTERN = ;
/* 386:    */   
/* 387:    */   @GwtIncompatible("regular expressions")
/* 388:    */   private static Pattern fpPattern()
/* 389:    */   {
/* 390:604 */     String decimal = "(?:\\d++(?:\\.\\d*+)?|\\.\\d++)";
/* 391:605 */     String completeDec = decimal + "(?:[eE][+-]?\\d++)?[fFdD]?";
/* 392:606 */     String hex = "(?:\\p{XDigit}++(?:\\.\\p{XDigit}*+)?|\\.\\p{XDigit}++)";
/* 393:607 */     String completeHex = "0[xX]" + hex + "[pP][+-]?\\d++[fFdD]?";
/* 394:608 */     String fpPattern = "[+-]?(?:NaN|Infinity|" + completeDec + "|" + completeHex + ")";
/* 395:609 */     return Pattern.compile(fpPattern);
/* 396:    */   }
/* 397:    */   
/* 398:    */   @Nullable
/* 399:    */   @CheckForNull
/* 400:    */   @Beta
/* 401:    */   @GwtIncompatible("regular expressions")
/* 402:    */   public static Double tryParse(String string)
/* 403:    */   {
/* 404:636 */     if (FLOATING_POINT_PATTERN.matcher(string).matches()) {
/* 405:    */       try
/* 406:    */       {
/* 407:640 */         return Double.valueOf(Double.parseDouble(string));
/* 408:    */       }
/* 409:    */       catch (NumberFormatException e) {}
/* 410:    */     }
/* 411:646 */     return null;
/* 412:    */   }
/* 413:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Doubles
 * JD-Core Version:    0.7.0.1
 */