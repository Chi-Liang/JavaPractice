/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.lang.reflect.Field;
/*   7:    */ import java.nio.ByteOrder;
/*   8:    */ import java.security.AccessController;
/*   9:    */ import java.security.PrivilegedActionException;
/*  10:    */ import java.security.PrivilegedExceptionAction;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import javax.annotation.CheckReturnValue;
/*  13:    */ import sun.misc.Unsafe;
/*  14:    */ 
/*  15:    */ public final class UnsignedBytes
/*  16:    */ {
/*  17:    */   public static final byte MAX_POWER_OF_TWO = -128;
/*  18:    */   public static final byte MAX_VALUE = -1;
/*  19:    */   private static final int UNSIGNED_MASK = 255;
/*  20:    */   
/*  21:    */   @CheckReturnValue
/*  22:    */   public static int toInt(byte value)
/*  23:    */   {
/*  24: 78 */     return value & 0xFF;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static byte checkedCast(long value)
/*  28:    */   {
/*  29: 92 */     if (value >> 8 != 0L) {
/*  30: 94 */       throw new IllegalArgumentException("Out of range: " + value);
/*  31:    */     }
/*  32: 96 */     return (byte)(int)value;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static byte saturatedCast(long value)
/*  36:    */   {
/*  37:108 */     if (value > toInt((byte)-1)) {
/*  38:109 */       return -1;
/*  39:    */     }
/*  40:111 */     if (value < 0L) {
/*  41:112 */       return 0;
/*  42:    */     }
/*  43:114 */     return (byte)(int)value;
/*  44:    */   }
/*  45:    */   
/*  46:    */   @CheckReturnValue
/*  47:    */   public static int compare(byte a, byte b)
/*  48:    */   {
/*  49:130 */     return toInt(a) - toInt(b);
/*  50:    */   }
/*  51:    */   
/*  52:    */   @CheckReturnValue
/*  53:    */   public static byte min(byte... array)
/*  54:    */   {
/*  55:143 */     Preconditions.checkArgument(array.length > 0);
/*  56:144 */     int min = toInt(array[0]);
/*  57:145 */     for (int i = 1; i < array.length; i++)
/*  58:    */     {
/*  59:146 */       int next = toInt(array[i]);
/*  60:147 */       if (next < min) {
/*  61:148 */         min = next;
/*  62:    */       }
/*  63:    */     }
/*  64:151 */     return (byte)min;
/*  65:    */   }
/*  66:    */   
/*  67:    */   @CheckReturnValue
/*  68:    */   public static byte max(byte... array)
/*  69:    */   {
/*  70:164 */     Preconditions.checkArgument(array.length > 0);
/*  71:165 */     int max = toInt(array[0]);
/*  72:166 */     for (int i = 1; i < array.length; i++)
/*  73:    */     {
/*  74:167 */       int next = toInt(array[i]);
/*  75:168 */       if (next > max) {
/*  76:169 */         max = next;
/*  77:    */       }
/*  78:    */     }
/*  79:172 */     return (byte)max;
/*  80:    */   }
/*  81:    */   
/*  82:    */   @CheckReturnValue
/*  83:    */   @Beta
/*  84:    */   public static String toString(byte x)
/*  85:    */   {
/*  86:183 */     return toString(x, 10);
/*  87:    */   }
/*  88:    */   
/*  89:    */   @CheckReturnValue
/*  90:    */   @Beta
/*  91:    */   public static String toString(byte x, int radix)
/*  92:    */   {
/*  93:199 */     Preconditions.checkArgument((radix >= 2) && (radix <= 36), "radix (%s) must be between Character.MIN_RADIX and Character.MAX_RADIX", new Object[] { Integer.valueOf(radix) });
/*  94:    */     
/*  95:    */ 
/*  96:    */ 
/*  97:    */ 
/*  98:204 */     return Integer.toString(toInt(x), radix);
/*  99:    */   }
/* 100:    */   
/* 101:    */   @Beta
/* 102:    */   public static byte parseUnsignedByte(String string)
/* 103:    */   {
/* 104:218 */     return parseUnsignedByte(string, 10);
/* 105:    */   }
/* 106:    */   
/* 107:    */   @Beta
/* 108:    */   public static byte parseUnsignedByte(String string, int radix)
/* 109:    */   {
/* 110:235 */     int parse = Integer.parseInt((String)Preconditions.checkNotNull(string), radix);
/* 111:237 */     if (parse >> 8 == 0) {
/* 112:238 */       return (byte)parse;
/* 113:    */     }
/* 114:240 */     throw new NumberFormatException("out of range: " + parse);
/* 115:    */   }
/* 116:    */   
/* 117:    */   @CheckReturnValue
/* 118:    */   public static String join(String separator, byte... array)
/* 119:    */   {
/* 120:255 */     Preconditions.checkNotNull(separator);
/* 121:256 */     if (array.length == 0) {
/* 122:257 */       return "";
/* 123:    */     }
/* 124:261 */     StringBuilder builder = new StringBuilder(array.length * (3 + separator.length()));
/* 125:262 */     builder.append(toInt(array[0]));
/* 126:263 */     for (int i = 1; i < array.length; i++) {
/* 127:264 */       builder.append(separator).append(toString(array[i]));
/* 128:    */     }
/* 129:266 */     return builder.toString();
/* 130:    */   }
/* 131:    */   
/* 132:    */   @CheckReturnValue
/* 133:    */   public static Comparator<byte[]> lexicographicalComparator()
/* 134:    */   {
/* 135:287 */     return LexicographicalComparatorHolder.BEST_COMPARATOR;
/* 136:    */   }
/* 137:    */   
/* 138:    */   @VisibleForTesting
/* 139:    */   static Comparator<byte[]> lexicographicalComparatorJavaImpl()
/* 140:    */   {
/* 141:292 */     return UnsignedBytes.LexicographicalComparatorHolder.PureJavaComparator.INSTANCE;
/* 142:    */   }
/* 143:    */   
/* 144:    */   @VisibleForTesting
/* 145:    */   static class LexicographicalComparatorHolder
/* 146:    */   {
/* 147:304 */     static final String UNSAFE_COMPARATOR_NAME = LexicographicalComparatorHolder.class.getName() + "$UnsafeComparator";
/* 148:307 */     static final Comparator<byte[]> BEST_COMPARATOR = getBestComparator();
/* 149:    */     
/* 150:    */     @VisibleForTesting
/* 151:    */     static enum UnsafeComparator
/* 152:    */       implements Comparator<byte[]>
/* 153:    */     {
/* 154:311 */       INSTANCE;
/* 155:    */       
/* 156:    */       static final boolean BIG_ENDIAN;
/* 157:    */       static final Unsafe theUnsafe;
/* 158:    */       static final int BYTE_ARRAY_BASE_OFFSET;
/* 159:    */       
/* 160:    */       static
/* 161:    */       {
/* 162:313 */         BIG_ENDIAN = ByteOrder.nativeOrder().equals(ByteOrder.BIG_ENDIAN);
/* 163:    */         
/* 164:    */ 
/* 165:    */ 
/* 166:    */ 
/* 167:    */ 
/* 168:    */ 
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:    */ 
/* 180:    */ 
/* 181:    */ 
/* 182:    */ 
/* 183:    */ 
/* 184:    */ 
/* 185:    */ 
/* 186:    */ 
/* 187:    */ 
/* 188:    */ 
/* 189:340 */         theUnsafe = getUnsafe();
/* 190:    */         
/* 191:342 */         BYTE_ARRAY_BASE_OFFSET = theUnsafe.arrayBaseOffset([B.class);
/* 192:345 */         if (theUnsafe.arrayIndexScale([B.class) != 1) {
/* 193:346 */           throw new AssertionError();
/* 194:    */         }
/* 195:    */       }
/* 196:    */       
/* 197:    */       private static Unsafe getUnsafe()
/* 198:    */       {
/* 199:    */         try
/* 200:    */         {
/* 201:359 */           return Unsafe.getUnsafe();
/* 202:    */         }
/* 203:    */         catch (SecurityException e)
/* 204:    */         {
/* 205:    */           try
/* 206:    */           {
/* 207:364 */             (Unsafe)AccessController.doPrivileged(new PrivilegedExceptionAction()
/* 208:    */             {
/* 209:    */               public Unsafe run()
/* 210:    */                 throws Exception
/* 211:    */               {
/* 212:367 */                 Class<Unsafe> k = Unsafe.class;
/* 213:368 */                 for (Field f : k.getDeclaredFields())
/* 214:    */                 {
/* 215:369 */                   f.setAccessible(true);
/* 216:370 */                   Object x = f.get(null);
/* 217:371 */                   if (k.isInstance(x)) {
/* 218:372 */                     return (Unsafe)k.cast(x);
/* 219:    */                   }
/* 220:    */                 }
/* 221:375 */                 throw new NoSuchFieldError("the Unsafe");
/* 222:    */               }
/* 223:    */             });
/* 224:    */           }
/* 225:    */           catch (PrivilegedActionException e)
/* 226:    */           {
/* 227:379 */             throw new RuntimeException("Could not initialize intrinsics", e.getCause());
/* 228:    */           }
/* 229:    */         }
/* 230:    */       }
/* 231:    */       
/* 232:    */       public int compare(byte[] left, byte[] right)
/* 233:    */       {
/* 234:385 */         int minLength = Math.min(left.length, right.length);
/* 235:386 */         int minWords = minLength / 8;
/* 236:393 */         for (int i = 0; i < minWords * 8; i += 8)
/* 237:    */         {
/* 238:394 */           long lw = theUnsafe.getLong(left, BYTE_ARRAY_BASE_OFFSET + i);
/* 239:395 */           long rw = theUnsafe.getLong(right, BYTE_ARRAY_BASE_OFFSET + i);
/* 240:396 */           if (lw != rw)
/* 241:    */           {
/* 242:397 */             if (BIG_ENDIAN) {
/* 243:398 */               return UnsignedLongs.compare(lw, rw);
/* 244:    */             }
/* 245:408 */             int n = Long.numberOfTrailingZeros(lw ^ rw) & 0xFFFFFFF8;
/* 246:409 */             return (int)((lw >>> n & 0xFF) - (rw >>> n & 0xFF));
/* 247:    */           }
/* 248:    */         }
/* 249:414 */         for (int i = minWords * 8; i < minLength; i++)
/* 250:    */         {
/* 251:415 */           int result = UnsignedBytes.compare(left[i], right[i]);
/* 252:416 */           if (result != 0) {
/* 253:417 */             return result;
/* 254:    */           }
/* 255:    */         }
/* 256:420 */         return left.length - right.length;
/* 257:    */       }
/* 258:    */       
/* 259:    */       private UnsafeComparator() {}
/* 260:    */     }
/* 261:    */     
/* 262:    */     static enum PureJavaComparator
/* 263:    */       implements Comparator<byte[]>
/* 264:    */     {
/* 265:425 */       INSTANCE;
/* 266:    */       
/* 267:    */       private PureJavaComparator() {}
/* 268:    */       
/* 269:    */       public int compare(byte[] left, byte[] right)
/* 270:    */       {
/* 271:429 */         int minLength = Math.min(left.length, right.length);
/* 272:430 */         for (int i = 0; i < minLength; i++)
/* 273:    */         {
/* 274:431 */           int result = UnsignedBytes.compare(left[i], right[i]);
/* 275:432 */           if (result != 0) {
/* 276:433 */             return result;
/* 277:    */           }
/* 278:    */         }
/* 279:436 */         return left.length - right.length;
/* 280:    */       }
/* 281:    */     }
/* 282:    */     
/* 283:    */     static Comparator<byte[]> getBestComparator()
/* 284:    */     {
/* 285:    */       try
/* 286:    */       {
/* 287:446 */         Class<?> theClass = Class.forName(UNSAFE_COMPARATOR_NAME);
/* 288:    */         
/* 289:    */ 
/* 290:    */ 
/* 291:450 */         return (Comparator)theClass.getEnumConstants()[0];
/* 292:    */       }
/* 293:    */       catch (Throwable t) {}
/* 294:453 */       return UnsignedBytes.lexicographicalComparatorJavaImpl();
/* 295:    */     }
/* 296:    */   }
/* 297:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.UnsignedBytes
 * JD-Core Version:    0.7.0.1
 */