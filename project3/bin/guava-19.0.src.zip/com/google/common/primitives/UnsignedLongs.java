/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.math.BigInteger;
/*   7:    */ import java.util.Comparator;
/*   8:    */ import javax.annotation.CheckReturnValue;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ @GwtCompatible
/*  12:    */ public final class UnsignedLongs
/*  13:    */ {
/*  14:    */   public static final long MAX_VALUE = -1L;
/*  15:    */   
/*  16:    */   private static long flip(long a)
/*  17:    */   {
/*  18: 65 */     return a ^ 0x0;
/*  19:    */   }
/*  20:    */   
/*  21:    */   @CheckReturnValue
/*  22:    */   public static int compare(long a, long b)
/*  23:    */   {
/*  24: 79 */     return Longs.compare(flip(a), flip(b));
/*  25:    */   }
/*  26:    */   
/*  27:    */   @CheckReturnValue
/*  28:    */   public static long min(long... array)
/*  29:    */   {
/*  30: 92 */     Preconditions.checkArgument(array.length > 0);
/*  31: 93 */     long min = flip(array[0]);
/*  32: 94 */     for (int i = 1; i < array.length; i++)
/*  33:    */     {
/*  34: 95 */       long next = flip(array[i]);
/*  35: 96 */       if (next < min) {
/*  36: 97 */         min = next;
/*  37:    */       }
/*  38:    */     }
/*  39:100 */     return flip(min);
/*  40:    */   }
/*  41:    */   
/*  42:    */   @CheckReturnValue
/*  43:    */   public static long max(long... array)
/*  44:    */   {
/*  45:113 */     Preconditions.checkArgument(array.length > 0);
/*  46:114 */     long max = flip(array[0]);
/*  47:115 */     for (int i = 1; i < array.length; i++)
/*  48:    */     {
/*  49:116 */       long next = flip(array[i]);
/*  50:117 */       if (next > max) {
/*  51:118 */         max = next;
/*  52:    */       }
/*  53:    */     }
/*  54:121 */     return flip(max);
/*  55:    */   }
/*  56:    */   
/*  57:    */   @CheckReturnValue
/*  58:    */   public static String join(String separator, long... array)
/*  59:    */   {
/*  60:134 */     Preconditions.checkNotNull(separator);
/*  61:135 */     if (array.length == 0) {
/*  62:136 */       return "";
/*  63:    */     }
/*  64:140 */     StringBuilder builder = new StringBuilder(array.length * 5);
/*  65:141 */     builder.append(toString(array[0]));
/*  66:142 */     for (int i = 1; i < array.length; i++) {
/*  67:143 */       builder.append(separator).append(toString(array[i]));
/*  68:    */     }
/*  69:145 */     return builder.toString();
/*  70:    */   }
/*  71:    */   
/*  72:    */   @CheckReturnValue
/*  73:    */   public static Comparator<long[]> lexicographicalComparator()
/*  74:    */   {
/*  75:163 */     return LexicographicalComparator.INSTANCE;
/*  76:    */   }
/*  77:    */   
/*  78:    */   static enum LexicographicalComparator
/*  79:    */     implements Comparator<long[]>
/*  80:    */   {
/*  81:167 */     INSTANCE;
/*  82:    */     
/*  83:    */     private LexicographicalComparator() {}
/*  84:    */     
/*  85:    */     public int compare(long[] left, long[] right)
/*  86:    */     {
/*  87:171 */       int minLength = Math.min(left.length, right.length);
/*  88:172 */       for (int i = 0; i < minLength; i++) {
/*  89:173 */         if (left[i] != right[i]) {
/*  90:174 */           return UnsignedLongs.compare(left[i], right[i]);
/*  91:    */         }
/*  92:    */       }
/*  93:177 */       return left.length - right.length;
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   @CheckReturnValue
/*  98:    */   public static long divide(long dividend, long divisor)
/*  99:    */   {
/* 100:191 */     if (divisor < 0L)
/* 101:    */     {
/* 102:192 */       if (compare(dividend, divisor) < 0) {
/* 103:193 */         return 0L;
/* 104:    */       }
/* 105:195 */       return 1L;
/* 106:    */     }
/* 107:200 */     if (dividend >= 0L) {
/* 108:201 */       return dividend / divisor;
/* 109:    */     }
/* 110:210 */     long quotient = (dividend >>> 1) / divisor << 1;
/* 111:211 */     long rem = dividend - quotient * divisor;
/* 112:212 */     return quotient + (compare(rem, divisor) >= 0 ? 1 : 0);
/* 113:    */   }
/* 114:    */   
/* 115:    */   @CheckReturnValue
/* 116:    */   public static long remainder(long dividend, long divisor)
/* 117:    */   {
/* 118:226 */     if (divisor < 0L)
/* 119:    */     {
/* 120:227 */       if (compare(dividend, divisor) < 0) {
/* 121:228 */         return dividend;
/* 122:    */       }
/* 123:230 */       return dividend - divisor;
/* 124:    */     }
/* 125:235 */     if (dividend >= 0L) {
/* 126:236 */       return dividend % divisor;
/* 127:    */     }
/* 128:245 */     long quotient = (dividend >>> 1) / divisor << 1;
/* 129:246 */     long rem = dividend - quotient * divisor;
/* 130:247 */     return rem - (compare(rem, divisor) >= 0 ? divisor : 0L);
/* 131:    */   }
/* 132:    */   
/* 133:    */   public static long parseUnsignedLong(String s)
/* 134:    */   {
/* 135:259 */     return parseUnsignedLong(s, 10);
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static long decode(String stringValue)
/* 139:    */   {
/* 140:279 */     ParseRequest request = ParseRequest.fromString(stringValue);
/* 141:    */     try
/* 142:    */     {
/* 143:282 */       return parseUnsignedLong(request.rawValue, request.radix);
/* 144:    */     }
/* 145:    */     catch (NumberFormatException e)
/* 146:    */     {
/* 147:284 */       NumberFormatException decodeException = new NumberFormatException("Error parsing value: " + stringValue);
/* 148:    */       
/* 149:286 */       decodeException.initCause(e);
/* 150:287 */       throw decodeException;
/* 151:    */     }
/* 152:    */   }
/* 153:    */   
/* 154:    */   public static long parseUnsignedLong(String s, int radix)
/* 155:    */   {
/* 156:303 */     Preconditions.checkNotNull(s);
/* 157:304 */     if (s.length() == 0) {
/* 158:305 */       throw new NumberFormatException("empty string");
/* 159:    */     }
/* 160:307 */     if ((radix < 2) || (radix > 36)) {
/* 161:308 */       throw new NumberFormatException("illegal radix: " + radix);
/* 162:    */     }
/* 163:311 */     int max_safe_pos = maxSafeDigits[radix] - 1;
/* 164:312 */     long value = 0L;
/* 165:313 */     for (int pos = 0; pos < s.length(); pos++)
/* 166:    */     {
/* 167:314 */       int digit = Character.digit(s.charAt(pos), radix);
/* 168:315 */       if (digit == -1) {
/* 169:316 */         throw new NumberFormatException(s);
/* 170:    */       }
/* 171:318 */       if ((pos > max_safe_pos) && (overflowInParse(value, digit, radix))) {
/* 172:319 */         throw new NumberFormatException("Too large for unsigned long: " + s);
/* 173:    */       }
/* 174:321 */       value = value * radix + digit;
/* 175:    */     }
/* 176:324 */     return value;
/* 177:    */   }
/* 178:    */   
/* 179:    */   private static boolean overflowInParse(long current, int digit, int radix)
/* 180:    */   {
/* 181:334 */     if (current >= 0L)
/* 182:    */     {
/* 183:335 */       if (current < maxValueDivs[radix]) {
/* 184:336 */         return false;
/* 185:    */       }
/* 186:338 */       if (current > maxValueDivs[radix]) {
/* 187:339 */         return true;
/* 188:    */       }
/* 189:342 */       return digit > maxValueMods[radix];
/* 190:    */     }
/* 191:346 */     return true;
/* 192:    */   }
/* 193:    */   
/* 194:    */   @CheckReturnValue
/* 195:    */   public static String toString(long x)
/* 196:    */   {
/* 197:354 */     return toString(x, 10);
/* 198:    */   }
/* 199:    */   
/* 200:    */   @CheckReturnValue
/* 201:    */   public static String toString(long x, int radix)
/* 202:    */   {
/* 203:368 */     Preconditions.checkArgument((radix >= 2) && (radix <= 36), "radix (%s) must be between Character.MIN_RADIX and Character.MAX_RADIX", new Object[] { Integer.valueOf(radix) });
/* 204:372 */     if (x == 0L) {
/* 205:374 */       return "0";
/* 206:    */     }
/* 207:376 */     char[] buf = new char[64];
/* 208:377 */     int i = buf.length;
/* 209:378 */     if (x < 0L)
/* 210:    */     {
/* 211:381 */       long quotient = divide(x, radix);
/* 212:382 */       long rem = x - quotient * radix;
/* 213:383 */       buf[(--i)] = Character.forDigit((int)rem, radix);
/* 214:384 */       x = quotient;
/* 215:    */     }
/* 216:387 */     while (x > 0L)
/* 217:    */     {
/* 218:388 */       buf[(--i)] = Character.forDigit((int)(x % radix), radix);
/* 219:389 */       x /= radix;
/* 220:    */     }
/* 221:392 */     return new String(buf, i, buf.length - i);
/* 222:    */   }
/* 223:    */   
/* 224:397 */   private static final long[] maxValueDivs = new long[37];
/* 225:398 */   private static final int[] maxValueMods = new int[37];
/* 226:399 */   private static final int[] maxSafeDigits = new int[37];
/* 227:    */   
/* 228:    */   static
/* 229:    */   {
/* 230:402 */     BigInteger overflow = new BigInteger("10000000000000000", 16);
/* 231:403 */     for (int i = 2; i <= 36; i++)
/* 232:    */     {
/* 233:404 */       maxValueDivs[i] = divide(-1L, i);
/* 234:405 */       maxValueMods[i] = ((int)remainder(-1L, i));
/* 235:406 */       maxSafeDigits[i] = (overflow.toString(i).length() - 1);
/* 236:    */     }
/* 237:    */   }
/* 238:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.UnsignedLongs
 * JD-Core Version:    0.7.0.1
 */