/*  1:   */ package com.google.common.primitives;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import javax.annotation.CheckReturnValue;
/*  5:   */ 
/*  6:   */ @CheckReturnValue
/*  7:   */ @GwtCompatible
/*  8:   */ final class ParseRequest
/*  9:   */ {
/* 10:   */   final String rawValue;
/* 11:   */   final int radix;
/* 12:   */   
/* 13:   */   private ParseRequest(String rawValue, int radix)
/* 14:   */   {
/* 15:31 */     this.rawValue = rawValue;
/* 16:32 */     this.radix = radix;
/* 17:   */   }
/* 18:   */   
/* 19:   */   static ParseRequest fromString(String stringValue)
/* 20:   */   {
/* 21:36 */     if (stringValue.length() == 0) {
/* 22:37 */       throw new NumberFormatException("empty string");
/* 23:   */     }
/* 24:43 */     char firstChar = stringValue.charAt(0);
/* 25:   */     int radix;
/* 26:   */     String rawValue;
/* 27:   */     int radix;
/* 28:44 */     if ((stringValue.startsWith("0x")) || (stringValue.startsWith("0X")))
/* 29:   */     {
/* 30:45 */       String rawValue = stringValue.substring(2);
/* 31:46 */       radix = 16;
/* 32:   */     }
/* 33:   */     else
/* 34:   */     {
/* 35:   */       int radix;
/* 36:47 */       if (firstChar == '#')
/* 37:   */       {
/* 38:48 */         String rawValue = stringValue.substring(1);
/* 39:49 */         radix = 16;
/* 40:   */       }
/* 41:   */       else
/* 42:   */       {
/* 43:   */         int radix;
/* 44:50 */         if ((firstChar == '0') && (stringValue.length() > 1))
/* 45:   */         {
/* 46:51 */           String rawValue = stringValue.substring(1);
/* 47:52 */           radix = 8;
/* 48:   */         }
/* 49:   */         else
/* 50:   */         {
/* 51:54 */           rawValue = stringValue;
/* 52:55 */           radix = 10;
/* 53:   */         }
/* 54:   */       }
/* 55:   */     }
/* 56:58 */     return new ParseRequest(rawValue, radix);
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.ParseRequest
 * JD-Core Version:    0.7.0.1
 */