/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.AbstractList;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.RandomAccess;
/*  13:    */ import javax.annotation.CheckReturnValue;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @CheckReturnValue
/*  17:    */ @GwtCompatible
/*  18:    */ public final class Booleans
/*  19:    */ {
/*  20:    */   public static int hashCode(boolean value)
/*  21:    */   {
/*  22: 63 */     return value ? 1231 : 1237;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static int compare(boolean a, boolean b)
/*  26:    */   {
/*  27: 80 */     return a ? 1 : a == b ? 0 : -1;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static boolean contains(boolean[] array, boolean target)
/*  31:    */   {
/*  32: 98 */     for (boolean value : array) {
/*  33: 99 */       if (value == target) {
/*  34:100 */         return true;
/*  35:    */       }
/*  36:    */     }
/*  37:103 */     return false;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static int indexOf(boolean[] array, boolean target)
/*  41:    */   {
/*  42:121 */     return indexOf(array, target, 0, array.length);
/*  43:    */   }
/*  44:    */   
/*  45:    */   private static int indexOf(boolean[] array, boolean target, int start, int end)
/*  46:    */   {
/*  47:126 */     for (int i = start; i < end; i++) {
/*  48:127 */       if (array[i] == target) {
/*  49:128 */         return i;
/*  50:    */       }
/*  51:    */     }
/*  52:131 */     return -1;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static int indexOf(boolean[] array, boolean[] target)
/*  56:    */   {
/*  57:146 */     Preconditions.checkNotNull(array, "array");
/*  58:147 */     Preconditions.checkNotNull(target, "target");
/*  59:148 */     if (target.length == 0) {
/*  60:149 */       return 0;
/*  61:    */     }
/*  62:    */     label64:
/*  63:153 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  64:    */     {
/*  65:154 */       for (int j = 0; j < target.length; j++) {
/*  66:155 */         if (array[(i + j)] != target[j]) {
/*  67:    */           break label64;
/*  68:    */         }
/*  69:    */       }
/*  70:159 */       return i;
/*  71:    */     }
/*  72:161 */     return -1;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static int lastIndexOf(boolean[] array, boolean target)
/*  76:    */   {
/*  77:174 */     return lastIndexOf(array, target, 0, array.length);
/*  78:    */   }
/*  79:    */   
/*  80:    */   private static int lastIndexOf(boolean[] array, boolean target, int start, int end)
/*  81:    */   {
/*  82:179 */     for (int i = end - 1; i >= start; i--) {
/*  83:180 */       if (array[i] == target) {
/*  84:181 */         return i;
/*  85:    */       }
/*  86:    */     }
/*  87:184 */     return -1;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static boolean[] concat(boolean[]... arrays)
/*  91:    */   {
/*  92:197 */     int length = 0;
/*  93:198 */     for (boolean[] array : arrays) {
/*  94:199 */       length += array.length;
/*  95:    */     }
/*  96:201 */     boolean[] result = new boolean[length];
/*  97:202 */     int pos = 0;
/*  98:203 */     for (boolean[] array : arrays)
/*  99:    */     {
/* 100:204 */       System.arraycopy(array, 0, result, pos, array.length);
/* 101:205 */       pos += array.length;
/* 102:    */     }
/* 103:207 */     return result;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static boolean[] ensureCapacity(boolean[] array, int minLength, int padding)
/* 107:    */   {
/* 108:227 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 109:228 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 110:229 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 111:    */   }
/* 112:    */   
/* 113:    */   private static boolean[] copyOf(boolean[] original, int length)
/* 114:    */   {
/* 115:236 */     boolean[] copy = new boolean[length];
/* 116:237 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 117:238 */     return copy;
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static String join(String separator, boolean... array)
/* 121:    */   {
/* 122:251 */     Preconditions.checkNotNull(separator);
/* 123:252 */     if (array.length == 0) {
/* 124:253 */       return "";
/* 125:    */     }
/* 126:257 */     StringBuilder builder = new StringBuilder(array.length * 7);
/* 127:258 */     builder.append(array[0]);
/* 128:259 */     for (int i = 1; i < array.length; i++) {
/* 129:260 */       builder.append(separator).append(array[i]);
/* 130:    */     }
/* 131:262 */     return builder.toString();
/* 132:    */   }
/* 133:    */   
/* 134:    */   public static Comparator<boolean[]> lexicographicalComparator()
/* 135:    */   {
/* 136:282 */     return LexicographicalComparator.INSTANCE;
/* 137:    */   }
/* 138:    */   
/* 139:    */   private static enum LexicographicalComparator
/* 140:    */     implements Comparator<boolean[]>
/* 141:    */   {
/* 142:286 */     INSTANCE;
/* 143:    */     
/* 144:    */     private LexicographicalComparator() {}
/* 145:    */     
/* 146:    */     public int compare(boolean[] left, boolean[] right)
/* 147:    */     {
/* 148:290 */       int minLength = Math.min(left.length, right.length);
/* 149:291 */       for (int i = 0; i < minLength; i++)
/* 150:    */       {
/* 151:292 */         int result = Booleans.compare(left[i], right[i]);
/* 152:293 */         if (result != 0) {
/* 153:294 */           return result;
/* 154:    */         }
/* 155:    */       }
/* 156:297 */       return left.length - right.length;
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   public static boolean[] toArray(Collection<Boolean> collection)
/* 161:    */   {
/* 162:319 */     if ((collection instanceof BooleanArrayAsList)) {
/* 163:320 */       return ((BooleanArrayAsList)collection).toBooleanArray();
/* 164:    */     }
/* 165:323 */     Object[] boxedArray = collection.toArray();
/* 166:324 */     int len = boxedArray.length;
/* 167:325 */     boolean[] array = new boolean[len];
/* 168:326 */     for (int i = 0; i < len; i++) {
/* 169:328 */       array[i] = ((Boolean)Preconditions.checkNotNull(boxedArray[i])).booleanValue();
/* 170:    */     }
/* 171:330 */     return array;
/* 172:    */   }
/* 173:    */   
/* 174:    */   public static List<Boolean> asList(boolean... backingArray)
/* 175:    */   {
/* 176:348 */     if (backingArray.length == 0) {
/* 177:349 */       return Collections.emptyList();
/* 178:    */     }
/* 179:351 */     return new BooleanArrayAsList(backingArray);
/* 180:    */   }
/* 181:    */   
/* 182:    */   @GwtCompatible
/* 183:    */   private static class BooleanArrayAsList
/* 184:    */     extends AbstractList<Boolean>
/* 185:    */     implements RandomAccess, Serializable
/* 186:    */   {
/* 187:    */     final boolean[] array;
/* 188:    */     final int start;
/* 189:    */     final int end;
/* 190:    */     private static final long serialVersionUID = 0L;
/* 191:    */     
/* 192:    */     BooleanArrayAsList(boolean[] array)
/* 193:    */     {
/* 194:362 */       this(array, 0, array.length);
/* 195:    */     }
/* 196:    */     
/* 197:    */     BooleanArrayAsList(boolean[] array, int start, int end)
/* 198:    */     {
/* 199:366 */       this.array = array;
/* 200:367 */       this.start = start;
/* 201:368 */       this.end = end;
/* 202:    */     }
/* 203:    */     
/* 204:    */     public int size()
/* 205:    */     {
/* 206:373 */       return this.end - this.start;
/* 207:    */     }
/* 208:    */     
/* 209:    */     public boolean isEmpty()
/* 210:    */     {
/* 211:378 */       return false;
/* 212:    */     }
/* 213:    */     
/* 214:    */     public Boolean get(int index)
/* 215:    */     {
/* 216:383 */       Preconditions.checkElementIndex(index, size());
/* 217:384 */       return Boolean.valueOf(this.array[(this.start + index)]);
/* 218:    */     }
/* 219:    */     
/* 220:    */     public boolean contains(Object target)
/* 221:    */     {
/* 222:390 */       return ((target instanceof Boolean)) && (Booleans.indexOf(this.array, ((Boolean)target).booleanValue(), this.start, this.end) != -1);
/* 223:    */     }
/* 224:    */     
/* 225:    */     public int indexOf(Object target)
/* 226:    */     {
/* 227:397 */       if ((target instanceof Boolean))
/* 228:    */       {
/* 229:398 */         int i = Booleans.indexOf(this.array, ((Boolean)target).booleanValue(), this.start, this.end);
/* 230:399 */         if (i >= 0) {
/* 231:400 */           return i - this.start;
/* 232:    */         }
/* 233:    */       }
/* 234:403 */       return -1;
/* 235:    */     }
/* 236:    */     
/* 237:    */     public int lastIndexOf(Object target)
/* 238:    */     {
/* 239:409 */       if ((target instanceof Boolean))
/* 240:    */       {
/* 241:410 */         int i = Booleans.lastIndexOf(this.array, ((Boolean)target).booleanValue(), this.start, this.end);
/* 242:411 */         if (i >= 0) {
/* 243:412 */           return i - this.start;
/* 244:    */         }
/* 245:    */       }
/* 246:415 */       return -1;
/* 247:    */     }
/* 248:    */     
/* 249:    */     public Boolean set(int index, Boolean element)
/* 250:    */     {
/* 251:420 */       Preconditions.checkElementIndex(index, size());
/* 252:421 */       boolean oldValue = this.array[(this.start + index)];
/* 253:    */       
/* 254:423 */       this.array[(this.start + index)] = ((Boolean)Preconditions.checkNotNull(element)).booleanValue();
/* 255:424 */       return Boolean.valueOf(oldValue);
/* 256:    */     }
/* 257:    */     
/* 258:    */     public List<Boolean> subList(int fromIndex, int toIndex)
/* 259:    */     {
/* 260:429 */       int size = size();
/* 261:430 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 262:431 */       if (fromIndex == toIndex) {
/* 263:432 */         return Collections.emptyList();
/* 264:    */       }
/* 265:434 */       return new BooleanArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 266:    */     }
/* 267:    */     
/* 268:    */     public boolean equals(@Nullable Object object)
/* 269:    */     {
/* 270:439 */       if (object == this) {
/* 271:440 */         return true;
/* 272:    */       }
/* 273:442 */       if ((object instanceof BooleanArrayAsList))
/* 274:    */       {
/* 275:443 */         BooleanArrayAsList that = (BooleanArrayAsList)object;
/* 276:444 */         int size = size();
/* 277:445 */         if (that.size() != size) {
/* 278:446 */           return false;
/* 279:    */         }
/* 280:448 */         for (int i = 0; i < size; i++) {
/* 281:449 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 282:450 */             return false;
/* 283:    */           }
/* 284:    */         }
/* 285:453 */         return true;
/* 286:    */       }
/* 287:455 */       return super.equals(object);
/* 288:    */     }
/* 289:    */     
/* 290:    */     public int hashCode()
/* 291:    */     {
/* 292:460 */       int result = 1;
/* 293:461 */       for (int i = this.start; i < this.end; i++) {
/* 294:462 */         result = 31 * result + Booleans.hashCode(this.array[i]);
/* 295:    */       }
/* 296:464 */       return result;
/* 297:    */     }
/* 298:    */     
/* 299:    */     public String toString()
/* 300:    */     {
/* 301:469 */       StringBuilder builder = new StringBuilder(size() * 7);
/* 302:470 */       builder.append(this.array[this.start] != 0 ? "[true" : "[false");
/* 303:471 */       for (int i = this.start + 1; i < this.end; i++) {
/* 304:472 */         builder.append(this.array[i] != 0 ? ", true" : ", false");
/* 305:    */       }
/* 306:474 */       return ']';
/* 307:    */     }
/* 308:    */     
/* 309:    */     boolean[] toBooleanArray()
/* 310:    */     {
/* 311:479 */       int size = size();
/* 312:480 */       boolean[] result = new boolean[size];
/* 313:481 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 314:482 */       return result;
/* 315:    */     }
/* 316:    */   }
/* 317:    */   
/* 318:    */   @Beta
/* 319:    */   public static int countTrue(boolean... values)
/* 320:    */   {
/* 321:495 */     int count = 0;
/* 322:496 */     for (boolean value : values) {
/* 323:497 */       if (value) {
/* 324:498 */         count++;
/* 325:    */       }
/* 326:    */     }
/* 327:501 */     return count;
/* 328:    */   }
/* 329:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Booleans
 * JD-Core Version:    0.7.0.1
 */