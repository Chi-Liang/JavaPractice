/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.AbstractList;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Collections;
/*   9:    */ import java.util.List;
/*  10:    */ import java.util.RandomAccess;
/*  11:    */ import javax.annotation.CheckReturnValue;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @CheckReturnValue
/*  15:    */ @GwtCompatible
/*  16:    */ public final class Bytes
/*  17:    */ {
/*  18:    */   public static int hashCode(byte value)
/*  19:    */   {
/*  20: 66 */     return value;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static boolean contains(byte[] array, byte target)
/*  24:    */   {
/*  25: 79 */     for (byte value : array) {
/*  26: 80 */       if (value == target) {
/*  27: 81 */         return true;
/*  28:    */       }
/*  29:    */     }
/*  30: 84 */     return false;
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static int indexOf(byte[] array, byte target)
/*  34:    */   {
/*  35: 97 */     return indexOf(array, target, 0, array.length);
/*  36:    */   }
/*  37:    */   
/*  38:    */   private static int indexOf(byte[] array, byte target, int start, int end)
/*  39:    */   {
/*  40:102 */     for (int i = start; i < end; i++) {
/*  41:103 */       if (array[i] == target) {
/*  42:104 */         return i;
/*  43:    */       }
/*  44:    */     }
/*  45:107 */     return -1;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static int indexOf(byte[] array, byte[] target)
/*  49:    */   {
/*  50:122 */     Preconditions.checkNotNull(array, "array");
/*  51:123 */     Preconditions.checkNotNull(target, "target");
/*  52:124 */     if (target.length == 0) {
/*  53:125 */       return 0;
/*  54:    */     }
/*  55:    */     label64:
/*  56:129 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  57:    */     {
/*  58:130 */       for (int j = 0; j < target.length; j++) {
/*  59:131 */         if (array[(i + j)] != target[j]) {
/*  60:    */           break label64;
/*  61:    */         }
/*  62:    */       }
/*  63:135 */       return i;
/*  64:    */     }
/*  65:137 */     return -1;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static int lastIndexOf(byte[] array, byte target)
/*  69:    */   {
/*  70:150 */     return lastIndexOf(array, target, 0, array.length);
/*  71:    */   }
/*  72:    */   
/*  73:    */   private static int lastIndexOf(byte[] array, byte target, int start, int end)
/*  74:    */   {
/*  75:155 */     for (int i = end - 1; i >= start; i--) {
/*  76:156 */       if (array[i] == target) {
/*  77:157 */         return i;
/*  78:    */       }
/*  79:    */     }
/*  80:160 */     return -1;
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static byte[] concat(byte[]... arrays)
/*  84:    */   {
/*  85:173 */     int length = 0;
/*  86:174 */     for (byte[] array : arrays) {
/*  87:175 */       length += array.length;
/*  88:    */     }
/*  89:177 */     byte[] result = new byte[length];
/*  90:178 */     int pos = 0;
/*  91:179 */     for (byte[] array : arrays)
/*  92:    */     {
/*  93:180 */       System.arraycopy(array, 0, result, pos, array.length);
/*  94:181 */       pos += array.length;
/*  95:    */     }
/*  96:183 */     return result;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static byte[] ensureCapacity(byte[] array, int minLength, int padding)
/* 100:    */   {
/* 101:203 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 102:204 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 103:205 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 104:    */   }
/* 105:    */   
/* 106:    */   private static byte[] copyOf(byte[] original, int length)
/* 107:    */   {
/* 108:212 */     byte[] copy = new byte[length];
/* 109:213 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 110:214 */     return copy;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static byte[] toArray(Collection<? extends Number> collection)
/* 114:    */   {
/* 115:233 */     if ((collection instanceof ByteArrayAsList)) {
/* 116:234 */       return ((ByteArrayAsList)collection).toByteArray();
/* 117:    */     }
/* 118:237 */     Object[] boxedArray = collection.toArray();
/* 119:238 */     int len = boxedArray.length;
/* 120:239 */     byte[] array = new byte[len];
/* 121:240 */     for (int i = 0; i < len; i++) {
/* 122:242 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).byteValue();
/* 123:    */     }
/* 124:244 */     return array;
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static List<Byte> asList(byte... backingArray)
/* 128:    */   {
/* 129:262 */     if (backingArray.length == 0) {
/* 130:263 */       return Collections.emptyList();
/* 131:    */     }
/* 132:265 */     return new ByteArrayAsList(backingArray);
/* 133:    */   }
/* 134:    */   
/* 135:    */   @GwtCompatible
/* 136:    */   private static class ByteArrayAsList
/* 137:    */     extends AbstractList<Byte>
/* 138:    */     implements RandomAccess, Serializable
/* 139:    */   {
/* 140:    */     final byte[] array;
/* 141:    */     final int start;
/* 142:    */     final int end;
/* 143:    */     private static final long serialVersionUID = 0L;
/* 144:    */     
/* 145:    */     ByteArrayAsList(byte[] array)
/* 146:    */     {
/* 147:276 */       this(array, 0, array.length);
/* 148:    */     }
/* 149:    */     
/* 150:    */     ByteArrayAsList(byte[] array, int start, int end)
/* 151:    */     {
/* 152:280 */       this.array = array;
/* 153:281 */       this.start = start;
/* 154:282 */       this.end = end;
/* 155:    */     }
/* 156:    */     
/* 157:    */     public int size()
/* 158:    */     {
/* 159:287 */       return this.end - this.start;
/* 160:    */     }
/* 161:    */     
/* 162:    */     public boolean isEmpty()
/* 163:    */     {
/* 164:292 */       return false;
/* 165:    */     }
/* 166:    */     
/* 167:    */     public Byte get(int index)
/* 168:    */     {
/* 169:297 */       Preconditions.checkElementIndex(index, size());
/* 170:298 */       return Byte.valueOf(this.array[(this.start + index)]);
/* 171:    */     }
/* 172:    */     
/* 173:    */     public boolean contains(Object target)
/* 174:    */     {
/* 175:304 */       return ((target instanceof Byte)) && (Bytes.indexOf(this.array, ((Byte)target).byteValue(), this.start, this.end) != -1);
/* 176:    */     }
/* 177:    */     
/* 178:    */     public int indexOf(Object target)
/* 179:    */     {
/* 180:310 */       if ((target instanceof Byte))
/* 181:    */       {
/* 182:311 */         int i = Bytes.indexOf(this.array, ((Byte)target).byteValue(), this.start, this.end);
/* 183:312 */         if (i >= 0) {
/* 184:313 */           return i - this.start;
/* 185:    */         }
/* 186:    */       }
/* 187:316 */       return -1;
/* 188:    */     }
/* 189:    */     
/* 190:    */     public int lastIndexOf(Object target)
/* 191:    */     {
/* 192:322 */       if ((target instanceof Byte))
/* 193:    */       {
/* 194:323 */         int i = Bytes.lastIndexOf(this.array, ((Byte)target).byteValue(), this.start, this.end);
/* 195:324 */         if (i >= 0) {
/* 196:325 */           return i - this.start;
/* 197:    */         }
/* 198:    */       }
/* 199:328 */       return -1;
/* 200:    */     }
/* 201:    */     
/* 202:    */     public Byte set(int index, Byte element)
/* 203:    */     {
/* 204:333 */       Preconditions.checkElementIndex(index, size());
/* 205:334 */       byte oldValue = this.array[(this.start + index)];
/* 206:    */       
/* 207:336 */       this.array[(this.start + index)] = ((Byte)Preconditions.checkNotNull(element)).byteValue();
/* 208:337 */       return Byte.valueOf(oldValue);
/* 209:    */     }
/* 210:    */     
/* 211:    */     public List<Byte> subList(int fromIndex, int toIndex)
/* 212:    */     {
/* 213:342 */       int size = size();
/* 214:343 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 215:344 */       if (fromIndex == toIndex) {
/* 216:345 */         return Collections.emptyList();
/* 217:    */       }
/* 218:347 */       return new ByteArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 219:    */     }
/* 220:    */     
/* 221:    */     public boolean equals(@Nullable Object object)
/* 222:    */     {
/* 223:352 */       if (object == this) {
/* 224:353 */         return true;
/* 225:    */       }
/* 226:355 */       if ((object instanceof ByteArrayAsList))
/* 227:    */       {
/* 228:356 */         ByteArrayAsList that = (ByteArrayAsList)object;
/* 229:357 */         int size = size();
/* 230:358 */         if (that.size() != size) {
/* 231:359 */           return false;
/* 232:    */         }
/* 233:361 */         for (int i = 0; i < size; i++) {
/* 234:362 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 235:363 */             return false;
/* 236:    */           }
/* 237:    */         }
/* 238:366 */         return true;
/* 239:    */       }
/* 240:368 */       return super.equals(object);
/* 241:    */     }
/* 242:    */     
/* 243:    */     public int hashCode()
/* 244:    */     {
/* 245:373 */       int result = 1;
/* 246:374 */       for (int i = this.start; i < this.end; i++) {
/* 247:375 */         result = 31 * result + Bytes.hashCode(this.array[i]);
/* 248:    */       }
/* 249:377 */       return result;
/* 250:    */     }
/* 251:    */     
/* 252:    */     public String toString()
/* 253:    */     {
/* 254:382 */       StringBuilder builder = new StringBuilder(size() * 5);
/* 255:383 */       builder.append('[').append(this.array[this.start]);
/* 256:384 */       for (int i = this.start + 1; i < this.end; i++) {
/* 257:385 */         builder.append(", ").append(this.array[i]);
/* 258:    */       }
/* 259:387 */       return ']';
/* 260:    */     }
/* 261:    */     
/* 262:    */     byte[] toByteArray()
/* 263:    */     {
/* 264:392 */       int size = size();
/* 265:393 */       byte[] result = new byte[size];
/* 266:394 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 267:395 */       return result;
/* 268:    */     }
/* 269:    */   }
/* 270:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Bytes
 * JD-Core Version:    0.7.0.1
 */