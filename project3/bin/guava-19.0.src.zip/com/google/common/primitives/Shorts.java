/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Converter;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.RandomAccess;
/*  15:    */ import javax.annotation.CheckReturnValue;
/*  16:    */ 
/*  17:    */ @CheckReturnValue
/*  18:    */ @GwtCompatible(emulated=true)
/*  19:    */ public final class Shorts
/*  20:    */ {
/*  21:    */   public static final int BYTES = 2;
/*  22:    */   public static final short MAX_POWER_OF_TWO = 16384;
/*  23:    */   
/*  24:    */   public static int hashCode(short value)
/*  25:    */   {
/*  26: 77 */     return value;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static short checkedCast(long value)
/*  30:    */   {
/*  31: 90 */     short result = (short)(int)value;
/*  32: 91 */     if (result != value) {
/*  33: 93 */       throw new IllegalArgumentException("Out of range: " + value);
/*  34:    */     }
/*  35: 95 */     return result;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static short saturatedCast(long value)
/*  39:    */   {
/*  40:107 */     if (value > 32767L) {
/*  41:108 */       return 32767;
/*  42:    */     }
/*  43:110 */     if (value < -32768L) {
/*  44:111 */       return -32768;
/*  45:    */     }
/*  46:113 */     return (short)(int)value;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static int compare(short a, short b)
/*  50:    */   {
/*  51:129 */     return a - b;
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static boolean contains(short[] array, short target)
/*  55:    */   {
/*  56:142 */     for (short value : array) {
/*  57:143 */       if (value == target) {
/*  58:144 */         return true;
/*  59:    */       }
/*  60:    */     }
/*  61:147 */     return false;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static int indexOf(short[] array, short target)
/*  65:    */   {
/*  66:160 */     return indexOf(array, target, 0, array.length);
/*  67:    */   }
/*  68:    */   
/*  69:    */   private static int indexOf(short[] array, short target, int start, int end)
/*  70:    */   {
/*  71:165 */     for (int i = start; i < end; i++) {
/*  72:166 */       if (array[i] == target) {
/*  73:167 */         return i;
/*  74:    */       }
/*  75:    */     }
/*  76:170 */     return -1;
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static int indexOf(short[] array, short[] target)
/*  80:    */   {
/*  81:185 */     Preconditions.checkNotNull(array, "array");
/*  82:186 */     Preconditions.checkNotNull(target, "target");
/*  83:187 */     if (target.length == 0) {
/*  84:188 */       return 0;
/*  85:    */     }
/*  86:    */     label64:
/*  87:192 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  88:    */     {
/*  89:193 */       for (int j = 0; j < target.length; j++) {
/*  90:194 */         if (array[(i + j)] != target[j]) {
/*  91:    */           break label64;
/*  92:    */         }
/*  93:    */       }
/*  94:198 */       return i;
/*  95:    */     }
/*  96:200 */     return -1;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static int lastIndexOf(short[] array, short target)
/* 100:    */   {
/* 101:213 */     return lastIndexOf(array, target, 0, array.length);
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static int lastIndexOf(short[] array, short target, int start, int end)
/* 105:    */   {
/* 106:218 */     for (int i = end - 1; i >= start; i--) {
/* 107:219 */       if (array[i] == target) {
/* 108:220 */         return i;
/* 109:    */       }
/* 110:    */     }
/* 111:223 */     return -1;
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static short min(short... array)
/* 115:    */   {
/* 116:235 */     Preconditions.checkArgument(array.length > 0);
/* 117:236 */     short min = array[0];
/* 118:237 */     for (int i = 1; i < array.length; i++) {
/* 119:238 */       if (array[i] < min) {
/* 120:239 */         min = array[i];
/* 121:    */       }
/* 122:    */     }
/* 123:242 */     return min;
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static short max(short... array)
/* 127:    */   {
/* 128:254 */     Preconditions.checkArgument(array.length > 0);
/* 129:255 */     short max = array[0];
/* 130:256 */     for (int i = 1; i < array.length; i++) {
/* 131:257 */       if (array[i] > max) {
/* 132:258 */         max = array[i];
/* 133:    */       }
/* 134:    */     }
/* 135:261 */     return max;
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static short[] concat(short[]... arrays)
/* 139:    */   {
/* 140:274 */     int length = 0;
/* 141:275 */     for (short[] array : arrays) {
/* 142:276 */       length += array.length;
/* 143:    */     }
/* 144:278 */     short[] result = new short[length];
/* 145:279 */     int pos = 0;
/* 146:280 */     for (short[] array : arrays)
/* 147:    */     {
/* 148:281 */       System.arraycopy(array, 0, result, pos, array.length);
/* 149:282 */       pos += array.length;
/* 150:    */     }
/* 151:284 */     return result;
/* 152:    */   }
/* 153:    */   
/* 154:    */   @GwtIncompatible("doesn't work")
/* 155:    */   public static byte[] toByteArray(short value)
/* 156:    */   {
/* 157:301 */     return new byte[] { (byte)(value >> 8), (byte)value };
/* 158:    */   }
/* 159:    */   
/* 160:    */   @GwtIncompatible("doesn't work")
/* 161:    */   public static short fromByteArray(byte[] bytes)
/* 162:    */   {
/* 163:321 */     Preconditions.checkArgument(bytes.length >= 2, "array too small: %s < %s", new Object[] { Integer.valueOf(bytes.length), Integer.valueOf(2) });
/* 164:322 */     return fromBytes(bytes[0], bytes[1]);
/* 165:    */   }
/* 166:    */   
/* 167:    */   @GwtIncompatible("doesn't work")
/* 168:    */   public static short fromBytes(byte b1, byte b2)
/* 169:    */   {
/* 170:334 */     return (short)(b1 << 8 | b2 & 0xFF);
/* 171:    */   }
/* 172:    */   
/* 173:    */   private static final class ShortConverter
/* 174:    */     extends Converter<String, Short>
/* 175:    */     implements Serializable
/* 176:    */   {
/* 177:339 */     static final ShortConverter INSTANCE = new ShortConverter();
/* 178:    */     private static final long serialVersionUID = 1L;
/* 179:    */     
/* 180:    */     protected Short doForward(String value)
/* 181:    */     {
/* 182:343 */       return Short.decode(value);
/* 183:    */     }
/* 184:    */     
/* 185:    */     protected String doBackward(Short value)
/* 186:    */     {
/* 187:348 */       return value.toString();
/* 188:    */     }
/* 189:    */     
/* 190:    */     public String toString()
/* 191:    */     {
/* 192:353 */       return "Shorts.stringConverter()";
/* 193:    */     }
/* 194:    */     
/* 195:    */     private Object readResolve()
/* 196:    */     {
/* 197:357 */       return INSTANCE;
/* 198:    */     }
/* 199:    */   }
/* 200:    */   
/* 201:    */   @Beta
/* 202:    */   public static Converter<String, Short> stringConverter()
/* 203:    */   {
/* 204:371 */     return ShortConverter.INSTANCE;
/* 205:    */   }
/* 206:    */   
/* 207:    */   public static short[] ensureCapacity(short[] array, int minLength, int padding)
/* 208:    */   {
/* 209:391 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 210:392 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 211:393 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 212:    */   }
/* 213:    */   
/* 214:    */   private static short[] copyOf(short[] original, int length)
/* 215:    */   {
/* 216:400 */     short[] copy = new short[length];
/* 217:401 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 218:402 */     return copy;
/* 219:    */   }
/* 220:    */   
/* 221:    */   public static String join(String separator, short... array)
/* 222:    */   {
/* 223:415 */     Preconditions.checkNotNull(separator);
/* 224:416 */     if (array.length == 0) {
/* 225:417 */       return "";
/* 226:    */     }
/* 227:421 */     StringBuilder builder = new StringBuilder(array.length * 6);
/* 228:422 */     builder.append(array[0]);
/* 229:423 */     for (int i = 1; i < array.length; i++) {
/* 230:424 */       builder.append(separator).append(array[i]);
/* 231:    */     }
/* 232:426 */     return builder.toString();
/* 233:    */   }
/* 234:    */   
/* 235:    */   public static Comparator<short[]> lexicographicalComparator()
/* 236:    */   {
/* 237:446 */     return LexicographicalComparator.INSTANCE;
/* 238:    */   }
/* 239:    */   
/* 240:    */   private static enum LexicographicalComparator
/* 241:    */     implements Comparator<short[]>
/* 242:    */   {
/* 243:450 */     INSTANCE;
/* 244:    */     
/* 245:    */     private LexicographicalComparator() {}
/* 246:    */     
/* 247:    */     public int compare(short[] left, short[] right)
/* 248:    */     {
/* 249:454 */       int minLength = Math.min(left.length, right.length);
/* 250:455 */       for (int i = 0; i < minLength; i++)
/* 251:    */       {
/* 252:456 */         int result = Shorts.compare(left[i], right[i]);
/* 253:457 */         if (result != 0) {
/* 254:458 */           return result;
/* 255:    */         }
/* 256:    */       }
/* 257:461 */       return left.length - right.length;
/* 258:    */     }
/* 259:    */   }
/* 260:    */   
/* 261:    */   public static short[] toArray(Collection<? extends Number> collection)
/* 262:    */   {
/* 263:481 */     if ((collection instanceof ShortArrayAsList)) {
/* 264:482 */       return ((ShortArrayAsList)collection).toShortArray();
/* 265:    */     }
/* 266:485 */     Object[] boxedArray = collection.toArray();
/* 267:486 */     int len = boxedArray.length;
/* 268:487 */     short[] array = new short[len];
/* 269:488 */     for (int i = 0; i < len; i++) {
/* 270:490 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).shortValue();
/* 271:    */     }
/* 272:492 */     return array;
/* 273:    */   }
/* 274:    */   
/* 275:    */   public static List<Short> asList(short... backingArray)
/* 276:    */   {
/* 277:510 */     if (backingArray.length == 0) {
/* 278:511 */       return Collections.emptyList();
/* 279:    */     }
/* 280:513 */     return new ShortArrayAsList(backingArray);
/* 281:    */   }
/* 282:    */   
/* 283:    */   @GwtCompatible
/* 284:    */   private static class ShortArrayAsList
/* 285:    */     extends AbstractList<Short>
/* 286:    */     implements RandomAccess, Serializable
/* 287:    */   {
/* 288:    */     final short[] array;
/* 289:    */     final int start;
/* 290:    */     final int end;
/* 291:    */     private static final long serialVersionUID = 0L;
/* 292:    */     
/* 293:    */     ShortArrayAsList(short[] array)
/* 294:    */     {
/* 295:524 */       this(array, 0, array.length);
/* 296:    */     }
/* 297:    */     
/* 298:    */     ShortArrayAsList(short[] array, int start, int end)
/* 299:    */     {
/* 300:528 */       this.array = array;
/* 301:529 */       this.start = start;
/* 302:530 */       this.end = end;
/* 303:    */     }
/* 304:    */     
/* 305:    */     public int size()
/* 306:    */     {
/* 307:535 */       return this.end - this.start;
/* 308:    */     }
/* 309:    */     
/* 310:    */     public boolean isEmpty()
/* 311:    */     {
/* 312:540 */       return false;
/* 313:    */     }
/* 314:    */     
/* 315:    */     public Short get(int index)
/* 316:    */     {
/* 317:545 */       Preconditions.checkElementIndex(index, size());
/* 318:546 */       return Short.valueOf(this.array[(this.start + index)]);
/* 319:    */     }
/* 320:    */     
/* 321:    */     public boolean contains(Object target)
/* 322:    */     {
/* 323:552 */       return ((target instanceof Short)) && (Shorts.indexOf(this.array, ((Short)target).shortValue(), this.start, this.end) != -1);
/* 324:    */     }
/* 325:    */     
/* 326:    */     public int indexOf(Object target)
/* 327:    */     {
/* 328:558 */       if ((target instanceof Short))
/* 329:    */       {
/* 330:559 */         int i = Shorts.indexOf(this.array, ((Short)target).shortValue(), this.start, this.end);
/* 331:560 */         if (i >= 0) {
/* 332:561 */           return i - this.start;
/* 333:    */         }
/* 334:    */       }
/* 335:564 */       return -1;
/* 336:    */     }
/* 337:    */     
/* 338:    */     public int lastIndexOf(Object target)
/* 339:    */     {
/* 340:570 */       if ((target instanceof Short))
/* 341:    */       {
/* 342:571 */         int i = Shorts.lastIndexOf(this.array, ((Short)target).shortValue(), this.start, this.end);
/* 343:572 */         if (i >= 0) {
/* 344:573 */           return i - this.start;
/* 345:    */         }
/* 346:    */       }
/* 347:576 */       return -1;
/* 348:    */     }
/* 349:    */     
/* 350:    */     public Short set(int index, Short element)
/* 351:    */     {
/* 352:581 */       Preconditions.checkElementIndex(index, size());
/* 353:582 */       short oldValue = this.array[(this.start + index)];
/* 354:    */       
/* 355:584 */       this.array[(this.start + index)] = ((Short)Preconditions.checkNotNull(element)).shortValue();
/* 356:585 */       return Short.valueOf(oldValue);
/* 357:    */     }
/* 358:    */     
/* 359:    */     public List<Short> subList(int fromIndex, int toIndex)
/* 360:    */     {
/* 361:590 */       int size = size();
/* 362:591 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 363:592 */       if (fromIndex == toIndex) {
/* 364:593 */         return Collections.emptyList();
/* 365:    */       }
/* 366:595 */       return new ShortArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 367:    */     }
/* 368:    */     
/* 369:    */     public boolean equals(Object object)
/* 370:    */     {
/* 371:600 */       if (object == this) {
/* 372:601 */         return true;
/* 373:    */       }
/* 374:603 */       if ((object instanceof ShortArrayAsList))
/* 375:    */       {
/* 376:604 */         ShortArrayAsList that = (ShortArrayAsList)object;
/* 377:605 */         int size = size();
/* 378:606 */         if (that.size() != size) {
/* 379:607 */           return false;
/* 380:    */         }
/* 381:609 */         for (int i = 0; i < size; i++) {
/* 382:610 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 383:611 */             return false;
/* 384:    */           }
/* 385:    */         }
/* 386:614 */         return true;
/* 387:    */       }
/* 388:616 */       return super.equals(object);
/* 389:    */     }
/* 390:    */     
/* 391:    */     public int hashCode()
/* 392:    */     {
/* 393:621 */       int result = 1;
/* 394:622 */       for (int i = this.start; i < this.end; i++) {
/* 395:623 */         result = 31 * result + Shorts.hashCode(this.array[i]);
/* 396:    */       }
/* 397:625 */       return result;
/* 398:    */     }
/* 399:    */     
/* 400:    */     public String toString()
/* 401:    */     {
/* 402:630 */       StringBuilder builder = new StringBuilder(size() * 6);
/* 403:631 */       builder.append('[').append(this.array[this.start]);
/* 404:632 */       for (int i = this.start + 1; i < this.end; i++) {
/* 405:633 */         builder.append(", ").append(this.array[i]);
/* 406:    */       }
/* 407:635 */       return ']';
/* 408:    */     }
/* 409:    */     
/* 410:    */     short[] toShortArray()
/* 411:    */     {
/* 412:640 */       int size = size();
/* 413:641 */       short[] result = new short[size];
/* 414:642 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 415:643 */       return result;
/* 416:    */     }
/* 417:    */   }
/* 418:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Shorts
 * JD-Core Version:    0.7.0.1
 */