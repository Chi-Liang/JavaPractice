/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Converter;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.RandomAccess;
/*  15:    */ import java.util.regex.Matcher;
/*  16:    */ import java.util.regex.Pattern;
/*  17:    */ import javax.annotation.CheckForNull;
/*  18:    */ import javax.annotation.CheckReturnValue;
/*  19:    */ import javax.annotation.Nullable;
/*  20:    */ 
/*  21:    */ @CheckReturnValue
/*  22:    */ @GwtCompatible(emulated=true)
/*  23:    */ public final class Floats
/*  24:    */ {
/*  25:    */   public static final int BYTES = 4;
/*  26:    */   
/*  27:    */   public static int hashCode(float value)
/*  28:    */   {
/*  29: 77 */     return Float.valueOf(value).hashCode();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static int compare(float a, float b)
/*  33:    */   {
/*  34: 95 */     return Float.compare(a, b);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static boolean isFinite(float value)
/*  38:    */   {
/*  39:106 */     return ((1.0F / -1.0F) < value ? 1 : 0) & (value < (1.0F / 1.0F) ? 1 : 0);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static boolean contains(float[] array, float target)
/*  43:    */   {
/*  44:120 */     for (float value : array) {
/*  45:121 */       if (value == target) {
/*  46:122 */         return true;
/*  47:    */       }
/*  48:    */     }
/*  49:125 */     return false;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static int indexOf(float[] array, float target)
/*  53:    */   {
/*  54:139 */     return indexOf(array, target, 0, array.length);
/*  55:    */   }
/*  56:    */   
/*  57:    */   private static int indexOf(float[] array, float target, int start, int end)
/*  58:    */   {
/*  59:144 */     for (int i = start; i < end; i++) {
/*  60:145 */       if (array[i] == target) {
/*  61:146 */         return i;
/*  62:    */       }
/*  63:    */     }
/*  64:149 */     return -1;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static int indexOf(float[] array, float[] target)
/*  68:    */   {
/*  69:167 */     Preconditions.checkNotNull(array, "array");
/*  70:168 */     Preconditions.checkNotNull(target, "target");
/*  71:169 */     if (target.length == 0) {
/*  72:170 */       return 0;
/*  73:    */     }
/*  74:    */     label65:
/*  75:174 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  76:    */     {
/*  77:175 */       for (int j = 0; j < target.length; j++) {
/*  78:176 */         if (array[(i + j)] != target[j]) {
/*  79:    */           break label65;
/*  80:    */         }
/*  81:    */       }
/*  82:180 */       return i;
/*  83:    */     }
/*  84:182 */     return -1;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static int lastIndexOf(float[] array, float target)
/*  88:    */   {
/*  89:196 */     return lastIndexOf(array, target, 0, array.length);
/*  90:    */   }
/*  91:    */   
/*  92:    */   private static int lastIndexOf(float[] array, float target, int start, int end)
/*  93:    */   {
/*  94:201 */     for (int i = end - 1; i >= start; i--) {
/*  95:202 */       if (array[i] == target) {
/*  96:203 */         return i;
/*  97:    */       }
/*  98:    */     }
/*  99:206 */     return -1;
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static float min(float... array)
/* 103:    */   {
/* 104:219 */     Preconditions.checkArgument(array.length > 0);
/* 105:220 */     float min = array[0];
/* 106:221 */     for (int i = 1; i < array.length; i++) {
/* 107:222 */       min = Math.min(min, array[i]);
/* 108:    */     }
/* 109:224 */     return min;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static float max(float... array)
/* 113:    */   {
/* 114:237 */     Preconditions.checkArgument(array.length > 0);
/* 115:238 */     float max = array[0];
/* 116:239 */     for (int i = 1; i < array.length; i++) {
/* 117:240 */       max = Math.max(max, array[i]);
/* 118:    */     }
/* 119:242 */     return max;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static float[] concat(float[]... arrays)
/* 123:    */   {
/* 124:255 */     int length = 0;
/* 125:256 */     for (float[] array : arrays) {
/* 126:257 */       length += array.length;
/* 127:    */     }
/* 128:259 */     float[] result = new float[length];
/* 129:260 */     int pos = 0;
/* 130:261 */     for (float[] array : arrays)
/* 131:    */     {
/* 132:262 */       System.arraycopy(array, 0, result, pos, array.length);
/* 133:263 */       pos += array.length;
/* 134:    */     }
/* 135:265 */     return result;
/* 136:    */   }
/* 137:    */   
/* 138:    */   private static final class FloatConverter
/* 139:    */     extends Converter<String, Float>
/* 140:    */     implements Serializable
/* 141:    */   {
/* 142:270 */     static final FloatConverter INSTANCE = new FloatConverter();
/* 143:    */     private static final long serialVersionUID = 1L;
/* 144:    */     
/* 145:    */     protected Float doForward(String value)
/* 146:    */     {
/* 147:274 */       return Float.valueOf(value);
/* 148:    */     }
/* 149:    */     
/* 150:    */     protected String doBackward(Float value)
/* 151:    */     {
/* 152:279 */       return value.toString();
/* 153:    */     }
/* 154:    */     
/* 155:    */     public String toString()
/* 156:    */     {
/* 157:284 */       return "Floats.stringConverter()";
/* 158:    */     }
/* 159:    */     
/* 160:    */     private Object readResolve()
/* 161:    */     {
/* 162:288 */       return INSTANCE;
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   @Beta
/* 167:    */   public static Converter<String, Float> stringConverter()
/* 168:    */   {
/* 169:302 */     return FloatConverter.INSTANCE;
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static float[] ensureCapacity(float[] array, int minLength, int padding)
/* 173:    */   {
/* 174:322 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 175:323 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 176:324 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 177:    */   }
/* 178:    */   
/* 179:    */   private static float[] copyOf(float[] original, int length)
/* 180:    */   {
/* 181:331 */     float[] copy = new float[length];
/* 182:332 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 183:333 */     return copy;
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static String join(String separator, float... array)
/* 187:    */   {
/* 188:351 */     Preconditions.checkNotNull(separator);
/* 189:352 */     if (array.length == 0) {
/* 190:353 */       return "";
/* 191:    */     }
/* 192:357 */     StringBuilder builder = new StringBuilder(array.length * 12);
/* 193:358 */     builder.append(array[0]);
/* 194:359 */     for (int i = 1; i < array.length; i++) {
/* 195:360 */       builder.append(separator).append(array[i]);
/* 196:    */     }
/* 197:362 */     return builder.toString();
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static Comparator<float[]> lexicographicalComparator()
/* 201:    */   {
/* 202:382 */     return LexicographicalComparator.INSTANCE;
/* 203:    */   }
/* 204:    */   
/* 205:    */   private static enum LexicographicalComparator
/* 206:    */     implements Comparator<float[]>
/* 207:    */   {
/* 208:386 */     INSTANCE;
/* 209:    */     
/* 210:    */     private LexicographicalComparator() {}
/* 211:    */     
/* 212:    */     public int compare(float[] left, float[] right)
/* 213:    */     {
/* 214:390 */       int minLength = Math.min(left.length, right.length);
/* 215:391 */       for (int i = 0; i < minLength; i++)
/* 216:    */       {
/* 217:392 */         int result = Float.compare(left[i], right[i]);
/* 218:393 */         if (result != 0) {
/* 219:394 */           return result;
/* 220:    */         }
/* 221:    */       }
/* 222:397 */       return left.length - right.length;
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   public static float[] toArray(Collection<? extends Number> collection)
/* 227:    */   {
/* 228:417 */     if ((collection instanceof FloatArrayAsList)) {
/* 229:418 */       return ((FloatArrayAsList)collection).toFloatArray();
/* 230:    */     }
/* 231:421 */     Object[] boxedArray = collection.toArray();
/* 232:422 */     int len = boxedArray.length;
/* 233:423 */     float[] array = new float[len];
/* 234:424 */     for (int i = 0; i < len; i++) {
/* 235:426 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).floatValue();
/* 236:    */     }
/* 237:428 */     return array;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public static List<Float> asList(float... backingArray)
/* 241:    */   {
/* 242:449 */     if (backingArray.length == 0) {
/* 243:450 */       return Collections.emptyList();
/* 244:    */     }
/* 245:452 */     return new FloatArrayAsList(backingArray);
/* 246:    */   }
/* 247:    */   
/* 248:    */   @GwtCompatible
/* 249:    */   private static class FloatArrayAsList
/* 250:    */     extends AbstractList<Float>
/* 251:    */     implements RandomAccess, Serializable
/* 252:    */   {
/* 253:    */     final float[] array;
/* 254:    */     final int start;
/* 255:    */     final int end;
/* 256:    */     private static final long serialVersionUID = 0L;
/* 257:    */     
/* 258:    */     FloatArrayAsList(float[] array)
/* 259:    */     {
/* 260:463 */       this(array, 0, array.length);
/* 261:    */     }
/* 262:    */     
/* 263:    */     FloatArrayAsList(float[] array, int start, int end)
/* 264:    */     {
/* 265:467 */       this.array = array;
/* 266:468 */       this.start = start;
/* 267:469 */       this.end = end;
/* 268:    */     }
/* 269:    */     
/* 270:    */     public int size()
/* 271:    */     {
/* 272:474 */       return this.end - this.start;
/* 273:    */     }
/* 274:    */     
/* 275:    */     public boolean isEmpty()
/* 276:    */     {
/* 277:479 */       return false;
/* 278:    */     }
/* 279:    */     
/* 280:    */     public Float get(int index)
/* 281:    */     {
/* 282:484 */       Preconditions.checkElementIndex(index, size());
/* 283:485 */       return Float.valueOf(this.array[(this.start + index)]);
/* 284:    */     }
/* 285:    */     
/* 286:    */     public boolean contains(Object target)
/* 287:    */     {
/* 288:491 */       return ((target instanceof Float)) && (Floats.indexOf(this.array, ((Float)target).floatValue(), this.start, this.end) != -1);
/* 289:    */     }
/* 290:    */     
/* 291:    */     public int indexOf(Object target)
/* 292:    */     {
/* 293:497 */       if ((target instanceof Float))
/* 294:    */       {
/* 295:498 */         int i = Floats.indexOf(this.array, ((Float)target).floatValue(), this.start, this.end);
/* 296:499 */         if (i >= 0) {
/* 297:500 */           return i - this.start;
/* 298:    */         }
/* 299:    */       }
/* 300:503 */       return -1;
/* 301:    */     }
/* 302:    */     
/* 303:    */     public int lastIndexOf(Object target)
/* 304:    */     {
/* 305:509 */       if ((target instanceof Float))
/* 306:    */       {
/* 307:510 */         int i = Floats.lastIndexOf(this.array, ((Float)target).floatValue(), this.start, this.end);
/* 308:511 */         if (i >= 0) {
/* 309:512 */           return i - this.start;
/* 310:    */         }
/* 311:    */       }
/* 312:515 */       return -1;
/* 313:    */     }
/* 314:    */     
/* 315:    */     public Float set(int index, Float element)
/* 316:    */     {
/* 317:520 */       Preconditions.checkElementIndex(index, size());
/* 318:521 */       float oldValue = this.array[(this.start + index)];
/* 319:    */       
/* 320:523 */       this.array[(this.start + index)] = ((Float)Preconditions.checkNotNull(element)).floatValue();
/* 321:524 */       return Float.valueOf(oldValue);
/* 322:    */     }
/* 323:    */     
/* 324:    */     public List<Float> subList(int fromIndex, int toIndex)
/* 325:    */     {
/* 326:529 */       int size = size();
/* 327:530 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 328:531 */       if (fromIndex == toIndex) {
/* 329:532 */         return Collections.emptyList();
/* 330:    */       }
/* 331:534 */       return new FloatArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 332:    */     }
/* 333:    */     
/* 334:    */     public boolean equals(@Nullable Object object)
/* 335:    */     {
/* 336:539 */       if (object == this) {
/* 337:540 */         return true;
/* 338:    */       }
/* 339:542 */       if ((object instanceof FloatArrayAsList))
/* 340:    */       {
/* 341:543 */         FloatArrayAsList that = (FloatArrayAsList)object;
/* 342:544 */         int size = size();
/* 343:545 */         if (that.size() != size) {
/* 344:546 */           return false;
/* 345:    */         }
/* 346:548 */         for (int i = 0; i < size; i++) {
/* 347:549 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 348:550 */             return false;
/* 349:    */           }
/* 350:    */         }
/* 351:553 */         return true;
/* 352:    */       }
/* 353:555 */       return super.equals(object);
/* 354:    */     }
/* 355:    */     
/* 356:    */     public int hashCode()
/* 357:    */     {
/* 358:560 */       int result = 1;
/* 359:561 */       for (int i = this.start; i < this.end; i++) {
/* 360:562 */         result = 31 * result + Floats.hashCode(this.array[i]);
/* 361:    */       }
/* 362:564 */       return result;
/* 363:    */     }
/* 364:    */     
/* 365:    */     public String toString()
/* 366:    */     {
/* 367:569 */       StringBuilder builder = new StringBuilder(size() * 12);
/* 368:570 */       builder.append('[').append(this.array[this.start]);
/* 369:571 */       for (int i = this.start + 1; i < this.end; i++) {
/* 370:572 */         builder.append(", ").append(this.array[i]);
/* 371:    */       }
/* 372:574 */       return ']';
/* 373:    */     }
/* 374:    */     
/* 375:    */     float[] toFloatArray()
/* 376:    */     {
/* 377:579 */       int size = size();
/* 378:580 */       float[] result = new float[size];
/* 379:581 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 380:582 */       return result;
/* 381:    */     }
/* 382:    */   }
/* 383:    */   
/* 384:    */   @Nullable
/* 385:    */   @CheckForNull
/* 386:    */   @Beta
/* 387:    */   @GwtIncompatible("regular expressions")
/* 388:    */   public static Float tryParse(String string)
/* 389:    */   {
/* 390:612 */     if (Doubles.FLOATING_POINT_PATTERN.matcher(string).matches()) {
/* 391:    */       try
/* 392:    */       {
/* 393:616 */         return Float.valueOf(Float.parseFloat(string));
/* 394:    */       }
/* 395:    */       catch (NumberFormatException e) {}
/* 396:    */     }
/* 397:622 */     return null;
/* 398:    */   }
/* 399:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Floats
 * JD-Core Version:    0.7.0.1
 */