/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Converter;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.RandomAccess;
/*  15:    */ import javax.annotation.CheckForNull;
/*  16:    */ import javax.annotation.CheckReturnValue;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @CheckReturnValue
/*  20:    */ @GwtCompatible(emulated=true)
/*  21:    */ public final class Ints
/*  22:    */ {
/*  23:    */   public static final int BYTES = 4;
/*  24:    */   public static final int MAX_POWER_OF_TWO = 1073741824;
/*  25:    */   
/*  26:    */   public static int hashCode(int value)
/*  27:    */   {
/*  28: 79 */     return value;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static int checkedCast(long value)
/*  32:    */   {
/*  33: 91 */     int result = (int)value;
/*  34: 92 */     if (result != value) {
/*  35: 94 */       throw new IllegalArgumentException("Out of range: " + value);
/*  36:    */     }
/*  37: 96 */     return result;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static int saturatedCast(long value)
/*  41:    */   {
/*  42:108 */     if (value > 2147483647L) {
/*  43:109 */       return 2147483647;
/*  44:    */     }
/*  45:111 */     if (value < -2147483648L) {
/*  46:112 */       return -2147483648;
/*  47:    */     }
/*  48:114 */     return (int)value;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static int compare(int a, int b)
/*  52:    */   {
/*  53:130 */     return a > b ? 1 : a < b ? -1 : 0;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static boolean contains(int[] array, int target)
/*  57:    */   {
/*  58:143 */     for (int value : array) {
/*  59:144 */       if (value == target) {
/*  60:145 */         return true;
/*  61:    */       }
/*  62:    */     }
/*  63:148 */     return false;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static int indexOf(int[] array, int target)
/*  67:    */   {
/*  68:161 */     return indexOf(array, target, 0, array.length);
/*  69:    */   }
/*  70:    */   
/*  71:    */   private static int indexOf(int[] array, int target, int start, int end)
/*  72:    */   {
/*  73:166 */     for (int i = start; i < end; i++) {
/*  74:167 */       if (array[i] == target) {
/*  75:168 */         return i;
/*  76:    */       }
/*  77:    */     }
/*  78:171 */     return -1;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public static int indexOf(int[] array, int[] target)
/*  82:    */   {
/*  83:186 */     Preconditions.checkNotNull(array, "array");
/*  84:187 */     Preconditions.checkNotNull(target, "target");
/*  85:188 */     if (target.length == 0) {
/*  86:189 */       return 0;
/*  87:    */     }
/*  88:    */     label64:
/*  89:193 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  90:    */     {
/*  91:194 */       for (int j = 0; j < target.length; j++) {
/*  92:195 */         if (array[(i + j)] != target[j]) {
/*  93:    */           break label64;
/*  94:    */         }
/*  95:    */       }
/*  96:199 */       return i;
/*  97:    */     }
/*  98:201 */     return -1;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public static int lastIndexOf(int[] array, int target)
/* 102:    */   {
/* 103:214 */     return lastIndexOf(array, target, 0, array.length);
/* 104:    */   }
/* 105:    */   
/* 106:    */   private static int lastIndexOf(int[] array, int target, int start, int end)
/* 107:    */   {
/* 108:219 */     for (int i = end - 1; i >= start; i--) {
/* 109:220 */       if (array[i] == target) {
/* 110:221 */         return i;
/* 111:    */       }
/* 112:    */     }
/* 113:224 */     return -1;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public static int min(int... array)
/* 117:    */   {
/* 118:236 */     Preconditions.checkArgument(array.length > 0);
/* 119:237 */     int min = array[0];
/* 120:238 */     for (int i = 1; i < array.length; i++) {
/* 121:239 */       if (array[i] < min) {
/* 122:240 */         min = array[i];
/* 123:    */       }
/* 124:    */     }
/* 125:243 */     return min;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static int max(int... array)
/* 129:    */   {
/* 130:255 */     Preconditions.checkArgument(array.length > 0);
/* 131:256 */     int max = array[0];
/* 132:257 */     for (int i = 1; i < array.length; i++) {
/* 133:258 */       if (array[i] > max) {
/* 134:259 */         max = array[i];
/* 135:    */       }
/* 136:    */     }
/* 137:262 */     return max;
/* 138:    */   }
/* 139:    */   
/* 140:    */   public static int[] concat(int[]... arrays)
/* 141:    */   {
/* 142:275 */     int length = 0;
/* 143:276 */     for (int[] array : arrays) {
/* 144:277 */       length += array.length;
/* 145:    */     }
/* 146:279 */     int[] result = new int[length];
/* 147:280 */     int pos = 0;
/* 148:281 */     for (int[] array : arrays)
/* 149:    */     {
/* 150:282 */       System.arraycopy(array, 0, result, pos, array.length);
/* 151:283 */       pos += array.length;
/* 152:    */     }
/* 153:285 */     return result;
/* 154:    */   }
/* 155:    */   
/* 156:    */   @GwtIncompatible("doesn't work")
/* 157:    */   public static byte[] toByteArray(int value)
/* 158:    */   {
/* 159:301 */     return new byte[] { (byte)(value >> 24), (byte)(value >> 16), (byte)(value >> 8), (byte)value };
/* 160:    */   }
/* 161:    */   
/* 162:    */   @GwtIncompatible("doesn't work")
/* 163:    */   public static int fromByteArray(byte[] bytes)
/* 164:    */   {
/* 165:323 */     Preconditions.checkArgument(bytes.length >= 4, "array too small: %s < %s", new Object[] { Integer.valueOf(bytes.length), Integer.valueOf(4) });
/* 166:324 */     return fromBytes(bytes[0], bytes[1], bytes[2], bytes[3]);
/* 167:    */   }
/* 168:    */   
/* 169:    */   @GwtIncompatible("doesn't work")
/* 170:    */   public static int fromBytes(byte b1, byte b2, byte b3, byte b4)
/* 171:    */   {
/* 172:336 */     return b1 << 24 | (b2 & 0xFF) << 16 | (b3 & 0xFF) << 8 | b4 & 0xFF;
/* 173:    */   }
/* 174:    */   
/* 175:    */   private static final class IntConverter
/* 176:    */     extends Converter<String, Integer>
/* 177:    */     implements Serializable
/* 178:    */   {
/* 179:341 */     static final IntConverter INSTANCE = new IntConverter();
/* 180:    */     private static final long serialVersionUID = 1L;
/* 181:    */     
/* 182:    */     protected Integer doForward(String value)
/* 183:    */     {
/* 184:345 */       return Integer.decode(value);
/* 185:    */     }
/* 186:    */     
/* 187:    */     protected String doBackward(Integer value)
/* 188:    */     {
/* 189:350 */       return value.toString();
/* 190:    */     }
/* 191:    */     
/* 192:    */     public String toString()
/* 193:    */     {
/* 194:355 */       return "Ints.stringConverter()";
/* 195:    */     }
/* 196:    */     
/* 197:    */     private Object readResolve()
/* 198:    */     {
/* 199:359 */       return INSTANCE;
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:    */   @Beta
/* 204:    */   public static Converter<String, Integer> stringConverter()
/* 205:    */   {
/* 206:373 */     return IntConverter.INSTANCE;
/* 207:    */   }
/* 208:    */   
/* 209:    */   public static int[] ensureCapacity(int[] array, int minLength, int padding)
/* 210:    */   {
/* 211:393 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 212:394 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 213:395 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 214:    */   }
/* 215:    */   
/* 216:    */   private static int[] copyOf(int[] original, int length)
/* 217:    */   {
/* 218:402 */     int[] copy = new int[length];
/* 219:403 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 220:404 */     return copy;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public static String join(String separator, int... array)
/* 224:    */   {
/* 225:417 */     Preconditions.checkNotNull(separator);
/* 226:418 */     if (array.length == 0) {
/* 227:419 */       return "";
/* 228:    */     }
/* 229:423 */     StringBuilder builder = new StringBuilder(array.length * 5);
/* 230:424 */     builder.append(array[0]);
/* 231:425 */     for (int i = 1; i < array.length; i++) {
/* 232:426 */       builder.append(separator).append(array[i]);
/* 233:    */     }
/* 234:428 */     return builder.toString();
/* 235:    */   }
/* 236:    */   
/* 237:    */   public static Comparator<int[]> lexicographicalComparator()
/* 238:    */   {
/* 239:447 */     return LexicographicalComparator.INSTANCE;
/* 240:    */   }
/* 241:    */   
/* 242:    */   private static enum LexicographicalComparator
/* 243:    */     implements Comparator<int[]>
/* 244:    */   {
/* 245:451 */     INSTANCE;
/* 246:    */     
/* 247:    */     private LexicographicalComparator() {}
/* 248:    */     
/* 249:    */     public int compare(int[] left, int[] right)
/* 250:    */     {
/* 251:455 */       int minLength = Math.min(left.length, right.length);
/* 252:456 */       for (int i = 0; i < minLength; i++)
/* 253:    */       {
/* 254:457 */         int result = Ints.compare(left[i], right[i]);
/* 255:458 */         if (result != 0) {
/* 256:459 */           return result;
/* 257:    */         }
/* 258:    */       }
/* 259:462 */       return left.length - right.length;
/* 260:    */     }
/* 261:    */   }
/* 262:    */   
/* 263:    */   public static int[] toArray(Collection<? extends Number> collection)
/* 264:    */   {
/* 265:482 */     if ((collection instanceof IntArrayAsList)) {
/* 266:483 */       return ((IntArrayAsList)collection).toIntArray();
/* 267:    */     }
/* 268:486 */     Object[] boxedArray = collection.toArray();
/* 269:487 */     int len = boxedArray.length;
/* 270:488 */     int[] array = new int[len];
/* 271:489 */     for (int i = 0; i < len; i++) {
/* 272:491 */       array[i] = ((Number)Preconditions.checkNotNull(boxedArray[i])).intValue();
/* 273:    */     }
/* 274:493 */     return array;
/* 275:    */   }
/* 276:    */   
/* 277:    */   public static List<Integer> asList(int... backingArray)
/* 278:    */   {
/* 279:511 */     if (backingArray.length == 0) {
/* 280:512 */       return Collections.emptyList();
/* 281:    */     }
/* 282:514 */     return new IntArrayAsList(backingArray);
/* 283:    */   }
/* 284:    */   
/* 285:    */   @GwtCompatible
/* 286:    */   private static class IntArrayAsList
/* 287:    */     extends AbstractList<Integer>
/* 288:    */     implements RandomAccess, Serializable
/* 289:    */   {
/* 290:    */     final int[] array;
/* 291:    */     final int start;
/* 292:    */     final int end;
/* 293:    */     private static final long serialVersionUID = 0L;
/* 294:    */     
/* 295:    */     IntArrayAsList(int[] array)
/* 296:    */     {
/* 297:525 */       this(array, 0, array.length);
/* 298:    */     }
/* 299:    */     
/* 300:    */     IntArrayAsList(int[] array, int start, int end)
/* 301:    */     {
/* 302:529 */       this.array = array;
/* 303:530 */       this.start = start;
/* 304:531 */       this.end = end;
/* 305:    */     }
/* 306:    */     
/* 307:    */     public int size()
/* 308:    */     {
/* 309:536 */       return this.end - this.start;
/* 310:    */     }
/* 311:    */     
/* 312:    */     public boolean isEmpty()
/* 313:    */     {
/* 314:541 */       return false;
/* 315:    */     }
/* 316:    */     
/* 317:    */     public Integer get(int index)
/* 318:    */     {
/* 319:546 */       Preconditions.checkElementIndex(index, size());
/* 320:547 */       return Integer.valueOf(this.array[(this.start + index)]);
/* 321:    */     }
/* 322:    */     
/* 323:    */     public boolean contains(Object target)
/* 324:    */     {
/* 325:553 */       return ((target instanceof Integer)) && (Ints.indexOf(this.array, ((Integer)target).intValue(), this.start, this.end) != -1);
/* 326:    */     }
/* 327:    */     
/* 328:    */     public int indexOf(Object target)
/* 329:    */     {
/* 330:559 */       if ((target instanceof Integer))
/* 331:    */       {
/* 332:560 */         int i = Ints.indexOf(this.array, ((Integer)target).intValue(), this.start, this.end);
/* 333:561 */         if (i >= 0) {
/* 334:562 */           return i - this.start;
/* 335:    */         }
/* 336:    */       }
/* 337:565 */       return -1;
/* 338:    */     }
/* 339:    */     
/* 340:    */     public int lastIndexOf(Object target)
/* 341:    */     {
/* 342:571 */       if ((target instanceof Integer))
/* 343:    */       {
/* 344:572 */         int i = Ints.lastIndexOf(this.array, ((Integer)target).intValue(), this.start, this.end);
/* 345:573 */         if (i >= 0) {
/* 346:574 */           return i - this.start;
/* 347:    */         }
/* 348:    */       }
/* 349:577 */       return -1;
/* 350:    */     }
/* 351:    */     
/* 352:    */     public Integer set(int index, Integer element)
/* 353:    */     {
/* 354:582 */       Preconditions.checkElementIndex(index, size());
/* 355:583 */       int oldValue = this.array[(this.start + index)];
/* 356:    */       
/* 357:585 */       this.array[(this.start + index)] = ((Integer)Preconditions.checkNotNull(element)).intValue();
/* 358:586 */       return Integer.valueOf(oldValue);
/* 359:    */     }
/* 360:    */     
/* 361:    */     public List<Integer> subList(int fromIndex, int toIndex)
/* 362:    */     {
/* 363:591 */       int size = size();
/* 364:592 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 365:593 */       if (fromIndex == toIndex) {
/* 366:594 */         return Collections.emptyList();
/* 367:    */       }
/* 368:596 */       return new IntArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 369:    */     }
/* 370:    */     
/* 371:    */     public boolean equals(@Nullable Object object)
/* 372:    */     {
/* 373:601 */       if (object == this) {
/* 374:602 */         return true;
/* 375:    */       }
/* 376:604 */       if ((object instanceof IntArrayAsList))
/* 377:    */       {
/* 378:605 */         IntArrayAsList that = (IntArrayAsList)object;
/* 379:606 */         int size = size();
/* 380:607 */         if (that.size() != size) {
/* 381:608 */           return false;
/* 382:    */         }
/* 383:610 */         for (int i = 0; i < size; i++) {
/* 384:611 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 385:612 */             return false;
/* 386:    */           }
/* 387:    */         }
/* 388:615 */         return true;
/* 389:    */       }
/* 390:617 */       return super.equals(object);
/* 391:    */     }
/* 392:    */     
/* 393:    */     public int hashCode()
/* 394:    */     {
/* 395:622 */       int result = 1;
/* 396:623 */       for (int i = this.start; i < this.end; i++) {
/* 397:624 */         result = 31 * result + Ints.hashCode(this.array[i]);
/* 398:    */       }
/* 399:626 */       return result;
/* 400:    */     }
/* 401:    */     
/* 402:    */     public String toString()
/* 403:    */     {
/* 404:631 */       StringBuilder builder = new StringBuilder(size() * 5);
/* 405:632 */       builder.append('[').append(this.array[this.start]);
/* 406:633 */       for (int i = this.start + 1; i < this.end; i++) {
/* 407:634 */         builder.append(", ").append(this.array[i]);
/* 408:    */       }
/* 409:636 */       return ']';
/* 410:    */     }
/* 411:    */     
/* 412:    */     int[] toIntArray()
/* 413:    */     {
/* 414:641 */       int size = size();
/* 415:642 */       int[] result = new int[size];
/* 416:643 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 417:644 */       return result;
/* 418:    */     }
/* 419:    */   }
/* 420:    */   
/* 421:    */   @Nullable
/* 422:    */   @CheckForNull
/* 423:    */   @Beta
/* 424:    */   public static Integer tryParse(String string)
/* 425:    */   {
/* 426:674 */     return tryParse(string, 10);
/* 427:    */   }
/* 428:    */   
/* 429:    */   @Nullable
/* 430:    */   @CheckForNull
/* 431:    */   @Beta
/* 432:    */   public static Integer tryParse(String string, int radix)
/* 433:    */   {
/* 434:705 */     Long result = Longs.tryParse(string, radix);
/* 435:706 */     if ((result == null) || (result.longValue() != result.intValue())) {
/* 436:707 */       return null;
/* 437:    */     }
/* 438:709 */     return Integer.valueOf(result.intValue());
/* 439:    */   }
/* 440:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Ints
 * JD-Core Version:    0.7.0.1
 */