/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import javax.annotation.CheckReturnValue;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ @GwtCompatible
/*  11:    */ public final class UnsignedInts
/*  12:    */ {
/*  13:    */   static final long INT_MASK = 4294967295L;
/*  14:    */   
/*  15:    */   static int flip(int value)
/*  16:    */   {
/*  17: 57 */     return value ^ 0x80000000;
/*  18:    */   }
/*  19:    */   
/*  20:    */   @CheckReturnValue
/*  21:    */   public static int compare(int a, int b)
/*  22:    */   {
/*  23: 71 */     return Ints.compare(flip(a), flip(b));
/*  24:    */   }
/*  25:    */   
/*  26:    */   @CheckReturnValue
/*  27:    */   public static long toLong(int value)
/*  28:    */   {
/*  29: 79 */     return value & 0xFFFFFFFF;
/*  30:    */   }
/*  31:    */   
/*  32:    */   @CheckReturnValue
/*  33:    */   public static int min(int... array)
/*  34:    */   {
/*  35: 92 */     Preconditions.checkArgument(array.length > 0);
/*  36: 93 */     int min = flip(array[0]);
/*  37: 94 */     for (int i = 1; i < array.length; i++)
/*  38:    */     {
/*  39: 95 */       int next = flip(array[i]);
/*  40: 96 */       if (next < min) {
/*  41: 97 */         min = next;
/*  42:    */       }
/*  43:    */     }
/*  44:100 */     return flip(min);
/*  45:    */   }
/*  46:    */   
/*  47:    */   @CheckReturnValue
/*  48:    */   public static int max(int... array)
/*  49:    */   {
/*  50:113 */     Preconditions.checkArgument(array.length > 0);
/*  51:114 */     int max = flip(array[0]);
/*  52:115 */     for (int i = 1; i < array.length; i++)
/*  53:    */     {
/*  54:116 */       int next = flip(array[i]);
/*  55:117 */       if (next > max) {
/*  56:118 */         max = next;
/*  57:    */       }
/*  58:    */     }
/*  59:121 */     return flip(max);
/*  60:    */   }
/*  61:    */   
/*  62:    */   @CheckReturnValue
/*  63:    */   public static String join(String separator, int... array)
/*  64:    */   {
/*  65:134 */     Preconditions.checkNotNull(separator);
/*  66:135 */     if (array.length == 0) {
/*  67:136 */       return "";
/*  68:    */     }
/*  69:140 */     StringBuilder builder = new StringBuilder(array.length * 5);
/*  70:141 */     builder.append(toString(array[0]));
/*  71:142 */     for (int i = 1; i < array.length; i++) {
/*  72:143 */       builder.append(separator).append(toString(array[i]));
/*  73:    */     }
/*  74:145 */     return builder.toString();
/*  75:    */   }
/*  76:    */   
/*  77:    */   @CheckReturnValue
/*  78:    */   public static Comparator<int[]> lexicographicalComparator()
/*  79:    */   {
/*  80:162 */     return LexicographicalComparator.INSTANCE;
/*  81:    */   }
/*  82:    */   
/*  83:    */   static enum LexicographicalComparator
/*  84:    */     implements Comparator<int[]>
/*  85:    */   {
/*  86:166 */     INSTANCE;
/*  87:    */     
/*  88:    */     private LexicographicalComparator() {}
/*  89:    */     
/*  90:    */     public int compare(int[] left, int[] right)
/*  91:    */     {
/*  92:170 */       int minLength = Math.min(left.length, right.length);
/*  93:171 */       for (int i = 0; i < minLength; i++) {
/*  94:172 */         if (left[i] != right[i]) {
/*  95:173 */           return UnsignedInts.compare(left[i], right[i]);
/*  96:    */         }
/*  97:    */       }
/*  98:176 */       return left.length - right.length;
/*  99:    */     }
/* 100:    */   }
/* 101:    */   
/* 102:    */   @CheckReturnValue
/* 103:    */   public static int divide(int dividend, int divisor)
/* 104:    */   {
/* 105:190 */     return (int)(toLong(dividend) / toLong(divisor));
/* 106:    */   }
/* 107:    */   
/* 108:    */   @CheckReturnValue
/* 109:    */   public static int remainder(int dividend, int divisor)
/* 110:    */   {
/* 111:203 */     return (int)(toLong(dividend) % toLong(divisor));
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static int decode(String stringValue)
/* 115:    */   {
/* 116:222 */     ParseRequest request = ParseRequest.fromString(stringValue);
/* 117:    */     try
/* 118:    */     {
/* 119:225 */       return parseUnsignedInt(request.rawValue, request.radix);
/* 120:    */     }
/* 121:    */     catch (NumberFormatException e)
/* 122:    */     {
/* 123:227 */       NumberFormatException decodeException = new NumberFormatException("Error parsing value: " + stringValue);
/* 124:    */       
/* 125:229 */       decodeException.initCause(e);
/* 126:230 */       throw decodeException;
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static int parseUnsignedInt(String s)
/* 131:    */   {
/* 132:242 */     return parseUnsignedInt(s, 10);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static int parseUnsignedInt(String string, int radix)
/* 136:    */   {
/* 137:257 */     Preconditions.checkNotNull(string);
/* 138:258 */     long result = Long.parseLong(string, radix);
/* 139:259 */     if ((result & 0xFFFFFFFF) != result) {
/* 140:260 */       throw new NumberFormatException("Input " + string + " in base " + radix + " is not in the range of an unsigned integer");
/* 141:    */     }
/* 142:263 */     return (int)result;
/* 143:    */   }
/* 144:    */   
/* 145:    */   @CheckReturnValue
/* 146:    */   public static String toString(int x)
/* 147:    */   {
/* 148:271 */     return toString(x, 10);
/* 149:    */   }
/* 150:    */   
/* 151:    */   @CheckReturnValue
/* 152:    */   public static String toString(int x, int radix)
/* 153:    */   {
/* 154:285 */     long asLong = x & 0xFFFFFFFF;
/* 155:286 */     return Long.toString(asLong, radix);
/* 156:    */   }
/* 157:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.UnsignedInts
 * JD-Core Version:    0.7.0.1
 */