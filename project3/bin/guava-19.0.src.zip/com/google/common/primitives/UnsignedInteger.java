/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.math.BigInteger;
/*   7:    */ import javax.annotation.CheckReturnValue;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @CheckReturnValue
/*  11:    */ @GwtCompatible(emulated=true)
/*  12:    */ public final class UnsignedInteger
/*  13:    */   extends Number
/*  14:    */   implements Comparable<UnsignedInteger>
/*  15:    */ {
/*  16: 47 */   public static final UnsignedInteger ZERO = fromIntBits(0);
/*  17: 48 */   public static final UnsignedInteger ONE = fromIntBits(1);
/*  18: 49 */   public static final UnsignedInteger MAX_VALUE = fromIntBits(-1);
/*  19:    */   private final int value;
/*  20:    */   
/*  21:    */   private UnsignedInteger(int value)
/*  22:    */   {
/*  23: 55 */     this.value = (value & 0xFFFFFFFF);
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static UnsignedInteger fromIntBits(int bits)
/*  27:    */   {
/*  28: 71 */     return new UnsignedInteger(bits);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static UnsignedInteger valueOf(long value)
/*  32:    */   {
/*  33: 79 */     Preconditions.checkArgument((value & 0xFFFFFFFF) == value, "value (%s) is outside the range for an unsigned integer value", new Object[] { Long.valueOf(value) });
/*  34:    */     
/*  35:    */ 
/*  36:    */ 
/*  37: 83 */     return fromIntBits((int)value);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static UnsignedInteger valueOf(BigInteger value)
/*  41:    */   {
/*  42: 93 */     Preconditions.checkNotNull(value);
/*  43: 94 */     Preconditions.checkArgument((value.signum() >= 0) && (value.bitLength() <= 32), "value (%s) is outside the range for an unsigned integer value", new Object[] { value });
/*  44:    */     
/*  45:    */ 
/*  46:    */ 
/*  47: 98 */     return fromIntBits(value.intValue());
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static UnsignedInteger valueOf(String string)
/*  51:    */   {
/*  52:109 */     return valueOf(string, 10);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static UnsignedInteger valueOf(String string, int radix)
/*  56:    */   {
/*  57:120 */     return fromIntBits(UnsignedInts.parseUnsignedInt(string, radix));
/*  58:    */   }
/*  59:    */   
/*  60:    */   public UnsignedInteger plus(UnsignedInteger val)
/*  61:    */   {
/*  62:130 */     return fromIntBits(this.value + ((UnsignedInteger)Preconditions.checkNotNull(val)).value);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public UnsignedInteger minus(UnsignedInteger val)
/*  66:    */   {
/*  67:140 */     return fromIntBits(this.value - ((UnsignedInteger)Preconditions.checkNotNull(val)).value);
/*  68:    */   }
/*  69:    */   
/*  70:    */   @GwtIncompatible("Does not truncate correctly")
/*  71:    */   public UnsignedInteger times(UnsignedInteger val)
/*  72:    */   {
/*  73:152 */     return fromIntBits(this.value * ((UnsignedInteger)Preconditions.checkNotNull(val)).value);
/*  74:    */   }
/*  75:    */   
/*  76:    */   public UnsignedInteger dividedBy(UnsignedInteger val)
/*  77:    */   {
/*  78:162 */     return fromIntBits(UnsignedInts.divide(this.value, ((UnsignedInteger)Preconditions.checkNotNull(val)).value));
/*  79:    */   }
/*  80:    */   
/*  81:    */   public UnsignedInteger mod(UnsignedInteger val)
/*  82:    */   {
/*  83:172 */     return fromIntBits(UnsignedInts.remainder(this.value, ((UnsignedInteger)Preconditions.checkNotNull(val)).value));
/*  84:    */   }
/*  85:    */   
/*  86:    */   public int intValue()
/*  87:    */   {
/*  88:184 */     return this.value;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public long longValue()
/*  92:    */   {
/*  93:192 */     return UnsignedInts.toLong(this.value);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public float floatValue()
/*  97:    */   {
/*  98:201 */     return (float)longValue();
/*  99:    */   }
/* 100:    */   
/* 101:    */   public double doubleValue()
/* 102:    */   {
/* 103:210 */     return longValue();
/* 104:    */   }
/* 105:    */   
/* 106:    */   public BigInteger bigIntegerValue()
/* 107:    */   {
/* 108:217 */     return BigInteger.valueOf(longValue());
/* 109:    */   }
/* 110:    */   
/* 111:    */   public int compareTo(UnsignedInteger other)
/* 112:    */   {
/* 113:227 */     Preconditions.checkNotNull(other);
/* 114:228 */     return UnsignedInts.compare(this.value, other.value);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public int hashCode()
/* 118:    */   {
/* 119:233 */     return this.value;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean equals(@Nullable Object obj)
/* 123:    */   {
/* 124:238 */     if ((obj instanceof UnsignedInteger))
/* 125:    */     {
/* 126:239 */       UnsignedInteger other = (UnsignedInteger)obj;
/* 127:240 */       return this.value == other.value;
/* 128:    */     }
/* 129:242 */     return false;
/* 130:    */   }
/* 131:    */   
/* 132:    */   public String toString()
/* 133:    */   {
/* 134:250 */     return toString(10);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public String toString(int radix)
/* 138:    */   {
/* 139:259 */     return UnsignedInts.toString(this.value, radix);
/* 140:    */   }
/* 141:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.UnsignedInteger
 * JD-Core Version:    0.7.0.1
 */