/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.math.BigInteger;
/*   7:    */ import javax.annotation.CheckReturnValue;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true)
/*  11:    */ public final class UnsignedLong
/*  12:    */   extends Number
/*  13:    */   implements Comparable<UnsignedLong>, Serializable
/*  14:    */ {
/*  15:    */   private static final long UNSIGNED_MASK = 9223372036854775807L;
/*  16: 47 */   public static final UnsignedLong ZERO = new UnsignedLong(0L);
/*  17: 48 */   public static final UnsignedLong ONE = new UnsignedLong(1L);
/*  18: 49 */   public static final UnsignedLong MAX_VALUE = new UnsignedLong(-1L);
/*  19:    */   private final long value;
/*  20:    */   
/*  21:    */   private UnsignedLong(long value)
/*  22:    */   {
/*  23: 54 */     this.value = value;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static UnsignedLong fromLongBits(long bits)
/*  27:    */   {
/*  28: 72 */     return new UnsignedLong(bits);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static UnsignedLong valueOf(long value)
/*  32:    */   {
/*  33: 82 */     Preconditions.checkArgument(value >= 0L, "value (%s) is outside the range for an unsigned long value", new Object[] { Long.valueOf(value) });
/*  34: 83 */     return fromLongBits(value);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static UnsignedLong valueOf(BigInteger value)
/*  38:    */   {
/*  39: 93 */     Preconditions.checkNotNull(value);
/*  40: 94 */     Preconditions.checkArgument((value.signum() >= 0) && (value.bitLength() <= 64), "value (%s) is outside the range for an unsigned long value", new Object[] { value });
/*  41:    */     
/*  42:    */ 
/*  43:    */ 
/*  44: 98 */     return fromLongBits(value.longValue());
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static UnsignedLong valueOf(String string)
/*  48:    */   {
/*  49:109 */     return valueOf(string, 10);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static UnsignedLong valueOf(String string, int radix)
/*  53:    */   {
/*  54:121 */     return fromLongBits(UnsignedLongs.parseUnsignedLong(string, radix));
/*  55:    */   }
/*  56:    */   
/*  57:    */   @CheckReturnValue
/*  58:    */   public UnsignedLong plus(UnsignedLong val)
/*  59:    */   {
/*  60:132 */     return fromLongBits(this.value + ((UnsignedLong)Preconditions.checkNotNull(val)).value);
/*  61:    */   }
/*  62:    */   
/*  63:    */   @CheckReturnValue
/*  64:    */   public UnsignedLong minus(UnsignedLong val)
/*  65:    */   {
/*  66:143 */     return fromLongBits(this.value - ((UnsignedLong)Preconditions.checkNotNull(val)).value);
/*  67:    */   }
/*  68:    */   
/*  69:    */   @CheckReturnValue
/*  70:    */   public UnsignedLong times(UnsignedLong val)
/*  71:    */   {
/*  72:154 */     return fromLongBits(this.value * ((UnsignedLong)Preconditions.checkNotNull(val)).value);
/*  73:    */   }
/*  74:    */   
/*  75:    */   @CheckReturnValue
/*  76:    */   public UnsignedLong dividedBy(UnsignedLong val)
/*  77:    */   {
/*  78:164 */     return fromLongBits(UnsignedLongs.divide(this.value, ((UnsignedLong)Preconditions.checkNotNull(val)).value));
/*  79:    */   }
/*  80:    */   
/*  81:    */   @CheckReturnValue
/*  82:    */   public UnsignedLong mod(UnsignedLong val)
/*  83:    */   {
/*  84:174 */     return fromLongBits(UnsignedLongs.remainder(this.value, ((UnsignedLong)Preconditions.checkNotNull(val)).value));
/*  85:    */   }
/*  86:    */   
/*  87:    */   public int intValue()
/*  88:    */   {
/*  89:182 */     return (int)this.value;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public long longValue()
/*  93:    */   {
/*  94:194 */     return this.value;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public float floatValue()
/*  98:    */   {
/*  99:204 */     float fValue = (float)(this.value & 0xFFFFFFFF);
/* 100:205 */     if (this.value < 0L) {
/* 101:206 */       fValue += 9.223372E+018F;
/* 102:    */     }
/* 103:208 */     return fValue;
/* 104:    */   }
/* 105:    */   
/* 106:    */   public double doubleValue()
/* 107:    */   {
/* 108:218 */     double dValue = this.value & 0xFFFFFFFF;
/* 109:219 */     if (this.value < 0L) {
/* 110:220 */       dValue += 9.223372036854776E+018D;
/* 111:    */     }
/* 112:222 */     return dValue;
/* 113:    */   }
/* 114:    */   
/* 115:    */   public BigInteger bigIntegerValue()
/* 116:    */   {
/* 117:229 */     BigInteger bigInt = BigInteger.valueOf(this.value & 0xFFFFFFFF);
/* 118:230 */     if (this.value < 0L) {
/* 119:231 */       bigInt = bigInt.setBit(63);
/* 120:    */     }
/* 121:233 */     return bigInt;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public int compareTo(UnsignedLong o)
/* 125:    */   {
/* 126:238 */     Preconditions.checkNotNull(o);
/* 127:239 */     return UnsignedLongs.compare(this.value, o.value);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public int hashCode()
/* 131:    */   {
/* 132:244 */     return Longs.hashCode(this.value);
/* 133:    */   }
/* 134:    */   
/* 135:    */   public boolean equals(@Nullable Object obj)
/* 136:    */   {
/* 137:249 */     if ((obj instanceof UnsignedLong))
/* 138:    */     {
/* 139:250 */       UnsignedLong other = (UnsignedLong)obj;
/* 140:251 */       return this.value == other.value;
/* 141:    */     }
/* 142:253 */     return false;
/* 143:    */   }
/* 144:    */   
/* 145:    */   public String toString()
/* 146:    */   {
/* 147:261 */     return UnsignedLongs.toString(this.value);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public String toString(int radix)
/* 151:    */   {
/* 152:270 */     return UnsignedLongs.toString(this.value, radix);
/* 153:    */   }
/* 154:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.UnsignedLong
 * JD-Core Version:    0.7.0.1
 */