/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.HashMap;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Set;
/*   8:    */ import javax.annotation.CheckReturnValue;
/*   9:    */ 
/*  10:    */ @CheckReturnValue
/*  11:    */ public final class Primitives
/*  12:    */ {
/*  13:    */   private static final Map<Class<?>, Class<?>> PRIMITIVE_TO_WRAPPER_TYPE;
/*  14:    */   private static final Map<Class<?>, Class<?>> WRAPPER_TO_PRIMITIVE_TYPE;
/*  15:    */   
/*  16:    */   static
/*  17:    */   {
/*  18: 48 */     Map<Class<?>, Class<?>> primToWrap = new HashMap(16);
/*  19: 49 */     Map<Class<?>, Class<?>> wrapToPrim = new HashMap(16);
/*  20:    */     
/*  21: 51 */     add(primToWrap, wrapToPrim, Boolean.TYPE, Boolean.class);
/*  22: 52 */     add(primToWrap, wrapToPrim, Byte.TYPE, Byte.class);
/*  23: 53 */     add(primToWrap, wrapToPrim, Character.TYPE, Character.class);
/*  24: 54 */     add(primToWrap, wrapToPrim, Double.TYPE, Double.class);
/*  25: 55 */     add(primToWrap, wrapToPrim, Float.TYPE, Float.class);
/*  26: 56 */     add(primToWrap, wrapToPrim, Integer.TYPE, Integer.class);
/*  27: 57 */     add(primToWrap, wrapToPrim, Long.TYPE, Long.class);
/*  28: 58 */     add(primToWrap, wrapToPrim, Short.TYPE, Short.class);
/*  29: 59 */     add(primToWrap, wrapToPrim, Void.TYPE, Void.class);
/*  30:    */     
/*  31: 61 */     PRIMITIVE_TO_WRAPPER_TYPE = Collections.unmodifiableMap(primToWrap);
/*  32: 62 */     WRAPPER_TO_PRIMITIVE_TYPE = Collections.unmodifiableMap(wrapToPrim);
/*  33:    */   }
/*  34:    */   
/*  35:    */   private static void add(Map<Class<?>, Class<?>> forward, Map<Class<?>, Class<?>> backward, Class<?> key, Class<?> value)
/*  36:    */   {
/*  37: 70 */     forward.put(key, value);
/*  38: 71 */     backward.put(value, key);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static Set<Class<?>> allPrimitiveTypes()
/*  42:    */   {
/*  43: 82 */     return PRIMITIVE_TO_WRAPPER_TYPE.keySet();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static Set<Class<?>> allWrapperTypes()
/*  47:    */   {
/*  48: 92 */     return WRAPPER_TO_PRIMITIVE_TYPE.keySet();
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static boolean isWrapperType(Class<?> type)
/*  52:    */   {
/*  53:102 */     return WRAPPER_TO_PRIMITIVE_TYPE.containsKey(Preconditions.checkNotNull(type));
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <T> Class<T> wrap(Class<T> type)
/*  57:    */   {
/*  58:115 */     Preconditions.checkNotNull(type);
/*  59:    */     
/*  60:    */ 
/*  61:    */ 
/*  62:119 */     Class<T> wrapped = (Class)PRIMITIVE_TO_WRAPPER_TYPE.get(type);
/*  63:120 */     return wrapped == null ? type : wrapped;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static <T> Class<T> unwrap(Class<T> type)
/*  67:    */   {
/*  68:133 */     Preconditions.checkNotNull(type);
/*  69:    */     
/*  70:    */ 
/*  71:    */ 
/*  72:137 */     Class<T> unwrapped = (Class)WRAPPER_TO_PRIMITIVE_TYPE.get(type);
/*  73:138 */     return unwrapped == null ? type : unwrapped;
/*  74:    */   }
/*  75:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Primitives
 * JD-Core Version:    0.7.0.1
 */