/*   1:    */ package com.google.common.primitives;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.AbstractList;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.RandomAccess;
/*  13:    */ import javax.annotation.CheckReturnValue;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @CheckReturnValue
/*  17:    */ @GwtCompatible(emulated=true)
/*  18:    */ public final class Chars
/*  19:    */ {
/*  20:    */   public static final int BYTES = 2;
/*  21:    */   
/*  22:    */   public static int hashCode(char value)
/*  23:    */   {
/*  24: 72 */     return value;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static char checkedCast(long value)
/*  28:    */   {
/*  29: 84 */     char result = (char)(int)value;
/*  30: 85 */     if (result != value) {
/*  31: 87 */       throw new IllegalArgumentException("Out of range: " + value);
/*  32:    */     }
/*  33: 89 */     return result;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static char saturatedCast(long value)
/*  37:    */   {
/*  38:101 */     if (value > 65535L) {
/*  39:102 */       return 65535;
/*  40:    */     }
/*  41:104 */     if (value < 0L) {
/*  42:105 */       return '\000';
/*  43:    */     }
/*  44:107 */     return (char)(int)value;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static int compare(char a, char b)
/*  48:    */   {
/*  49:123 */     return a - b;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static boolean contains(char[] array, char target)
/*  53:    */   {
/*  54:136 */     for (char value : array) {
/*  55:137 */       if (value == target) {
/*  56:138 */         return true;
/*  57:    */       }
/*  58:    */     }
/*  59:141 */     return false;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static int indexOf(char[] array, char target)
/*  63:    */   {
/*  64:154 */     return indexOf(array, target, 0, array.length);
/*  65:    */   }
/*  66:    */   
/*  67:    */   private static int indexOf(char[] array, char target, int start, int end)
/*  68:    */   {
/*  69:159 */     for (int i = start; i < end; i++) {
/*  70:160 */       if (array[i] == target) {
/*  71:161 */         return i;
/*  72:    */       }
/*  73:    */     }
/*  74:164 */     return -1;
/*  75:    */   }
/*  76:    */   
/*  77:    */   public static int indexOf(char[] array, char[] target)
/*  78:    */   {
/*  79:179 */     Preconditions.checkNotNull(array, "array");
/*  80:180 */     Preconditions.checkNotNull(target, "target");
/*  81:181 */     if (target.length == 0) {
/*  82:182 */       return 0;
/*  83:    */     }
/*  84:    */     label64:
/*  85:186 */     for (int i = 0; i < array.length - target.length + 1; i++)
/*  86:    */     {
/*  87:187 */       for (int j = 0; j < target.length; j++) {
/*  88:188 */         if (array[(i + j)] != target[j]) {
/*  89:    */           break label64;
/*  90:    */         }
/*  91:    */       }
/*  92:192 */       return i;
/*  93:    */     }
/*  94:194 */     return -1;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static int lastIndexOf(char[] array, char target)
/*  98:    */   {
/*  99:207 */     return lastIndexOf(array, target, 0, array.length);
/* 100:    */   }
/* 101:    */   
/* 102:    */   private static int lastIndexOf(char[] array, char target, int start, int end)
/* 103:    */   {
/* 104:212 */     for (int i = end - 1; i >= start; i--) {
/* 105:213 */       if (array[i] == target) {
/* 106:214 */         return i;
/* 107:    */       }
/* 108:    */     }
/* 109:217 */     return -1;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public static char min(char... array)
/* 113:    */   {
/* 114:229 */     Preconditions.checkArgument(array.length > 0);
/* 115:230 */     char min = array[0];
/* 116:231 */     for (int i = 1; i < array.length; i++) {
/* 117:232 */       if (array[i] < min) {
/* 118:233 */         min = array[i];
/* 119:    */       }
/* 120:    */     }
/* 121:236 */     return min;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public static char max(char... array)
/* 125:    */   {
/* 126:248 */     Preconditions.checkArgument(array.length > 0);
/* 127:249 */     char max = array[0];
/* 128:250 */     for (int i = 1; i < array.length; i++) {
/* 129:251 */       if (array[i] > max) {
/* 130:252 */         max = array[i];
/* 131:    */       }
/* 132:    */     }
/* 133:255 */     return max;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static char[] concat(char[]... arrays)
/* 137:    */   {
/* 138:268 */     int length = 0;
/* 139:269 */     for (char[] array : arrays) {
/* 140:270 */       length += array.length;
/* 141:    */     }
/* 142:272 */     char[] result = new char[length];
/* 143:273 */     int pos = 0;
/* 144:274 */     for (char[] array : arrays)
/* 145:    */     {
/* 146:275 */       System.arraycopy(array, 0, result, pos, array.length);
/* 147:276 */       pos += array.length;
/* 148:    */     }
/* 149:278 */     return result;
/* 150:    */   }
/* 151:    */   
/* 152:    */   @GwtIncompatible("doesn't work")
/* 153:    */   public static byte[] toByteArray(char value)
/* 154:    */   {
/* 155:294 */     return new byte[] { (byte)(value >> '\b'), (byte)value };
/* 156:    */   }
/* 157:    */   
/* 158:    */   @GwtIncompatible("doesn't work")
/* 159:    */   public static char fromByteArray(byte[] bytes)
/* 160:    */   {
/* 161:311 */     Preconditions.checkArgument(bytes.length >= 2, "array too small: %s < %s", new Object[] { Integer.valueOf(bytes.length), Integer.valueOf(2) });
/* 162:312 */     return fromBytes(bytes[0], bytes[1]);
/* 163:    */   }
/* 164:    */   
/* 165:    */   @GwtIncompatible("doesn't work")
/* 166:    */   public static char fromBytes(byte b1, byte b2)
/* 167:    */   {
/* 168:324 */     return (char)(b1 << 8 | b2 & 0xFF);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public static char[] ensureCapacity(char[] array, int minLength, int padding)
/* 172:    */   {
/* 173:344 */     Preconditions.checkArgument(minLength >= 0, "Invalid minLength: %s", new Object[] { Integer.valueOf(minLength) });
/* 174:345 */     Preconditions.checkArgument(padding >= 0, "Invalid padding: %s", new Object[] { Integer.valueOf(padding) });
/* 175:346 */     return array.length < minLength ? copyOf(array, minLength + padding) : array;
/* 176:    */   }
/* 177:    */   
/* 178:    */   private static char[] copyOf(char[] original, int length)
/* 179:    */   {
/* 180:353 */     char[] copy = new char[length];
/* 181:354 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, length));
/* 182:355 */     return copy;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public static String join(String separator, char... array)
/* 186:    */   {
/* 187:368 */     Preconditions.checkNotNull(separator);
/* 188:369 */     int len = array.length;
/* 189:370 */     if (len == 0) {
/* 190:371 */       return "";
/* 191:    */     }
/* 192:374 */     StringBuilder builder = new StringBuilder(len + separator.length() * (len - 1));
/* 193:375 */     builder.append(array[0]);
/* 194:376 */     for (int i = 1; i < len; i++) {
/* 195:377 */       builder.append(separator).append(array[i]);
/* 196:    */     }
/* 197:379 */     return builder.toString();
/* 198:    */   }
/* 199:    */   
/* 200:    */   public static Comparator<char[]> lexicographicalComparator()
/* 201:    */   {
/* 202:399 */     return LexicographicalComparator.INSTANCE;
/* 203:    */   }
/* 204:    */   
/* 205:    */   private static enum LexicographicalComparator
/* 206:    */     implements Comparator<char[]>
/* 207:    */   {
/* 208:403 */     INSTANCE;
/* 209:    */     
/* 210:    */     private LexicographicalComparator() {}
/* 211:    */     
/* 212:    */     public int compare(char[] left, char[] right)
/* 213:    */     {
/* 214:407 */       int minLength = Math.min(left.length, right.length);
/* 215:408 */       for (int i = 0; i < minLength; i++)
/* 216:    */       {
/* 217:409 */         int result = Chars.compare(left[i], right[i]);
/* 218:410 */         if (result != 0) {
/* 219:411 */           return result;
/* 220:    */         }
/* 221:    */       }
/* 222:414 */       return left.length - right.length;
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   public static char[] toArray(Collection<Character> collection)
/* 227:    */   {
/* 228:433 */     if ((collection instanceof CharArrayAsList)) {
/* 229:434 */       return ((CharArrayAsList)collection).toCharArray();
/* 230:    */     }
/* 231:437 */     Object[] boxedArray = collection.toArray();
/* 232:438 */     int len = boxedArray.length;
/* 233:439 */     char[] array = new char[len];
/* 234:440 */     for (int i = 0; i < len; i++) {
/* 235:442 */       array[i] = ((Character)Preconditions.checkNotNull(boxedArray[i])).charValue();
/* 236:    */     }
/* 237:444 */     return array;
/* 238:    */   }
/* 239:    */   
/* 240:    */   public static List<Character> asList(char... backingArray)
/* 241:    */   {
/* 242:462 */     if (backingArray.length == 0) {
/* 243:463 */       return Collections.emptyList();
/* 244:    */     }
/* 245:465 */     return new CharArrayAsList(backingArray);
/* 246:    */   }
/* 247:    */   
/* 248:    */   @GwtCompatible
/* 249:    */   private static class CharArrayAsList
/* 250:    */     extends AbstractList<Character>
/* 251:    */     implements RandomAccess, Serializable
/* 252:    */   {
/* 253:    */     final char[] array;
/* 254:    */     final int start;
/* 255:    */     final int end;
/* 256:    */     private static final long serialVersionUID = 0L;
/* 257:    */     
/* 258:    */     CharArrayAsList(char[] array)
/* 259:    */     {
/* 260:476 */       this(array, 0, array.length);
/* 261:    */     }
/* 262:    */     
/* 263:    */     CharArrayAsList(char[] array, int start, int end)
/* 264:    */     {
/* 265:480 */       this.array = array;
/* 266:481 */       this.start = start;
/* 267:482 */       this.end = end;
/* 268:    */     }
/* 269:    */     
/* 270:    */     public int size()
/* 271:    */     {
/* 272:487 */       return this.end - this.start;
/* 273:    */     }
/* 274:    */     
/* 275:    */     public boolean isEmpty()
/* 276:    */     {
/* 277:492 */       return false;
/* 278:    */     }
/* 279:    */     
/* 280:    */     public Character get(int index)
/* 281:    */     {
/* 282:497 */       Preconditions.checkElementIndex(index, size());
/* 283:498 */       return Character.valueOf(this.array[(this.start + index)]);
/* 284:    */     }
/* 285:    */     
/* 286:    */     public boolean contains(Object target)
/* 287:    */     {
/* 288:504 */       return ((target instanceof Character)) && (Chars.indexOf(this.array, ((Character)target).charValue(), this.start, this.end) != -1);
/* 289:    */     }
/* 290:    */     
/* 291:    */     public int indexOf(Object target)
/* 292:    */     {
/* 293:511 */       if ((target instanceof Character))
/* 294:    */       {
/* 295:512 */         int i = Chars.indexOf(this.array, ((Character)target).charValue(), this.start, this.end);
/* 296:513 */         if (i >= 0) {
/* 297:514 */           return i - this.start;
/* 298:    */         }
/* 299:    */       }
/* 300:517 */       return -1;
/* 301:    */     }
/* 302:    */     
/* 303:    */     public int lastIndexOf(Object target)
/* 304:    */     {
/* 305:523 */       if ((target instanceof Character))
/* 306:    */       {
/* 307:524 */         int i = Chars.lastIndexOf(this.array, ((Character)target).charValue(), this.start, this.end);
/* 308:525 */         if (i >= 0) {
/* 309:526 */           return i - this.start;
/* 310:    */         }
/* 311:    */       }
/* 312:529 */       return -1;
/* 313:    */     }
/* 314:    */     
/* 315:    */     public Character set(int index, Character element)
/* 316:    */     {
/* 317:534 */       Preconditions.checkElementIndex(index, size());
/* 318:535 */       char oldValue = this.array[(this.start + index)];
/* 319:    */       
/* 320:537 */       this.array[(this.start + index)] = ((Character)Preconditions.checkNotNull(element)).charValue();
/* 321:538 */       return Character.valueOf(oldValue);
/* 322:    */     }
/* 323:    */     
/* 324:    */     public List<Character> subList(int fromIndex, int toIndex)
/* 325:    */     {
/* 326:543 */       int size = size();
/* 327:544 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size);
/* 328:545 */       if (fromIndex == toIndex) {
/* 329:546 */         return Collections.emptyList();
/* 330:    */       }
/* 331:548 */       return new CharArrayAsList(this.array, this.start + fromIndex, this.start + toIndex);
/* 332:    */     }
/* 333:    */     
/* 334:    */     public boolean equals(@Nullable Object object)
/* 335:    */     {
/* 336:553 */       if (object == this) {
/* 337:554 */         return true;
/* 338:    */       }
/* 339:556 */       if ((object instanceof CharArrayAsList))
/* 340:    */       {
/* 341:557 */         CharArrayAsList that = (CharArrayAsList)object;
/* 342:558 */         int size = size();
/* 343:559 */         if (that.size() != size) {
/* 344:560 */           return false;
/* 345:    */         }
/* 346:562 */         for (int i = 0; i < size; i++) {
/* 347:563 */           if (this.array[(this.start + i)] != that.array[(that.start + i)]) {
/* 348:564 */             return false;
/* 349:    */           }
/* 350:    */         }
/* 351:567 */         return true;
/* 352:    */       }
/* 353:569 */       return super.equals(object);
/* 354:    */     }
/* 355:    */     
/* 356:    */     public int hashCode()
/* 357:    */     {
/* 358:574 */       int result = 1;
/* 359:575 */       for (int i = this.start; i < this.end; i++) {
/* 360:576 */         result = 31 * result + Chars.hashCode(this.array[i]);
/* 361:    */       }
/* 362:578 */       return result;
/* 363:    */     }
/* 364:    */     
/* 365:    */     public String toString()
/* 366:    */     {
/* 367:583 */       StringBuilder builder = new StringBuilder(size() * 3);
/* 368:584 */       builder.append('[').append(this.array[this.start]);
/* 369:585 */       for (int i = this.start + 1; i < this.end; i++) {
/* 370:586 */         builder.append(", ").append(this.array[i]);
/* 371:    */       }
/* 372:588 */       return ']';
/* 373:    */     }
/* 374:    */     
/* 375:    */     char[] toCharArray()
/* 376:    */     {
/* 377:593 */       int size = size();
/* 378:594 */       char[] result = new char[size];
/* 379:595 */       System.arraycopy(this.array, this.start, result, 0, size);
/* 380:596 */       return result;
/* 381:    */     }
/* 382:    */   }
/* 383:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.primitives.Chars
 * JD-Core Version:    0.7.0.1
 */