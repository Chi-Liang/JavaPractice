/*   1:    */ package com.google.common.xml;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.escape.Escaper;
/*   6:    */ import com.google.common.escape.Escapers;
/*   7:    */ import com.google.common.escape.Escapers.Builder;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ @GwtCompatible
/*  11:    */ public class XmlEscapers
/*  12:    */ {
/*  13:    */   private static final char MIN_ASCII_CONTROL_CHAR = '\000';
/*  14:    */   private static final char MAX_ASCII_CONTROL_CHAR = '\037';
/*  15:    */   private static final Escaper XML_ESCAPER;
/*  16:    */   private static final Escaper XML_CONTENT_ESCAPER;
/*  17:    */   private static final Escaper XML_ATTRIBUTE_ESCAPER;
/*  18:    */   
/*  19:    */   public static Escaper xmlContentEscaper()
/*  20:    */   {
/*  21: 86 */     return XML_CONTENT_ESCAPER;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static Escaper xmlAttributeEscaper()
/*  25:    */   {
/*  26:113 */     return XML_ATTRIBUTE_ESCAPER;
/*  27:    */   }
/*  28:    */   
/*  29:    */   static
/*  30:    */   {
/*  31:120 */     Escapers.Builder builder = Escapers.builder();
/*  32:    */     
/*  33:    */ 
/*  34:    */ 
/*  35:124 */     builder.setSafeRange('\000', 65533);
/*  36:    */     
/*  37:126 */     builder.setUnsafeReplacement("�");
/*  38:138 */     for (char c = '\000'; c <= '\037'; c = (char)(c + '\001')) {
/*  39:139 */       if ((c != '\t') && (c != '\n') && (c != '\r')) {
/*  40:140 */         builder.addEscape(c, "�");
/*  41:    */       }
/*  42:    */     }
/*  43:146 */     builder.addEscape('&', "&amp;");
/*  44:147 */     builder.addEscape('<', "&lt;");
/*  45:148 */     builder.addEscape('>', "&gt;");
/*  46:149 */     XML_CONTENT_ESCAPER = builder.build();
/*  47:150 */     builder.addEscape('\'', "&apos;");
/*  48:151 */     builder.addEscape('"', "&quot;");
/*  49:152 */     XML_ESCAPER = builder.build();
/*  50:153 */     builder.addEscape('\t', "&#x9;");
/*  51:154 */     builder.addEscape('\n', "&#xA;");
/*  52:155 */     builder.addEscape('\r', "&#xD;");
/*  53:156 */     XML_ATTRIBUTE_ESCAPER = builder.build();
/*  54:    */   }
/*  55:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.xml.XmlEscapers
 * JD-Core Version:    0.7.0.1
 */