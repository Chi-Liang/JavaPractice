

java.lang.annotation.Annotation
java.lang.annotation.Documented
java.lang.annotation.Retention
java.lang.annotation.RetentionPolicy
java.lang.annotation.Target

CLASS
TYPE, METHOD


GwtCompatible

  serializable
  
  emulated



/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.annotations.GwtCompatible
 * JD-Core Version:    0.7.0.1
 */