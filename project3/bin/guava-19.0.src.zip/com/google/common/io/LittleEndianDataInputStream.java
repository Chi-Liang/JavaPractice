/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.primitives.Ints;
/*   6:    */ import com.google.common.primitives.Longs;
/*   7:    */ import java.io.DataInput;
/*   8:    */ import java.io.DataInputStream;
/*   9:    */ import java.io.EOFException;
/*  10:    */ import java.io.FilterInputStream;
/*  11:    */ import java.io.IOException;
/*  12:    */ import java.io.InputStream;
/*  13:    */ 
/*  14:    */ @Beta
/*  15:    */ public final class LittleEndianDataInputStream
/*  16:    */   extends FilterInputStream
/*  17:    */   implements DataInput
/*  18:    */ {
/*  19:    */   public LittleEndianDataInputStream(InputStream in)
/*  20:    */   {
/*  21: 53 */     super((InputStream)Preconditions.checkNotNull(in));
/*  22:    */   }
/*  23:    */   
/*  24:    */   public String readLine()
/*  25:    */   {
/*  26: 61 */     throw new UnsupportedOperationException("readLine is not supported");
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void readFully(byte[] b)
/*  30:    */     throws IOException
/*  31:    */   {
/*  32: 66 */     ByteStreams.readFully(this, b);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void readFully(byte[] b, int off, int len)
/*  36:    */     throws IOException
/*  37:    */   {
/*  38: 71 */     ByteStreams.readFully(this, b, off, len);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public int skipBytes(int n)
/*  42:    */     throws IOException
/*  43:    */   {
/*  44: 76 */     return (int)this.in.skip(n);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public int readUnsignedByte()
/*  48:    */     throws IOException
/*  49:    */   {
/*  50: 81 */     int b1 = this.in.read();
/*  51: 82 */     if (0 > b1) {
/*  52: 83 */       throw new EOFException();
/*  53:    */     }
/*  54: 86 */     return b1;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public int readUnsignedShort()
/*  58:    */     throws IOException
/*  59:    */   {
/*  60:100 */     byte b1 = readAndCheckByte();
/*  61:101 */     byte b2 = readAndCheckByte();
/*  62:    */     
/*  63:103 */     return Ints.fromBytes((byte)0, (byte)0, b2, b1);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public int readInt()
/*  67:    */     throws IOException
/*  68:    */   {
/*  69:116 */     byte b1 = readAndCheckByte();
/*  70:117 */     byte b2 = readAndCheckByte();
/*  71:118 */     byte b3 = readAndCheckByte();
/*  72:119 */     byte b4 = readAndCheckByte();
/*  73:    */     
/*  74:121 */     return Ints.fromBytes(b4, b3, b2, b1);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public long readLong()
/*  78:    */     throws IOException
/*  79:    */   {
/*  80:134 */     byte b1 = readAndCheckByte();
/*  81:135 */     byte b2 = readAndCheckByte();
/*  82:136 */     byte b3 = readAndCheckByte();
/*  83:137 */     byte b4 = readAndCheckByte();
/*  84:138 */     byte b5 = readAndCheckByte();
/*  85:139 */     byte b6 = readAndCheckByte();
/*  86:140 */     byte b7 = readAndCheckByte();
/*  87:141 */     byte b8 = readAndCheckByte();
/*  88:    */     
/*  89:143 */     return Longs.fromBytes(b8, b7, b6, b5, b4, b3, b2, b1);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public float readFloat()
/*  93:    */     throws IOException
/*  94:    */   {
/*  95:156 */     return Float.intBitsToFloat(readInt());
/*  96:    */   }
/*  97:    */   
/*  98:    */   public double readDouble()
/*  99:    */     throws IOException
/* 100:    */   {
/* 101:170 */     return Double.longBitsToDouble(readLong());
/* 102:    */   }
/* 103:    */   
/* 104:    */   public String readUTF()
/* 105:    */     throws IOException
/* 106:    */   {
/* 107:175 */     return new DataInputStream(this.in).readUTF();
/* 108:    */   }
/* 109:    */   
/* 110:    */   public short readShort()
/* 111:    */     throws IOException
/* 112:    */   {
/* 113:188 */     return (short)readUnsignedShort();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public char readChar()
/* 117:    */     throws IOException
/* 118:    */   {
/* 119:201 */     return (char)readUnsignedShort();
/* 120:    */   }
/* 121:    */   
/* 122:    */   public byte readByte()
/* 123:    */     throws IOException
/* 124:    */   {
/* 125:206 */     return (byte)readUnsignedByte();
/* 126:    */   }
/* 127:    */   
/* 128:    */   public boolean readBoolean()
/* 129:    */     throws IOException
/* 130:    */   {
/* 131:211 */     return readUnsignedByte() != 0;
/* 132:    */   }
/* 133:    */   
/* 134:    */   private byte readAndCheckByte()
/* 135:    */     throws IOException, EOFException
/* 136:    */   {
/* 137:223 */     int b1 = this.in.read();
/* 138:225 */     if (-1 == b1) {
/* 139:226 */       throw new EOFException();
/* 140:    */     }
/* 141:229 */     return (byte)b1;
/* 142:    */   }
/* 143:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.LittleEndianDataInputStream
 * JD-Core Version:    0.7.0.1
 */