/*  1:   */ package com.google.common.io;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.FilterOutputStream;
/*  6:   */ import java.io.IOException;
/*  7:   */ import java.io.OutputStream;
/*  8:   */ 
/*  9:   */ @Beta
/* 10:   */ public final class CountingOutputStream
/* 11:   */   extends FilterOutputStream
/* 12:   */ {
/* 13:   */   private long count;
/* 14:   */   
/* 15:   */   public CountingOutputStream(OutputStream out)
/* 16:   */   {
/* 17:44 */     super((OutputStream)Preconditions.checkNotNull(out));
/* 18:   */   }
/* 19:   */   
/* 20:   */   public long getCount()
/* 21:   */   {
/* 22:49 */     return this.count;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public void write(byte[] b, int off, int len)
/* 26:   */     throws IOException
/* 27:   */   {
/* 28:53 */     this.out.write(b, off, len);
/* 29:54 */     this.count += len;
/* 30:   */   }
/* 31:   */   
/* 32:   */   public void write(int b)
/* 33:   */     throws IOException
/* 34:   */   {
/* 35:58 */     this.out.write(b);
/* 36:59 */     this.count += 1L;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public void close()
/* 40:   */     throws IOException
/* 41:   */   {
/* 42:66 */     this.out.close();
/* 43:   */   }
/* 44:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.CountingOutputStream
 * JD-Core Version:    0.7.0.1
 */