/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import java.io.Closeable;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InputStream;
/*   8:    */ import java.io.Reader;
/*   9:    */ import java.util.logging.Level;
/*  10:    */ import java.util.logging.Logger;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ 
/*  13:    */ @Beta
/*  14:    */ public final class Closeables
/*  15:    */ {
/*  16:    */   @VisibleForTesting
/*  17: 39 */   static final Logger logger = Logger.getLogger(Closeables.class.getName());
/*  18:    */   
/*  19:    */   public static void close(@Nullable Closeable closeable, boolean swallowIOException)
/*  20:    */     throws IOException
/*  21:    */   {
/*  22: 75 */     if (closeable == null) {
/*  23: 76 */       return;
/*  24:    */     }
/*  25:    */     try
/*  26:    */     {
/*  27: 79 */       closeable.close();
/*  28:    */     }
/*  29:    */     catch (IOException e)
/*  30:    */     {
/*  31: 81 */       if (swallowIOException) {
/*  32: 82 */         logger.log(Level.WARNING, "IOException thrown while closing Closeable.", e);
/*  33:    */       } else {
/*  34: 85 */         throw e;
/*  35:    */       }
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static void closeQuietly(@Nullable InputStream inputStream)
/*  40:    */   {
/*  41:    */     try
/*  42:    */     {
/*  43:106 */       close(inputStream, true);
/*  44:    */     }
/*  45:    */     catch (IOException impossible)
/*  46:    */     {
/*  47:108 */       throw new AssertionError(impossible);
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static void closeQuietly(@Nullable Reader reader)
/*  52:    */   {
/*  53:    */     try
/*  54:    */     {
/*  55:127 */       close(reader, true);
/*  56:    */     }
/*  57:    */     catch (IOException impossible)
/*  58:    */     {
/*  59:129 */       throw new AssertionError(impossible);
/*  60:    */     }
/*  61:    */   }
/*  62:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.Closeables
 * JD-Core Version:    0.7.0.1
 */