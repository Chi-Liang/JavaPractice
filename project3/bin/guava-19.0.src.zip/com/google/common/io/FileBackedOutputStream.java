/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import java.io.ByteArrayInputStream;
/*   6:    */ import java.io.ByteArrayOutputStream;
/*   7:    */ import java.io.File;
/*   8:    */ import java.io.FileInputStream;
/*   9:    */ import java.io.FileOutputStream;
/*  10:    */ import java.io.IOException;
/*  11:    */ import java.io.InputStream;
/*  12:    */ import java.io.OutputStream;
/*  13:    */ 
/*  14:    */ @Beta
/*  15:    */ public final class FileBackedOutputStream
/*  16:    */   extends OutputStream
/*  17:    */ {
/*  18:    */   private final int fileThreshold;
/*  19:    */   private final boolean resetOnFinalize;
/*  20:    */   private final ByteSource source;
/*  21:    */   private OutputStream out;
/*  22:    */   private MemoryOutput memory;
/*  23:    */   private File file;
/*  24:    */   
/*  25:    */   private static class MemoryOutput
/*  26:    */     extends ByteArrayOutputStream
/*  27:    */   {
/*  28:    */     byte[] getBuffer()
/*  29:    */     {
/*  30: 54 */       return this.buf;
/*  31:    */     }
/*  32:    */     
/*  33:    */     int getCount()
/*  34:    */     {
/*  35: 58 */       return this.count;
/*  36:    */     }
/*  37:    */   }
/*  38:    */   
/*  39:    */   @VisibleForTesting
/*  40:    */   synchronized File getFile()
/*  41:    */   {
/*  42: 64 */     return this.file;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public FileBackedOutputStream(int fileThreshold)
/*  46:    */   {
/*  47: 76 */     this(fileThreshold, false);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public FileBackedOutputStream(int fileThreshold, boolean resetOnFinalize)
/*  51:    */   {
/*  52: 91 */     this.fileThreshold = fileThreshold;
/*  53: 92 */     this.resetOnFinalize = resetOnFinalize;
/*  54: 93 */     this.memory = new MemoryOutput(null);
/*  55: 94 */     this.out = this.memory;
/*  56: 96 */     if (resetOnFinalize) {
/*  57: 97 */       this.source = new ByteSource()
/*  58:    */       {
/*  59:    */         public InputStream openStream()
/*  60:    */           throws IOException
/*  61:    */         {
/*  62:100 */           return FileBackedOutputStream.this.openInputStream();
/*  63:    */         }
/*  64:    */         
/*  65:    */         protected void finalize()
/*  66:    */         {
/*  67:    */           try
/*  68:    */           {
/*  69:105 */             FileBackedOutputStream.this.reset();
/*  70:    */           }
/*  71:    */           catch (Throwable t)
/*  72:    */           {
/*  73:107 */             t.printStackTrace(System.err);
/*  74:    */           }
/*  75:    */         }
/*  76:    */       };
/*  77:    */     } else {
/*  78:112 */       this.source = new ByteSource()
/*  79:    */       {
/*  80:    */         public InputStream openStream()
/*  81:    */           throws IOException
/*  82:    */         {
/*  83:115 */           return FileBackedOutputStream.this.openInputStream();
/*  84:    */         }
/*  85:    */       };
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public ByteSource asByteSource()
/*  90:    */   {
/*  91:128 */     return this.source;
/*  92:    */   }
/*  93:    */   
/*  94:    */   private synchronized InputStream openInputStream()
/*  95:    */     throws IOException
/*  96:    */   {
/*  97:132 */     if (this.file != null) {
/*  98:133 */       return new FileInputStream(this.file);
/*  99:    */     }
/* 100:135 */     return new ByteArrayInputStream(this.memory.getBuffer(), 0, this.memory.getCount());
/* 101:    */   }
/* 102:    */   
/* 103:    */   public synchronized void reset()
/* 104:    */     throws IOException
/* 105:    */   {
/* 106:    */     try
/* 107:    */     {
/* 108:149 */       close();
/* 109:    */     }
/* 110:    */     finally
/* 111:    */     {
/* 112:    */       File deleteMe;
/* 113:151 */       if (this.memory == null) {
/* 114:152 */         this.memory = new MemoryOutput(null);
/* 115:    */       } else {
/* 116:154 */         this.memory.reset();
/* 117:    */       }
/* 118:156 */       this.out = this.memory;
/* 119:157 */       if (this.file != null)
/* 120:    */       {
/* 121:158 */         File deleteMe = this.file;
/* 122:159 */         this.file = null;
/* 123:160 */         if (!deleteMe.delete()) {
/* 124:161 */           throw new IOException("Could not delete: " + deleteMe);
/* 125:    */         }
/* 126:    */       }
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   public synchronized void write(int b)
/* 131:    */     throws IOException
/* 132:    */   {
/* 133:168 */     update(1);
/* 134:169 */     this.out.write(b);
/* 135:    */   }
/* 136:    */   
/* 137:    */   public synchronized void write(byte[] b)
/* 138:    */     throws IOException
/* 139:    */   {
/* 140:173 */     write(b, 0, b.length);
/* 141:    */   }
/* 142:    */   
/* 143:    */   public synchronized void write(byte[] b, int off, int len)
/* 144:    */     throws IOException
/* 145:    */   {
/* 146:178 */     update(len);
/* 147:179 */     this.out.write(b, off, len);
/* 148:    */   }
/* 149:    */   
/* 150:    */   public synchronized void close()
/* 151:    */     throws IOException
/* 152:    */   {
/* 153:183 */     this.out.close();
/* 154:    */   }
/* 155:    */   
/* 156:    */   public synchronized void flush()
/* 157:    */     throws IOException
/* 158:    */   {
/* 159:187 */     this.out.flush();
/* 160:    */   }
/* 161:    */   
/* 162:    */   private void update(int len)
/* 163:    */     throws IOException
/* 164:    */   {
/* 165:195 */     if ((this.file == null) && (this.memory.getCount() + len > this.fileThreshold))
/* 166:    */     {
/* 167:196 */       File temp = File.createTempFile("FileBackedOutputStream", null);
/* 168:197 */       if (this.resetOnFinalize) {
/* 169:200 */         temp.deleteOnExit();
/* 170:    */       }
/* 171:202 */       FileOutputStream transfer = new FileOutputStream(temp);
/* 172:203 */       transfer.write(this.memory.getBuffer(), 0, this.memory.getCount());
/* 173:204 */       transfer.flush();
/* 174:    */       
/* 175:    */ 
/* 176:207 */       this.out = transfer;
/* 177:208 */       this.file = temp;
/* 178:209 */       this.memory = null;
/* 179:    */     }
/* 180:    */   }
/* 181:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.FileBackedOutputStream
 * JD-Core Version:    0.7.0.1
 */