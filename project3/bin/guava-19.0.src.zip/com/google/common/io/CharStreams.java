/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Closeable;
/*   6:    */ import java.io.EOFException;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.Reader;
/*   9:    */ import java.io.Writer;
/*  10:    */ import java.nio.CharBuffer;
/*  11:    */ import java.util.ArrayList;
/*  12:    */ import java.util.List;
/*  13:    */ 
/*  14:    */ @Beta
/*  15:    */ public final class CharStreams
/*  16:    */ {
/*  17:    */   private static final int BUF_SIZE = 2048;
/*  18:    */   
/*  19:    */   public static long copy(Readable from, Appendable to)
/*  20:    */     throws IOException
/*  21:    */   {
/*  22: 64 */     Preconditions.checkNotNull(from);
/*  23: 65 */     Preconditions.checkNotNull(to);
/*  24: 66 */     CharBuffer buf = CharBuffer.allocate(2048);
/*  25: 67 */     long total = 0L;
/*  26: 68 */     while (from.read(buf) != -1)
/*  27:    */     {
/*  28: 69 */       buf.flip();
/*  29: 70 */       to.append(buf);
/*  30: 71 */       total += buf.remaining();
/*  31: 72 */       buf.clear();
/*  32:    */     }
/*  33: 74 */     return total;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static String toString(Readable r)
/*  37:    */     throws IOException
/*  38:    */   {
/*  39: 86 */     return toStringBuilder(r).toString();
/*  40:    */   }
/*  41:    */   
/*  42:    */   private static StringBuilder toStringBuilder(Readable r)
/*  43:    */     throws IOException
/*  44:    */   {
/*  45: 98 */     StringBuilder sb = new StringBuilder();
/*  46: 99 */     copy(r, sb);
/*  47:100 */     return sb;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static List<String> readLines(Readable r)
/*  51:    */     throws IOException
/*  52:    */   {
/*  53:117 */     List<String> result = new ArrayList();
/*  54:118 */     LineReader lineReader = new LineReader(r);
/*  55:    */     String line;
/*  56:120 */     while ((line = lineReader.readLine()) != null) {
/*  57:121 */       result.add(line);
/*  58:    */     }
/*  59:123 */     return result;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static <T> T readLines(Readable readable, LineProcessor<T> processor)
/*  63:    */     throws IOException
/*  64:    */   {
/*  65:138 */     Preconditions.checkNotNull(readable);
/*  66:139 */     Preconditions.checkNotNull(processor);
/*  67:    */     
/*  68:141 */     LineReader lineReader = new LineReader(readable);
/*  69:    */     String line;
/*  70:143 */     while ((line = lineReader.readLine()) != null) {
/*  71:144 */       if (!processor.processLine(line)) {
/*  72:    */         break;
/*  73:    */       }
/*  74:    */     }
/*  75:148 */     return processor.getResult();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static void skipFully(Reader reader, long n)
/*  79:    */     throws IOException
/*  80:    */   {
/*  81:163 */     Preconditions.checkNotNull(reader);
/*  82:164 */     while (n > 0L)
/*  83:    */     {
/*  84:165 */       long amt = reader.skip(n);
/*  85:166 */       if (amt == 0L) {
/*  86:167 */         throw new EOFException();
/*  87:    */       }
/*  88:169 */       n -= amt;
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static Writer nullWriter()
/*  93:    */   {
/*  94:179 */     return NullWriter.INSTANCE;
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static final class NullWriter
/*  98:    */     extends Writer
/*  99:    */   {
/* 100:184 */     private static final NullWriter INSTANCE = new NullWriter();
/* 101:    */     
/* 102:    */     public void write(int c) {}
/* 103:    */     
/* 104:    */     public void write(char[] cbuf)
/* 105:    */     {
/* 106:192 */       Preconditions.checkNotNull(cbuf);
/* 107:    */     }
/* 108:    */     
/* 109:    */     public void write(char[] cbuf, int off, int len)
/* 110:    */     {
/* 111:197 */       Preconditions.checkPositionIndexes(off, off + len, cbuf.length);
/* 112:    */     }
/* 113:    */     
/* 114:    */     public void write(String str)
/* 115:    */     {
/* 116:202 */       Preconditions.checkNotNull(str);
/* 117:    */     }
/* 118:    */     
/* 119:    */     public void write(String str, int off, int len)
/* 120:    */     {
/* 121:207 */       Preconditions.checkPositionIndexes(off, off + len, str.length());
/* 122:    */     }
/* 123:    */     
/* 124:    */     public Writer append(CharSequence csq)
/* 125:    */     {
/* 126:212 */       Preconditions.checkNotNull(csq);
/* 127:213 */       return this;
/* 128:    */     }
/* 129:    */     
/* 130:    */     public Writer append(CharSequence csq, int start, int end)
/* 131:    */     {
/* 132:218 */       Preconditions.checkPositionIndexes(start, end, csq.length());
/* 133:219 */       return this;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public Writer append(char c)
/* 137:    */     {
/* 138:224 */       return this;
/* 139:    */     }
/* 140:    */     
/* 141:    */     public void flush() {}
/* 142:    */     
/* 143:    */     public void close() {}
/* 144:    */     
/* 145:    */     public String toString()
/* 146:    */     {
/* 147:237 */       return "CharStreams.nullWriter()";
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static Writer asWriter(Appendable target)
/* 152:    */   {
/* 153:252 */     if ((target instanceof Writer)) {
/* 154:253 */       return (Writer)target;
/* 155:    */     }
/* 156:255 */     return new AppendableWriter(target);
/* 157:    */   }
/* 158:    */   
/* 159:    */   static Reader asReader(Readable readable)
/* 160:    */   {
/* 161:261 */     Preconditions.checkNotNull(readable);
/* 162:262 */     if ((readable instanceof Reader)) {
/* 163:263 */       return (Reader)readable;
/* 164:    */     }
/* 165:265 */     new Reader()
/* 166:    */     {
/* 167:    */       public int read(char[] cbuf, int off, int len)
/* 168:    */         throws IOException
/* 169:    */       {
/* 170:268 */         return read(CharBuffer.wrap(cbuf, off, len));
/* 171:    */       }
/* 172:    */       
/* 173:    */       public int read(CharBuffer target)
/* 174:    */         throws IOException
/* 175:    */       {
/* 176:273 */         return this.val$readable.read(target);
/* 177:    */       }
/* 178:    */       
/* 179:    */       public void close()
/* 180:    */         throws IOException
/* 181:    */       {
/* 182:278 */         if ((this.val$readable instanceof Closeable)) {
/* 183:279 */           ((Closeable)this.val$readable).close();
/* 184:    */         }
/* 185:    */       }
/* 186:    */     };
/* 187:    */   }
/* 188:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.CharStreams
 * JD-Core Version:    0.7.0.1
 */