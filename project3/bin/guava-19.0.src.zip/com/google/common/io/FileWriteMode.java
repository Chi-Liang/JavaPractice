package com.google.common.io;

public enum FileWriteMode
{
  APPEND;
  
  private FileWriteMode() {}
}


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.FileWriteMode
 * JD-Core Version:    0.7.0.1
 */