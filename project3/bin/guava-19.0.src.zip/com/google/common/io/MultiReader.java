/*  1:   */ package com.google.common.io;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import java.io.IOException;
/*  5:   */ import java.io.Reader;
/*  6:   */ import java.util.Iterator;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ class MultiReader
/* 10:   */   extends Reader
/* 11:   */ {
/* 12:   */   private final Iterator<? extends CharSource> it;
/* 13:   */   private Reader current;
/* 14:   */   
/* 15:   */   MultiReader(Iterator<? extends CharSource> readers)
/* 16:   */     throws IOException
/* 17:   */   {
/* 18:38 */     this.it = readers;
/* 19:39 */     advance();
/* 20:   */   }
/* 21:   */   
/* 22:   */   private void advance()
/* 23:   */     throws IOException
/* 24:   */   {
/* 25:46 */     close();
/* 26:47 */     if (this.it.hasNext()) {
/* 27:48 */       this.current = ((CharSource)this.it.next()).openStream();
/* 28:   */     }
/* 29:   */   }
/* 30:   */   
/* 31:   */   public int read(@Nullable char[] cbuf, int off, int len)
/* 32:   */     throws IOException
/* 33:   */   {
/* 34:53 */     if (this.current == null) {
/* 35:54 */       return -1;
/* 36:   */     }
/* 37:56 */     int result = this.current.read(cbuf, off, len);
/* 38:57 */     if (result == -1)
/* 39:   */     {
/* 40:58 */       advance();
/* 41:59 */       return read(cbuf, off, len);
/* 42:   */     }
/* 43:61 */     return result;
/* 44:   */   }
/* 45:   */   
/* 46:   */   public long skip(long n)
/* 47:   */     throws IOException
/* 48:   */   {
/* 49:65 */     Preconditions.checkArgument(n >= 0L, "n is negative");
/* 50:66 */     if (n > 0L) {
/* 51:67 */       while (this.current != null)
/* 52:   */       {
/* 53:68 */         long result = this.current.skip(n);
/* 54:69 */         if (result > 0L) {
/* 55:70 */           return result;
/* 56:   */         }
/* 57:72 */         advance();
/* 58:   */       }
/* 59:   */     }
/* 60:75 */     return 0L;
/* 61:   */   }
/* 62:   */   
/* 63:   */   public boolean ready()
/* 64:   */     throws IOException
/* 65:   */   {
/* 66:79 */     return (this.current != null) && (this.current.ready());
/* 67:   */   }
/* 68:   */   
/* 69:   */   public void close()
/* 70:   */     throws IOException
/* 71:   */   {
/* 72:83 */     if (this.current != null) {
/* 73:   */       try
/* 74:   */       {
/* 75:85 */         this.current.close();
/* 76:   */       }
/* 77:   */       finally
/* 78:   */       {
/* 79:87 */         this.current = null;
/* 80:   */       }
/* 81:   */     }
/* 82:   */   }
/* 83:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.MultiReader
 * JD-Core Version:    0.7.0.1
 */