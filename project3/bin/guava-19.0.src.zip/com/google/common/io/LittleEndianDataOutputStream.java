/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.primitives.Longs;
/*   6:    */ import java.io.DataOutput;
/*   7:    */ import java.io.DataOutputStream;
/*   8:    */ import java.io.FilterOutputStream;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.io.OutputStream;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ public class LittleEndianDataOutputStream
/*  14:    */   extends FilterOutputStream
/*  15:    */   implements DataOutput
/*  16:    */ {
/*  17:    */   public LittleEndianDataOutputStream(OutputStream out)
/*  18:    */   {
/*  19: 52 */     super(new DataOutputStream((OutputStream)Preconditions.checkNotNull(out)));
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void write(byte[] b, int off, int len)
/*  23:    */     throws IOException
/*  24:    */   {
/*  25: 57 */     this.out.write(b, off, len);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public void writeBoolean(boolean v)
/*  29:    */     throws IOException
/*  30:    */   {
/*  31: 61 */     ((DataOutputStream)this.out).writeBoolean(v);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public void writeByte(int v)
/*  35:    */     throws IOException
/*  36:    */   {
/*  37: 65 */     ((DataOutputStream)this.out).writeByte(v);
/*  38:    */   }
/*  39:    */   
/*  40:    */   @Deprecated
/*  41:    */   public void writeBytes(String s)
/*  42:    */     throws IOException
/*  43:    */   {
/*  44: 75 */     ((DataOutputStream)this.out).writeBytes(s);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void writeChar(int v)
/*  48:    */     throws IOException
/*  49:    */   {
/*  50: 85 */     writeShort(v);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void writeChars(String s)
/*  54:    */     throws IOException
/*  55:    */   {
/*  56: 96 */     for (int i = 0; i < s.length(); i++) {
/*  57: 97 */       writeChar(s.charAt(i));
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public void writeDouble(double v)
/*  62:    */     throws IOException
/*  63:    */   {
/*  64:109 */     writeLong(Double.doubleToLongBits(v));
/*  65:    */   }
/*  66:    */   
/*  67:    */   public void writeFloat(float v)
/*  68:    */     throws IOException
/*  69:    */   {
/*  70:120 */     writeInt(Float.floatToIntBits(v));
/*  71:    */   }
/*  72:    */   
/*  73:    */   public void writeInt(int v)
/*  74:    */     throws IOException
/*  75:    */   {
/*  76:131 */     this.out.write(0xFF & v);
/*  77:132 */     this.out.write(0xFF & v >> 8);
/*  78:133 */     this.out.write(0xFF & v >> 16);
/*  79:134 */     this.out.write(0xFF & v >> 24);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void writeLong(long v)
/*  83:    */     throws IOException
/*  84:    */   {
/*  85:145 */     byte[] bytes = Longs.toByteArray(Long.reverseBytes(v));
/*  86:146 */     write(bytes, 0, bytes.length);
/*  87:    */   }
/*  88:    */   
/*  89:    */   public void writeShort(int v)
/*  90:    */     throws IOException
/*  91:    */   {
/*  92:157 */     this.out.write(0xFF & v);
/*  93:158 */     this.out.write(0xFF & v >> 8);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public void writeUTF(String str)
/*  97:    */     throws IOException
/*  98:    */   {
/*  99:162 */     ((DataOutputStream)this.out).writeUTF(str);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public void close()
/* 103:    */     throws IOException
/* 104:    */   {
/* 105:169 */     this.out.close();
/* 106:    */   }
/* 107:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.LittleEndianDataOutputStream
 * JD-Core Version:    0.7.0.1
 */