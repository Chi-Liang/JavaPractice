/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.ByteArrayInputStream;
/*   6:    */ import java.io.ByteArrayOutputStream;
/*   7:    */ import java.io.DataInput;
/*   8:    */ import java.io.DataInputStream;
/*   9:    */ import java.io.DataOutput;
/*  10:    */ import java.io.DataOutputStream;
/*  11:    */ import java.io.EOFException;
/*  12:    */ import java.io.FilterInputStream;
/*  13:    */ import java.io.IOException;
/*  14:    */ import java.io.InputStream;
/*  15:    */ import java.io.OutputStream;
/*  16:    */ import java.nio.ByteBuffer;
/*  17:    */ import java.nio.channels.FileChannel;
/*  18:    */ import java.nio.channels.ReadableByteChannel;
/*  19:    */ import java.nio.channels.WritableByteChannel;
/*  20:    */ import java.util.Arrays;
/*  21:    */ 
/*  22:    */ @Beta
/*  23:    */ public final class ByteStreams
/*  24:    */ {
/*  25:    */   static final int BUF_SIZE = 8192;
/*  26: 61 */   static final byte[] skipBuffer = new byte[8192];
/*  27:    */   private static final int ZERO_COPY_CHUNK_SIZE = 524288;
/*  28:    */   
/*  29:    */   public static long copy(InputStream from, OutputStream to)
/*  30:    */     throws IOException
/*  31:    */   {
/*  32:105 */     Preconditions.checkNotNull(from);
/*  33:106 */     Preconditions.checkNotNull(to);
/*  34:107 */     byte[] buf = new byte[8192];
/*  35:108 */     long total = 0L;
/*  36:    */     for (;;)
/*  37:    */     {
/*  38:110 */       int r = from.read(buf);
/*  39:111 */       if (r == -1) {
/*  40:    */         break;
/*  41:    */       }
/*  42:114 */       to.write(buf, 0, r);
/*  43:115 */       total += r;
/*  44:    */     }
/*  45:117 */     return total;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static long copy(ReadableByteChannel from, WritableByteChannel to)
/*  49:    */     throws IOException
/*  50:    */   {
/*  51:131 */     Preconditions.checkNotNull(from);
/*  52:132 */     Preconditions.checkNotNull(to);
/*  53:133 */     if ((from instanceof FileChannel))
/*  54:    */     {
/*  55:134 */       FileChannel sourceChannel = (FileChannel)from;
/*  56:135 */       long oldPosition = sourceChannel.position();
/*  57:136 */       long position = oldPosition;
/*  58:    */       long copied;
/*  59:    */       do
/*  60:    */       {
/*  61:139 */         copied = sourceChannel.transferTo(position, 524288L, to);
/*  62:140 */         position += copied;
/*  63:141 */         sourceChannel.position(position);
/*  64:142 */       } while ((copied > 0L) || (position < sourceChannel.size()));
/*  65:143 */       return position - oldPosition;
/*  66:    */     }
/*  67:146 */     ByteBuffer buf = ByteBuffer.allocate(8192);
/*  68:147 */     long total = 0L;
/*  69:148 */     while (from.read(buf) != -1)
/*  70:    */     {
/*  71:149 */       buf.flip();
/*  72:150 */       while (buf.hasRemaining()) {
/*  73:151 */         total += to.write(buf);
/*  74:    */       }
/*  75:153 */       buf.clear();
/*  76:    */     }
/*  77:155 */     return total;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static byte[] toByteArray(InputStream in)
/*  81:    */     throws IOException
/*  82:    */   {
/*  83:167 */     ByteArrayOutputStream out = new ByteArrayOutputStream();
/*  84:168 */     copy(in, out);
/*  85:169 */     return out.toByteArray();
/*  86:    */   }
/*  87:    */   
/*  88:    */   static byte[] toByteArray(InputStream in, int expectedSize)
/*  89:    */     throws IOException
/*  90:    */   {
/*  91:180 */     byte[] bytes = new byte[expectedSize];
/*  92:181 */     int remaining = expectedSize;
/*  93:183 */     while (remaining > 0)
/*  94:    */     {
/*  95:184 */       int off = expectedSize - remaining;
/*  96:185 */       int read = in.read(bytes, off, remaining);
/*  97:186 */       if (read == -1) {
/*  98:189 */         return Arrays.copyOf(bytes, off);
/*  99:    */       }
/* 100:191 */       remaining -= read;
/* 101:    */     }
/* 102:195 */     int b = in.read();
/* 103:196 */     if (b == -1) {
/* 104:197 */       return bytes;
/* 105:    */     }
/* 106:201 */     FastByteArrayOutputStream out = new FastByteArrayOutputStream(null);
/* 107:202 */     out.write(b);
/* 108:203 */     copy(in, out);
/* 109:    */     
/* 110:205 */     byte[] result = new byte[bytes.length + out.size()];
/* 111:206 */     System.arraycopy(bytes, 0, result, 0, bytes.length);
/* 112:207 */     out.writeTo(result, bytes.length);
/* 113:208 */     return result;
/* 114:    */   }
/* 115:    */   
/* 116:    */   private static final class FastByteArrayOutputStream
/* 117:    */     extends ByteArrayOutputStream
/* 118:    */   {
/* 119:    */     void writeTo(byte[] b, int off)
/* 120:    */     {
/* 121:221 */       System.arraycopy(this.buf, 0, b, off, this.count);
/* 122:    */     }
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static ByteArrayDataInput newDataInput(byte[] bytes)
/* 126:    */   {
/* 127:230 */     return newDataInput(new ByteArrayInputStream(bytes));
/* 128:    */   }
/* 129:    */   
/* 130:    */   public static ByteArrayDataInput newDataInput(byte[] bytes, int start)
/* 131:    */   {
/* 132:241 */     Preconditions.checkPositionIndex(start, bytes.length);
/* 133:242 */     return newDataInput(new ByteArrayInputStream(bytes, start, bytes.length - start));
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static ByteArrayDataInput newDataInput(ByteArrayInputStream byteArrayInputStream)
/* 137:    */   {
/* 138:255 */     return new ByteArrayDataInputStream((ByteArrayInputStream)Preconditions.checkNotNull(byteArrayInputStream));
/* 139:    */   }
/* 140:    */   
/* 141:    */   private static class ByteArrayDataInputStream
/* 142:    */     implements ByteArrayDataInput
/* 143:    */   {
/* 144:    */     final DataInput input;
/* 145:    */     
/* 146:    */     ByteArrayDataInputStream(ByteArrayInputStream byteArrayInputStream)
/* 147:    */     {
/* 148:262 */       this.input = new DataInputStream(byteArrayInputStream);
/* 149:    */     }
/* 150:    */     
/* 151:    */     public void readFully(byte[] b)
/* 152:    */     {
/* 153:    */       try
/* 154:    */       {
/* 155:267 */         this.input.readFully(b);
/* 156:    */       }
/* 157:    */       catch (IOException e)
/* 158:    */       {
/* 159:269 */         throw new IllegalStateException(e);
/* 160:    */       }
/* 161:    */     }
/* 162:    */     
/* 163:    */     public void readFully(byte[] b, int off, int len)
/* 164:    */     {
/* 165:    */       try
/* 166:    */       {
/* 167:275 */         this.input.readFully(b, off, len);
/* 168:    */       }
/* 169:    */       catch (IOException e)
/* 170:    */       {
/* 171:277 */         throw new IllegalStateException(e);
/* 172:    */       }
/* 173:    */     }
/* 174:    */     
/* 175:    */     public int skipBytes(int n)
/* 176:    */     {
/* 177:    */       try
/* 178:    */       {
/* 179:283 */         return this.input.skipBytes(n);
/* 180:    */       }
/* 181:    */       catch (IOException e)
/* 182:    */       {
/* 183:285 */         throw new IllegalStateException(e);
/* 184:    */       }
/* 185:    */     }
/* 186:    */     
/* 187:    */     public boolean readBoolean()
/* 188:    */     {
/* 189:    */       try
/* 190:    */       {
/* 191:291 */         return this.input.readBoolean();
/* 192:    */       }
/* 193:    */       catch (IOException e)
/* 194:    */       {
/* 195:293 */         throw new IllegalStateException(e);
/* 196:    */       }
/* 197:    */     }
/* 198:    */     
/* 199:    */     public byte readByte()
/* 200:    */     {
/* 201:    */       try
/* 202:    */       {
/* 203:299 */         return this.input.readByte();
/* 204:    */       }
/* 205:    */       catch (EOFException e)
/* 206:    */       {
/* 207:301 */         throw new IllegalStateException(e);
/* 208:    */       }
/* 209:    */       catch (IOException impossible)
/* 210:    */       {
/* 211:303 */         throw new AssertionError(impossible);
/* 212:    */       }
/* 213:    */     }
/* 214:    */     
/* 215:    */     public int readUnsignedByte()
/* 216:    */     {
/* 217:    */       try
/* 218:    */       {
/* 219:309 */         return this.input.readUnsignedByte();
/* 220:    */       }
/* 221:    */       catch (IOException e)
/* 222:    */       {
/* 223:311 */         throw new IllegalStateException(e);
/* 224:    */       }
/* 225:    */     }
/* 226:    */     
/* 227:    */     public short readShort()
/* 228:    */     {
/* 229:    */       try
/* 230:    */       {
/* 231:317 */         return this.input.readShort();
/* 232:    */       }
/* 233:    */       catch (IOException e)
/* 234:    */       {
/* 235:319 */         throw new IllegalStateException(e);
/* 236:    */       }
/* 237:    */     }
/* 238:    */     
/* 239:    */     public int readUnsignedShort()
/* 240:    */     {
/* 241:    */       try
/* 242:    */       {
/* 243:325 */         return this.input.readUnsignedShort();
/* 244:    */       }
/* 245:    */       catch (IOException e)
/* 246:    */       {
/* 247:327 */         throw new IllegalStateException(e);
/* 248:    */       }
/* 249:    */     }
/* 250:    */     
/* 251:    */     public char readChar()
/* 252:    */     {
/* 253:    */       try
/* 254:    */       {
/* 255:333 */         return this.input.readChar();
/* 256:    */       }
/* 257:    */       catch (IOException e)
/* 258:    */       {
/* 259:335 */         throw new IllegalStateException(e);
/* 260:    */       }
/* 261:    */     }
/* 262:    */     
/* 263:    */     public int readInt()
/* 264:    */     {
/* 265:    */       try
/* 266:    */       {
/* 267:341 */         return this.input.readInt();
/* 268:    */       }
/* 269:    */       catch (IOException e)
/* 270:    */       {
/* 271:343 */         throw new IllegalStateException(e);
/* 272:    */       }
/* 273:    */     }
/* 274:    */     
/* 275:    */     public long readLong()
/* 276:    */     {
/* 277:    */       try
/* 278:    */       {
/* 279:349 */         return this.input.readLong();
/* 280:    */       }
/* 281:    */       catch (IOException e)
/* 282:    */       {
/* 283:351 */         throw new IllegalStateException(e);
/* 284:    */       }
/* 285:    */     }
/* 286:    */     
/* 287:    */     public float readFloat()
/* 288:    */     {
/* 289:    */       try
/* 290:    */       {
/* 291:357 */         return this.input.readFloat();
/* 292:    */       }
/* 293:    */       catch (IOException e)
/* 294:    */       {
/* 295:359 */         throw new IllegalStateException(e);
/* 296:    */       }
/* 297:    */     }
/* 298:    */     
/* 299:    */     public double readDouble()
/* 300:    */     {
/* 301:    */       try
/* 302:    */       {
/* 303:365 */         return this.input.readDouble();
/* 304:    */       }
/* 305:    */       catch (IOException e)
/* 306:    */       {
/* 307:367 */         throw new IllegalStateException(e);
/* 308:    */       }
/* 309:    */     }
/* 310:    */     
/* 311:    */     public String readLine()
/* 312:    */     {
/* 313:    */       try
/* 314:    */       {
/* 315:373 */         return this.input.readLine();
/* 316:    */       }
/* 317:    */       catch (IOException e)
/* 318:    */       {
/* 319:375 */         throw new IllegalStateException(e);
/* 320:    */       }
/* 321:    */     }
/* 322:    */     
/* 323:    */     public String readUTF()
/* 324:    */     {
/* 325:    */       try
/* 326:    */       {
/* 327:381 */         return this.input.readUTF();
/* 328:    */       }
/* 329:    */       catch (IOException e)
/* 330:    */       {
/* 331:383 */         throw new IllegalStateException(e);
/* 332:    */       }
/* 333:    */     }
/* 334:    */   }
/* 335:    */   
/* 336:    */   public static ByteArrayDataOutput newDataOutput()
/* 337:    */   {
/* 338:392 */     return newDataOutput(new ByteArrayOutputStream());
/* 339:    */   }
/* 340:    */   
/* 341:    */   public static ByteArrayDataOutput newDataOutput(int size)
/* 342:    */   {
/* 343:404 */     if (size < 0) {
/* 344:405 */       throw new IllegalArgumentException(String.format("Invalid size: %s", new Object[] { Integer.valueOf(size) }));
/* 345:    */     }
/* 346:407 */     return newDataOutput(new ByteArrayOutputStream(size));
/* 347:    */   }
/* 348:    */   
/* 349:    */   public static ByteArrayDataOutput newDataOutput(ByteArrayOutputStream byteArrayOutputSteam)
/* 350:    */   {
/* 351:426 */     return new ByteArrayDataOutputStream((ByteArrayOutputStream)Preconditions.checkNotNull(byteArrayOutputSteam));
/* 352:    */   }
/* 353:    */   
/* 354:    */   private static class ByteArrayDataOutputStream
/* 355:    */     implements ByteArrayDataOutput
/* 356:    */   {
/* 357:    */     final DataOutput output;
/* 358:    */     final ByteArrayOutputStream byteArrayOutputSteam;
/* 359:    */     
/* 360:    */     ByteArrayDataOutputStream(ByteArrayOutputStream byteArrayOutputSteam)
/* 361:    */     {
/* 362:437 */       this.byteArrayOutputSteam = byteArrayOutputSteam;
/* 363:438 */       this.output = new DataOutputStream(byteArrayOutputSteam);
/* 364:    */     }
/* 365:    */     
/* 366:    */     public void write(int b)
/* 367:    */     {
/* 368:    */       try
/* 369:    */       {
/* 370:443 */         this.output.write(b);
/* 371:    */       }
/* 372:    */       catch (IOException impossible)
/* 373:    */       {
/* 374:445 */         throw new AssertionError(impossible);
/* 375:    */       }
/* 376:    */     }
/* 377:    */     
/* 378:    */     public void write(byte[] b)
/* 379:    */     {
/* 380:    */       try
/* 381:    */       {
/* 382:451 */         this.output.write(b);
/* 383:    */       }
/* 384:    */       catch (IOException impossible)
/* 385:    */       {
/* 386:453 */         throw new AssertionError(impossible);
/* 387:    */       }
/* 388:    */     }
/* 389:    */     
/* 390:    */     public void write(byte[] b, int off, int len)
/* 391:    */     {
/* 392:    */       try
/* 393:    */       {
/* 394:459 */         this.output.write(b, off, len);
/* 395:    */       }
/* 396:    */       catch (IOException impossible)
/* 397:    */       {
/* 398:461 */         throw new AssertionError(impossible);
/* 399:    */       }
/* 400:    */     }
/* 401:    */     
/* 402:    */     public void writeBoolean(boolean v)
/* 403:    */     {
/* 404:    */       try
/* 405:    */       {
/* 406:467 */         this.output.writeBoolean(v);
/* 407:    */       }
/* 408:    */       catch (IOException impossible)
/* 409:    */       {
/* 410:469 */         throw new AssertionError(impossible);
/* 411:    */       }
/* 412:    */     }
/* 413:    */     
/* 414:    */     public void writeByte(int v)
/* 415:    */     {
/* 416:    */       try
/* 417:    */       {
/* 418:475 */         this.output.writeByte(v);
/* 419:    */       }
/* 420:    */       catch (IOException impossible)
/* 421:    */       {
/* 422:477 */         throw new AssertionError(impossible);
/* 423:    */       }
/* 424:    */     }
/* 425:    */     
/* 426:    */     public void writeBytes(String s)
/* 427:    */     {
/* 428:    */       try
/* 429:    */       {
/* 430:483 */         this.output.writeBytes(s);
/* 431:    */       }
/* 432:    */       catch (IOException impossible)
/* 433:    */       {
/* 434:485 */         throw new AssertionError(impossible);
/* 435:    */       }
/* 436:    */     }
/* 437:    */     
/* 438:    */     public void writeChar(int v)
/* 439:    */     {
/* 440:    */       try
/* 441:    */       {
/* 442:491 */         this.output.writeChar(v);
/* 443:    */       }
/* 444:    */       catch (IOException impossible)
/* 445:    */       {
/* 446:493 */         throw new AssertionError(impossible);
/* 447:    */       }
/* 448:    */     }
/* 449:    */     
/* 450:    */     public void writeChars(String s)
/* 451:    */     {
/* 452:    */       try
/* 453:    */       {
/* 454:499 */         this.output.writeChars(s);
/* 455:    */       }
/* 456:    */       catch (IOException impossible)
/* 457:    */       {
/* 458:501 */         throw new AssertionError(impossible);
/* 459:    */       }
/* 460:    */     }
/* 461:    */     
/* 462:    */     public void writeDouble(double v)
/* 463:    */     {
/* 464:    */       try
/* 465:    */       {
/* 466:507 */         this.output.writeDouble(v);
/* 467:    */       }
/* 468:    */       catch (IOException impossible)
/* 469:    */       {
/* 470:509 */         throw new AssertionError(impossible);
/* 471:    */       }
/* 472:    */     }
/* 473:    */     
/* 474:    */     public void writeFloat(float v)
/* 475:    */     {
/* 476:    */       try
/* 477:    */       {
/* 478:515 */         this.output.writeFloat(v);
/* 479:    */       }
/* 480:    */       catch (IOException impossible)
/* 481:    */       {
/* 482:517 */         throw new AssertionError(impossible);
/* 483:    */       }
/* 484:    */     }
/* 485:    */     
/* 486:    */     public void writeInt(int v)
/* 487:    */     {
/* 488:    */       try
/* 489:    */       {
/* 490:523 */         this.output.writeInt(v);
/* 491:    */       }
/* 492:    */       catch (IOException impossible)
/* 493:    */       {
/* 494:525 */         throw new AssertionError(impossible);
/* 495:    */       }
/* 496:    */     }
/* 497:    */     
/* 498:    */     public void writeLong(long v)
/* 499:    */     {
/* 500:    */       try
/* 501:    */       {
/* 502:531 */         this.output.writeLong(v);
/* 503:    */       }
/* 504:    */       catch (IOException impossible)
/* 505:    */       {
/* 506:533 */         throw new AssertionError(impossible);
/* 507:    */       }
/* 508:    */     }
/* 509:    */     
/* 510:    */     public void writeShort(int v)
/* 511:    */     {
/* 512:    */       try
/* 513:    */       {
/* 514:539 */         this.output.writeShort(v);
/* 515:    */       }
/* 516:    */       catch (IOException impossible)
/* 517:    */       {
/* 518:541 */         throw new AssertionError(impossible);
/* 519:    */       }
/* 520:    */     }
/* 521:    */     
/* 522:    */     public void writeUTF(String s)
/* 523:    */     {
/* 524:    */       try
/* 525:    */       {
/* 526:547 */         this.output.writeUTF(s);
/* 527:    */       }
/* 528:    */       catch (IOException impossible)
/* 529:    */       {
/* 530:549 */         throw new AssertionError(impossible);
/* 531:    */       }
/* 532:    */     }
/* 533:    */     
/* 534:    */     public byte[] toByteArray()
/* 535:    */     {
/* 536:554 */       return this.byteArrayOutputSteam.toByteArray();
/* 537:    */     }
/* 538:    */   }
/* 539:    */   
/* 540:558 */   private static final OutputStream NULL_OUTPUT_STREAM = new OutputStream()
/* 541:    */   {
/* 542:    */     public void write(int b) {}
/* 543:    */     
/* 544:    */     public void write(byte[] b)
/* 545:    */     {
/* 546:565 */       Preconditions.checkNotNull(b);
/* 547:    */     }
/* 548:    */     
/* 549:    */     public void write(byte[] b, int off, int len)
/* 550:    */     {
/* 551:569 */       Preconditions.checkNotNull(b);
/* 552:    */     }
/* 553:    */     
/* 554:    */     public String toString()
/* 555:    */     {
/* 556:574 */       return "ByteStreams.nullOutputStream()";
/* 557:    */     }
/* 558:    */   };
/* 559:    */   
/* 560:    */   public static OutputStream nullOutputStream()
/* 561:    */   {
/* 562:584 */     return NULL_OUTPUT_STREAM;
/* 563:    */   }
/* 564:    */   
/* 565:    */   public static InputStream limit(InputStream in, long limit)
/* 566:    */   {
/* 567:597 */     return new LimitedInputStream(in, limit);
/* 568:    */   }
/* 569:    */   
/* 570:    */   private static final class LimitedInputStream
/* 571:    */     extends FilterInputStream
/* 572:    */   {
/* 573:    */     private long left;
/* 574:603 */     private long mark = -1L;
/* 575:    */     
/* 576:    */     LimitedInputStream(InputStream in, long limit)
/* 577:    */     {
/* 578:606 */       super();
/* 579:607 */       Preconditions.checkNotNull(in);
/* 580:608 */       Preconditions.checkArgument(limit >= 0L, "limit must be non-negative");
/* 581:609 */       this.left = limit;
/* 582:    */     }
/* 583:    */     
/* 584:    */     public int available()
/* 585:    */       throws IOException
/* 586:    */     {
/* 587:613 */       return (int)Math.min(this.in.available(), this.left);
/* 588:    */     }
/* 589:    */     
/* 590:    */     public synchronized void mark(int readLimit)
/* 591:    */     {
/* 592:618 */       this.in.mark(readLimit);
/* 593:619 */       this.mark = this.left;
/* 594:    */     }
/* 595:    */     
/* 596:    */     public int read()
/* 597:    */       throws IOException
/* 598:    */     {
/* 599:623 */       if (this.left == 0L) {
/* 600:624 */         return -1;
/* 601:    */       }
/* 602:627 */       int result = this.in.read();
/* 603:628 */       if (result != -1) {
/* 604:629 */         this.left -= 1L;
/* 605:    */       }
/* 606:631 */       return result;
/* 607:    */     }
/* 608:    */     
/* 609:    */     public int read(byte[] b, int off, int len)
/* 610:    */       throws IOException
/* 611:    */     {
/* 612:635 */       if (this.left == 0L) {
/* 613:636 */         return -1;
/* 614:    */       }
/* 615:639 */       len = (int)Math.min(len, this.left);
/* 616:640 */       int result = this.in.read(b, off, len);
/* 617:641 */       if (result != -1) {
/* 618:642 */         this.left -= result;
/* 619:    */       }
/* 620:644 */       return result;
/* 621:    */     }
/* 622:    */     
/* 623:    */     public synchronized void reset()
/* 624:    */       throws IOException
/* 625:    */     {
/* 626:648 */       if (!this.in.markSupported()) {
/* 627:649 */         throw new IOException("Mark not supported");
/* 628:    */       }
/* 629:651 */       if (this.mark == -1L) {
/* 630:652 */         throw new IOException("Mark not set");
/* 631:    */       }
/* 632:655 */       this.in.reset();
/* 633:656 */       this.left = this.mark;
/* 634:    */     }
/* 635:    */     
/* 636:    */     public long skip(long n)
/* 637:    */       throws IOException
/* 638:    */     {
/* 639:660 */       n = Math.min(n, this.left);
/* 640:661 */       long skipped = this.in.skip(n);
/* 641:662 */       this.left -= skipped;
/* 642:663 */       return skipped;
/* 643:    */     }
/* 644:    */   }
/* 645:    */   
/* 646:    */   public static void readFully(InputStream in, byte[] b)
/* 647:    */     throws IOException
/* 648:    */   {
/* 649:679 */     readFully(in, b, 0, b.length);
/* 650:    */   }
/* 651:    */   
/* 652:    */   public static void readFully(InputStream in, byte[] b, int off, int len)
/* 653:    */     throws IOException
/* 654:    */   {
/* 655:698 */     int read = read(in, b, off, len);
/* 656:699 */     if (read != len) {
/* 657:700 */       throw new EOFException("reached end of stream after reading " + read + " bytes; " + len + " bytes expected");
/* 658:    */     }
/* 659:    */   }
/* 660:    */   
/* 661:    */   public static void skipFully(InputStream in, long n)
/* 662:    */     throws IOException
/* 663:    */   {
/* 664:718 */     long skipped = skipUpTo(in, n);
/* 665:719 */     if (skipped < n) {
/* 666:720 */       throw new EOFException("reached end of stream after skipping " + skipped + " bytes; " + n + " bytes expected");
/* 667:    */     }
/* 668:    */   }
/* 669:    */   
/* 670:    */   static long skipUpTo(InputStream in, long n)
/* 671:    */     throws IOException
/* 672:    */   {
/* 673:732 */     long totalSkipped = 0L;
/* 674:734 */     while (totalSkipped < n)
/* 675:    */     {
/* 676:735 */       long remaining = n - totalSkipped;
/* 677:    */       
/* 678:737 */       long skipped = skipSafely(in, remaining);
/* 679:739 */       if (skipped == 0L)
/* 680:    */       {
/* 681:742 */         int skip = (int)Math.min(remaining, skipBuffer.length);
/* 682:743 */         if ((skipped = in.read(skipBuffer, 0, skip)) == -1L) {
/* 683:    */           break;
/* 684:    */         }
/* 685:    */       }
/* 686:749 */       totalSkipped += skipped;
/* 687:    */     }
/* 688:752 */     return totalSkipped;
/* 689:    */   }
/* 690:    */   
/* 691:    */   private static long skipSafely(InputStream in, long n)
/* 692:    */     throws IOException
/* 693:    */   {
/* 694:763 */     int available = in.available();
/* 695:764 */     return available == 0 ? 0L : in.skip(Math.min(available, n));
/* 696:    */   }
/* 697:    */   
/* 698:    */   public static <T> T readBytes(InputStream input, ByteProcessor<T> processor)
/* 699:    */     throws IOException
/* 700:    */   {
/* 701:778 */     Preconditions.checkNotNull(input);
/* 702:779 */     Preconditions.checkNotNull(processor);
/* 703:    */     
/* 704:781 */     byte[] buf = new byte[8192];
/* 705:    */     int read;
/* 706:    */     do
/* 707:    */     {
/* 708:784 */       read = input.read(buf);
/* 709:785 */     } while ((read != -1) && (processor.processBytes(buf, 0, read)));
/* 710:786 */     return processor.getResult();
/* 711:    */   }
/* 712:    */   
/* 713:    */   public static int read(InputStream in, byte[] b, int off, int len)
/* 714:    */     throws IOException
/* 715:    */   {
/* 716:815 */     Preconditions.checkNotNull(in);
/* 717:816 */     Preconditions.checkNotNull(b);
/* 718:817 */     if (len < 0) {
/* 719:818 */       throw new IndexOutOfBoundsException("len is negative");
/* 720:    */     }
/* 721:820 */     int total = 0;
/* 722:821 */     while (total < len)
/* 723:    */     {
/* 724:822 */       int result = in.read(b, off + total, len - total);
/* 725:823 */       if (result == -1) {
/* 726:    */         break;
/* 727:    */       }
/* 728:826 */       total += result;
/* 729:    */     }
/* 730:828 */     return total;
/* 731:    */   }
/* 732:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.ByteStreams
 * JD-Core Version:    0.7.0.1
 */