/*  1:   */ package com.google.common.io;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import java.io.Flushable;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.util.logging.Level;
/*  7:   */ import java.util.logging.Logger;
/*  8:   */ 
/*  9:   */ @Beta
/* 10:   */ public final class Flushables
/* 11:   */ {
/* 12:34 */   private static final Logger logger = Logger.getLogger(Flushables.class.getName());
/* 13:   */   
/* 14:   */   public static void flush(Flushable flushable, boolean swallowIOException)
/* 15:   */     throws IOException
/* 16:   */   {
/* 17:   */     try
/* 18:   */     {
/* 19:56 */       flushable.flush();
/* 20:   */     }
/* 21:   */     catch (IOException e)
/* 22:   */     {
/* 23:58 */       if (swallowIOException) {
/* 24:59 */         logger.log(Level.WARNING, "IOException thrown while flushing Flushable.", e);
/* 25:   */       } else {
/* 26:62 */         throw e;
/* 27:   */       }
/* 28:   */     }
/* 29:   */   }
/* 30:   */   
/* 31:   */   public static void flushQuietly(Flushable flushable)
/* 32:   */   {
/* 33:   */     try
/* 34:   */     {
/* 35:75 */       flush(flushable, true);
/* 36:   */     }
/* 37:   */     catch (IOException e)
/* 38:   */     {
/* 39:77 */       logger.log(Level.SEVERE, "IOException should not have been thrown.", e);
/* 40:   */     }
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.Flushables
 * JD-Core Version:    0.7.0.1
 */