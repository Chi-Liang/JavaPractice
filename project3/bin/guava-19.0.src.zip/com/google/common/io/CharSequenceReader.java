/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.Reader;
/*   6:    */ import java.nio.CharBuffer;
/*   7:    */ 
/*   8:    */ final class CharSequenceReader
/*   9:    */   extends Reader
/*  10:    */ {
/*  11:    */   private CharSequence seq;
/*  12:    */   private int pos;
/*  13:    */   private int mark;
/*  14:    */   
/*  15:    */   public CharSequenceReader(CharSequence seq)
/*  16:    */   {
/*  17: 44 */     this.seq = ((CharSequence)Preconditions.checkNotNull(seq));
/*  18:    */   }
/*  19:    */   
/*  20:    */   private void checkOpen()
/*  21:    */     throws IOException
/*  22:    */   {
/*  23: 48 */     if (this.seq == null) {
/*  24: 49 */       throw new IOException("reader closed");
/*  25:    */     }
/*  26:    */   }
/*  27:    */   
/*  28:    */   private boolean hasRemaining()
/*  29:    */   {
/*  30: 54 */     return remaining() > 0;
/*  31:    */   }
/*  32:    */   
/*  33:    */   private int remaining()
/*  34:    */   {
/*  35: 58 */     return this.seq.length() - this.pos;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public synchronized int read(CharBuffer target)
/*  39:    */     throws IOException
/*  40:    */   {
/*  41: 63 */     Preconditions.checkNotNull(target);
/*  42: 64 */     checkOpen();
/*  43: 65 */     if (!hasRemaining()) {
/*  44: 66 */       return -1;
/*  45:    */     }
/*  46: 68 */     int charsToRead = Math.min(target.remaining(), remaining());
/*  47: 69 */     for (int i = 0; i < charsToRead; i++) {
/*  48: 70 */       target.put(this.seq.charAt(this.pos++));
/*  49:    */     }
/*  50: 72 */     return charsToRead;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public synchronized int read()
/*  54:    */     throws IOException
/*  55:    */   {
/*  56: 77 */     checkOpen();
/*  57: 78 */     return hasRemaining() ? this.seq.charAt(this.pos++) : -1;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public synchronized int read(char[] cbuf, int off, int len)
/*  61:    */     throws IOException
/*  62:    */   {
/*  63: 83 */     Preconditions.checkPositionIndexes(off, off + len, cbuf.length);
/*  64: 84 */     checkOpen();
/*  65: 85 */     if (!hasRemaining()) {
/*  66: 86 */       return -1;
/*  67:    */     }
/*  68: 88 */     int charsToRead = Math.min(len, remaining());
/*  69: 89 */     for (int i = 0; i < charsToRead; i++) {
/*  70: 90 */       cbuf[(off + i)] = this.seq.charAt(this.pos++);
/*  71:    */     }
/*  72: 92 */     return charsToRead;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public synchronized long skip(long n)
/*  76:    */     throws IOException
/*  77:    */   {
/*  78: 97 */     Preconditions.checkArgument(n >= 0L, "n (%s) may not be negative", new Object[] { Long.valueOf(n) });
/*  79: 98 */     checkOpen();
/*  80: 99 */     int charsToSkip = (int)Math.min(remaining(), n);
/*  81:100 */     this.pos += charsToSkip;
/*  82:101 */     return charsToSkip;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public synchronized boolean ready()
/*  86:    */     throws IOException
/*  87:    */   {
/*  88:106 */     checkOpen();
/*  89:107 */     return true;
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean markSupported()
/*  93:    */   {
/*  94:112 */     return true;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public synchronized void mark(int readAheadLimit)
/*  98:    */     throws IOException
/*  99:    */   {
/* 100:117 */     Preconditions.checkArgument(readAheadLimit >= 0, "readAheadLimit (%s) may not be negative", new Object[] { Integer.valueOf(readAheadLimit) });
/* 101:118 */     checkOpen();
/* 102:119 */     this.mark = this.pos;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public synchronized void reset()
/* 106:    */     throws IOException
/* 107:    */   {
/* 108:124 */     checkOpen();
/* 109:125 */     this.pos = this.mark;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public synchronized void close()
/* 113:    */     throws IOException
/* 114:    */   {
/* 115:130 */     this.seq = null;
/* 116:    */   }
/* 117:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.CharSequenceReader
 * JD-Core Version:    0.7.0.1
 */