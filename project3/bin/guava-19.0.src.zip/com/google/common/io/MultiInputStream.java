/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.IOException;
/*   5:    */ import java.io.InputStream;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ final class MultiInputStream
/*  10:    */   extends InputStream
/*  11:    */ {
/*  12:    */   private Iterator<? extends ByteSource> it;
/*  13:    */   private InputStream in;
/*  14:    */   
/*  15:    */   public MultiInputStream(Iterator<? extends ByteSource> it)
/*  16:    */     throws IOException
/*  17:    */   {
/*  18: 46 */     this.it = ((Iterator)Preconditions.checkNotNull(it));
/*  19: 47 */     advance();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public void close()
/*  23:    */     throws IOException
/*  24:    */   {
/*  25: 51 */     if (this.in != null) {
/*  26:    */       try
/*  27:    */       {
/*  28: 53 */         this.in.close();
/*  29:    */       }
/*  30:    */       finally
/*  31:    */       {
/*  32: 55 */         this.in = null;
/*  33:    */       }
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   private void advance()
/*  38:    */     throws IOException
/*  39:    */   {
/*  40: 64 */     close();
/*  41: 65 */     if (this.it.hasNext()) {
/*  42: 66 */       this.in = ((ByteSource)this.it.next()).openStream();
/*  43:    */     }
/*  44:    */   }
/*  45:    */   
/*  46:    */   public int available()
/*  47:    */     throws IOException
/*  48:    */   {
/*  49: 71 */     if (this.in == null) {
/*  50: 72 */       return 0;
/*  51:    */     }
/*  52: 74 */     return this.in.available();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean markSupported()
/*  56:    */   {
/*  57: 78 */     return false;
/*  58:    */   }
/*  59:    */   
/*  60:    */   public int read()
/*  61:    */     throws IOException
/*  62:    */   {
/*  63: 82 */     if (this.in == null) {
/*  64: 83 */       return -1;
/*  65:    */     }
/*  66: 85 */     int result = this.in.read();
/*  67: 86 */     if (result == -1)
/*  68:    */     {
/*  69: 87 */       advance();
/*  70: 88 */       return read();
/*  71:    */     }
/*  72: 90 */     return result;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public int read(@Nullable byte[] b, int off, int len)
/*  76:    */     throws IOException
/*  77:    */   {
/*  78: 94 */     if (this.in == null) {
/*  79: 95 */       return -1;
/*  80:    */     }
/*  81: 97 */     int result = this.in.read(b, off, len);
/*  82: 98 */     if (result == -1)
/*  83:    */     {
/*  84: 99 */       advance();
/*  85:100 */       return read(b, off, len);
/*  86:    */     }
/*  87:102 */     return result;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public long skip(long n)
/*  91:    */     throws IOException
/*  92:    */   {
/*  93:106 */     if ((this.in == null) || (n <= 0L)) {
/*  94:107 */       return 0L;
/*  95:    */     }
/*  96:109 */     long result = this.in.skip(n);
/*  97:110 */     if (result != 0L) {
/*  98:111 */       return result;
/*  99:    */     }
/* 100:113 */     if (read() == -1) {
/* 101:114 */       return 0L;
/* 102:    */     }
/* 103:116 */     return 1L + this.in.skip(n - 1L);
/* 104:    */   }
/* 105:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.MultiInputStream
 * JD-Core Version:    0.7.0.1
 */