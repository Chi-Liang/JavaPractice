/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.BufferedOutputStream;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.InputStream;
/*   7:    */ import java.io.OutputStream;
/*   8:    */ import java.io.OutputStreamWriter;
/*   9:    */ import java.io.Writer;
/*  10:    */ import java.nio.charset.Charset;
/*  11:    */ 
/*  12:    */ public abstract class ByteSink
/*  13:    */ {
/*  14:    */   public CharSink asCharSink(Charset charset)
/*  15:    */   {
/*  16: 59 */     return new AsCharSink(charset, null);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public abstract OutputStream openStream()
/*  20:    */     throws IOException;
/*  21:    */   
/*  22:    */   public OutputStream openBufferedStream()
/*  23:    */     throws IOException
/*  24:    */   {
/*  25: 85 */     OutputStream out = openStream();
/*  26: 86 */     return (out instanceof BufferedOutputStream) ? (BufferedOutputStream)out : new BufferedOutputStream(out);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void write(byte[] bytes)
/*  30:    */     throws IOException
/*  31:    */   {
/*  32: 97 */     Preconditions.checkNotNull(bytes);
/*  33:    */     
/*  34: 99 */     Closer closer = Closer.create();
/*  35:    */     try
/*  36:    */     {
/*  37:101 */       OutputStream out = (OutputStream)closer.register(openStream());
/*  38:102 */       out.write(bytes);
/*  39:103 */       out.flush();
/*  40:    */     }
/*  41:    */     catch (Throwable e)
/*  42:    */     {
/*  43:105 */       throw closer.rethrow(e);
/*  44:    */     }
/*  45:    */     finally
/*  46:    */     {
/*  47:107 */       closer.close();
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public long writeFrom(InputStream input)
/*  52:    */     throws IOException
/*  53:    */   {
/*  54:119 */     Preconditions.checkNotNull(input);
/*  55:    */     
/*  56:121 */     Closer closer = Closer.create();
/*  57:    */     try
/*  58:    */     {
/*  59:123 */       OutputStream out = (OutputStream)closer.register(openStream());
/*  60:124 */       long written = ByteStreams.copy(input, out);
/*  61:125 */       out.flush();
/*  62:126 */       return written;
/*  63:    */     }
/*  64:    */     catch (Throwable e)
/*  65:    */     {
/*  66:128 */       throw closer.rethrow(e);
/*  67:    */     }
/*  68:    */     finally
/*  69:    */     {
/*  70:130 */       closer.close();
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   private final class AsCharSink
/*  75:    */     extends CharSink
/*  76:    */   {
/*  77:    */     private final Charset charset;
/*  78:    */     
/*  79:    */     private AsCharSink(Charset charset)
/*  80:    */     {
/*  81:143 */       this.charset = ((Charset)Preconditions.checkNotNull(charset));
/*  82:    */     }
/*  83:    */     
/*  84:    */     public Writer openStream()
/*  85:    */       throws IOException
/*  86:    */     {
/*  87:148 */       return new OutputStreamWriter(ByteSink.this.openStream(), this.charset);
/*  88:    */     }
/*  89:    */     
/*  90:    */     public String toString()
/*  91:    */     {
/*  92:153 */       return ByteSink.this.toString() + ".asCharSink(" + this.charset + ")";
/*  93:    */     }
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.ByteSink
 * JD-Core Version:    0.7.0.1
 */