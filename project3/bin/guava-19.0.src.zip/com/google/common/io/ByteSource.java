/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Ascii;
/*   5:    */ import com.google.common.base.Optional;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.collect.ImmutableList;
/*   8:    */ import com.google.common.hash.Funnels;
/*   9:    */ import com.google.common.hash.HashCode;
/*  10:    */ import com.google.common.hash.HashFunction;
/*  11:    */ import com.google.common.hash.Hasher;
/*  12:    */ import java.io.BufferedInputStream;
/*  13:    */ import java.io.ByteArrayInputStream;
/*  14:    */ import java.io.IOException;
/*  15:    */ import java.io.InputStream;
/*  16:    */ import java.io.InputStreamReader;
/*  17:    */ import java.io.OutputStream;
/*  18:    */ import java.io.Reader;
/*  19:    */ import java.nio.charset.Charset;
/*  20:    */ import java.util.Arrays;
/*  21:    */ import java.util.Iterator;
/*  22:    */ 
/*  23:    */ public abstract class ByteSource
/*  24:    */ {
/*  25:    */   public CharSource asCharSource(Charset charset)
/*  26:    */   {
/*  27: 74 */     return new AsCharSource(charset, null);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public abstract InputStream openStream()
/*  31:    */     throws IOException;
/*  32:    */   
/*  33:    */   public InputStream openBufferedStream()
/*  34:    */     throws IOException
/*  35:    */   {
/*  36:100 */     InputStream in = openStream();
/*  37:101 */     return (in instanceof BufferedInputStream) ? (BufferedInputStream)in : new BufferedInputStream(in);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public ByteSource slice(long offset, long length)
/*  41:    */   {
/*  42:116 */     return new SlicedByteSource(offset, length);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean isEmpty()
/*  46:    */     throws IOException
/*  47:    */   {
/*  48:133 */     Optional<Long> sizeIfKnown = sizeIfKnown();
/*  49:134 */     if ((sizeIfKnown.isPresent()) && (((Long)sizeIfKnown.get()).longValue() == 0L)) {
/*  50:135 */       return true;
/*  51:    */     }
/*  52:137 */     Closer closer = Closer.create();
/*  53:    */     try
/*  54:    */     {
/*  55:139 */       InputStream in = (InputStream)closer.register(openStream());
/*  56:140 */       return in.read() == -1;
/*  57:    */     }
/*  58:    */     catch (Throwable e)
/*  59:    */     {
/*  60:142 */       throw closer.rethrow(e);
/*  61:    */     }
/*  62:    */     finally
/*  63:    */     {
/*  64:144 */       closer.close();
/*  65:    */     }
/*  66:    */   }
/*  67:    */   
/*  68:    */   @Beta
/*  69:    */   public Optional<Long> sizeIfKnown()
/*  70:    */   {
/*  71:164 */     return Optional.absent();
/*  72:    */   }
/*  73:    */   
/*  74:    */   public long size()
/*  75:    */     throws IOException
/*  76:    */   {
/*  77:187 */     Optional<Long> sizeIfKnown = sizeIfKnown();
/*  78:188 */     if (sizeIfKnown.isPresent()) {
/*  79:189 */       return ((Long)sizeIfKnown.get()).longValue();
/*  80:    */     }
/*  81:192 */     Closer closer = Closer.create();
/*  82:    */     long l;
/*  83:    */     try
/*  84:    */     {
/*  85:194 */       InputStream in = (InputStream)closer.register(openStream());
/*  86:195 */       return countBySkipping(in);
/*  87:    */     }
/*  88:    */     catch (IOException e) {}finally
/*  89:    */     {
/*  90:199 */       closer.close();
/*  91:    */     }
/*  92:202 */     closer = Closer.create();
/*  93:    */     try
/*  94:    */     {
/*  95:204 */       InputStream in = (InputStream)closer.register(openStream());
/*  96:205 */       return countByReading(in);
/*  97:    */     }
/*  98:    */     catch (Throwable e)
/*  99:    */     {
/* 100:207 */       throw closer.rethrow(e);
/* 101:    */     }
/* 102:    */     finally
/* 103:    */     {
/* 104:209 */       closer.close();
/* 105:    */     }
/* 106:    */   }
/* 107:    */   
/* 108:    */   private long countBySkipping(InputStream in)
/* 109:    */     throws IOException
/* 110:    */   {
/* 111:218 */     long count = 0L;
/* 112:    */     long skipped;
/* 113:220 */     while ((skipped = ByteStreams.skipUpTo(in, 2147483647L)) > 0L) {
/* 114:221 */       count += skipped;
/* 115:    */     }
/* 116:223 */     return count;
/* 117:    */   }
/* 118:    */   
/* 119:    */   private long countByReading(InputStream in)
/* 120:    */     throws IOException
/* 121:    */   {
/* 122:227 */     long count = 0L;
/* 123:    */     long read;
/* 124:229 */     while ((read = in.read(ByteStreams.skipBuffer)) != -1L) {
/* 125:230 */       count += read;
/* 126:    */     }
/* 127:232 */     return count;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public long copyTo(OutputStream output)
/* 131:    */     throws IOException
/* 132:    */   {
/* 133:243 */     Preconditions.checkNotNull(output);
/* 134:    */     
/* 135:245 */     Closer closer = Closer.create();
/* 136:    */     try
/* 137:    */     {
/* 138:247 */       InputStream in = (InputStream)closer.register(openStream());
/* 139:248 */       return ByteStreams.copy(in, output);
/* 140:    */     }
/* 141:    */     catch (Throwable e)
/* 142:    */     {
/* 143:250 */       throw closer.rethrow(e);
/* 144:    */     }
/* 145:    */     finally
/* 146:    */     {
/* 147:252 */       closer.close();
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public long copyTo(ByteSink sink)
/* 152:    */     throws IOException
/* 153:    */   {
/* 154:263 */     Preconditions.checkNotNull(sink);
/* 155:    */     
/* 156:265 */     Closer closer = Closer.create();
/* 157:    */     try
/* 158:    */     {
/* 159:267 */       InputStream in = (InputStream)closer.register(openStream());
/* 160:268 */       OutputStream out = (OutputStream)closer.register(sink.openStream());
/* 161:269 */       return ByteStreams.copy(in, out);
/* 162:    */     }
/* 163:    */     catch (Throwable e)
/* 164:    */     {
/* 165:271 */       throw closer.rethrow(e);
/* 166:    */     }
/* 167:    */     finally
/* 168:    */     {
/* 169:273 */       closer.close();
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   public byte[] read()
/* 174:    */     throws IOException
/* 175:    */   {
/* 176:283 */     Closer closer = Closer.create();
/* 177:    */     try
/* 178:    */     {
/* 179:285 */       InputStream in = (InputStream)closer.register(openStream());
/* 180:286 */       return ByteStreams.toByteArray(in);
/* 181:    */     }
/* 182:    */     catch (Throwable e)
/* 183:    */     {
/* 184:288 */       throw closer.rethrow(e);
/* 185:    */     }
/* 186:    */     finally
/* 187:    */     {
/* 188:290 */       closer.close();
/* 189:    */     }
/* 190:    */   }
/* 191:    */   
/* 192:    */   @Beta
/* 193:    */   public <T> T read(ByteProcessor<T> processor)
/* 194:    */     throws IOException
/* 195:    */   {
/* 196:305 */     Preconditions.checkNotNull(processor);
/* 197:    */     
/* 198:307 */     Closer closer = Closer.create();
/* 199:    */     try
/* 200:    */     {
/* 201:309 */       InputStream in = (InputStream)closer.register(openStream());
/* 202:310 */       return ByteStreams.readBytes(in, processor);
/* 203:    */     }
/* 204:    */     catch (Throwable e)
/* 205:    */     {
/* 206:312 */       throw closer.rethrow(e);
/* 207:    */     }
/* 208:    */     finally
/* 209:    */     {
/* 210:314 */       closer.close();
/* 211:    */     }
/* 212:    */   }
/* 213:    */   
/* 214:    */   public HashCode hash(HashFunction hashFunction)
/* 215:    */     throws IOException
/* 216:    */   {
/* 217:324 */     Hasher hasher = hashFunction.newHasher();
/* 218:325 */     copyTo(Funnels.asOutputStream(hasher));
/* 219:326 */     return hasher.hash();
/* 220:    */   }
/* 221:    */   
/* 222:    */   /* Error */
/* 223:    */   public boolean contentEquals(ByteSource other)
/* 224:    */     throws IOException
/* 225:    */   {
/* 226:    */     // Byte code:
/* 227:    */     //   0: aload_1
/* 228:    */     //   1: invokestatic 34	com/google/common/base/Preconditions:checkNotNull	(Ljava/lang/Object;)Ljava/lang/Object;
/* 229:    */     //   4: pop
/* 230:    */     //   5: sipush 8192
/* 231:    */     //   8: newarray byte
/* 232:    */     //   10: astore_2
/* 233:    */     //   11: sipush 8192
/* 234:    */     //   14: newarray byte
/* 235:    */     //   16: astore_3
/* 236:    */     //   17: invokestatic 16	com/google/common/io/Closer:create	()Lcom/google/common/io/Closer;
/* 237:    */     //   20: astore 4
/* 238:    */     //   22: aload 4
/* 239:    */     //   24: aload_0
/* 240:    */     //   25: invokevirtual 6	com/google/common/io/ByteSource:openStream	()Ljava/io/InputStream;
/* 241:    */     //   28: invokevirtual 17	com/google/common/io/Closer:register	(Ljava/io/Closeable;)Ljava/io/Closeable;
/* 242:    */     //   31: checkcast 18	java/io/InputStream
/* 243:    */     //   34: astore 5
/* 244:    */     //   36: aload 4
/* 245:    */     //   38: aload_1
/* 246:    */     //   39: invokevirtual 6	com/google/common/io/ByteSource:openStream	()Ljava/io/InputStream;
/* 247:    */     //   42: invokevirtual 17	com/google/common/io/Closer:register	(Ljava/io/Closeable;)Ljava/io/Closeable;
/* 248:    */     //   45: checkcast 18	java/io/InputStream
/* 249:    */     //   48: astore 6
/* 250:    */     //   50: aload 5
/* 251:    */     //   52: aload_2
/* 252:    */     //   53: iconst_0
/* 253:    */     //   54: sipush 8192
/* 254:    */     //   57: invokestatic 44	com/google/common/io/ByteStreams:read	(Ljava/io/InputStream;[BII)I
/* 255:    */     //   60: istore 7
/* 256:    */     //   62: aload 6
/* 257:    */     //   64: aload_3
/* 258:    */     //   65: iconst_0
/* 259:    */     //   66: sipush 8192
/* 260:    */     //   69: invokestatic 44	com/google/common/io/ByteStreams:read	(Ljava/io/InputStream;[BII)I
/* 261:    */     //   72: istore 8
/* 262:    */     //   74: iload 7
/* 263:    */     //   76: iload 8
/* 264:    */     //   78: if_icmpne +11 -> 89
/* 265:    */     //   81: aload_2
/* 266:    */     //   82: aload_3
/* 267:    */     //   83: invokestatic 45	java/util/Arrays:equals	([B[B)Z
/* 268:    */     //   86: ifne +14 -> 100
/* 269:    */     //   89: iconst_0
/* 270:    */     //   90: istore 9
/* 271:    */     //   92: aload 4
/* 272:    */     //   94: invokevirtual 20	com/google/common/io/Closer:close	()V
/* 273:    */     //   97: iload 9
/* 274:    */     //   99: ireturn
/* 275:    */     //   100: iload 7
/* 276:    */     //   102: sipush 8192
/* 277:    */     //   105: if_icmpeq +14 -> 119
/* 278:    */     //   108: iconst_1
/* 279:    */     //   109: istore 9
/* 280:    */     //   111: aload 4
/* 281:    */     //   113: invokevirtual 20	com/google/common/io/Closer:close	()V
/* 282:    */     //   116: iload 9
/* 283:    */     //   118: ireturn
/* 284:    */     //   119: goto -69 -> 50
/* 285:    */     //   122: astore 5
/* 286:    */     //   124: aload 4
/* 287:    */     //   126: aload 5
/* 288:    */     //   128: invokevirtual 22	com/google/common/io/Closer:rethrow	(Ljava/lang/Throwable;)Ljava/lang/RuntimeException;
/* 289:    */     //   131: athrow
/* 290:    */     //   132: astore 10
/* 291:    */     //   134: aload 4
/* 292:    */     //   136: invokevirtual 20	com/google/common/io/Closer:close	()V
/* 293:    */     //   139: aload 10
/* 294:    */     //   141: athrow
/* 295:    */     // Line number table:
/* 296:    */     //   Java source line #337	-> byte code offset #0
/* 297:    */     //   Java source line #339	-> byte code offset #5
/* 298:    */     //   Java source line #340	-> byte code offset #11
/* 299:    */     //   Java source line #342	-> byte code offset #17
/* 300:    */     //   Java source line #344	-> byte code offset #22
/* 301:    */     //   Java source line #345	-> byte code offset #36
/* 302:    */     //   Java source line #347	-> byte code offset #50
/* 303:    */     //   Java source line #348	-> byte code offset #62
/* 304:    */     //   Java source line #349	-> byte code offset #74
/* 305:    */     //   Java source line #350	-> byte code offset #89
/* 306:    */     //   Java source line #358	-> byte code offset #92
/* 307:    */     //   Java source line #351	-> byte code offset #100
/* 308:    */     //   Java source line #352	-> byte code offset #108
/* 309:    */     //   Java source line #358	-> byte code offset #111
/* 310:    */     //   Java source line #354	-> byte code offset #119
/* 311:    */     //   Java source line #355	-> byte code offset #122
/* 312:    */     //   Java source line #356	-> byte code offset #124
/* 313:    */     //   Java source line #358	-> byte code offset #132
/* 314:    */     // Local variable table:
/* 315:    */     //   start	length	slot	name	signature
/* 316:    */     //   0	142	0	this	ByteSource
/* 317:    */     //   0	142	1	other	ByteSource
/* 318:    */     //   10	72	2	buf1	byte[]
/* 319:    */     //   16	67	3	buf2	byte[]
/* 320:    */     //   20	115	4	closer	Closer
/* 321:    */     //   34	17	5	in1	InputStream
/* 322:    */     //   122	5	5	e	Throwable
/* 323:    */     //   48	15	6	in2	InputStream
/* 324:    */     //   60	41	7	read1	int
/* 325:    */     //   72	5	8	read2	int
/* 326:    */     //   90	27	9	bool	boolean
/* 327:    */     //   132	8	10	localObject	Object
/* 328:    */     // Exception table:
/* 329:    */     //   from	to	target	type
/* 330:    */     //   22	92	122	java/lang/Throwable
/* 331:    */     //   100	111	122	java/lang/Throwable
/* 332:    */     //   119	122	122	java/lang/Throwable
/* 333:    */     //   22	92	132	finally
/* 334:    */     //   100	111	132	finally
/* 335:    */     //   119	134	132	finally
/* 336:    */   }
/* 337:    */   
/* 338:    */   public static ByteSource concat(Iterable<? extends ByteSource> sources)
/* 339:    */   {
/* 340:374 */     return new ConcatenatedByteSource(sources);
/* 341:    */   }
/* 342:    */   
/* 343:    */   public static ByteSource concat(Iterator<? extends ByteSource> sources)
/* 344:    */   {
/* 345:396 */     return concat(ImmutableList.copyOf(sources));
/* 346:    */   }
/* 347:    */   
/* 348:    */   public static ByteSource concat(ByteSource... sources)
/* 349:    */   {
/* 350:412 */     return concat(ImmutableList.copyOf(sources));
/* 351:    */   }
/* 352:    */   
/* 353:    */   public static ByteSource wrap(byte[] b)
/* 354:    */   {
/* 355:422 */     return new ByteArrayByteSource(b);
/* 356:    */   }
/* 357:    */   
/* 358:    */   public static ByteSource empty()
/* 359:    */   {
/* 360:431 */     return EmptyByteSource.INSTANCE;
/* 361:    */   }
/* 362:    */   
/* 363:    */   private final class AsCharSource
/* 364:    */     extends CharSource
/* 365:    */   {
/* 366:    */     private final Charset charset;
/* 367:    */     
/* 368:    */     private AsCharSource(Charset charset)
/* 369:    */     {
/* 370:443 */       this.charset = ((Charset)Preconditions.checkNotNull(charset));
/* 371:    */     }
/* 372:    */     
/* 373:    */     public Reader openStream()
/* 374:    */       throws IOException
/* 375:    */     {
/* 376:448 */       return new InputStreamReader(ByteSource.this.openStream(), this.charset);
/* 377:    */     }
/* 378:    */     
/* 379:    */     public String toString()
/* 380:    */     {
/* 381:453 */       return ByteSource.this.toString() + ".asCharSource(" + this.charset + ")";
/* 382:    */     }
/* 383:    */   }
/* 384:    */   
/* 385:    */   private final class SlicedByteSource
/* 386:    */     extends ByteSource
/* 387:    */   {
/* 388:    */     final long offset;
/* 389:    */     final long length;
/* 390:    */     
/* 391:    */     SlicedByteSource(long offset, long length)
/* 392:    */     {
/* 393:466 */       Preconditions.checkArgument(offset >= 0L, "offset (%s) may not be negative", new Object[] { Long.valueOf(offset) });
/* 394:467 */       Preconditions.checkArgument(length >= 0L, "length (%s) may not be negative", new Object[] { Long.valueOf(length) });
/* 395:468 */       this.offset = offset;
/* 396:469 */       this.length = length;
/* 397:    */     }
/* 398:    */     
/* 399:    */     public InputStream openStream()
/* 400:    */       throws IOException
/* 401:    */     {
/* 402:474 */       return sliceStream(ByteSource.this.openStream());
/* 403:    */     }
/* 404:    */     
/* 405:    */     public InputStream openBufferedStream()
/* 406:    */       throws IOException
/* 407:    */     {
/* 408:479 */       return sliceStream(ByteSource.this.openBufferedStream());
/* 409:    */     }
/* 410:    */     
/* 411:    */     private InputStream sliceStream(InputStream in)
/* 412:    */       throws IOException
/* 413:    */     {
/* 414:483 */       if (this.offset > 0L)
/* 415:    */       {
/* 416:    */         long skipped;
/* 417:    */         try
/* 418:    */         {
/* 419:486 */           skipped = ByteStreams.skipUpTo(in, this.offset);
/* 420:    */         }
/* 421:    */         catch (Throwable e)
/* 422:    */         {
/* 423:488 */           Closer closer = Closer.create();
/* 424:489 */           closer.register(in);
/* 425:    */           try
/* 426:    */           {
/* 427:491 */             throw closer.rethrow(e);
/* 428:    */           }
/* 429:    */           finally
/* 430:    */           {
/* 431:493 */             closer.close();
/* 432:    */           }
/* 433:    */         }
/* 434:497 */         if (skipped < this.offset)
/* 435:    */         {
/* 436:499 */           in.close();
/* 437:500 */           return new ByteArrayInputStream(new byte[0]);
/* 438:    */         }
/* 439:    */       }
/* 440:503 */       return ByteStreams.limit(in, this.length);
/* 441:    */     }
/* 442:    */     
/* 443:    */     public ByteSource slice(long offset, long length)
/* 444:    */     {
/* 445:508 */       Preconditions.checkArgument(offset >= 0L, "offset (%s) may not be negative", new Object[] { Long.valueOf(offset) });
/* 446:509 */       Preconditions.checkArgument(length >= 0L, "length (%s) may not be negative", new Object[] { Long.valueOf(length) });
/* 447:510 */       long maxLength = this.length - offset;
/* 448:511 */       return ByteSource.this.slice(this.offset + offset, Math.min(length, maxLength));
/* 449:    */     }
/* 450:    */     
/* 451:    */     public boolean isEmpty()
/* 452:    */       throws IOException
/* 453:    */     {
/* 454:516 */       return (this.length == 0L) || (super.isEmpty());
/* 455:    */     }
/* 456:    */     
/* 457:    */     public Optional<Long> sizeIfKnown()
/* 458:    */     {
/* 459:521 */       Optional<Long> optionalUnslicedSize = ByteSource.this.sizeIfKnown();
/* 460:522 */       if (optionalUnslicedSize.isPresent())
/* 461:    */       {
/* 462:523 */         long unslicedSize = ((Long)optionalUnslicedSize.get()).longValue();
/* 463:524 */         long off = Math.min(this.offset, unslicedSize);
/* 464:525 */         return Optional.of(Long.valueOf(Math.min(this.length, unslicedSize - off)));
/* 465:    */       }
/* 466:527 */       return Optional.absent();
/* 467:    */     }
/* 468:    */     
/* 469:    */     public String toString()
/* 470:    */     {
/* 471:532 */       return ByteSource.this.toString() + ".slice(" + this.offset + ", " + this.length + ")";
/* 472:    */     }
/* 473:    */   }
/* 474:    */   
/* 475:    */   private static class ByteArrayByteSource
/* 476:    */     extends ByteSource
/* 477:    */   {
/* 478:    */     final byte[] bytes;
/* 479:    */     final int offset;
/* 480:    */     final int length;
/* 481:    */     
/* 482:    */     ByteArrayByteSource(byte[] bytes)
/* 483:    */     {
/* 484:543 */       this(bytes, 0, bytes.length);
/* 485:    */     }
/* 486:    */     
/* 487:    */     ByteArrayByteSource(byte[] bytes, int offset, int length)
/* 488:    */     {
/* 489:548 */       this.bytes = bytes;
/* 490:549 */       this.offset = offset;
/* 491:550 */       this.length = length;
/* 492:    */     }
/* 493:    */     
/* 494:    */     public InputStream openStream()
/* 495:    */     {
/* 496:555 */       return new ByteArrayInputStream(this.bytes, this.offset, this.length);
/* 497:    */     }
/* 498:    */     
/* 499:    */     public InputStream openBufferedStream()
/* 500:    */       throws IOException
/* 501:    */     {
/* 502:560 */       return openStream();
/* 503:    */     }
/* 504:    */     
/* 505:    */     public boolean isEmpty()
/* 506:    */     {
/* 507:565 */       return this.length == 0;
/* 508:    */     }
/* 509:    */     
/* 510:    */     public long size()
/* 511:    */     {
/* 512:570 */       return this.length;
/* 513:    */     }
/* 514:    */     
/* 515:    */     public Optional<Long> sizeIfKnown()
/* 516:    */     {
/* 517:575 */       return Optional.of(Long.valueOf(this.length));
/* 518:    */     }
/* 519:    */     
/* 520:    */     public byte[] read()
/* 521:    */     {
/* 522:580 */       return Arrays.copyOfRange(this.bytes, this.offset, this.offset + this.length);
/* 523:    */     }
/* 524:    */     
/* 525:    */     public long copyTo(OutputStream output)
/* 526:    */       throws IOException
/* 527:    */     {
/* 528:585 */       output.write(this.bytes, this.offset, this.length);
/* 529:586 */       return this.length;
/* 530:    */     }
/* 531:    */     
/* 532:    */     public <T> T read(ByteProcessor<T> processor)
/* 533:    */       throws IOException
/* 534:    */     {
/* 535:591 */       processor.processBytes(this.bytes, this.offset, this.length);
/* 536:592 */       return processor.getResult();
/* 537:    */     }
/* 538:    */     
/* 539:    */     public HashCode hash(HashFunction hashFunction)
/* 540:    */       throws IOException
/* 541:    */     {
/* 542:597 */       return hashFunction.hashBytes(this.bytes, this.offset, this.length);
/* 543:    */     }
/* 544:    */     
/* 545:    */     public ByteSource slice(long offset, long length)
/* 546:    */     {
/* 547:602 */       Preconditions.checkArgument(offset >= 0L, "offset (%s) may not be negative", new Object[] { Long.valueOf(offset) });
/* 548:603 */       Preconditions.checkArgument(length >= 0L, "length (%s) may not be negative", new Object[] { Long.valueOf(length) });
/* 549:    */       
/* 550:605 */       offset = Math.min(offset, this.length);
/* 551:606 */       length = Math.min(length, this.length - offset);
/* 552:607 */       int newOffset = this.offset + (int)offset;
/* 553:608 */       return new ByteArrayByteSource(this.bytes, newOffset, (int)length);
/* 554:    */     }
/* 555:    */     
/* 556:    */     public String toString()
/* 557:    */     {
/* 558:613 */       return "ByteSource.wrap(" + Ascii.truncate(BaseEncoding.base16().encode(this.bytes, this.offset, this.length), 30, "...") + ")";
/* 559:    */     }
/* 560:    */   }
/* 561:    */   
/* 562:    */   private static final class EmptyByteSource
/* 563:    */     extends ByteSource.ByteArrayByteSource
/* 564:    */   {
/* 565:620 */     static final EmptyByteSource INSTANCE = new EmptyByteSource();
/* 566:    */     
/* 567:    */     EmptyByteSource()
/* 568:    */     {
/* 569:623 */       super();
/* 570:    */     }
/* 571:    */     
/* 572:    */     public CharSource asCharSource(Charset charset)
/* 573:    */     {
/* 574:628 */       Preconditions.checkNotNull(charset);
/* 575:629 */       return CharSource.empty();
/* 576:    */     }
/* 577:    */     
/* 578:    */     public byte[] read()
/* 579:    */     {
/* 580:634 */       return this.bytes;
/* 581:    */     }
/* 582:    */     
/* 583:    */     public String toString()
/* 584:    */     {
/* 585:639 */       return "ByteSource.empty()";
/* 586:    */     }
/* 587:    */   }
/* 588:    */   
/* 589:    */   private static final class ConcatenatedByteSource
/* 590:    */     extends ByteSource
/* 591:    */   {
/* 592:    */     final Iterable<? extends ByteSource> sources;
/* 593:    */     
/* 594:    */     ConcatenatedByteSource(Iterable<? extends ByteSource> sources)
/* 595:    */     {
/* 596:648 */       this.sources = ((Iterable)Preconditions.checkNotNull(sources));
/* 597:    */     }
/* 598:    */     
/* 599:    */     public InputStream openStream()
/* 600:    */       throws IOException
/* 601:    */     {
/* 602:653 */       return new MultiInputStream(this.sources.iterator());
/* 603:    */     }
/* 604:    */     
/* 605:    */     public boolean isEmpty()
/* 606:    */       throws IOException
/* 607:    */     {
/* 608:658 */       for (ByteSource source : this.sources) {
/* 609:659 */         if (!source.isEmpty()) {
/* 610:660 */           return false;
/* 611:    */         }
/* 612:    */       }
/* 613:663 */       return true;
/* 614:    */     }
/* 615:    */     
/* 616:    */     public Optional<Long> sizeIfKnown()
/* 617:    */     {
/* 618:668 */       long result = 0L;
/* 619:669 */       for (ByteSource source : this.sources)
/* 620:    */       {
/* 621:670 */         Optional<Long> sizeIfKnown = source.sizeIfKnown();
/* 622:671 */         if (!sizeIfKnown.isPresent()) {
/* 623:672 */           return Optional.absent();
/* 624:    */         }
/* 625:674 */         result += ((Long)sizeIfKnown.get()).longValue();
/* 626:    */       }
/* 627:676 */       return Optional.of(Long.valueOf(result));
/* 628:    */     }
/* 629:    */     
/* 630:    */     public long size()
/* 631:    */       throws IOException
/* 632:    */     {
/* 633:681 */       long result = 0L;
/* 634:682 */       for (ByteSource source : this.sources) {
/* 635:683 */         result += source.size();
/* 636:    */       }
/* 637:685 */       return result;
/* 638:    */     }
/* 639:    */     
/* 640:    */     public String toString()
/* 641:    */     {
/* 642:690 */       return "ByteSource.concat(" + this.sources + ")";
/* 643:    */     }
/* 644:    */   }
/* 645:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.ByteSource
 * JD-Core Version:    0.7.0.1
 */