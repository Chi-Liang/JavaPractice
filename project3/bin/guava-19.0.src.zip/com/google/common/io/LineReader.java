/*  1:   */ package com.google.common.io;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.IOException;
/*  6:   */ import java.io.Reader;
/*  7:   */ import java.nio.CharBuffer;
/*  8:   */ import java.util.LinkedList;
/*  9:   */ import java.util.Queue;
/* 10:   */ 
/* 11:   */ @Beta
/* 12:   */ public final class LineReader
/* 13:   */ {
/* 14:   */   private final Readable readable;
/* 15:   */   private final Reader reader;
/* 16:41 */   private final char[] buf = new char[4096];
/* 17:42 */   private final CharBuffer cbuf = CharBuffer.wrap(this.buf);
/* 18:44 */   private final Queue<String> lines = new LinkedList();
/* 19:45 */   private final LineBuffer lineBuf = new LineBuffer()
/* 20:   */   {
/* 21:   */     protected void handleLine(String line, String end)
/* 22:   */     {
/* 23:47 */       LineReader.this.lines.add(line);
/* 24:   */     }
/* 25:   */   };
/* 26:   */   
/* 27:   */   public LineReader(Readable readable)
/* 28:   */   {
/* 29:56 */     this.readable = ((Readable)Preconditions.checkNotNull(readable));
/* 30:57 */     this.reader = ((readable instanceof Reader) ? (Reader)readable : null);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public String readLine()
/* 34:   */     throws IOException
/* 35:   */   {
/* 36:72 */     while (this.lines.peek() == null)
/* 37:   */     {
/* 38:73 */       this.cbuf.clear();
/* 39:   */       
/* 40:   */ 
/* 41:76 */       int read = this.reader != null ? this.reader.read(this.buf, 0, this.buf.length) : this.readable.read(this.cbuf);
/* 42:79 */       if (read == -1)
/* 43:   */       {
/* 44:80 */         this.lineBuf.finish();
/* 45:81 */         break;
/* 46:   */       }
/* 47:83 */       this.lineBuf.add(this.buf, 0, read);
/* 48:   */     }
/* 49:85 */     return (String)this.lines.poll();
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.LineReader
 * JD-Core Version:    0.7.0.1
 */