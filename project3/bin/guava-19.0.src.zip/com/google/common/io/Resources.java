/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.MoreObjects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.Lists;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.InputStream;
/*   9:    */ import java.io.OutputStream;
/*  10:    */ import java.net.URL;
/*  11:    */ import java.nio.charset.Charset;
/*  12:    */ import java.util.List;
/*  13:    */ 
/*  14:    */ @Beta
/*  15:    */ public final class Resources
/*  16:    */ {
/*  17:    */   public static ByteSource asByteSource(URL url)
/*  18:    */   {
/*  19: 56 */     return new UrlByteSource(url, null);
/*  20:    */   }
/*  21:    */   
/*  22:    */   private static final class UrlByteSource
/*  23:    */     extends ByteSource
/*  24:    */   {
/*  25:    */     private final URL url;
/*  26:    */     
/*  27:    */     private UrlByteSource(URL url)
/*  28:    */     {
/*  29: 67 */       this.url = ((URL)Preconditions.checkNotNull(url));
/*  30:    */     }
/*  31:    */     
/*  32:    */     public InputStream openStream()
/*  33:    */       throws IOException
/*  34:    */     {
/*  35: 72 */       return this.url.openStream();
/*  36:    */     }
/*  37:    */     
/*  38:    */     public String toString()
/*  39:    */     {
/*  40: 77 */       return "Resources.asByteSource(" + this.url + ")";
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static CharSource asCharSource(URL url, Charset charset)
/*  45:    */   {
/*  46: 88 */     return asByteSource(url).asCharSource(charset);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static byte[] toByteArray(URL url)
/*  50:    */     throws IOException
/*  51:    */   {
/*  52: 99 */     return asByteSource(url).read();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static String toString(URL url, Charset charset)
/*  56:    */     throws IOException
/*  57:    */   {
/*  58:113 */     return asCharSource(url, charset).read();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <T> T readLines(URL url, Charset charset, LineProcessor<T> callback)
/*  62:    */     throws IOException
/*  63:    */   {
/*  64:129 */     return asCharSource(url, charset).readLines(callback);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static List<String> readLines(URL url, Charset charset)
/*  68:    */     throws IOException
/*  69:    */   {
/*  70:151 */     (List)readLines(url, charset, new LineProcessor()
/*  71:    */     {
/*  72:152 */       final List<String> result = Lists.newArrayList();
/*  73:    */       
/*  74:    */       public boolean processLine(String line)
/*  75:    */       {
/*  76:156 */         this.result.add(line);
/*  77:157 */         return true;
/*  78:    */       }
/*  79:    */       
/*  80:    */       public List<String> getResult()
/*  81:    */       {
/*  82:162 */         return this.result;
/*  83:    */       }
/*  84:    */     });
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static void copy(URL from, OutputStream to)
/*  88:    */     throws IOException
/*  89:    */   {
/*  90:175 */     asByteSource(from).copyTo(to);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static URL getResource(String resourceName)
/*  94:    */   {
/*  95:193 */     ClassLoader loader = (ClassLoader)MoreObjects.firstNonNull(Thread.currentThread().getContextClassLoader(), Resources.class.getClassLoader());
/*  96:    */     
/*  97:    */ 
/*  98:196 */     URL url = loader.getResource(resourceName);
/*  99:197 */     Preconditions.checkArgument(url != null, "resource %s not found.", new Object[] { resourceName });
/* 100:198 */     return url;
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static URL getResource(Class<?> contextClass, String resourceName)
/* 104:    */   {
/* 105:208 */     URL url = contextClass.getResource(resourceName);
/* 106:209 */     Preconditions.checkArgument(url != null, "resource %s relative to %s not found.", new Object[] { resourceName, contextClass.getName() });
/* 107:    */     
/* 108:211 */     return url;
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.Resources
 * JD-Core Version:    0.7.0.1
 */