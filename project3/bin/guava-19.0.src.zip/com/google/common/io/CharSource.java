/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Ascii;
/*   5:    */ import com.google.common.base.Optional;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Splitter;
/*   8:    */ import com.google.common.collect.AbstractIterator;
/*   9:    */ import com.google.common.collect.ImmutableList;
/*  10:    */ import com.google.common.collect.Lists;
/*  11:    */ import java.io.BufferedReader;
/*  12:    */ import java.io.IOException;
/*  13:    */ import java.io.Reader;
/*  14:    */ import java.io.Writer;
/*  15:    */ import java.util.Iterator;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.regex.Pattern;
/*  18:    */ import javax.annotation.Nullable;
/*  19:    */ 
/*  20:    */ public abstract class CharSource
/*  21:    */ {
/*  22:    */   public abstract Reader openStream()
/*  23:    */     throws IOException;
/*  24:    */   
/*  25:    */   public BufferedReader openBufferedStream()
/*  26:    */     throws IOException
/*  27:    */   {
/*  28: 92 */     Reader reader = openStream();
/*  29: 93 */     return (reader instanceof BufferedReader) ? (BufferedReader)reader : new BufferedReader(reader);
/*  30:    */   }
/*  31:    */   
/*  32:    */   @Beta
/*  33:    */   public Optional<Long> lengthIfKnown()
/*  34:    */   {
/*  35:114 */     return Optional.absent();
/*  36:    */   }
/*  37:    */   
/*  38:    */   @Beta
/*  39:    */   public long length()
/*  40:    */     throws IOException
/*  41:    */   {
/*  42:138 */     Optional<Long> lengthIfKnown = lengthIfKnown();
/*  43:139 */     if (lengthIfKnown.isPresent()) {
/*  44:140 */       return ((Long)lengthIfKnown.get()).longValue();
/*  45:    */     }
/*  46:143 */     Closer closer = Closer.create();
/*  47:    */     try
/*  48:    */     {
/*  49:145 */       Reader reader = (Reader)closer.register(openStream());
/*  50:146 */       return countBySkipping(reader);
/*  51:    */     }
/*  52:    */     catch (Throwable e)
/*  53:    */     {
/*  54:148 */       throw closer.rethrow(e);
/*  55:    */     }
/*  56:    */     finally
/*  57:    */     {
/*  58:150 */       closer.close();
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   private long countBySkipping(Reader reader)
/*  63:    */     throws IOException
/*  64:    */   {
/*  65:155 */     long count = 0L;
/*  66:    */     long read;
/*  67:157 */     while ((read = reader.skip(9223372036854775807L)) != 0L) {
/*  68:158 */       count += read;
/*  69:    */     }
/*  70:160 */     return count;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public long copyTo(Appendable appendable)
/*  74:    */     throws IOException
/*  75:    */   {
/*  76:171 */     Preconditions.checkNotNull(appendable);
/*  77:    */     
/*  78:173 */     Closer closer = Closer.create();
/*  79:    */     try
/*  80:    */     {
/*  81:175 */       Reader reader = (Reader)closer.register(openStream());
/*  82:176 */       return CharStreams.copy(reader, appendable);
/*  83:    */     }
/*  84:    */     catch (Throwable e)
/*  85:    */     {
/*  86:178 */       throw closer.rethrow(e);
/*  87:    */     }
/*  88:    */     finally
/*  89:    */     {
/*  90:180 */       closer.close();
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   public long copyTo(CharSink sink)
/*  95:    */     throws IOException
/*  96:    */   {
/*  97:191 */     Preconditions.checkNotNull(sink);
/*  98:    */     
/*  99:193 */     Closer closer = Closer.create();
/* 100:    */     try
/* 101:    */     {
/* 102:195 */       Reader reader = (Reader)closer.register(openStream());
/* 103:196 */       Writer writer = (Writer)closer.register(sink.openStream());
/* 104:197 */       return CharStreams.copy(reader, writer);
/* 105:    */     }
/* 106:    */     catch (Throwable e)
/* 107:    */     {
/* 108:199 */       throw closer.rethrow(e);
/* 109:    */     }
/* 110:    */     finally
/* 111:    */     {
/* 112:201 */       closer.close();
/* 113:    */     }
/* 114:    */   }
/* 115:    */   
/* 116:    */   public String read()
/* 117:    */     throws IOException
/* 118:    */   {
/* 119:211 */     Closer closer = Closer.create();
/* 120:    */     try
/* 121:    */     {
/* 122:213 */       Reader reader = (Reader)closer.register(openStream());
/* 123:214 */       return CharStreams.toString(reader);
/* 124:    */     }
/* 125:    */     catch (Throwable e)
/* 126:    */     {
/* 127:216 */       throw closer.rethrow(e);
/* 128:    */     }
/* 129:    */     finally
/* 130:    */     {
/* 131:218 */       closer.close();
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   @Nullable
/* 136:    */   public String readFirstLine()
/* 137:    */     throws IOException
/* 138:    */   {
/* 139:232 */     Closer closer = Closer.create();
/* 140:    */     try
/* 141:    */     {
/* 142:234 */       BufferedReader reader = (BufferedReader)closer.register(openBufferedStream());
/* 143:235 */       return reader.readLine();
/* 144:    */     }
/* 145:    */     catch (Throwable e)
/* 146:    */     {
/* 147:237 */       throw closer.rethrow(e);
/* 148:    */     }
/* 149:    */     finally
/* 150:    */     {
/* 151:239 */       closer.close();
/* 152:    */     }
/* 153:    */   }
/* 154:    */   
/* 155:    */   public ImmutableList<String> readLines()
/* 156:    */     throws IOException
/* 157:    */   {
/* 158:254 */     Closer closer = Closer.create();
/* 159:    */     try
/* 160:    */     {
/* 161:256 */       BufferedReader reader = (BufferedReader)closer.register(openBufferedStream());
/* 162:257 */       List<String> result = Lists.newArrayList();
/* 163:    */       String line;
/* 164:259 */       while ((line = reader.readLine()) != null) {
/* 165:260 */         result.add(line);
/* 166:    */       }
/* 167:262 */       return ImmutableList.copyOf(result);
/* 168:    */     }
/* 169:    */     catch (Throwable e)
/* 170:    */     {
/* 171:264 */       throw closer.rethrow(e);
/* 172:    */     }
/* 173:    */     finally
/* 174:    */     {
/* 175:266 */       closer.close();
/* 176:    */     }
/* 177:    */   }
/* 178:    */   
/* 179:    */   @Beta
/* 180:    */   public <T> T readLines(LineProcessor<T> processor)
/* 181:    */     throws IOException
/* 182:    */   {
/* 183:286 */     Preconditions.checkNotNull(processor);
/* 184:    */     
/* 185:288 */     Closer closer = Closer.create();
/* 186:    */     try
/* 187:    */     {
/* 188:290 */       Reader reader = (Reader)closer.register(openStream());
/* 189:291 */       return CharStreams.readLines(reader, processor);
/* 190:    */     }
/* 191:    */     catch (Throwable e)
/* 192:    */     {
/* 193:293 */       throw closer.rethrow(e);
/* 194:    */     }
/* 195:    */     finally
/* 196:    */     {
/* 197:295 */       closer.close();
/* 198:    */     }
/* 199:    */   }
/* 200:    */   
/* 201:    */   public boolean isEmpty()
/* 202:    */     throws IOException
/* 203:    */   {
/* 204:312 */     Optional<Long> lengthIfKnown = lengthIfKnown();
/* 205:313 */     if ((lengthIfKnown.isPresent()) && (((Long)lengthIfKnown.get()).longValue() == 0L)) {
/* 206:314 */       return true;
/* 207:    */     }
/* 208:316 */     Closer closer = Closer.create();
/* 209:    */     try
/* 210:    */     {
/* 211:318 */       Reader reader = (Reader)closer.register(openStream());
/* 212:319 */       return reader.read() == -1;
/* 213:    */     }
/* 214:    */     catch (Throwable e)
/* 215:    */     {
/* 216:321 */       throw closer.rethrow(e);
/* 217:    */     }
/* 218:    */     finally
/* 219:    */     {
/* 220:323 */       closer.close();
/* 221:    */     }
/* 222:    */   }
/* 223:    */   
/* 224:    */   public static CharSource concat(Iterable<? extends CharSource> sources)
/* 225:    */   {
/* 226:339 */     return new ConcatenatedCharSource(sources);
/* 227:    */   }
/* 228:    */   
/* 229:    */   public static CharSource concat(Iterator<? extends CharSource> sources)
/* 230:    */   {
/* 231:361 */     return concat(ImmutableList.copyOf(sources));
/* 232:    */   }
/* 233:    */   
/* 234:    */   public static CharSource concat(CharSource... sources)
/* 235:    */   {
/* 236:377 */     return concat(ImmutableList.copyOf(sources));
/* 237:    */   }
/* 238:    */   
/* 239:    */   public static CharSource wrap(CharSequence charSequence)
/* 240:    */   {
/* 241:388 */     return new CharSequenceCharSource(charSequence);
/* 242:    */   }
/* 243:    */   
/* 244:    */   public static CharSource empty()
/* 245:    */   {
/* 246:397 */     return EmptyCharSource.INSTANCE;
/* 247:    */   }
/* 248:    */   
/* 249:    */   private static class CharSequenceCharSource
/* 250:    */     extends CharSource
/* 251:    */   {
/* 252:402 */     private static final Splitter LINE_SPLITTER = Splitter.on(Pattern.compile("\r\n|\n|\r"));
/* 253:    */     private final CharSequence seq;
/* 254:    */     
/* 255:    */     protected CharSequenceCharSource(CharSequence seq)
/* 256:    */     {
/* 257:408 */       this.seq = ((CharSequence)Preconditions.checkNotNull(seq));
/* 258:    */     }
/* 259:    */     
/* 260:    */     public Reader openStream()
/* 261:    */     {
/* 262:413 */       return new CharSequenceReader(this.seq);
/* 263:    */     }
/* 264:    */     
/* 265:    */     public String read()
/* 266:    */     {
/* 267:418 */       return this.seq.toString();
/* 268:    */     }
/* 269:    */     
/* 270:    */     public boolean isEmpty()
/* 271:    */     {
/* 272:423 */       return this.seq.length() == 0;
/* 273:    */     }
/* 274:    */     
/* 275:    */     public long length()
/* 276:    */     {
/* 277:428 */       return this.seq.length();
/* 278:    */     }
/* 279:    */     
/* 280:    */     public Optional<Long> lengthIfKnown()
/* 281:    */     {
/* 282:433 */       return Optional.of(Long.valueOf(this.seq.length()));
/* 283:    */     }
/* 284:    */     
/* 285:    */     private Iterable<String> lines()
/* 286:    */     {
/* 287:442 */       new Iterable()
/* 288:    */       {
/* 289:    */         public Iterator<String> iterator()
/* 290:    */         {
/* 291:445 */           new AbstractIterator()
/* 292:    */           {
/* 293:446 */             Iterator<String> lines = CharSource.CharSequenceCharSource.LINE_SPLITTER.split(CharSource.CharSequenceCharSource.this.seq).iterator();
/* 294:    */             
/* 295:    */             protected String computeNext()
/* 296:    */             {
/* 297:450 */               if (this.lines.hasNext())
/* 298:    */               {
/* 299:451 */                 String next = (String)this.lines.next();
/* 300:453 */                 if ((this.lines.hasNext()) || (!next.isEmpty())) {
/* 301:454 */                   return next;
/* 302:    */                 }
/* 303:    */               }
/* 304:457 */               return (String)endOfData();
/* 305:    */             }
/* 306:    */           };
/* 307:    */         }
/* 308:    */       };
/* 309:    */     }
/* 310:    */     
/* 311:    */     public String readFirstLine()
/* 312:    */     {
/* 313:466 */       Iterator<String> lines = lines().iterator();
/* 314:467 */       return lines.hasNext() ? (String)lines.next() : null;
/* 315:    */     }
/* 316:    */     
/* 317:    */     public ImmutableList<String> readLines()
/* 318:    */     {
/* 319:472 */       return ImmutableList.copyOf(lines());
/* 320:    */     }
/* 321:    */     
/* 322:    */     public <T> T readLines(LineProcessor<T> processor)
/* 323:    */       throws IOException
/* 324:    */     {
/* 325:477 */       for (String line : lines()) {
/* 326:478 */         if (!processor.processLine(line)) {
/* 327:    */           break;
/* 328:    */         }
/* 329:    */       }
/* 330:482 */       return processor.getResult();
/* 331:    */     }
/* 332:    */     
/* 333:    */     public String toString()
/* 334:    */     {
/* 335:487 */       return "CharSource.wrap(" + Ascii.truncate(this.seq, 30, "...") + ")";
/* 336:    */     }
/* 337:    */   }
/* 338:    */   
/* 339:    */   private static final class EmptyCharSource
/* 340:    */     extends CharSource.CharSequenceCharSource
/* 341:    */   {
/* 342:493 */     private static final EmptyCharSource INSTANCE = new EmptyCharSource();
/* 343:    */     
/* 344:    */     private EmptyCharSource()
/* 345:    */     {
/* 346:496 */       super();
/* 347:    */     }
/* 348:    */     
/* 349:    */     public String toString()
/* 350:    */     {
/* 351:501 */       return "CharSource.empty()";
/* 352:    */     }
/* 353:    */   }
/* 354:    */   
/* 355:    */   private static final class ConcatenatedCharSource
/* 356:    */     extends CharSource
/* 357:    */   {
/* 358:    */     private final Iterable<? extends CharSource> sources;
/* 359:    */     
/* 360:    */     ConcatenatedCharSource(Iterable<? extends CharSource> sources)
/* 361:    */     {
/* 362:510 */       this.sources = ((Iterable)Preconditions.checkNotNull(sources));
/* 363:    */     }
/* 364:    */     
/* 365:    */     public Reader openStream()
/* 366:    */       throws IOException
/* 367:    */     {
/* 368:515 */       return new MultiReader(this.sources.iterator());
/* 369:    */     }
/* 370:    */     
/* 371:    */     public boolean isEmpty()
/* 372:    */       throws IOException
/* 373:    */     {
/* 374:520 */       for (CharSource source : this.sources) {
/* 375:521 */         if (!source.isEmpty()) {
/* 376:522 */           return false;
/* 377:    */         }
/* 378:    */       }
/* 379:525 */       return true;
/* 380:    */     }
/* 381:    */     
/* 382:    */     public Optional<Long> lengthIfKnown()
/* 383:    */     {
/* 384:530 */       long result = 0L;
/* 385:531 */       for (CharSource source : this.sources)
/* 386:    */       {
/* 387:532 */         Optional<Long> lengthIfKnown = source.lengthIfKnown();
/* 388:533 */         if (!lengthIfKnown.isPresent()) {
/* 389:534 */           return Optional.absent();
/* 390:    */         }
/* 391:536 */         result += ((Long)lengthIfKnown.get()).longValue();
/* 392:    */       }
/* 393:538 */       return Optional.of(Long.valueOf(result));
/* 394:    */     }
/* 395:    */     
/* 396:    */     public long length()
/* 397:    */       throws IOException
/* 398:    */     {
/* 399:543 */       long result = 0L;
/* 400:544 */       for (CharSource source : this.sources) {
/* 401:545 */         result += source.length();
/* 402:    */       }
/* 403:547 */       return result;
/* 404:    */     }
/* 405:    */     
/* 406:    */     public String toString()
/* 407:    */     {
/* 408:552 */       return "CharSource.concat(" + this.sources + ")";
/* 409:    */     }
/* 410:    */   }
/* 411:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.CharSource
 * JD-Core Version:    0.7.0.1
 */