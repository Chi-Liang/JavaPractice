/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import java.io.IOException;
/*   4:    */ 
/*   5:    */ abstract class LineBuffer
/*   6:    */ {
/*   7: 35 */   private StringBuilder line = new StringBuilder();
/*   8:    */   private boolean sawReturn;
/*   9:    */   
/*  10:    */   protected void add(char[] cbuf, int off, int len)
/*  11:    */     throws IOException
/*  12:    */   {
/*  13: 51 */     int pos = off;
/*  14: 52 */     if ((this.sawReturn) && (len > 0)) {
/*  15: 54 */       if (finishLine(cbuf[pos] == '\n')) {
/*  16: 55 */         pos++;
/*  17:    */       }
/*  18:    */     }
/*  19: 59 */     int start = pos;
/*  20: 60 */     for (int end = off + len; pos < end; pos++) {
/*  21: 61 */       switch (cbuf[pos])
/*  22:    */       {
/*  23:    */       case '\r': 
/*  24: 63 */         this.line.append(cbuf, start, pos - start);
/*  25: 64 */         this.sawReturn = true;
/*  26: 65 */         if (pos + 1 < end) {
/*  27: 66 */           if (finishLine(cbuf[(pos + 1)] == '\n')) {
/*  28: 67 */             pos++;
/*  29:    */           }
/*  30:    */         }
/*  31: 70 */         start = pos + 1;
/*  32: 71 */         break;
/*  33:    */       case '\n': 
/*  34: 74 */         this.line.append(cbuf, start, pos - start);
/*  35: 75 */         finishLine(true);
/*  36: 76 */         start = pos + 1;
/*  37:    */       }
/*  38:    */     }
/*  39: 83 */     this.line.append(cbuf, start, off + len - start);
/*  40:    */   }
/*  41:    */   
/*  42:    */   private boolean finishLine(boolean sawNewline)
/*  43:    */     throws IOException
/*  44:    */   {
/*  45: 88 */     handleLine(this.line.toString(), sawNewline ? "\n" : this.sawReturn ? "\r" : sawNewline ? "\r\n" : "");
/*  46:    */     
/*  47:    */ 
/*  48: 91 */     this.line = new StringBuilder();
/*  49: 92 */     this.sawReturn = false;
/*  50: 93 */     return sawNewline;
/*  51:    */   }
/*  52:    */   
/*  53:    */   protected void finish()
/*  54:    */     throws IOException
/*  55:    */   {
/*  56:104 */     if ((this.sawReturn) || (this.line.length() > 0)) {
/*  57:105 */       finishLine(false);
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   protected abstract void handleLine(String paramString1, String paramString2)
/*  62:    */     throws IOException;
/*  63:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.LineBuffer
 * JD-Core Version:    0.7.0.1
 */