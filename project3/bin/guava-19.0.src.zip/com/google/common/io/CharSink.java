/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.io.BufferedWriter;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.Writer;
/*   7:    */ 
/*   8:    */ public abstract class CharSink
/*   9:    */ {
/*  10:    */   public abstract Writer openStream()
/*  11:    */     throws IOException;
/*  12:    */   
/*  13:    */   public Writer openBufferedStream()
/*  14:    */     throws IOException
/*  15:    */   {
/*  16: 79 */     Writer writer = openStream();
/*  17: 80 */     return (writer instanceof BufferedWriter) ? (BufferedWriter)writer : new BufferedWriter(writer);
/*  18:    */   }
/*  19:    */   
/*  20:    */   public void write(CharSequence charSequence)
/*  21:    */     throws IOException
/*  22:    */   {
/*  23: 91 */     Preconditions.checkNotNull(charSequence);
/*  24:    */     
/*  25: 93 */     Closer closer = Closer.create();
/*  26:    */     try
/*  27:    */     {
/*  28: 95 */       Writer out = (Writer)closer.register(openStream());
/*  29: 96 */       out.append(charSequence);
/*  30: 97 */       out.flush();
/*  31:    */     }
/*  32:    */     catch (Throwable e)
/*  33:    */     {
/*  34: 99 */       throw closer.rethrow(e);
/*  35:    */     }
/*  36:    */     finally
/*  37:    */     {
/*  38:101 */       closer.close();
/*  39:    */     }
/*  40:    */   }
/*  41:    */   
/*  42:    */   public void writeLines(Iterable<? extends CharSequence> lines)
/*  43:    */     throws IOException
/*  44:    */   {
/*  45:113 */     writeLines(lines, System.getProperty("line.separator"));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public void writeLines(Iterable<? extends CharSequence> lines, String lineSeparator)
/*  49:    */     throws IOException
/*  50:    */   {
/*  51:124 */     Preconditions.checkNotNull(lines);
/*  52:125 */     Preconditions.checkNotNull(lineSeparator);
/*  53:    */     
/*  54:127 */     Closer closer = Closer.create();
/*  55:    */     try
/*  56:    */     {
/*  57:129 */       Writer out = (Writer)closer.register(openBufferedStream());
/*  58:130 */       for (CharSequence line : lines) {
/*  59:131 */         out.append(line).append(lineSeparator);
/*  60:    */       }
/*  61:133 */       out.flush();
/*  62:    */     }
/*  63:    */     catch (Throwable e)
/*  64:    */     {
/*  65:135 */       throw closer.rethrow(e);
/*  66:    */     }
/*  67:    */     finally
/*  68:    */     {
/*  69:137 */       closer.close();
/*  70:    */     }
/*  71:    */   }
/*  72:    */   
/*  73:    */   public long writeFrom(Readable readable)
/*  74:    */     throws IOException
/*  75:    */   {
/*  76:149 */     Preconditions.checkNotNull(readable);
/*  77:    */     
/*  78:151 */     Closer closer = Closer.create();
/*  79:    */     try
/*  80:    */     {
/*  81:153 */       Writer out = (Writer)closer.register(openStream());
/*  82:154 */       long written = CharStreams.copy(readable, out);
/*  83:155 */       out.flush();
/*  84:156 */       return written;
/*  85:    */     }
/*  86:    */     catch (Throwable e)
/*  87:    */     {
/*  88:158 */       throw closer.rethrow(e);
/*  89:    */     }
/*  90:    */     finally
/*  91:    */     {
/*  92:160 */       closer.close();
/*  93:    */     }
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.CharSink
 * JD-Core Version:    0.7.0.1
 */