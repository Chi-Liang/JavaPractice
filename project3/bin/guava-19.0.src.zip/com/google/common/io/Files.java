/*   1:    */ package com.google.common.io;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Joiner;
/*   5:    */ import com.google.common.base.Optional;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Predicate;
/*   8:    */ import com.google.common.base.Splitter;
/*   9:    */ import com.google.common.collect.ImmutableSet;
/*  10:    */ import com.google.common.collect.Lists;
/*  11:    */ import com.google.common.collect.TreeTraverser;
/*  12:    */ import com.google.common.hash.HashCode;
/*  13:    */ import com.google.common.hash.HashFunction;
/*  14:    */ import java.io.BufferedReader;
/*  15:    */ import java.io.BufferedWriter;
/*  16:    */ import java.io.File;
/*  17:    */ import java.io.FileInputStream;
/*  18:    */ import java.io.FileNotFoundException;
/*  19:    */ import java.io.FileOutputStream;
/*  20:    */ import java.io.IOException;
/*  21:    */ import java.io.InputStream;
/*  22:    */ import java.io.InputStreamReader;
/*  23:    */ import java.io.OutputStream;
/*  24:    */ import java.io.OutputStreamWriter;
/*  25:    */ import java.io.RandomAccessFile;
/*  26:    */ import java.nio.MappedByteBuffer;
/*  27:    */ import java.nio.channels.FileChannel;
/*  28:    */ import java.nio.channels.FileChannel.MapMode;
/*  29:    */ import java.nio.charset.Charset;
/*  30:    */ import java.util.ArrayList;
/*  31:    */ import java.util.Arrays;
/*  32:    */ import java.util.Collections;
/*  33:    */ import java.util.List;
/*  34:    */ 
/*  35:    */ @Beta
/*  36:    */ public final class Files
/*  37:    */ {
/*  38:    */   private static final int TEMP_DIR_ATTEMPTS = 10000;
/*  39:    */   
/*  40:    */   public static BufferedReader newReader(File file, Charset charset)
/*  41:    */     throws FileNotFoundException
/*  42:    */   {
/*  43: 84 */     Preconditions.checkNotNull(file);
/*  44: 85 */     Preconditions.checkNotNull(charset);
/*  45: 86 */     return new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static BufferedWriter newWriter(File file, Charset charset)
/*  49:    */     throws FileNotFoundException
/*  50:    */   {
/*  51:101 */     Preconditions.checkNotNull(file);
/*  52:102 */     Preconditions.checkNotNull(charset);
/*  53:103 */     return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), charset));
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static ByteSource asByteSource(File file)
/*  57:    */   {
/*  58:113 */     return new FileByteSource(file, null);
/*  59:    */   }
/*  60:    */   
/*  61:    */   private static final class FileByteSource
/*  62:    */     extends ByteSource
/*  63:    */   {
/*  64:    */     private final File file;
/*  65:    */     
/*  66:    */     private FileByteSource(File file)
/*  67:    */     {
/*  68:121 */       this.file = ((File)Preconditions.checkNotNull(file));
/*  69:    */     }
/*  70:    */     
/*  71:    */     public FileInputStream openStream()
/*  72:    */       throws IOException
/*  73:    */     {
/*  74:126 */       return new FileInputStream(this.file);
/*  75:    */     }
/*  76:    */     
/*  77:    */     public Optional<Long> sizeIfKnown()
/*  78:    */     {
/*  79:131 */       if (this.file.isFile()) {
/*  80:132 */         return Optional.of(Long.valueOf(this.file.length()));
/*  81:    */       }
/*  82:134 */       return Optional.absent();
/*  83:    */     }
/*  84:    */     
/*  85:    */     public long size()
/*  86:    */       throws IOException
/*  87:    */     {
/*  88:140 */       if (!this.file.isFile()) {
/*  89:141 */         throw new FileNotFoundException(this.file.toString());
/*  90:    */       }
/*  91:143 */       return this.file.length();
/*  92:    */     }
/*  93:    */     
/*  94:    */     public byte[] read()
/*  95:    */       throws IOException
/*  96:    */     {
/*  97:148 */       Closer closer = Closer.create();
/*  98:    */       try
/*  99:    */       {
/* 100:150 */         FileInputStream in = (FileInputStream)closer.register(openStream());
/* 101:151 */         return Files.readFile(in, in.getChannel().size());
/* 102:    */       }
/* 103:    */       catch (Throwable e)
/* 104:    */       {
/* 105:153 */         throw closer.rethrow(e);
/* 106:    */       }
/* 107:    */       finally
/* 108:    */       {
/* 109:155 */         closer.close();
/* 110:    */       }
/* 111:    */     }
/* 112:    */     
/* 113:    */     public String toString()
/* 114:    */     {
/* 115:161 */       return "Files.asByteSource(" + this.file + ")";
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   static byte[] readFile(InputStream in, long expectedSize)
/* 120:    */     throws IOException
/* 121:    */   {
/* 122:173 */     if (expectedSize > 2147483647L) {
/* 123:174 */       throw new OutOfMemoryError("file is too large to fit in a byte array: " + expectedSize + " bytes");
/* 124:    */     }
/* 125:180 */     return expectedSize == 0L ? ByteStreams.toByteArray(in) : ByteStreams.toByteArray(in, (int)expectedSize);
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static ByteSink asByteSink(File file, FileWriteMode... modes)
/* 129:    */   {
/* 130:195 */     return new FileByteSink(file, modes, null);
/* 131:    */   }
/* 132:    */   
/* 133:    */   private static final class FileByteSink
/* 134:    */     extends ByteSink
/* 135:    */   {
/* 136:    */     private final File file;
/* 137:    */     private final ImmutableSet<FileWriteMode> modes;
/* 138:    */     
/* 139:    */     private FileByteSink(File file, FileWriteMode... modes)
/* 140:    */     {
/* 141:204 */       this.file = ((File)Preconditions.checkNotNull(file));
/* 142:205 */       this.modes = ImmutableSet.copyOf(modes);
/* 143:    */     }
/* 144:    */     
/* 145:    */     public FileOutputStream openStream()
/* 146:    */       throws IOException
/* 147:    */     {
/* 148:210 */       return new FileOutputStream(this.file, this.modes.contains(FileWriteMode.APPEND));
/* 149:    */     }
/* 150:    */     
/* 151:    */     public String toString()
/* 152:    */     {
/* 153:215 */       return "Files.asByteSink(" + this.file + ", " + this.modes + ")";
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static CharSource asCharSource(File file, Charset charset)
/* 158:    */   {
/* 159:226 */     return asByteSource(file).asCharSource(charset);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static CharSink asCharSink(File file, Charset charset, FileWriteMode... modes)
/* 163:    */   {
/* 164:241 */     return asByteSink(file, modes).asCharSink(charset);
/* 165:    */   }
/* 166:    */   
/* 167:    */   private static FileWriteMode[] modes(boolean append)
/* 168:    */   {
/* 169:245 */     return append ? new FileWriteMode[] { FileWriteMode.APPEND } : new FileWriteMode[0];
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static byte[] toByteArray(File file)
/* 173:    */     throws IOException
/* 174:    */   {
/* 175:260 */     return asByteSource(file).read();
/* 176:    */   }
/* 177:    */   
/* 178:    */   public static String toString(File file, Charset charset)
/* 179:    */     throws IOException
/* 180:    */   {
/* 181:274 */     return asCharSource(file, charset).read();
/* 182:    */   }
/* 183:    */   
/* 184:    */   public static void write(byte[] from, File to)
/* 185:    */     throws IOException
/* 186:    */   {
/* 187:285 */     asByteSink(to, new FileWriteMode[0]).write(from);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public static void copy(File from, OutputStream to)
/* 191:    */     throws IOException
/* 192:    */   {
/* 193:296 */     asByteSource(from).copyTo(to);
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static void copy(File from, File to)
/* 197:    */     throws IOException
/* 198:    */   {
/* 199:313 */     Preconditions.checkArgument(!from.equals(to), "Source %s and destination %s must be different", new Object[] { from, to });
/* 200:    */     
/* 201:315 */     asByteSource(from).copyTo(asByteSink(to, new FileWriteMode[0]));
/* 202:    */   }
/* 203:    */   
/* 204:    */   public static void write(CharSequence from, File to, Charset charset)
/* 205:    */     throws IOException
/* 206:    */   {
/* 207:330 */     asCharSink(to, charset, new FileWriteMode[0]).write(from);
/* 208:    */   }
/* 209:    */   
/* 210:    */   public static void append(CharSequence from, File to, Charset charset)
/* 211:    */     throws IOException
/* 212:    */   {
/* 213:345 */     write(from, to, charset, true);
/* 214:    */   }
/* 215:    */   
/* 216:    */   private static void write(CharSequence from, File to, Charset charset, boolean append)
/* 217:    */     throws IOException
/* 218:    */   {
/* 219:361 */     asCharSink(to, charset, modes(append)).write(from);
/* 220:    */   }
/* 221:    */   
/* 222:    */   public static void copy(File from, Charset charset, Appendable to)
/* 223:    */     throws IOException
/* 224:    */   {
/* 225:376 */     asCharSource(from, charset).copyTo(to);
/* 226:    */   }
/* 227:    */   
/* 228:    */   public static boolean equal(File file1, File file2)
/* 229:    */     throws IOException
/* 230:    */   {
/* 231:385 */     Preconditions.checkNotNull(file1);
/* 232:386 */     Preconditions.checkNotNull(file2);
/* 233:387 */     if ((file1 == file2) || (file1.equals(file2))) {
/* 234:388 */       return true;
/* 235:    */     }
/* 236:396 */     long len1 = file1.length();
/* 237:397 */     long len2 = file2.length();
/* 238:398 */     if ((len1 != 0L) && (len2 != 0L) && (len1 != len2)) {
/* 239:399 */       return false;
/* 240:    */     }
/* 241:401 */     return asByteSource(file1).contentEquals(asByteSource(file2));
/* 242:    */   }
/* 243:    */   
/* 244:    */   public static File createTempDir()
/* 245:    */   {
/* 246:424 */     File baseDir = new File(System.getProperty("java.io.tmpdir"));
/* 247:425 */     String baseName = System.currentTimeMillis() + "-";
/* 248:427 */     for (int counter = 0; counter < 10000; counter++)
/* 249:    */     {
/* 250:428 */       File tempDir = new File(baseDir, baseName + counter);
/* 251:429 */       if (tempDir.mkdir()) {
/* 252:430 */         return tempDir;
/* 253:    */       }
/* 254:    */     }
/* 255:433 */     throw new IllegalStateException("Failed to create directory within 10000 attempts (tried " + baseName + "0 to " + baseName + 9999 + ')');
/* 256:    */   }
/* 257:    */   
/* 258:    */   public static void touch(File file)
/* 259:    */     throws IOException
/* 260:    */   {
/* 261:446 */     Preconditions.checkNotNull(file);
/* 262:447 */     if ((!file.createNewFile()) && (!file.setLastModified(System.currentTimeMillis()))) {
/* 263:449 */       throw new IOException("Unable to update modification time of " + file);
/* 264:    */     }
/* 265:    */   }
/* 266:    */   
/* 267:    */   public static void createParentDirs(File file)
/* 268:    */     throws IOException
/* 269:    */   {
/* 270:464 */     Preconditions.checkNotNull(file);
/* 271:465 */     File parent = file.getCanonicalFile().getParentFile();
/* 272:466 */     if (parent == null) {
/* 273:474 */       return;
/* 274:    */     }
/* 275:476 */     parent.mkdirs();
/* 276:477 */     if (!parent.isDirectory()) {
/* 277:478 */       throw new IOException("Unable to create parent directories of " + file);
/* 278:    */     }
/* 279:    */   }
/* 280:    */   
/* 281:    */   public static void move(File from, File to)
/* 282:    */     throws IOException
/* 283:    */   {
/* 284:494 */     Preconditions.checkNotNull(from);
/* 285:495 */     Preconditions.checkNotNull(to);
/* 286:496 */     Preconditions.checkArgument(!from.equals(to), "Source %s and destination %s must be different", new Object[] { from, to });
/* 287:499 */     if (!from.renameTo(to))
/* 288:    */     {
/* 289:500 */       copy(from, to);
/* 290:501 */       if (!from.delete())
/* 291:    */       {
/* 292:502 */         if (!to.delete()) {
/* 293:503 */           throw new IOException("Unable to delete " + to);
/* 294:    */         }
/* 295:505 */         throw new IOException("Unable to delete " + from);
/* 296:    */       }
/* 297:    */     }
/* 298:    */   }
/* 299:    */   
/* 300:    */   public static String readFirstLine(File file, Charset charset)
/* 301:    */     throws IOException
/* 302:    */   {
/* 303:523 */     return asCharSource(file, charset).readFirstLine();
/* 304:    */   }
/* 305:    */   
/* 306:    */   public static List<String> readLines(File file, Charset charset)
/* 307:    */     throws IOException
/* 308:    */   {
/* 309:545 */     (List)readLines(file, charset, new LineProcessor()
/* 310:    */     {
/* 311:546 */       final List<String> result = Lists.newArrayList();
/* 312:    */       
/* 313:    */       public boolean processLine(String line)
/* 314:    */       {
/* 315:550 */         this.result.add(line);
/* 316:551 */         return true;
/* 317:    */       }
/* 318:    */       
/* 319:    */       public List<String> getResult()
/* 320:    */       {
/* 321:556 */         return this.result;
/* 322:    */       }
/* 323:    */     });
/* 324:    */   }
/* 325:    */   
/* 326:    */   public static <T> T readLines(File file, Charset charset, LineProcessor<T> callback)
/* 327:    */     throws IOException
/* 328:    */   {
/* 329:574 */     return asCharSource(file, charset).readLines(callback);
/* 330:    */   }
/* 331:    */   
/* 332:    */   public static <T> T readBytes(File file, ByteProcessor<T> processor)
/* 333:    */     throws IOException
/* 334:    */   {
/* 335:590 */     return asByteSource(file).read(processor);
/* 336:    */   }
/* 337:    */   
/* 338:    */   public static HashCode hash(File file, HashFunction hashFunction)
/* 339:    */     throws IOException
/* 340:    */   {
/* 341:604 */     return asByteSource(file).hash(hashFunction);
/* 342:    */   }
/* 343:    */   
/* 344:    */   public static MappedByteBuffer map(File file)
/* 345:    */     throws IOException
/* 346:    */   {
/* 347:624 */     Preconditions.checkNotNull(file);
/* 348:625 */     return map(file, FileChannel.MapMode.READ_ONLY);
/* 349:    */   }
/* 350:    */   
/* 351:    */   public static MappedByteBuffer map(File file, FileChannel.MapMode mode)
/* 352:    */     throws IOException
/* 353:    */   {
/* 354:648 */     Preconditions.checkNotNull(file);
/* 355:649 */     Preconditions.checkNotNull(mode);
/* 356:650 */     if (!file.exists()) {
/* 357:651 */       throw new FileNotFoundException(file.toString());
/* 358:    */     }
/* 359:653 */     return map(file, mode, file.length());
/* 360:    */   }
/* 361:    */   
/* 362:    */   public static MappedByteBuffer map(File file, FileChannel.MapMode mode, long size)
/* 363:    */     throws FileNotFoundException, IOException
/* 364:    */   {
/* 365:679 */     Preconditions.checkNotNull(file);
/* 366:680 */     Preconditions.checkNotNull(mode);
/* 367:    */     
/* 368:682 */     Closer closer = Closer.create();
/* 369:    */     try
/* 370:    */     {
/* 371:684 */       RandomAccessFile raf = (RandomAccessFile)closer.register(new RandomAccessFile(file, mode == FileChannel.MapMode.READ_ONLY ? "r" : "rw"));
/* 372:    */       
/* 373:686 */       return map(raf, mode, size);
/* 374:    */     }
/* 375:    */     catch (Throwable e)
/* 376:    */     {
/* 377:688 */       throw closer.rethrow(e);
/* 378:    */     }
/* 379:    */     finally
/* 380:    */     {
/* 381:690 */       closer.close();
/* 382:    */     }
/* 383:    */   }
/* 384:    */   
/* 385:    */   private static MappedByteBuffer map(RandomAccessFile raf, FileChannel.MapMode mode, long size)
/* 386:    */     throws IOException
/* 387:    */   {
/* 388:696 */     Closer closer = Closer.create();
/* 389:    */     try
/* 390:    */     {
/* 391:698 */       FileChannel channel = (FileChannel)closer.register(raf.getChannel());
/* 392:699 */       return channel.map(mode, 0L, size);
/* 393:    */     }
/* 394:    */     catch (Throwable e)
/* 395:    */     {
/* 396:701 */       throw closer.rethrow(e);
/* 397:    */     }
/* 398:    */     finally
/* 399:    */     {
/* 400:703 */       closer.close();
/* 401:    */     }
/* 402:    */   }
/* 403:    */   
/* 404:    */   public static String simplifyPath(String pathname)
/* 405:    */   {
/* 406:729 */     Preconditions.checkNotNull(pathname);
/* 407:730 */     if (pathname.length() == 0) {
/* 408:731 */       return ".";
/* 409:    */     }
/* 410:735 */     Iterable<String> components = Splitter.on('/').omitEmptyStrings().split(pathname);
/* 411:    */     
/* 412:737 */     List<String> path = new ArrayList();
/* 413:740 */     for (String component : components) {
/* 414:741 */       if (!component.equals(".")) {
/* 415:743 */         if (component.equals(".."))
/* 416:    */         {
/* 417:744 */           if ((path.size() > 0) && (!((String)path.get(path.size() - 1)).equals(".."))) {
/* 418:745 */             path.remove(path.size() - 1);
/* 419:    */           } else {
/* 420:747 */             path.add("..");
/* 421:    */           }
/* 422:    */         }
/* 423:    */         else {
/* 424:750 */           path.add(component);
/* 425:    */         }
/* 426:    */       }
/* 427:    */     }
/* 428:755 */     String result = Joiner.on('/').join(path);
/* 429:756 */     if (pathname.charAt(0) == '/') {
/* 430:757 */       result = "/" + result;
/* 431:    */     }
/* 432:760 */     while (result.startsWith("/../")) {
/* 433:761 */       result = result.substring(3);
/* 434:    */     }
/* 435:763 */     if (result.equals("/..")) {
/* 436:764 */       result = "/";
/* 437:765 */     } else if ("".equals(result)) {
/* 438:766 */       result = ".";
/* 439:    */     }
/* 440:769 */     return result;
/* 441:    */   }
/* 442:    */   
/* 443:    */   public static String getFileExtension(String fullName)
/* 444:    */   {
/* 445:780 */     Preconditions.checkNotNull(fullName);
/* 446:781 */     String fileName = new File(fullName).getName();
/* 447:782 */     int dotIndex = fileName.lastIndexOf('.');
/* 448:783 */     return dotIndex == -1 ? "" : fileName.substring(dotIndex + 1);
/* 449:    */   }
/* 450:    */   
/* 451:    */   public static String getNameWithoutExtension(String file)
/* 452:    */   {
/* 453:797 */     Preconditions.checkNotNull(file);
/* 454:798 */     String fileName = new File(file).getName();
/* 455:799 */     int dotIndex = fileName.lastIndexOf('.');
/* 456:800 */     return dotIndex == -1 ? fileName : fileName.substring(0, dotIndex);
/* 457:    */   }
/* 458:    */   
/* 459:    */   public static TreeTraverser<File> fileTreeTraverser()
/* 460:    */   {
/* 461:814 */     return FILE_TREE_TRAVERSER;
/* 462:    */   }
/* 463:    */   
/* 464:817 */   private static final TreeTraverser<File> FILE_TREE_TRAVERSER = new TreeTraverser()
/* 465:    */   {
/* 466:    */     public Iterable<File> children(File file)
/* 467:    */     {
/* 468:821 */       if (file.isDirectory())
/* 469:    */       {
/* 470:822 */         File[] files = file.listFiles();
/* 471:823 */         if (files != null) {
/* 472:824 */           return Collections.unmodifiableList(Arrays.asList(files));
/* 473:    */         }
/* 474:    */       }
/* 475:828 */       return Collections.emptyList();
/* 476:    */     }
/* 477:    */     
/* 478:    */     public String toString()
/* 479:    */     {
/* 480:833 */       return "Files.fileTreeTraverser()";
/* 481:    */     }
/* 482:    */   };
/* 483:    */   
/* 484:    */   public static Predicate<File> isDirectory()
/* 485:    */   {
/* 486:843 */     return FilePredicate.IS_DIRECTORY;
/* 487:    */   }
/* 488:    */   
/* 489:    */   public static Predicate<File> isFile()
/* 490:    */   {
/* 491:852 */     return FilePredicate.IS_FILE;
/* 492:    */   }
/* 493:    */   
/* 494:    */   private static abstract enum FilePredicate
/* 495:    */     implements Predicate<File>
/* 496:    */   {
/* 497:856 */     IS_DIRECTORY,  IS_FILE;
/* 498:    */     
/* 499:    */     private FilePredicate() {}
/* 500:    */   }
/* 501:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.Files
 * JD-Core Version:    0.7.0.1
 */