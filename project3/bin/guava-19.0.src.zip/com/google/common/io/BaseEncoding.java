/*    1:     */ package com.google.common.io;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Ascii;
/*    7:     */ import com.google.common.base.CharMatcher;
/*    8:     */ import com.google.common.base.Preconditions;
/*    9:     */ import com.google.common.math.IntMath;
/*   10:     */ import java.io.IOException;
/*   11:     */ import java.io.InputStream;
/*   12:     */ import java.io.OutputStream;
/*   13:     */ import java.io.Reader;
/*   14:     */ import java.io.Writer;
/*   15:     */ import java.math.RoundingMode;
/*   16:     */ import java.util.Arrays;
/*   17:     */ import javax.annotation.CheckReturnValue;
/*   18:     */ import javax.annotation.Nullable;
/*   19:     */ 
/*   20:     */ @Beta
/*   21:     */ @GwtCompatible(emulated=true)
/*   22:     */ public abstract class BaseEncoding
/*   23:     */ {
/*   24:     */   public static final class DecodingException
/*   25:     */     extends IOException
/*   26:     */   {
/*   27:     */     DecodingException(String message)
/*   28:     */     {
/*   29: 137 */       super();
/*   30:     */     }
/*   31:     */     
/*   32:     */     DecodingException(Throwable cause)
/*   33:     */     {
/*   34: 141 */       super();
/*   35:     */     }
/*   36:     */   }
/*   37:     */   
/*   38:     */   public String encode(byte[] bytes)
/*   39:     */   {
/*   40: 149 */     return encode(bytes, 0, bytes.length);
/*   41:     */   }
/*   42:     */   
/*   43:     */   public final String encode(byte[] bytes, int off, int len)
/*   44:     */   {
/*   45: 157 */     Preconditions.checkPositionIndexes(off, off + len, bytes.length);
/*   46: 158 */     StringBuilder result = new StringBuilder(maxEncodedSize(len));
/*   47:     */     try
/*   48:     */     {
/*   49: 160 */       encodeTo(result, bytes, off, len);
/*   50:     */     }
/*   51:     */     catch (IOException impossible)
/*   52:     */     {
/*   53: 162 */       throw new AssertionError(impossible);
/*   54:     */     }
/*   55: 164 */     return result.toString();
/*   56:     */   }
/*   57:     */   
/*   58:     */   @GwtIncompatible("Writer,OutputStream")
/*   59:     */   public abstract OutputStream encodingStream(Writer paramWriter);
/*   60:     */   
/*   61:     */   @GwtIncompatible("ByteSink,CharSink")
/*   62:     */   public final ByteSink encodingSink(final CharSink encodedSink)
/*   63:     */   {
/*   64: 180 */     Preconditions.checkNotNull(encodedSink);
/*   65: 181 */     new ByteSink()
/*   66:     */     {
/*   67:     */       public OutputStream openStream()
/*   68:     */         throws IOException
/*   69:     */       {
/*   70: 184 */         return BaseEncoding.this.encodingStream(encodedSink.openStream());
/*   71:     */       }
/*   72:     */     };
/*   73:     */   }
/*   74:     */   
/*   75:     */   private static byte[] extract(byte[] result, int length)
/*   76:     */   {
/*   77: 192 */     if (length == result.length) {
/*   78: 193 */       return result;
/*   79:     */     }
/*   80: 195 */     byte[] trunc = new byte[length];
/*   81: 196 */     System.arraycopy(result, 0, trunc, 0, length);
/*   82: 197 */     return trunc;
/*   83:     */   }
/*   84:     */   
/*   85:     */   public final byte[] decode(CharSequence chars)
/*   86:     */   {
/*   87:     */     try
/*   88:     */     {
/*   89: 210 */       return decodeChecked(chars);
/*   90:     */     }
/*   91:     */     catch (DecodingException badInput)
/*   92:     */     {
/*   93: 212 */       throw new IllegalArgumentException(badInput);
/*   94:     */     }
/*   95:     */   }
/*   96:     */   
/*   97:     */   final byte[] decodeChecked(CharSequence chars)
/*   98:     */     throws BaseEncoding.DecodingException
/*   99:     */   {
/*  100: 224 */     chars = padding().trimTrailingFrom(chars);
/*  101: 225 */     byte[] tmp = new byte[maxDecodedSize(chars.length())];
/*  102: 226 */     int len = decodeTo(tmp, chars);
/*  103: 227 */     return extract(tmp, len);
/*  104:     */   }
/*  105:     */   
/*  106:     */   @GwtIncompatible("Reader,InputStream")
/*  107:     */   public abstract InputStream decodingStream(Reader paramReader);
/*  108:     */   
/*  109:     */   @GwtIncompatible("ByteSource,CharSource")
/*  110:     */   public final ByteSource decodingSource(final CharSource encodedSource)
/*  111:     */   {
/*  112: 244 */     Preconditions.checkNotNull(encodedSource);
/*  113: 245 */     new ByteSource()
/*  114:     */     {
/*  115:     */       public InputStream openStream()
/*  116:     */         throws IOException
/*  117:     */       {
/*  118: 248 */         return BaseEncoding.this.decodingStream(encodedSource.openStream());
/*  119:     */       }
/*  120:     */     };
/*  121:     */   }
/*  122:     */   
/*  123: 317 */   private static final BaseEncoding BASE64 = new Base64Encoding("base64()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Character.valueOf('='));
/*  124:     */   
/*  125:     */   abstract int maxEncodedSize(int paramInt);
/*  126:     */   
/*  127:     */   abstract void encodeTo(Appendable paramAppendable, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
/*  128:     */     throws IOException;
/*  129:     */   
/*  130:     */   abstract int maxDecodedSize(int paramInt);
/*  131:     */   
/*  132:     */   abstract int decodeTo(byte[] paramArrayOfByte, CharSequence paramCharSequence)
/*  133:     */     throws BaseEncoding.DecodingException;
/*  134:     */   
/*  135:     */   abstract CharMatcher padding();
/*  136:     */   
/*  137:     */   @CheckReturnValue
/*  138:     */   public abstract BaseEncoding omitPadding();
/*  139:     */   
/*  140:     */   @CheckReturnValue
/*  141:     */   public abstract BaseEncoding withPadChar(char paramChar);
/*  142:     */   
/*  143:     */   @CheckReturnValue
/*  144:     */   public abstract BaseEncoding withSeparator(String paramString, int paramInt);
/*  145:     */   
/*  146:     */   @CheckReturnValue
/*  147:     */   public abstract BaseEncoding upperCase();
/*  148:     */   
/*  149:     */   @CheckReturnValue
/*  150:     */   public abstract BaseEncoding lowerCase();
/*  151:     */   
/*  152:     */   public static BaseEncoding base64()
/*  153:     */   {
/*  154: 334 */     return BASE64;
/*  155:     */   }
/*  156:     */   
/*  157: 337 */   private static final BaseEncoding BASE64_URL = new Base64Encoding("base64Url()", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_", Character.valueOf('='));
/*  158:     */   
/*  159:     */   public static BaseEncoding base64Url()
/*  160:     */   {
/*  161: 355 */     return BASE64_URL;
/*  162:     */   }
/*  163:     */   
/*  164: 358 */   private static final BaseEncoding BASE32 = new StandardBaseEncoding("base32()", "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567", Character.valueOf('='));
/*  165:     */   
/*  166:     */   public static BaseEncoding base32()
/*  167:     */   {
/*  168: 375 */     return BASE32;
/*  169:     */   }
/*  170:     */   
/*  171: 378 */   private static final BaseEncoding BASE32_HEX = new StandardBaseEncoding("base32Hex()", "0123456789ABCDEFGHIJKLMNOPQRSTUV", Character.valueOf('='));
/*  172:     */   
/*  173:     */   public static BaseEncoding base32Hex()
/*  174:     */   {
/*  175: 394 */     return BASE32_HEX;
/*  176:     */   }
/*  177:     */   
/*  178: 397 */   private static final BaseEncoding BASE16 = new Base16Encoding("base16()", "0123456789ABCDEF");
/*  179:     */   
/*  180:     */   public static BaseEncoding base16()
/*  181:     */   {
/*  182: 414 */     return BASE16;
/*  183:     */   }
/*  184:     */   
/*  185:     */   private static final class Alphabet
/*  186:     */     extends CharMatcher
/*  187:     */   {
/*  188:     */     private final String name;
/*  189:     */     private final char[] chars;
/*  190:     */     final int mask;
/*  191:     */     final int bitsPerChar;
/*  192:     */     final int charsPerChunk;
/*  193:     */     final int bytesPerChunk;
/*  194:     */     private final byte[] decodabet;
/*  195:     */     private final boolean[] validPadding;
/*  196:     */     
/*  197:     */     Alphabet(String name, char[] chars)
/*  198:     */     {
/*  199: 429 */       this.name = ((String)Preconditions.checkNotNull(name));
/*  200: 430 */       this.chars = ((char[])Preconditions.checkNotNull(chars));
/*  201:     */       try
/*  202:     */       {
/*  203: 432 */         this.bitsPerChar = IntMath.log2(chars.length, RoundingMode.UNNECESSARY);
/*  204:     */       }
/*  205:     */       catch (ArithmeticException e)
/*  206:     */       {
/*  207: 434 */         throw new IllegalArgumentException("Illegal alphabet length " + chars.length, e);
/*  208:     */       }
/*  209: 441 */       int gcd = Math.min(8, Integer.lowestOneBit(this.bitsPerChar));
/*  210: 442 */       this.charsPerChunk = (8 / gcd);
/*  211: 443 */       this.bytesPerChunk = (this.bitsPerChar / gcd);
/*  212:     */       
/*  213: 445 */       this.mask = (chars.length - 1);
/*  214:     */       
/*  215: 447 */       byte[] decodabet = new byte[''];
/*  216: 448 */       Arrays.fill(decodabet, (byte)-1);
/*  217: 449 */       for (int i = 0; i < chars.length; i++)
/*  218:     */       {
/*  219: 450 */         char c = chars[i];
/*  220: 451 */         Preconditions.checkArgument(CharMatcher.ASCII.matches(c), "Non-ASCII character: %s", new Object[] { Character.valueOf(c) });
/*  221: 452 */         Preconditions.checkArgument(decodabet[c] == -1, "Duplicate character: %s", new Object[] { Character.valueOf(c) });
/*  222: 453 */         decodabet[c] = ((byte)i);
/*  223:     */       }
/*  224: 455 */       this.decodabet = decodabet;
/*  225:     */       
/*  226: 457 */       boolean[] validPadding = new boolean[this.charsPerChunk];
/*  227: 458 */       for (int i = 0; i < this.bytesPerChunk; i++) {
/*  228: 459 */         validPadding[IntMath.divide(i * 8, this.bitsPerChar, RoundingMode.CEILING)] = true;
/*  229:     */       }
/*  230: 461 */       this.validPadding = validPadding;
/*  231:     */     }
/*  232:     */     
/*  233:     */     char encode(int bits)
/*  234:     */     {
/*  235: 465 */       return this.chars[bits];
/*  236:     */     }
/*  237:     */     
/*  238:     */     boolean isValidPaddingStartPosition(int index)
/*  239:     */     {
/*  240: 469 */       return this.validPadding[(index % this.charsPerChunk)];
/*  241:     */     }
/*  242:     */     
/*  243:     */     int decode(char ch)
/*  244:     */       throws BaseEncoding.DecodingException
/*  245:     */     {
/*  246: 473 */       if ((ch > '') || (this.decodabet[ch] == -1)) {
/*  247: 474 */         throw new BaseEncoding.DecodingException("Unrecognized character: " + (CharMatcher.INVISIBLE.matches(ch) ? "0x" + Integer.toHexString(ch) : Character.valueOf(ch)));
/*  248:     */       }
/*  249: 477 */       return this.decodabet[ch];
/*  250:     */     }
/*  251:     */     
/*  252:     */     private boolean hasLowerCase()
/*  253:     */     {
/*  254: 481 */       for (char c : this.chars) {
/*  255: 482 */         if (Ascii.isLowerCase(c)) {
/*  256: 483 */           return true;
/*  257:     */         }
/*  258:     */       }
/*  259: 486 */       return false;
/*  260:     */     }
/*  261:     */     
/*  262:     */     private boolean hasUpperCase()
/*  263:     */     {
/*  264: 490 */       for (char c : this.chars) {
/*  265: 491 */         if (Ascii.isUpperCase(c)) {
/*  266: 492 */           return true;
/*  267:     */         }
/*  268:     */       }
/*  269: 495 */       return false;
/*  270:     */     }
/*  271:     */     
/*  272:     */     Alphabet upperCase()
/*  273:     */     {
/*  274: 499 */       if (!hasLowerCase()) {
/*  275: 500 */         return this;
/*  276:     */       }
/*  277: 502 */       Preconditions.checkState(!hasUpperCase(), "Cannot call upperCase() on a mixed-case alphabet");
/*  278: 503 */       char[] upperCased = new char[this.chars.length];
/*  279: 504 */       for (int i = 0; i < this.chars.length; i++) {
/*  280: 505 */         upperCased[i] = Ascii.toUpperCase(this.chars[i]);
/*  281:     */       }
/*  282: 507 */       return new Alphabet(this.name + ".upperCase()", upperCased);
/*  283:     */     }
/*  284:     */     
/*  285:     */     Alphabet lowerCase()
/*  286:     */     {
/*  287: 512 */       if (!hasUpperCase()) {
/*  288: 513 */         return this;
/*  289:     */       }
/*  290: 515 */       Preconditions.checkState(!hasLowerCase(), "Cannot call lowerCase() on a mixed-case alphabet");
/*  291: 516 */       char[] lowerCased = new char[this.chars.length];
/*  292: 517 */       for (int i = 0; i < this.chars.length; i++) {
/*  293: 518 */         lowerCased[i] = Ascii.toLowerCase(this.chars[i]);
/*  294:     */       }
/*  295: 520 */       return new Alphabet(this.name + ".lowerCase()", lowerCased);
/*  296:     */     }
/*  297:     */     
/*  298:     */     public boolean matches(char c)
/*  299:     */     {
/*  300: 526 */       return (CharMatcher.ASCII.matches(c)) && (this.decodabet[c] != -1);
/*  301:     */     }
/*  302:     */     
/*  303:     */     public String toString()
/*  304:     */     {
/*  305: 531 */       return this.name;
/*  306:     */     }
/*  307:     */   }
/*  308:     */   
/*  309:     */   static class StandardBaseEncoding
/*  310:     */     extends BaseEncoding
/*  311:     */   {
/*  312:     */     final BaseEncoding.Alphabet alphabet;
/*  313:     */     @Nullable
/*  314:     */     final Character paddingChar;
/*  315:     */     private transient BaseEncoding upperCase;
/*  316:     */     private transient BaseEncoding lowerCase;
/*  317:     */     
/*  318:     */     StandardBaseEncoding(String name, String alphabetChars, @Nullable Character paddingChar)
/*  319:     */     {
/*  320: 543 */       this(new BaseEncoding.Alphabet(name, alphabetChars.toCharArray()), paddingChar);
/*  321:     */     }
/*  322:     */     
/*  323:     */     StandardBaseEncoding(BaseEncoding.Alphabet alphabet, @Nullable Character paddingChar)
/*  324:     */     {
/*  325: 547 */       this.alphabet = ((BaseEncoding.Alphabet)Preconditions.checkNotNull(alphabet));
/*  326: 548 */       Preconditions.checkArgument((paddingChar == null) || (!alphabet.matches(paddingChar.charValue())), "Padding character %s was already in alphabet", new Object[] { paddingChar });
/*  327:     */       
/*  328: 550 */       this.paddingChar = paddingChar;
/*  329:     */     }
/*  330:     */     
/*  331:     */     CharMatcher padding()
/*  332:     */     {
/*  333: 555 */       return this.paddingChar == null ? CharMatcher.NONE : CharMatcher.is(this.paddingChar.charValue());
/*  334:     */     }
/*  335:     */     
/*  336:     */     int maxEncodedSize(int bytes)
/*  337:     */     {
/*  338: 560 */       return this.alphabet.charsPerChunk * IntMath.divide(bytes, this.alphabet.bytesPerChunk, RoundingMode.CEILING);
/*  339:     */     }
/*  340:     */     
/*  341:     */     @GwtIncompatible("Writer,OutputStream")
/*  342:     */     public OutputStream encodingStream(final Writer out)
/*  343:     */     {
/*  344: 566 */       Preconditions.checkNotNull(out);
/*  345: 567 */       new OutputStream()
/*  346:     */       {
/*  347: 568 */         int bitBuffer = 0;
/*  348: 569 */         int bitBufferLength = 0;
/*  349: 570 */         int writtenChars = 0;
/*  350:     */         
/*  351:     */         public void write(int b)
/*  352:     */           throws IOException
/*  353:     */         {
/*  354: 574 */           this.bitBuffer <<= 8;
/*  355: 575 */           this.bitBuffer |= b & 0xFF;
/*  356: 576 */           this.bitBufferLength += 8;
/*  357: 577 */           while (this.bitBufferLength >= BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar)
/*  358:     */           {
/*  359: 578 */             int charIndex = this.bitBuffer >> this.bitBufferLength - BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar & BaseEncoding.StandardBaseEncoding.this.alphabet.mask;
/*  360:     */             
/*  361: 580 */             out.write(BaseEncoding.StandardBaseEncoding.this.alphabet.encode(charIndex));
/*  362: 581 */             this.writtenChars += 1;
/*  363: 582 */             this.bitBufferLength -= BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar;
/*  364:     */           }
/*  365:     */         }
/*  366:     */         
/*  367:     */         public void flush()
/*  368:     */           throws IOException
/*  369:     */         {
/*  370: 588 */           out.flush();
/*  371:     */         }
/*  372:     */         
/*  373:     */         public void close()
/*  374:     */           throws IOException
/*  375:     */         {
/*  376: 593 */           if (this.bitBufferLength > 0)
/*  377:     */           {
/*  378: 594 */             int charIndex = this.bitBuffer << BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar - this.bitBufferLength & BaseEncoding.StandardBaseEncoding.this.alphabet.mask;
/*  379:     */             
/*  380: 596 */             out.write(BaseEncoding.StandardBaseEncoding.this.alphabet.encode(charIndex));
/*  381: 597 */             this.writtenChars += 1;
/*  382: 598 */             if (BaseEncoding.StandardBaseEncoding.this.paddingChar != null) {
/*  383: 599 */               while (this.writtenChars % BaseEncoding.StandardBaseEncoding.this.alphabet.charsPerChunk != 0)
/*  384:     */               {
/*  385: 600 */                 out.write(BaseEncoding.StandardBaseEncoding.this.paddingChar.charValue());
/*  386: 601 */                 this.writtenChars += 1;
/*  387:     */               }
/*  388:     */             }
/*  389:     */           }
/*  390: 605 */           out.close();
/*  391:     */         }
/*  392:     */       };
/*  393:     */     }
/*  394:     */     
/*  395:     */     void encodeTo(Appendable target, byte[] bytes, int off, int len)
/*  396:     */       throws IOException
/*  397:     */     {
/*  398: 612 */       Preconditions.checkNotNull(target);
/*  399: 613 */       Preconditions.checkPositionIndexes(off, off + len, bytes.length);
/*  400: 614 */       for (int i = 0; i < len; i += this.alphabet.bytesPerChunk) {
/*  401: 615 */         encodeChunkTo(target, bytes, off + i, Math.min(this.alphabet.bytesPerChunk, len - i));
/*  402:     */       }
/*  403:     */     }
/*  404:     */     
/*  405:     */     void encodeChunkTo(Appendable target, byte[] bytes, int off, int len)
/*  406:     */       throws IOException
/*  407:     */     {
/*  408: 621 */       Preconditions.checkNotNull(target);
/*  409: 622 */       Preconditions.checkPositionIndexes(off, off + len, bytes.length);
/*  410: 623 */       Preconditions.checkArgument(len <= this.alphabet.bytesPerChunk);
/*  411: 624 */       long bitBuffer = 0L;
/*  412: 625 */       for (int i = 0; i < len; i++)
/*  413:     */       {
/*  414: 626 */         bitBuffer |= bytes[(off + i)] & 0xFF;
/*  415: 627 */         bitBuffer <<= 8;
/*  416:     */       }
/*  417: 630 */       int bitOffset = (len + 1) * 8 - this.alphabet.bitsPerChar;
/*  418: 631 */       int bitsProcessed = 0;
/*  419: 632 */       while (bitsProcessed < len * 8)
/*  420:     */       {
/*  421: 633 */         int charIndex = (int)(bitBuffer >>> bitOffset - bitsProcessed) & this.alphabet.mask;
/*  422: 634 */         target.append(this.alphabet.encode(charIndex));
/*  423: 635 */         bitsProcessed += this.alphabet.bitsPerChar;
/*  424:     */       }
/*  425: 637 */       if (this.paddingChar != null) {
/*  426: 638 */         while (bitsProcessed < this.alphabet.bytesPerChunk * 8)
/*  427:     */         {
/*  428: 639 */           target.append(this.paddingChar.charValue());
/*  429: 640 */           bitsProcessed += this.alphabet.bitsPerChar;
/*  430:     */         }
/*  431:     */       }
/*  432:     */     }
/*  433:     */     
/*  434:     */     int maxDecodedSize(int chars)
/*  435:     */     {
/*  436: 647 */       return (int)((this.alphabet.bitsPerChar * chars + 7L) / 8L);
/*  437:     */     }
/*  438:     */     
/*  439:     */     int decodeTo(byte[] target, CharSequence chars)
/*  440:     */       throws BaseEncoding.DecodingException
/*  441:     */     {
/*  442: 652 */       Preconditions.checkNotNull(target);
/*  443: 653 */       chars = padding().trimTrailingFrom(chars);
/*  444: 654 */       if (!this.alphabet.isValidPaddingStartPosition(chars.length())) {
/*  445: 655 */         throw new BaseEncoding.DecodingException("Invalid input length " + chars.length());
/*  446:     */       }
/*  447: 657 */       int bytesWritten = 0;
/*  448: 658 */       for (int charIdx = 0; charIdx < chars.length(); charIdx += this.alphabet.charsPerChunk)
/*  449:     */       {
/*  450: 659 */         long chunk = 0L;
/*  451: 660 */         int charsProcessed = 0;
/*  452: 661 */         for (int i = 0; i < this.alphabet.charsPerChunk; i++)
/*  453:     */         {
/*  454: 662 */           chunk <<= this.alphabet.bitsPerChar;
/*  455: 663 */           if (charIdx + i < chars.length()) {
/*  456: 664 */             chunk |= this.alphabet.decode(chars.charAt(charIdx + charsProcessed++));
/*  457:     */           }
/*  458:     */         }
/*  459: 667 */         int minOffset = this.alphabet.bytesPerChunk * 8 - charsProcessed * this.alphabet.bitsPerChar;
/*  460: 668 */         for (int offset = (this.alphabet.bytesPerChunk - 1) * 8; offset >= minOffset; offset -= 8) {
/*  461: 669 */           target[(bytesWritten++)] = ((byte)(int)(chunk >>> offset & 0xFF));
/*  462:     */         }
/*  463:     */       }
/*  464: 672 */       return bytesWritten;
/*  465:     */     }
/*  466:     */     
/*  467:     */     @GwtIncompatible("Reader,InputStream")
/*  468:     */     public InputStream decodingStream(final Reader reader)
/*  469:     */     {
/*  470: 678 */       Preconditions.checkNotNull(reader);
/*  471: 679 */       new InputStream()
/*  472:     */       {
/*  473: 680 */         int bitBuffer = 0;
/*  474: 681 */         int bitBufferLength = 0;
/*  475: 682 */         int readChars = 0;
/*  476: 683 */         boolean hitPadding = false;
/*  477: 684 */         final CharMatcher paddingMatcher = BaseEncoding.StandardBaseEncoding.this.padding();
/*  478:     */         
/*  479:     */         public int read()
/*  480:     */           throws IOException
/*  481:     */         {
/*  482:     */           for (;;)
/*  483:     */           {
/*  484: 689 */             int readChar = reader.read();
/*  485: 690 */             if (readChar == -1)
/*  486:     */             {
/*  487: 691 */               if ((!this.hitPadding) && (!BaseEncoding.StandardBaseEncoding.this.alphabet.isValidPaddingStartPosition(this.readChars))) {
/*  488: 692 */                 throw new BaseEncoding.DecodingException("Invalid input length " + this.readChars);
/*  489:     */               }
/*  490: 694 */               return -1;
/*  491:     */             }
/*  492: 696 */             this.readChars += 1;
/*  493: 697 */             char ch = (char)readChar;
/*  494: 698 */             if (this.paddingMatcher.matches(ch))
/*  495:     */             {
/*  496: 699 */               if ((!this.hitPadding) && ((this.readChars == 1) || (!BaseEncoding.StandardBaseEncoding.this.alphabet.isValidPaddingStartPosition(this.readChars - 1)))) {
/*  497: 701 */                 throw new BaseEncoding.DecodingException("Padding cannot start at index " + this.readChars);
/*  498:     */               }
/*  499: 703 */               this.hitPadding = true;
/*  500:     */             }
/*  501:     */             else
/*  502:     */             {
/*  503: 704 */               if (this.hitPadding) {
/*  504: 705 */                 throw new BaseEncoding.DecodingException("Expected padding character but found '" + ch + "' at index " + this.readChars);
/*  505:     */               }
/*  506: 708 */               this.bitBuffer <<= BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar;
/*  507: 709 */               this.bitBuffer |= BaseEncoding.StandardBaseEncoding.this.alphabet.decode(ch);
/*  508: 710 */               this.bitBufferLength += BaseEncoding.StandardBaseEncoding.this.alphabet.bitsPerChar;
/*  509: 712 */               if (this.bitBufferLength >= 8)
/*  510:     */               {
/*  511: 713 */                 this.bitBufferLength -= 8;
/*  512: 714 */                 return this.bitBuffer >> this.bitBufferLength & 0xFF;
/*  513:     */               }
/*  514:     */             }
/*  515:     */           }
/*  516:     */         }
/*  517:     */         
/*  518:     */         public void close()
/*  519:     */           throws IOException
/*  520:     */         {
/*  521: 722 */           reader.close();
/*  522:     */         }
/*  523:     */       };
/*  524:     */     }
/*  525:     */     
/*  526:     */     public BaseEncoding omitPadding()
/*  527:     */     {
/*  528: 729 */       return this.paddingChar == null ? this : newInstance(this.alphabet, null);
/*  529:     */     }
/*  530:     */     
/*  531:     */     public BaseEncoding withPadChar(char padChar)
/*  532:     */     {
/*  533: 734 */       if ((8 % this.alphabet.bitsPerChar == 0) || ((this.paddingChar != null) && (this.paddingChar.charValue() == padChar))) {
/*  534: 736 */         return this;
/*  535:     */       }
/*  536: 738 */       return newInstance(this.alphabet, Character.valueOf(padChar));
/*  537:     */     }
/*  538:     */     
/*  539:     */     public BaseEncoding withSeparator(String separator, int afterEveryChars)
/*  540:     */     {
/*  541: 744 */       Preconditions.checkArgument(padding().or(this.alphabet).matchesNoneOf(separator), "Separator (%s) cannot contain alphabet or padding characters", new Object[] { separator });
/*  542:     */       
/*  543: 746 */       return new BaseEncoding.SeparatedBaseEncoding(this, separator, afterEveryChars);
/*  544:     */     }
/*  545:     */     
/*  546:     */     public BaseEncoding upperCase()
/*  547:     */     {
/*  548: 754 */       BaseEncoding result = this.upperCase;
/*  549: 755 */       if (result == null)
/*  550:     */       {
/*  551: 756 */         BaseEncoding.Alphabet upper = this.alphabet.upperCase();
/*  552: 757 */         result = this.upperCase = upper == this.alphabet ? this : newInstance(upper, this.paddingChar);
/*  553:     */       }
/*  554: 760 */       return result;
/*  555:     */     }
/*  556:     */     
/*  557:     */     public BaseEncoding lowerCase()
/*  558:     */     {
/*  559: 765 */       BaseEncoding result = this.lowerCase;
/*  560: 766 */       if (result == null)
/*  561:     */       {
/*  562: 767 */         BaseEncoding.Alphabet lower = this.alphabet.lowerCase();
/*  563: 768 */         result = this.lowerCase = lower == this.alphabet ? this : newInstance(lower, this.paddingChar);
/*  564:     */       }
/*  565: 771 */       return result;
/*  566:     */     }
/*  567:     */     
/*  568:     */     BaseEncoding newInstance(BaseEncoding.Alphabet alphabet, @Nullable Character paddingChar)
/*  569:     */     {
/*  570: 775 */       return new StandardBaseEncoding(alphabet, paddingChar);
/*  571:     */     }
/*  572:     */     
/*  573:     */     public String toString()
/*  574:     */     {
/*  575: 780 */       StringBuilder builder = new StringBuilder("BaseEncoding.");
/*  576: 781 */       builder.append(this.alphabet.toString());
/*  577: 782 */       if (8 % this.alphabet.bitsPerChar != 0) {
/*  578: 783 */         if (this.paddingChar == null) {
/*  579: 784 */           builder.append(".omitPadding()");
/*  580:     */         } else {
/*  581: 786 */           builder.append(".withPadChar(").append(this.paddingChar).append(')');
/*  582:     */         }
/*  583:     */       }
/*  584: 789 */       return builder.toString();
/*  585:     */     }
/*  586:     */   }
/*  587:     */   
/*  588:     */   static final class Base16Encoding
/*  589:     */     extends BaseEncoding.StandardBaseEncoding
/*  590:     */   {
/*  591: 794 */     final char[] encoding = new char[512];
/*  592:     */     
/*  593:     */     Base16Encoding(String name, String alphabetChars)
/*  594:     */     {
/*  595: 797 */       this(new BaseEncoding.Alphabet(name, alphabetChars.toCharArray()));
/*  596:     */     }
/*  597:     */     
/*  598:     */     private Base16Encoding(BaseEncoding.Alphabet alphabet)
/*  599:     */     {
/*  600: 801 */       super(null);
/*  601: 802 */       Preconditions.checkArgument(BaseEncoding.Alphabet.access$000(alphabet).length == 16);
/*  602: 803 */       for (int i = 0; i < 256; i++)
/*  603:     */       {
/*  604: 804 */         this.encoding[i] = alphabet.encode(i >>> 4);
/*  605: 805 */         this.encoding[(i | 0x100)] = alphabet.encode(i & 0xF);
/*  606:     */       }
/*  607:     */     }
/*  608:     */     
/*  609:     */     void encodeTo(Appendable target, byte[] bytes, int off, int len)
/*  610:     */       throws IOException
/*  611:     */     {
/*  612: 811 */       Preconditions.checkNotNull(target);
/*  613: 812 */       Preconditions.checkPositionIndexes(off, off + len, bytes.length);
/*  614: 813 */       for (int i = 0; i < len; i++)
/*  615:     */       {
/*  616: 814 */         int b = bytes[(off + i)] & 0xFF;
/*  617: 815 */         target.append(this.encoding[b]);
/*  618: 816 */         target.append(this.encoding[(b | 0x100)]);
/*  619:     */       }
/*  620:     */     }
/*  621:     */     
/*  622:     */     int decodeTo(byte[] target, CharSequence chars)
/*  623:     */       throws BaseEncoding.DecodingException
/*  624:     */     {
/*  625: 822 */       Preconditions.checkNotNull(target);
/*  626: 823 */       if (chars.length() % 2 == 1) {
/*  627: 824 */         throw new BaseEncoding.DecodingException("Invalid input length " + chars.length());
/*  628:     */       }
/*  629: 826 */       int bytesWritten = 0;
/*  630: 827 */       for (int i = 0; i < chars.length(); i += 2)
/*  631:     */       {
/*  632: 828 */         int decoded = this.alphabet.decode(chars.charAt(i)) << 4 | this.alphabet.decode(chars.charAt(i + 1));
/*  633: 829 */         target[(bytesWritten++)] = ((byte)decoded);
/*  634:     */       }
/*  635: 831 */       return bytesWritten;
/*  636:     */     }
/*  637:     */     
/*  638:     */     BaseEncoding newInstance(BaseEncoding.Alphabet alphabet, @Nullable Character paddingChar)
/*  639:     */     {
/*  640: 836 */       return new Base16Encoding(alphabet);
/*  641:     */     }
/*  642:     */   }
/*  643:     */   
/*  644:     */   static final class Base64Encoding
/*  645:     */     extends BaseEncoding.StandardBaseEncoding
/*  646:     */   {
/*  647:     */     Base64Encoding(String name, String alphabetChars, @Nullable Character paddingChar)
/*  648:     */     {
/*  649: 842 */       this(new BaseEncoding.Alphabet(name, alphabetChars.toCharArray()), paddingChar);
/*  650:     */     }
/*  651:     */     
/*  652:     */     private Base64Encoding(BaseEncoding.Alphabet alphabet, @Nullable Character paddingChar)
/*  653:     */     {
/*  654: 846 */       super(paddingChar);
/*  655: 847 */       Preconditions.checkArgument(BaseEncoding.Alphabet.access$000(alphabet).length == 64);
/*  656:     */     }
/*  657:     */     
/*  658:     */     void encodeTo(Appendable target, byte[] bytes, int off, int len)
/*  659:     */       throws IOException
/*  660:     */     {
/*  661: 852 */       Preconditions.checkNotNull(target);
/*  662: 853 */       Preconditions.checkPositionIndexes(off, off + len, bytes.length);
/*  663: 854 */       int i = off;
/*  664: 855 */       for (int remaining = len; remaining >= 3; remaining -= 3)
/*  665:     */       {
/*  666: 856 */         int chunk = (bytes[(i++)] & 0xFF) << 16 | (bytes[(i++)] & 0xFF) << 8 | bytes[(i++)] & 0xFF;
/*  667: 857 */         target.append(this.alphabet.encode(chunk >>> 18));
/*  668: 858 */         target.append(this.alphabet.encode(chunk >>> 12 & 0x3F));
/*  669: 859 */         target.append(this.alphabet.encode(chunk >>> 6 & 0x3F));
/*  670: 860 */         target.append(this.alphabet.encode(chunk & 0x3F));
/*  671:     */       }
/*  672: 862 */       if (i < off + len) {
/*  673: 863 */         encodeChunkTo(target, bytes, i, off + len - i);
/*  674:     */       }
/*  675:     */     }
/*  676:     */     
/*  677:     */     int decodeTo(byte[] target, CharSequence chars)
/*  678:     */       throws BaseEncoding.DecodingException
/*  679:     */     {
/*  680: 869 */       Preconditions.checkNotNull(target);
/*  681: 870 */       chars = padding().trimTrailingFrom(chars);
/*  682: 871 */       if (!this.alphabet.isValidPaddingStartPosition(chars.length())) {
/*  683: 872 */         throw new BaseEncoding.DecodingException("Invalid input length " + chars.length());
/*  684:     */       }
/*  685: 874 */       int bytesWritten = 0;
/*  686: 875 */       for (int i = 0; i < chars.length();)
/*  687:     */       {
/*  688: 876 */         int chunk = this.alphabet.decode(chars.charAt(i++)) << 18;
/*  689: 877 */         chunk |= this.alphabet.decode(chars.charAt(i++)) << 12;
/*  690: 878 */         target[(bytesWritten++)] = ((byte)(chunk >>> 16));
/*  691: 879 */         if (i < chars.length())
/*  692:     */         {
/*  693: 880 */           chunk |= this.alphabet.decode(chars.charAt(i++)) << 6;
/*  694: 881 */           target[(bytesWritten++)] = ((byte)(chunk >>> 8 & 0xFF));
/*  695: 882 */           if (i < chars.length())
/*  696:     */           {
/*  697: 883 */             chunk |= this.alphabet.decode(chars.charAt(i++));
/*  698: 884 */             target[(bytesWritten++)] = ((byte)(chunk & 0xFF));
/*  699:     */           }
/*  700:     */         }
/*  701:     */       }
/*  702: 888 */       return bytesWritten;
/*  703:     */     }
/*  704:     */     
/*  705:     */     BaseEncoding newInstance(BaseEncoding.Alphabet alphabet, @Nullable Character paddingChar)
/*  706:     */     {
/*  707: 893 */       return new Base64Encoding(alphabet, paddingChar);
/*  708:     */     }
/*  709:     */   }
/*  710:     */   
/*  711:     */   @GwtIncompatible("Reader")
/*  712:     */   static Reader ignoringReader(Reader delegate, final CharMatcher toIgnore)
/*  713:     */   {
/*  714: 899 */     Preconditions.checkNotNull(delegate);
/*  715: 900 */     Preconditions.checkNotNull(toIgnore);
/*  716: 901 */     new Reader()
/*  717:     */     {
/*  718:     */       public int read()
/*  719:     */         throws IOException
/*  720:     */       {
/*  721:     */         int readChar;
/*  722:     */         do
/*  723:     */         {
/*  724: 906 */           readChar = this.val$delegate.read();
/*  725: 907 */         } while ((readChar != -1) && (toIgnore.matches((char)readChar)));
/*  726: 908 */         return readChar;
/*  727:     */       }
/*  728:     */       
/*  729:     */       public int read(char[] cbuf, int off, int len)
/*  730:     */         throws IOException
/*  731:     */       {
/*  732: 913 */         throw new UnsupportedOperationException();
/*  733:     */       }
/*  734:     */       
/*  735:     */       public void close()
/*  736:     */         throws IOException
/*  737:     */       {
/*  738: 918 */         this.val$delegate.close();
/*  739:     */       }
/*  740:     */     };
/*  741:     */   }
/*  742:     */   
/*  743:     */   static Appendable separatingAppendable(final Appendable delegate, final String separator, int afterEveryChars)
/*  744:     */   {
/*  745: 925 */     Preconditions.checkNotNull(delegate);
/*  746: 926 */     Preconditions.checkNotNull(separator);
/*  747: 927 */     Preconditions.checkArgument(afterEveryChars > 0);
/*  748: 928 */     new Appendable()
/*  749:     */     {
/*  750: 929 */       int charsUntilSeparator = this.val$afterEveryChars;
/*  751:     */       
/*  752:     */       public Appendable append(char c)
/*  753:     */         throws IOException
/*  754:     */       {
/*  755: 933 */         if (this.charsUntilSeparator == 0)
/*  756:     */         {
/*  757: 934 */           delegate.append(separator);
/*  758: 935 */           this.charsUntilSeparator = this.val$afterEveryChars;
/*  759:     */         }
/*  760: 937 */         delegate.append(c);
/*  761: 938 */         this.charsUntilSeparator -= 1;
/*  762: 939 */         return this;
/*  763:     */       }
/*  764:     */       
/*  765:     */       public Appendable append(CharSequence chars, int off, int len)
/*  766:     */         throws IOException
/*  767:     */       {
/*  768: 944 */         throw new UnsupportedOperationException();
/*  769:     */       }
/*  770:     */       
/*  771:     */       public Appendable append(CharSequence chars)
/*  772:     */         throws IOException
/*  773:     */       {
/*  774: 949 */         throw new UnsupportedOperationException();
/*  775:     */       }
/*  776:     */     };
/*  777:     */   }
/*  778:     */   
/*  779:     */   @GwtIncompatible("Writer")
/*  780:     */   static Writer separatingWriter(final Writer delegate, String separator, int afterEveryChars)
/*  781:     */   {
/*  782: 957 */     Appendable seperatingAppendable = separatingAppendable(delegate, separator, afterEveryChars);
/*  783:     */     
/*  784: 959 */     new Writer()
/*  785:     */     {
/*  786:     */       public void write(int c)
/*  787:     */         throws IOException
/*  788:     */       {
/*  789: 962 */         this.val$seperatingAppendable.append((char)c);
/*  790:     */       }
/*  791:     */       
/*  792:     */       public void write(char[] chars, int off, int len)
/*  793:     */         throws IOException
/*  794:     */       {
/*  795: 967 */         throw new UnsupportedOperationException();
/*  796:     */       }
/*  797:     */       
/*  798:     */       public void flush()
/*  799:     */         throws IOException
/*  800:     */       {
/*  801: 972 */         delegate.flush();
/*  802:     */       }
/*  803:     */       
/*  804:     */       public void close()
/*  805:     */         throws IOException
/*  806:     */       {
/*  807: 977 */         delegate.close();
/*  808:     */       }
/*  809:     */     };
/*  810:     */   }
/*  811:     */   
/*  812:     */   static final class SeparatedBaseEncoding
/*  813:     */     extends BaseEncoding
/*  814:     */   {
/*  815:     */     private final BaseEncoding delegate;
/*  816:     */     private final String separator;
/*  817:     */     private final int afterEveryChars;
/*  818:     */     private final CharMatcher separatorChars;
/*  819:     */     
/*  820:     */     SeparatedBaseEncoding(BaseEncoding delegate, String separator, int afterEveryChars)
/*  821:     */     {
/*  822: 989 */       this.delegate = ((BaseEncoding)Preconditions.checkNotNull(delegate));
/*  823: 990 */       this.separator = ((String)Preconditions.checkNotNull(separator));
/*  824: 991 */       this.afterEveryChars = afterEveryChars;
/*  825: 992 */       Preconditions.checkArgument(afterEveryChars > 0, "Cannot add a separator after every %s chars", new Object[] { Integer.valueOf(afterEveryChars) });
/*  826:     */       
/*  827: 994 */       this.separatorChars = CharMatcher.anyOf(separator).precomputed();
/*  828:     */     }
/*  829:     */     
/*  830:     */     CharMatcher padding()
/*  831:     */     {
/*  832: 999 */       return this.delegate.padding();
/*  833:     */     }
/*  834:     */     
/*  835:     */     int maxEncodedSize(int bytes)
/*  836:     */     {
/*  837:1004 */       int unseparatedSize = this.delegate.maxEncodedSize(bytes);
/*  838:1005 */       return unseparatedSize + this.separator.length() * IntMath.divide(Math.max(0, unseparatedSize - 1), this.afterEveryChars, RoundingMode.FLOOR);
/*  839:     */     }
/*  840:     */     
/*  841:     */     @GwtIncompatible("Writer,OutputStream")
/*  842:     */     public OutputStream encodingStream(Writer output)
/*  843:     */     {
/*  844:1012 */       return this.delegate.encodingStream(separatingWriter(output, this.separator, this.afterEveryChars));
/*  845:     */     }
/*  846:     */     
/*  847:     */     void encodeTo(Appendable target, byte[] bytes, int off, int len)
/*  848:     */       throws IOException
/*  849:     */     {
/*  850:1017 */       this.delegate.encodeTo(separatingAppendable(target, this.separator, this.afterEveryChars), bytes, off, len);
/*  851:     */     }
/*  852:     */     
/*  853:     */     int maxDecodedSize(int chars)
/*  854:     */     {
/*  855:1022 */       return this.delegate.maxDecodedSize(chars);
/*  856:     */     }
/*  857:     */     
/*  858:     */     int decodeTo(byte[] target, CharSequence chars)
/*  859:     */       throws BaseEncoding.DecodingException
/*  860:     */     {
/*  861:1027 */       return this.delegate.decodeTo(target, this.separatorChars.removeFrom(chars));
/*  862:     */     }
/*  863:     */     
/*  864:     */     @GwtIncompatible("Reader,InputStream")
/*  865:     */     public InputStream decodingStream(Reader reader)
/*  866:     */     {
/*  867:1033 */       return this.delegate.decodingStream(ignoringReader(reader, this.separatorChars));
/*  868:     */     }
/*  869:     */     
/*  870:     */     public BaseEncoding omitPadding()
/*  871:     */     {
/*  872:1038 */       return this.delegate.omitPadding().withSeparator(this.separator, this.afterEveryChars);
/*  873:     */     }
/*  874:     */     
/*  875:     */     public BaseEncoding withPadChar(char padChar)
/*  876:     */     {
/*  877:1043 */       return this.delegate.withPadChar(padChar).withSeparator(this.separator, this.afterEveryChars);
/*  878:     */     }
/*  879:     */     
/*  880:     */     public BaseEncoding withSeparator(String separator, int afterEveryChars)
/*  881:     */     {
/*  882:1048 */       throw new UnsupportedOperationException("Already have a separator");
/*  883:     */     }
/*  884:     */     
/*  885:     */     public BaseEncoding upperCase()
/*  886:     */     {
/*  887:1053 */       return this.delegate.upperCase().withSeparator(this.separator, this.afterEveryChars);
/*  888:     */     }
/*  889:     */     
/*  890:     */     public BaseEncoding lowerCase()
/*  891:     */     {
/*  892:1058 */       return this.delegate.lowerCase().withSeparator(this.separator, this.afterEveryChars);
/*  893:     */     }
/*  894:     */     
/*  895:     */     public String toString()
/*  896:     */     {
/*  897:1063 */       return this.delegate.toString() + ".withSeparator(\"" + this.separator + "\", " + this.afterEveryChars + ")";
/*  898:     */     }
/*  899:     */   }
/*  900:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.io.BaseEncoding
 * JD-Core Version:    0.7.0.1
 */