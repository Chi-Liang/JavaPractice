/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import java.util.AbstractCollection;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.Set;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ abstract class AbstractMultiset<E>
/*  13:    */   extends AbstractCollection<E>
/*  14:    */   implements Multiset<E>
/*  15:    */ {
/*  16:    */   private transient Set<E> elementSet;
/*  17:    */   private transient Set<Multiset.Entry<E>> entrySet;
/*  18:    */   
/*  19:    */   public int size()
/*  20:    */   {
/*  21: 53 */     return Multisets.sizeImpl(this);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public boolean isEmpty()
/*  25:    */   {
/*  26: 58 */     return entrySet().isEmpty();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public boolean contains(@Nullable Object element)
/*  30:    */   {
/*  31: 63 */     return count(element) > 0;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Iterator<E> iterator()
/*  35:    */   {
/*  36: 68 */     return Multisets.iteratorImpl(this);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public int count(@Nullable Object element)
/*  40:    */   {
/*  41: 73 */     for (Multiset.Entry<E> entry : entrySet()) {
/*  42: 74 */       if (Objects.equal(entry.getElement(), element)) {
/*  43: 75 */         return entry.getCount();
/*  44:    */       }
/*  45:    */     }
/*  46: 78 */     return 0;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean add(@Nullable E element)
/*  50:    */   {
/*  51: 85 */     add(element, 1);
/*  52: 86 */     return true;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public int add(@Nullable E element, int occurrences)
/*  56:    */   {
/*  57: 91 */     throw new UnsupportedOperationException();
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean remove(@Nullable Object element)
/*  61:    */   {
/*  62: 96 */     return remove(element, 1) > 0;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public int remove(@Nullable Object element, int occurrences)
/*  66:    */   {
/*  67:101 */     throw new UnsupportedOperationException();
/*  68:    */   }
/*  69:    */   
/*  70:    */   public int setCount(@Nullable E element, int count)
/*  71:    */   {
/*  72:106 */     return Multisets.setCountImpl(this, element, count);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean setCount(@Nullable E element, int oldCount, int newCount)
/*  76:    */   {
/*  77:111 */     return Multisets.setCountImpl(this, element, oldCount, newCount);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public boolean addAll(Collection<? extends E> elementsToAdd)
/*  81:    */   {
/*  82:124 */     return Multisets.addAllImpl(this, elementsToAdd);
/*  83:    */   }
/*  84:    */   
/*  85:    */   public boolean removeAll(Collection<?> elementsToRemove)
/*  86:    */   {
/*  87:129 */     return Multisets.removeAllImpl(this, elementsToRemove);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public boolean retainAll(Collection<?> elementsToRetain)
/*  91:    */   {
/*  92:134 */     return Multisets.retainAllImpl(this, elementsToRetain);
/*  93:    */   }
/*  94:    */   
/*  95:    */   public void clear()
/*  96:    */   {
/*  97:139 */     Iterators.clear(entryIterator());
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Set<E> elementSet()
/* 101:    */   {
/* 102:148 */     Set<E> result = this.elementSet;
/* 103:149 */     if (result == null) {
/* 104:150 */       this.elementSet = (result = createElementSet());
/* 105:    */     }
/* 106:152 */     return result;
/* 107:    */   }
/* 108:    */   
/* 109:    */   Set<E> createElementSet()
/* 110:    */   {
/* 111:160 */     return new ElementSet();
/* 112:    */   }
/* 113:    */   
/* 114:    */   abstract Iterator<Multiset.Entry<E>> entryIterator();
/* 115:    */   
/* 116:    */   abstract int distinctElements();
/* 117:    */   
/* 118:    */   class ElementSet
/* 119:    */     extends Multisets.ElementSet<E>
/* 120:    */   {
/* 121:    */     ElementSet() {}
/* 122:    */     
/* 123:    */     Multiset<E> multiset()
/* 124:    */     {
/* 125:167 */       return AbstractMultiset.this;
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   public Set<Multiset.Entry<E>> entrySet()
/* 130:    */   {
/* 131:179 */     Set<Multiset.Entry<E>> result = this.entrySet;
/* 132:180 */     if (result == null) {
/* 133:181 */       this.entrySet = (result = createEntrySet());
/* 134:    */     }
/* 135:183 */     return result;
/* 136:    */   }
/* 137:    */   
/* 138:    */   class EntrySet
/* 139:    */     extends Multisets.EntrySet<E>
/* 140:    */   {
/* 141:    */     EntrySet() {}
/* 142:    */     
/* 143:    */     Multiset<E> multiset()
/* 144:    */     {
/* 145:190 */       return AbstractMultiset.this;
/* 146:    */     }
/* 147:    */     
/* 148:    */     public Iterator<Multiset.Entry<E>> iterator()
/* 149:    */     {
/* 150:195 */       return AbstractMultiset.this.entryIterator();
/* 151:    */     }
/* 152:    */     
/* 153:    */     public int size()
/* 154:    */     {
/* 155:200 */       return AbstractMultiset.this.distinctElements();
/* 156:    */     }
/* 157:    */   }
/* 158:    */   
/* 159:    */   Set<Multiset.Entry<E>> createEntrySet()
/* 160:    */   {
/* 161:205 */     return new EntrySet();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public boolean equals(@Nullable Object object)
/* 165:    */   {
/* 166:219 */     return Multisets.equalsImpl(this, object);
/* 167:    */   }
/* 168:    */   
/* 169:    */   public int hashCode()
/* 170:    */   {
/* 171:230 */     return entrySet().hashCode();
/* 172:    */   }
/* 173:    */   
/* 174:    */   public String toString()
/* 175:    */   {
/* 176:241 */     return entrySet().toString();
/* 177:    */   }
/* 178:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractMultiset
 * JD-Core Version:    0.7.0.1
 */