/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.j2objc.annotations.Weak;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ final class ImmutableMapValues<K, V>
/*  12:    */   extends ImmutableCollection<V>
/*  13:    */ {
/*  14:    */   @Weak
/*  15:    */   private final ImmutableMap<K, V> map;
/*  16:    */   
/*  17:    */   ImmutableMapValues(ImmutableMap<K, V> map)
/*  18:    */   {
/*  19: 39 */     this.map = map;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public int size()
/*  23:    */   {
/*  24: 44 */     return this.map.size();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public UnmodifiableIterator<V> iterator()
/*  28:    */   {
/*  29: 49 */     new UnmodifiableIterator()
/*  30:    */     {
/*  31: 50 */       final UnmodifiableIterator<Map.Entry<K, V>> entryItr = ImmutableMapValues.this.map.entrySet().iterator();
/*  32:    */       
/*  33:    */       public boolean hasNext()
/*  34:    */       {
/*  35: 54 */         return this.entryItr.hasNext();
/*  36:    */       }
/*  37:    */       
/*  38:    */       public V next()
/*  39:    */       {
/*  40: 59 */         return ((Map.Entry)this.entryItr.next()).getValue();
/*  41:    */       }
/*  42:    */     };
/*  43:    */   }
/*  44:    */   
/*  45:    */   public boolean contains(@Nullable Object object)
/*  46:    */   {
/*  47: 66 */     return (object != null) && (Iterators.contains(iterator(), object));
/*  48:    */   }
/*  49:    */   
/*  50:    */   boolean isPartialView()
/*  51:    */   {
/*  52: 71 */     return true;
/*  53:    */   }
/*  54:    */   
/*  55:    */   ImmutableList<V> createAsList()
/*  56:    */   {
/*  57: 76 */     final ImmutableList<Map.Entry<K, V>> entryList = this.map.entrySet().asList();
/*  58: 77 */     new ImmutableAsList()
/*  59:    */     {
/*  60:    */       public V get(int index)
/*  61:    */       {
/*  62: 80 */         return ((Map.Entry)entryList.get(index)).getValue();
/*  63:    */       }
/*  64:    */       
/*  65:    */       ImmutableCollection<V> delegateCollection()
/*  66:    */       {
/*  67: 85 */         return ImmutableMapValues.this;
/*  68:    */       }
/*  69:    */     };
/*  70:    */   }
/*  71:    */   
/*  72:    */   @GwtIncompatible("serialization")
/*  73:    */   Object writeReplace()
/*  74:    */   {
/*  75: 93 */     return new SerializedForm(this.map);
/*  76:    */   }
/*  77:    */   
/*  78:    */   @GwtIncompatible("serialization")
/*  79:    */   private static class SerializedForm<V>
/*  80:    */     implements Serializable
/*  81:    */   {
/*  82:    */     final ImmutableMap<?, V> map;
/*  83:    */     private static final long serialVersionUID = 0L;
/*  84:    */     
/*  85:    */     SerializedForm(ImmutableMap<?, V> map)
/*  86:    */     {
/*  87:101 */       this.map = map;
/*  88:    */     }
/*  89:    */     
/*  90:    */     Object readResolve()
/*  91:    */     {
/*  92:105 */       return this.map.values();
/*  93:    */     }
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableMapValues
 * JD-Core Version:    0.7.0.1
 */