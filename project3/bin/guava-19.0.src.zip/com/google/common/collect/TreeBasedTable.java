/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Supplier;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.Comparator;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.NoSuchElementException;
/*  13:    */ import java.util.Set;
/*  14:    */ import java.util.SortedMap;
/*  15:    */ import java.util.SortedSet;
/*  16:    */ import java.util.TreeMap;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible(serializable=true)
/*  20:    */ @Beta
/*  21:    */ public class TreeBasedTable<R, C, V>
/*  22:    */   extends StandardRowSortedTable<R, C, V>
/*  23:    */ {
/*  24:    */   private final Comparator<? super C> columnComparator;
/*  25:    */   private static final long serialVersionUID = 0L;
/*  26:    */   
/*  27:    */   private static class Factory<C, V>
/*  28:    */     implements Supplier<TreeMap<C, V>>, Serializable
/*  29:    */   {
/*  30:    */     final Comparator<? super C> comparator;
/*  31:    */     private static final long serialVersionUID = 0L;
/*  32:    */     
/*  33:    */     Factory(Comparator<? super C> comparator)
/*  34:    */     {
/*  35: 86 */       this.comparator = comparator;
/*  36:    */     }
/*  37:    */     
/*  38:    */     public TreeMap<C, V> get()
/*  39:    */     {
/*  40: 91 */       return new TreeMap(this.comparator);
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <R extends Comparable, C extends Comparable, V> TreeBasedTable<R, C, V> create()
/*  45:    */   {
/*  46:107 */     return new TreeBasedTable(Ordering.natural(), Ordering.natural());
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static <R, C, V> TreeBasedTable<R, C, V> create(Comparator<? super R> rowComparator, Comparator<? super C> columnComparator)
/*  50:    */   {
/*  51:119 */     Preconditions.checkNotNull(rowComparator);
/*  52:120 */     Preconditions.checkNotNull(columnComparator);
/*  53:121 */     return new TreeBasedTable(rowComparator, columnComparator);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <R, C, V> TreeBasedTable<R, C, V> create(TreeBasedTable<R, C, ? extends V> table)
/*  57:    */   {
/*  58:129 */     TreeBasedTable<R, C, V> result = new TreeBasedTable(table.rowComparator(), table.columnComparator());
/*  59:    */     
/*  60:131 */     result.putAll(table);
/*  61:132 */     return result;
/*  62:    */   }
/*  63:    */   
/*  64:    */   TreeBasedTable(Comparator<? super R> rowComparator, Comparator<? super C> columnComparator)
/*  65:    */   {
/*  66:136 */     super(new TreeMap(rowComparator), new Factory(columnComparator));
/*  67:137 */     this.columnComparator = columnComparator;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public Comparator<? super R> rowComparator()
/*  71:    */   {
/*  72:147 */     return rowKeySet().comparator();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public Comparator<? super C> columnComparator()
/*  76:    */   {
/*  77:155 */     return this.columnComparator;
/*  78:    */   }
/*  79:    */   
/*  80:    */   public SortedMap<C, V> row(R rowKey)
/*  81:    */   {
/*  82:172 */     return new TreeRow(rowKey);
/*  83:    */   }
/*  84:    */   
/*  85:    */   private class TreeRow
/*  86:    */     extends StandardTable<R, C, V>.Row
/*  87:    */     implements SortedMap<C, V>
/*  88:    */   {
/*  89:    */     @Nullable
/*  90:    */     final C lowerBound;
/*  91:    */     @Nullable
/*  92:    */     final C upperBound;
/*  93:    */     transient SortedMap<C, V> wholeRow;
/*  94:    */     
/*  95:    */     TreeRow()
/*  96:    */     {
/*  97:180 */       this(rowKey, null, null);
/*  98:    */     }
/*  99:    */     
/* 100:    */     TreeRow(@Nullable C rowKey, @Nullable C lowerBound)
/* 101:    */     {
/* 102:184 */       super(rowKey);
/* 103:185 */       this.lowerBound = lowerBound;
/* 104:186 */       this.upperBound = upperBound;
/* 105:187 */       Preconditions.checkArgument((lowerBound == null) || (upperBound == null) || (compare(lowerBound, upperBound) <= 0));
/* 106:    */     }
/* 107:    */     
/* 108:    */     public SortedSet<C> keySet()
/* 109:    */     {
/* 110:193 */       return new Maps.SortedKeySet(this);
/* 111:    */     }
/* 112:    */     
/* 113:    */     public Comparator<? super C> comparator()
/* 114:    */     {
/* 115:198 */       return TreeBasedTable.this.columnComparator();
/* 116:    */     }
/* 117:    */     
/* 118:    */     int compare(Object a, Object b)
/* 119:    */     {
/* 120:204 */       Comparator<Object> cmp = comparator();
/* 121:205 */       return cmp.compare(a, b);
/* 122:    */     }
/* 123:    */     
/* 124:    */     boolean rangeContains(@Nullable Object o)
/* 125:    */     {
/* 126:209 */       return (o != null) && ((this.lowerBound == null) || (compare(this.lowerBound, o) <= 0)) && ((this.upperBound == null) || (compare(this.upperBound, o) > 0));
/* 127:    */     }
/* 128:    */     
/* 129:    */     public SortedMap<C, V> subMap(C fromKey, C toKey)
/* 130:    */     {
/* 131:216 */       Preconditions.checkArgument((rangeContains(Preconditions.checkNotNull(fromKey))) && (rangeContains(Preconditions.checkNotNull(toKey))));
/* 132:217 */       return new TreeRow(TreeBasedTable.this, this.rowKey, fromKey, toKey);
/* 133:    */     }
/* 134:    */     
/* 135:    */     public SortedMap<C, V> headMap(C toKey)
/* 136:    */     {
/* 137:222 */       Preconditions.checkArgument(rangeContains(Preconditions.checkNotNull(toKey)));
/* 138:223 */       return new TreeRow(TreeBasedTable.this, this.rowKey, this.lowerBound, toKey);
/* 139:    */     }
/* 140:    */     
/* 141:    */     public SortedMap<C, V> tailMap(C fromKey)
/* 142:    */     {
/* 143:228 */       Preconditions.checkArgument(rangeContains(Preconditions.checkNotNull(fromKey)));
/* 144:229 */       return new TreeRow(TreeBasedTable.this, this.rowKey, fromKey, this.upperBound);
/* 145:    */     }
/* 146:    */     
/* 147:    */     public C firstKey()
/* 148:    */     {
/* 149:234 */       SortedMap<C, V> backing = backingRowMap();
/* 150:235 */       if (backing == null) {
/* 151:236 */         throw new NoSuchElementException();
/* 152:    */       }
/* 153:238 */       return backingRowMap().firstKey();
/* 154:    */     }
/* 155:    */     
/* 156:    */     public C lastKey()
/* 157:    */     {
/* 158:243 */       SortedMap<C, V> backing = backingRowMap();
/* 159:244 */       if (backing == null) {
/* 160:245 */         throw new NoSuchElementException();
/* 161:    */       }
/* 162:247 */       return backingRowMap().lastKey();
/* 163:    */     }
/* 164:    */     
/* 165:    */     SortedMap<C, V> wholeRow()
/* 166:    */     {
/* 167:257 */       if ((this.wholeRow == null) || ((this.wholeRow.isEmpty()) && (TreeBasedTable.this.backingMap.containsKey(this.rowKey)))) {
/* 168:258 */         this.wholeRow = ((SortedMap)TreeBasedTable.this.backingMap.get(this.rowKey));
/* 169:    */       }
/* 170:260 */       return this.wholeRow;
/* 171:    */     }
/* 172:    */     
/* 173:    */     SortedMap<C, V> backingRowMap()
/* 174:    */     {
/* 175:265 */       return (SortedMap)super.backingRowMap();
/* 176:    */     }
/* 177:    */     
/* 178:    */     SortedMap<C, V> computeBackingRowMap()
/* 179:    */     {
/* 180:270 */       SortedMap<C, V> map = wholeRow();
/* 181:271 */       if (map != null)
/* 182:    */       {
/* 183:272 */         if (this.lowerBound != null) {
/* 184:273 */           map = map.tailMap(this.lowerBound);
/* 185:    */         }
/* 186:275 */         if (this.upperBound != null) {
/* 187:276 */           map = map.headMap(this.upperBound);
/* 188:    */         }
/* 189:278 */         return map;
/* 190:    */       }
/* 191:280 */       return null;
/* 192:    */     }
/* 193:    */     
/* 194:    */     void maintainEmptyInvariant()
/* 195:    */     {
/* 196:285 */       if ((wholeRow() != null) && (this.wholeRow.isEmpty()))
/* 197:    */       {
/* 198:286 */         TreeBasedTable.this.backingMap.remove(this.rowKey);
/* 199:287 */         this.wholeRow = null;
/* 200:288 */         this.backingRowMap = null;
/* 201:    */       }
/* 202:    */     }
/* 203:    */     
/* 204:    */     public boolean containsKey(Object key)
/* 205:    */     {
/* 206:294 */       return (rangeContains(key)) && (super.containsKey(key));
/* 207:    */     }
/* 208:    */     
/* 209:    */     public V put(C key, V value)
/* 210:    */     {
/* 211:299 */       Preconditions.checkArgument(rangeContains(Preconditions.checkNotNull(key)));
/* 212:300 */       return super.put(key, value);
/* 213:    */     }
/* 214:    */   }
/* 215:    */   
/* 216:    */   public SortedSet<R> rowKeySet()
/* 217:    */   {
/* 218:308 */     return super.rowKeySet();
/* 219:    */   }
/* 220:    */   
/* 221:    */   public SortedMap<R, Map<C, V>> rowMap()
/* 222:    */   {
/* 223:313 */     return super.rowMap();
/* 224:    */   }
/* 225:    */   
/* 226:    */   Iterator<C> createColumnKeyIterator()
/* 227:    */   {
/* 228:322 */     final Comparator<? super C> comparator = columnComparator();
/* 229:    */     
/* 230:324 */     final Iterator<C> merged = Iterators.mergeSorted(Iterables.transform(this.backingMap.values(), new Function()
/* 231:    */     {
/* 232:    */       public Iterator<C> apply(Map<C, V> input)
/* 233:    */       {
/* 234:331 */         return input.keySet().iterator();
/* 235:    */       }
/* 236:331 */     }), comparator);
/* 237:    */     
/* 238:    */ 
/* 239:    */ 
/* 240:    */ 
/* 241:336 */     new AbstractIterator()
/* 242:    */     {
/* 243:    */       C lastValue;
/* 244:    */       
/* 245:    */       protected C computeNext()
/* 246:    */       {
/* 247:341 */         while (merged.hasNext())
/* 248:    */         {
/* 249:342 */           C next = merged.next();
/* 250:343 */           boolean duplicate = (this.lastValue != null) && (comparator.compare(next, this.lastValue) == 0);
/* 251:346 */           if (!duplicate)
/* 252:    */           {
/* 253:347 */             this.lastValue = next;
/* 254:348 */             return this.lastValue;
/* 255:    */           }
/* 256:    */         }
/* 257:352 */         this.lastValue = null;
/* 258:353 */         return endOfData();
/* 259:    */       }
/* 260:    */     };
/* 261:    */   }
/* 262:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.TreeBasedTable
 * JD-Core Version:    0.7.0.1
 */