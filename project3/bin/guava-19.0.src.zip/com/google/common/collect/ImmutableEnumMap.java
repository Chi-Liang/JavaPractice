/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.EnumMap;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import java.util.Set;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible(serializable=true, emulated=true)
/*  12:    */ final class ImmutableEnumMap<K extends Enum<K>, V>
/*  13:    */   extends ImmutableMap.IteratorBasedImmutableMap<K, V>
/*  14:    */ {
/*  15:    */   private final transient EnumMap<K, V> delegate;
/*  16:    */   
/*  17:    */   static <K extends Enum<K>, V> ImmutableMap<K, V> asImmutable(EnumMap<K, V> map)
/*  18:    */   {
/*  19: 38 */     switch (map.size())
/*  20:    */     {
/*  21:    */     case 0: 
/*  22: 40 */       return ImmutableMap.of();
/*  23:    */     case 1: 
/*  24: 42 */       Map.Entry<K, V> entry = (Map.Entry)Iterables.getOnlyElement(map.entrySet());
/*  25: 43 */       return ImmutableMap.of(entry.getKey(), entry.getValue());
/*  26:    */     }
/*  27: 45 */     return new ImmutableEnumMap(map);
/*  28:    */   }
/*  29:    */   
/*  30:    */   private ImmutableEnumMap(EnumMap<K, V> delegate)
/*  31:    */   {
/*  32: 52 */     this.delegate = delegate;
/*  33: 53 */     Preconditions.checkArgument(!delegate.isEmpty());
/*  34:    */   }
/*  35:    */   
/*  36:    */   UnmodifiableIterator<K> keyIterator()
/*  37:    */   {
/*  38: 58 */     return Iterators.unmodifiableIterator(this.delegate.keySet().iterator());
/*  39:    */   }
/*  40:    */   
/*  41:    */   public int size()
/*  42:    */   {
/*  43: 63 */     return this.delegate.size();
/*  44:    */   }
/*  45:    */   
/*  46:    */   public boolean containsKey(@Nullable Object key)
/*  47:    */   {
/*  48: 68 */     return this.delegate.containsKey(key);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public V get(Object key)
/*  52:    */   {
/*  53: 73 */     return this.delegate.get(key);
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean equals(Object object)
/*  57:    */   {
/*  58: 78 */     if (object == this) {
/*  59: 79 */       return true;
/*  60:    */     }
/*  61: 81 */     if ((object instanceof ImmutableEnumMap)) {
/*  62: 82 */       object = ((ImmutableEnumMap)object).delegate;
/*  63:    */     }
/*  64: 84 */     return this.delegate.equals(object);
/*  65:    */   }
/*  66:    */   
/*  67:    */   UnmodifiableIterator<Map.Entry<K, V>> entryIterator()
/*  68:    */   {
/*  69: 89 */     return Maps.unmodifiableEntryIterator(this.delegate.entrySet().iterator());
/*  70:    */   }
/*  71:    */   
/*  72:    */   boolean isPartialView()
/*  73:    */   {
/*  74: 94 */     return false;
/*  75:    */   }
/*  76:    */   
/*  77:    */   Object writeReplace()
/*  78:    */   {
/*  79:100 */     return new EnumSerializedForm(this.delegate);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private static class EnumSerializedForm<K extends Enum<K>, V>
/*  83:    */     implements Serializable
/*  84:    */   {
/*  85:    */     final EnumMap<K, V> delegate;
/*  86:    */     private static final long serialVersionUID = 0L;
/*  87:    */     
/*  88:    */     EnumSerializedForm(EnumMap<K, V> delegate)
/*  89:    */     {
/*  90:110 */       this.delegate = delegate;
/*  91:    */     }
/*  92:    */     
/*  93:    */     Object readResolve()
/*  94:    */     {
/*  95:114 */       return new ImmutableEnumMap(this.delegate, null);
/*  96:    */     }
/*  97:    */   }
/*  98:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableEnumMap
 * JD-Core Version:    0.7.0.1
 */