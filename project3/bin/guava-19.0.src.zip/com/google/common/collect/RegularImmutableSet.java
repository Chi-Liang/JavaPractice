/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import javax.annotation.Nullable;
/*   6:    */ 
/*   7:    */ @GwtCompatible(serializable=true, emulated=true)
/*   8:    */ final class RegularImmutableSet<E>
/*   9:    */   extends ImmutableSet<E>
/*  10:    */ {
/*  11: 32 */   static final RegularImmutableSet<Object> EMPTY = new RegularImmutableSet(ObjectArrays.EMPTY_ARRAY, 0, null, 0);
/*  12:    */   private final transient Object[] elements;
/*  13:    */   @VisibleForTesting
/*  14:    */   final transient Object[] table;
/*  15:    */   private final transient int mask;
/*  16:    */   private final transient int hashCode;
/*  17:    */   
/*  18:    */   RegularImmutableSet(Object[] elements, int hashCode, Object[] table, int mask)
/*  19:    */   {
/*  20: 43 */     this.elements = elements;
/*  21: 44 */     this.table = table;
/*  22: 45 */     this.mask = mask;
/*  23: 46 */     this.hashCode = hashCode;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public boolean contains(@Nullable Object target)
/*  27:    */   {
/*  28: 51 */     Object[] table = this.table;
/*  29: 52 */     if ((target == null) || (table == null)) {
/*  30: 53 */       return false;
/*  31:    */     }
/*  32: 55 */     for (int i = Hashing.smearedHash(target);; i++)
/*  33:    */     {
/*  34: 56 */       i &= this.mask;
/*  35: 57 */       Object candidate = table[i];
/*  36: 58 */       if (candidate == null) {
/*  37: 59 */         return false;
/*  38:    */       }
/*  39: 60 */       if (candidate.equals(target)) {
/*  40: 61 */         return true;
/*  41:    */       }
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public int size()
/*  46:    */   {
/*  47: 68 */     return this.elements.length;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public UnmodifiableIterator<E> iterator()
/*  51:    */   {
/*  52: 74 */     return Iterators.forArray(this.elements);
/*  53:    */   }
/*  54:    */   
/*  55:    */   int copyIntoArray(Object[] dst, int offset)
/*  56:    */   {
/*  57: 79 */     System.arraycopy(this.elements, 0, dst, offset, this.elements.length);
/*  58: 80 */     return offset + this.elements.length;
/*  59:    */   }
/*  60:    */   
/*  61:    */   ImmutableList<E> createAsList()
/*  62:    */   {
/*  63: 85 */     return this.table == null ? ImmutableList.of() : new RegularImmutableAsList(this, this.elements);
/*  64:    */   }
/*  65:    */   
/*  66:    */   boolean isPartialView()
/*  67:    */   {
/*  68: 90 */     return false;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public int hashCode()
/*  72:    */   {
/*  73: 95 */     return this.hashCode;
/*  74:    */   }
/*  75:    */   
/*  76:    */   boolean isHashCodeFast()
/*  77:    */   {
/*  78:100 */     return true;
/*  79:    */   }
/*  80:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableSet
 * JD-Core Version:    0.7.0.1
 */