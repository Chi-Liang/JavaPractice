/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ abstract class ImmutableSortedMapFauxverideShim<K, V>
/*   4:    */   extends ImmutableMap<K, V>
/*   5:    */ {
/*   6:    */   @Deprecated
/*   7:    */   public static <K, V> ImmutableSortedMap.Builder<K, V> builder()
/*   8:    */   {
/*   9: 38 */     throw new UnsupportedOperationException();
/*  10:    */   }
/*  11:    */   
/*  12:    */   @Deprecated
/*  13:    */   public static <K, V> ImmutableSortedMap<K, V> of(K k1, V v1)
/*  14:    */   {
/*  15: 52 */     throw new UnsupportedOperationException();
/*  16:    */   }
/*  17:    */   
/*  18:    */   @Deprecated
/*  19:    */   public static <K, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2)
/*  20:    */   {
/*  21: 66 */     throw new UnsupportedOperationException();
/*  22:    */   }
/*  23:    */   
/*  24:    */   @Deprecated
/*  25:    */   public static <K, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  26:    */   {
/*  27: 81 */     throw new UnsupportedOperationException();
/*  28:    */   }
/*  29:    */   
/*  30:    */   @Deprecated
/*  31:    */   public static <K, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  32:    */   {
/*  33: 96 */     throw new UnsupportedOperationException();
/*  34:    */   }
/*  35:    */   
/*  36:    */   @Deprecated
/*  37:    */   public static <K, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  38:    */   {
/*  39:112 */     throw new UnsupportedOperationException();
/*  40:    */   }
/*  41:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedMapFauxverideShim
 * JD-Core Version:    0.7.0.1
 */