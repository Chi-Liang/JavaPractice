/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.base.Objects;
/*    6:     */ import com.google.common.base.Preconditions;
/*    7:     */ import com.google.common.base.Predicate;
/*    8:     */ import com.google.common.base.Predicates;
/*    9:     */ import com.google.common.primitives.Ints;
/*   10:     */ import java.io.Serializable;
/*   11:     */ import java.util.Collection;
/*   12:     */ import java.util.Collections;
/*   13:     */ import java.util.Iterator;
/*   14:     */ import java.util.List;
/*   15:     */ import java.util.NoSuchElementException;
/*   16:     */ import java.util.Set;
/*   17:     */ import javax.annotation.CheckReturnValue;
/*   18:     */ import javax.annotation.Nullable;
/*   19:     */ 
/*   20:     */ @GwtCompatible
/*   21:     */ public final class Multisets
/*   22:     */ {
/*   23:     */   public static <E> Multiset<E> unmodifiableMultiset(Multiset<? extends E> multiset)
/*   24:     */   {
/*   25:  74 */     if (((multiset instanceof UnmodifiableMultiset)) || ((multiset instanceof ImmutableMultiset)))
/*   26:     */     {
/*   27:  77 */       Multiset<E> result = multiset;
/*   28:  78 */       return result;
/*   29:     */     }
/*   30:  80 */     return new UnmodifiableMultiset((Multiset)Preconditions.checkNotNull(multiset));
/*   31:     */   }
/*   32:     */   
/*   33:     */   @Deprecated
/*   34:     */   public static <E> Multiset<E> unmodifiableMultiset(ImmutableMultiset<E> multiset)
/*   35:     */   {
/*   36:  91 */     return (Multiset)Preconditions.checkNotNull(multiset);
/*   37:     */   }
/*   38:     */   
/*   39:     */   static class UnmodifiableMultiset<E>
/*   40:     */     extends ForwardingMultiset<E>
/*   41:     */     implements Serializable
/*   42:     */   {
/*   43:     */     final Multiset<? extends E> delegate;
/*   44:     */     transient Set<E> elementSet;
/*   45:     */     transient Set<Multiset.Entry<E>> entrySet;
/*   46:     */     private static final long serialVersionUID = 0L;
/*   47:     */     
/*   48:     */     UnmodifiableMultiset(Multiset<? extends E> delegate)
/*   49:     */     {
/*   50:  98 */       this.delegate = delegate;
/*   51:     */     }
/*   52:     */     
/*   53:     */     protected Multiset<E> delegate()
/*   54:     */     {
/*   55: 105 */       return this.delegate;
/*   56:     */     }
/*   57:     */     
/*   58:     */     Set<E> createElementSet()
/*   59:     */     {
/*   60: 111 */       return Collections.unmodifiableSet(this.delegate.elementSet());
/*   61:     */     }
/*   62:     */     
/*   63:     */     public Set<E> elementSet()
/*   64:     */     {
/*   65: 116 */       Set<E> es = this.elementSet;
/*   66: 117 */       return es == null ? (this.elementSet = createElementSet()) : es;
/*   67:     */     }
/*   68:     */     
/*   69:     */     public Set<Multiset.Entry<E>> entrySet()
/*   70:     */     {
/*   71: 125 */       Set<Multiset.Entry<E>> es = this.entrySet;
/*   72: 126 */       return es == null ? (this.entrySet = Collections.unmodifiableSet(this.delegate.entrySet())) : es;
/*   73:     */     }
/*   74:     */     
/*   75:     */     public Iterator<E> iterator()
/*   76:     */     {
/*   77: 137 */       return Iterators.unmodifiableIterator(this.delegate.iterator());
/*   78:     */     }
/*   79:     */     
/*   80:     */     public boolean add(E element)
/*   81:     */     {
/*   82: 142 */       throw new UnsupportedOperationException();
/*   83:     */     }
/*   84:     */     
/*   85:     */     public int add(E element, int occurences)
/*   86:     */     {
/*   87: 147 */       throw new UnsupportedOperationException();
/*   88:     */     }
/*   89:     */     
/*   90:     */     public boolean addAll(Collection<? extends E> elementsToAdd)
/*   91:     */     {
/*   92: 152 */       throw new UnsupportedOperationException();
/*   93:     */     }
/*   94:     */     
/*   95:     */     public boolean remove(Object element)
/*   96:     */     {
/*   97: 157 */       throw new UnsupportedOperationException();
/*   98:     */     }
/*   99:     */     
/*  100:     */     public int remove(Object element, int occurrences)
/*  101:     */     {
/*  102: 162 */       throw new UnsupportedOperationException();
/*  103:     */     }
/*  104:     */     
/*  105:     */     public boolean removeAll(Collection<?> elementsToRemove)
/*  106:     */     {
/*  107: 167 */       throw new UnsupportedOperationException();
/*  108:     */     }
/*  109:     */     
/*  110:     */     public boolean retainAll(Collection<?> elementsToRetain)
/*  111:     */     {
/*  112: 172 */       throw new UnsupportedOperationException();
/*  113:     */     }
/*  114:     */     
/*  115:     */     public void clear()
/*  116:     */     {
/*  117: 177 */       throw new UnsupportedOperationException();
/*  118:     */     }
/*  119:     */     
/*  120:     */     public int setCount(E element, int count)
/*  121:     */     {
/*  122: 182 */       throw new UnsupportedOperationException();
/*  123:     */     }
/*  124:     */     
/*  125:     */     public boolean setCount(E element, int oldCount, int newCount)
/*  126:     */     {
/*  127: 187 */       throw new UnsupportedOperationException();
/*  128:     */     }
/*  129:     */   }
/*  130:     */   
/*  131:     */   @Beta
/*  132:     */   public static <E> SortedMultiset<E> unmodifiableSortedMultiset(SortedMultiset<E> sortedMultiset)
/*  133:     */   {
/*  134: 210 */     return new UnmodifiableSortedMultiset((SortedMultiset)Preconditions.checkNotNull(sortedMultiset));
/*  135:     */   }
/*  136:     */   
/*  137:     */   public static <E> Multiset.Entry<E> immutableEntry(@Nullable E e, int n)
/*  138:     */   {
/*  139: 222 */     return new ImmutableEntry(e, n);
/*  140:     */   }
/*  141:     */   
/*  142:     */   static class ImmutableEntry<E>
/*  143:     */     extends Multisets.AbstractEntry<E>
/*  144:     */     implements Serializable
/*  145:     */   {
/*  146:     */     @Nullable
/*  147:     */     private final E element;
/*  148:     */     private final int count;
/*  149:     */     private static final long serialVersionUID = 0L;
/*  150:     */     
/*  151:     */     ImmutableEntry(@Nullable E element, int count)
/*  152:     */     {
/*  153: 230 */       this.element = element;
/*  154: 231 */       this.count = count;
/*  155: 232 */       CollectPreconditions.checkNonnegative(count, "count");
/*  156:     */     }
/*  157:     */     
/*  158:     */     @Nullable
/*  159:     */     public final E getElement()
/*  160:     */     {
/*  161: 238 */       return this.element;
/*  162:     */     }
/*  163:     */     
/*  164:     */     public final int getCount()
/*  165:     */     {
/*  166: 243 */       return this.count;
/*  167:     */     }
/*  168:     */     
/*  169:     */     public ImmutableEntry<E> nextInBucket()
/*  170:     */     {
/*  171: 247 */       return null;
/*  172:     */     }
/*  173:     */   }
/*  174:     */   
/*  175:     */   @CheckReturnValue
/*  176:     */   @Beta
/*  177:     */   public static <E> Multiset<E> filter(Multiset<E> unfiltered, Predicate<? super E> predicate)
/*  178:     */   {
/*  179: 282 */     if ((unfiltered instanceof FilteredMultiset))
/*  180:     */     {
/*  181: 285 */       FilteredMultiset<E> filtered = (FilteredMultiset)unfiltered;
/*  182: 286 */       Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*  183: 287 */       return new FilteredMultiset(filtered.unfiltered, combinedPredicate);
/*  184:     */     }
/*  185: 289 */     return new FilteredMultiset(unfiltered, predicate);
/*  186:     */   }
/*  187:     */   
/*  188:     */   private static final class FilteredMultiset<E>
/*  189:     */     extends AbstractMultiset<E>
/*  190:     */   {
/*  191:     */     final Multiset<E> unfiltered;
/*  192:     */     final Predicate<? super E> predicate;
/*  193:     */     
/*  194:     */     FilteredMultiset(Multiset<E> unfiltered, Predicate<? super E> predicate)
/*  195:     */     {
/*  196: 297 */       this.unfiltered = ((Multiset)Preconditions.checkNotNull(unfiltered));
/*  197: 298 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/*  198:     */     }
/*  199:     */     
/*  200:     */     public UnmodifiableIterator<E> iterator()
/*  201:     */     {
/*  202: 303 */       return Iterators.filter(this.unfiltered.iterator(), this.predicate);
/*  203:     */     }
/*  204:     */     
/*  205:     */     Set<E> createElementSet()
/*  206:     */     {
/*  207: 308 */       return Sets.filter(this.unfiltered.elementSet(), this.predicate);
/*  208:     */     }
/*  209:     */     
/*  210:     */     Set<Multiset.Entry<E>> createEntrySet()
/*  211:     */     {
/*  212: 313 */       Sets.filter(this.unfiltered.entrySet(), new Predicate()
/*  213:     */       {
/*  214:     */         public boolean apply(Multiset.Entry<E> entry)
/*  215:     */         {
/*  216: 318 */           return Multisets.FilteredMultiset.this.predicate.apply(entry.getElement());
/*  217:     */         }
/*  218:     */       });
/*  219:     */     }
/*  220:     */     
/*  221:     */     Iterator<Multiset.Entry<E>> entryIterator()
/*  222:     */     {
/*  223: 325 */       throw new AssertionError("should never be called");
/*  224:     */     }
/*  225:     */     
/*  226:     */     int distinctElements()
/*  227:     */     {
/*  228: 330 */       return elementSet().size();
/*  229:     */     }
/*  230:     */     
/*  231:     */     public int count(@Nullable Object element)
/*  232:     */     {
/*  233: 335 */       int count = this.unfiltered.count(element);
/*  234: 336 */       if (count > 0)
/*  235:     */       {
/*  236: 338 */         E e = element;
/*  237: 339 */         return this.predicate.apply(e) ? count : 0;
/*  238:     */       }
/*  239: 341 */       return 0;
/*  240:     */     }
/*  241:     */     
/*  242:     */     public int add(@Nullable E element, int occurrences)
/*  243:     */     {
/*  244: 346 */       Preconditions.checkArgument(this.predicate.apply(element), "Element %s does not match predicate %s", new Object[] { element, this.predicate });
/*  245:     */       
/*  246: 348 */       return this.unfiltered.add(element, occurrences);
/*  247:     */     }
/*  248:     */     
/*  249:     */     public int remove(@Nullable Object element, int occurrences)
/*  250:     */     {
/*  251: 353 */       CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/*  252: 354 */       if (occurrences == 0) {
/*  253: 355 */         return count(element);
/*  254:     */       }
/*  255: 357 */       return contains(element) ? this.unfiltered.remove(element, occurrences) : 0;
/*  256:     */     }
/*  257:     */     
/*  258:     */     public void clear()
/*  259:     */     {
/*  260: 363 */       elementSet().clear();
/*  261:     */     }
/*  262:     */   }
/*  263:     */   
/*  264:     */   static int inferDistinctElements(Iterable<?> elements)
/*  265:     */   {
/*  266: 374 */     if ((elements instanceof Multiset)) {
/*  267: 375 */       return ((Multiset)elements).elementSet().size();
/*  268:     */     }
/*  269: 377 */     return 11;
/*  270:     */   }
/*  271:     */   
/*  272:     */   @Beta
/*  273:     */   public static <E> Multiset<E> union(Multiset<? extends E> multiset1, final Multiset<? extends E> multiset2)
/*  274:     */   {
/*  275: 398 */     Preconditions.checkNotNull(multiset1);
/*  276: 399 */     Preconditions.checkNotNull(multiset2);
/*  277:     */     
/*  278: 401 */     new AbstractMultiset()
/*  279:     */     {
/*  280:     */       public boolean contains(@Nullable Object element)
/*  281:     */       {
/*  282: 404 */         return (this.val$multiset1.contains(element)) || (multiset2.contains(element));
/*  283:     */       }
/*  284:     */       
/*  285:     */       public boolean isEmpty()
/*  286:     */       {
/*  287: 409 */         return (this.val$multiset1.isEmpty()) && (multiset2.isEmpty());
/*  288:     */       }
/*  289:     */       
/*  290:     */       public int count(Object element)
/*  291:     */       {
/*  292: 414 */         return Math.max(this.val$multiset1.count(element), multiset2.count(element));
/*  293:     */       }
/*  294:     */       
/*  295:     */       Set<E> createElementSet()
/*  296:     */       {
/*  297: 419 */         return Sets.union(this.val$multiset1.elementSet(), multiset2.elementSet());
/*  298:     */       }
/*  299:     */       
/*  300:     */       Iterator<Multiset.Entry<E>> entryIterator()
/*  301:     */       {
/*  302: 424 */         final Iterator<? extends Multiset.Entry<? extends E>> iterator1 = this.val$multiset1.entrySet().iterator();
/*  303: 425 */         final Iterator<? extends Multiset.Entry<? extends E>> iterator2 = multiset2.entrySet().iterator();
/*  304:     */         
/*  305: 427 */         new AbstractIterator()
/*  306:     */         {
/*  307:     */           protected Multiset.Entry<E> computeNext()
/*  308:     */           {
/*  309: 430 */             if (iterator1.hasNext())
/*  310:     */             {
/*  311: 431 */               Multiset.Entry<? extends E> entry1 = (Multiset.Entry)iterator1.next();
/*  312: 432 */               E element = entry1.getElement();
/*  313: 433 */               int count = Math.max(entry1.getCount(), Multisets.1.this.val$multiset2.count(element));
/*  314: 434 */               return Multisets.immutableEntry(element, count);
/*  315:     */             }
/*  316: 436 */             while (iterator2.hasNext())
/*  317:     */             {
/*  318: 437 */               Multiset.Entry<? extends E> entry2 = (Multiset.Entry)iterator2.next();
/*  319: 438 */               E element = entry2.getElement();
/*  320: 439 */               if (!Multisets.1.this.val$multiset1.contains(element)) {
/*  321: 440 */                 return Multisets.immutableEntry(element, entry2.getCount());
/*  322:     */               }
/*  323:     */             }
/*  324: 443 */             return (Multiset.Entry)endOfData();
/*  325:     */           }
/*  326:     */         };
/*  327:     */       }
/*  328:     */       
/*  329:     */       int distinctElements()
/*  330:     */       {
/*  331: 450 */         return elementSet().size();
/*  332:     */       }
/*  333:     */     };
/*  334:     */   }
/*  335:     */   
/*  336:     */   public static <E> Multiset<E> intersection(Multiset<E> multiset1, final Multiset<?> multiset2)
/*  337:     */   {
/*  338: 471 */     Preconditions.checkNotNull(multiset1);
/*  339: 472 */     Preconditions.checkNotNull(multiset2);
/*  340:     */     
/*  341: 474 */     new AbstractMultiset()
/*  342:     */     {
/*  343:     */       public int count(Object element)
/*  344:     */       {
/*  345: 477 */         int count1 = this.val$multiset1.count(element);
/*  346: 478 */         return count1 == 0 ? 0 : Math.min(count1, multiset2.count(element));
/*  347:     */       }
/*  348:     */       
/*  349:     */       Set<E> createElementSet()
/*  350:     */       {
/*  351: 483 */         return Sets.intersection(this.val$multiset1.elementSet(), multiset2.elementSet());
/*  352:     */       }
/*  353:     */       
/*  354:     */       Iterator<Multiset.Entry<E>> entryIterator()
/*  355:     */       {
/*  356: 488 */         final Iterator<Multiset.Entry<E>> iterator1 = this.val$multiset1.entrySet().iterator();
/*  357:     */         
/*  358: 490 */         new AbstractIterator()
/*  359:     */         {
/*  360:     */           protected Multiset.Entry<E> computeNext()
/*  361:     */           {
/*  362: 493 */             while (iterator1.hasNext())
/*  363:     */             {
/*  364: 494 */               Multiset.Entry<E> entry1 = (Multiset.Entry)iterator1.next();
/*  365: 495 */               E element = entry1.getElement();
/*  366: 496 */               int count = Math.min(entry1.getCount(), Multisets.2.this.val$multiset2.count(element));
/*  367: 497 */               if (count > 0) {
/*  368: 498 */                 return Multisets.immutableEntry(element, count);
/*  369:     */               }
/*  370:     */             }
/*  371: 501 */             return (Multiset.Entry)endOfData();
/*  372:     */           }
/*  373:     */         };
/*  374:     */       }
/*  375:     */       
/*  376:     */       int distinctElements()
/*  377:     */       {
/*  378: 508 */         return elementSet().size();
/*  379:     */       }
/*  380:     */     };
/*  381:     */   }
/*  382:     */   
/*  383:     */   @Beta
/*  384:     */   public static <E> Multiset<E> sum(Multiset<? extends E> multiset1, final Multiset<? extends E> multiset2)
/*  385:     */   {
/*  386: 531 */     Preconditions.checkNotNull(multiset1);
/*  387: 532 */     Preconditions.checkNotNull(multiset2);
/*  388:     */     
/*  389:     */ 
/*  390: 535 */     new AbstractMultiset()
/*  391:     */     {
/*  392:     */       public boolean contains(@Nullable Object element)
/*  393:     */       {
/*  394: 538 */         return (this.val$multiset1.contains(element)) || (multiset2.contains(element));
/*  395:     */       }
/*  396:     */       
/*  397:     */       public boolean isEmpty()
/*  398:     */       {
/*  399: 543 */         return (this.val$multiset1.isEmpty()) && (multiset2.isEmpty());
/*  400:     */       }
/*  401:     */       
/*  402:     */       public int size()
/*  403:     */       {
/*  404: 548 */         return this.val$multiset1.size() + multiset2.size();
/*  405:     */       }
/*  406:     */       
/*  407:     */       public int count(Object element)
/*  408:     */       {
/*  409: 553 */         return this.val$multiset1.count(element) + multiset2.count(element);
/*  410:     */       }
/*  411:     */       
/*  412:     */       Set<E> createElementSet()
/*  413:     */       {
/*  414: 558 */         return Sets.union(this.val$multiset1.elementSet(), multiset2.elementSet());
/*  415:     */       }
/*  416:     */       
/*  417:     */       Iterator<Multiset.Entry<E>> entryIterator()
/*  418:     */       {
/*  419: 563 */         final Iterator<? extends Multiset.Entry<? extends E>> iterator1 = this.val$multiset1.entrySet().iterator();
/*  420: 564 */         final Iterator<? extends Multiset.Entry<? extends E>> iterator2 = multiset2.entrySet().iterator();
/*  421: 565 */         new AbstractIterator()
/*  422:     */         {
/*  423:     */           protected Multiset.Entry<E> computeNext()
/*  424:     */           {
/*  425: 568 */             if (iterator1.hasNext())
/*  426:     */             {
/*  427: 569 */               Multiset.Entry<? extends E> entry1 = (Multiset.Entry)iterator1.next();
/*  428: 570 */               E element = entry1.getElement();
/*  429: 571 */               int count = entry1.getCount() + Multisets.3.this.val$multiset2.count(element);
/*  430: 572 */               return Multisets.immutableEntry(element, count);
/*  431:     */             }
/*  432: 574 */             while (iterator2.hasNext())
/*  433:     */             {
/*  434: 575 */               Multiset.Entry<? extends E> entry2 = (Multiset.Entry)iterator2.next();
/*  435: 576 */               E element = entry2.getElement();
/*  436: 577 */               if (!Multisets.3.this.val$multiset1.contains(element)) {
/*  437: 578 */                 return Multisets.immutableEntry(element, entry2.getCount());
/*  438:     */               }
/*  439:     */             }
/*  440: 581 */             return (Multiset.Entry)endOfData();
/*  441:     */           }
/*  442:     */         };
/*  443:     */       }
/*  444:     */       
/*  445:     */       int distinctElements()
/*  446:     */       {
/*  447: 588 */         return elementSet().size();
/*  448:     */       }
/*  449:     */     };
/*  450:     */   }
/*  451:     */   
/*  452:     */   @Beta
/*  453:     */   public static <E> Multiset<E> difference(Multiset<E> multiset1, final Multiset<?> multiset2)
/*  454:     */   {
/*  455: 611 */     Preconditions.checkNotNull(multiset1);
/*  456: 612 */     Preconditions.checkNotNull(multiset2);
/*  457:     */     
/*  458:     */ 
/*  459: 615 */     new AbstractMultiset()
/*  460:     */     {
/*  461:     */       public int count(@Nullable Object element)
/*  462:     */       {
/*  463: 618 */         int count1 = this.val$multiset1.count(element);
/*  464: 619 */         return count1 == 0 ? 0 : Math.max(0, count1 - multiset2.count(element));
/*  465:     */       }
/*  466:     */       
/*  467:     */       Iterator<Multiset.Entry<E>> entryIterator()
/*  468:     */       {
/*  469: 624 */         final Iterator<Multiset.Entry<E>> iterator1 = this.val$multiset1.entrySet().iterator();
/*  470: 625 */         new AbstractIterator()
/*  471:     */         {
/*  472:     */           protected Multiset.Entry<E> computeNext()
/*  473:     */           {
/*  474: 628 */             while (iterator1.hasNext())
/*  475:     */             {
/*  476: 629 */               Multiset.Entry<E> entry1 = (Multiset.Entry)iterator1.next();
/*  477: 630 */               E element = entry1.getElement();
/*  478: 631 */               int count = entry1.getCount() - Multisets.4.this.val$multiset2.count(element);
/*  479: 632 */               if (count > 0) {
/*  480: 633 */                 return Multisets.immutableEntry(element, count);
/*  481:     */               }
/*  482:     */             }
/*  483: 636 */             return (Multiset.Entry)endOfData();
/*  484:     */           }
/*  485:     */         };
/*  486:     */       }
/*  487:     */       
/*  488:     */       int distinctElements()
/*  489:     */       {
/*  490: 643 */         return Iterators.size(entryIterator());
/*  491:     */       }
/*  492:     */     };
/*  493:     */   }
/*  494:     */   
/*  495:     */   public static boolean containsOccurrences(Multiset<?> superMultiset, Multiset<?> subMultiset)
/*  496:     */   {
/*  497: 655 */     Preconditions.checkNotNull(superMultiset);
/*  498: 656 */     Preconditions.checkNotNull(subMultiset);
/*  499: 657 */     for (Multiset.Entry<?> entry : subMultiset.entrySet())
/*  500:     */     {
/*  501: 658 */       int superCount = superMultiset.count(entry.getElement());
/*  502: 659 */       if (superCount < entry.getCount()) {
/*  503: 660 */         return false;
/*  504:     */       }
/*  505:     */     }
/*  506: 663 */     return true;
/*  507:     */   }
/*  508:     */   
/*  509:     */   public static boolean retainOccurrences(Multiset<?> multisetToModify, Multiset<?> multisetToRetain)
/*  510:     */   {
/*  511: 687 */     return retainOccurrencesImpl(multisetToModify, multisetToRetain);
/*  512:     */   }
/*  513:     */   
/*  514:     */   private static <E> boolean retainOccurrencesImpl(Multiset<E> multisetToModify, Multiset<?> occurrencesToRetain)
/*  515:     */   {
/*  516: 695 */     Preconditions.checkNotNull(multisetToModify);
/*  517: 696 */     Preconditions.checkNotNull(occurrencesToRetain);
/*  518:     */     
/*  519: 698 */     Iterator<Multiset.Entry<E>> entryIterator = multisetToModify.entrySet().iterator();
/*  520: 699 */     boolean changed = false;
/*  521: 700 */     while (entryIterator.hasNext())
/*  522:     */     {
/*  523: 701 */       Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  524: 702 */       int retainCount = occurrencesToRetain.count(entry.getElement());
/*  525: 703 */       if (retainCount == 0)
/*  526:     */       {
/*  527: 704 */         entryIterator.remove();
/*  528: 705 */         changed = true;
/*  529:     */       }
/*  530: 706 */       else if (retainCount < entry.getCount())
/*  531:     */       {
/*  532: 707 */         multisetToModify.setCount(entry.getElement(), retainCount);
/*  533: 708 */         changed = true;
/*  534:     */       }
/*  535:     */     }
/*  536: 711 */     return changed;
/*  537:     */   }
/*  538:     */   
/*  539:     */   public static boolean removeOccurrences(Multiset<?> multisetToModify, Iterable<?> occurrencesToRemove)
/*  540:     */   {
/*  541: 740 */     if ((occurrencesToRemove instanceof Multiset)) {
/*  542: 741 */       return removeOccurrences(multisetToModify, (Multiset)occurrencesToRemove);
/*  543:     */     }
/*  544: 743 */     Preconditions.checkNotNull(multisetToModify);
/*  545: 744 */     Preconditions.checkNotNull(occurrencesToRemove);
/*  546: 745 */     boolean changed = false;
/*  547: 746 */     for (Object o : occurrencesToRemove) {
/*  548: 747 */       changed |= multisetToModify.remove(o);
/*  549:     */     }
/*  550: 749 */     return changed;
/*  551:     */   }
/*  552:     */   
/*  553:     */   public static boolean removeOccurrences(Multiset<?> multisetToModify, Multiset<?> occurrencesToRemove)
/*  554:     */   {
/*  555: 778 */     Preconditions.checkNotNull(multisetToModify);
/*  556: 779 */     Preconditions.checkNotNull(occurrencesToRemove);
/*  557:     */     
/*  558: 781 */     boolean changed = false;
/*  559: 782 */     Iterator<? extends Multiset.Entry<?>> entryIterator = multisetToModify.entrySet().iterator();
/*  560: 783 */     while (entryIterator.hasNext())
/*  561:     */     {
/*  562: 784 */       Multiset.Entry<?> entry = (Multiset.Entry)entryIterator.next();
/*  563: 785 */       int removeCount = occurrencesToRemove.count(entry.getElement());
/*  564: 786 */       if (removeCount >= entry.getCount())
/*  565:     */       {
/*  566: 787 */         entryIterator.remove();
/*  567: 788 */         changed = true;
/*  568:     */       }
/*  569: 789 */       else if (removeCount > 0)
/*  570:     */       {
/*  571: 790 */         multisetToModify.remove(entry.getElement(), removeCount);
/*  572: 791 */         changed = true;
/*  573:     */       }
/*  574:     */     }
/*  575: 794 */     return changed;
/*  576:     */   }
/*  577:     */   
/*  578:     */   static abstract class AbstractEntry<E>
/*  579:     */     implements Multiset.Entry<E>
/*  580:     */   {
/*  581:     */     public boolean equals(@Nullable Object object)
/*  582:     */     {
/*  583: 808 */       if ((object instanceof Multiset.Entry))
/*  584:     */       {
/*  585: 809 */         Multiset.Entry<?> that = (Multiset.Entry)object;
/*  586: 810 */         return (getCount() == that.getCount()) && (Objects.equal(getElement(), that.getElement()));
/*  587:     */       }
/*  588: 813 */       return false;
/*  589:     */     }
/*  590:     */     
/*  591:     */     public int hashCode()
/*  592:     */     {
/*  593: 822 */       E e = getElement();
/*  594: 823 */       return (e == null ? 0 : e.hashCode()) ^ getCount();
/*  595:     */     }
/*  596:     */     
/*  597:     */     public String toString()
/*  598:     */     {
/*  599: 835 */       String text = String.valueOf(getElement());
/*  600: 836 */       int n = getCount();
/*  601: 837 */       return text + " x " + n;
/*  602:     */     }
/*  603:     */   }
/*  604:     */   
/*  605:     */   static boolean equalsImpl(Multiset<?> multiset, @Nullable Object object)
/*  606:     */   {
/*  607: 845 */     if (object == multiset) {
/*  608: 846 */       return true;
/*  609:     */     }
/*  610: 848 */     if ((object instanceof Multiset))
/*  611:     */     {
/*  612: 849 */       Multiset<?> that = (Multiset)object;
/*  613: 856 */       if ((multiset.size() != that.size()) || (multiset.entrySet().size() != that.entrySet().size())) {
/*  614: 857 */         return false;
/*  615:     */       }
/*  616: 859 */       for (Multiset.Entry<?> entry : that.entrySet()) {
/*  617: 860 */         if (multiset.count(entry.getElement()) != entry.getCount()) {
/*  618: 861 */           return false;
/*  619:     */         }
/*  620:     */       }
/*  621: 864 */       return true;
/*  622:     */     }
/*  623: 866 */     return false;
/*  624:     */   }
/*  625:     */   
/*  626:     */   static <E> boolean addAllImpl(Multiset<E> self, Collection<? extends E> elements)
/*  627:     */   {
/*  628: 873 */     if (elements.isEmpty()) {
/*  629: 874 */       return false;
/*  630:     */     }
/*  631: 876 */     if ((elements instanceof Multiset))
/*  632:     */     {
/*  633: 877 */       Multiset<? extends E> that = cast(elements);
/*  634: 878 */       for (Multiset.Entry<? extends E> entry : that.entrySet()) {
/*  635: 879 */         self.add(entry.getElement(), entry.getCount());
/*  636:     */       }
/*  637:     */     }
/*  638:     */     else
/*  639:     */     {
/*  640: 882 */       Iterators.addAll(self, elements.iterator());
/*  641:     */     }
/*  642: 884 */     return true;
/*  643:     */   }
/*  644:     */   
/*  645:     */   static boolean removeAllImpl(Multiset<?> self, Collection<?> elementsToRemove)
/*  646:     */   {
/*  647: 891 */     Collection<?> collection = (elementsToRemove instanceof Multiset) ? ((Multiset)elementsToRemove).elementSet() : elementsToRemove;
/*  648:     */     
/*  649:     */ 
/*  650:     */ 
/*  651:     */ 
/*  652: 896 */     return self.elementSet().removeAll(collection);
/*  653:     */   }
/*  654:     */   
/*  655:     */   static boolean retainAllImpl(Multiset<?> self, Collection<?> elementsToRetain)
/*  656:     */   {
/*  657: 903 */     Preconditions.checkNotNull(elementsToRetain);
/*  658: 904 */     Collection<?> collection = (elementsToRetain instanceof Multiset) ? ((Multiset)elementsToRetain).elementSet() : elementsToRetain;
/*  659:     */     
/*  660:     */ 
/*  661:     */ 
/*  662:     */ 
/*  663: 909 */     return self.elementSet().retainAll(collection);
/*  664:     */   }
/*  665:     */   
/*  666:     */   static <E> int setCountImpl(Multiset<E> self, E element, int count)
/*  667:     */   {
/*  668: 916 */     CollectPreconditions.checkNonnegative(count, "count");
/*  669:     */     
/*  670: 918 */     int oldCount = self.count(element);
/*  671:     */     
/*  672: 920 */     int delta = count - oldCount;
/*  673: 921 */     if (delta > 0) {
/*  674: 922 */       self.add(element, delta);
/*  675: 923 */     } else if (delta < 0) {
/*  676: 924 */       self.remove(element, -delta);
/*  677:     */     }
/*  678: 927 */     return oldCount;
/*  679:     */   }
/*  680:     */   
/*  681:     */   static <E> boolean setCountImpl(Multiset<E> self, E element, int oldCount, int newCount)
/*  682:     */   {
/*  683: 934 */     CollectPreconditions.checkNonnegative(oldCount, "oldCount");
/*  684: 935 */     CollectPreconditions.checkNonnegative(newCount, "newCount");
/*  685: 937 */     if (self.count(element) == oldCount)
/*  686:     */     {
/*  687: 938 */       self.setCount(element, newCount);
/*  688: 939 */       return true;
/*  689:     */     }
/*  690: 941 */     return false;
/*  691:     */   }
/*  692:     */   
/*  693:     */   static abstract class ElementSet<E>
/*  694:     */     extends Sets.ImprovedAbstractSet<E>
/*  695:     */   {
/*  696:     */     abstract Multiset<E> multiset();
/*  697:     */     
/*  698:     */     public void clear()
/*  699:     */     {
/*  700: 950 */       multiset().clear();
/*  701:     */     }
/*  702:     */     
/*  703:     */     public boolean contains(Object o)
/*  704:     */     {
/*  705: 955 */       return multiset().contains(o);
/*  706:     */     }
/*  707:     */     
/*  708:     */     public boolean containsAll(Collection<?> c)
/*  709:     */     {
/*  710: 960 */       return multiset().containsAll(c);
/*  711:     */     }
/*  712:     */     
/*  713:     */     public boolean isEmpty()
/*  714:     */     {
/*  715: 965 */       return multiset().isEmpty();
/*  716:     */     }
/*  717:     */     
/*  718:     */     public Iterator<E> iterator()
/*  719:     */     {
/*  720: 970 */       new TransformedIterator(multiset().entrySet().iterator())
/*  721:     */       {
/*  722:     */         E transform(Multiset.Entry<E> entry)
/*  723:     */         {
/*  724: 973 */           return entry.getElement();
/*  725:     */         }
/*  726:     */       };
/*  727:     */     }
/*  728:     */     
/*  729:     */     public boolean remove(Object o)
/*  730:     */     {
/*  731: 980 */       return multiset().remove(o, 2147483647) > 0;
/*  732:     */     }
/*  733:     */     
/*  734:     */     public int size()
/*  735:     */     {
/*  736: 985 */       return multiset().entrySet().size();
/*  737:     */     }
/*  738:     */   }
/*  739:     */   
/*  740:     */   static abstract class EntrySet<E>
/*  741:     */     extends Sets.ImprovedAbstractSet<Multiset.Entry<E>>
/*  742:     */   {
/*  743:     */     abstract Multiset<E> multiset();
/*  744:     */     
/*  745:     */     public boolean contains(@Nullable Object o)
/*  746:     */     {
/*  747: 994 */       if ((o instanceof Multiset.Entry))
/*  748:     */       {
/*  749: 999 */         Multiset.Entry<?> entry = (Multiset.Entry)o;
/*  750:1000 */         if (entry.getCount() <= 0) {
/*  751:1001 */           return false;
/*  752:     */         }
/*  753:1003 */         int count = multiset().count(entry.getElement());
/*  754:1004 */         return count == entry.getCount();
/*  755:     */       }
/*  756:1006 */       return false;
/*  757:     */     }
/*  758:     */     
/*  759:     */     public boolean remove(Object object)
/*  760:     */     {
/*  761:1013 */       if ((object instanceof Multiset.Entry))
/*  762:     */       {
/*  763:1014 */         Multiset.Entry<?> entry = (Multiset.Entry)object;
/*  764:1015 */         Object element = entry.getElement();
/*  765:1016 */         int entryCount = entry.getCount();
/*  766:1017 */         if (entryCount != 0)
/*  767:     */         {
/*  768:1020 */           Multiset<Object> multiset = multiset();
/*  769:1021 */           return multiset.setCount(element, entryCount, 0);
/*  770:     */         }
/*  771:     */       }
/*  772:1024 */       return false;
/*  773:     */     }
/*  774:     */     
/*  775:     */     public void clear()
/*  776:     */     {
/*  777:1029 */       multiset().clear();
/*  778:     */     }
/*  779:     */   }
/*  780:     */   
/*  781:     */   static <E> Iterator<E> iteratorImpl(Multiset<E> multiset)
/*  782:     */   {
/*  783:1037 */     return new MultisetIteratorImpl(multiset, multiset.entrySet().iterator());
/*  784:     */   }
/*  785:     */   
/*  786:     */   static final class MultisetIteratorImpl<E>
/*  787:     */     implements Iterator<E>
/*  788:     */   {
/*  789:     */     private final Multiset<E> multiset;
/*  790:     */     private final Iterator<Multiset.Entry<E>> entryIterator;
/*  791:     */     private Multiset.Entry<E> currentEntry;
/*  792:     */     private int laterCount;
/*  793:     */     private int totalCount;
/*  794:     */     private boolean canRemove;
/*  795:     */     
/*  796:     */     MultisetIteratorImpl(Multiset<E> multiset, Iterator<Multiset.Entry<E>> entryIterator)
/*  797:     */     {
/*  798:1054 */       this.multiset = multiset;
/*  799:1055 */       this.entryIterator = entryIterator;
/*  800:     */     }
/*  801:     */     
/*  802:     */     public boolean hasNext()
/*  803:     */     {
/*  804:1060 */       return (this.laterCount > 0) || (this.entryIterator.hasNext());
/*  805:     */     }
/*  806:     */     
/*  807:     */     public E next()
/*  808:     */     {
/*  809:1065 */       if (!hasNext()) {
/*  810:1066 */         throw new NoSuchElementException();
/*  811:     */       }
/*  812:1068 */       if (this.laterCount == 0)
/*  813:     */       {
/*  814:1069 */         this.currentEntry = ((Multiset.Entry)this.entryIterator.next());
/*  815:1070 */         this.totalCount = (this.laterCount = this.currentEntry.getCount());
/*  816:     */       }
/*  817:1072 */       this.laterCount -= 1;
/*  818:1073 */       this.canRemove = true;
/*  819:1074 */       return this.currentEntry.getElement();
/*  820:     */     }
/*  821:     */     
/*  822:     */     public void remove()
/*  823:     */     {
/*  824:1079 */       CollectPreconditions.checkRemove(this.canRemove);
/*  825:1080 */       if (this.totalCount == 1) {
/*  826:1081 */         this.entryIterator.remove();
/*  827:     */       } else {
/*  828:1083 */         this.multiset.remove(this.currentEntry.getElement());
/*  829:     */       }
/*  830:1085 */       this.totalCount -= 1;
/*  831:1086 */       this.canRemove = false;
/*  832:     */     }
/*  833:     */   }
/*  834:     */   
/*  835:     */   static int sizeImpl(Multiset<?> multiset)
/*  836:     */   {
/*  837:1094 */     long size = 0L;
/*  838:1095 */     for (Multiset.Entry<?> entry : multiset.entrySet()) {
/*  839:1096 */       size += entry.getCount();
/*  840:     */     }
/*  841:1098 */     return Ints.saturatedCast(size);
/*  842:     */   }
/*  843:     */   
/*  844:     */   static <T> Multiset<T> cast(Iterable<T> iterable)
/*  845:     */   {
/*  846:1105 */     return (Multiset)iterable;
/*  847:     */   }
/*  848:     */   
/*  849:1108 */   private static final Ordering<Multiset.Entry<?>> DECREASING_COUNT_ORDERING = new Ordering()
/*  850:     */   {
/*  851:     */     public int compare(Multiset.Entry<?> entry1, Multiset.Entry<?> entry2)
/*  852:     */     {
/*  853:1112 */       return Ints.compare(entry2.getCount(), entry1.getCount());
/*  854:     */     }
/*  855:     */   };
/*  856:     */   
/*  857:     */   @Beta
/*  858:     */   public static <E> ImmutableMultiset<E> copyHighestCountFirst(Multiset<E> multiset)
/*  859:     */   {
/*  860:1124 */     List<Multiset.Entry<E>> sortedEntries = DECREASING_COUNT_ORDERING.immutableSortedCopy(multiset.entrySet());
/*  861:     */     
/*  862:1126 */     return ImmutableMultiset.copyFromEntries(sortedEntries);
/*  863:     */   }
/*  864:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Multisets
 * JD-Core Version:    0.7.0.1
 */