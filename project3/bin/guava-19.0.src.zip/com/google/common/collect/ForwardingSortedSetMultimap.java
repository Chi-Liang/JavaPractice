/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Comparator;
/*  5:   */ import java.util.SortedSet;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ public abstract class ForwardingSortedSetMultimap<K, V>
/* 10:   */   extends ForwardingSetMultimap<K, V>
/* 11:   */   implements SortedSetMultimap<K, V>
/* 12:   */ {
/* 13:   */   protected abstract SortedSetMultimap<K, V> delegate();
/* 14:   */   
/* 15:   */   public SortedSet<V> get(@Nullable K key)
/* 16:   */   {
/* 17:47 */     return delegate().get(key);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public SortedSet<V> removeAll(@Nullable Object key)
/* 21:   */   {
/* 22:52 */     return delegate().removeAll(key);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public SortedSet<V> replaceValues(K key, Iterable<? extends V> values)
/* 26:   */   {
/* 27:57 */     return delegate().replaceValues(key, values);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Comparator<? super V> valueComparator()
/* 31:   */   {
/* 32:62 */     return delegate().valueComparator();
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingSortedSetMultimap
 * JD-Core Version:    0.7.0.1
 */