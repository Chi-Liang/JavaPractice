/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.NoSuchElementException;
/*   8:    */ import java.util.SortedMap;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ public abstract class ForwardingSortedMap<K, V>
/*  13:    */   extends ForwardingMap<K, V>
/*  14:    */   implements SortedMap<K, V>
/*  15:    */ {
/*  16:    */   protected abstract SortedMap<K, V> delegate();
/*  17:    */   
/*  18:    */   public Comparator<? super K> comparator()
/*  19:    */   {
/*  20: 68 */     return delegate().comparator();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public K firstKey()
/*  24:    */   {
/*  25: 73 */     return delegate().firstKey();
/*  26:    */   }
/*  27:    */   
/*  28:    */   public SortedMap<K, V> headMap(K toKey)
/*  29:    */   {
/*  30: 78 */     return delegate().headMap(toKey);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public K lastKey()
/*  34:    */   {
/*  35: 83 */     return delegate().lastKey();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public SortedMap<K, V> subMap(K fromKey, K toKey)
/*  39:    */   {
/*  40: 88 */     return delegate().subMap(fromKey, toKey);
/*  41:    */   }
/*  42:    */   
/*  43:    */   public SortedMap<K, V> tailMap(K fromKey)
/*  44:    */   {
/*  45: 93 */     return delegate().tailMap(fromKey);
/*  46:    */   }
/*  47:    */   
/*  48:    */   @Beta
/*  49:    */   protected class StandardKeySet
/*  50:    */     extends Maps.SortedKeySet<K, V>
/*  51:    */   {
/*  52:    */     public StandardKeySet()
/*  53:    */     {
/*  54:107 */       super();
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   private int unsafeCompare(Object k1, Object k2)
/*  59:    */   {
/*  60:114 */     Comparator<? super K> comparator = comparator();
/*  61:115 */     if (comparator == null) {
/*  62:116 */       return ((Comparable)k1).compareTo(k2);
/*  63:    */     }
/*  64:118 */     return comparator.compare(k1, k2);
/*  65:    */   }
/*  66:    */   
/*  67:    */   @Beta
/*  68:    */   protected boolean standardContainsKey(@Nullable Object key)
/*  69:    */   {
/*  70:    */     try
/*  71:    */     {
/*  72:136 */       SortedMap<Object, V> self = this;
/*  73:137 */       Object ceilingKey = self.tailMap(key).firstKey();
/*  74:138 */       return unsafeCompare(ceilingKey, key) == 0;
/*  75:    */     }
/*  76:    */     catch (ClassCastException e)
/*  77:    */     {
/*  78:140 */       return false;
/*  79:    */     }
/*  80:    */     catch (NoSuchElementException e)
/*  81:    */     {
/*  82:142 */       return false;
/*  83:    */     }
/*  84:    */     catch (NullPointerException e) {}
/*  85:144 */     return false;
/*  86:    */   }
/*  87:    */   
/*  88:    */   @Beta
/*  89:    */   protected SortedMap<K, V> standardSubMap(K fromKey, K toKey)
/*  90:    */   {
/*  91:158 */     Preconditions.checkArgument(unsafeCompare(fromKey, toKey) <= 0, "fromKey must be <= toKey");
/*  92:159 */     return tailMap(fromKey).headMap(toKey);
/*  93:    */   }
/*  94:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingSortedMap
 * JD-Core Version:    0.7.0.1
 */