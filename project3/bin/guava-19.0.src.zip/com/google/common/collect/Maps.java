/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Converter;
/*    7:     */ import com.google.common.base.Equivalence;
/*    8:     */ import com.google.common.base.Function;
/*    9:     */ import com.google.common.base.Joiner;
/*   10:     */ import com.google.common.base.Joiner.MapJoiner;
/*   11:     */ import com.google.common.base.Objects;
/*   12:     */ import com.google.common.base.Preconditions;
/*   13:     */ import com.google.common.base.Predicate;
/*   14:     */ import com.google.common.base.Predicates;
/*   15:     */ import com.google.j2objc.annotations.Weak;
/*   16:     */ import java.io.Serializable;
/*   17:     */ import java.util.AbstractCollection;
/*   18:     */ import java.util.AbstractMap;
/*   19:     */ import java.util.ArrayList;
/*   20:     */ import java.util.Collection;
/*   21:     */ import java.util.Collections;
/*   22:     */ import java.util.Comparator;
/*   23:     */ import java.util.EnumMap;
/*   24:     */ import java.util.Enumeration;
/*   25:     */ import java.util.HashMap;
/*   26:     */ import java.util.IdentityHashMap;
/*   27:     */ import java.util.Iterator;
/*   28:     */ import java.util.LinkedHashMap;
/*   29:     */ import java.util.Map;
/*   30:     */ import java.util.Map.Entry;
/*   31:     */ import java.util.NavigableMap;
/*   32:     */ import java.util.NavigableSet;
/*   33:     */ import java.util.Properties;
/*   34:     */ import java.util.Set;
/*   35:     */ import java.util.SortedMap;
/*   36:     */ import java.util.SortedSet;
/*   37:     */ import java.util.TreeMap;
/*   38:     */ import java.util.concurrent.ConcurrentMap;
/*   39:     */ import javax.annotation.CheckReturnValue;
/*   40:     */ import javax.annotation.Nullable;
/*   41:     */ 
/*   42:     */ @GwtCompatible(emulated=true)
/*   43:     */ public final class Maps
/*   44:     */ {
/*   45:     */   private static abstract enum EntryFunction
/*   46:     */     implements Function<Map.Entry<?, ?>, Object>
/*   47:     */   {
/*   48:  89 */     KEY,  VALUE;
/*   49:     */     
/*   50:     */     private EntryFunction() {}
/*   51:     */   }
/*   52:     */   
/*   53:     */   static <K> Function<Map.Entry<K, ?>, K> keyFunction()
/*   54:     */   {
/*   55: 107 */     return EntryFunction.KEY;
/*   56:     */   }
/*   57:     */   
/*   58:     */   static <V> Function<Map.Entry<?, V>, V> valueFunction()
/*   59:     */   {
/*   60: 112 */     return EntryFunction.VALUE;
/*   61:     */   }
/*   62:     */   
/*   63:     */   static <K, V> Iterator<K> keyIterator(Iterator<Map.Entry<K, V>> entryIterator)
/*   64:     */   {
/*   65: 116 */     return Iterators.transform(entryIterator, keyFunction());
/*   66:     */   }
/*   67:     */   
/*   68:     */   static <K, V> Iterator<V> valueIterator(Iterator<Map.Entry<K, V>> entryIterator)
/*   69:     */   {
/*   70: 120 */     return Iterators.transform(entryIterator, valueFunction());
/*   71:     */   }
/*   72:     */   
/*   73:     */   @GwtCompatible(serializable=true)
/*   74:     */   @Beta
/*   75:     */   public static <K extends Enum<K>, V> ImmutableMap<K, V> immutableEnumMap(Map<K, ? extends V> map)
/*   76:     */   {
/*   77: 138 */     if ((map instanceof ImmutableEnumMap))
/*   78:     */     {
/*   79: 140 */       ImmutableEnumMap<K, V> result = (ImmutableEnumMap)map;
/*   80: 141 */       return result;
/*   81:     */     }
/*   82: 142 */     if (map.isEmpty()) {
/*   83: 143 */       return ImmutableMap.of();
/*   84:     */     }
/*   85: 145 */     for (Map.Entry<K, ? extends V> entry : map.entrySet())
/*   86:     */     {
/*   87: 146 */       Preconditions.checkNotNull(entry.getKey());
/*   88: 147 */       Preconditions.checkNotNull(entry.getValue());
/*   89:     */     }
/*   90: 149 */     return ImmutableEnumMap.asImmutable(new EnumMap(map));
/*   91:     */   }
/*   92:     */   
/*   93:     */   public static <K, V> HashMap<K, V> newHashMap()
/*   94:     */   {
/*   95: 165 */     return new HashMap();
/*   96:     */   }
/*   97:     */   
/*   98:     */   public static <K, V> HashMap<K, V> newHashMapWithExpectedSize(int expectedSize)
/*   99:     */   {
/*  100: 182 */     return new HashMap(capacity(expectedSize));
/*  101:     */   }
/*  102:     */   
/*  103:     */   static int capacity(int expectedSize)
/*  104:     */   {
/*  105: 191 */     if (expectedSize < 3)
/*  106:     */     {
/*  107: 192 */       CollectPreconditions.checkNonnegative(expectedSize, "expectedSize");
/*  108: 193 */       return expectedSize + 1;
/*  109:     */     }
/*  110: 195 */     if (expectedSize < 1073741824) {
/*  111: 199 */       return (int)(expectedSize / 0.75F + 1.0F);
/*  112:     */     }
/*  113: 201 */     return 2147483647;
/*  114:     */   }
/*  115:     */   
/*  116:     */   public static <K, V> HashMap<K, V> newHashMap(Map<? extends K, ? extends V> map)
/*  117:     */   {
/*  118: 219 */     return new HashMap(map);
/*  119:     */   }
/*  120:     */   
/*  121:     */   public static <K, V> LinkedHashMap<K, V> newLinkedHashMap()
/*  122:     */   {
/*  123: 232 */     return new LinkedHashMap();
/*  124:     */   }
/*  125:     */   
/*  126:     */   public static <K, V> LinkedHashMap<K, V> newLinkedHashMapWithExpectedSize(int expectedSize)
/*  127:     */   {
/*  128: 250 */     return new LinkedHashMap(capacity(expectedSize));
/*  129:     */   }
/*  130:     */   
/*  131:     */   public static <K, V> LinkedHashMap<K, V> newLinkedHashMap(Map<? extends K, ? extends V> map)
/*  132:     */   {
/*  133: 265 */     return new LinkedHashMap(map);
/*  134:     */   }
/*  135:     */   
/*  136:     */   public static <K, V> ConcurrentMap<K, V> newConcurrentMap()
/*  137:     */   {
/*  138: 284 */     return new MapMaker().makeMap();
/*  139:     */   }
/*  140:     */   
/*  141:     */   public static <K extends Comparable, V> TreeMap<K, V> newTreeMap()
/*  142:     */   {
/*  143: 297 */     return new TreeMap();
/*  144:     */   }
/*  145:     */   
/*  146:     */   public static <K, V> TreeMap<K, V> newTreeMap(SortedMap<K, ? extends V> map)
/*  147:     */   {
/*  148: 313 */     return new TreeMap(map);
/*  149:     */   }
/*  150:     */   
/*  151:     */   public static <C, K extends C, V> TreeMap<K, V> newTreeMap(@Nullable Comparator<C> comparator)
/*  152:     */   {
/*  153: 332 */     return new TreeMap(comparator);
/*  154:     */   }
/*  155:     */   
/*  156:     */   public static <K extends Enum<K>, V> EnumMap<K, V> newEnumMap(Class<K> type)
/*  157:     */   {
/*  158: 342 */     return new EnumMap((Class)Preconditions.checkNotNull(type));
/*  159:     */   }
/*  160:     */   
/*  161:     */   public static <K extends Enum<K>, V> EnumMap<K, V> newEnumMap(Map<K, ? extends V> map)
/*  162:     */   {
/*  163: 355 */     return new EnumMap(map);
/*  164:     */   }
/*  165:     */   
/*  166:     */   public static <K, V> IdentityHashMap<K, V> newIdentityHashMap()
/*  167:     */   {
/*  168: 364 */     return new IdentityHashMap();
/*  169:     */   }
/*  170:     */   
/*  171:     */   public static <K, V> MapDifference<K, V> difference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right)
/*  172:     */   {
/*  173: 386 */     if ((left instanceof SortedMap))
/*  174:     */     {
/*  175: 387 */       SortedMap<K, ? extends V> sortedLeft = (SortedMap)left;
/*  176: 388 */       SortedMapDifference<K, V> result = difference(sortedLeft, right);
/*  177: 389 */       return result;
/*  178:     */     }
/*  179: 391 */     return difference(left, right, Equivalence.equals());
/*  180:     */   }
/*  181:     */   
/*  182:     */   @Beta
/*  183:     */   public static <K, V> MapDifference<K, V> difference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right, Equivalence<? super V> valueEquivalence)
/*  184:     */   {
/*  185: 418 */     Preconditions.checkNotNull(valueEquivalence);
/*  186:     */     
/*  187: 420 */     Map<K, V> onlyOnLeft = newLinkedHashMap();
/*  188: 421 */     Map<K, V> onlyOnRight = new LinkedHashMap(right);
/*  189: 422 */     Map<K, V> onBoth = newLinkedHashMap();
/*  190: 423 */     Map<K, MapDifference.ValueDifference<V>> differences = newLinkedHashMap();
/*  191: 424 */     doDifference(left, right, valueEquivalence, onlyOnLeft, onlyOnRight, onBoth, differences);
/*  192: 425 */     return new MapDifferenceImpl(onlyOnLeft, onlyOnRight, onBoth, differences);
/*  193:     */   }
/*  194:     */   
/*  195:     */   private static <K, V> void doDifference(Map<? extends K, ? extends V> left, Map<? extends K, ? extends V> right, Equivalence<? super V> valueEquivalence, Map<K, V> onlyOnLeft, Map<K, V> onlyOnRight, Map<K, V> onBoth, Map<K, MapDifference.ValueDifference<V>> differences)
/*  196:     */   {
/*  197: 436 */     for (Map.Entry<? extends K, ? extends V> entry : left.entrySet())
/*  198:     */     {
/*  199: 437 */       K leftKey = entry.getKey();
/*  200: 438 */       V leftValue = entry.getValue();
/*  201: 439 */       if (right.containsKey(leftKey))
/*  202:     */       {
/*  203: 440 */         V rightValue = onlyOnRight.remove(leftKey);
/*  204: 441 */         if (valueEquivalence.equivalent(leftValue, rightValue)) {
/*  205: 442 */           onBoth.put(leftKey, leftValue);
/*  206:     */         } else {
/*  207: 444 */           differences.put(leftKey, ValueDifferenceImpl.create(leftValue, rightValue));
/*  208:     */         }
/*  209:     */       }
/*  210:     */       else
/*  211:     */       {
/*  212: 447 */         onlyOnLeft.put(leftKey, leftValue);
/*  213:     */       }
/*  214:     */     }
/*  215:     */   }
/*  216:     */   
/*  217:     */   private static <K, V> Map<K, V> unmodifiableMap(Map<K, V> map)
/*  218:     */   {
/*  219: 453 */     if ((map instanceof SortedMap)) {
/*  220: 454 */       return Collections.unmodifiableSortedMap((SortedMap)map);
/*  221:     */     }
/*  222: 456 */     return Collections.unmodifiableMap(map);
/*  223:     */   }
/*  224:     */   
/*  225:     */   static class MapDifferenceImpl<K, V>
/*  226:     */     implements MapDifference<K, V>
/*  227:     */   {
/*  228:     */     final Map<K, V> onlyOnLeft;
/*  229:     */     final Map<K, V> onlyOnRight;
/*  230:     */     final Map<K, V> onBoth;
/*  231:     */     final Map<K, MapDifference.ValueDifference<V>> differences;
/*  232:     */     
/*  233:     */     MapDifferenceImpl(Map<K, V> onlyOnLeft, Map<K, V> onlyOnRight, Map<K, V> onBoth, Map<K, MapDifference.ValueDifference<V>> differences)
/*  234:     */     {
/*  235: 471 */       this.onlyOnLeft = Maps.unmodifiableMap(onlyOnLeft);
/*  236: 472 */       this.onlyOnRight = Maps.unmodifiableMap(onlyOnRight);
/*  237: 473 */       this.onBoth = Maps.unmodifiableMap(onBoth);
/*  238: 474 */       this.differences = Maps.unmodifiableMap(differences);
/*  239:     */     }
/*  240:     */     
/*  241:     */     public boolean areEqual()
/*  242:     */     {
/*  243: 479 */       return (this.onlyOnLeft.isEmpty()) && (this.onlyOnRight.isEmpty()) && (this.differences.isEmpty());
/*  244:     */     }
/*  245:     */     
/*  246:     */     public Map<K, V> entriesOnlyOnLeft()
/*  247:     */     {
/*  248: 484 */       return this.onlyOnLeft;
/*  249:     */     }
/*  250:     */     
/*  251:     */     public Map<K, V> entriesOnlyOnRight()
/*  252:     */     {
/*  253: 489 */       return this.onlyOnRight;
/*  254:     */     }
/*  255:     */     
/*  256:     */     public Map<K, V> entriesInCommon()
/*  257:     */     {
/*  258: 494 */       return this.onBoth;
/*  259:     */     }
/*  260:     */     
/*  261:     */     public Map<K, MapDifference.ValueDifference<V>> entriesDiffering()
/*  262:     */     {
/*  263: 499 */       return this.differences;
/*  264:     */     }
/*  265:     */     
/*  266:     */     public boolean equals(Object object)
/*  267:     */     {
/*  268: 504 */       if (object == this) {
/*  269: 505 */         return true;
/*  270:     */       }
/*  271: 507 */       if ((object instanceof MapDifference))
/*  272:     */       {
/*  273: 508 */         MapDifference<?, ?> other = (MapDifference)object;
/*  274: 509 */         return (entriesOnlyOnLeft().equals(other.entriesOnlyOnLeft())) && (entriesOnlyOnRight().equals(other.entriesOnlyOnRight())) && (entriesInCommon().equals(other.entriesInCommon())) && (entriesDiffering().equals(other.entriesDiffering()));
/*  275:     */       }
/*  276: 514 */       return false;
/*  277:     */     }
/*  278:     */     
/*  279:     */     public int hashCode()
/*  280:     */     {
/*  281: 519 */       return Objects.hashCode(new Object[] { entriesOnlyOnLeft(), entriesOnlyOnRight(), entriesInCommon(), entriesDiffering() });
/*  282:     */     }
/*  283:     */     
/*  284:     */     public String toString()
/*  285:     */     {
/*  286: 525 */       if (areEqual()) {
/*  287: 526 */         return "equal";
/*  288:     */       }
/*  289: 529 */       StringBuilder result = new StringBuilder("not equal");
/*  290: 530 */       if (!this.onlyOnLeft.isEmpty()) {
/*  291: 531 */         result.append(": only on left=").append(this.onlyOnLeft);
/*  292:     */       }
/*  293: 533 */       if (!this.onlyOnRight.isEmpty()) {
/*  294: 534 */         result.append(": only on right=").append(this.onlyOnRight);
/*  295:     */       }
/*  296: 536 */       if (!this.differences.isEmpty()) {
/*  297: 537 */         result.append(": value differences=").append(this.differences);
/*  298:     */       }
/*  299: 539 */       return result.toString();
/*  300:     */     }
/*  301:     */   }
/*  302:     */   
/*  303:     */   static class ValueDifferenceImpl<V>
/*  304:     */     implements MapDifference.ValueDifference<V>
/*  305:     */   {
/*  306:     */     private final V left;
/*  307:     */     private final V right;
/*  308:     */     
/*  309:     */     static <V> MapDifference.ValueDifference<V> create(@Nullable V left, @Nullable V right)
/*  310:     */     {
/*  311: 548 */       return new ValueDifferenceImpl(left, right);
/*  312:     */     }
/*  313:     */     
/*  314:     */     private ValueDifferenceImpl(@Nullable V left, @Nullable V right)
/*  315:     */     {
/*  316: 552 */       this.left = left;
/*  317: 553 */       this.right = right;
/*  318:     */     }
/*  319:     */     
/*  320:     */     public V leftValue()
/*  321:     */     {
/*  322: 558 */       return this.left;
/*  323:     */     }
/*  324:     */     
/*  325:     */     public V rightValue()
/*  326:     */     {
/*  327: 563 */       return this.right;
/*  328:     */     }
/*  329:     */     
/*  330:     */     public boolean equals(@Nullable Object object)
/*  331:     */     {
/*  332: 568 */       if ((object instanceof MapDifference.ValueDifference))
/*  333:     */       {
/*  334: 569 */         MapDifference.ValueDifference<?> that = (MapDifference.ValueDifference)object;
/*  335: 570 */         return (Objects.equal(this.left, that.leftValue())) && (Objects.equal(this.right, that.rightValue()));
/*  336:     */       }
/*  337: 573 */       return false;
/*  338:     */     }
/*  339:     */     
/*  340:     */     public int hashCode()
/*  341:     */     {
/*  342: 578 */       return Objects.hashCode(new Object[] { this.left, this.right });
/*  343:     */     }
/*  344:     */     
/*  345:     */     public String toString()
/*  346:     */     {
/*  347: 583 */       return "(" + this.left + ", " + this.right + ")";
/*  348:     */     }
/*  349:     */   }
/*  350:     */   
/*  351:     */   public static <K, V> SortedMapDifference<K, V> difference(SortedMap<K, ? extends V> left, Map<? extends K, ? extends V> right)
/*  352:     */   {
/*  353: 608 */     Preconditions.checkNotNull(left);
/*  354: 609 */     Preconditions.checkNotNull(right);
/*  355: 610 */     Comparator<? super K> comparator = orNaturalOrder(left.comparator());
/*  356: 611 */     SortedMap<K, V> onlyOnLeft = newTreeMap(comparator);
/*  357: 612 */     SortedMap<K, V> onlyOnRight = newTreeMap(comparator);
/*  358: 613 */     onlyOnRight.putAll(right);
/*  359: 614 */     SortedMap<K, V> onBoth = newTreeMap(comparator);
/*  360: 615 */     SortedMap<K, MapDifference.ValueDifference<V>> differences = newTreeMap(comparator);
/*  361: 616 */     doDifference(left, right, Equivalence.equals(), onlyOnLeft, onlyOnRight, onBoth, differences);
/*  362: 617 */     return new SortedMapDifferenceImpl(onlyOnLeft, onlyOnRight, onBoth, differences);
/*  363:     */   }
/*  364:     */   
/*  365:     */   static class SortedMapDifferenceImpl<K, V>
/*  366:     */     extends Maps.MapDifferenceImpl<K, V>
/*  367:     */     implements SortedMapDifference<K, V>
/*  368:     */   {
/*  369:     */     SortedMapDifferenceImpl(SortedMap<K, V> onlyOnLeft, SortedMap<K, V> onlyOnRight, SortedMap<K, V> onBoth, SortedMap<K, MapDifference.ValueDifference<V>> differences)
/*  370:     */     {
/*  371: 627 */       super(onlyOnRight, onBoth, differences);
/*  372:     */     }
/*  373:     */     
/*  374:     */     public SortedMap<K, MapDifference.ValueDifference<V>> entriesDiffering()
/*  375:     */     {
/*  376: 632 */       return (SortedMap)super.entriesDiffering();
/*  377:     */     }
/*  378:     */     
/*  379:     */     public SortedMap<K, V> entriesInCommon()
/*  380:     */     {
/*  381: 637 */       return (SortedMap)super.entriesInCommon();
/*  382:     */     }
/*  383:     */     
/*  384:     */     public SortedMap<K, V> entriesOnlyOnLeft()
/*  385:     */     {
/*  386: 642 */       return (SortedMap)super.entriesOnlyOnLeft();
/*  387:     */     }
/*  388:     */     
/*  389:     */     public SortedMap<K, V> entriesOnlyOnRight()
/*  390:     */     {
/*  391: 647 */       return (SortedMap)super.entriesOnlyOnRight();
/*  392:     */     }
/*  393:     */   }
/*  394:     */   
/*  395:     */   static <E> Comparator<? super E> orNaturalOrder(@Nullable Comparator<? super E> comparator)
/*  396:     */   {
/*  397: 658 */     if (comparator != null) {
/*  398: 659 */       return comparator;
/*  399:     */     }
/*  400: 661 */     return Ordering.natural();
/*  401:     */   }
/*  402:     */   
/*  403:     */   public static <K, V> Map<K, V> asMap(Set<K> set, Function<? super K, V> function)
/*  404:     */   {
/*  405: 692 */     if ((set instanceof SortedSet)) {
/*  406: 693 */       return asMap((SortedSet)set, function);
/*  407:     */     }
/*  408: 695 */     return new AsMapView(set, function);
/*  409:     */   }
/*  410:     */   
/*  411:     */   public static <K, V> SortedMap<K, V> asMap(SortedSet<K> set, Function<? super K, V> function)
/*  412:     */   {
/*  413: 726 */     return Platform.mapsAsMapSortedSet(set, function);
/*  414:     */   }
/*  415:     */   
/*  416:     */   static <K, V> SortedMap<K, V> asMapSortedIgnoreNavigable(SortedSet<K> set, Function<? super K, V> function)
/*  417:     */   {
/*  418: 731 */     return new SortedAsMapView(set, function);
/*  419:     */   }
/*  420:     */   
/*  421:     */   @GwtIncompatible("NavigableMap")
/*  422:     */   public static <K, V> NavigableMap<K, V> asMap(NavigableSet<K> set, Function<? super K, V> function)
/*  423:     */   {
/*  424: 763 */     return new NavigableAsMapView(set, function);
/*  425:     */   }
/*  426:     */   
/*  427:     */   private static class AsMapView<K, V>
/*  428:     */     extends Maps.ViewCachingAbstractMap<K, V>
/*  429:     */   {
/*  430:     */     private final Set<K> set;
/*  431:     */     final Function<? super K, V> function;
/*  432:     */     
/*  433:     */     Set<K> backingSet()
/*  434:     */     {
/*  435: 772 */       return this.set;
/*  436:     */     }
/*  437:     */     
/*  438:     */     AsMapView(Set<K> set, Function<? super K, V> function)
/*  439:     */     {
/*  440: 776 */       this.set = ((Set)Preconditions.checkNotNull(set));
/*  441: 777 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*  442:     */     }
/*  443:     */     
/*  444:     */     public Set<K> createKeySet()
/*  445:     */     {
/*  446: 782 */       return Maps.removeOnlySet(backingSet());
/*  447:     */     }
/*  448:     */     
/*  449:     */     Collection<V> createValues()
/*  450:     */     {
/*  451: 787 */       return Collections2.transform(this.set, this.function);
/*  452:     */     }
/*  453:     */     
/*  454:     */     public int size()
/*  455:     */     {
/*  456: 792 */       return backingSet().size();
/*  457:     */     }
/*  458:     */     
/*  459:     */     public boolean containsKey(@Nullable Object key)
/*  460:     */     {
/*  461: 797 */       return backingSet().contains(key);
/*  462:     */     }
/*  463:     */     
/*  464:     */     public V get(@Nullable Object key)
/*  465:     */     {
/*  466: 802 */       if (Collections2.safeContains(backingSet(), key))
/*  467:     */       {
/*  468: 804 */         K k = key;
/*  469: 805 */         return this.function.apply(k);
/*  470:     */       }
/*  471: 807 */       return null;
/*  472:     */     }
/*  473:     */     
/*  474:     */     public V remove(@Nullable Object key)
/*  475:     */     {
/*  476: 813 */       if (backingSet().remove(key))
/*  477:     */       {
/*  478: 815 */         K k = key;
/*  479: 816 */         return this.function.apply(k);
/*  480:     */       }
/*  481: 818 */       return null;
/*  482:     */     }
/*  483:     */     
/*  484:     */     public void clear()
/*  485:     */     {
/*  486: 824 */       backingSet().clear();
/*  487:     */     }
/*  488:     */     
/*  489:     */     protected Set<Map.Entry<K, V>> createEntrySet()
/*  490:     */     {
/*  491: 841 */       new Maps.EntrySet()
/*  492:     */       {
/*  493:     */         Map<K, V> map()
/*  494:     */         {
/*  495: 833 */           return Maps.AsMapView.this;
/*  496:     */         }
/*  497:     */         
/*  498:     */         public Iterator<Map.Entry<K, V>> iterator()
/*  499:     */         {
/*  500: 838 */           return Maps.asMapEntryIterator(Maps.AsMapView.this.backingSet(), Maps.AsMapView.this.function);
/*  501:     */         }
/*  502:     */       };
/*  503:     */     }
/*  504:     */   }
/*  505:     */   
/*  506:     */   static <K, V> Iterator<Map.Entry<K, V>> asMapEntryIterator(Set<K> set, final Function<? super K, V> function)
/*  507:     */   {
/*  508: 847 */     new TransformedIterator(set.iterator())
/*  509:     */     {
/*  510:     */       Map.Entry<K, V> transform(K key)
/*  511:     */       {
/*  512: 850 */         return Maps.immutableEntry(key, function.apply(key));
/*  513:     */       }
/*  514:     */     };
/*  515:     */   }
/*  516:     */   
/*  517:     */   private static class SortedAsMapView<K, V>
/*  518:     */     extends Maps.AsMapView<K, V>
/*  519:     */     implements SortedMap<K, V>
/*  520:     */   {
/*  521:     */     SortedAsMapView(SortedSet<K> set, Function<? super K, V> function)
/*  522:     */     {
/*  523: 858 */       super(function);
/*  524:     */     }
/*  525:     */     
/*  526:     */     SortedSet<K> backingSet()
/*  527:     */     {
/*  528: 863 */       return (SortedSet)super.backingSet();
/*  529:     */     }
/*  530:     */     
/*  531:     */     public Comparator<? super K> comparator()
/*  532:     */     {
/*  533: 868 */       return backingSet().comparator();
/*  534:     */     }
/*  535:     */     
/*  536:     */     public Set<K> keySet()
/*  537:     */     {
/*  538: 873 */       return Maps.removeOnlySortedSet(backingSet());
/*  539:     */     }
/*  540:     */     
/*  541:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/*  542:     */     {
/*  543: 878 */       return Maps.asMap(backingSet().subSet(fromKey, toKey), this.function);
/*  544:     */     }
/*  545:     */     
/*  546:     */     public SortedMap<K, V> headMap(K toKey)
/*  547:     */     {
/*  548: 883 */       return Maps.asMap(backingSet().headSet(toKey), this.function);
/*  549:     */     }
/*  550:     */     
/*  551:     */     public SortedMap<K, V> tailMap(K fromKey)
/*  552:     */     {
/*  553: 888 */       return Maps.asMap(backingSet().tailSet(fromKey), this.function);
/*  554:     */     }
/*  555:     */     
/*  556:     */     public K firstKey()
/*  557:     */     {
/*  558: 893 */       return backingSet().first();
/*  559:     */     }
/*  560:     */     
/*  561:     */     public K lastKey()
/*  562:     */     {
/*  563: 898 */       return backingSet().last();
/*  564:     */     }
/*  565:     */   }
/*  566:     */   
/*  567:     */   @GwtIncompatible("NavigableMap")
/*  568:     */   private static final class NavigableAsMapView<K, V>
/*  569:     */     extends AbstractNavigableMap<K, V>
/*  570:     */   {
/*  571:     */     private final NavigableSet<K> set;
/*  572:     */     private final Function<? super K, V> function;
/*  573:     */     
/*  574:     */     NavigableAsMapView(NavigableSet<K> ks, Function<? super K, V> vFunction)
/*  575:     */     {
/*  576: 913 */       this.set = ((NavigableSet)Preconditions.checkNotNull(ks));
/*  577: 914 */       this.function = ((Function)Preconditions.checkNotNull(vFunction));
/*  578:     */     }
/*  579:     */     
/*  580:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/*  581:     */     {
/*  582: 920 */       return Maps.asMap(this.set.subSet(fromKey, fromInclusive, toKey, toInclusive), this.function);
/*  583:     */     }
/*  584:     */     
/*  585:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/*  586:     */     {
/*  587: 925 */       return Maps.asMap(this.set.headSet(toKey, inclusive), this.function);
/*  588:     */     }
/*  589:     */     
/*  590:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/*  591:     */     {
/*  592: 930 */       return Maps.asMap(this.set.tailSet(fromKey, inclusive), this.function);
/*  593:     */     }
/*  594:     */     
/*  595:     */     public Comparator<? super K> comparator()
/*  596:     */     {
/*  597: 935 */       return this.set.comparator();
/*  598:     */     }
/*  599:     */     
/*  600:     */     @Nullable
/*  601:     */     public V get(@Nullable Object key)
/*  602:     */     {
/*  603: 941 */       if (Collections2.safeContains(this.set, key))
/*  604:     */       {
/*  605: 943 */         K k = key;
/*  606: 944 */         return this.function.apply(k);
/*  607:     */       }
/*  608: 946 */       return null;
/*  609:     */     }
/*  610:     */     
/*  611:     */     public void clear()
/*  612:     */     {
/*  613: 952 */       this.set.clear();
/*  614:     */     }
/*  615:     */     
/*  616:     */     Iterator<Map.Entry<K, V>> entryIterator()
/*  617:     */     {
/*  618: 957 */       return Maps.asMapEntryIterator(this.set, this.function);
/*  619:     */     }
/*  620:     */     
/*  621:     */     Iterator<Map.Entry<K, V>> descendingEntryIterator()
/*  622:     */     {
/*  623: 962 */       return descendingMap().entrySet().iterator();
/*  624:     */     }
/*  625:     */     
/*  626:     */     public NavigableSet<K> navigableKeySet()
/*  627:     */     {
/*  628: 967 */       return Maps.removeOnlyNavigableSet(this.set);
/*  629:     */     }
/*  630:     */     
/*  631:     */     public int size()
/*  632:     */     {
/*  633: 972 */       return this.set.size();
/*  634:     */     }
/*  635:     */     
/*  636:     */     public NavigableMap<K, V> descendingMap()
/*  637:     */     {
/*  638: 977 */       return Maps.asMap(this.set.descendingSet(), this.function);
/*  639:     */     }
/*  640:     */   }
/*  641:     */   
/*  642:     */   private static <E> Set<E> removeOnlySet(Set<E> set)
/*  643:     */   {
/*  644: 982 */     new ForwardingSet()
/*  645:     */     {
/*  646:     */       protected Set<E> delegate()
/*  647:     */       {
/*  648: 985 */         return this.val$set;
/*  649:     */       }
/*  650:     */       
/*  651:     */       public boolean add(E element)
/*  652:     */       {
/*  653: 990 */         throw new UnsupportedOperationException();
/*  654:     */       }
/*  655:     */       
/*  656:     */       public boolean addAll(Collection<? extends E> es)
/*  657:     */       {
/*  658: 995 */         throw new UnsupportedOperationException();
/*  659:     */       }
/*  660:     */     };
/*  661:     */   }
/*  662:     */   
/*  663:     */   private static <E> SortedSet<E> removeOnlySortedSet(SortedSet<E> set)
/*  664:     */   {
/*  665:1001 */     new ForwardingSortedSet()
/*  666:     */     {
/*  667:     */       protected SortedSet<E> delegate()
/*  668:     */       {
/*  669:1004 */         return this.val$set;
/*  670:     */       }
/*  671:     */       
/*  672:     */       public boolean add(E element)
/*  673:     */       {
/*  674:1009 */         throw new UnsupportedOperationException();
/*  675:     */       }
/*  676:     */       
/*  677:     */       public boolean addAll(Collection<? extends E> es)
/*  678:     */       {
/*  679:1014 */         throw new UnsupportedOperationException();
/*  680:     */       }
/*  681:     */       
/*  682:     */       public SortedSet<E> headSet(E toElement)
/*  683:     */       {
/*  684:1019 */         return Maps.removeOnlySortedSet(super.headSet(toElement));
/*  685:     */       }
/*  686:     */       
/*  687:     */       public SortedSet<E> subSet(E fromElement, E toElement)
/*  688:     */       {
/*  689:1024 */         return Maps.removeOnlySortedSet(super.subSet(fromElement, toElement));
/*  690:     */       }
/*  691:     */       
/*  692:     */       public SortedSet<E> tailSet(E fromElement)
/*  693:     */       {
/*  694:1029 */         return Maps.removeOnlySortedSet(super.tailSet(fromElement));
/*  695:     */       }
/*  696:     */     };
/*  697:     */   }
/*  698:     */   
/*  699:     */   @GwtIncompatible("NavigableSet")
/*  700:     */   private static <E> NavigableSet<E> removeOnlyNavigableSet(NavigableSet<E> set)
/*  701:     */   {
/*  702:1036 */     new ForwardingNavigableSet()
/*  703:     */     {
/*  704:     */       protected NavigableSet<E> delegate()
/*  705:     */       {
/*  706:1039 */         return this.val$set;
/*  707:     */       }
/*  708:     */       
/*  709:     */       public boolean add(E element)
/*  710:     */       {
/*  711:1044 */         throw new UnsupportedOperationException();
/*  712:     */       }
/*  713:     */       
/*  714:     */       public boolean addAll(Collection<? extends E> es)
/*  715:     */       {
/*  716:1049 */         throw new UnsupportedOperationException();
/*  717:     */       }
/*  718:     */       
/*  719:     */       public SortedSet<E> headSet(E toElement)
/*  720:     */       {
/*  721:1054 */         return Maps.removeOnlySortedSet(super.headSet(toElement));
/*  722:     */       }
/*  723:     */       
/*  724:     */       public SortedSet<E> subSet(E fromElement, E toElement)
/*  725:     */       {
/*  726:1059 */         return Maps.removeOnlySortedSet(super.subSet(fromElement, toElement));
/*  727:     */       }
/*  728:     */       
/*  729:     */       public SortedSet<E> tailSet(E fromElement)
/*  730:     */       {
/*  731:1064 */         return Maps.removeOnlySortedSet(super.tailSet(fromElement));
/*  732:     */       }
/*  733:     */       
/*  734:     */       public NavigableSet<E> headSet(E toElement, boolean inclusive)
/*  735:     */       {
/*  736:1069 */         return Maps.removeOnlyNavigableSet(super.headSet(toElement, inclusive));
/*  737:     */       }
/*  738:     */       
/*  739:     */       public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/*  740:     */       {
/*  741:1074 */         return Maps.removeOnlyNavigableSet(super.tailSet(fromElement, inclusive));
/*  742:     */       }
/*  743:     */       
/*  744:     */       public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  745:     */       {
/*  746:1080 */         return Maps.removeOnlyNavigableSet(super.subSet(fromElement, fromInclusive, toElement, toInclusive));
/*  747:     */       }
/*  748:     */       
/*  749:     */       public NavigableSet<E> descendingSet()
/*  750:     */       {
/*  751:1086 */         return Maps.removeOnlyNavigableSet(super.descendingSet());
/*  752:     */       }
/*  753:     */     };
/*  754:     */   }
/*  755:     */   
/*  756:     */   public static <K, V> ImmutableMap<K, V> toMap(Iterable<K> keys, Function<? super K, V> valueFunction)
/*  757:     */   {
/*  758:1112 */     return toMap(keys.iterator(), valueFunction);
/*  759:     */   }
/*  760:     */   
/*  761:     */   public static <K, V> ImmutableMap<K, V> toMap(Iterator<K> keys, Function<? super K, V> valueFunction)
/*  762:     */   {
/*  763:1133 */     Preconditions.checkNotNull(valueFunction);
/*  764:     */     
/*  765:1135 */     Map<K, V> builder = newLinkedHashMap();
/*  766:1136 */     while (keys.hasNext())
/*  767:     */     {
/*  768:1137 */       K key = keys.next();
/*  769:1138 */       builder.put(key, valueFunction.apply(key));
/*  770:     */     }
/*  771:1140 */     return ImmutableMap.copyOf(builder);
/*  772:     */   }
/*  773:     */   
/*  774:     */   public static <K, V> ImmutableMap<K, V> uniqueIndex(Iterable<V> values, Function<? super V, K> keyFunction)
/*  775:     */   {
/*  776:1173 */     return uniqueIndex(values.iterator(), keyFunction);
/*  777:     */   }
/*  778:     */   
/*  779:     */   public static <K, V> ImmutableMap<K, V> uniqueIndex(Iterator<V> values, Function<? super V, K> keyFunction)
/*  780:     */   {
/*  781:1206 */     Preconditions.checkNotNull(keyFunction);
/*  782:1207 */     ImmutableMap.Builder<K, V> builder = ImmutableMap.builder();
/*  783:1208 */     while (values.hasNext())
/*  784:     */     {
/*  785:1209 */       V value = values.next();
/*  786:1210 */       builder.put(keyFunction.apply(value), value);
/*  787:     */     }
/*  788:     */     try
/*  789:     */     {
/*  790:1213 */       return builder.build();
/*  791:     */     }
/*  792:     */     catch (IllegalArgumentException duplicateKeys)
/*  793:     */     {
/*  794:1215 */       throw new IllegalArgumentException(duplicateKeys.getMessage() + ". To index multiple values under a key, use Multimaps.index.");
/*  795:     */     }
/*  796:     */   }
/*  797:     */   
/*  798:     */   @GwtIncompatible("java.util.Properties")
/*  799:     */   public static ImmutableMap<String, String> fromProperties(Properties properties)
/*  800:     */   {
/*  801:1236 */     ImmutableMap.Builder<String, String> builder = ImmutableMap.builder();
/*  802:1238 */     for (Enumeration<?> e = properties.propertyNames(); e.hasMoreElements();)
/*  803:     */     {
/*  804:1239 */       String key = (String)e.nextElement();
/*  805:1240 */       builder.put(key, properties.getProperty(key));
/*  806:     */     }
/*  807:1243 */     return builder.build();
/*  808:     */   }
/*  809:     */   
/*  810:     */   @GwtCompatible(serializable=true)
/*  811:     */   public static <K, V> Map.Entry<K, V> immutableEntry(@Nullable K key, @Nullable V value)
/*  812:     */   {
/*  813:1257 */     return new ImmutableEntry(key, value);
/*  814:     */   }
/*  815:     */   
/*  816:     */   static <K, V> Set<Map.Entry<K, V>> unmodifiableEntrySet(Set<Map.Entry<K, V>> entrySet)
/*  817:     */   {
/*  818:1269 */     return new UnmodifiableEntrySet(Collections.unmodifiableSet(entrySet));
/*  819:     */   }
/*  820:     */   
/*  821:     */   static <K, V> Map.Entry<K, V> unmodifiableEntry(Map.Entry<? extends K, ? extends V> entry)
/*  822:     */   {
/*  823:1282 */     Preconditions.checkNotNull(entry);
/*  824:1283 */     new AbstractMapEntry()
/*  825:     */     {
/*  826:     */       public K getKey()
/*  827:     */       {
/*  828:1286 */         return this.val$entry.getKey();
/*  829:     */       }
/*  830:     */       
/*  831:     */       public V getValue()
/*  832:     */       {
/*  833:1291 */         return this.val$entry.getValue();
/*  834:     */       }
/*  835:     */     };
/*  836:     */   }
/*  837:     */   
/*  838:     */   static <K, V> UnmodifiableIterator<Map.Entry<K, V>> unmodifiableEntryIterator(Iterator<Map.Entry<K, V>> entryIterator)
/*  839:     */   {
/*  840:1298 */     new UnmodifiableIterator()
/*  841:     */     {
/*  842:     */       public boolean hasNext()
/*  843:     */       {
/*  844:1301 */         return this.val$entryIterator.hasNext();
/*  845:     */       }
/*  846:     */       
/*  847:     */       public Map.Entry<K, V> next()
/*  848:     */       {
/*  849:1306 */         return Maps.unmodifiableEntry((Map.Entry)this.val$entryIterator.next());
/*  850:     */       }
/*  851:     */     };
/*  852:     */   }
/*  853:     */   
/*  854:     */   static class UnmodifiableEntries<K, V>
/*  855:     */     extends ForwardingCollection<Map.Entry<K, V>>
/*  856:     */   {
/*  857:     */     private final Collection<Map.Entry<K, V>> entries;
/*  858:     */     
/*  859:     */     UnmodifiableEntries(Collection<Map.Entry<K, V>> entries)
/*  860:     */     {
/*  861:1316 */       this.entries = entries;
/*  862:     */     }
/*  863:     */     
/*  864:     */     protected Collection<Map.Entry<K, V>> delegate()
/*  865:     */     {
/*  866:1321 */       return this.entries;
/*  867:     */     }
/*  868:     */     
/*  869:     */     public Iterator<Map.Entry<K, V>> iterator()
/*  870:     */     {
/*  871:1326 */       return Maps.unmodifiableEntryIterator(this.entries.iterator());
/*  872:     */     }
/*  873:     */     
/*  874:     */     public Object[] toArray()
/*  875:     */     {
/*  876:1333 */       return standardToArray();
/*  877:     */     }
/*  878:     */     
/*  879:     */     public <T> T[] toArray(T[] array)
/*  880:     */     {
/*  881:1338 */       return standardToArray(array);
/*  882:     */     }
/*  883:     */   }
/*  884:     */   
/*  885:     */   static class UnmodifiableEntrySet<K, V>
/*  886:     */     extends Maps.UnmodifiableEntries<K, V>
/*  887:     */     implements Set<Map.Entry<K, V>>
/*  888:     */   {
/*  889:     */     UnmodifiableEntrySet(Set<Map.Entry<K, V>> entries)
/*  890:     */     {
/*  891:1346 */       super();
/*  892:     */     }
/*  893:     */     
/*  894:     */     public boolean equals(@Nullable Object object)
/*  895:     */     {
/*  896:1353 */       return Sets.equalsImpl(this, object);
/*  897:     */     }
/*  898:     */     
/*  899:     */     public int hashCode()
/*  900:     */     {
/*  901:1358 */       return Sets.hashCodeImpl(this);
/*  902:     */     }
/*  903:     */   }
/*  904:     */   
/*  905:     */   @Beta
/*  906:     */   public static <A, B> Converter<A, B> asConverter(BiMap<A, B> bimap)
/*  907:     */   {
/*  908:1375 */     return new BiMapConverter(bimap);
/*  909:     */   }
/*  910:     */   
/*  911:     */   private static final class BiMapConverter<A, B>
/*  912:     */     extends Converter<A, B>
/*  913:     */     implements Serializable
/*  914:     */   {
/*  915:     */     private final BiMap<A, B> bimap;
/*  916:     */     private static final long serialVersionUID = 0L;
/*  917:     */     
/*  918:     */     BiMapConverter(BiMap<A, B> bimap)
/*  919:     */     {
/*  920:1382 */       this.bimap = ((BiMap)Preconditions.checkNotNull(bimap));
/*  921:     */     }
/*  922:     */     
/*  923:     */     protected B doForward(A a)
/*  924:     */     {
/*  925:1387 */       return convert(this.bimap, a);
/*  926:     */     }
/*  927:     */     
/*  928:     */     protected A doBackward(B b)
/*  929:     */     {
/*  930:1392 */       return convert(this.bimap.inverse(), b);
/*  931:     */     }
/*  932:     */     
/*  933:     */     private static <X, Y> Y convert(BiMap<X, Y> bimap, X input)
/*  934:     */     {
/*  935:1396 */       Y output = bimap.get(input);
/*  936:1397 */       Preconditions.checkArgument(output != null, "No non-null mapping present for input: %s", new Object[] { input });
/*  937:1398 */       return output;
/*  938:     */     }
/*  939:     */     
/*  940:     */     public boolean equals(@Nullable Object object)
/*  941:     */     {
/*  942:1403 */       if ((object instanceof BiMapConverter))
/*  943:     */       {
/*  944:1404 */         BiMapConverter<?, ?> that = (BiMapConverter)object;
/*  945:1405 */         return this.bimap.equals(that.bimap);
/*  946:     */       }
/*  947:1407 */       return false;
/*  948:     */     }
/*  949:     */     
/*  950:     */     public int hashCode()
/*  951:     */     {
/*  952:1412 */       return this.bimap.hashCode();
/*  953:     */     }
/*  954:     */     
/*  955:     */     public String toString()
/*  956:     */     {
/*  957:1418 */       return "Maps.asConverter(" + this.bimap + ")";
/*  958:     */     }
/*  959:     */   }
/*  960:     */   
/*  961:     */   public static <K, V> BiMap<K, V> synchronizedBiMap(BiMap<K, V> bimap)
/*  962:     */   {
/*  963:1453 */     return Synchronized.biMap(bimap, null);
/*  964:     */   }
/*  965:     */   
/*  966:     */   public static <K, V> BiMap<K, V> unmodifiableBiMap(BiMap<? extends K, ? extends V> bimap)
/*  967:     */   {
/*  968:1470 */     return new UnmodifiableBiMap(bimap, null);
/*  969:     */   }
/*  970:     */   
/*  971:     */   private static class UnmodifiableBiMap<K, V>
/*  972:     */     extends ForwardingMap<K, V>
/*  973:     */     implements BiMap<K, V>, Serializable
/*  974:     */   {
/*  975:     */     final Map<K, V> unmodifiableMap;
/*  976:     */     final BiMap<? extends K, ? extends V> delegate;
/*  977:     */     BiMap<V, K> inverse;
/*  978:     */     transient Set<V> values;
/*  979:     */     private static final long serialVersionUID = 0L;
/*  980:     */     
/*  981:     */     UnmodifiableBiMap(BiMap<? extends K, ? extends V> delegate, @Nullable BiMap<V, K> inverse)
/*  982:     */     {
/*  983:1482 */       this.unmodifiableMap = Collections.unmodifiableMap(delegate);
/*  984:1483 */       this.delegate = delegate;
/*  985:1484 */       this.inverse = inverse;
/*  986:     */     }
/*  987:     */     
/*  988:     */     protected Map<K, V> delegate()
/*  989:     */     {
/*  990:1489 */       return this.unmodifiableMap;
/*  991:     */     }
/*  992:     */     
/*  993:     */     public V forcePut(K key, V value)
/*  994:     */     {
/*  995:1494 */       throw new UnsupportedOperationException();
/*  996:     */     }
/*  997:     */     
/*  998:     */     public BiMap<V, K> inverse()
/*  999:     */     {
/* 1000:1499 */       BiMap<V, K> result = this.inverse;
/* 1001:1500 */       return result == null ? (this.inverse = new UnmodifiableBiMap(this.delegate.inverse(), this)) : result;
/* 1002:     */     }
/* 1003:     */     
/* 1004:     */     public Set<V> values()
/* 1005:     */     {
/* 1006:1507 */       Set<V> result = this.values;
/* 1007:1508 */       return result == null ? (this.values = Collections.unmodifiableSet(this.delegate.values())) : result;
/* 1008:     */     }
/* 1009:     */   }
/* 1010:     */   
/* 1011:     */   public static <K, V1, V2> Map<K, V2> transformValues(Map<K, V1> fromMap, Function<? super V1, V2> function)
/* 1012:     */   {
/* 1013:1554 */     return transformEntries(fromMap, asEntryTransformer(function));
/* 1014:     */   }
/* 1015:     */   
/* 1016:     */   public static <K, V1, V2> SortedMap<K, V2> transformValues(SortedMap<K, V1> fromMap, Function<? super V1, V2> function)
/* 1017:     */   {
/* 1018:1598 */     return transformEntries(fromMap, asEntryTransformer(function));
/* 1019:     */   }
/* 1020:     */   
/* 1021:     */   @GwtIncompatible("NavigableMap")
/* 1022:     */   public static <K, V1, V2> NavigableMap<K, V2> transformValues(NavigableMap<K, V1> fromMap, Function<? super V1, V2> function)
/* 1023:     */   {
/* 1024:1645 */     return transformEntries(fromMap, asEntryTransformer(function));
/* 1025:     */   }
/* 1026:     */   
/* 1027:     */   public static <K, V1, V2> Map<K, V2> transformEntries(Map<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1028:     */   {
/* 1029:1701 */     if ((fromMap instanceof SortedMap)) {
/* 1030:1702 */       return transformEntries((SortedMap)fromMap, transformer);
/* 1031:     */     }
/* 1032:1704 */     return new TransformedEntriesMap(fromMap, transformer);
/* 1033:     */   }
/* 1034:     */   
/* 1035:     */   public static <K, V1, V2> SortedMap<K, V2> transformEntries(SortedMap<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1036:     */   {
/* 1037:1761 */     return Platform.mapsTransformEntriesSortedMap(fromMap, transformer);
/* 1038:     */   }
/* 1039:     */   
/* 1040:     */   @GwtIncompatible("NavigableMap")
/* 1041:     */   public static <K, V1, V2> NavigableMap<K, V2> transformEntries(NavigableMap<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1042:     */   {
/* 1043:1820 */     return new TransformedEntriesNavigableMap(fromMap, transformer);
/* 1044:     */   }
/* 1045:     */   
/* 1046:     */   static <K, V1, V2> SortedMap<K, V2> transformEntriesIgnoreNavigable(SortedMap<K, V1> fromMap, EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1047:     */   {
/* 1048:1825 */     return new TransformedEntriesSortedMap(fromMap, transformer);
/* 1049:     */   }
/* 1050:     */   
/* 1051:     */   static <K, V1, V2> EntryTransformer<K, V1, V2> asEntryTransformer(Function<? super V1, V2> function)
/* 1052:     */   {
/* 1053:1864 */     Preconditions.checkNotNull(function);
/* 1054:1865 */     new EntryTransformer()
/* 1055:     */     {
/* 1056:     */       public V2 transformEntry(K key, V1 value)
/* 1057:     */       {
/* 1058:1868 */         return this.val$function.apply(value);
/* 1059:     */       }
/* 1060:     */     };
/* 1061:     */   }
/* 1062:     */   
/* 1063:     */   static <K, V1, V2> Function<V1, V2> asValueToValueFunction(EntryTransformer<? super K, V1, V2> transformer, final K key)
/* 1064:     */   {
/* 1065:1875 */     Preconditions.checkNotNull(transformer);
/* 1066:1876 */     new Function()
/* 1067:     */     {
/* 1068:     */       public V2 apply(@Nullable V1 v1)
/* 1069:     */       {
/* 1070:1879 */         return this.val$transformer.transformEntry(key, v1);
/* 1071:     */       }
/* 1072:     */     };
/* 1073:     */   }
/* 1074:     */   
/* 1075:     */   static <K, V1, V2> Function<Map.Entry<K, V1>, V2> asEntryToValueFunction(EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1076:     */   {
/* 1077:1889 */     Preconditions.checkNotNull(transformer);
/* 1078:1890 */     new Function()
/* 1079:     */     {
/* 1080:     */       public V2 apply(Map.Entry<K, V1> entry)
/* 1081:     */       {
/* 1082:1893 */         return this.val$transformer.transformEntry(entry.getKey(), entry.getValue());
/* 1083:     */       }
/* 1084:     */     };
/* 1085:     */   }
/* 1086:     */   
/* 1087:     */   static <V2, K, V1> Map.Entry<K, V2> transformEntry(final EntryTransformer<? super K, ? super V1, V2> transformer, Map.Entry<K, V1> entry)
/* 1088:     */   {
/* 1089:1903 */     Preconditions.checkNotNull(transformer);
/* 1090:1904 */     Preconditions.checkNotNull(entry);
/* 1091:1905 */     new AbstractMapEntry()
/* 1092:     */     {
/* 1093:     */       public K getKey()
/* 1094:     */       {
/* 1095:1908 */         return this.val$entry.getKey();
/* 1096:     */       }
/* 1097:     */       
/* 1098:     */       public V2 getValue()
/* 1099:     */       {
/* 1100:1913 */         return transformer.transformEntry(this.val$entry.getKey(), this.val$entry.getValue());
/* 1101:     */       }
/* 1102:     */     };
/* 1103:     */   }
/* 1104:     */   
/* 1105:     */   static <K, V1, V2> Function<Map.Entry<K, V1>, Map.Entry<K, V2>> asEntryToEntryFunction(EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1106:     */   {
/* 1107:1923 */     Preconditions.checkNotNull(transformer);
/* 1108:1924 */     new Function()
/* 1109:     */     {
/* 1110:     */       public Map.Entry<K, V2> apply(Map.Entry<K, V1> entry)
/* 1111:     */       {
/* 1112:1927 */         return Maps.transformEntry(this.val$transformer, entry);
/* 1113:     */       }
/* 1114:     */     };
/* 1115:     */   }
/* 1116:     */   
/* 1117:     */   public static abstract interface EntryTransformer<K, V1, V2>
/* 1118:     */   {
/* 1119:     */     public abstract V2 transformEntry(@Nullable K paramK, @Nullable V1 paramV1);
/* 1120:     */   }
/* 1121:     */   
/* 1122:     */   static class TransformedEntriesMap<K, V1, V2>
/* 1123:     */     extends Maps.IteratorBasedAbstractMap<K, V2>
/* 1124:     */   {
/* 1125:     */     final Map<K, V1> fromMap;
/* 1126:     */     final Maps.EntryTransformer<? super K, ? super V1, V2> transformer;
/* 1127:     */     
/* 1128:     */     TransformedEntriesMap(Map<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1129:     */     {
/* 1130:1938 */       this.fromMap = ((Map)Preconditions.checkNotNull(fromMap));
/* 1131:1939 */       this.transformer = ((Maps.EntryTransformer)Preconditions.checkNotNull(transformer));
/* 1132:     */     }
/* 1133:     */     
/* 1134:     */     public int size()
/* 1135:     */     {
/* 1136:1944 */       return this.fromMap.size();
/* 1137:     */     }
/* 1138:     */     
/* 1139:     */     public boolean containsKey(Object key)
/* 1140:     */     {
/* 1141:1949 */       return this.fromMap.containsKey(key);
/* 1142:     */     }
/* 1143:     */     
/* 1144:     */     public V2 get(Object key)
/* 1145:     */     {
/* 1146:1956 */       V1 value = this.fromMap.get(key);
/* 1147:1957 */       return (value != null) || (this.fromMap.containsKey(key)) ? this.transformer.transformEntry(key, value) : null;
/* 1148:     */     }
/* 1149:     */     
/* 1150:     */     public V2 remove(Object key)
/* 1151:     */     {
/* 1152:1966 */       return this.fromMap.containsKey(key) ? this.transformer.transformEntry(key, this.fromMap.remove(key)) : null;
/* 1153:     */     }
/* 1154:     */     
/* 1155:     */     public void clear()
/* 1156:     */     {
/* 1157:1973 */       this.fromMap.clear();
/* 1158:     */     }
/* 1159:     */     
/* 1160:     */     public Set<K> keySet()
/* 1161:     */     {
/* 1162:1978 */       return this.fromMap.keySet();
/* 1163:     */     }
/* 1164:     */     
/* 1165:     */     Iterator<Map.Entry<K, V2>> entryIterator()
/* 1166:     */     {
/* 1167:1983 */       return Iterators.transform(this.fromMap.entrySet().iterator(), Maps.asEntryToEntryFunction(this.transformer));
/* 1168:     */     }
/* 1169:     */     
/* 1170:     */     public Collection<V2> values()
/* 1171:     */     {
/* 1172:1989 */       return new Maps.Values(this);
/* 1173:     */     }
/* 1174:     */   }
/* 1175:     */   
/* 1176:     */   static class TransformedEntriesSortedMap<K, V1, V2>
/* 1177:     */     extends Maps.TransformedEntriesMap<K, V1, V2>
/* 1178:     */     implements SortedMap<K, V2>
/* 1179:     */   {
/* 1180:     */     protected SortedMap<K, V1> fromMap()
/* 1181:     */     {
/* 1182:1997 */       return (SortedMap)this.fromMap;
/* 1183:     */     }
/* 1184:     */     
/* 1185:     */     TransformedEntriesSortedMap(SortedMap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1186:     */     {
/* 1187:2002 */       super(transformer);
/* 1188:     */     }
/* 1189:     */     
/* 1190:     */     public Comparator<? super K> comparator()
/* 1191:     */     {
/* 1192:2007 */       return fromMap().comparator();
/* 1193:     */     }
/* 1194:     */     
/* 1195:     */     public K firstKey()
/* 1196:     */     {
/* 1197:2012 */       return fromMap().firstKey();
/* 1198:     */     }
/* 1199:     */     
/* 1200:     */     public SortedMap<K, V2> headMap(K toKey)
/* 1201:     */     {
/* 1202:2017 */       return Maps.transformEntries(fromMap().headMap(toKey), this.transformer);
/* 1203:     */     }
/* 1204:     */     
/* 1205:     */     public K lastKey()
/* 1206:     */     {
/* 1207:2022 */       return fromMap().lastKey();
/* 1208:     */     }
/* 1209:     */     
/* 1210:     */     public SortedMap<K, V2> subMap(K fromKey, K toKey)
/* 1211:     */     {
/* 1212:2027 */       return Maps.transformEntries(fromMap().subMap(fromKey, toKey), this.transformer);
/* 1213:     */     }
/* 1214:     */     
/* 1215:     */     public SortedMap<K, V2> tailMap(K fromKey)
/* 1216:     */     {
/* 1217:2032 */       return Maps.transformEntries(fromMap().tailMap(fromKey), this.transformer);
/* 1218:     */     }
/* 1219:     */   }
/* 1220:     */   
/* 1221:     */   @GwtIncompatible("NavigableMap")
/* 1222:     */   private static class TransformedEntriesNavigableMap<K, V1, V2>
/* 1223:     */     extends Maps.TransformedEntriesSortedMap<K, V1, V2>
/* 1224:     */     implements NavigableMap<K, V2>
/* 1225:     */   {
/* 1226:     */     TransformedEntriesNavigableMap(NavigableMap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/* 1227:     */     {
/* 1228:2042 */       super(transformer);
/* 1229:     */     }
/* 1230:     */     
/* 1231:     */     public Map.Entry<K, V2> ceilingEntry(K key)
/* 1232:     */     {
/* 1233:2047 */       return transformEntry(fromMap().ceilingEntry(key));
/* 1234:     */     }
/* 1235:     */     
/* 1236:     */     public K ceilingKey(K key)
/* 1237:     */     {
/* 1238:2052 */       return fromMap().ceilingKey(key);
/* 1239:     */     }
/* 1240:     */     
/* 1241:     */     public NavigableSet<K> descendingKeySet()
/* 1242:     */     {
/* 1243:2057 */       return fromMap().descendingKeySet();
/* 1244:     */     }
/* 1245:     */     
/* 1246:     */     public NavigableMap<K, V2> descendingMap()
/* 1247:     */     {
/* 1248:2062 */       return Maps.transformEntries(fromMap().descendingMap(), this.transformer);
/* 1249:     */     }
/* 1250:     */     
/* 1251:     */     public Map.Entry<K, V2> firstEntry()
/* 1252:     */     {
/* 1253:2067 */       return transformEntry(fromMap().firstEntry());
/* 1254:     */     }
/* 1255:     */     
/* 1256:     */     public Map.Entry<K, V2> floorEntry(K key)
/* 1257:     */     {
/* 1258:2072 */       return transformEntry(fromMap().floorEntry(key));
/* 1259:     */     }
/* 1260:     */     
/* 1261:     */     public K floorKey(K key)
/* 1262:     */     {
/* 1263:2077 */       return fromMap().floorKey(key);
/* 1264:     */     }
/* 1265:     */     
/* 1266:     */     public NavigableMap<K, V2> headMap(K toKey)
/* 1267:     */     {
/* 1268:2082 */       return headMap(toKey, false);
/* 1269:     */     }
/* 1270:     */     
/* 1271:     */     public NavigableMap<K, V2> headMap(K toKey, boolean inclusive)
/* 1272:     */     {
/* 1273:2087 */       return Maps.transformEntries(fromMap().headMap(toKey, inclusive), this.transformer);
/* 1274:     */     }
/* 1275:     */     
/* 1276:     */     public Map.Entry<K, V2> higherEntry(K key)
/* 1277:     */     {
/* 1278:2092 */       return transformEntry(fromMap().higherEntry(key));
/* 1279:     */     }
/* 1280:     */     
/* 1281:     */     public K higherKey(K key)
/* 1282:     */     {
/* 1283:2097 */       return fromMap().higherKey(key);
/* 1284:     */     }
/* 1285:     */     
/* 1286:     */     public Map.Entry<K, V2> lastEntry()
/* 1287:     */     {
/* 1288:2102 */       return transformEntry(fromMap().lastEntry());
/* 1289:     */     }
/* 1290:     */     
/* 1291:     */     public Map.Entry<K, V2> lowerEntry(K key)
/* 1292:     */     {
/* 1293:2107 */       return transformEntry(fromMap().lowerEntry(key));
/* 1294:     */     }
/* 1295:     */     
/* 1296:     */     public K lowerKey(K key)
/* 1297:     */     {
/* 1298:2112 */       return fromMap().lowerKey(key);
/* 1299:     */     }
/* 1300:     */     
/* 1301:     */     public NavigableSet<K> navigableKeySet()
/* 1302:     */     {
/* 1303:2117 */       return fromMap().navigableKeySet();
/* 1304:     */     }
/* 1305:     */     
/* 1306:     */     public Map.Entry<K, V2> pollFirstEntry()
/* 1307:     */     {
/* 1308:2122 */       return transformEntry(fromMap().pollFirstEntry());
/* 1309:     */     }
/* 1310:     */     
/* 1311:     */     public Map.Entry<K, V2> pollLastEntry()
/* 1312:     */     {
/* 1313:2127 */       return transformEntry(fromMap().pollLastEntry());
/* 1314:     */     }
/* 1315:     */     
/* 1316:     */     public NavigableMap<K, V2> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 1317:     */     {
/* 1318:2133 */       return Maps.transformEntries(fromMap().subMap(fromKey, fromInclusive, toKey, toInclusive), this.transformer);
/* 1319:     */     }
/* 1320:     */     
/* 1321:     */     public NavigableMap<K, V2> subMap(K fromKey, K toKey)
/* 1322:     */     {
/* 1323:2139 */       return subMap(fromKey, true, toKey, false);
/* 1324:     */     }
/* 1325:     */     
/* 1326:     */     public NavigableMap<K, V2> tailMap(K fromKey)
/* 1327:     */     {
/* 1328:2144 */       return tailMap(fromKey, true);
/* 1329:     */     }
/* 1330:     */     
/* 1331:     */     public NavigableMap<K, V2> tailMap(K fromKey, boolean inclusive)
/* 1332:     */     {
/* 1333:2149 */       return Maps.transformEntries(fromMap().tailMap(fromKey, inclusive), this.transformer);
/* 1334:     */     }
/* 1335:     */     
/* 1336:     */     @Nullable
/* 1337:     */     private Map.Entry<K, V2> transformEntry(@Nullable Map.Entry<K, V1> entry)
/* 1338:     */     {
/* 1339:2154 */       return entry == null ? null : Maps.transformEntry(this.transformer, entry);
/* 1340:     */     }
/* 1341:     */     
/* 1342:     */     protected NavigableMap<K, V1> fromMap()
/* 1343:     */     {
/* 1344:2159 */       return (NavigableMap)super.fromMap();
/* 1345:     */     }
/* 1346:     */   }
/* 1347:     */   
/* 1348:     */   static <K> Predicate<Map.Entry<K, ?>> keyPredicateOnEntries(Predicate<? super K> keyPredicate)
/* 1349:     */   {
/* 1350:2164 */     return Predicates.compose(keyPredicate, keyFunction());
/* 1351:     */   }
/* 1352:     */   
/* 1353:     */   static <V> Predicate<Map.Entry<?, V>> valuePredicateOnEntries(Predicate<? super V> valuePredicate)
/* 1354:     */   {
/* 1355:2168 */     return Predicates.compose(valuePredicate, valueFunction());
/* 1356:     */   }
/* 1357:     */   
/* 1358:     */   @CheckReturnValue
/* 1359:     */   public static <K, V> Map<K, V> filterKeys(Map<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1360:     */   {
/* 1361:2202 */     if ((unfiltered instanceof SortedMap)) {
/* 1362:2203 */       return filterKeys((SortedMap)unfiltered, keyPredicate);
/* 1363:     */     }
/* 1364:2204 */     if ((unfiltered instanceof BiMap)) {
/* 1365:2205 */       return filterKeys((BiMap)unfiltered, keyPredicate);
/* 1366:     */     }
/* 1367:2207 */     Preconditions.checkNotNull(keyPredicate);
/* 1368:2208 */     Predicate<Map.Entry<K, ?>> entryPredicate = keyPredicateOnEntries(keyPredicate);
/* 1369:2209 */     return (unfiltered instanceof AbstractFilteredMap) ? filterFiltered((AbstractFilteredMap)unfiltered, entryPredicate) : new FilteredKeyMap((Map)Preconditions.checkNotNull(unfiltered), keyPredicate, entryPredicate);
/* 1370:     */   }
/* 1371:     */   
/* 1372:     */   @CheckReturnValue
/* 1373:     */   public static <K, V> SortedMap<K, V> filterKeys(SortedMap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1374:     */   {
/* 1375:2249 */     return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
/* 1376:     */   }
/* 1377:     */   
/* 1378:     */   @CheckReturnValue
/* 1379:     */   @GwtIncompatible("NavigableMap")
/* 1380:     */   public static <K, V> NavigableMap<K, V> filterKeys(NavigableMap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1381:     */   {
/* 1382:2288 */     return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
/* 1383:     */   }
/* 1384:     */   
/* 1385:     */   @CheckReturnValue
/* 1386:     */   public static <K, V> BiMap<K, V> filterKeys(BiMap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1387:     */   {
/* 1388:2319 */     Preconditions.checkNotNull(keyPredicate);
/* 1389:2320 */     return filterEntries(unfiltered, keyPredicateOnEntries(keyPredicate));
/* 1390:     */   }
/* 1391:     */   
/* 1392:     */   @CheckReturnValue
/* 1393:     */   public static <K, V> Map<K, V> filterValues(Map<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1394:     */   {
/* 1395:2355 */     if ((unfiltered instanceof SortedMap)) {
/* 1396:2356 */       return filterValues((SortedMap)unfiltered, valuePredicate);
/* 1397:     */     }
/* 1398:2357 */     if ((unfiltered instanceof BiMap)) {
/* 1399:2358 */       return filterValues((BiMap)unfiltered, valuePredicate);
/* 1400:     */     }
/* 1401:2360 */     return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
/* 1402:     */   }
/* 1403:     */   
/* 1404:     */   @CheckReturnValue
/* 1405:     */   public static <K, V> SortedMap<K, V> filterValues(SortedMap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1406:     */   {
/* 1407:2397 */     return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
/* 1408:     */   }
/* 1409:     */   
/* 1410:     */   @CheckReturnValue
/* 1411:     */   @GwtIncompatible("NavigableMap")
/* 1412:     */   public static <K, V> NavigableMap<K, V> filterValues(NavigableMap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1413:     */   {
/* 1414:2435 */     return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
/* 1415:     */   }
/* 1416:     */   
/* 1417:     */   @CheckReturnValue
/* 1418:     */   public static <K, V> BiMap<K, V> filterValues(BiMap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1419:     */   {
/* 1420:2469 */     return filterEntries(unfiltered, valuePredicateOnEntries(valuePredicate));
/* 1421:     */   }
/* 1422:     */   
/* 1423:     */   @CheckReturnValue
/* 1424:     */   public static <K, V> Map<K, V> filterEntries(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1425:     */   {
/* 1426:2504 */     if ((unfiltered instanceof SortedMap)) {
/* 1427:2505 */       return filterEntries((SortedMap)unfiltered, entryPredicate);
/* 1428:     */     }
/* 1429:2506 */     if ((unfiltered instanceof BiMap)) {
/* 1430:2507 */       return filterEntries((BiMap)unfiltered, entryPredicate);
/* 1431:     */     }
/* 1432:2509 */     Preconditions.checkNotNull(entryPredicate);
/* 1433:2510 */     return (unfiltered instanceof AbstractFilteredMap) ? filterFiltered((AbstractFilteredMap)unfiltered, entryPredicate) : new FilteredEntryMap((Map)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1434:     */   }
/* 1435:     */   
/* 1436:     */   @CheckReturnValue
/* 1437:     */   public static <K, V> SortedMap<K, V> filterEntries(SortedMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1438:     */   {
/* 1439:2549 */     return Platform.mapsFilterSortedMap(unfiltered, entryPredicate);
/* 1440:     */   }
/* 1441:     */   
/* 1442:     */   static <K, V> SortedMap<K, V> filterSortedIgnoreNavigable(SortedMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1443:     */   {
/* 1444:2554 */     Preconditions.checkNotNull(entryPredicate);
/* 1445:2555 */     return (unfiltered instanceof FilteredEntrySortedMap) ? filterFiltered((FilteredEntrySortedMap)unfiltered, entryPredicate) : new FilteredEntrySortedMap((SortedMap)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1446:     */   }
/* 1447:     */   
/* 1448:     */   @CheckReturnValue
/* 1449:     */   @GwtIncompatible("NavigableMap")
/* 1450:     */   public static <K, V> NavigableMap<K, V> filterEntries(NavigableMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1451:     */   {
/* 1452:2595 */     Preconditions.checkNotNull(entryPredicate);
/* 1453:2596 */     return (unfiltered instanceof FilteredEntryNavigableMap) ? filterFiltered((FilteredEntryNavigableMap)unfiltered, entryPredicate) : new FilteredEntryNavigableMap((NavigableMap)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1454:     */   }
/* 1455:     */   
/* 1456:     */   @CheckReturnValue
/* 1457:     */   public static <K, V> BiMap<K, V> filterEntries(BiMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1458:     */   {
/* 1459:2631 */     Preconditions.checkNotNull(unfiltered);
/* 1460:2632 */     Preconditions.checkNotNull(entryPredicate);
/* 1461:2633 */     return (unfiltered instanceof FilteredEntryBiMap) ? filterFiltered((FilteredEntryBiMap)unfiltered, entryPredicate) : new FilteredEntryBiMap(unfiltered, entryPredicate);
/* 1462:     */   }
/* 1463:     */   
/* 1464:     */   private static <K, V> Map<K, V> filterFiltered(AbstractFilteredMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1465:     */   {
/* 1466:2644 */     return new FilteredEntryMap(map.unfiltered, Predicates.and(map.predicate, entryPredicate));
/* 1467:     */   }
/* 1468:     */   
/* 1469:     */   private static abstract class AbstractFilteredMap<K, V>
/* 1470:     */     extends Maps.ViewCachingAbstractMap<K, V>
/* 1471:     */   {
/* 1472:     */     final Map<K, V> unfiltered;
/* 1473:     */     final Predicate<? super Map.Entry<K, V>> predicate;
/* 1474:     */     
/* 1475:     */     AbstractFilteredMap(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> predicate)
/* 1476:     */     {
/* 1477:2653 */       this.unfiltered = unfiltered;
/* 1478:2654 */       this.predicate = predicate;
/* 1479:     */     }
/* 1480:     */     
/* 1481:     */     boolean apply(@Nullable Object key, @Nullable V value)
/* 1482:     */     {
/* 1483:2661 */       K k = key;
/* 1484:2662 */       return this.predicate.apply(Maps.immutableEntry(k, value));
/* 1485:     */     }
/* 1486:     */     
/* 1487:     */     public V put(K key, V value)
/* 1488:     */     {
/* 1489:2667 */       Preconditions.checkArgument(apply(key, value));
/* 1490:2668 */       return this.unfiltered.put(key, value);
/* 1491:     */     }
/* 1492:     */     
/* 1493:     */     public void putAll(Map<? extends K, ? extends V> map)
/* 1494:     */     {
/* 1495:2673 */       for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 1496:2674 */         Preconditions.checkArgument(apply(entry.getKey(), entry.getValue()));
/* 1497:     */       }
/* 1498:2676 */       this.unfiltered.putAll(map);
/* 1499:     */     }
/* 1500:     */     
/* 1501:     */     public boolean containsKey(Object key)
/* 1502:     */     {
/* 1503:2681 */       return (this.unfiltered.containsKey(key)) && (apply(key, this.unfiltered.get(key)));
/* 1504:     */     }
/* 1505:     */     
/* 1506:     */     public V get(Object key)
/* 1507:     */     {
/* 1508:2686 */       V value = this.unfiltered.get(key);
/* 1509:2687 */       return (value != null) && (apply(key, value)) ? value : null;
/* 1510:     */     }
/* 1511:     */     
/* 1512:     */     public boolean isEmpty()
/* 1513:     */     {
/* 1514:2692 */       return entrySet().isEmpty();
/* 1515:     */     }
/* 1516:     */     
/* 1517:     */     public V remove(Object key)
/* 1518:     */     {
/* 1519:2697 */       return containsKey(key) ? this.unfiltered.remove(key) : null;
/* 1520:     */     }
/* 1521:     */     
/* 1522:     */     Collection<V> createValues()
/* 1523:     */     {
/* 1524:2702 */       return new Maps.FilteredMapValues(this, this.unfiltered, this.predicate);
/* 1525:     */     }
/* 1526:     */   }
/* 1527:     */   
/* 1528:     */   private static final class FilteredMapValues<K, V>
/* 1529:     */     extends Maps.Values<K, V>
/* 1530:     */   {
/* 1531:     */     Map<K, V> unfiltered;
/* 1532:     */     Predicate<? super Map.Entry<K, V>> predicate;
/* 1533:     */     
/* 1534:     */     FilteredMapValues(Map<K, V> filteredMap, Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> predicate)
/* 1535:     */     {
/* 1536:2712 */       super();
/* 1537:2713 */       this.unfiltered = unfiltered;
/* 1538:2714 */       this.predicate = predicate;
/* 1539:     */     }
/* 1540:     */     
/* 1541:     */     public boolean remove(Object o)
/* 1542:     */     {
/* 1543:2719 */       return Iterables.removeFirstMatching(this.unfiltered.entrySet(), Predicates.and(this.predicate, Maps.valuePredicateOnEntries(Predicates.equalTo(o)))) != null;
/* 1544:     */     }
/* 1545:     */     
/* 1546:     */     private boolean removeIf(Predicate<? super V> valuePredicate)
/* 1547:     */     {
/* 1548:2726 */       return Iterables.removeIf(this.unfiltered.entrySet(), Predicates.and(this.predicate, Maps.valuePredicateOnEntries(valuePredicate)));
/* 1549:     */     }
/* 1550:     */     
/* 1551:     */     public boolean removeAll(Collection<?> collection)
/* 1552:     */     {
/* 1553:2733 */       return removeIf(Predicates.in(collection));
/* 1554:     */     }
/* 1555:     */     
/* 1556:     */     public boolean retainAll(Collection<?> collection)
/* 1557:     */     {
/* 1558:2738 */       return removeIf(Predicates.not(Predicates.in(collection)));
/* 1559:     */     }
/* 1560:     */     
/* 1561:     */     public Object[] toArray()
/* 1562:     */     {
/* 1563:2744 */       return Lists.newArrayList(iterator()).toArray();
/* 1564:     */     }
/* 1565:     */     
/* 1566:     */     public <T> T[] toArray(T[] array)
/* 1567:     */     {
/* 1568:2749 */       return Lists.newArrayList(iterator()).toArray(array);
/* 1569:     */     }
/* 1570:     */   }
/* 1571:     */   
/* 1572:     */   private static class FilteredKeyMap<K, V>
/* 1573:     */     extends Maps.AbstractFilteredMap<K, V>
/* 1574:     */   {
/* 1575:     */     Predicate<? super K> keyPredicate;
/* 1576:     */     
/* 1577:     */     FilteredKeyMap(Map<K, V> unfiltered, Predicate<? super K> keyPredicate, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1578:     */     {
/* 1579:2760 */       super(entryPredicate);
/* 1580:2761 */       this.keyPredicate = keyPredicate;
/* 1581:     */     }
/* 1582:     */     
/* 1583:     */     protected Set<Map.Entry<K, V>> createEntrySet()
/* 1584:     */     {
/* 1585:2766 */       return Sets.filter(this.unfiltered.entrySet(), this.predicate);
/* 1586:     */     }
/* 1587:     */     
/* 1588:     */     Set<K> createKeySet()
/* 1589:     */     {
/* 1590:2771 */       return Sets.filter(this.unfiltered.keySet(), this.keyPredicate);
/* 1591:     */     }
/* 1592:     */     
/* 1593:     */     public boolean containsKey(Object key)
/* 1594:     */     {
/* 1595:2779 */       return (this.unfiltered.containsKey(key)) && (this.keyPredicate.apply(key));
/* 1596:     */     }
/* 1597:     */   }
/* 1598:     */   
/* 1599:     */   static class FilteredEntryMap<K, V>
/* 1600:     */     extends Maps.AbstractFilteredMap<K, V>
/* 1601:     */   {
/* 1602:     */     final Set<Map.Entry<K, V>> filteredEntrySet;
/* 1603:     */     
/* 1604:     */     FilteredEntryMap(Map<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1605:     */     {
/* 1606:2791 */       super(entryPredicate);
/* 1607:2792 */       this.filteredEntrySet = Sets.filter(unfiltered.entrySet(), this.predicate);
/* 1608:     */     }
/* 1609:     */     
/* 1610:     */     protected Set<Map.Entry<K, V>> createEntrySet()
/* 1611:     */     {
/* 1612:2797 */       return new EntrySet(null);
/* 1613:     */     }
/* 1614:     */     
/* 1615:     */     private class EntrySet
/* 1616:     */       extends ForwardingSet<Map.Entry<K, V>>
/* 1617:     */     {
/* 1618:     */       private EntrySet() {}
/* 1619:     */       
/* 1620:     */       protected Set<Map.Entry<K, V>> delegate()
/* 1621:     */       {
/* 1622:2804 */         return Maps.FilteredEntryMap.this.filteredEntrySet;
/* 1623:     */       }
/* 1624:     */       
/* 1625:     */       public Iterator<Map.Entry<K, V>> iterator()
/* 1626:     */       {
/* 1627:2809 */         new TransformedIterator(Maps.FilteredEntryMap.this.filteredEntrySet.iterator())
/* 1628:     */         {
/* 1629:     */           Map.Entry<K, V> transform(final Map.Entry<K, V> entry)
/* 1630:     */           {
/* 1631:2812 */             new ForwardingMapEntry()
/* 1632:     */             {
/* 1633:     */               protected Map.Entry<K, V> delegate()
/* 1634:     */               {
/* 1635:2815 */                 return entry;
/* 1636:     */               }
/* 1637:     */               
/* 1638:     */               public V setValue(V newValue)
/* 1639:     */               {
/* 1640:2820 */                 Preconditions.checkArgument(Maps.FilteredEntryMap.this.apply(getKey(), newValue));
/* 1641:2821 */                 return super.setValue(newValue);
/* 1642:     */               }
/* 1643:     */             };
/* 1644:     */           }
/* 1645:     */         };
/* 1646:     */       }
/* 1647:     */     }
/* 1648:     */     
/* 1649:     */     Set<K> createKeySet()
/* 1650:     */     {
/* 1651:2831 */       return new KeySet();
/* 1652:     */     }
/* 1653:     */     
/* 1654:     */     class KeySet
/* 1655:     */       extends Maps.KeySet<K, V>
/* 1656:     */     {
/* 1657:     */       KeySet()
/* 1658:     */       {
/* 1659:2837 */         super();
/* 1660:     */       }
/* 1661:     */       
/* 1662:     */       public boolean remove(Object o)
/* 1663:     */       {
/* 1664:2842 */         if (Maps.FilteredEntryMap.this.containsKey(o))
/* 1665:     */         {
/* 1666:2843 */           Maps.FilteredEntryMap.this.unfiltered.remove(o);
/* 1667:2844 */           return true;
/* 1668:     */         }
/* 1669:2846 */         return false;
/* 1670:     */       }
/* 1671:     */       
/* 1672:     */       private boolean removeIf(Predicate<? super K> keyPredicate)
/* 1673:     */       {
/* 1674:2850 */         return Iterables.removeIf(Maps.FilteredEntryMap.this.unfiltered.entrySet(), Predicates.and(Maps.FilteredEntryMap.this.predicate, Maps.keyPredicateOnEntries(keyPredicate)));
/* 1675:     */       }
/* 1676:     */       
/* 1677:     */       public boolean removeAll(Collection<?> c)
/* 1678:     */       {
/* 1679:2857 */         return removeIf(Predicates.in(c));
/* 1680:     */       }
/* 1681:     */       
/* 1682:     */       public boolean retainAll(Collection<?> c)
/* 1683:     */       {
/* 1684:2862 */         return removeIf(Predicates.not(Predicates.in(c)));
/* 1685:     */       }
/* 1686:     */       
/* 1687:     */       public Object[] toArray()
/* 1688:     */       {
/* 1689:2868 */         return Lists.newArrayList(iterator()).toArray();
/* 1690:     */       }
/* 1691:     */       
/* 1692:     */       public <T> T[] toArray(T[] array)
/* 1693:     */       {
/* 1694:2873 */         return Lists.newArrayList(iterator()).toArray(array);
/* 1695:     */       }
/* 1696:     */     }
/* 1697:     */   }
/* 1698:     */   
/* 1699:     */   private static <K, V> SortedMap<K, V> filterFiltered(FilteredEntrySortedMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1700:     */   {
/* 1701:2884 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(map.predicate, entryPredicate);
/* 1702:2885 */     return new FilteredEntrySortedMap(map.sortedMap(), predicate);
/* 1703:     */   }
/* 1704:     */   
/* 1705:     */   private static class FilteredEntrySortedMap<K, V>
/* 1706:     */     extends Maps.FilteredEntryMap<K, V>
/* 1707:     */     implements SortedMap<K, V>
/* 1708:     */   {
/* 1709:     */     FilteredEntrySortedMap(SortedMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1710:     */     {
/* 1711:2893 */       super(entryPredicate);
/* 1712:     */     }
/* 1713:     */     
/* 1714:     */     SortedMap<K, V> sortedMap()
/* 1715:     */     {
/* 1716:2897 */       return (SortedMap)this.unfiltered;
/* 1717:     */     }
/* 1718:     */     
/* 1719:     */     public SortedSet<K> keySet()
/* 1720:     */     {
/* 1721:2902 */       return (SortedSet)super.keySet();
/* 1722:     */     }
/* 1723:     */     
/* 1724:     */     SortedSet<K> createKeySet()
/* 1725:     */     {
/* 1726:2907 */       return new SortedKeySet();
/* 1727:     */     }
/* 1728:     */     
/* 1729:     */     class SortedKeySet
/* 1730:     */       extends Maps.FilteredEntryMap<K, V>.KeySet
/* 1731:     */       implements SortedSet<K>
/* 1732:     */     {
/* 1733:     */       SortedKeySet()
/* 1734:     */       {
/* 1735:2911 */         super();
/* 1736:     */       }
/* 1737:     */       
/* 1738:     */       public Comparator<? super K> comparator()
/* 1739:     */       {
/* 1740:2914 */         return Maps.FilteredEntrySortedMap.this.sortedMap().comparator();
/* 1741:     */       }
/* 1742:     */       
/* 1743:     */       public SortedSet<K> subSet(K fromElement, K toElement)
/* 1744:     */       {
/* 1745:2919 */         return (SortedSet)Maps.FilteredEntrySortedMap.this.subMap(fromElement, toElement).keySet();
/* 1746:     */       }
/* 1747:     */       
/* 1748:     */       public SortedSet<K> headSet(K toElement)
/* 1749:     */       {
/* 1750:2924 */         return (SortedSet)Maps.FilteredEntrySortedMap.this.headMap(toElement).keySet();
/* 1751:     */       }
/* 1752:     */       
/* 1753:     */       public SortedSet<K> tailSet(K fromElement)
/* 1754:     */       {
/* 1755:2929 */         return (SortedSet)Maps.FilteredEntrySortedMap.this.tailMap(fromElement).keySet();
/* 1756:     */       }
/* 1757:     */       
/* 1758:     */       public K first()
/* 1759:     */       {
/* 1760:2934 */         return Maps.FilteredEntrySortedMap.this.firstKey();
/* 1761:     */       }
/* 1762:     */       
/* 1763:     */       public K last()
/* 1764:     */       {
/* 1765:2939 */         return Maps.FilteredEntrySortedMap.this.lastKey();
/* 1766:     */       }
/* 1767:     */     }
/* 1768:     */     
/* 1769:     */     public Comparator<? super K> comparator()
/* 1770:     */     {
/* 1771:2945 */       return sortedMap().comparator();
/* 1772:     */     }
/* 1773:     */     
/* 1774:     */     public K firstKey()
/* 1775:     */     {
/* 1776:2951 */       return keySet().iterator().next();
/* 1777:     */     }
/* 1778:     */     
/* 1779:     */     public K lastKey()
/* 1780:     */     {
/* 1781:2956 */       SortedMap<K, V> headMap = sortedMap();
/* 1782:     */       for (;;)
/* 1783:     */       {
/* 1784:2959 */         K key = headMap.lastKey();
/* 1785:2960 */         if (apply(key, this.unfiltered.get(key))) {
/* 1786:2961 */           return key;
/* 1787:     */         }
/* 1788:2963 */         headMap = sortedMap().headMap(key);
/* 1789:     */       }
/* 1790:     */     }
/* 1791:     */     
/* 1792:     */     public SortedMap<K, V> headMap(K toKey)
/* 1793:     */     {
/* 1794:2969 */       return new FilteredEntrySortedMap(sortedMap().headMap(toKey), this.predicate);
/* 1795:     */     }
/* 1796:     */     
/* 1797:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 1798:     */     {
/* 1799:2974 */       return new FilteredEntrySortedMap(sortedMap().subMap(fromKey, toKey), this.predicate);
/* 1800:     */     }
/* 1801:     */     
/* 1802:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 1803:     */     {
/* 1804:2979 */       return new FilteredEntrySortedMap(sortedMap().tailMap(fromKey), this.predicate);
/* 1805:     */     }
/* 1806:     */   }
/* 1807:     */   
/* 1808:     */   @GwtIncompatible("NavigableMap")
/* 1809:     */   private static <K, V> NavigableMap<K, V> filterFiltered(FilteredEntryNavigableMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1810:     */   {
/* 1811:2990 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(map.entryPredicate, entryPredicate);
/* 1812:2991 */     return new FilteredEntryNavigableMap(map.unfiltered, predicate);
/* 1813:     */   }
/* 1814:     */   
/* 1815:     */   @GwtIncompatible("NavigableMap")
/* 1816:     */   private static class FilteredEntryNavigableMap<K, V>
/* 1817:     */     extends AbstractNavigableMap<K, V>
/* 1818:     */   {
/* 1819:     */     private final NavigableMap<K, V> unfiltered;
/* 1820:     */     private final Predicate<? super Map.Entry<K, V>> entryPredicate;
/* 1821:     */     private final Map<K, V> filteredDelegate;
/* 1822:     */     
/* 1823:     */     FilteredEntryNavigableMap(NavigableMap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1824:     */     {
/* 1825:3008 */       this.unfiltered = ((NavigableMap)Preconditions.checkNotNull(unfiltered));
/* 1826:3009 */       this.entryPredicate = entryPredicate;
/* 1827:3010 */       this.filteredDelegate = new Maps.FilteredEntryMap(unfiltered, entryPredicate);
/* 1828:     */     }
/* 1829:     */     
/* 1830:     */     public Comparator<? super K> comparator()
/* 1831:     */     {
/* 1832:3015 */       return this.unfiltered.comparator();
/* 1833:     */     }
/* 1834:     */     
/* 1835:     */     public NavigableSet<K> navigableKeySet()
/* 1836:     */     {
/* 1837:3020 */       new Maps.NavigableKeySet(this)
/* 1838:     */       {
/* 1839:     */         public boolean removeAll(Collection<?> c)
/* 1840:     */         {
/* 1841:3023 */           return Iterators.removeIf(Maps.FilteredEntryNavigableMap.this.unfiltered.entrySet().iterator(), Predicates.and(Maps.FilteredEntryNavigableMap.this.entryPredicate, Maps.keyPredicateOnEntries(Predicates.in(c))));
/* 1842:     */         }
/* 1843:     */         
/* 1844:     */         public boolean retainAll(Collection<?> c)
/* 1845:     */         {
/* 1846:3030 */           return Iterators.removeIf(Maps.FilteredEntryNavigableMap.this.unfiltered.entrySet().iterator(), Predicates.and(Maps.FilteredEntryNavigableMap.this.entryPredicate, Maps.keyPredicateOnEntries(Predicates.not(Predicates.in(c)))));
/* 1847:     */         }
/* 1848:     */       };
/* 1849:     */     }
/* 1850:     */     
/* 1851:     */     public Collection<V> values()
/* 1852:     */     {
/* 1853:3040 */       return new Maps.FilteredMapValues(this, this.unfiltered, this.entryPredicate);
/* 1854:     */     }
/* 1855:     */     
/* 1856:     */     Iterator<Map.Entry<K, V>> entryIterator()
/* 1857:     */     {
/* 1858:3045 */       return Iterators.filter(this.unfiltered.entrySet().iterator(), this.entryPredicate);
/* 1859:     */     }
/* 1860:     */     
/* 1861:     */     Iterator<Map.Entry<K, V>> descendingEntryIterator()
/* 1862:     */     {
/* 1863:3050 */       return Iterators.filter(this.unfiltered.descendingMap().entrySet().iterator(), this.entryPredicate);
/* 1864:     */     }
/* 1865:     */     
/* 1866:     */     public int size()
/* 1867:     */     {
/* 1868:3055 */       return this.filteredDelegate.size();
/* 1869:     */     }
/* 1870:     */     
/* 1871:     */     public boolean isEmpty()
/* 1872:     */     {
/* 1873:3060 */       return !Iterables.any(this.unfiltered.entrySet(), this.entryPredicate);
/* 1874:     */     }
/* 1875:     */     
/* 1876:     */     @Nullable
/* 1877:     */     public V get(@Nullable Object key)
/* 1878:     */     {
/* 1879:3066 */       return this.filteredDelegate.get(key);
/* 1880:     */     }
/* 1881:     */     
/* 1882:     */     public boolean containsKey(@Nullable Object key)
/* 1883:     */     {
/* 1884:3071 */       return this.filteredDelegate.containsKey(key);
/* 1885:     */     }
/* 1886:     */     
/* 1887:     */     public V put(K key, V value)
/* 1888:     */     {
/* 1889:3076 */       return this.filteredDelegate.put(key, value);
/* 1890:     */     }
/* 1891:     */     
/* 1892:     */     public V remove(@Nullable Object key)
/* 1893:     */     {
/* 1894:3081 */       return this.filteredDelegate.remove(key);
/* 1895:     */     }
/* 1896:     */     
/* 1897:     */     public void putAll(Map<? extends K, ? extends V> m)
/* 1898:     */     {
/* 1899:3086 */       this.filteredDelegate.putAll(m);
/* 1900:     */     }
/* 1901:     */     
/* 1902:     */     public void clear()
/* 1903:     */     {
/* 1904:3091 */       this.filteredDelegate.clear();
/* 1905:     */     }
/* 1906:     */     
/* 1907:     */     public Set<Map.Entry<K, V>> entrySet()
/* 1908:     */     {
/* 1909:3096 */       return this.filteredDelegate.entrySet();
/* 1910:     */     }
/* 1911:     */     
/* 1912:     */     public Map.Entry<K, V> pollFirstEntry()
/* 1913:     */     {
/* 1914:3101 */       return (Map.Entry)Iterables.removeFirstMatching(this.unfiltered.entrySet(), this.entryPredicate);
/* 1915:     */     }
/* 1916:     */     
/* 1917:     */     public Map.Entry<K, V> pollLastEntry()
/* 1918:     */     {
/* 1919:3106 */       return (Map.Entry)Iterables.removeFirstMatching(this.unfiltered.descendingMap().entrySet(), this.entryPredicate);
/* 1920:     */     }
/* 1921:     */     
/* 1922:     */     public NavigableMap<K, V> descendingMap()
/* 1923:     */     {
/* 1924:3111 */       return Maps.filterEntries(this.unfiltered.descendingMap(), this.entryPredicate);
/* 1925:     */     }
/* 1926:     */     
/* 1927:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 1928:     */     {
/* 1929:3117 */       return Maps.filterEntries(this.unfiltered.subMap(fromKey, fromInclusive, toKey, toInclusive), this.entryPredicate);
/* 1930:     */     }
/* 1931:     */     
/* 1932:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 1933:     */     {
/* 1934:3123 */       return Maps.filterEntries(this.unfiltered.headMap(toKey, inclusive), this.entryPredicate);
/* 1935:     */     }
/* 1936:     */     
/* 1937:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 1938:     */     {
/* 1939:3128 */       return Maps.filterEntries(this.unfiltered.tailMap(fromKey, inclusive), this.entryPredicate);
/* 1940:     */     }
/* 1941:     */   }
/* 1942:     */   
/* 1943:     */   private static <K, V> BiMap<K, V> filterFiltered(FilteredEntryBiMap<K, V> map, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1944:     */   {
/* 1945:3138 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(map.predicate, entryPredicate);
/* 1946:3139 */     return new FilteredEntryBiMap(map.unfiltered(), predicate);
/* 1947:     */   }
/* 1948:     */   
/* 1949:     */   static final class FilteredEntryBiMap<K, V>
/* 1950:     */     extends Maps.FilteredEntryMap<K, V>
/* 1951:     */     implements BiMap<K, V>
/* 1952:     */   {
/* 1953:     */     private final BiMap<V, K> inverse;
/* 1954:     */     
/* 1955:     */     private static <K, V> Predicate<Map.Entry<V, K>> inversePredicate(Predicate<? super Map.Entry<K, V>> forwardPredicate)
/* 1956:     */     {
/* 1957:3148 */       new Predicate()
/* 1958:     */       {
/* 1959:     */         public boolean apply(Map.Entry<V, K> input)
/* 1960:     */         {
/* 1961:3151 */           return this.val$forwardPredicate.apply(Maps.immutableEntry(input.getValue(), input.getKey()));
/* 1962:     */         }
/* 1963:     */       };
/* 1964:     */     }
/* 1965:     */     
/* 1966:     */     FilteredEntryBiMap(BiMap<K, V> delegate, Predicate<? super Map.Entry<K, V>> predicate)
/* 1967:     */     {
/* 1968:3157 */       super(predicate);
/* 1969:3158 */       this.inverse = new FilteredEntryBiMap(delegate.inverse(), inversePredicate(predicate), this);
/* 1970:     */     }
/* 1971:     */     
/* 1972:     */     private FilteredEntryBiMap(BiMap<K, V> delegate, Predicate<? super Map.Entry<K, V>> predicate, BiMap<V, K> inverse)
/* 1973:     */     {
/* 1974:3164 */       super(predicate);
/* 1975:3165 */       this.inverse = inverse;
/* 1976:     */     }
/* 1977:     */     
/* 1978:     */     BiMap<K, V> unfiltered()
/* 1979:     */     {
/* 1980:3169 */       return (BiMap)this.unfiltered;
/* 1981:     */     }
/* 1982:     */     
/* 1983:     */     public V forcePut(@Nullable K key, @Nullable V value)
/* 1984:     */     {
/* 1985:3174 */       Preconditions.checkArgument(apply(key, value));
/* 1986:3175 */       return unfiltered().forcePut(key, value);
/* 1987:     */     }
/* 1988:     */     
/* 1989:     */     public BiMap<V, K> inverse()
/* 1990:     */     {
/* 1991:3180 */       return this.inverse;
/* 1992:     */     }
/* 1993:     */     
/* 1994:     */     public Set<V> values()
/* 1995:     */     {
/* 1996:3185 */       return this.inverse.keySet();
/* 1997:     */     }
/* 1998:     */   }
/* 1999:     */   
/* 2000:     */   @GwtIncompatible("NavigableMap")
/* 2001:     */   public static <K, V> NavigableMap<K, V> unmodifiableNavigableMap(NavigableMap<K, V> map)
/* 2002:     */   {
/* 2003:3203 */     Preconditions.checkNotNull(map);
/* 2004:3204 */     if ((map instanceof UnmodifiableNavigableMap)) {
/* 2005:3205 */       return map;
/* 2006:     */     }
/* 2007:3207 */     return new UnmodifiableNavigableMap(map);
/* 2008:     */   }
/* 2009:     */   
/* 2010:     */   @Nullable
/* 2011:     */   private static <K, V> Map.Entry<K, V> unmodifiableOrNull(@Nullable Map.Entry<K, V> entry)
/* 2012:     */   {
/* 2013:3213 */     return entry == null ? null : unmodifiableEntry(entry);
/* 2014:     */   }
/* 2015:     */   
/* 2016:     */   @GwtIncompatible("NavigableMap")
/* 2017:     */   static class UnmodifiableNavigableMap<K, V>
/* 2018:     */     extends ForwardingSortedMap<K, V>
/* 2019:     */     implements NavigableMap<K, V>, Serializable
/* 2020:     */   {
/* 2021:     */     private final NavigableMap<K, V> delegate;
/* 2022:     */     private transient UnmodifiableNavigableMap<K, V> descendingMap;
/* 2023:     */     
/* 2024:     */     UnmodifiableNavigableMap(NavigableMap<K, V> delegate)
/* 2025:     */     {
/* 2026:3222 */       this.delegate = delegate;
/* 2027:     */     }
/* 2028:     */     
/* 2029:     */     UnmodifiableNavigableMap(NavigableMap<K, V> delegate, UnmodifiableNavigableMap<K, V> descendingMap)
/* 2030:     */     {
/* 2031:3227 */       this.delegate = delegate;
/* 2032:3228 */       this.descendingMap = descendingMap;
/* 2033:     */     }
/* 2034:     */     
/* 2035:     */     protected SortedMap<K, V> delegate()
/* 2036:     */     {
/* 2037:3233 */       return Collections.unmodifiableSortedMap(this.delegate);
/* 2038:     */     }
/* 2039:     */     
/* 2040:     */     public Map.Entry<K, V> lowerEntry(K key)
/* 2041:     */     {
/* 2042:3238 */       return Maps.unmodifiableOrNull(this.delegate.lowerEntry(key));
/* 2043:     */     }
/* 2044:     */     
/* 2045:     */     public K lowerKey(K key)
/* 2046:     */     {
/* 2047:3243 */       return this.delegate.lowerKey(key);
/* 2048:     */     }
/* 2049:     */     
/* 2050:     */     public Map.Entry<K, V> floorEntry(K key)
/* 2051:     */     {
/* 2052:3248 */       return Maps.unmodifiableOrNull(this.delegate.floorEntry(key));
/* 2053:     */     }
/* 2054:     */     
/* 2055:     */     public K floorKey(K key)
/* 2056:     */     {
/* 2057:3253 */       return this.delegate.floorKey(key);
/* 2058:     */     }
/* 2059:     */     
/* 2060:     */     public Map.Entry<K, V> ceilingEntry(K key)
/* 2061:     */     {
/* 2062:3258 */       return Maps.unmodifiableOrNull(this.delegate.ceilingEntry(key));
/* 2063:     */     }
/* 2064:     */     
/* 2065:     */     public K ceilingKey(K key)
/* 2066:     */     {
/* 2067:3263 */       return this.delegate.ceilingKey(key);
/* 2068:     */     }
/* 2069:     */     
/* 2070:     */     public Map.Entry<K, V> higherEntry(K key)
/* 2071:     */     {
/* 2072:3268 */       return Maps.unmodifiableOrNull(this.delegate.higherEntry(key));
/* 2073:     */     }
/* 2074:     */     
/* 2075:     */     public K higherKey(K key)
/* 2076:     */     {
/* 2077:3273 */       return this.delegate.higherKey(key);
/* 2078:     */     }
/* 2079:     */     
/* 2080:     */     public Map.Entry<K, V> firstEntry()
/* 2081:     */     {
/* 2082:3278 */       return Maps.unmodifiableOrNull(this.delegate.firstEntry());
/* 2083:     */     }
/* 2084:     */     
/* 2085:     */     public Map.Entry<K, V> lastEntry()
/* 2086:     */     {
/* 2087:3283 */       return Maps.unmodifiableOrNull(this.delegate.lastEntry());
/* 2088:     */     }
/* 2089:     */     
/* 2090:     */     public final Map.Entry<K, V> pollFirstEntry()
/* 2091:     */     {
/* 2092:3288 */       throw new UnsupportedOperationException();
/* 2093:     */     }
/* 2094:     */     
/* 2095:     */     public final Map.Entry<K, V> pollLastEntry()
/* 2096:     */     {
/* 2097:3293 */       throw new UnsupportedOperationException();
/* 2098:     */     }
/* 2099:     */     
/* 2100:     */     public NavigableMap<K, V> descendingMap()
/* 2101:     */     {
/* 2102:3300 */       UnmodifiableNavigableMap<K, V> result = this.descendingMap;
/* 2103:3301 */       return result == null ? (this.descendingMap = new UnmodifiableNavigableMap(this.delegate.descendingMap(), this)) : result;
/* 2104:     */     }
/* 2105:     */     
/* 2106:     */     public Set<K> keySet()
/* 2107:     */     {
/* 2108:3308 */       return navigableKeySet();
/* 2109:     */     }
/* 2110:     */     
/* 2111:     */     public NavigableSet<K> navigableKeySet()
/* 2112:     */     {
/* 2113:3313 */       return Sets.unmodifiableNavigableSet(this.delegate.navigableKeySet());
/* 2114:     */     }
/* 2115:     */     
/* 2116:     */     public NavigableSet<K> descendingKeySet()
/* 2117:     */     {
/* 2118:3318 */       return Sets.unmodifiableNavigableSet(this.delegate.descendingKeySet());
/* 2119:     */     }
/* 2120:     */     
/* 2121:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 2122:     */     {
/* 2123:3323 */       return subMap(fromKey, true, toKey, false);
/* 2124:     */     }
/* 2125:     */     
/* 2126:     */     public SortedMap<K, V> headMap(K toKey)
/* 2127:     */     {
/* 2128:3328 */       return headMap(toKey, false);
/* 2129:     */     }
/* 2130:     */     
/* 2131:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 2132:     */     {
/* 2133:3333 */       return tailMap(fromKey, true);
/* 2134:     */     }
/* 2135:     */     
/* 2136:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 2137:     */     {
/* 2138:3339 */       return Maps.unmodifiableNavigableMap(this.delegate.subMap(fromKey, fromInclusive, toKey, toInclusive));
/* 2139:     */     }
/* 2140:     */     
/* 2141:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 2142:     */     {
/* 2143:3345 */       return Maps.unmodifiableNavigableMap(this.delegate.headMap(toKey, inclusive));
/* 2144:     */     }
/* 2145:     */     
/* 2146:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 2147:     */     {
/* 2148:3350 */       return Maps.unmodifiableNavigableMap(this.delegate.tailMap(fromKey, inclusive));
/* 2149:     */     }
/* 2150:     */   }
/* 2151:     */   
/* 2152:     */   @GwtIncompatible("NavigableMap")
/* 2153:     */   public static <K, V> NavigableMap<K, V> synchronizedNavigableMap(NavigableMap<K, V> navigableMap)
/* 2154:     */   {
/* 2155:3405 */     return Synchronized.navigableMap(navigableMap);
/* 2156:     */   }
/* 2157:     */   
/* 2158:     */   @GwtCompatible
/* 2159:     */   static abstract class ViewCachingAbstractMap<K, V>
/* 2160:     */     extends AbstractMap<K, V>
/* 2161:     */   {
/* 2162:     */     private transient Set<Map.Entry<K, V>> entrySet;
/* 2163:     */     private transient Set<K> keySet;
/* 2164:     */     private transient Collection<V> values;
/* 2165:     */     
/* 2166:     */     abstract Set<Map.Entry<K, V>> createEntrySet();
/* 2167:     */     
/* 2168:     */     public Set<Map.Entry<K, V>> entrySet()
/* 2169:     */     {
/* 2170:3425 */       Set<Map.Entry<K, V>> result = this.entrySet;
/* 2171:3426 */       return result == null ? (this.entrySet = createEntrySet()) : result;
/* 2172:     */     }
/* 2173:     */     
/* 2174:     */     public Set<K> keySet()
/* 2175:     */     {
/* 2176:3433 */       Set<K> result = this.keySet;
/* 2177:3434 */       return result == null ? (this.keySet = createKeySet()) : result;
/* 2178:     */     }
/* 2179:     */     
/* 2180:     */     Set<K> createKeySet()
/* 2181:     */     {
/* 2182:3438 */       return new Maps.KeySet(this);
/* 2183:     */     }
/* 2184:     */     
/* 2185:     */     public Collection<V> values()
/* 2186:     */     {
/* 2187:3445 */       Collection<V> result = this.values;
/* 2188:3446 */       return result == null ? (this.values = createValues()) : result;
/* 2189:     */     }
/* 2190:     */     
/* 2191:     */     Collection<V> createValues()
/* 2192:     */     {
/* 2193:3450 */       return new Maps.Values(this);
/* 2194:     */     }
/* 2195:     */   }
/* 2196:     */   
/* 2197:     */   static abstract class IteratorBasedAbstractMap<K, V>
/* 2198:     */     extends AbstractMap<K, V>
/* 2199:     */   {
/* 2200:     */     public abstract int size();
/* 2201:     */     
/* 2202:     */     abstract Iterator<Map.Entry<K, V>> entryIterator();
/* 2203:     */     
/* 2204:     */     public Set<Map.Entry<K, V>> entrySet()
/* 2205:     */     {
/* 2206:3462 */       new Maps.EntrySet()
/* 2207:     */       {
/* 2208:     */         Map<K, V> map()
/* 2209:     */         {
/* 2210:3465 */           return Maps.IteratorBasedAbstractMap.this;
/* 2211:     */         }
/* 2212:     */         
/* 2213:     */         public Iterator<Map.Entry<K, V>> iterator()
/* 2214:     */         {
/* 2215:3470 */           return Maps.IteratorBasedAbstractMap.this.entryIterator();
/* 2216:     */         }
/* 2217:     */       };
/* 2218:     */     }
/* 2219:     */     
/* 2220:     */     public void clear()
/* 2221:     */     {
/* 2222:3477 */       Iterators.clear(entryIterator());
/* 2223:     */     }
/* 2224:     */   }
/* 2225:     */   
/* 2226:     */   static <V> V safeGet(Map<?, V> map, @Nullable Object key)
/* 2227:     */   {
/* 2228:3486 */     Preconditions.checkNotNull(map);
/* 2229:     */     try
/* 2230:     */     {
/* 2231:3488 */       return map.get(key);
/* 2232:     */     }
/* 2233:     */     catch (ClassCastException e)
/* 2234:     */     {
/* 2235:3490 */       return null;
/* 2236:     */     }
/* 2237:     */     catch (NullPointerException e) {}
/* 2238:3492 */     return null;
/* 2239:     */   }
/* 2240:     */   
/* 2241:     */   static boolean safeContainsKey(Map<?, ?> map, Object key)
/* 2242:     */   {
/* 2243:3501 */     Preconditions.checkNotNull(map);
/* 2244:     */     try
/* 2245:     */     {
/* 2246:3503 */       return map.containsKey(key);
/* 2247:     */     }
/* 2248:     */     catch (ClassCastException e)
/* 2249:     */     {
/* 2250:3505 */       return false;
/* 2251:     */     }
/* 2252:     */     catch (NullPointerException e) {}
/* 2253:3507 */     return false;
/* 2254:     */   }
/* 2255:     */   
/* 2256:     */   static <V> V safeRemove(Map<?, V> map, Object key)
/* 2257:     */   {
/* 2258:3516 */     Preconditions.checkNotNull(map);
/* 2259:     */     try
/* 2260:     */     {
/* 2261:3518 */       return map.remove(key);
/* 2262:     */     }
/* 2263:     */     catch (ClassCastException e)
/* 2264:     */     {
/* 2265:3520 */       return null;
/* 2266:     */     }
/* 2267:     */     catch (NullPointerException e) {}
/* 2268:3522 */     return null;
/* 2269:     */   }
/* 2270:     */   
/* 2271:     */   static boolean containsKeyImpl(Map<?, ?> map, @Nullable Object key)
/* 2272:     */   {
/* 2273:3530 */     return Iterators.contains(keyIterator(map.entrySet().iterator()), key);
/* 2274:     */   }
/* 2275:     */   
/* 2276:     */   static boolean containsValueImpl(Map<?, ?> map, @Nullable Object value)
/* 2277:     */   {
/* 2278:3537 */     return Iterators.contains(valueIterator(map.entrySet().iterator()), value);
/* 2279:     */   }
/* 2280:     */   
/* 2281:     */   static <K, V> boolean containsEntryImpl(Collection<Map.Entry<K, V>> c, Object o)
/* 2282:     */   {
/* 2283:3554 */     if (!(o instanceof Map.Entry)) {
/* 2284:3555 */       return false;
/* 2285:     */     }
/* 2286:3557 */     return c.contains(unmodifiableEntry((Map.Entry)o));
/* 2287:     */   }
/* 2288:     */   
/* 2289:     */   static <K, V> boolean removeEntryImpl(Collection<Map.Entry<K, V>> c, Object o)
/* 2290:     */   {
/* 2291:3574 */     if (!(o instanceof Map.Entry)) {
/* 2292:3575 */       return false;
/* 2293:     */     }
/* 2294:3577 */     return c.remove(unmodifiableEntry((Map.Entry)o));
/* 2295:     */   }
/* 2296:     */   
/* 2297:     */   static boolean equalsImpl(Map<?, ?> map, Object object)
/* 2298:     */   {
/* 2299:3584 */     if (map == object) {
/* 2300:3585 */       return true;
/* 2301:     */     }
/* 2302:3586 */     if ((object instanceof Map))
/* 2303:     */     {
/* 2304:3587 */       Map<?, ?> o = (Map)object;
/* 2305:3588 */       return map.entrySet().equals(o.entrySet());
/* 2306:     */     }
/* 2307:3590 */     return false;
/* 2308:     */   }
/* 2309:     */   
/* 2310:3593 */   static final Joiner.MapJoiner STANDARD_JOINER = Collections2.STANDARD_JOINER.withKeyValueSeparator("=");
/* 2311:     */   
/* 2312:     */   static String toStringImpl(Map<?, ?> map)
/* 2313:     */   {
/* 2314:3599 */     StringBuilder sb = Collections2.newStringBuilderForCollection(map.size()).append('{');
/* 2315:3600 */     STANDARD_JOINER.appendTo(sb, map);
/* 2316:3601 */     return '}';
/* 2317:     */   }
/* 2318:     */   
/* 2319:     */   static <K, V> void putAllImpl(Map<K, V> self, Map<? extends K, ? extends V> map)
/* 2320:     */   {
/* 2321:3608 */     for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 2322:3609 */       self.put(entry.getKey(), entry.getValue());
/* 2323:     */     }
/* 2324:     */   }
/* 2325:     */   
/* 2326:     */   static class KeySet<K, V>
/* 2327:     */     extends Sets.ImprovedAbstractSet<K>
/* 2328:     */   {
/* 2329:     */     @Weak
/* 2330:     */     final Map<K, V> map;
/* 2331:     */     
/* 2332:     */     KeySet(Map<K, V> map)
/* 2333:     */     {
/* 2334:3617 */       this.map = ((Map)Preconditions.checkNotNull(map));
/* 2335:     */     }
/* 2336:     */     
/* 2337:     */     Map<K, V> map()
/* 2338:     */     {
/* 2339:3621 */       return this.map;
/* 2340:     */     }
/* 2341:     */     
/* 2342:     */     public Iterator<K> iterator()
/* 2343:     */     {
/* 2344:3626 */       return Maps.keyIterator(map().entrySet().iterator());
/* 2345:     */     }
/* 2346:     */     
/* 2347:     */     public int size()
/* 2348:     */     {
/* 2349:3631 */       return map().size();
/* 2350:     */     }
/* 2351:     */     
/* 2352:     */     public boolean isEmpty()
/* 2353:     */     {
/* 2354:3636 */       return map().isEmpty();
/* 2355:     */     }
/* 2356:     */     
/* 2357:     */     public boolean contains(Object o)
/* 2358:     */     {
/* 2359:3641 */       return map().containsKey(o);
/* 2360:     */     }
/* 2361:     */     
/* 2362:     */     public boolean remove(Object o)
/* 2363:     */     {
/* 2364:3646 */       if (contains(o))
/* 2365:     */       {
/* 2366:3647 */         map().remove(o);
/* 2367:3648 */         return true;
/* 2368:     */       }
/* 2369:3650 */       return false;
/* 2370:     */     }
/* 2371:     */     
/* 2372:     */     public void clear()
/* 2373:     */     {
/* 2374:3655 */       map().clear();
/* 2375:     */     }
/* 2376:     */   }
/* 2377:     */   
/* 2378:     */   @Nullable
/* 2379:     */   static <K> K keyOrNull(@Nullable Map.Entry<K, ?> entry)
/* 2380:     */   {
/* 2381:3661 */     return entry == null ? null : entry.getKey();
/* 2382:     */   }
/* 2383:     */   
/* 2384:     */   @Nullable
/* 2385:     */   static <V> V valueOrNull(@Nullable Map.Entry<?, V> entry)
/* 2386:     */   {
/* 2387:3666 */     return entry == null ? null : entry.getValue();
/* 2388:     */   }
/* 2389:     */   
/* 2390:     */   static class SortedKeySet<K, V>
/* 2391:     */     extends Maps.KeySet<K, V>
/* 2392:     */     implements SortedSet<K>
/* 2393:     */   {
/* 2394:     */     SortedKeySet(SortedMap<K, V> map)
/* 2395:     */     {
/* 2396:3671 */       super();
/* 2397:     */     }
/* 2398:     */     
/* 2399:     */     SortedMap<K, V> map()
/* 2400:     */     {
/* 2401:3676 */       return (SortedMap)super.map();
/* 2402:     */     }
/* 2403:     */     
/* 2404:     */     public Comparator<? super K> comparator()
/* 2405:     */     {
/* 2406:3681 */       return map().comparator();
/* 2407:     */     }
/* 2408:     */     
/* 2409:     */     public SortedSet<K> subSet(K fromElement, K toElement)
/* 2410:     */     {
/* 2411:3686 */       return new SortedKeySet(map().subMap(fromElement, toElement));
/* 2412:     */     }
/* 2413:     */     
/* 2414:     */     public SortedSet<K> headSet(K toElement)
/* 2415:     */     {
/* 2416:3691 */       return new SortedKeySet(map().headMap(toElement));
/* 2417:     */     }
/* 2418:     */     
/* 2419:     */     public SortedSet<K> tailSet(K fromElement)
/* 2420:     */     {
/* 2421:3696 */       return new SortedKeySet(map().tailMap(fromElement));
/* 2422:     */     }
/* 2423:     */     
/* 2424:     */     public K first()
/* 2425:     */     {
/* 2426:3701 */       return map().firstKey();
/* 2427:     */     }
/* 2428:     */     
/* 2429:     */     public K last()
/* 2430:     */     {
/* 2431:3706 */       return map().lastKey();
/* 2432:     */     }
/* 2433:     */   }
/* 2434:     */   
/* 2435:     */   @GwtIncompatible("NavigableMap")
/* 2436:     */   static class NavigableKeySet<K, V>
/* 2437:     */     extends Maps.SortedKeySet<K, V>
/* 2438:     */     implements NavigableSet<K>
/* 2439:     */   {
/* 2440:     */     NavigableKeySet(NavigableMap<K, V> map)
/* 2441:     */     {
/* 2442:3713 */       super();
/* 2443:     */     }
/* 2444:     */     
/* 2445:     */     NavigableMap<K, V> map()
/* 2446:     */     {
/* 2447:3718 */       return (NavigableMap)this.map;
/* 2448:     */     }
/* 2449:     */     
/* 2450:     */     public K lower(K e)
/* 2451:     */     {
/* 2452:3723 */       return map().lowerKey(e);
/* 2453:     */     }
/* 2454:     */     
/* 2455:     */     public K floor(K e)
/* 2456:     */     {
/* 2457:3728 */       return map().floorKey(e);
/* 2458:     */     }
/* 2459:     */     
/* 2460:     */     public K ceiling(K e)
/* 2461:     */     {
/* 2462:3733 */       return map().ceilingKey(e);
/* 2463:     */     }
/* 2464:     */     
/* 2465:     */     public K higher(K e)
/* 2466:     */     {
/* 2467:3738 */       return map().higherKey(e);
/* 2468:     */     }
/* 2469:     */     
/* 2470:     */     public K pollFirst()
/* 2471:     */     {
/* 2472:3743 */       return Maps.keyOrNull(map().pollFirstEntry());
/* 2473:     */     }
/* 2474:     */     
/* 2475:     */     public K pollLast()
/* 2476:     */     {
/* 2477:3748 */       return Maps.keyOrNull(map().pollLastEntry());
/* 2478:     */     }
/* 2479:     */     
/* 2480:     */     public NavigableSet<K> descendingSet()
/* 2481:     */     {
/* 2482:3753 */       return map().descendingKeySet();
/* 2483:     */     }
/* 2484:     */     
/* 2485:     */     public Iterator<K> descendingIterator()
/* 2486:     */     {
/* 2487:3758 */       return descendingSet().iterator();
/* 2488:     */     }
/* 2489:     */     
/* 2490:     */     public NavigableSet<K> subSet(K fromElement, boolean fromInclusive, K toElement, boolean toInclusive)
/* 2491:     */     {
/* 2492:3764 */       return map().subMap(fromElement, fromInclusive, toElement, toInclusive).navigableKeySet();
/* 2493:     */     }
/* 2494:     */     
/* 2495:     */     public NavigableSet<K> headSet(K toElement, boolean inclusive)
/* 2496:     */     {
/* 2497:3769 */       return map().headMap(toElement, inclusive).navigableKeySet();
/* 2498:     */     }
/* 2499:     */     
/* 2500:     */     public NavigableSet<K> tailSet(K fromElement, boolean inclusive)
/* 2501:     */     {
/* 2502:3774 */       return map().tailMap(fromElement, inclusive).navigableKeySet();
/* 2503:     */     }
/* 2504:     */     
/* 2505:     */     public SortedSet<K> subSet(K fromElement, K toElement)
/* 2506:     */     {
/* 2507:3779 */       return subSet(fromElement, true, toElement, false);
/* 2508:     */     }
/* 2509:     */     
/* 2510:     */     public SortedSet<K> headSet(K toElement)
/* 2511:     */     {
/* 2512:3784 */       return headSet(toElement, false);
/* 2513:     */     }
/* 2514:     */     
/* 2515:     */     public SortedSet<K> tailSet(K fromElement)
/* 2516:     */     {
/* 2517:3789 */       return tailSet(fromElement, true);
/* 2518:     */     }
/* 2519:     */   }
/* 2520:     */   
/* 2521:     */   static class Values<K, V>
/* 2522:     */     extends AbstractCollection<V>
/* 2523:     */   {
/* 2524:     */     @Weak
/* 2525:     */     final Map<K, V> map;
/* 2526:     */     
/* 2527:     */     Values(Map<K, V> map)
/* 2528:     */     {
/* 2529:3797 */       this.map = ((Map)Preconditions.checkNotNull(map));
/* 2530:     */     }
/* 2531:     */     
/* 2532:     */     final Map<K, V> map()
/* 2533:     */     {
/* 2534:3801 */       return this.map;
/* 2535:     */     }
/* 2536:     */     
/* 2537:     */     public Iterator<V> iterator()
/* 2538:     */     {
/* 2539:3806 */       return Maps.valueIterator(map().entrySet().iterator());
/* 2540:     */     }
/* 2541:     */     
/* 2542:     */     public boolean remove(Object o)
/* 2543:     */     {
/* 2544:     */       try
/* 2545:     */       {
/* 2546:3812 */         return super.remove(o);
/* 2547:     */       }
/* 2548:     */       catch (UnsupportedOperationException e)
/* 2549:     */       {
/* 2550:3814 */         for (Map.Entry<K, V> entry : map().entrySet()) {
/* 2551:3815 */           if (Objects.equal(o, entry.getValue()))
/* 2552:     */           {
/* 2553:3816 */             map().remove(entry.getKey());
/* 2554:3817 */             return true;
/* 2555:     */           }
/* 2556:     */         }
/* 2557:     */       }
/* 2558:3820 */       return false;
/* 2559:     */     }
/* 2560:     */     
/* 2561:     */     public boolean removeAll(Collection<?> c)
/* 2562:     */     {
/* 2563:     */       try
/* 2564:     */       {
/* 2565:3827 */         return super.removeAll((Collection)Preconditions.checkNotNull(c));
/* 2566:     */       }
/* 2567:     */       catch (UnsupportedOperationException e)
/* 2568:     */       {
/* 2569:3829 */         Set<K> toRemove = Sets.newHashSet();
/* 2570:3830 */         for (Map.Entry<K, V> entry : map().entrySet()) {
/* 2571:3831 */           if (c.contains(entry.getValue())) {
/* 2572:3832 */             toRemove.add(entry.getKey());
/* 2573:     */           }
/* 2574:     */         }
/* 2575:3835 */         return map().keySet().removeAll(toRemove);
/* 2576:     */       }
/* 2577:     */     }
/* 2578:     */     
/* 2579:     */     public boolean retainAll(Collection<?> c)
/* 2580:     */     {
/* 2581:     */       try
/* 2582:     */       {
/* 2583:3842 */         return super.retainAll((Collection)Preconditions.checkNotNull(c));
/* 2584:     */       }
/* 2585:     */       catch (UnsupportedOperationException e)
/* 2586:     */       {
/* 2587:3844 */         Set<K> toRetain = Sets.newHashSet();
/* 2588:3845 */         for (Map.Entry<K, V> entry : map().entrySet()) {
/* 2589:3846 */           if (c.contains(entry.getValue())) {
/* 2590:3847 */             toRetain.add(entry.getKey());
/* 2591:     */           }
/* 2592:     */         }
/* 2593:3850 */         return map().keySet().retainAll(toRetain);
/* 2594:     */       }
/* 2595:     */     }
/* 2596:     */     
/* 2597:     */     public int size()
/* 2598:     */     {
/* 2599:3856 */       return map().size();
/* 2600:     */     }
/* 2601:     */     
/* 2602:     */     public boolean isEmpty()
/* 2603:     */     {
/* 2604:3861 */       return map().isEmpty();
/* 2605:     */     }
/* 2606:     */     
/* 2607:     */     public boolean contains(@Nullable Object o)
/* 2608:     */     {
/* 2609:3866 */       return map().containsValue(o);
/* 2610:     */     }
/* 2611:     */     
/* 2612:     */     public void clear()
/* 2613:     */     {
/* 2614:3871 */       map().clear();
/* 2615:     */     }
/* 2616:     */   }
/* 2617:     */   
/* 2618:     */   static abstract class EntrySet<K, V>
/* 2619:     */     extends Sets.ImprovedAbstractSet<Map.Entry<K, V>>
/* 2620:     */   {
/* 2621:     */     abstract Map<K, V> map();
/* 2622:     */     
/* 2623:     */     public int size()
/* 2624:     */     {
/* 2625:3880 */       return map().size();
/* 2626:     */     }
/* 2627:     */     
/* 2628:     */     public void clear()
/* 2629:     */     {
/* 2630:3885 */       map().clear();
/* 2631:     */     }
/* 2632:     */     
/* 2633:     */     public boolean contains(Object o)
/* 2634:     */     {
/* 2635:3890 */       if ((o instanceof Map.Entry))
/* 2636:     */       {
/* 2637:3891 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 2638:3892 */         Object key = entry.getKey();
/* 2639:3893 */         V value = Maps.safeGet(map(), key);
/* 2640:3894 */         return (Objects.equal(value, entry.getValue())) && ((value != null) || (map().containsKey(key)));
/* 2641:     */       }
/* 2642:3896 */       return false;
/* 2643:     */     }
/* 2644:     */     
/* 2645:     */     public boolean isEmpty()
/* 2646:     */     {
/* 2647:3901 */       return map().isEmpty();
/* 2648:     */     }
/* 2649:     */     
/* 2650:     */     public boolean remove(Object o)
/* 2651:     */     {
/* 2652:3906 */       if (contains(o))
/* 2653:     */       {
/* 2654:3907 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 2655:3908 */         return map().keySet().remove(entry.getKey());
/* 2656:     */       }
/* 2657:3910 */       return false;
/* 2658:     */     }
/* 2659:     */     
/* 2660:     */     public boolean removeAll(Collection<?> c)
/* 2661:     */     {
/* 2662:     */       try
/* 2663:     */       {
/* 2664:3916 */         return super.removeAll((Collection)Preconditions.checkNotNull(c));
/* 2665:     */       }
/* 2666:     */       catch (UnsupportedOperationException e) {}
/* 2667:3919 */       return Sets.removeAllImpl(this, c.iterator());
/* 2668:     */     }
/* 2669:     */     
/* 2670:     */     public boolean retainAll(Collection<?> c)
/* 2671:     */     {
/* 2672:     */       try
/* 2673:     */       {
/* 2674:3926 */         return super.retainAll((Collection)Preconditions.checkNotNull(c));
/* 2675:     */       }
/* 2676:     */       catch (UnsupportedOperationException e)
/* 2677:     */       {
/* 2678:3929 */         Set<Object> keys = Sets.newHashSetWithExpectedSize(c.size());
/* 2679:3930 */         for (Object o : c) {
/* 2680:3931 */           if (contains(o))
/* 2681:     */           {
/* 2682:3932 */             Map.Entry<?, ?> entry = (Map.Entry)o;
/* 2683:3933 */             keys.add(entry.getKey());
/* 2684:     */           }
/* 2685:     */         }
/* 2686:3936 */         return map().keySet().retainAll(keys);
/* 2687:     */       }
/* 2688:     */     }
/* 2689:     */   }
/* 2690:     */   
/* 2691:     */   @GwtIncompatible("NavigableMap")
/* 2692:     */   static abstract class DescendingMap<K, V>
/* 2693:     */     extends ForwardingMap<K, V>
/* 2694:     */     implements NavigableMap<K, V>
/* 2695:     */   {
/* 2696:     */     private transient Comparator<? super K> comparator;
/* 2697:     */     private transient Set<Map.Entry<K, V>> entrySet;
/* 2698:     */     private transient NavigableSet<K> navigableKeySet;
/* 2699:     */     
/* 2700:     */     abstract NavigableMap<K, V> forward();
/* 2701:     */     
/* 2702:     */     protected final Map<K, V> delegate()
/* 2703:     */     {
/* 2704:3949 */       return forward();
/* 2705:     */     }
/* 2706:     */     
/* 2707:     */     public Comparator<? super K> comparator()
/* 2708:     */     {
/* 2709:3957 */       Comparator<? super K> result = this.comparator;
/* 2710:3958 */       if (result == null)
/* 2711:     */       {
/* 2712:3959 */         Comparator<? super K> forwardCmp = forward().comparator();
/* 2713:3960 */         if (forwardCmp == null) {
/* 2714:3961 */           forwardCmp = Ordering.natural();
/* 2715:     */         }
/* 2716:3963 */         result = this.comparator = reverse(forwardCmp);
/* 2717:     */       }
/* 2718:3965 */       return result;
/* 2719:     */     }
/* 2720:     */     
/* 2721:     */     private static <T> Ordering<T> reverse(Comparator<T> forward)
/* 2722:     */     {
/* 2723:3970 */       return Ordering.from(forward).reverse();
/* 2724:     */     }
/* 2725:     */     
/* 2726:     */     public K firstKey()
/* 2727:     */     {
/* 2728:3975 */       return forward().lastKey();
/* 2729:     */     }
/* 2730:     */     
/* 2731:     */     public K lastKey()
/* 2732:     */     {
/* 2733:3980 */       return forward().firstKey();
/* 2734:     */     }
/* 2735:     */     
/* 2736:     */     public Map.Entry<K, V> lowerEntry(K key)
/* 2737:     */     {
/* 2738:3985 */       return forward().higherEntry(key);
/* 2739:     */     }
/* 2740:     */     
/* 2741:     */     public K lowerKey(K key)
/* 2742:     */     {
/* 2743:3990 */       return forward().higherKey(key);
/* 2744:     */     }
/* 2745:     */     
/* 2746:     */     public Map.Entry<K, V> floorEntry(K key)
/* 2747:     */     {
/* 2748:3995 */       return forward().ceilingEntry(key);
/* 2749:     */     }
/* 2750:     */     
/* 2751:     */     public K floorKey(K key)
/* 2752:     */     {
/* 2753:4000 */       return forward().ceilingKey(key);
/* 2754:     */     }
/* 2755:     */     
/* 2756:     */     public Map.Entry<K, V> ceilingEntry(K key)
/* 2757:     */     {
/* 2758:4005 */       return forward().floorEntry(key);
/* 2759:     */     }
/* 2760:     */     
/* 2761:     */     public K ceilingKey(K key)
/* 2762:     */     {
/* 2763:4010 */       return forward().floorKey(key);
/* 2764:     */     }
/* 2765:     */     
/* 2766:     */     public Map.Entry<K, V> higherEntry(K key)
/* 2767:     */     {
/* 2768:4015 */       return forward().lowerEntry(key);
/* 2769:     */     }
/* 2770:     */     
/* 2771:     */     public K higherKey(K key)
/* 2772:     */     {
/* 2773:4020 */       return forward().lowerKey(key);
/* 2774:     */     }
/* 2775:     */     
/* 2776:     */     public Map.Entry<K, V> firstEntry()
/* 2777:     */     {
/* 2778:4025 */       return forward().lastEntry();
/* 2779:     */     }
/* 2780:     */     
/* 2781:     */     public Map.Entry<K, V> lastEntry()
/* 2782:     */     {
/* 2783:4030 */       return forward().firstEntry();
/* 2784:     */     }
/* 2785:     */     
/* 2786:     */     public Map.Entry<K, V> pollFirstEntry()
/* 2787:     */     {
/* 2788:4035 */       return forward().pollLastEntry();
/* 2789:     */     }
/* 2790:     */     
/* 2791:     */     public Map.Entry<K, V> pollLastEntry()
/* 2792:     */     {
/* 2793:4040 */       return forward().pollFirstEntry();
/* 2794:     */     }
/* 2795:     */     
/* 2796:     */     public NavigableMap<K, V> descendingMap()
/* 2797:     */     {
/* 2798:4045 */       return forward();
/* 2799:     */     }
/* 2800:     */     
/* 2801:     */     public Set<Map.Entry<K, V>> entrySet()
/* 2802:     */     {
/* 2803:4052 */       Set<Map.Entry<K, V>> result = this.entrySet;
/* 2804:4053 */       return result == null ? (this.entrySet = createEntrySet()) : result;
/* 2805:     */     }
/* 2806:     */     
/* 2807:     */     abstract Iterator<Map.Entry<K, V>> entryIterator();
/* 2808:     */     
/* 2809:     */     Set<Map.Entry<K, V>> createEntrySet()
/* 2810:     */     {
/* 2811:4071 */       new Maps.EntrySet()
/* 2812:     */       {
/* 2813:     */         Map<K, V> map()
/* 2814:     */         {
/* 2815:4063 */           return Maps.DescendingMap.this;
/* 2816:     */         }
/* 2817:     */         
/* 2818:     */         public Iterator<Map.Entry<K, V>> iterator()
/* 2819:     */         {
/* 2820:4068 */           return Maps.DescendingMap.this.entryIterator();
/* 2821:     */         }
/* 2822:     */       };
/* 2823:     */     }
/* 2824:     */     
/* 2825:     */     public Set<K> keySet()
/* 2826:     */     {
/* 2827:4076 */       return navigableKeySet();
/* 2828:     */     }
/* 2829:     */     
/* 2830:     */     public NavigableSet<K> navigableKeySet()
/* 2831:     */     {
/* 2832:4083 */       NavigableSet<K> result = this.navigableKeySet;
/* 2833:4084 */       return result == null ? (this.navigableKeySet = new Maps.NavigableKeySet(this)) : result;
/* 2834:     */     }
/* 2835:     */     
/* 2836:     */     public NavigableSet<K> descendingKeySet()
/* 2837:     */     {
/* 2838:4089 */       return forward().navigableKeySet();
/* 2839:     */     }
/* 2840:     */     
/* 2841:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 2842:     */     {
/* 2843:4095 */       return forward().subMap(toKey, toInclusive, fromKey, fromInclusive).descendingMap();
/* 2844:     */     }
/* 2845:     */     
/* 2846:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 2847:     */     {
/* 2848:4100 */       return forward().tailMap(toKey, inclusive).descendingMap();
/* 2849:     */     }
/* 2850:     */     
/* 2851:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 2852:     */     {
/* 2853:4105 */       return forward().headMap(fromKey, inclusive).descendingMap();
/* 2854:     */     }
/* 2855:     */     
/* 2856:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 2857:     */     {
/* 2858:4110 */       return subMap(fromKey, true, toKey, false);
/* 2859:     */     }
/* 2860:     */     
/* 2861:     */     public SortedMap<K, V> headMap(K toKey)
/* 2862:     */     {
/* 2863:4115 */       return headMap(toKey, false);
/* 2864:     */     }
/* 2865:     */     
/* 2866:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 2867:     */     {
/* 2868:4120 */       return tailMap(fromKey, true);
/* 2869:     */     }
/* 2870:     */     
/* 2871:     */     public Collection<V> values()
/* 2872:     */     {
/* 2873:4125 */       return new Maps.Values(this);
/* 2874:     */     }
/* 2875:     */     
/* 2876:     */     public String toString()
/* 2877:     */     {
/* 2878:4130 */       return standardToString();
/* 2879:     */     }
/* 2880:     */   }
/* 2881:     */   
/* 2882:     */   static <E> ImmutableMap<E, Integer> indexMap(Collection<E> list)
/* 2883:     */   {
/* 2884:4138 */     ImmutableMap.Builder<E, Integer> builder = new ImmutableMap.Builder(list.size());
/* 2885:4139 */     int i = 0;
/* 2886:4140 */     for (E e : list) {
/* 2887:4141 */       builder.put(e, Integer.valueOf(i++));
/* 2888:     */     }
/* 2889:4143 */     return builder.build();
/* 2890:     */   }
/* 2891:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Maps
 * JD-Core Version:    0.7.0.1
 */