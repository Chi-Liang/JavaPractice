/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.ArrayDeque;
/*   7:    */ import java.util.Deque;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.Queue;
/*  10:    */ 
/*  11:    */ @Beta
/*  12:    */ @GwtCompatible(emulated=true)
/*  13:    */ public abstract class TreeTraverser<T>
/*  14:    */ {
/*  15:    */   public abstract Iterable<T> children(T paramT);
/*  16:    */   
/*  17:    */   public final FluentIterable<T> preOrderTraversal(final T root)
/*  18:    */   {
/*  19: 70 */     Preconditions.checkNotNull(root);
/*  20: 71 */     new FluentIterable()
/*  21:    */     {
/*  22:    */       public UnmodifiableIterator<T> iterator()
/*  23:    */       {
/*  24: 74 */         return TreeTraverser.this.preOrderIterator(root);
/*  25:    */       }
/*  26:    */     };
/*  27:    */   }
/*  28:    */   
/*  29:    */   UnmodifiableIterator<T> preOrderIterator(T root)
/*  30:    */   {
/*  31: 81 */     return new PreOrderIterator(root);
/*  32:    */   }
/*  33:    */   
/*  34:    */   private final class PreOrderIterator
/*  35:    */     extends UnmodifiableIterator<T>
/*  36:    */   {
/*  37:    */     private final Deque<Iterator<T>> stack;
/*  38:    */     
/*  39:    */     PreOrderIterator()
/*  40:    */     {
/*  41: 88 */       this.stack = new ArrayDeque();
/*  42: 89 */       this.stack.addLast(Iterators.singletonIterator(Preconditions.checkNotNull(root)));
/*  43:    */     }
/*  44:    */     
/*  45:    */     public boolean hasNext()
/*  46:    */     {
/*  47: 94 */       return !this.stack.isEmpty();
/*  48:    */     }
/*  49:    */     
/*  50:    */     public T next()
/*  51:    */     {
/*  52: 99 */       Iterator<T> itr = (Iterator)this.stack.getLast();
/*  53:100 */       T result = Preconditions.checkNotNull(itr.next());
/*  54:101 */       if (!itr.hasNext()) {
/*  55:102 */         this.stack.removeLast();
/*  56:    */       }
/*  57:104 */       Iterator<T> childItr = TreeTraverser.this.children(result).iterator();
/*  58:105 */       if (childItr.hasNext()) {
/*  59:106 */         this.stack.addLast(childItr);
/*  60:    */       }
/*  61:108 */       return result;
/*  62:    */     }
/*  63:    */   }
/*  64:    */   
/*  65:    */   public final FluentIterable<T> postOrderTraversal(final T root)
/*  66:    */   {
/*  67:120 */     Preconditions.checkNotNull(root);
/*  68:121 */     new FluentIterable()
/*  69:    */     {
/*  70:    */       public UnmodifiableIterator<T> iterator()
/*  71:    */       {
/*  72:124 */         return TreeTraverser.this.postOrderIterator(root);
/*  73:    */       }
/*  74:    */     };
/*  75:    */   }
/*  76:    */   
/*  77:    */   UnmodifiableIterator<T> postOrderIterator(T root)
/*  78:    */   {
/*  79:131 */     return new PostOrderIterator(root);
/*  80:    */   }
/*  81:    */   
/*  82:    */   private static final class PostOrderNode<T>
/*  83:    */   {
/*  84:    */     final T root;
/*  85:    */     final Iterator<T> childIterator;
/*  86:    */     
/*  87:    */     PostOrderNode(T root, Iterator<T> childIterator)
/*  88:    */     {
/*  89:139 */       this.root = Preconditions.checkNotNull(root);
/*  90:140 */       this.childIterator = ((Iterator)Preconditions.checkNotNull(childIterator));
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   private final class PostOrderIterator
/*  95:    */     extends AbstractIterator<T>
/*  96:    */   {
/*  97:    */     private final ArrayDeque<TreeTraverser.PostOrderNode<T>> stack;
/*  98:    */     
/*  99:    */     PostOrderIterator()
/* 100:    */     {
/* 101:148 */       this.stack = new ArrayDeque();
/* 102:149 */       this.stack.addLast(expand(root));
/* 103:    */     }
/* 104:    */     
/* 105:    */     protected T computeNext()
/* 106:    */     {
/* 107:154 */       while (!this.stack.isEmpty())
/* 108:    */       {
/* 109:155 */         TreeTraverser.PostOrderNode<T> top = (TreeTraverser.PostOrderNode)this.stack.getLast();
/* 110:156 */         if (top.childIterator.hasNext())
/* 111:    */         {
/* 112:157 */           T child = top.childIterator.next();
/* 113:158 */           this.stack.addLast(expand(child));
/* 114:    */         }
/* 115:    */         else
/* 116:    */         {
/* 117:160 */           this.stack.removeLast();
/* 118:161 */           return top.root;
/* 119:    */         }
/* 120:    */       }
/* 121:164 */       return endOfData();
/* 122:    */     }
/* 123:    */     
/* 124:    */     private TreeTraverser.PostOrderNode<T> expand(T t)
/* 125:    */     {
/* 126:168 */       return new TreeTraverser.PostOrderNode(t, TreeTraverser.this.children(t).iterator());
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   public final FluentIterable<T> breadthFirstTraversal(final T root)
/* 131:    */   {
/* 132:180 */     Preconditions.checkNotNull(root);
/* 133:181 */     new FluentIterable()
/* 134:    */     {
/* 135:    */       public UnmodifiableIterator<T> iterator()
/* 136:    */       {
/* 137:184 */         return new TreeTraverser.BreadthFirstIterator(TreeTraverser.this, root);
/* 138:    */       }
/* 139:    */     };
/* 140:    */   }
/* 141:    */   
/* 142:    */   private final class BreadthFirstIterator
/* 143:    */     extends UnmodifiableIterator<T>
/* 144:    */     implements PeekingIterator<T>
/* 145:    */   {
/* 146:    */     private final Queue<T> queue;
/* 147:    */     
/* 148:    */     BreadthFirstIterator()
/* 149:    */     {
/* 150:194 */       this.queue = new ArrayDeque();
/* 151:195 */       this.queue.add(root);
/* 152:    */     }
/* 153:    */     
/* 154:    */     public boolean hasNext()
/* 155:    */     {
/* 156:200 */       return !this.queue.isEmpty();
/* 157:    */     }
/* 158:    */     
/* 159:    */     public T peek()
/* 160:    */     {
/* 161:205 */       return this.queue.element();
/* 162:    */     }
/* 163:    */     
/* 164:    */     public T next()
/* 165:    */     {
/* 166:210 */       T result = this.queue.remove();
/* 167:211 */       Iterables.addAll(this.queue, TreeTraverser.this.children(result));
/* 168:212 */       return result;
/* 169:    */     }
/* 170:    */   }
/* 171:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.TreeTraverser
 * JD-Core Version:    0.7.0.1
 */