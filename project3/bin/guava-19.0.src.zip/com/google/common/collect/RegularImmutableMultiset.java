/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.primitives.Ints;
/*   7:    */ import java.util.Collection;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true)
/*  11:    */ class RegularImmutableMultiset<E>
/*  12:    */   extends ImmutableMultiset<E>
/*  13:    */ {
/*  14: 38 */   static final RegularImmutableMultiset<Object> EMPTY = new RegularImmutableMultiset(ImmutableList.of());
/*  15:    */   private final transient Multisets.ImmutableEntry<E>[] entries;
/*  16:    */   private final transient Multisets.ImmutableEntry<E>[] hashTable;
/*  17:    */   private final transient int size;
/*  18:    */   private final transient int hashCode;
/*  19:    */   private transient ImmutableSet<E> elementSet;
/*  20:    */   
/*  21:    */   RegularImmutableMultiset(Collection<? extends Multiset.Entry<? extends E>> entries)
/*  22:    */   {
/*  23: 49 */     int distinct = entries.size();
/*  24:    */     
/*  25: 51 */     Multisets.ImmutableEntry<E>[] entryArray = new Multisets.ImmutableEntry[distinct];
/*  26: 52 */     if (distinct == 0)
/*  27:    */     {
/*  28: 53 */       this.entries = entryArray;
/*  29: 54 */       this.hashTable = null;
/*  30: 55 */       this.size = 0;
/*  31: 56 */       this.hashCode = 0;
/*  32: 57 */       this.elementSet = ImmutableSet.of();
/*  33:    */     }
/*  34:    */     else
/*  35:    */     {
/*  36: 59 */       int tableSize = Hashing.closedTableSize(distinct, 1.0D);
/*  37: 60 */       int mask = tableSize - 1;
/*  38:    */       
/*  39: 62 */       Multisets.ImmutableEntry<E>[] hashTable = new Multisets.ImmutableEntry[tableSize];
/*  40:    */       
/*  41: 64 */       int index = 0;
/*  42: 65 */       int hashCode = 0;
/*  43: 66 */       long size = 0L;
/*  44: 67 */       for (Multiset.Entry<? extends E> entry : entries)
/*  45:    */       {
/*  46: 68 */         E element = Preconditions.checkNotNull(entry.getElement());
/*  47: 69 */         int count = entry.getCount();
/*  48: 70 */         int hash = element.hashCode();
/*  49: 71 */         int bucket = Hashing.smear(hash) & mask;
/*  50: 72 */         Multisets.ImmutableEntry<E> bucketHead = hashTable[bucket];
/*  51:    */         Multisets.ImmutableEntry<E> newEntry;
/*  52:    */         Multisets.ImmutableEntry<E> newEntry;
/*  53: 74 */         if (bucketHead == null)
/*  54:    */         {
/*  55: 75 */           boolean canReuseEntry = ((entry instanceof Multisets.ImmutableEntry)) && (!(entry instanceof NonTerminalEntry));
/*  56:    */           
/*  57: 77 */           newEntry = canReuseEntry ? (Multisets.ImmutableEntry)entry : new Multisets.ImmutableEntry(element, count);
/*  58:    */         }
/*  59:    */         else
/*  60:    */         {
/*  61: 82 */           newEntry = new NonTerminalEntry(element, count, bucketHead);
/*  62:    */         }
/*  63: 84 */         hashCode += (hash ^ count);
/*  64: 85 */         entryArray[(index++)] = newEntry;
/*  65: 86 */         hashTable[bucket] = newEntry;
/*  66: 87 */         size += count;
/*  67:    */       }
/*  68: 89 */       this.entries = entryArray;
/*  69: 90 */       this.hashTable = hashTable;
/*  70: 91 */       this.size = Ints.saturatedCast(size);
/*  71: 92 */       this.hashCode = hashCode;
/*  72:    */     }
/*  73:    */   }
/*  74:    */   
/*  75:    */   private static final class NonTerminalEntry<E>
/*  76:    */     extends Multisets.ImmutableEntry<E>
/*  77:    */   {
/*  78:    */     private final Multisets.ImmutableEntry<E> nextInBucket;
/*  79:    */     
/*  80:    */     NonTerminalEntry(E element, int count, Multisets.ImmutableEntry<E> nextInBucket)
/*  81:    */     {
/*  82:100 */       super(count);
/*  83:101 */       this.nextInBucket = nextInBucket;
/*  84:    */     }
/*  85:    */     
/*  86:    */     public Multisets.ImmutableEntry<E> nextInBucket()
/*  87:    */     {
/*  88:106 */       return this.nextInBucket;
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   boolean isPartialView()
/*  93:    */   {
/*  94:112 */     return false;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public int count(@Nullable Object element)
/*  98:    */   {
/*  99:117 */     Multisets.ImmutableEntry<E>[] hashTable = this.hashTable;
/* 100:118 */     if ((element == null) || (hashTable == null)) {
/* 101:119 */       return 0;
/* 102:    */     }
/* 103:121 */     int hash = Hashing.smearedHash(element);
/* 104:122 */     int mask = hashTable.length - 1;
/* 105:123 */     for (Multisets.ImmutableEntry<E> entry = hashTable[(hash & mask)]; entry != null; entry = entry.nextInBucket()) {
/* 106:126 */       if (Objects.equal(element, entry.getElement())) {
/* 107:127 */         return entry.getCount();
/* 108:    */       }
/* 109:    */     }
/* 110:130 */     return 0;
/* 111:    */   }
/* 112:    */   
/* 113:    */   public int size()
/* 114:    */   {
/* 115:135 */     return this.size;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public ImmutableSet<E> elementSet()
/* 119:    */   {
/* 120:140 */     ImmutableSet<E> result = this.elementSet;
/* 121:141 */     return result == null ? (this.elementSet = new ElementSet(null)) : result;
/* 122:    */   }
/* 123:    */   
/* 124:    */   private final class ElementSet
/* 125:    */     extends ImmutableSet.Indexed<E>
/* 126:    */   {
/* 127:    */     private ElementSet() {}
/* 128:    */     
/* 129:    */     E get(int index)
/* 130:    */     {
/* 131:149 */       return RegularImmutableMultiset.this.entries[index].getElement();
/* 132:    */     }
/* 133:    */     
/* 134:    */     public boolean contains(@Nullable Object object)
/* 135:    */     {
/* 136:154 */       return RegularImmutableMultiset.this.contains(object);
/* 137:    */     }
/* 138:    */     
/* 139:    */     boolean isPartialView()
/* 140:    */     {
/* 141:159 */       return true;
/* 142:    */     }
/* 143:    */     
/* 144:    */     public int size()
/* 145:    */     {
/* 146:164 */       return RegularImmutableMultiset.this.entries.length;
/* 147:    */     }
/* 148:    */   }
/* 149:    */   
/* 150:    */   Multiset.Entry<E> getEntry(int index)
/* 151:    */   {
/* 152:170 */     return this.entries[index];
/* 153:    */   }
/* 154:    */   
/* 155:    */   public int hashCode()
/* 156:    */   {
/* 157:175 */     return this.hashCode;
/* 158:    */   }
/* 159:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableMultiset
 * JD-Core Version:    0.7.0.1
 */