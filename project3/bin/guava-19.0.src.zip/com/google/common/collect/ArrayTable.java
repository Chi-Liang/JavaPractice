/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.lang.reflect.Array;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Map.Entry;
/*  15:    */ import java.util.Set;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @Beta
/*  19:    */ @GwtCompatible(emulated=true)
/*  20:    */ public final class ArrayTable<R, C, V>
/*  21:    */   extends AbstractTable<R, C, V>
/*  22:    */   implements Serializable
/*  23:    */ {
/*  24:    */   private final ImmutableList<R> rowList;
/*  25:    */   private final ImmutableList<C> columnList;
/*  26:    */   private final ImmutableMap<R, Integer> rowKeyToIndex;
/*  27:    */   private final ImmutableMap<C, Integer> columnKeyToIndex;
/*  28:    */   private final V[][] array;
/*  29:    */   private transient ArrayTable<R, C, V>.ColumnMap columnMap;
/*  30:    */   private transient ArrayTable<R, C, V>.RowMap rowMap;
/*  31:    */   private static final long serialVersionUID = 0L;
/*  32:    */   
/*  33:    */   public static <R, C, V> ArrayTable<R, C, V> create(Iterable<? extends R> rowKeys, Iterable<? extends C> columnKeys)
/*  34:    */   {
/*  35:101 */     return new ArrayTable(rowKeys, columnKeys);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <R, C, V> ArrayTable<R, C, V> create(Table<R, C, V> table)
/*  39:    */   {
/*  40:133 */     return (table instanceof ArrayTable) ? new ArrayTable((ArrayTable)table) : new ArrayTable(table);
/*  41:    */   }
/*  42:    */   
/*  43:    */   private ArrayTable(Iterable<? extends R> rowKeys, Iterable<? extends C> columnKeys)
/*  44:    */   {
/*  45:147 */     this.rowList = ImmutableList.copyOf(rowKeys);
/*  46:148 */     this.columnList = ImmutableList.copyOf(columnKeys);
/*  47:149 */     Preconditions.checkArgument(!this.rowList.isEmpty());
/*  48:150 */     Preconditions.checkArgument(!this.columnList.isEmpty());
/*  49:    */     
/*  50:    */ 
/*  51:    */ 
/*  52:    */ 
/*  53:    */ 
/*  54:    */ 
/*  55:157 */     this.rowKeyToIndex = Maps.indexMap(this.rowList);
/*  56:158 */     this.columnKeyToIndex = Maps.indexMap(this.columnList);
/*  57:    */     
/*  58:    */ 
/*  59:161 */     V[][] tmpArray = (Object[][])new Object[this.rowList.size()][this.columnList.size()];
/*  60:162 */     this.array = tmpArray;
/*  61:    */     
/*  62:164 */     eraseAll();
/*  63:    */   }
/*  64:    */   
/*  65:    */   private ArrayTable(Table<R, C, V> table)
/*  66:    */   {
/*  67:168 */     this(table.rowKeySet(), table.columnKeySet());
/*  68:169 */     putAll(table);
/*  69:    */   }
/*  70:    */   
/*  71:    */   private ArrayTable(ArrayTable<R, C, V> table)
/*  72:    */   {
/*  73:173 */     this.rowList = table.rowList;
/*  74:174 */     this.columnList = table.columnList;
/*  75:175 */     this.rowKeyToIndex = table.rowKeyToIndex;
/*  76:176 */     this.columnKeyToIndex = table.columnKeyToIndex;
/*  77:    */     
/*  78:178 */     V[][] copy = (Object[][])new Object[this.rowList.size()][this.columnList.size()];
/*  79:179 */     this.array = copy;
/*  80:    */     
/*  81:181 */     eraseAll();
/*  82:182 */     for (int i = 0; i < this.rowList.size(); i++) {
/*  83:183 */       System.arraycopy(table.array[i], 0, copy[i], 0, table.array[i].length);
/*  84:    */     }
/*  85:    */   }
/*  86:    */   
/*  87:    */   private static abstract class ArrayMap<K, V>
/*  88:    */     extends Maps.IteratorBasedAbstractMap<K, V>
/*  89:    */   {
/*  90:    */     private final ImmutableMap<K, Integer> keyIndex;
/*  91:    */     
/*  92:    */     private ArrayMap(ImmutableMap<K, Integer> keyIndex)
/*  93:    */     {
/*  94:191 */       this.keyIndex = keyIndex;
/*  95:    */     }
/*  96:    */     
/*  97:    */     public Set<K> keySet()
/*  98:    */     {
/*  99:196 */       return this.keyIndex.keySet();
/* 100:    */     }
/* 101:    */     
/* 102:    */     K getKey(int index)
/* 103:    */     {
/* 104:200 */       return this.keyIndex.keySet().asList().get(index);
/* 105:    */     }
/* 106:    */     
/* 107:    */     abstract String getKeyRole();
/* 108:    */     
/* 109:    */     @Nullable
/* 110:    */     abstract V getValue(int paramInt);
/* 111:    */     
/* 112:    */     @Nullable
/* 113:    */     abstract V setValue(int paramInt, V paramV);
/* 114:    */     
/* 115:    */     public int size()
/* 116:    */     {
/* 117:213 */       return this.keyIndex.size();
/* 118:    */     }
/* 119:    */     
/* 120:    */     public boolean isEmpty()
/* 121:    */     {
/* 122:218 */       return this.keyIndex.isEmpty();
/* 123:    */     }
/* 124:    */     
/* 125:    */     Iterator<Map.Entry<K, V>> entryIterator()
/* 126:    */     {
/* 127:223 */       new AbstractIndexedListIterator(size())
/* 128:    */       {
/* 129:    */         protected Map.Entry<K, V> get(final int index)
/* 130:    */         {
/* 131:226 */           new AbstractMapEntry()
/* 132:    */           {
/* 133:    */             public K getKey()
/* 134:    */             {
/* 135:229 */               return ArrayTable.ArrayMap.this.getKey(index);
/* 136:    */             }
/* 137:    */             
/* 138:    */             public V getValue()
/* 139:    */             {
/* 140:234 */               return ArrayTable.ArrayMap.this.getValue(index);
/* 141:    */             }
/* 142:    */             
/* 143:    */             public V setValue(V value)
/* 144:    */             {
/* 145:239 */               return ArrayTable.ArrayMap.this.setValue(index, value);
/* 146:    */             }
/* 147:    */           };
/* 148:    */         }
/* 149:    */       };
/* 150:    */     }
/* 151:    */     
/* 152:    */     public boolean containsKey(@Nullable Object key)
/* 153:    */     {
/* 154:250 */       return this.keyIndex.containsKey(key);
/* 155:    */     }
/* 156:    */     
/* 157:    */     public V get(@Nullable Object key)
/* 158:    */     {
/* 159:255 */       Integer index = (Integer)this.keyIndex.get(key);
/* 160:256 */       if (index == null) {
/* 161:257 */         return null;
/* 162:    */       }
/* 163:259 */       return getValue(index.intValue());
/* 164:    */     }
/* 165:    */     
/* 166:    */     public V put(K key, V value)
/* 167:    */     {
/* 168:265 */       Integer index = (Integer)this.keyIndex.get(key);
/* 169:266 */       if (index == null) {
/* 170:267 */         throw new IllegalArgumentException(getKeyRole() + " " + key + " not in " + this.keyIndex.keySet());
/* 171:    */       }
/* 172:270 */       return setValue(index.intValue(), value);
/* 173:    */     }
/* 174:    */     
/* 175:    */     public V remove(Object key)
/* 176:    */     {
/* 177:275 */       throw new UnsupportedOperationException();
/* 178:    */     }
/* 179:    */     
/* 180:    */     public void clear()
/* 181:    */     {
/* 182:280 */       throw new UnsupportedOperationException();
/* 183:    */     }
/* 184:    */   }
/* 185:    */   
/* 186:    */   public ImmutableList<R> rowKeyList()
/* 187:    */   {
/* 188:289 */     return this.rowList;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public ImmutableList<C> columnKeyList()
/* 192:    */   {
/* 193:297 */     return this.columnList;
/* 194:    */   }
/* 195:    */   
/* 196:    */   public V at(int rowIndex, int columnIndex)
/* 197:    */   {
/* 198:316 */     Preconditions.checkElementIndex(rowIndex, this.rowList.size());
/* 199:317 */     Preconditions.checkElementIndex(columnIndex, this.columnList.size());
/* 200:318 */     return this.array[rowIndex][columnIndex];
/* 201:    */   }
/* 202:    */   
/* 203:    */   public V set(int rowIndex, int columnIndex, @Nullable V value)
/* 204:    */   {
/* 205:338 */     Preconditions.checkElementIndex(rowIndex, this.rowList.size());
/* 206:339 */     Preconditions.checkElementIndex(columnIndex, this.columnList.size());
/* 207:340 */     V oldValue = this.array[rowIndex][columnIndex];
/* 208:341 */     this.array[rowIndex][columnIndex] = value;
/* 209:342 */     return oldValue;
/* 210:    */   }
/* 211:    */   
/* 212:    */   @GwtIncompatible("reflection")
/* 213:    */   public V[][] toArray(Class<V> valueClass)
/* 214:    */   {
/* 215:359 */     V[][] copy = (Object[][])Array.newInstance(valueClass, new int[] { this.rowList.size(), this.columnList.size() });
/* 216:361 */     for (int i = 0; i < this.rowList.size(); i++) {
/* 217:362 */       System.arraycopy(this.array[i], 0, copy[i], 0, this.array[i].length);
/* 218:    */     }
/* 219:364 */     return copy;
/* 220:    */   }
/* 221:    */   
/* 222:    */   @Deprecated
/* 223:    */   public void clear()
/* 224:    */   {
/* 225:376 */     throw new UnsupportedOperationException();
/* 226:    */   }
/* 227:    */   
/* 228:    */   public void eraseAll()
/* 229:    */   {
/* 230:384 */     for (V[] row : this.array) {
/* 231:385 */       Arrays.fill(row, null);
/* 232:    */     }
/* 233:    */   }
/* 234:    */   
/* 235:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/* 236:    */   {
/* 237:395 */     return (containsRow(rowKey)) && (containsColumn(columnKey));
/* 238:    */   }
/* 239:    */   
/* 240:    */   public boolean containsColumn(@Nullable Object columnKey)
/* 241:    */   {
/* 242:404 */     return this.columnKeyToIndex.containsKey(columnKey);
/* 243:    */   }
/* 244:    */   
/* 245:    */   public boolean containsRow(@Nullable Object rowKey)
/* 246:    */   {
/* 247:413 */     return this.rowKeyToIndex.containsKey(rowKey);
/* 248:    */   }
/* 249:    */   
/* 250:    */   public boolean containsValue(@Nullable Object value)
/* 251:    */   {
/* 252:418 */     for (V[] row : this.array) {
/* 253:419 */       for (V element : row) {
/* 254:420 */         if (Objects.equal(value, element)) {
/* 255:421 */           return true;
/* 256:    */         }
/* 257:    */       }
/* 258:    */     }
/* 259:425 */     return false;
/* 260:    */   }
/* 261:    */   
/* 262:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/* 263:    */   {
/* 264:430 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 265:431 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 266:432 */     return (rowIndex == null) || (columnIndex == null) ? null : at(rowIndex.intValue(), columnIndex.intValue());
/* 267:    */   }
/* 268:    */   
/* 269:    */   public boolean isEmpty()
/* 270:    */   {
/* 271:440 */     return false;
/* 272:    */   }
/* 273:    */   
/* 274:    */   public V put(R rowKey, C columnKey, @Nullable V value)
/* 275:    */   {
/* 276:451 */     Preconditions.checkNotNull(rowKey);
/* 277:452 */     Preconditions.checkNotNull(columnKey);
/* 278:453 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 279:454 */     Preconditions.checkArgument(rowIndex != null, "Row %s not in %s", new Object[] { rowKey, this.rowList });
/* 280:455 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 281:456 */     Preconditions.checkArgument(columnIndex != null, "Column %s not in %s", new Object[] { columnKey, this.columnList });
/* 282:457 */     return set(rowIndex.intValue(), columnIndex.intValue(), value);
/* 283:    */   }
/* 284:    */   
/* 285:    */   public void putAll(Table<? extends R, ? extends C, ? extends V> table)
/* 286:    */   {
/* 287:478 */     super.putAll(table);
/* 288:    */   }
/* 289:    */   
/* 290:    */   @Deprecated
/* 291:    */   public V remove(Object rowKey, Object columnKey)
/* 292:    */   {
/* 293:490 */     throw new UnsupportedOperationException();
/* 294:    */   }
/* 295:    */   
/* 296:    */   public V erase(@Nullable Object rowKey, @Nullable Object columnKey)
/* 297:    */   {
/* 298:507 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 299:508 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 300:509 */     if ((rowIndex == null) || (columnIndex == null)) {
/* 301:510 */       return null;
/* 302:    */     }
/* 303:512 */     return set(rowIndex.intValue(), columnIndex.intValue(), null);
/* 304:    */   }
/* 305:    */   
/* 306:    */   public int size()
/* 307:    */   {
/* 308:519 */     return this.rowList.size() * this.columnList.size();
/* 309:    */   }
/* 310:    */   
/* 311:    */   public Set<Table.Cell<R, C, V>> cellSet()
/* 312:    */   {
/* 313:537 */     return super.cellSet();
/* 314:    */   }
/* 315:    */   
/* 316:    */   Iterator<Table.Cell<R, C, V>> cellIterator()
/* 317:    */   {
/* 318:542 */     new AbstractIndexedListIterator(size())
/* 319:    */     {
/* 320:    */       protected Table.Cell<R, C, V> get(final int index)
/* 321:    */       {
/* 322:545 */         new Tables.AbstractCell()
/* 323:    */         {
/* 324:546 */           final int rowIndex = index / ArrayTable.this.columnList.size();
/* 325:547 */           final int columnIndex = index % ArrayTable.this.columnList.size();
/* 326:    */           
/* 327:    */           public R getRowKey()
/* 328:    */           {
/* 329:551 */             return ArrayTable.this.rowList.get(this.rowIndex);
/* 330:    */           }
/* 331:    */           
/* 332:    */           public C getColumnKey()
/* 333:    */           {
/* 334:556 */             return ArrayTable.this.columnList.get(this.columnIndex);
/* 335:    */           }
/* 336:    */           
/* 337:    */           public V getValue()
/* 338:    */           {
/* 339:561 */             return ArrayTable.this.at(this.rowIndex, this.columnIndex);
/* 340:    */           }
/* 341:    */         };
/* 342:    */       }
/* 343:    */     };
/* 344:    */   }
/* 345:    */   
/* 346:    */   public Map<R, V> column(C columnKey)
/* 347:    */   {
/* 348:582 */     Preconditions.checkNotNull(columnKey);
/* 349:583 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 350:584 */     return columnIndex == null ? ImmutableMap.of() : new Column(columnIndex.intValue());
/* 351:    */   }
/* 352:    */   
/* 353:    */   private class Column
/* 354:    */     extends ArrayTable.ArrayMap<R, V>
/* 355:    */   {
/* 356:    */     final int columnIndex;
/* 357:    */     
/* 358:    */     Column(int columnIndex)
/* 359:    */     {
/* 360:591 */       super(null);
/* 361:592 */       this.columnIndex = columnIndex;
/* 362:    */     }
/* 363:    */     
/* 364:    */     String getKeyRole()
/* 365:    */     {
/* 366:597 */       return "Row";
/* 367:    */     }
/* 368:    */     
/* 369:    */     V getValue(int index)
/* 370:    */     {
/* 371:602 */       return ArrayTable.this.at(index, this.columnIndex);
/* 372:    */     }
/* 373:    */     
/* 374:    */     V setValue(int index, V newValue)
/* 375:    */     {
/* 376:607 */       return ArrayTable.this.set(index, this.columnIndex, newValue);
/* 377:    */     }
/* 378:    */   }
/* 379:    */   
/* 380:    */   public ImmutableSet<C> columnKeySet()
/* 381:    */   {
/* 382:619 */     return this.columnKeyToIndex.keySet();
/* 383:    */   }
/* 384:    */   
/* 385:    */   public Map<C, Map<R, V>> columnMap()
/* 386:    */   {
/* 387:626 */     ArrayTable<R, C, V>.ColumnMap map = this.columnMap;
/* 388:627 */     return map == null ? (this.columnMap = new ColumnMap(null)) : map;
/* 389:    */   }
/* 390:    */   
/* 391:    */   private class ColumnMap
/* 392:    */     extends ArrayTable.ArrayMap<C, Map<R, V>>
/* 393:    */   {
/* 394:    */     private ColumnMap()
/* 395:    */     {
/* 396:633 */       super(null);
/* 397:    */     }
/* 398:    */     
/* 399:    */     String getKeyRole()
/* 400:    */     {
/* 401:638 */       return "Column";
/* 402:    */     }
/* 403:    */     
/* 404:    */     Map<R, V> getValue(int index)
/* 405:    */     {
/* 406:643 */       return new ArrayTable.Column(ArrayTable.this, index);
/* 407:    */     }
/* 408:    */     
/* 409:    */     Map<R, V> setValue(int index, Map<R, V> newValue)
/* 410:    */     {
/* 411:648 */       throw new UnsupportedOperationException();
/* 412:    */     }
/* 413:    */     
/* 414:    */     public Map<R, V> put(C key, Map<R, V> value)
/* 415:    */     {
/* 416:653 */       throw new UnsupportedOperationException();
/* 417:    */     }
/* 418:    */   }
/* 419:    */   
/* 420:    */   public Map<C, V> row(R rowKey)
/* 421:    */   {
/* 422:672 */     Preconditions.checkNotNull(rowKey);
/* 423:673 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 424:674 */     return rowIndex == null ? ImmutableMap.of() : new Row(rowIndex.intValue());
/* 425:    */   }
/* 426:    */   
/* 427:    */   private class Row
/* 428:    */     extends ArrayTable.ArrayMap<C, V>
/* 429:    */   {
/* 430:    */     final int rowIndex;
/* 431:    */     
/* 432:    */     Row(int rowIndex)
/* 433:    */     {
/* 434:681 */       super(null);
/* 435:682 */       this.rowIndex = rowIndex;
/* 436:    */     }
/* 437:    */     
/* 438:    */     String getKeyRole()
/* 439:    */     {
/* 440:687 */       return "Column";
/* 441:    */     }
/* 442:    */     
/* 443:    */     V getValue(int index)
/* 444:    */     {
/* 445:692 */       return ArrayTable.this.at(this.rowIndex, index);
/* 446:    */     }
/* 447:    */     
/* 448:    */     V setValue(int index, V newValue)
/* 449:    */     {
/* 450:697 */       return ArrayTable.this.set(this.rowIndex, index, newValue);
/* 451:    */     }
/* 452:    */   }
/* 453:    */   
/* 454:    */   public ImmutableSet<R> rowKeySet()
/* 455:    */   {
/* 456:709 */     return this.rowKeyToIndex.keySet();
/* 457:    */   }
/* 458:    */   
/* 459:    */   public Map<R, Map<C, V>> rowMap()
/* 460:    */   {
/* 461:716 */     ArrayTable<R, C, V>.RowMap map = this.rowMap;
/* 462:717 */     return map == null ? (this.rowMap = new RowMap(null)) : map;
/* 463:    */   }
/* 464:    */   
/* 465:    */   private class RowMap
/* 466:    */     extends ArrayTable.ArrayMap<R, Map<C, V>>
/* 467:    */   {
/* 468:    */     private RowMap()
/* 469:    */     {
/* 470:723 */       super(null);
/* 471:    */     }
/* 472:    */     
/* 473:    */     String getKeyRole()
/* 474:    */     {
/* 475:728 */       return "Row";
/* 476:    */     }
/* 477:    */     
/* 478:    */     Map<C, V> getValue(int index)
/* 479:    */     {
/* 480:733 */       return new ArrayTable.Row(ArrayTable.this, index);
/* 481:    */     }
/* 482:    */     
/* 483:    */     Map<C, V> setValue(int index, Map<C, V> newValue)
/* 484:    */     {
/* 485:738 */       throw new UnsupportedOperationException();
/* 486:    */     }
/* 487:    */     
/* 488:    */     public Map<C, V> put(R key, Map<C, V> value)
/* 489:    */     {
/* 490:743 */       throw new UnsupportedOperationException();
/* 491:    */     }
/* 492:    */   }
/* 493:    */   
/* 494:    */   public Collection<V> values()
/* 495:    */   {
/* 496:758 */     return super.values();
/* 497:    */   }
/* 498:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ArrayTable
 * JD-Core Version:    0.7.0.1
 */