/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.io.Serializable;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.EnumSet;
/*   7:    */ 
/*   8:    */ @GwtCompatible(serializable=true, emulated=true)
/*   9:    */ final class ImmutableEnumSet<E extends Enum<E>>
/*  10:    */   extends ImmutableSet<E>
/*  11:    */ {
/*  12:    */   private final transient EnumSet<E> delegate;
/*  13:    */   private transient int hashCode;
/*  14:    */   
/*  15:    */   static ImmutableSet asImmutable(EnumSet set)
/*  16:    */   {
/*  17: 36 */     switch (set.size())
/*  18:    */     {
/*  19:    */     case 0: 
/*  20: 38 */       return ImmutableSet.of();
/*  21:    */     case 1: 
/*  22: 40 */       return ImmutableSet.of(Iterables.getOnlyElement(set));
/*  23:    */     }
/*  24: 42 */     return new ImmutableEnumSet(set);
/*  25:    */   }
/*  26:    */   
/*  27:    */   private ImmutableEnumSet(EnumSet<E> delegate)
/*  28:    */   {
/*  29: 57 */     this.delegate = delegate;
/*  30:    */   }
/*  31:    */   
/*  32:    */   boolean isPartialView()
/*  33:    */   {
/*  34: 62 */     return false;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public UnmodifiableIterator<E> iterator()
/*  38:    */   {
/*  39: 67 */     return Iterators.unmodifiableIterator(this.delegate.iterator());
/*  40:    */   }
/*  41:    */   
/*  42:    */   public int size()
/*  43:    */   {
/*  44: 72 */     return this.delegate.size();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public boolean contains(Object object)
/*  48:    */   {
/*  49: 77 */     return this.delegate.contains(object);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean containsAll(Collection<?> collection)
/*  53:    */   {
/*  54: 82 */     if ((collection instanceof ImmutableEnumSet)) {
/*  55: 83 */       collection = ((ImmutableEnumSet)collection).delegate;
/*  56:    */     }
/*  57: 85 */     return this.delegate.containsAll(collection);
/*  58:    */   }
/*  59:    */   
/*  60:    */   public boolean isEmpty()
/*  61:    */   {
/*  62: 90 */     return this.delegate.isEmpty();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean equals(Object object)
/*  66:    */   {
/*  67: 95 */     if (object == this) {
/*  68: 96 */       return true;
/*  69:    */     }
/*  70: 98 */     if ((object instanceof ImmutableEnumSet)) {
/*  71: 99 */       object = ((ImmutableEnumSet)object).delegate;
/*  72:    */     }
/*  73:101 */     return this.delegate.equals(object);
/*  74:    */   }
/*  75:    */   
/*  76:    */   boolean isHashCodeFast()
/*  77:    */   {
/*  78:106 */     return true;
/*  79:    */   }
/*  80:    */   
/*  81:    */   public int hashCode()
/*  82:    */   {
/*  83:113 */     int result = this.hashCode;
/*  84:114 */     return result == 0 ? (this.hashCode = this.delegate.hashCode()) : result;
/*  85:    */   }
/*  86:    */   
/*  87:    */   public String toString()
/*  88:    */   {
/*  89:119 */     return this.delegate.toString();
/*  90:    */   }
/*  91:    */   
/*  92:    */   Object writeReplace()
/*  93:    */   {
/*  94:125 */     return new EnumSerializedForm(this.delegate);
/*  95:    */   }
/*  96:    */   
/*  97:    */   private static class EnumSerializedForm<E extends Enum<E>>
/*  98:    */     implements Serializable
/*  99:    */   {
/* 100:    */     final EnumSet<E> delegate;
/* 101:    */     private static final long serialVersionUID = 0L;
/* 102:    */     
/* 103:    */     EnumSerializedForm(EnumSet<E> delegate)
/* 104:    */     {
/* 105:135 */       this.delegate = delegate;
/* 106:    */     }
/* 107:    */     
/* 108:    */     Object readResolve()
/* 109:    */     {
/* 110:140 */       return new ImmutableEnumSet(this.delegate.clone(), null);
/* 111:    */     }
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableEnumSet
 * JD-Core Version:    0.7.0.1
 */