/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.annotations.VisibleForTesting;
/*    7:     */ import com.google.common.base.Function;
/*    8:     */ import com.google.common.base.Objects;
/*    9:     */ import com.google.common.base.Preconditions;
/*   10:     */ import com.google.common.math.IntMath;
/*   11:     */ import com.google.common.primitives.Ints;
/*   12:     */ import java.io.Serializable;
/*   13:     */ import java.math.RoundingMode;
/*   14:     */ import java.util.AbstractList;
/*   15:     */ import java.util.AbstractSequentialList;
/*   16:     */ import java.util.ArrayList;
/*   17:     */ import java.util.Arrays;
/*   18:     */ import java.util.Collection;
/*   19:     */ import java.util.Collections;
/*   20:     */ import java.util.Iterator;
/*   21:     */ import java.util.LinkedList;
/*   22:     */ import java.util.List;
/*   23:     */ import java.util.ListIterator;
/*   24:     */ import java.util.NoSuchElementException;
/*   25:     */ import java.util.RandomAccess;
/*   26:     */ import java.util.concurrent.CopyOnWriteArrayList;
/*   27:     */ import javax.annotation.CheckReturnValue;
/*   28:     */ import javax.annotation.Nullable;
/*   29:     */ 
/*   30:     */ @GwtCompatible(emulated=true)
/*   31:     */ public final class Lists
/*   32:     */ {
/*   33:     */   @GwtCompatible(serializable=true)
/*   34:     */   public static <E> ArrayList<E> newArrayList()
/*   35:     */   {
/*   36:  89 */     return new ArrayList();
/*   37:     */   }
/*   38:     */   
/*   39:     */   @GwtCompatible(serializable=true)
/*   40:     */   public static <E> ArrayList<E> newArrayList(E... elements)
/*   41:     */   {
/*   42: 111 */     Preconditions.checkNotNull(elements);
/*   43:     */     
/*   44: 113 */     int capacity = computeArrayListCapacity(elements.length);
/*   45: 114 */     ArrayList<E> list = new ArrayList(capacity);
/*   46: 115 */     Collections.addAll(list, elements);
/*   47: 116 */     return list;
/*   48:     */   }
/*   49:     */   
/*   50:     */   @VisibleForTesting
/*   51:     */   static int computeArrayListCapacity(int arraySize)
/*   52:     */   {
/*   53: 121 */     CollectPreconditions.checkNonnegative(arraySize, "arraySize");
/*   54:     */     
/*   55:     */ 
/*   56: 124 */     return Ints.saturatedCast(5L + arraySize + arraySize / 10);
/*   57:     */   }
/*   58:     */   
/*   59:     */   @GwtCompatible(serializable=true)
/*   60:     */   public static <E> ArrayList<E> newArrayList(Iterable<? extends E> elements)
/*   61:     */   {
/*   62: 144 */     Preconditions.checkNotNull(elements);
/*   63:     */     
/*   64: 146 */     return (elements instanceof Collection) ? new ArrayList(Collections2.cast(elements)) : newArrayList(elements.iterator());
/*   65:     */   }
/*   66:     */   
/*   67:     */   @GwtCompatible(serializable=true)
/*   68:     */   public static <E> ArrayList<E> newArrayList(Iterator<? extends E> elements)
/*   69:     */   {
/*   70: 161 */     ArrayList<E> list = newArrayList();
/*   71: 162 */     Iterators.addAll(list, elements);
/*   72: 163 */     return list;
/*   73:     */   }
/*   74:     */   
/*   75:     */   @GwtCompatible(serializable=true)
/*   76:     */   public static <E> ArrayList<E> newArrayListWithCapacity(int initialArraySize)
/*   77:     */   {
/*   78: 186 */     CollectPreconditions.checkNonnegative(initialArraySize, "initialArraySize");
/*   79: 187 */     return new ArrayList(initialArraySize);
/*   80:     */   }
/*   81:     */   
/*   82:     */   @GwtCompatible(serializable=true)
/*   83:     */   public static <E> ArrayList<E> newArrayListWithExpectedSize(int estimatedSize)
/*   84:     */   {
/*   85: 208 */     return new ArrayList(computeArrayListCapacity(estimatedSize));
/*   86:     */   }
/*   87:     */   
/*   88:     */   @GwtCompatible(serializable=true)
/*   89:     */   public static <E> LinkedList<E> newLinkedList()
/*   90:     */   {
/*   91: 232 */     return new LinkedList();
/*   92:     */   }
/*   93:     */   
/*   94:     */   @GwtCompatible(serializable=true)
/*   95:     */   public static <E> LinkedList<E> newLinkedList(Iterable<? extends E> elements)
/*   96:     */   {
/*   97: 257 */     LinkedList<E> list = newLinkedList();
/*   98: 258 */     Iterables.addAll(list, elements);
/*   99: 259 */     return list;
/*  100:     */   }
/*  101:     */   
/*  102:     */   @GwtIncompatible("CopyOnWriteArrayList")
/*  103:     */   public static <E> CopyOnWriteArrayList<E> newCopyOnWriteArrayList()
/*  104:     */   {
/*  105: 273 */     return new CopyOnWriteArrayList();
/*  106:     */   }
/*  107:     */   
/*  108:     */   @GwtIncompatible("CopyOnWriteArrayList")
/*  109:     */   public static <E> CopyOnWriteArrayList<E> newCopyOnWriteArrayList(Iterable<? extends E> elements)
/*  110:     */   {
/*  111: 288 */     Collection<? extends E> elementsCollection = (elements instanceof Collection) ? Collections2.cast(elements) : newArrayList(elements);
/*  112:     */     
/*  113:     */ 
/*  114:     */ 
/*  115: 292 */     return new CopyOnWriteArrayList(elementsCollection);
/*  116:     */   }
/*  117:     */   
/*  118:     */   public static <E> List<E> asList(@Nullable E first, E[] rest)
/*  119:     */   {
/*  120: 312 */     return new OnePlusArrayList(first, rest);
/*  121:     */   }
/*  122:     */   
/*  123:     */   private static class OnePlusArrayList<E>
/*  124:     */     extends AbstractList<E>
/*  125:     */     implements Serializable, RandomAccess
/*  126:     */   {
/*  127:     */     final E first;
/*  128:     */     final E[] rest;
/*  129:     */     private static final long serialVersionUID = 0L;
/*  130:     */     
/*  131:     */     OnePlusArrayList(@Nullable E first, E[] rest)
/*  132:     */     {
/*  133: 322 */       this.first = first;
/*  134: 323 */       this.rest = ((Object[])Preconditions.checkNotNull(rest));
/*  135:     */     }
/*  136:     */     
/*  137:     */     public int size()
/*  138:     */     {
/*  139: 328 */       return this.rest.length + 1;
/*  140:     */     }
/*  141:     */     
/*  142:     */     public E get(int index)
/*  143:     */     {
/*  144: 334 */       Preconditions.checkElementIndex(index, size());
/*  145: 335 */       return index == 0 ? this.first : this.rest[(index - 1)];
/*  146:     */     }
/*  147:     */   }
/*  148:     */   
/*  149:     */   public static <E> List<E> asList(@Nullable E first, @Nullable E second, E[] rest)
/*  150:     */   {
/*  151: 359 */     return new TwoPlusArrayList(first, second, rest);
/*  152:     */   }
/*  153:     */   
/*  154:     */   private static class TwoPlusArrayList<E>
/*  155:     */     extends AbstractList<E>
/*  156:     */     implements Serializable, RandomAccess
/*  157:     */   {
/*  158:     */     final E first;
/*  159:     */     final E second;
/*  160:     */     final E[] rest;
/*  161:     */     private static final long serialVersionUID = 0L;
/*  162:     */     
/*  163:     */     TwoPlusArrayList(@Nullable E first, @Nullable E second, E[] rest)
/*  164:     */     {
/*  165: 370 */       this.first = first;
/*  166: 371 */       this.second = second;
/*  167: 372 */       this.rest = ((Object[])Preconditions.checkNotNull(rest));
/*  168:     */     }
/*  169:     */     
/*  170:     */     public int size()
/*  171:     */     {
/*  172: 377 */       return this.rest.length + 2;
/*  173:     */     }
/*  174:     */     
/*  175:     */     public E get(int index)
/*  176:     */     {
/*  177: 382 */       switch (index)
/*  178:     */       {
/*  179:     */       case 0: 
/*  180: 384 */         return this.first;
/*  181:     */       case 1: 
/*  182: 386 */         return this.second;
/*  183:     */       }
/*  184: 389 */       Preconditions.checkElementIndex(index, size());
/*  185: 390 */       return this.rest[(index - 2)];
/*  186:     */     }
/*  187:     */   }
/*  188:     */   
/*  189:     */   public static <B> List<List<B>> cartesianProduct(List<? extends List<? extends B>> lists)
/*  190:     */   {
/*  191: 455 */     return CartesianList.create(lists);
/*  192:     */   }
/*  193:     */   
/*  194:     */   public static <B> List<List<B>> cartesianProduct(List<? extends B>... lists)
/*  195:     */   {
/*  196: 516 */     return cartesianProduct(Arrays.asList(lists));
/*  197:     */   }
/*  198:     */   
/*  199:     */   @CheckReturnValue
/*  200:     */   public static <F, T> List<T> transform(List<F> fromList, Function<? super F, ? extends T> function)
/*  201:     */   {
/*  202: 555 */     return (fromList instanceof RandomAccess) ? new TransformingRandomAccessList(fromList, function) : new TransformingSequentialList(fromList, function);
/*  203:     */   }
/*  204:     */   
/*  205:     */   private static class TransformingSequentialList<F, T>
/*  206:     */     extends AbstractSequentialList<T>
/*  207:     */     implements Serializable
/*  208:     */   {
/*  209:     */     final List<F> fromList;
/*  210:     */     final Function<? super F, ? extends T> function;
/*  211:     */     private static final long serialVersionUID = 0L;
/*  212:     */     
/*  213:     */     TransformingSequentialList(List<F> fromList, Function<? super F, ? extends T> function)
/*  214:     */     {
/*  215: 571 */       this.fromList = ((List)Preconditions.checkNotNull(fromList));
/*  216: 572 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*  217:     */     }
/*  218:     */     
/*  219:     */     public void clear()
/*  220:     */     {
/*  221: 581 */       this.fromList.clear();
/*  222:     */     }
/*  223:     */     
/*  224:     */     public int size()
/*  225:     */     {
/*  226: 586 */       return this.fromList.size();
/*  227:     */     }
/*  228:     */     
/*  229:     */     public ListIterator<T> listIterator(int index)
/*  230:     */     {
/*  231: 591 */       new TransformedListIterator(this.fromList.listIterator(index))
/*  232:     */       {
/*  233:     */         T transform(F from)
/*  234:     */         {
/*  235: 594 */           return Lists.TransformingSequentialList.this.function.apply(from);
/*  236:     */         }
/*  237:     */       };
/*  238:     */     }
/*  239:     */   }
/*  240:     */   
/*  241:     */   private static class TransformingRandomAccessList<F, T>
/*  242:     */     extends AbstractList<T>
/*  243:     */     implements RandomAccess, Serializable
/*  244:     */   {
/*  245:     */     final List<F> fromList;
/*  246:     */     final Function<? super F, ? extends T> function;
/*  247:     */     private static final long serialVersionUID = 0L;
/*  248:     */     
/*  249:     */     TransformingRandomAccessList(List<F> fromList, Function<? super F, ? extends T> function)
/*  250:     */     {
/*  251: 616 */       this.fromList = ((List)Preconditions.checkNotNull(fromList));
/*  252: 617 */       this.function = ((Function)Preconditions.checkNotNull(function));
/*  253:     */     }
/*  254:     */     
/*  255:     */     public void clear()
/*  256:     */     {
/*  257: 622 */       this.fromList.clear();
/*  258:     */     }
/*  259:     */     
/*  260:     */     public T get(int index)
/*  261:     */     {
/*  262: 627 */       return this.function.apply(this.fromList.get(index));
/*  263:     */     }
/*  264:     */     
/*  265:     */     public Iterator<T> iterator()
/*  266:     */     {
/*  267: 632 */       return listIterator();
/*  268:     */     }
/*  269:     */     
/*  270:     */     public ListIterator<T> listIterator(int index)
/*  271:     */     {
/*  272: 637 */       new TransformedListIterator(this.fromList.listIterator(index))
/*  273:     */       {
/*  274:     */         T transform(F from)
/*  275:     */         {
/*  276: 640 */           return Lists.TransformingRandomAccessList.this.function.apply(from);
/*  277:     */         }
/*  278:     */       };
/*  279:     */     }
/*  280:     */     
/*  281:     */     public boolean isEmpty()
/*  282:     */     {
/*  283: 647 */       return this.fromList.isEmpty();
/*  284:     */     }
/*  285:     */     
/*  286:     */     public T remove(int index)
/*  287:     */     {
/*  288: 652 */       return this.function.apply(this.fromList.remove(index));
/*  289:     */     }
/*  290:     */     
/*  291:     */     public int size()
/*  292:     */     {
/*  293: 657 */       return this.fromList.size();
/*  294:     */     }
/*  295:     */   }
/*  296:     */   
/*  297:     */   public static <T> List<List<T>> partition(List<T> list, int size)
/*  298:     */   {
/*  299: 682 */     Preconditions.checkNotNull(list);
/*  300: 683 */     Preconditions.checkArgument(size > 0);
/*  301: 684 */     return (list instanceof RandomAccess) ? new RandomAccessPartition(list, size) : new Partition(list, size);
/*  302:     */   }
/*  303:     */   
/*  304:     */   private static class Partition<T>
/*  305:     */     extends AbstractList<List<T>>
/*  306:     */   {
/*  307:     */     final List<T> list;
/*  308:     */     final int size;
/*  309:     */     
/*  310:     */     Partition(List<T> list, int size)
/*  311:     */     {
/*  312: 694 */       this.list = list;
/*  313: 695 */       this.size = size;
/*  314:     */     }
/*  315:     */     
/*  316:     */     public List<T> get(int index)
/*  317:     */     {
/*  318: 700 */       Preconditions.checkElementIndex(index, size());
/*  319: 701 */       int start = index * this.size;
/*  320: 702 */       int end = Math.min(start + this.size, this.list.size());
/*  321: 703 */       return this.list.subList(start, end);
/*  322:     */     }
/*  323:     */     
/*  324:     */     public int size()
/*  325:     */     {
/*  326: 708 */       return IntMath.divide(this.list.size(), this.size, RoundingMode.CEILING);
/*  327:     */     }
/*  328:     */     
/*  329:     */     public boolean isEmpty()
/*  330:     */     {
/*  331: 713 */       return this.list.isEmpty();
/*  332:     */     }
/*  333:     */   }
/*  334:     */   
/*  335:     */   private static class RandomAccessPartition<T>
/*  336:     */     extends Lists.Partition<T>
/*  337:     */     implements RandomAccess
/*  338:     */   {
/*  339:     */     RandomAccessPartition(List<T> list, int size)
/*  340:     */     {
/*  341: 719 */       super(size);
/*  342:     */     }
/*  343:     */   }
/*  344:     */   
/*  345:     */   @Beta
/*  346:     */   public static ImmutableList<Character> charactersOf(String string)
/*  347:     */   {
/*  348: 731 */     return new StringAsImmutableList((String)Preconditions.checkNotNull(string));
/*  349:     */   }
/*  350:     */   
/*  351:     */   private static final class StringAsImmutableList
/*  352:     */     extends ImmutableList<Character>
/*  353:     */   {
/*  354:     */     private final String string;
/*  355:     */     
/*  356:     */     StringAsImmutableList(String string)
/*  357:     */     {
/*  358: 740 */       this.string = string;
/*  359:     */     }
/*  360:     */     
/*  361:     */     public int indexOf(@Nullable Object object)
/*  362:     */     {
/*  363: 745 */       return (object instanceof Character) ? this.string.indexOf(((Character)object).charValue()) : -1;
/*  364:     */     }
/*  365:     */     
/*  366:     */     public int lastIndexOf(@Nullable Object object)
/*  367:     */     {
/*  368: 750 */       return (object instanceof Character) ? this.string.lastIndexOf(((Character)object).charValue()) : -1;
/*  369:     */     }
/*  370:     */     
/*  371:     */     public ImmutableList<Character> subList(int fromIndex, int toIndex)
/*  372:     */     {
/*  373: 755 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/*  374: 756 */       return Lists.charactersOf(this.string.substring(fromIndex, toIndex));
/*  375:     */     }
/*  376:     */     
/*  377:     */     boolean isPartialView()
/*  378:     */     {
/*  379: 761 */       return false;
/*  380:     */     }
/*  381:     */     
/*  382:     */     public Character get(int index)
/*  383:     */     {
/*  384: 766 */       Preconditions.checkElementIndex(index, size());
/*  385: 767 */       return Character.valueOf(this.string.charAt(index));
/*  386:     */     }
/*  387:     */     
/*  388:     */     public int size()
/*  389:     */     {
/*  390: 772 */       return this.string.length();
/*  391:     */     }
/*  392:     */   }
/*  393:     */   
/*  394:     */   @Beta
/*  395:     */   public static List<Character> charactersOf(CharSequence sequence)
/*  396:     */   {
/*  397: 789 */     return new CharSequenceAsList((CharSequence)Preconditions.checkNotNull(sequence));
/*  398:     */   }
/*  399:     */   
/*  400:     */   private static final class CharSequenceAsList
/*  401:     */     extends AbstractList<Character>
/*  402:     */   {
/*  403:     */     private final CharSequence sequence;
/*  404:     */     
/*  405:     */     CharSequenceAsList(CharSequence sequence)
/*  406:     */     {
/*  407: 796 */       this.sequence = sequence;
/*  408:     */     }
/*  409:     */     
/*  410:     */     public Character get(int index)
/*  411:     */     {
/*  412: 801 */       Preconditions.checkElementIndex(index, size());
/*  413: 802 */       return Character.valueOf(this.sequence.charAt(index));
/*  414:     */     }
/*  415:     */     
/*  416:     */     public int size()
/*  417:     */     {
/*  418: 807 */       return this.sequence.length();
/*  419:     */     }
/*  420:     */   }
/*  421:     */   
/*  422:     */   @CheckReturnValue
/*  423:     */   public static <T> List<T> reverse(List<T> list)
/*  424:     */   {
/*  425: 825 */     if ((list instanceof ImmutableList)) {
/*  426: 826 */       return ((ImmutableList)list).reverse();
/*  427:     */     }
/*  428: 827 */     if ((list instanceof ReverseList)) {
/*  429: 828 */       return ((ReverseList)list).getForwardList();
/*  430:     */     }
/*  431: 829 */     if ((list instanceof RandomAccess)) {
/*  432: 830 */       return new RandomAccessReverseList(list);
/*  433:     */     }
/*  434: 832 */     return new ReverseList(list);
/*  435:     */   }
/*  436:     */   
/*  437:     */   private static class ReverseList<T>
/*  438:     */     extends AbstractList<T>
/*  439:     */   {
/*  440:     */     private final List<T> forwardList;
/*  441:     */     
/*  442:     */     ReverseList(List<T> forwardList)
/*  443:     */     {
/*  444: 840 */       this.forwardList = ((List)Preconditions.checkNotNull(forwardList));
/*  445:     */     }
/*  446:     */     
/*  447:     */     List<T> getForwardList()
/*  448:     */     {
/*  449: 844 */       return this.forwardList;
/*  450:     */     }
/*  451:     */     
/*  452:     */     private int reverseIndex(int index)
/*  453:     */     {
/*  454: 848 */       int size = size();
/*  455: 849 */       Preconditions.checkElementIndex(index, size);
/*  456: 850 */       return size - 1 - index;
/*  457:     */     }
/*  458:     */     
/*  459:     */     private int reversePosition(int index)
/*  460:     */     {
/*  461: 854 */       int size = size();
/*  462: 855 */       Preconditions.checkPositionIndex(index, size);
/*  463: 856 */       return size - index;
/*  464:     */     }
/*  465:     */     
/*  466:     */     public void add(int index, @Nullable T element)
/*  467:     */     {
/*  468: 861 */       this.forwardList.add(reversePosition(index), element);
/*  469:     */     }
/*  470:     */     
/*  471:     */     public void clear()
/*  472:     */     {
/*  473: 866 */       this.forwardList.clear();
/*  474:     */     }
/*  475:     */     
/*  476:     */     public T remove(int index)
/*  477:     */     {
/*  478: 871 */       return this.forwardList.remove(reverseIndex(index));
/*  479:     */     }
/*  480:     */     
/*  481:     */     protected void removeRange(int fromIndex, int toIndex)
/*  482:     */     {
/*  483: 876 */       subList(fromIndex, toIndex).clear();
/*  484:     */     }
/*  485:     */     
/*  486:     */     public T set(int index, @Nullable T element)
/*  487:     */     {
/*  488: 881 */       return this.forwardList.set(reverseIndex(index), element);
/*  489:     */     }
/*  490:     */     
/*  491:     */     public T get(int index)
/*  492:     */     {
/*  493: 886 */       return this.forwardList.get(reverseIndex(index));
/*  494:     */     }
/*  495:     */     
/*  496:     */     public int size()
/*  497:     */     {
/*  498: 891 */       return this.forwardList.size();
/*  499:     */     }
/*  500:     */     
/*  501:     */     public List<T> subList(int fromIndex, int toIndex)
/*  502:     */     {
/*  503: 896 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/*  504: 897 */       return Lists.reverse(this.forwardList.subList(reversePosition(toIndex), reversePosition(fromIndex)));
/*  505:     */     }
/*  506:     */     
/*  507:     */     public Iterator<T> iterator()
/*  508:     */     {
/*  509: 902 */       return listIterator();
/*  510:     */     }
/*  511:     */     
/*  512:     */     public ListIterator<T> listIterator(int index)
/*  513:     */     {
/*  514: 907 */       int start = reversePosition(index);
/*  515: 908 */       final ListIterator<T> forwardIterator = this.forwardList.listIterator(start);
/*  516: 909 */       new ListIterator()
/*  517:     */       {
/*  518:     */         boolean canRemoveOrSet;
/*  519:     */         
/*  520:     */         public void add(T e)
/*  521:     */         {
/*  522: 915 */           forwardIterator.add(e);
/*  523: 916 */           forwardIterator.previous();
/*  524: 917 */           this.canRemoveOrSet = false;
/*  525:     */         }
/*  526:     */         
/*  527:     */         public boolean hasNext()
/*  528:     */         {
/*  529: 922 */           return forwardIterator.hasPrevious();
/*  530:     */         }
/*  531:     */         
/*  532:     */         public boolean hasPrevious()
/*  533:     */         {
/*  534: 927 */           return forwardIterator.hasNext();
/*  535:     */         }
/*  536:     */         
/*  537:     */         public T next()
/*  538:     */         {
/*  539: 932 */           if (!hasNext()) {
/*  540: 933 */             throw new NoSuchElementException();
/*  541:     */           }
/*  542: 935 */           this.canRemoveOrSet = true;
/*  543: 936 */           return forwardIterator.previous();
/*  544:     */         }
/*  545:     */         
/*  546:     */         public int nextIndex()
/*  547:     */         {
/*  548: 941 */           return Lists.ReverseList.this.reversePosition(forwardIterator.nextIndex());
/*  549:     */         }
/*  550:     */         
/*  551:     */         public T previous()
/*  552:     */         {
/*  553: 946 */           if (!hasPrevious()) {
/*  554: 947 */             throw new NoSuchElementException();
/*  555:     */           }
/*  556: 949 */           this.canRemoveOrSet = true;
/*  557: 950 */           return forwardIterator.next();
/*  558:     */         }
/*  559:     */         
/*  560:     */         public int previousIndex()
/*  561:     */         {
/*  562: 955 */           return nextIndex() - 1;
/*  563:     */         }
/*  564:     */         
/*  565:     */         public void remove()
/*  566:     */         {
/*  567: 960 */           CollectPreconditions.checkRemove(this.canRemoveOrSet);
/*  568: 961 */           forwardIterator.remove();
/*  569: 962 */           this.canRemoveOrSet = false;
/*  570:     */         }
/*  571:     */         
/*  572:     */         public void set(T e)
/*  573:     */         {
/*  574: 967 */           Preconditions.checkState(this.canRemoveOrSet);
/*  575: 968 */           forwardIterator.set(e);
/*  576:     */         }
/*  577:     */       };
/*  578:     */     }
/*  579:     */   }
/*  580:     */   
/*  581:     */   private static class RandomAccessReverseList<T>
/*  582:     */     extends Lists.ReverseList<T>
/*  583:     */     implements RandomAccess
/*  584:     */   {
/*  585:     */     RandomAccessReverseList(List<T> forwardList)
/*  586:     */     {
/*  587: 976 */       super();
/*  588:     */     }
/*  589:     */   }
/*  590:     */   
/*  591:     */   static int hashCodeImpl(List<?> list)
/*  592:     */   {
/*  593: 985 */     int hashCode = 1;
/*  594: 986 */     for (Object o : list)
/*  595:     */     {
/*  596: 987 */       hashCode = 31 * hashCode + (o == null ? 0 : o.hashCode());
/*  597:     */       
/*  598: 989 */       hashCode = hashCode ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  599:     */     }
/*  600: 992 */     return hashCode;
/*  601:     */   }
/*  602:     */   
/*  603:     */   static boolean equalsImpl(List<?> thisList, @Nullable Object other)
/*  604:     */   {
/*  605: 999 */     if (other == Preconditions.checkNotNull(thisList)) {
/*  606:1000 */       return true;
/*  607:     */     }
/*  608:1002 */     if (!(other instanceof List)) {
/*  609:1003 */       return false;
/*  610:     */     }
/*  611:1005 */     List<?> otherList = (List)other;
/*  612:1006 */     int size = thisList.size();
/*  613:1007 */     if (size != otherList.size()) {
/*  614:1008 */       return false;
/*  615:     */     }
/*  616:1010 */     if (((thisList instanceof RandomAccess)) && ((otherList instanceof RandomAccess)))
/*  617:     */     {
/*  618:1012 */       for (int i = 0; i < size; i++) {
/*  619:1013 */         if (!Objects.equal(thisList.get(i), otherList.get(i))) {
/*  620:1014 */           return false;
/*  621:     */         }
/*  622:     */       }
/*  623:1017 */       return true;
/*  624:     */     }
/*  625:1019 */     return Iterators.elementsEqual(thisList.iterator(), otherList.iterator());
/*  626:     */   }
/*  627:     */   
/*  628:     */   static <E> boolean addAllImpl(List<E> list, int index, Iterable<? extends E> elements)
/*  629:     */   {
/*  630:1027 */     boolean changed = false;
/*  631:1028 */     ListIterator<E> listIterator = list.listIterator(index);
/*  632:1029 */     for (E e : elements)
/*  633:     */     {
/*  634:1030 */       listIterator.add(e);
/*  635:1031 */       changed = true;
/*  636:     */     }
/*  637:1033 */     return changed;
/*  638:     */   }
/*  639:     */   
/*  640:     */   static int indexOfImpl(List<?> list, @Nullable Object element)
/*  641:     */   {
/*  642:1040 */     if ((list instanceof RandomAccess)) {
/*  643:1041 */       return indexOfRandomAccess(list, element);
/*  644:     */     }
/*  645:1043 */     ListIterator<?> listIterator = list.listIterator();
/*  646:1044 */     while (listIterator.hasNext()) {
/*  647:1045 */       if (Objects.equal(element, listIterator.next())) {
/*  648:1046 */         return listIterator.previousIndex();
/*  649:     */       }
/*  650:     */     }
/*  651:1049 */     return -1;
/*  652:     */   }
/*  653:     */   
/*  654:     */   private static int indexOfRandomAccess(List<?> list, @Nullable Object element)
/*  655:     */   {
/*  656:1054 */     int size = list.size();
/*  657:1055 */     if (element == null) {
/*  658:1056 */       for (int i = 0; i < size; i++) {
/*  659:1057 */         if (list.get(i) == null) {
/*  660:1058 */           return i;
/*  661:     */         }
/*  662:     */       }
/*  663:     */     } else {
/*  664:1062 */       for (int i = 0; i < size; i++) {
/*  665:1063 */         if (element.equals(list.get(i))) {
/*  666:1064 */           return i;
/*  667:     */         }
/*  668:     */       }
/*  669:     */     }
/*  670:1068 */     return -1;
/*  671:     */   }
/*  672:     */   
/*  673:     */   static int lastIndexOfImpl(List<?> list, @Nullable Object element)
/*  674:     */   {
/*  675:1075 */     if ((list instanceof RandomAccess)) {
/*  676:1076 */       return lastIndexOfRandomAccess(list, element);
/*  677:     */     }
/*  678:1078 */     ListIterator<?> listIterator = list.listIterator(list.size());
/*  679:1079 */     while (listIterator.hasPrevious()) {
/*  680:1080 */       if (Objects.equal(element, listIterator.previous())) {
/*  681:1081 */         return listIterator.nextIndex();
/*  682:     */       }
/*  683:     */     }
/*  684:1084 */     return -1;
/*  685:     */   }
/*  686:     */   
/*  687:     */   private static int lastIndexOfRandomAccess(List<?> list, @Nullable Object element)
/*  688:     */   {
/*  689:1089 */     if (element == null) {
/*  690:1090 */       for (int i = list.size() - 1; i >= 0; i--) {
/*  691:1091 */         if (list.get(i) == null) {
/*  692:1092 */           return i;
/*  693:     */         }
/*  694:     */       }
/*  695:     */     } else {
/*  696:1096 */       for (int i = list.size() - 1; i >= 0; i--) {
/*  697:1097 */         if (element.equals(list.get(i))) {
/*  698:1098 */           return i;
/*  699:     */         }
/*  700:     */       }
/*  701:     */     }
/*  702:1102 */     return -1;
/*  703:     */   }
/*  704:     */   
/*  705:     */   static <E> ListIterator<E> listIteratorImpl(List<E> list, int index)
/*  706:     */   {
/*  707:1109 */     return new AbstractListWrapper(list).listIterator(index);
/*  708:     */   }
/*  709:     */   
/*  710:     */   static <E> List<E> subListImpl(List<E> list, int fromIndex, int toIndex)
/*  711:     */   {
/*  712:     */     List<E> wrapper;
/*  713:     */     List<E> wrapper;
/*  714:1117 */     if ((list instanceof RandomAccess)) {
/*  715:1118 */       wrapper = new RandomAccessListWrapper(list)
/*  716:     */       {
/*  717:     */         private static final long serialVersionUID = 0L;
/*  718:     */         
/*  719:     */         public ListIterator<E> listIterator(int index)
/*  720:     */         {
/*  721:1121 */           return this.backingList.listIterator(index);
/*  722:     */         }
/*  723:     */       };
/*  724:     */     } else {
/*  725:1127 */       wrapper = new AbstractListWrapper(list)
/*  726:     */       {
/*  727:     */         private static final long serialVersionUID = 0L;
/*  728:     */         
/*  729:     */         public ListIterator<E> listIterator(int index)
/*  730:     */         {
/*  731:1130 */           return this.backingList.listIterator(index);
/*  732:     */         }
/*  733:     */       };
/*  734:     */     }
/*  735:1136 */     return wrapper.subList(fromIndex, toIndex);
/*  736:     */   }
/*  737:     */   
/*  738:     */   private static class AbstractListWrapper<E>
/*  739:     */     extends AbstractList<E>
/*  740:     */   {
/*  741:     */     final List<E> backingList;
/*  742:     */     
/*  743:     */     AbstractListWrapper(List<E> backingList)
/*  744:     */     {
/*  745:1143 */       this.backingList = ((List)Preconditions.checkNotNull(backingList));
/*  746:     */     }
/*  747:     */     
/*  748:     */     public void add(int index, E element)
/*  749:     */     {
/*  750:1148 */       this.backingList.add(index, element);
/*  751:     */     }
/*  752:     */     
/*  753:     */     public boolean addAll(int index, Collection<? extends E> c)
/*  754:     */     {
/*  755:1153 */       return this.backingList.addAll(index, c);
/*  756:     */     }
/*  757:     */     
/*  758:     */     public E get(int index)
/*  759:     */     {
/*  760:1158 */       return this.backingList.get(index);
/*  761:     */     }
/*  762:     */     
/*  763:     */     public E remove(int index)
/*  764:     */     {
/*  765:1163 */       return this.backingList.remove(index);
/*  766:     */     }
/*  767:     */     
/*  768:     */     public E set(int index, E element)
/*  769:     */     {
/*  770:1168 */       return this.backingList.set(index, element);
/*  771:     */     }
/*  772:     */     
/*  773:     */     public boolean contains(Object o)
/*  774:     */     {
/*  775:1173 */       return this.backingList.contains(o);
/*  776:     */     }
/*  777:     */     
/*  778:     */     public int size()
/*  779:     */     {
/*  780:1178 */       return this.backingList.size();
/*  781:     */     }
/*  782:     */   }
/*  783:     */   
/*  784:     */   private static class RandomAccessListWrapper<E>
/*  785:     */     extends Lists.AbstractListWrapper<E>
/*  786:     */     implements RandomAccess
/*  787:     */   {
/*  788:     */     RandomAccessListWrapper(List<E> backingList)
/*  789:     */     {
/*  790:1185 */       super();
/*  791:     */     }
/*  792:     */   }
/*  793:     */   
/*  794:     */   static <T> List<T> cast(Iterable<T> iterable)
/*  795:     */   {
/*  796:1193 */     return (List)iterable;
/*  797:     */   }
/*  798:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Lists
 * JD-Core Version:    0.7.0.1
 */