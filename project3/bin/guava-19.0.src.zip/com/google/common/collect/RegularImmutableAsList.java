/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import com.google.j2objc.annotations.Weak;
/*  6:   */ 
/*  7:   */ @GwtCompatible(emulated=true)
/*  8:   */ class RegularImmutableAsList<E>
/*  9:   */   extends ImmutableAsList<E>
/* 10:   */ {
/* 11:   */   @Weak
/* 12:   */   private final ImmutableCollection<E> delegate;
/* 13:   */   private final ImmutableList<? extends E> delegateList;
/* 14:   */   
/* 15:   */   RegularImmutableAsList(ImmutableCollection<E> delegate, ImmutableList<? extends E> delegateList)
/* 16:   */   {
/* 17:36 */     this.delegate = delegate;
/* 18:37 */     this.delegateList = delegateList;
/* 19:   */   }
/* 20:   */   
/* 21:   */   RegularImmutableAsList(ImmutableCollection<E> delegate, Object[] array)
/* 22:   */   {
/* 23:41 */     this(delegate, ImmutableList.asImmutableList(array));
/* 24:   */   }
/* 25:   */   
/* 26:   */   ImmutableCollection<E> delegateCollection()
/* 27:   */   {
/* 28:46 */     return this.delegate;
/* 29:   */   }
/* 30:   */   
/* 31:   */   ImmutableList<? extends E> delegateList()
/* 32:   */   {
/* 33:50 */     return this.delegateList;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public UnmodifiableListIterator<E> listIterator(int index)
/* 37:   */   {
/* 38:56 */     return this.delegateList.listIterator(index);
/* 39:   */   }
/* 40:   */   
/* 41:   */   @GwtIncompatible("not present in emulated superclass")
/* 42:   */   int copyIntoArray(Object[] dst, int offset)
/* 43:   */   {
/* 44:62 */     return this.delegateList.copyIntoArray(dst, offset);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public E get(int index)
/* 48:   */   {
/* 49:67 */     return this.delegateList.get(index);
/* 50:   */   }
/* 51:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableAsList
 * JD-Core Version:    0.7.0.1
 */