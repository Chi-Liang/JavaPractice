/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Comparator;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.LinkedHashMap;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Map.Entry;
/*  14:    */ import java.util.Set;
/*  15:    */ import java.util.SortedSet;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @Deprecated
/*  19:    */ @Beta
/*  20:    */ @GwtCompatible
/*  21:    */ public final class MapConstraints
/*  22:    */ {
/*  23:    */   public static MapConstraint<Object, Object> notNull()
/*  24:    */   {
/*  25: 61 */     return NotNullMapConstraint.INSTANCE;
/*  26:    */   }
/*  27:    */   
/*  28:    */   private static enum NotNullMapConstraint
/*  29:    */     implements MapConstraint<Object, Object>
/*  30:    */   {
/*  31: 66 */     INSTANCE;
/*  32:    */     
/*  33:    */     private NotNullMapConstraint() {}
/*  34:    */     
/*  35:    */     public void checkKeyValue(Object key, Object value)
/*  36:    */     {
/*  37: 70 */       Preconditions.checkNotNull(key);
/*  38: 71 */       Preconditions.checkNotNull(value);
/*  39:    */     }
/*  40:    */     
/*  41:    */     public String toString()
/*  42:    */     {
/*  43: 76 */       return "Not null";
/*  44:    */     }
/*  45:    */   }
/*  46:    */   
/*  47:    */   public static <K, V> Map<K, V> constrainedMap(Map<K, V> map, MapConstraint<? super K, ? super V> constraint)
/*  48:    */   {
/*  49: 94 */     return new ConstrainedMap(map, constraint);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static <K, V> Multimap<K, V> constrainedMultimap(Multimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*  53:    */   {
/*  54:115 */     return new ConstrainedMultimap(multimap, constraint);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public static <K, V> ListMultimap<K, V> constrainedListMultimap(ListMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*  58:    */   {
/*  59:136 */     return new ConstrainedListMultimap(multimap, constraint);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static <K, V> SetMultimap<K, V> constrainedSetMultimap(SetMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*  63:    */   {
/*  64:156 */     return new ConstrainedSetMultimap(multimap, constraint);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static <K, V> SortedSetMultimap<K, V> constrainedSortedSetMultimap(SortedSetMultimap<K, V> multimap, MapConstraint<? super K, ? super V> constraint)
/*  68:    */   {
/*  69:176 */     return new ConstrainedSortedSetMultimap(multimap, constraint);
/*  70:    */   }
/*  71:    */   
/*  72:    */   private static <K, V> Map.Entry<K, V> constrainedEntry(Map.Entry<K, V> entry, final MapConstraint<? super K, ? super V> constraint)
/*  73:    */   {
/*  74:190 */     Preconditions.checkNotNull(entry);
/*  75:191 */     Preconditions.checkNotNull(constraint);
/*  76:192 */     new ForwardingMapEntry()
/*  77:    */     {
/*  78:    */       protected Map.Entry<K, V> delegate()
/*  79:    */       {
/*  80:195 */         return this.val$entry;
/*  81:    */       }
/*  82:    */       
/*  83:    */       public V setValue(V value)
/*  84:    */       {
/*  85:200 */         constraint.checkKeyValue(getKey(), value);
/*  86:201 */         return this.val$entry.setValue(value);
/*  87:    */       }
/*  88:    */     };
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static <K, V> Map.Entry<K, Collection<V>> constrainedAsMapEntry(Map.Entry<K, Collection<V>> entry, final MapConstraint<? super K, ? super V> constraint)
/*  92:    */   {
/*  93:218 */     Preconditions.checkNotNull(entry);
/*  94:219 */     Preconditions.checkNotNull(constraint);
/*  95:220 */     new ForwardingMapEntry()
/*  96:    */     {
/*  97:    */       protected Map.Entry<K, Collection<V>> delegate()
/*  98:    */       {
/*  99:223 */         return this.val$entry;
/* 100:    */       }
/* 101:    */       
/* 102:    */       public Collection<V> getValue()
/* 103:    */       {
/* 104:228 */         Constraints.constrainedTypePreservingCollection((Collection)this.val$entry.getValue(), new Constraint()
/* 105:    */         {
/* 106:    */           public V checkElement(V value)
/* 107:    */           {
/* 108:233 */             MapConstraints.2.this.val$constraint.checkKeyValue(MapConstraints.2.this.getKey(), value);
/* 109:234 */             return value;
/* 110:    */           }
/* 111:    */         });
/* 112:    */       }
/* 113:    */     };
/* 114:    */   }
/* 115:    */   
/* 116:    */   private static <K, V> Set<Map.Entry<K, Collection<V>>> constrainedAsMapEntries(Set<Map.Entry<K, Collection<V>>> entries, MapConstraint<? super K, ? super V> constraint)
/* 117:    */   {
/* 118:255 */     return new ConstrainedAsMapEntries(entries, constraint);
/* 119:    */   }
/* 120:    */   
/* 121:    */   private static <K, V> Collection<Map.Entry<K, V>> constrainedEntries(Collection<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/* 122:    */   {
/* 123:272 */     if ((entries instanceof Set)) {
/* 124:273 */       return constrainedEntrySet((Set)entries, constraint);
/* 125:    */     }
/* 126:275 */     return new ConstrainedEntries(entries, constraint);
/* 127:    */   }
/* 128:    */   
/* 129:    */   private static <K, V> Set<Map.Entry<K, V>> constrainedEntrySet(Set<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/* 130:    */   {
/* 131:294 */     return new ConstrainedEntrySet(entries, constraint);
/* 132:    */   }
/* 133:    */   
/* 134:    */   static class ConstrainedMap<K, V>
/* 135:    */     extends ForwardingMap<K, V>
/* 136:    */   {
/* 137:    */     private final Map<K, V> delegate;
/* 138:    */     final MapConstraint<? super K, ? super V> constraint;
/* 139:    */     private transient Set<Map.Entry<K, V>> entrySet;
/* 140:    */     
/* 141:    */     ConstrainedMap(Map<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 142:    */     {
/* 143:304 */       this.delegate = ((Map)Preconditions.checkNotNull(delegate));
/* 144:305 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/* 145:    */     }
/* 146:    */     
/* 147:    */     protected Map<K, V> delegate()
/* 148:    */     {
/* 149:310 */       return this.delegate;
/* 150:    */     }
/* 151:    */     
/* 152:    */     public Set<Map.Entry<K, V>> entrySet()
/* 153:    */     {
/* 154:315 */       Set<Map.Entry<K, V>> result = this.entrySet;
/* 155:316 */       if (result == null) {
/* 156:317 */         this.entrySet = (result = MapConstraints.constrainedEntrySet(this.delegate.entrySet(), this.constraint));
/* 157:    */       }
/* 158:319 */       return result;
/* 159:    */     }
/* 160:    */     
/* 161:    */     public V put(K key, V value)
/* 162:    */     {
/* 163:324 */       this.constraint.checkKeyValue(key, value);
/* 164:325 */       return this.delegate.put(key, value);
/* 165:    */     }
/* 166:    */     
/* 167:    */     public void putAll(Map<? extends K, ? extends V> map)
/* 168:    */     {
/* 169:330 */       this.delegate.putAll(MapConstraints.checkMap(map, this.constraint));
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   public static <K, V> BiMap<K, V> constrainedBiMap(BiMap<K, V> map, MapConstraint<? super K, ? super V> constraint)
/* 174:    */   {
/* 175:347 */     return new ConstrainedBiMap(map, null, constraint);
/* 176:    */   }
/* 177:    */   
/* 178:    */   private static class ConstrainedBiMap<K, V>
/* 179:    */     extends MapConstraints.ConstrainedMap<K, V>
/* 180:    */     implements BiMap<K, V>
/* 181:    */   {
/* 182:    */     volatile BiMap<V, K> inverse;
/* 183:    */     
/* 184:    */     ConstrainedBiMap(BiMap<K, V> delegate, @Nullable BiMap<V, K> inverse, MapConstraint<? super K, ? super V> constraint)
/* 185:    */     {
/* 186:370 */       super(constraint);
/* 187:371 */       this.inverse = inverse;
/* 188:    */     }
/* 189:    */     
/* 190:    */     protected BiMap<K, V> delegate()
/* 191:    */     {
/* 192:376 */       return (BiMap)super.delegate();
/* 193:    */     }
/* 194:    */     
/* 195:    */     public V forcePut(K key, V value)
/* 196:    */     {
/* 197:381 */       this.constraint.checkKeyValue(key, value);
/* 198:382 */       return delegate().forcePut(key, value);
/* 199:    */     }
/* 200:    */     
/* 201:    */     public BiMap<V, K> inverse()
/* 202:    */     {
/* 203:387 */       if (this.inverse == null) {
/* 204:388 */         this.inverse = new ConstrainedBiMap(delegate().inverse(), this, new MapConstraints.InverseConstraint(this.constraint));
/* 205:    */       }
/* 206:391 */       return this.inverse;
/* 207:    */     }
/* 208:    */     
/* 209:    */     public Set<V> values()
/* 210:    */     {
/* 211:396 */       return delegate().values();
/* 212:    */     }
/* 213:    */   }
/* 214:    */   
/* 215:    */   private static class InverseConstraint<K, V>
/* 216:    */     implements MapConstraint<K, V>
/* 217:    */   {
/* 218:    */     final MapConstraint<? super V, ? super K> constraint;
/* 219:    */     
/* 220:    */     public InverseConstraint(MapConstraint<? super V, ? super K> constraint)
/* 221:    */     {
/* 222:405 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/* 223:    */     }
/* 224:    */     
/* 225:    */     public void checkKeyValue(K key, V value)
/* 226:    */     {
/* 227:410 */       this.constraint.checkKeyValue(value, key);
/* 228:    */     }
/* 229:    */   }
/* 230:    */   
/* 231:    */   private static class ConstrainedMultimap<K, V>
/* 232:    */     extends ForwardingMultimap<K, V>
/* 233:    */     implements Serializable
/* 234:    */   {
/* 235:    */     final MapConstraint<? super K, ? super V> constraint;
/* 236:    */     final Multimap<K, V> delegate;
/* 237:    */     transient Collection<Map.Entry<K, V>> entries;
/* 238:    */     transient Map<K, Collection<V>> asMap;
/* 239:    */     
/* 240:    */     public ConstrainedMultimap(Multimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 241:    */     {
/* 242:426 */       this.delegate = ((Multimap)Preconditions.checkNotNull(delegate));
/* 243:427 */       this.constraint = ((MapConstraint)Preconditions.checkNotNull(constraint));
/* 244:    */     }
/* 245:    */     
/* 246:    */     protected Multimap<K, V> delegate()
/* 247:    */     {
/* 248:432 */       return this.delegate;
/* 249:    */     }
/* 250:    */     
/* 251:    */     public Map<K, Collection<V>> asMap()
/* 252:    */     {
/* 253:437 */       Map<K, Collection<V>> result = this.asMap;
/* 254:438 */       if (result == null)
/* 255:    */       {
/* 256:439 */         final Map<K, Collection<V>> asMapDelegate = this.delegate.asMap();
/* 257:    */         
/* 258:    */ 
/* 259:    */ 
/* 260:    */ 
/* 261:    */ 
/* 262:    */ 
/* 263:    */ 
/* 264:    */ 
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:    */ 
/* 269:    */ 
/* 270:    */ 
/* 271:    */ 
/* 272:    */ 
/* 273:    */ 
/* 274:    */ 
/* 275:    */ 
/* 276:    */ 
/* 277:    */ 
/* 278:    */ 
/* 279:    */ 
/* 280:    */ 
/* 281:    */ 
/* 282:    */ 
/* 283:    */ 
/* 284:    */ 
/* 285:    */ 
/* 286:    */ 
/* 287:    */ 
/* 288:    */ 
/* 289:    */ 
/* 290:    */ 
/* 291:    */ 
/* 292:    */ 
/* 293:    */ 
/* 294:    */ 
/* 295:    */ 
/* 296:    */ 
/* 297:    */ 
/* 298:    */ 
/* 299:    */ 
/* 300:    */ 
/* 301:    */ 
/* 302:485 */         this.asMap = (result = new ForwardingMap()
/* 303:    */         {
/* 304:    */           Set<Map.Entry<K, Collection<V>>> entrySet;
/* 305:    */           Collection<Collection<V>> values;
/* 306:    */           
/* 307:    */           protected Map<K, Collection<V>> delegate()
/* 308:    */           {
/* 309:448 */             return asMapDelegate;
/* 310:    */           }
/* 311:    */           
/* 312:    */           public Set<Map.Entry<K, Collection<V>>> entrySet()
/* 313:    */           {
/* 314:453 */             Set<Map.Entry<K, Collection<V>>> result = this.entrySet;
/* 315:454 */             if (result == null) {
/* 316:455 */               this.entrySet = (result = MapConstraints.constrainedAsMapEntries(asMapDelegate.entrySet(), this.this$0.constraint));
/* 317:    */             }
/* 318:457 */             return result;
/* 319:    */           }
/* 320:    */           
/* 321:    */           public Collection<V> get(Object key)
/* 322:    */           {
/* 323:    */             try
/* 324:    */             {
/* 325:464 */               Collection<V> collection = this.this$0.get(key);
/* 326:465 */               return collection.isEmpty() ? null : collection;
/* 327:    */             }
/* 328:    */             catch (ClassCastException e) {}
/* 329:467 */             return null;
/* 330:    */           }
/* 331:    */           
/* 332:    */           public Collection<Collection<V>> values()
/* 333:    */           {
/* 334:473 */             Collection<Collection<V>> result = this.values;
/* 335:474 */             if (result == null) {
/* 336:475 */               this.values = (result = new MapConstraints.ConstrainedAsMapValues(delegate().values(), entrySet()));
/* 337:    */             }
/* 338:477 */             return result;
/* 339:    */           }
/* 340:    */           
/* 341:    */           public boolean containsValue(Object o)
/* 342:    */           {
/* 343:482 */             return values().contains(o);
/* 344:    */           }
/* 345:    */         });
/* 346:    */       }
/* 347:487 */       return result;
/* 348:    */     }
/* 349:    */     
/* 350:    */     public Collection<Map.Entry<K, V>> entries()
/* 351:    */     {
/* 352:492 */       Collection<Map.Entry<K, V>> result = this.entries;
/* 353:493 */       if (result == null) {
/* 354:494 */         this.entries = (result = MapConstraints.constrainedEntries(this.delegate.entries(), this.constraint));
/* 355:    */       }
/* 356:496 */       return result;
/* 357:    */     }
/* 358:    */     
/* 359:    */     public Collection<V> get(final K key)
/* 360:    */     {
/* 361:501 */       Constraints.constrainedTypePreservingCollection(this.delegate.get(key), new Constraint()
/* 362:    */       {
/* 363:    */         public V checkElement(V value)
/* 364:    */         {
/* 365:506 */           MapConstraints.ConstrainedMultimap.this.constraint.checkKeyValue(key, value);
/* 366:507 */           return value;
/* 367:    */         }
/* 368:    */       });
/* 369:    */     }
/* 370:    */     
/* 371:    */     public boolean put(K key, V value)
/* 372:    */     {
/* 373:514 */       this.constraint.checkKeyValue(key, value);
/* 374:515 */       return this.delegate.put(key, value);
/* 375:    */     }
/* 376:    */     
/* 377:    */     public boolean putAll(K key, Iterable<? extends V> values)
/* 378:    */     {
/* 379:520 */       return this.delegate.putAll(key, MapConstraints.checkValues(key, values, this.constraint));
/* 380:    */     }
/* 381:    */     
/* 382:    */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/* 383:    */     {
/* 384:525 */       boolean changed = false;
/* 385:526 */       for (Map.Entry<? extends K, ? extends V> entry : multimap.entries()) {
/* 386:527 */         changed |= put(entry.getKey(), entry.getValue());
/* 387:    */       }
/* 388:529 */       return changed;
/* 389:    */     }
/* 390:    */     
/* 391:    */     public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/* 392:    */     {
/* 393:534 */       return this.delegate.replaceValues(key, MapConstraints.checkValues(key, values, this.constraint));
/* 394:    */     }
/* 395:    */   }
/* 396:    */   
/* 397:    */   private static class ConstrainedAsMapValues<K, V>
/* 398:    */     extends ForwardingCollection<Collection<V>>
/* 399:    */   {
/* 400:    */     final Collection<Collection<V>> delegate;
/* 401:    */     final Set<Map.Entry<K, Collection<V>>> entrySet;
/* 402:    */     
/* 403:    */     ConstrainedAsMapValues(Collection<Collection<V>> delegate, Set<Map.Entry<K, Collection<V>>> entrySet)
/* 404:    */     {
/* 405:549 */       this.delegate = delegate;
/* 406:550 */       this.entrySet = entrySet;
/* 407:    */     }
/* 408:    */     
/* 409:    */     protected Collection<Collection<V>> delegate()
/* 410:    */     {
/* 411:555 */       return this.delegate;
/* 412:    */     }
/* 413:    */     
/* 414:    */     public Iterator<Collection<V>> iterator()
/* 415:    */     {
/* 416:560 */       final Iterator<Map.Entry<K, Collection<V>>> iterator = this.entrySet.iterator();
/* 417:561 */       new Iterator()
/* 418:    */       {
/* 419:    */         public boolean hasNext()
/* 420:    */         {
/* 421:564 */           return iterator.hasNext();
/* 422:    */         }
/* 423:    */         
/* 424:    */         public Collection<V> next()
/* 425:    */         {
/* 426:569 */           return (Collection)((Map.Entry)iterator.next()).getValue();
/* 427:    */         }
/* 428:    */         
/* 429:    */         public void remove()
/* 430:    */         {
/* 431:574 */           iterator.remove();
/* 432:    */         }
/* 433:    */       };
/* 434:    */     }
/* 435:    */     
/* 436:    */     public Object[] toArray()
/* 437:    */     {
/* 438:581 */       return standardToArray();
/* 439:    */     }
/* 440:    */     
/* 441:    */     public <T> T[] toArray(T[] array)
/* 442:    */     {
/* 443:586 */       return standardToArray(array);
/* 444:    */     }
/* 445:    */     
/* 446:    */     public boolean contains(Object o)
/* 447:    */     {
/* 448:591 */       return standardContains(o);
/* 449:    */     }
/* 450:    */     
/* 451:    */     public boolean containsAll(Collection<?> c)
/* 452:    */     {
/* 453:596 */       return standardContainsAll(c);
/* 454:    */     }
/* 455:    */     
/* 456:    */     public boolean remove(Object o)
/* 457:    */     {
/* 458:601 */       return standardRemove(o);
/* 459:    */     }
/* 460:    */     
/* 461:    */     public boolean removeAll(Collection<?> c)
/* 462:    */     {
/* 463:606 */       return standardRemoveAll(c);
/* 464:    */     }
/* 465:    */     
/* 466:    */     public boolean retainAll(Collection<?> c)
/* 467:    */     {
/* 468:611 */       return standardRetainAll(c);
/* 469:    */     }
/* 470:    */   }
/* 471:    */   
/* 472:    */   private static class ConstrainedEntries<K, V>
/* 473:    */     extends ForwardingCollection<Map.Entry<K, V>>
/* 474:    */   {
/* 475:    */     final MapConstraint<? super K, ? super V> constraint;
/* 476:    */     final Collection<Map.Entry<K, V>> entries;
/* 477:    */     
/* 478:    */     ConstrainedEntries(Collection<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/* 479:    */     {
/* 480:622 */       this.entries = entries;
/* 481:623 */       this.constraint = constraint;
/* 482:    */     }
/* 483:    */     
/* 484:    */     protected Collection<Map.Entry<K, V>> delegate()
/* 485:    */     {
/* 486:628 */       return this.entries;
/* 487:    */     }
/* 488:    */     
/* 489:    */     public Iterator<Map.Entry<K, V>> iterator()
/* 490:    */     {
/* 491:633 */       new TransformedIterator(this.entries.iterator())
/* 492:    */       {
/* 493:    */         Map.Entry<K, V> transform(Map.Entry<K, V> from)
/* 494:    */         {
/* 495:636 */           return MapConstraints.constrainedEntry(from, MapConstraints.ConstrainedEntries.this.constraint);
/* 496:    */         }
/* 497:    */       };
/* 498:    */     }
/* 499:    */     
/* 500:    */     public Object[] toArray()
/* 501:    */     {
/* 502:645 */       return standardToArray();
/* 503:    */     }
/* 504:    */     
/* 505:    */     public <T> T[] toArray(T[] array)
/* 506:    */     {
/* 507:650 */       return standardToArray(array);
/* 508:    */     }
/* 509:    */     
/* 510:    */     public boolean contains(Object o)
/* 511:    */     {
/* 512:655 */       return Maps.containsEntryImpl(delegate(), o);
/* 513:    */     }
/* 514:    */     
/* 515:    */     public boolean containsAll(Collection<?> c)
/* 516:    */     {
/* 517:660 */       return standardContainsAll(c);
/* 518:    */     }
/* 519:    */     
/* 520:    */     public boolean remove(Object o)
/* 521:    */     {
/* 522:665 */       return Maps.removeEntryImpl(delegate(), o);
/* 523:    */     }
/* 524:    */     
/* 525:    */     public boolean removeAll(Collection<?> c)
/* 526:    */     {
/* 527:670 */       return standardRemoveAll(c);
/* 528:    */     }
/* 529:    */     
/* 530:    */     public boolean retainAll(Collection<?> c)
/* 531:    */     {
/* 532:675 */       return standardRetainAll(c);
/* 533:    */     }
/* 534:    */   }
/* 535:    */   
/* 536:    */   static class ConstrainedEntrySet<K, V>
/* 537:    */     extends MapConstraints.ConstrainedEntries<K, V>
/* 538:    */     implements Set<Map.Entry<K, V>>
/* 539:    */   {
/* 540:    */     ConstrainedEntrySet(Set<Map.Entry<K, V>> entries, MapConstraint<? super K, ? super V> constraint)
/* 541:    */     {
/* 542:683 */       super(constraint);
/* 543:    */     }
/* 544:    */     
/* 545:    */     public boolean equals(@Nullable Object object)
/* 546:    */     {
/* 547:690 */       return Sets.equalsImpl(this, object);
/* 548:    */     }
/* 549:    */     
/* 550:    */     public int hashCode()
/* 551:    */     {
/* 552:695 */       return Sets.hashCodeImpl(this);
/* 553:    */     }
/* 554:    */   }
/* 555:    */   
/* 556:    */   static class ConstrainedAsMapEntries<K, V>
/* 557:    */     extends ForwardingSet<Map.Entry<K, Collection<V>>>
/* 558:    */   {
/* 559:    */     private final MapConstraint<? super K, ? super V> constraint;
/* 560:    */     private final Set<Map.Entry<K, Collection<V>>> entries;
/* 561:    */     
/* 562:    */     ConstrainedAsMapEntries(Set<Map.Entry<K, Collection<V>>> entries, MapConstraint<? super K, ? super V> constraint)
/* 563:    */     {
/* 564:706 */       this.entries = entries;
/* 565:707 */       this.constraint = constraint;
/* 566:    */     }
/* 567:    */     
/* 568:    */     protected Set<Map.Entry<K, Collection<V>>> delegate()
/* 569:    */     {
/* 570:712 */       return this.entries;
/* 571:    */     }
/* 572:    */     
/* 573:    */     public Iterator<Map.Entry<K, Collection<V>>> iterator()
/* 574:    */     {
/* 575:717 */       new TransformedIterator(this.entries.iterator())
/* 576:    */       {
/* 577:    */         Map.Entry<K, Collection<V>> transform(Map.Entry<K, Collection<V>> from)
/* 578:    */         {
/* 579:721 */           return MapConstraints.constrainedAsMapEntry(from, MapConstraints.ConstrainedAsMapEntries.this.constraint);
/* 580:    */         }
/* 581:    */       };
/* 582:    */     }
/* 583:    */     
/* 584:    */     public Object[] toArray()
/* 585:    */     {
/* 586:730 */       return standardToArray();
/* 587:    */     }
/* 588:    */     
/* 589:    */     public <T> T[] toArray(T[] array)
/* 590:    */     {
/* 591:735 */       return standardToArray(array);
/* 592:    */     }
/* 593:    */     
/* 594:    */     public boolean contains(Object o)
/* 595:    */     {
/* 596:740 */       return Maps.containsEntryImpl(delegate(), o);
/* 597:    */     }
/* 598:    */     
/* 599:    */     public boolean containsAll(Collection<?> c)
/* 600:    */     {
/* 601:745 */       return standardContainsAll(c);
/* 602:    */     }
/* 603:    */     
/* 604:    */     public boolean equals(@Nullable Object object)
/* 605:    */     {
/* 606:750 */       return standardEquals(object);
/* 607:    */     }
/* 608:    */     
/* 609:    */     public int hashCode()
/* 610:    */     {
/* 611:755 */       return standardHashCode();
/* 612:    */     }
/* 613:    */     
/* 614:    */     public boolean remove(Object o)
/* 615:    */     {
/* 616:760 */       return Maps.removeEntryImpl(delegate(), o);
/* 617:    */     }
/* 618:    */     
/* 619:    */     public boolean removeAll(Collection<?> c)
/* 620:    */     {
/* 621:765 */       return standardRemoveAll(c);
/* 622:    */     }
/* 623:    */     
/* 624:    */     public boolean retainAll(Collection<?> c)
/* 625:    */     {
/* 626:770 */       return standardRetainAll(c);
/* 627:    */     }
/* 628:    */   }
/* 629:    */   
/* 630:    */   private static class ConstrainedListMultimap<K, V>
/* 631:    */     extends MapConstraints.ConstrainedMultimap<K, V>
/* 632:    */     implements ListMultimap<K, V>
/* 633:    */   {
/* 634:    */     ConstrainedListMultimap(ListMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 635:    */     {
/* 636:778 */       super(constraint);
/* 637:    */     }
/* 638:    */     
/* 639:    */     public List<V> get(K key)
/* 640:    */     {
/* 641:783 */       return (List)super.get(key);
/* 642:    */     }
/* 643:    */     
/* 644:    */     public List<V> removeAll(Object key)
/* 645:    */     {
/* 646:788 */       return (List)super.removeAll(key);
/* 647:    */     }
/* 648:    */     
/* 649:    */     public List<V> replaceValues(K key, Iterable<? extends V> values)
/* 650:    */     {
/* 651:793 */       return (List)super.replaceValues(key, values);
/* 652:    */     }
/* 653:    */   }
/* 654:    */   
/* 655:    */   private static class ConstrainedSetMultimap<K, V>
/* 656:    */     extends MapConstraints.ConstrainedMultimap<K, V>
/* 657:    */     implements SetMultimap<K, V>
/* 658:    */   {
/* 659:    */     ConstrainedSetMultimap(SetMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 660:    */     {
/* 661:801 */       super(constraint);
/* 662:    */     }
/* 663:    */     
/* 664:    */     public Set<V> get(K key)
/* 665:    */     {
/* 666:806 */       return (Set)super.get(key);
/* 667:    */     }
/* 668:    */     
/* 669:    */     public Set<Map.Entry<K, V>> entries()
/* 670:    */     {
/* 671:811 */       return (Set)super.entries();
/* 672:    */     }
/* 673:    */     
/* 674:    */     public Set<V> removeAll(Object key)
/* 675:    */     {
/* 676:816 */       return (Set)super.removeAll(key);
/* 677:    */     }
/* 678:    */     
/* 679:    */     public Set<V> replaceValues(K key, Iterable<? extends V> values)
/* 680:    */     {
/* 681:821 */       return (Set)super.replaceValues(key, values);
/* 682:    */     }
/* 683:    */   }
/* 684:    */   
/* 685:    */   private static class ConstrainedSortedSetMultimap<K, V>
/* 686:    */     extends MapConstraints.ConstrainedSetMultimap<K, V>
/* 687:    */     implements SortedSetMultimap<K, V>
/* 688:    */   {
/* 689:    */     ConstrainedSortedSetMultimap(SortedSetMultimap<K, V> delegate, MapConstraint<? super K, ? super V> constraint)
/* 690:    */     {
/* 691:829 */       super(constraint);
/* 692:    */     }
/* 693:    */     
/* 694:    */     public SortedSet<V> get(K key)
/* 695:    */     {
/* 696:834 */       return (SortedSet)super.get(key);
/* 697:    */     }
/* 698:    */     
/* 699:    */     public SortedSet<V> removeAll(Object key)
/* 700:    */     {
/* 701:839 */       return (SortedSet)super.removeAll(key);
/* 702:    */     }
/* 703:    */     
/* 704:    */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values)
/* 705:    */     {
/* 706:844 */       return (SortedSet)super.replaceValues(key, values);
/* 707:    */     }
/* 708:    */     
/* 709:    */     public Comparator<? super V> valueComparator()
/* 710:    */     {
/* 711:849 */       return ((SortedSetMultimap)delegate()).valueComparator();
/* 712:    */     }
/* 713:    */   }
/* 714:    */   
/* 715:    */   private static <K, V> Collection<V> checkValues(K key, Iterable<? extends V> values, MapConstraint<? super K, ? super V> constraint)
/* 716:    */   {
/* 717:855 */     Collection<V> copy = Lists.newArrayList(values);
/* 718:856 */     for (V value : copy) {
/* 719:857 */       constraint.checkKeyValue(key, value);
/* 720:    */     }
/* 721:859 */     return copy;
/* 722:    */   }
/* 723:    */   
/* 724:    */   private static <K, V> Map<K, V> checkMap(Map<? extends K, ? extends V> map, MapConstraint<? super K, ? super V> constraint)
/* 725:    */   {
/* 726:864 */     Map<K, V> copy = new LinkedHashMap(map);
/* 727:865 */     for (Map.Entry<K, V> entry : copy.entrySet()) {
/* 728:866 */       constraint.checkKeyValue(entry.getKey(), entry.getValue());
/* 729:    */     }
/* 730:868 */     return copy;
/* 731:    */   }
/* 732:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.MapConstraints
 * JD-Core Version:    0.7.0.1
 */