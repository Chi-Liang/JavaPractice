/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import javax.annotation.Nullable;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public class ComputationException
/*  8:   */   extends RuntimeException
/*  9:   */ {
/* 10:   */   private static final long serialVersionUID = 0L;
/* 11:   */   
/* 12:   */   public ComputationException(@Nullable Throwable cause)
/* 13:   */   {
/* 14:35 */     super(cause);
/* 15:   */   }
/* 16:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ComputationException
 * JD-Core Version:    0.7.0.1
 */