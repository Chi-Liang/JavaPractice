/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.MoreObjects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Map;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ public abstract class ImmutableTable<R, C, V>
/*  14:    */   extends AbstractTable<R, C, V>
/*  15:    */ {
/*  16: 45 */   private static final ImmutableTable<Object, Object, Object> EMPTY = new SparseImmutableTable(ImmutableList.of(), ImmutableSet.of(), ImmutableSet.of());
/*  17:    */   
/*  18:    */   public static <R, C, V> ImmutableTable<R, C, V> of()
/*  19:    */   {
/*  20: 54 */     return EMPTY;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static <R, C, V> ImmutableTable<R, C, V> of(R rowKey, C columnKey, V value)
/*  24:    */   {
/*  25: 59 */     return new SingletonImmutableTable(rowKey, columnKey, value);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <R, C, V> ImmutableTable<R, C, V> copyOf(Table<? extends R, ? extends C, ? extends V> table)
/*  29:    */   {
/*  30: 78 */     if ((table instanceof ImmutableTable))
/*  31:    */     {
/*  32: 80 */       ImmutableTable<R, C, V> parameterizedTable = (ImmutableTable)table;
/*  33: 81 */       return parameterizedTable;
/*  34:    */     }
/*  35: 83 */     int size = table.size();
/*  36: 84 */     switch (size)
/*  37:    */     {
/*  38:    */     case 0: 
/*  39: 86 */       return of();
/*  40:    */     case 1: 
/*  41: 88 */       Table.Cell<? extends R, ? extends C, ? extends V> onlyCell = (Table.Cell)Iterables.getOnlyElement(table.cellSet());
/*  42:    */       
/*  43: 90 */       return of(onlyCell.getRowKey(), onlyCell.getColumnKey(), onlyCell.getValue());
/*  44:    */     }
/*  45: 93 */     ImmutableSet.Builder<Table.Cell<R, C, V>> cellSetBuilder = new ImmutableSet.Builder(size);
/*  46: 95 */     for (Table.Cell<? extends R, ? extends C, ? extends V> cell : table.cellSet()) {
/*  47:100 */       cellSetBuilder.add(cellOf(cell.getRowKey(), cell.getColumnKey(), cell.getValue()));
/*  48:    */     }
/*  49:103 */     return RegularImmutableTable.forCells(cellSetBuilder.build());
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static <R, C, V> Builder<R, C, V> builder()
/*  53:    */   {
/*  54:113 */     return new Builder();
/*  55:    */   }
/*  56:    */   
/*  57:    */   static <R, C, V> Table.Cell<R, C, V> cellOf(R rowKey, C columnKey, V value)
/*  58:    */   {
/*  59:121 */     return Tables.immutableCell(Preconditions.checkNotNull(rowKey), Preconditions.checkNotNull(columnKey), Preconditions.checkNotNull(value));
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static final class Builder<R, C, V>
/*  63:    */   {
/*  64:151 */     private final List<Table.Cell<R, C, V>> cells = Lists.newArrayList();
/*  65:    */     private Comparator<? super R> rowComparator;
/*  66:    */     private Comparator<? super C> columnComparator;
/*  67:    */     
/*  68:    */     public Builder<R, C, V> orderRowsBy(Comparator<? super R> rowComparator)
/*  69:    */     {
/*  70:165 */       this.rowComparator = ((Comparator)Preconditions.checkNotNull(rowComparator));
/*  71:166 */       return this;
/*  72:    */     }
/*  73:    */     
/*  74:    */     public Builder<R, C, V> orderColumnsBy(Comparator<? super C> columnComparator)
/*  75:    */     {
/*  76:173 */       this.columnComparator = ((Comparator)Preconditions.checkNotNull(columnComparator));
/*  77:174 */       return this;
/*  78:    */     }
/*  79:    */     
/*  80:    */     public Builder<R, C, V> put(R rowKey, C columnKey, V value)
/*  81:    */     {
/*  82:183 */       this.cells.add(ImmutableTable.cellOf(rowKey, columnKey, value));
/*  83:184 */       return this;
/*  84:    */     }
/*  85:    */     
/*  86:    */     public Builder<R, C, V> put(Table.Cell<? extends R, ? extends C, ? extends V> cell)
/*  87:    */     {
/*  88:193 */       if ((cell instanceof Tables.ImmutableCell))
/*  89:    */       {
/*  90:194 */         Preconditions.checkNotNull(cell.getRowKey());
/*  91:195 */         Preconditions.checkNotNull(cell.getColumnKey());
/*  92:196 */         Preconditions.checkNotNull(cell.getValue());
/*  93:    */         
/*  94:198 */         Table.Cell<R, C, V> immutableCell = cell;
/*  95:199 */         this.cells.add(immutableCell);
/*  96:    */       }
/*  97:    */       else
/*  98:    */       {
/*  99:201 */         put(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
/* 100:    */       }
/* 101:203 */       return this;
/* 102:    */     }
/* 103:    */     
/* 104:    */     public Builder<R, C, V> putAll(Table<? extends R, ? extends C, ? extends V> table)
/* 105:    */     {
/* 106:214 */       for (Table.Cell<? extends R, ? extends C, ? extends V> cell : table.cellSet()) {
/* 107:215 */         put(cell);
/* 108:    */       }
/* 109:217 */       return this;
/* 110:    */     }
/* 111:    */     
/* 112:    */     public ImmutableTable<R, C, V> build()
/* 113:    */     {
/* 114:226 */       int size = this.cells.size();
/* 115:227 */       switch (size)
/* 116:    */       {
/* 117:    */       case 0: 
/* 118:229 */         return ImmutableTable.of();
/* 119:    */       case 1: 
/* 120:231 */         return new SingletonImmutableTable((Table.Cell)Iterables.getOnlyElement(this.cells));
/* 121:    */       }
/* 122:233 */       return RegularImmutableTable.forCells(this.cells, this.rowComparator, this.columnComparator);
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   public ImmutableSet<Table.Cell<R, C, V>> cellSet()
/* 127:    */   {
/* 128:242 */     return (ImmutableSet)super.cellSet();
/* 129:    */   }
/* 130:    */   
/* 131:    */   abstract ImmutableSet<Table.Cell<R, C, V>> createCellSet();
/* 132:    */   
/* 133:    */   final UnmodifiableIterator<Table.Cell<R, C, V>> cellIterator()
/* 134:    */   {
/* 135:250 */     throw new AssertionError("should never be called");
/* 136:    */   }
/* 137:    */   
/* 138:    */   public ImmutableCollection<V> values()
/* 139:    */   {
/* 140:255 */     return (ImmutableCollection)super.values();
/* 141:    */   }
/* 142:    */   
/* 143:    */   abstract ImmutableCollection<V> createValues();
/* 144:    */   
/* 145:    */   final Iterator<V> valuesIterator()
/* 146:    */   {
/* 147:263 */     throw new AssertionError("should never be called");
/* 148:    */   }
/* 149:    */   
/* 150:    */   public ImmutableMap<R, V> column(C columnKey)
/* 151:    */   {
/* 152:273 */     Preconditions.checkNotNull(columnKey);
/* 153:274 */     return (ImmutableMap)MoreObjects.firstNonNull((ImmutableMap)columnMap().get(columnKey), ImmutableMap.of());
/* 154:    */   }
/* 155:    */   
/* 156:    */   public ImmutableSet<C> columnKeySet()
/* 157:    */   {
/* 158:281 */     return columnMap().keySet();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public abstract ImmutableMap<C, Map<R, V>> columnMap();
/* 162:    */   
/* 163:    */   public ImmutableMap<C, V> row(R rowKey)
/* 164:    */   {
/* 165:300 */     Preconditions.checkNotNull(rowKey);
/* 166:301 */     return (ImmutableMap)MoreObjects.firstNonNull((ImmutableMap)rowMap().get(rowKey), ImmutableMap.of());
/* 167:    */   }
/* 168:    */   
/* 169:    */   public ImmutableSet<R> rowKeySet()
/* 170:    */   {
/* 171:308 */     return rowMap().keySet();
/* 172:    */   }
/* 173:    */   
/* 174:    */   public abstract ImmutableMap<R, Map<C, V>> rowMap();
/* 175:    */   
/* 176:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/* 177:    */   {
/* 178:322 */     return get(rowKey, columnKey) != null;
/* 179:    */   }
/* 180:    */   
/* 181:    */   public boolean containsValue(@Nullable Object value)
/* 182:    */   {
/* 183:327 */     return values().contains(value);
/* 184:    */   }
/* 185:    */   
/* 186:    */   @Deprecated
/* 187:    */   public final void clear()
/* 188:    */   {
/* 189:339 */     throw new UnsupportedOperationException();
/* 190:    */   }
/* 191:    */   
/* 192:    */   @Deprecated
/* 193:    */   public final V put(R rowKey, C columnKey, V value)
/* 194:    */   {
/* 195:351 */     throw new UnsupportedOperationException();
/* 196:    */   }
/* 197:    */   
/* 198:    */   @Deprecated
/* 199:    */   public final void putAll(Table<? extends R, ? extends C, ? extends V> table)
/* 200:    */   {
/* 201:363 */     throw new UnsupportedOperationException();
/* 202:    */   }
/* 203:    */   
/* 204:    */   @Deprecated
/* 205:    */   public final V remove(Object rowKey, Object columnKey)
/* 206:    */   {
/* 207:375 */     throw new UnsupportedOperationException();
/* 208:    */   }
/* 209:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableTable
 * JD-Core Version:    0.7.0.1
 */