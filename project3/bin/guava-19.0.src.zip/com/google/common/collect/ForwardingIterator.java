/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Iterator;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public abstract class ForwardingIterator<T>
/*  8:   */   extends ForwardingObject
/*  9:   */   implements Iterator<T>
/* 10:   */ {
/* 11:   */   protected abstract Iterator<T> delegate();
/* 12:   */   
/* 13:   */   public boolean hasNext()
/* 14:   */   {
/* 15:43 */     return delegate().hasNext();
/* 16:   */   }
/* 17:   */   
/* 18:   */   public T next()
/* 19:   */   {
/* 20:48 */     return delegate().next();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public void remove()
/* 24:   */   {
/* 25:53 */     delegate().remove();
/* 26:   */   }
/* 27:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingIterator
 * JD-Core Version:    0.7.0.1
 */