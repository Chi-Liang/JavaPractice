/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Iterator;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public abstract class UnmodifiableIterator<E>
/*  8:   */   implements Iterator<E>
/*  9:   */ {
/* 10:   */   @Deprecated
/* 11:   */   public final void remove()
/* 12:   */   {
/* 13:47 */     throw new UnsupportedOperationException();
/* 14:   */   }
/* 15:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.UnmodifiableIterator
 * JD-Core Version:    0.7.0.1
 */