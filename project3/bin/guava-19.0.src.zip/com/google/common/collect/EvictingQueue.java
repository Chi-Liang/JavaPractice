/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Queue;
/*  10:    */ 
/*  11:    */ @Beta
/*  12:    */ @GwtCompatible
/*  13:    */ public final class EvictingQueue<E>
/*  14:    */   extends ForwardingQueue<E>
/*  15:    */   implements Serializable
/*  16:    */ {
/*  17:    */   private final Queue<E> delegate;
/*  18:    */   @VisibleForTesting
/*  19:    */   final int maxSize;
/*  20:    */   private static final long serialVersionUID = 0L;
/*  21:    */   
/*  22:    */   private EvictingQueue(int maxSize)
/*  23:    */   {
/*  24: 53 */     Preconditions.checkArgument(maxSize >= 0, "maxSize (%s) must >= 0", new Object[] { Integer.valueOf(maxSize) });
/*  25: 54 */     this.delegate = Platform.newFastestQueue(maxSize);
/*  26: 55 */     this.maxSize = maxSize;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static <E> EvictingQueue<E> create(int maxSize)
/*  30:    */   {
/*  31: 65 */     return new EvictingQueue(maxSize);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public int remainingCapacity()
/*  35:    */   {
/*  36: 75 */     return this.maxSize - size();
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected Queue<E> delegate()
/*  40:    */   {
/*  41: 80 */     return this.delegate;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public boolean offer(E e)
/*  45:    */   {
/*  46: 91 */     return add(e);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean add(E e)
/*  50:    */   {
/*  51:102 */     Preconditions.checkNotNull(e);
/*  52:103 */     if (this.maxSize == 0) {
/*  53:104 */       return true;
/*  54:    */     }
/*  55:106 */     if (size() == this.maxSize) {
/*  56:107 */       this.delegate.remove();
/*  57:    */     }
/*  58:109 */     this.delegate.add(e);
/*  59:110 */     return true;
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean addAll(Collection<? extends E> collection)
/*  63:    */   {
/*  64:115 */     return standardAddAll(collection);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean contains(Object object)
/*  68:    */   {
/*  69:120 */     return delegate().contains(Preconditions.checkNotNull(object));
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean remove(Object object)
/*  73:    */   {
/*  74:125 */     return delegate().remove(Preconditions.checkNotNull(object));
/*  75:    */   }
/*  76:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.EvictingQueue
 * JD-Core Version:    0.7.0.1
 */