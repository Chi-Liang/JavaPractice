/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.primitives.Ints;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.NoSuchElementException;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ public final class ImmutableRangeSet<C extends Comparable>
/*  14:    */   extends AbstractRangeSet<C>
/*  15:    */   implements Serializable
/*  16:    */ {
/*  17: 47 */   private static final ImmutableRangeSet<Comparable<?>> EMPTY = new ImmutableRangeSet(ImmutableList.of());
/*  18: 50 */   private static final ImmutableRangeSet<Comparable<?>> ALL = new ImmutableRangeSet(ImmutableList.of(Range.all()));
/*  19:    */   private final transient ImmutableList<Range<C>> ranges;
/*  20:    */   private transient ImmutableRangeSet<C> complement;
/*  21:    */   
/*  22:    */   public static <C extends Comparable> ImmutableRangeSet<C> of()
/*  23:    */   {
/*  24: 58 */     return EMPTY;
/*  25:    */   }
/*  26:    */   
/*  27:    */   static <C extends Comparable> ImmutableRangeSet<C> all()
/*  28:    */   {
/*  29: 66 */     return ALL;
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static <C extends Comparable> ImmutableRangeSet<C> of(Range<C> range)
/*  33:    */   {
/*  34: 74 */     Preconditions.checkNotNull(range);
/*  35: 75 */     if (range.isEmpty()) {
/*  36: 76 */       return of();
/*  37:    */     }
/*  38: 77 */     if (range.equals(Range.all())) {
/*  39: 78 */       return all();
/*  40:    */     }
/*  41: 80 */     return new ImmutableRangeSet(ImmutableList.of(range));
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <C extends Comparable> ImmutableRangeSet<C> copyOf(RangeSet<C> rangeSet)
/*  45:    */   {
/*  46: 88 */     Preconditions.checkNotNull(rangeSet);
/*  47: 89 */     if (rangeSet.isEmpty()) {
/*  48: 90 */       return of();
/*  49:    */     }
/*  50: 91 */     if (rangeSet.encloses(Range.all())) {
/*  51: 92 */       return all();
/*  52:    */     }
/*  53: 95 */     if ((rangeSet instanceof ImmutableRangeSet))
/*  54:    */     {
/*  55: 96 */       ImmutableRangeSet<C> immutableRangeSet = (ImmutableRangeSet)rangeSet;
/*  56: 97 */       if (!immutableRangeSet.isPartialView()) {
/*  57: 98 */         return immutableRangeSet;
/*  58:    */       }
/*  59:    */     }
/*  60:101 */     return new ImmutableRangeSet(ImmutableList.copyOf(rangeSet.asRanges()));
/*  61:    */   }
/*  62:    */   
/*  63:    */   ImmutableRangeSet(ImmutableList<Range<C>> ranges)
/*  64:    */   {
/*  65:105 */     this.ranges = ranges;
/*  66:    */   }
/*  67:    */   
/*  68:    */   private ImmutableRangeSet(ImmutableList<Range<C>> ranges, ImmutableRangeSet<C> complement)
/*  69:    */   {
/*  70:109 */     this.ranges = ranges;
/*  71:110 */     this.complement = complement;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public boolean encloses(Range<C> otherRange)
/*  75:    */   {
/*  76:117 */     int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), otherRange.lowerBound, Ordering.natural(), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_LOWER);
/*  77:    */     
/*  78:    */ 
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:125 */     return (index != -1) && (((Range)this.ranges.get(index)).encloses(otherRange));
/*  85:    */   }
/*  86:    */   
/*  87:    */   public Range<C> rangeContaining(C value)
/*  88:    */   {
/*  89:130 */     int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(value), Ordering.natural(), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_LOWER);
/*  90:138 */     if (index != -1)
/*  91:    */     {
/*  92:139 */       Range<C> range = (Range)this.ranges.get(index);
/*  93:140 */       return range.contains(value) ? range : null;
/*  94:    */     }
/*  95:142 */     return null;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public Range<C> span()
/*  99:    */   {
/* 100:147 */     if (this.ranges.isEmpty()) {
/* 101:148 */       throw new NoSuchElementException();
/* 102:    */     }
/* 103:150 */     return Range.create(((Range)this.ranges.get(0)).lowerBound, ((Range)this.ranges.get(this.ranges.size() - 1)).upperBound);
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean isEmpty()
/* 107:    */   {
/* 108:155 */     return this.ranges.isEmpty();
/* 109:    */   }
/* 110:    */   
/* 111:    */   public void add(Range<C> range)
/* 112:    */   {
/* 113:160 */     throw new UnsupportedOperationException();
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void addAll(RangeSet<C> other)
/* 117:    */   {
/* 118:165 */     throw new UnsupportedOperationException();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void remove(Range<C> range)
/* 122:    */   {
/* 123:170 */     throw new UnsupportedOperationException();
/* 124:    */   }
/* 125:    */   
/* 126:    */   public void removeAll(RangeSet<C> other)
/* 127:    */   {
/* 128:175 */     throw new UnsupportedOperationException();
/* 129:    */   }
/* 130:    */   
/* 131:    */   public ImmutableSet<Range<C>> asRanges()
/* 132:    */   {
/* 133:180 */     if (this.ranges.isEmpty()) {
/* 134:181 */       return ImmutableSet.of();
/* 135:    */     }
/* 136:183 */     return new RegularImmutableSortedSet(this.ranges, Range.RANGE_LEX_ORDERING);
/* 137:    */   }
/* 138:    */   
/* 139:    */   public ImmutableSet<Range<C>> asDescendingSetOfRanges()
/* 140:    */   {
/* 141:188 */     if (this.ranges.isEmpty()) {
/* 142:189 */       return ImmutableSet.of();
/* 143:    */     }
/* 144:191 */     return new RegularImmutableSortedSet(this.ranges.reverse(), Range.RANGE_LEX_ORDERING.reverse());
/* 145:    */   }
/* 146:    */   
/* 147:    */   private final class ComplementRanges
/* 148:    */     extends ImmutableList<Range<C>>
/* 149:    */   {
/* 150:    */     private final boolean positiveBoundedBelow;
/* 151:    */     private final boolean positiveBoundedAbove;
/* 152:    */     private final int size;
/* 153:    */     
/* 154:    */     ComplementRanges()
/* 155:    */     {
/* 156:207 */       this.positiveBoundedBelow = ((Range)ImmutableRangeSet.this.ranges.get(0)).hasLowerBound();
/* 157:208 */       this.positiveBoundedAbove = ((Range)Iterables.getLast(ImmutableRangeSet.this.ranges)).hasUpperBound();
/* 158:    */       
/* 159:210 */       int size = ImmutableRangeSet.this.ranges.size() - 1;
/* 160:211 */       if (this.positiveBoundedBelow) {
/* 161:212 */         size++;
/* 162:    */       }
/* 163:214 */       if (this.positiveBoundedAbove) {
/* 164:215 */         size++;
/* 165:    */       }
/* 166:217 */       this.size = size;
/* 167:    */     }
/* 168:    */     
/* 169:    */     public int size()
/* 170:    */     {
/* 171:222 */       return this.size;
/* 172:    */     }
/* 173:    */     
/* 174:    */     public Range<C> get(int index)
/* 175:    */     {
/* 176:227 */       Preconditions.checkElementIndex(index, this.size);
/* 177:    */       Cut<C> lowerBound;
/* 178:    */       Cut<C> lowerBound;
/* 179:230 */       if (this.positiveBoundedBelow) {
/* 180:231 */         lowerBound = index == 0 ? Cut.belowAll() : ((Range)ImmutableRangeSet.this.ranges.get(index - 1)).upperBound;
/* 181:    */       } else {
/* 182:233 */         lowerBound = ((Range)ImmutableRangeSet.this.ranges.get(index)).upperBound;
/* 183:    */       }
/* 184:    */       Cut<C> upperBound;
/* 185:    */       Cut<C> upperBound;
/* 186:237 */       if ((this.positiveBoundedAbove) && (index == this.size - 1)) {
/* 187:238 */         upperBound = Cut.aboveAll();
/* 188:    */       } else {
/* 189:240 */         upperBound = ((Range)ImmutableRangeSet.this.ranges.get(index + (this.positiveBoundedBelow ? 0 : 1))).lowerBound;
/* 190:    */       }
/* 191:243 */       return Range.create(lowerBound, upperBound);
/* 192:    */     }
/* 193:    */     
/* 194:    */     boolean isPartialView()
/* 195:    */     {
/* 196:248 */       return true;
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   public ImmutableRangeSet<C> complement()
/* 201:    */   {
/* 202:254 */     ImmutableRangeSet<C> result = this.complement;
/* 203:255 */     if (result != null) {
/* 204:256 */       return result;
/* 205:    */     }
/* 206:257 */     if (this.ranges.isEmpty()) {
/* 207:258 */       return this.complement = all();
/* 208:    */     }
/* 209:259 */     if ((this.ranges.size() == 1) && (((Range)this.ranges.get(0)).equals(Range.all()))) {
/* 210:260 */       return this.complement = of();
/* 211:    */     }
/* 212:262 */     ImmutableList<Range<C>> complementRanges = new ComplementRanges();
/* 213:263 */     result = this.complement = new ImmutableRangeSet(complementRanges, this);
/* 214:    */     
/* 215:265 */     return result;
/* 216:    */   }
/* 217:    */   
/* 218:    */   private ImmutableList<Range<C>> intersectRanges(final Range<C> range)
/* 219:    */   {
/* 220:273 */     if ((this.ranges.isEmpty()) || (range.isEmpty())) {
/* 221:274 */       return ImmutableList.of();
/* 222:    */     }
/* 223:275 */     if (range.encloses(span())) {
/* 224:276 */       return this.ranges;
/* 225:    */     }
/* 226:    */     int fromIndex;
/* 227:    */     final int fromIndex;
/* 228:280 */     if (range.hasLowerBound()) {
/* 229:281 */       fromIndex = SortedLists.binarySearch(this.ranges, Range.upperBoundFn(), range.lowerBound, SortedLists.KeyPresentBehavior.FIRST_AFTER, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 230:    */     } else {
/* 231:289 */       fromIndex = 0;
/* 232:    */     }
/* 233:    */     int toIndex;
/* 234:    */     int toIndex;
/* 235:293 */     if (range.hasUpperBound()) {
/* 236:294 */       toIndex = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), range.upperBound, SortedLists.KeyPresentBehavior.FIRST_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 237:    */     } else {
/* 238:302 */       toIndex = this.ranges.size();
/* 239:    */     }
/* 240:304 */     final int length = toIndex - fromIndex;
/* 241:305 */     if (length == 0) {
/* 242:306 */       return ImmutableList.of();
/* 243:    */     }
/* 244:308 */     new ImmutableList()
/* 245:    */     {
/* 246:    */       public int size()
/* 247:    */       {
/* 248:311 */         return length;
/* 249:    */       }
/* 250:    */       
/* 251:    */       public Range<C> get(int index)
/* 252:    */       {
/* 253:316 */         Preconditions.checkElementIndex(index, length);
/* 254:317 */         if ((index == 0) || (index == length - 1)) {
/* 255:318 */           return ((Range)ImmutableRangeSet.this.ranges.get(index + fromIndex)).intersection(range);
/* 256:    */         }
/* 257:320 */         return (Range)ImmutableRangeSet.this.ranges.get(index + fromIndex);
/* 258:    */       }
/* 259:    */       
/* 260:    */       boolean isPartialView()
/* 261:    */       {
/* 262:326 */         return true;
/* 263:    */       }
/* 264:    */     };
/* 265:    */   }
/* 266:    */   
/* 267:    */   public ImmutableRangeSet<C> subRangeSet(Range<C> range)
/* 268:    */   {
/* 269:337 */     if (!isEmpty())
/* 270:    */     {
/* 271:338 */       Range<C> span = span();
/* 272:339 */       if (range.encloses(span)) {
/* 273:340 */         return this;
/* 274:    */       }
/* 275:341 */       if (range.isConnected(span)) {
/* 276:342 */         return new ImmutableRangeSet(intersectRanges(range));
/* 277:    */       }
/* 278:    */     }
/* 279:345 */     return of();
/* 280:    */   }
/* 281:    */   
/* 282:    */   public ImmutableSortedSet<C> asSet(DiscreteDomain<C> domain)
/* 283:    */   {
/* 284:368 */     Preconditions.checkNotNull(domain);
/* 285:369 */     if (isEmpty()) {
/* 286:370 */       return ImmutableSortedSet.of();
/* 287:    */     }
/* 288:372 */     Range<C> span = span().canonical(domain);
/* 289:373 */     if (!span.hasLowerBound()) {
/* 290:376 */       throw new IllegalArgumentException("Neither the DiscreteDomain nor this range set are bounded below");
/* 291:    */     }
/* 292:378 */     if (!span.hasUpperBound()) {
/* 293:    */       try
/* 294:    */       {
/* 295:380 */         domain.maxValue();
/* 296:    */       }
/* 297:    */       catch (NoSuchElementException e)
/* 298:    */       {
/* 299:382 */         throw new IllegalArgumentException("Neither the DiscreteDomain nor this range set are bounded above");
/* 300:    */       }
/* 301:    */     }
/* 302:387 */     return new AsSet(domain);
/* 303:    */   }
/* 304:    */   
/* 305:    */   private final class AsSet
/* 306:    */     extends ImmutableSortedSet<C>
/* 307:    */   {
/* 308:    */     private final DiscreteDomain<C> domain;
/* 309:    */     private transient Integer size;
/* 310:    */     
/* 311:    */     AsSet()
/* 312:    */     {
/* 313:394 */       super();
/* 314:395 */       this.domain = domain;
/* 315:    */     }
/* 316:    */     
/* 317:    */     public int size()
/* 318:    */     {
/* 319:403 */       Integer result = this.size;
/* 320:404 */       if (result == null)
/* 321:    */       {
/* 322:405 */         long total = 0L;
/* 323:406 */         for (Range<C> range : ImmutableRangeSet.this.ranges)
/* 324:    */         {
/* 325:407 */           total += ContiguousSet.create(range, this.domain).size();
/* 326:408 */           if (total >= 2147483647L) {
/* 327:    */             break;
/* 328:    */           }
/* 329:    */         }
/* 330:412 */         result = this.size = Integer.valueOf(Ints.saturatedCast(total));
/* 331:    */       }
/* 332:414 */       return result.intValue();
/* 333:    */     }
/* 334:    */     
/* 335:    */     public UnmodifiableIterator<C> iterator()
/* 336:    */     {
/* 337:419 */       new AbstractIterator()
/* 338:    */       {
/* 339:420 */         final Iterator<Range<C>> rangeItr = ImmutableRangeSet.this.ranges.iterator();
/* 340:421 */         Iterator<C> elemItr = Iterators.emptyIterator();
/* 341:    */         
/* 342:    */         protected C computeNext()
/* 343:    */         {
/* 344:425 */           while (!this.elemItr.hasNext()) {
/* 345:426 */             if (this.rangeItr.hasNext()) {
/* 346:427 */               this.elemItr = ContiguousSet.create((Range)this.rangeItr.next(), ImmutableRangeSet.AsSet.this.domain).iterator();
/* 347:    */             } else {
/* 348:429 */               return (Comparable)endOfData();
/* 349:    */             }
/* 350:    */           }
/* 351:432 */           return (Comparable)this.elemItr.next();
/* 352:    */         }
/* 353:    */       };
/* 354:    */     }
/* 355:    */     
/* 356:    */     @GwtIncompatible("NavigableSet")
/* 357:    */     public UnmodifiableIterator<C> descendingIterator()
/* 358:    */     {
/* 359:440 */       new AbstractIterator()
/* 360:    */       {
/* 361:441 */         final Iterator<Range<C>> rangeItr = ImmutableRangeSet.this.ranges.reverse().iterator();
/* 362:442 */         Iterator<C> elemItr = Iterators.emptyIterator();
/* 363:    */         
/* 364:    */         protected C computeNext()
/* 365:    */         {
/* 366:446 */           while (!this.elemItr.hasNext()) {
/* 367:447 */             if (this.rangeItr.hasNext()) {
/* 368:448 */               this.elemItr = ContiguousSet.create((Range)this.rangeItr.next(), ImmutableRangeSet.AsSet.this.domain).descendingIterator();
/* 369:    */             } else {
/* 370:450 */               return (Comparable)endOfData();
/* 371:    */             }
/* 372:    */           }
/* 373:453 */           return (Comparable)this.elemItr.next();
/* 374:    */         }
/* 375:    */       };
/* 376:    */     }
/* 377:    */     
/* 378:    */     ImmutableSortedSet<C> subSet(Range<C> range)
/* 379:    */     {
/* 380:459 */       return ImmutableRangeSet.this.subRangeSet(range).asSet(this.domain);
/* 381:    */     }
/* 382:    */     
/* 383:    */     ImmutableSortedSet<C> headSetImpl(C toElement, boolean inclusive)
/* 384:    */     {
/* 385:464 */       return subSet(Range.upTo(toElement, BoundType.forBoolean(inclusive)));
/* 386:    */     }
/* 387:    */     
/* 388:    */     ImmutableSortedSet<C> subSetImpl(C fromElement, boolean fromInclusive, C toElement, boolean toInclusive)
/* 389:    */     {
/* 390:470 */       if ((!fromInclusive) && (!toInclusive) && (Range.compareOrThrow(fromElement, toElement) == 0)) {
/* 391:471 */         return ImmutableSortedSet.of();
/* 392:    */       }
/* 393:473 */       return subSet(Range.range(fromElement, BoundType.forBoolean(fromInclusive), toElement, BoundType.forBoolean(toInclusive)));
/* 394:    */     }
/* 395:    */     
/* 396:    */     ImmutableSortedSet<C> tailSetImpl(C fromElement, boolean inclusive)
/* 397:    */     {
/* 398:481 */       return subSet(Range.downTo(fromElement, BoundType.forBoolean(inclusive)));
/* 399:    */     }
/* 400:    */     
/* 401:    */     public boolean contains(@Nullable Object o)
/* 402:    */     {
/* 403:486 */       if (o == null) {
/* 404:487 */         return false;
/* 405:    */       }
/* 406:    */       try
/* 407:    */       {
/* 408:491 */         C c = (Comparable)o;
/* 409:492 */         return ImmutableRangeSet.this.contains(c);
/* 410:    */       }
/* 411:    */       catch (ClassCastException e) {}
/* 412:494 */       return false;
/* 413:    */     }
/* 414:    */     
/* 415:    */     int indexOf(Object target)
/* 416:    */     {
/* 417:500 */       if (contains(target))
/* 418:    */       {
/* 419:502 */         C c = (Comparable)target;
/* 420:503 */         long total = 0L;
/* 421:504 */         for (Range<C> range : ImmutableRangeSet.this.ranges)
/* 422:    */         {
/* 423:505 */           if (range.contains(c)) {
/* 424:506 */             return Ints.saturatedCast(total + ContiguousSet.create(range, this.domain).indexOf(c));
/* 425:    */           }
/* 426:508 */           total += ContiguousSet.create(range, this.domain).size();
/* 427:    */         }
/* 428:511 */         throw new AssertionError("impossible");
/* 429:    */       }
/* 430:513 */       return -1;
/* 431:    */     }
/* 432:    */     
/* 433:    */     boolean isPartialView()
/* 434:    */     {
/* 435:518 */       return ImmutableRangeSet.this.ranges.isPartialView();
/* 436:    */     }
/* 437:    */     
/* 438:    */     public String toString()
/* 439:    */     {
/* 440:523 */       return ImmutableRangeSet.this.ranges.toString();
/* 441:    */     }
/* 442:    */     
/* 443:    */     Object writeReplace()
/* 444:    */     {
/* 445:528 */       return new ImmutableRangeSet.AsSetSerializedForm(ImmutableRangeSet.this.ranges, this.domain);
/* 446:    */     }
/* 447:    */   }
/* 448:    */   
/* 449:    */   private static class AsSetSerializedForm<C extends Comparable>
/* 450:    */     implements Serializable
/* 451:    */   {
/* 452:    */     private final ImmutableList<Range<C>> ranges;
/* 453:    */     private final DiscreteDomain<C> domain;
/* 454:    */     
/* 455:    */     AsSetSerializedForm(ImmutableList<Range<C>> ranges, DiscreteDomain<C> domain)
/* 456:    */     {
/* 457:537 */       this.ranges = ranges;
/* 458:538 */       this.domain = domain;
/* 459:    */     }
/* 460:    */     
/* 461:    */     Object readResolve()
/* 462:    */     {
/* 463:542 */       return new ImmutableRangeSet(this.ranges).asSet(this.domain);
/* 464:    */     }
/* 465:    */   }
/* 466:    */   
/* 467:    */   boolean isPartialView()
/* 468:    */   {
/* 469:553 */     return this.ranges.isPartialView();
/* 470:    */   }
/* 471:    */   
/* 472:    */   public static <C extends Comparable<?>> Builder<C> builder()
/* 473:    */   {
/* 474:560 */     return new Builder();
/* 475:    */   }
/* 476:    */   
/* 477:    */   public static class Builder<C extends Comparable<?>>
/* 478:    */   {
/* 479:    */     private final RangeSet<C> rangeSet;
/* 480:    */     
/* 481:    */     public Builder()
/* 482:    */     {
/* 483:570 */       this.rangeSet = TreeRangeSet.create();
/* 484:    */     }
/* 485:    */     
/* 486:    */     public Builder<C> add(Range<C> range)
/* 487:    */     {
/* 488:581 */       if (range.isEmpty()) {
/* 489:582 */         throw new IllegalArgumentException("range must not be empty, but was " + range);
/* 490:    */       }
/* 491:583 */       if (!this.rangeSet.complement().encloses(range))
/* 492:    */       {
/* 493:584 */         for (Range<C> currentRange : this.rangeSet.asRanges()) {
/* 494:585 */           Preconditions.checkArgument((!currentRange.isConnected(range)) || (currentRange.intersection(range).isEmpty()), "Ranges may not overlap, but received %s and %s", new Object[] { currentRange, range });
/* 495:    */         }
/* 496:591 */         throw new AssertionError("should have thrown an IAE above");
/* 497:    */       }
/* 498:593 */       this.rangeSet.add(range);
/* 499:594 */       return this;
/* 500:    */     }
/* 501:    */     
/* 502:    */     public Builder<C> addAll(RangeSet<C> ranges)
/* 503:    */     {
/* 504:602 */       for (Range<C> range : ranges.asRanges()) {
/* 505:603 */         add(range);
/* 506:    */       }
/* 507:605 */       return this;
/* 508:    */     }
/* 509:    */     
/* 510:    */     public ImmutableRangeSet<C> build()
/* 511:    */     {
/* 512:612 */       return ImmutableRangeSet.copyOf(this.rangeSet);
/* 513:    */     }
/* 514:    */   }
/* 515:    */   
/* 516:    */   private static final class SerializedForm<C extends Comparable>
/* 517:    */     implements Serializable
/* 518:    */   {
/* 519:    */     private final ImmutableList<Range<C>> ranges;
/* 520:    */     
/* 521:    */     SerializedForm(ImmutableList<Range<C>> ranges)
/* 522:    */     {
/* 523:620 */       this.ranges = ranges;
/* 524:    */     }
/* 525:    */     
/* 526:    */     Object readResolve()
/* 527:    */     {
/* 528:624 */       if (this.ranges.isEmpty()) {
/* 529:625 */         return ImmutableRangeSet.of();
/* 530:    */       }
/* 531:626 */       if (this.ranges.equals(ImmutableList.of(Range.all()))) {
/* 532:627 */         return ImmutableRangeSet.all();
/* 533:    */       }
/* 534:629 */       return new ImmutableRangeSet(this.ranges);
/* 535:    */     }
/* 536:    */   }
/* 537:    */   
/* 538:    */   Object writeReplace()
/* 539:    */   {
/* 540:635 */     return new SerializedForm(this.ranges);
/* 541:    */   }
/* 542:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableRangeSet
 * JD-Core Version:    0.7.0.1
 */