/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Predicate;
/*  5:   */ import java.util.Map.Entry;
/*  6:   */ import java.util.Set;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ final class FilteredEntrySetMultimap<K, V>
/* 10:   */   extends FilteredEntryMultimap<K, V>
/* 11:   */   implements FilteredSetMultimap<K, V>
/* 12:   */ {
/* 13:   */   FilteredEntrySetMultimap(SetMultimap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> predicate)
/* 14:   */   {
/* 15:35 */     super(unfiltered, predicate);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public SetMultimap<K, V> unfiltered()
/* 19:   */   {
/* 20:40 */     return (SetMultimap)this.unfiltered;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Set<V> get(K key)
/* 24:   */   {
/* 25:45 */     return (Set)super.get(key);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public Set<V> removeAll(Object key)
/* 29:   */   {
/* 30:50 */     return (Set)super.removeAll(key);
/* 31:   */   }
/* 32:   */   
/* 33:   */   public Set<V> replaceValues(K key, Iterable<? extends V> values)
/* 34:   */   {
/* 35:55 */     return (Set)super.replaceValues(key, values);
/* 36:   */   }
/* 37:   */   
/* 38:   */   Set<Map.Entry<K, V>> createEntries()
/* 39:   */   {
/* 40:60 */     return Sets.filter(unfiltered().entries(), entryPredicate());
/* 41:   */   }
/* 42:   */   
/* 43:   */   public Set<Map.Entry<K, V>> entries()
/* 44:   */   {
/* 45:65 */     return (Set)super.entries();
/* 46:   */   }
/* 47:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.FilteredEntrySetMultimap
 * JD-Core Version:    0.7.0.1
 */