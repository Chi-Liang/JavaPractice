/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.AbstractCollection;
/*   7:    */ import java.util.Collection;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible(emulated=true)
/*  12:    */ public abstract class ImmutableCollection<E>
/*  13:    */   extends AbstractCollection<E>
/*  14:    */   implements Serializable
/*  15:    */ {
/*  16:    */   private transient ImmutableList<E> asList;
/*  17:    */   
/*  18:    */   public abstract UnmodifiableIterator<E> iterator();
/*  19:    */   
/*  20:    */   public final Object[] toArray()
/*  21:    */   {
/*  22:167 */     int size = size();
/*  23:168 */     if (size == 0) {
/*  24:169 */       return ObjectArrays.EMPTY_ARRAY;
/*  25:    */     }
/*  26:171 */     Object[] result = new Object[size];
/*  27:172 */     copyIntoArray(result, 0);
/*  28:173 */     return result;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public final <T> T[] toArray(T[] other)
/*  32:    */   {
/*  33:178 */     Preconditions.checkNotNull(other);
/*  34:179 */     int size = size();
/*  35:180 */     if (other.length < size) {
/*  36:181 */       other = ObjectArrays.newArray(other, size);
/*  37:182 */     } else if (other.length > size) {
/*  38:183 */       other[size] = null;
/*  39:    */     }
/*  40:185 */     copyIntoArray(other, 0);
/*  41:186 */     return other;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public abstract boolean contains(@Nullable Object paramObject);
/*  45:    */   
/*  46:    */   @Deprecated
/*  47:    */   public final boolean add(E e)
/*  48:    */   {
/*  49:201 */     throw new UnsupportedOperationException();
/*  50:    */   }
/*  51:    */   
/*  52:    */   @Deprecated
/*  53:    */   public final boolean remove(Object object)
/*  54:    */   {
/*  55:213 */     throw new UnsupportedOperationException();
/*  56:    */   }
/*  57:    */   
/*  58:    */   @Deprecated
/*  59:    */   public final boolean addAll(Collection<? extends E> newElements)
/*  60:    */   {
/*  61:225 */     throw new UnsupportedOperationException();
/*  62:    */   }
/*  63:    */   
/*  64:    */   @Deprecated
/*  65:    */   public final boolean removeAll(Collection<?> oldElements)
/*  66:    */   {
/*  67:237 */     throw new UnsupportedOperationException();
/*  68:    */   }
/*  69:    */   
/*  70:    */   @Deprecated
/*  71:    */   public final boolean retainAll(Collection<?> elementsToKeep)
/*  72:    */   {
/*  73:249 */     throw new UnsupportedOperationException();
/*  74:    */   }
/*  75:    */   
/*  76:    */   @Deprecated
/*  77:    */   public final void clear()
/*  78:    */   {
/*  79:261 */     throw new UnsupportedOperationException();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public ImmutableList<E> asList()
/*  83:    */   {
/*  84:281 */     ImmutableList<E> list = this.asList;
/*  85:282 */     return list == null ? (this.asList = createAsList()) : list;
/*  86:    */   }
/*  87:    */   
/*  88:    */   ImmutableList<E> createAsList()
/*  89:    */   {
/*  90:286 */     switch (size())
/*  91:    */     {
/*  92:    */     case 0: 
/*  93:288 */       return ImmutableList.of();
/*  94:    */     case 1: 
/*  95:290 */       return ImmutableList.of(iterator().next());
/*  96:    */     }
/*  97:292 */     return new RegularImmutableAsList(this, toArray());
/*  98:    */   }
/*  99:    */   
/* 100:    */   abstract boolean isPartialView();
/* 101:    */   
/* 102:    */   int copyIntoArray(Object[] dst, int offset)
/* 103:    */   {
/* 104:309 */     for (E e : this) {
/* 105:310 */       dst[(offset++)] = e;
/* 106:    */     }
/* 107:312 */     return offset;
/* 108:    */   }
/* 109:    */   
/* 110:    */   Object writeReplace()
/* 111:    */   {
/* 112:317 */     return new ImmutableList.SerializedForm(toArray());
/* 113:    */   }
/* 114:    */   
/* 115:    */   public static abstract class Builder<E>
/* 116:    */   {
/* 117:    */     static final int DEFAULT_INITIAL_CAPACITY = 4;
/* 118:    */     
/* 119:    */     static int expandedCapacity(int oldCapacity, int minCapacity)
/* 120:    */     {
/* 121:329 */       if (minCapacity < 0) {
/* 122:330 */         throw new AssertionError("cannot store more than MAX_VALUE elements");
/* 123:    */       }
/* 124:333 */       int newCapacity = oldCapacity + (oldCapacity >> 1) + 1;
/* 125:334 */       if (newCapacity < minCapacity) {
/* 126:335 */         newCapacity = Integer.highestOneBit(minCapacity - 1) << 1;
/* 127:    */       }
/* 128:337 */       if (newCapacity < 0) {
/* 129:338 */         newCapacity = 2147483647;
/* 130:    */       }
/* 131:341 */       return newCapacity;
/* 132:    */     }
/* 133:    */     
/* 134:    */     public abstract Builder<E> add(E paramE);
/* 135:    */     
/* 136:    */     public Builder<E> add(E... elements)
/* 137:    */     {
/* 138:371 */       for (E element : elements) {
/* 139:372 */         add(element);
/* 140:    */       }
/* 141:374 */       return this;
/* 142:    */     }
/* 143:    */     
/* 144:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 145:    */     {
/* 146:390 */       for (E element : elements) {
/* 147:391 */         add(element);
/* 148:    */       }
/* 149:393 */       return this;
/* 150:    */     }
/* 151:    */     
/* 152:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 153:    */     {
/* 154:409 */       while (elements.hasNext()) {
/* 155:410 */         add(elements.next());
/* 156:    */       }
/* 157:412 */       return this;
/* 158:    */     }
/* 159:    */     
/* 160:    */     public abstract ImmutableCollection<E> build();
/* 161:    */   }
/* 162:    */   
/* 163:    */   static abstract class ArrayBasedBuilder<E>
/* 164:    */     extends ImmutableCollection.Builder<E>
/* 165:    */   {
/* 166:    */     Object[] contents;
/* 167:    */     int size;
/* 168:    */     
/* 169:    */     ArrayBasedBuilder(int initialCapacity)
/* 170:    */     {
/* 171:430 */       CollectPreconditions.checkNonnegative(initialCapacity, "initialCapacity");
/* 172:431 */       this.contents = new Object[initialCapacity];
/* 173:432 */       this.size = 0;
/* 174:    */     }
/* 175:    */     
/* 176:    */     private void ensureCapacity(int minCapacity)
/* 177:    */     {
/* 178:440 */       if (this.contents.length < minCapacity) {
/* 179:441 */         this.contents = ObjectArrays.arraysCopyOf(this.contents, expandedCapacity(this.contents.length, minCapacity));
/* 180:    */       }
/* 181:    */     }
/* 182:    */     
/* 183:    */     public ArrayBasedBuilder<E> add(E element)
/* 184:    */     {
/* 185:449 */       Preconditions.checkNotNull(element);
/* 186:450 */       ensureCapacity(this.size + 1);
/* 187:451 */       this.contents[(this.size++)] = element;
/* 188:452 */       return this;
/* 189:    */     }
/* 190:    */     
/* 191:    */     public ImmutableCollection.Builder<E> add(E... elements)
/* 192:    */     {
/* 193:457 */       ObjectArrays.checkElementsNotNull(elements);
/* 194:458 */       ensureCapacity(this.size + elements.length);
/* 195:459 */       System.arraycopy(elements, 0, this.contents, this.size, elements.length);
/* 196:460 */       this.size += elements.length;
/* 197:461 */       return this;
/* 198:    */     }
/* 199:    */     
/* 200:    */     public ImmutableCollection.Builder<E> addAll(Iterable<? extends E> elements)
/* 201:    */     {
/* 202:466 */       if ((elements instanceof Collection))
/* 203:    */       {
/* 204:467 */         Collection<?> collection = (Collection)elements;
/* 205:468 */         ensureCapacity(this.size + collection.size());
/* 206:    */       }
/* 207:470 */       super.addAll(elements);
/* 208:471 */       return this;
/* 209:    */     }
/* 210:    */   }
/* 211:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableCollection
 * JD-Core Version:    0.7.0.1
 */