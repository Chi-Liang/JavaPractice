/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ 
/*  6:   */ @GwtCompatible(serializable=true)
/*  7:   */ final class UsingToStringOrdering
/*  8:   */   extends Ordering<Object>
/*  9:   */   implements Serializable
/* 10:   */ {
/* 11:29 */   static final UsingToStringOrdering INSTANCE = new UsingToStringOrdering();
/* 12:   */   private static final long serialVersionUID = 0L;
/* 13:   */   
/* 14:   */   public int compare(Object left, Object right)
/* 15:   */   {
/* 16:33 */     return left.toString().compareTo(right.toString());
/* 17:   */   }
/* 18:   */   
/* 19:   */   private Object readResolve()
/* 20:   */   {
/* 21:38 */     return INSTANCE;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public String toString()
/* 25:   */   {
/* 26:43 */     return "Ordering.usingToString()";
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.UsingToStringOrdering
 * JD-Core Version:    0.7.0.1
 */