/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Function;
/*   7:    */ import com.google.common.base.Joiner;
/*   8:    */ import com.google.common.base.Optional;
/*   9:    */ import com.google.common.base.Preconditions;
/*  10:    */ import com.google.common.base.Predicate;
/*  11:    */ import java.util.Arrays;
/*  12:    */ import java.util.Collection;
/*  13:    */ import java.util.Comparator;
/*  14:    */ import java.util.Iterator;
/*  15:    */ import java.util.List;
/*  16:    */ import java.util.SortedSet;
/*  17:    */ import javax.annotation.CheckReturnValue;
/*  18:    */ import javax.annotation.Nullable;
/*  19:    */ 
/*  20:    */ @GwtCompatible(emulated=true)
/*  21:    */ public abstract class FluentIterable<E>
/*  22:    */   implements Iterable<E>
/*  23:    */ {
/*  24:    */   private final Iterable<E> iterable;
/*  25:    */   
/*  26:    */   protected FluentIterable()
/*  27:    */   {
/*  28:118 */     this.iterable = this;
/*  29:    */   }
/*  30:    */   
/*  31:    */   FluentIterable(Iterable<E> iterable)
/*  32:    */   {
/*  33:122 */     this.iterable = ((Iterable)Preconditions.checkNotNull(iterable));
/*  34:    */   }
/*  35:    */   
/*  36:    */   @CheckReturnValue
/*  37:    */   public static <E> FluentIterable<E> from(final Iterable<E> iterable)
/*  38:    */   {
/*  39:134 */     (iterable instanceof FluentIterable) ? (FluentIterable)iterable : new FluentIterable(iterable)
/*  40:    */     {
/*  41:    */       public Iterator<E> iterator()
/*  42:    */       {
/*  43:139 */         return iterable.iterator();
/*  44:    */       }
/*  45:    */     };
/*  46:    */   }
/*  47:    */   
/*  48:    */   @Deprecated
/*  49:    */   @CheckReturnValue
/*  50:    */   public static <E> FluentIterable<E> from(FluentIterable<E> iterable)
/*  51:    */   {
/*  52:155 */     return (FluentIterable)Preconditions.checkNotNull(iterable);
/*  53:    */   }
/*  54:    */   
/*  55:    */   @CheckReturnValue
/*  56:    */   @Beta
/*  57:    */   public static <E> FluentIterable<E> of(E[] elements)
/*  58:    */   {
/*  59:169 */     return from(Lists.newArrayList(elements));
/*  60:    */   }
/*  61:    */   
/*  62:    */   @CheckReturnValue
/*  63:    */   public String toString()
/*  64:    */   {
/*  65:182 */     return Iterables.toString(this.iterable);
/*  66:    */   }
/*  67:    */   
/*  68:    */   @CheckReturnValue
/*  69:    */   public final int size()
/*  70:    */   {
/*  71:192 */     return Iterables.size(this.iterable);
/*  72:    */   }
/*  73:    */   
/*  74:    */   @CheckReturnValue
/*  75:    */   public final boolean contains(@Nullable Object target)
/*  76:    */   {
/*  77:203 */     return Iterables.contains(this.iterable, target);
/*  78:    */   }
/*  79:    */   
/*  80:    */   @CheckReturnValue
/*  81:    */   public final FluentIterable<E> cycle()
/*  82:    */   {
/*  83:226 */     return from(Iterables.cycle(this.iterable));
/*  84:    */   }
/*  85:    */   
/*  86:    */   @CheckReturnValue
/*  87:    */   @Beta
/*  88:    */   public final FluentIterable<E> append(Iterable<? extends E> other)
/*  89:    */   {
/*  90:243 */     return from(Iterables.concat(this.iterable, other));
/*  91:    */   }
/*  92:    */   
/*  93:    */   @CheckReturnValue
/*  94:    */   @Beta
/*  95:    */   public final FluentIterable<E> append(E... elements)
/*  96:    */   {
/*  97:257 */     return from(Iterables.concat(this.iterable, Arrays.asList(elements)));
/*  98:    */   }
/*  99:    */   
/* 100:    */   @CheckReturnValue
/* 101:    */   public final FluentIterable<E> filter(Predicate<? super E> predicate)
/* 102:    */   {
/* 103:268 */     return from(Iterables.filter(this.iterable, predicate));
/* 104:    */   }
/* 105:    */   
/* 106:    */   @CheckReturnValue
/* 107:    */   @GwtIncompatible("Class.isInstance")
/* 108:    */   public final <T> FluentIterable<T> filter(Class<T> type)
/* 109:    */   {
/* 110:289 */     return from(Iterables.filter(this.iterable, type));
/* 111:    */   }
/* 112:    */   
/* 113:    */   @CheckReturnValue
/* 114:    */   public final boolean anyMatch(Predicate<? super E> predicate)
/* 115:    */   {
/* 116:299 */     return Iterables.any(this.iterable, predicate);
/* 117:    */   }
/* 118:    */   
/* 119:    */   @CheckReturnValue
/* 120:    */   public final boolean allMatch(Predicate<? super E> predicate)
/* 121:    */   {
/* 122:310 */     return Iterables.all(this.iterable, predicate);
/* 123:    */   }
/* 124:    */   
/* 125:    */   @CheckReturnValue
/* 126:    */   public final Optional<E> firstMatch(Predicate<? super E> predicate)
/* 127:    */   {
/* 128:324 */     return Iterables.tryFind(this.iterable, predicate);
/* 129:    */   }
/* 130:    */   
/* 131:    */   @CheckReturnValue
/* 132:    */   public final <T> FluentIterable<T> transform(Function<? super E, T> function)
/* 133:    */   {
/* 134:339 */     return from(Iterables.transform(this.iterable, function));
/* 135:    */   }
/* 136:    */   
/* 137:    */   @CheckReturnValue
/* 138:    */   public <T> FluentIterable<T> transformAndConcat(Function<? super E, ? extends Iterable<? extends T>> function)
/* 139:    */   {
/* 140:359 */     return from(Iterables.concat(transform(function)));
/* 141:    */   }
/* 142:    */   
/* 143:    */   @CheckReturnValue
/* 144:    */   public final Optional<E> first()
/* 145:    */   {
/* 146:375 */     Iterator<E> iterator = this.iterable.iterator();
/* 147:376 */     return iterator.hasNext() ? Optional.of(iterator.next()) : Optional.absent();
/* 148:    */   }
/* 149:    */   
/* 150:    */   @CheckReturnValue
/* 151:    */   public final Optional<E> last()
/* 152:    */   {
/* 153:393 */     if ((this.iterable instanceof List))
/* 154:    */     {
/* 155:394 */       List<E> list = (List)this.iterable;
/* 156:395 */       if (list.isEmpty()) {
/* 157:396 */         return Optional.absent();
/* 158:    */       }
/* 159:398 */       return Optional.of(list.get(list.size() - 1));
/* 160:    */     }
/* 161:400 */     Iterator<E> iterator = this.iterable.iterator();
/* 162:401 */     if (!iterator.hasNext()) {
/* 163:402 */       return Optional.absent();
/* 164:    */     }
/* 165:410 */     if ((this.iterable instanceof SortedSet))
/* 166:    */     {
/* 167:411 */       SortedSet<E> sortedSet = (SortedSet)this.iterable;
/* 168:412 */       return Optional.of(sortedSet.last());
/* 169:    */     }
/* 170:    */     for (;;)
/* 171:    */     {
/* 172:416 */       E current = iterator.next();
/* 173:417 */       if (!iterator.hasNext()) {
/* 174:418 */         return Optional.of(current);
/* 175:    */       }
/* 176:    */     }
/* 177:    */   }
/* 178:    */   
/* 179:    */   @CheckReturnValue
/* 180:    */   public final FluentIterable<E> skip(int numberToSkip)
/* 181:    */   {
/* 182:444 */     return from(Iterables.skip(this.iterable, numberToSkip));
/* 183:    */   }
/* 184:    */   
/* 185:    */   @CheckReturnValue
/* 186:    */   public final FluentIterable<E> limit(int maxSize)
/* 187:    */   {
/* 188:461 */     return from(Iterables.limit(this.iterable, maxSize));
/* 189:    */   }
/* 190:    */   
/* 191:    */   @CheckReturnValue
/* 192:    */   public final boolean isEmpty()
/* 193:    */   {
/* 194:471 */     return !this.iterable.iterator().hasNext();
/* 195:    */   }
/* 196:    */   
/* 197:    */   @CheckReturnValue
/* 198:    */   public final ImmutableList<E> toList()
/* 199:    */   {
/* 200:484 */     return ImmutableList.copyOf(this.iterable);
/* 201:    */   }
/* 202:    */   
/* 203:    */   @CheckReturnValue
/* 204:    */   public final ImmutableList<E> toSortedList(Comparator<? super E> comparator)
/* 205:    */   {
/* 206:501 */     return Ordering.from(comparator).immutableSortedCopy(this.iterable);
/* 207:    */   }
/* 208:    */   
/* 209:    */   @CheckReturnValue
/* 210:    */   public final ImmutableSet<E> toSet()
/* 211:    */   {
/* 212:514 */     return ImmutableSet.copyOf(this.iterable);
/* 213:    */   }
/* 214:    */   
/* 215:    */   @CheckReturnValue
/* 216:    */   public final ImmutableSortedSet<E> toSortedSet(Comparator<? super E> comparator)
/* 217:    */   {
/* 218:532 */     return ImmutableSortedSet.copyOf(comparator, this.iterable);
/* 219:    */   }
/* 220:    */   
/* 221:    */   @CheckReturnValue
/* 222:    */   public final ImmutableMultiset<E> toMultiset()
/* 223:    */   {
/* 224:544 */     return ImmutableMultiset.copyOf(this.iterable);
/* 225:    */   }
/* 226:    */   
/* 227:    */   @CheckReturnValue
/* 228:    */   public final <V> ImmutableMap<E, V> toMap(Function<? super E, V> valueFunction)
/* 229:    */   {
/* 230:566 */     return Maps.toMap(this.iterable, valueFunction);
/* 231:    */   }
/* 232:    */   
/* 233:    */   @CheckReturnValue
/* 234:    */   public final <K> ImmutableListMultimap<K, E> index(Function<? super E, K> keyFunction)
/* 235:    */   {
/* 236:594 */     return Multimaps.index(this.iterable, keyFunction);
/* 237:    */   }
/* 238:    */   
/* 239:    */   @CheckReturnValue
/* 240:    */   public final <K> ImmutableMap<K, E> uniqueIndex(Function<? super E, K> keyFunction)
/* 241:    */   {
/* 242:629 */     return Maps.uniqueIndex(this.iterable, keyFunction);
/* 243:    */   }
/* 244:    */   
/* 245:    */   @CheckReturnValue
/* 246:    */   @GwtIncompatible("Array.newArray(Class, int)")
/* 247:    */   public final E[] toArray(Class<E> type)
/* 248:    */   {
/* 249:647 */     return Iterables.toArray(this.iterable, type);
/* 250:    */   }
/* 251:    */   
/* 252:    */   public final <C extends Collection<? super E>> C copyInto(C collection)
/* 253:    */   {
/* 254:662 */     Preconditions.checkNotNull(collection);
/* 255:663 */     if ((this.iterable instanceof Collection)) {
/* 256:664 */       collection.addAll(Collections2.cast(this.iterable));
/* 257:    */     } else {
/* 258:666 */       for (E item : this.iterable) {
/* 259:667 */         collection.add(item);
/* 260:    */       }
/* 261:    */     }
/* 262:670 */     return collection;
/* 263:    */   }
/* 264:    */   
/* 265:    */   @CheckReturnValue
/* 266:    */   @Beta
/* 267:    */   public final String join(Joiner joiner)
/* 268:    */   {
/* 269:686 */     return joiner.join(this);
/* 270:    */   }
/* 271:    */   
/* 272:    */   @CheckReturnValue
/* 273:    */   public final E get(int position)
/* 274:    */   {
/* 275:704 */     return Iterables.get(this.iterable, position);
/* 276:    */   }
/* 277:    */   
/* 278:    */   private static class FromIterableFunction<E>
/* 279:    */     implements Function<Iterable<E>, FluentIterable<E>>
/* 280:    */   {
/* 281:    */     public FluentIterable<E> apply(Iterable<E> fromObject)
/* 282:    */     {
/* 283:713 */       return FluentIterable.from(fromObject);
/* 284:    */     }
/* 285:    */   }
/* 286:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.FluentIterable
 * JD-Core Version:    0.7.0.1
 */