/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import java.io.InvalidObjectException;
/*  6:   */ import java.io.ObjectInputStream;
/*  7:   */ import java.io.Serializable;
/*  8:   */ 
/*  9:   */ @GwtCompatible(serializable=true, emulated=true)
/* 10:   */ abstract class ImmutableAsList<E>
/* 11:   */   extends ImmutableList<E>
/* 12:   */ {
/* 13:   */   abstract ImmutableCollection<E> delegateCollection();
/* 14:   */   
/* 15:   */   public boolean contains(Object target)
/* 16:   */   {
/* 17:42 */     return delegateCollection().contains(target);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int size()
/* 21:   */   {
/* 22:47 */     return delegateCollection().size();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public boolean isEmpty()
/* 26:   */   {
/* 27:52 */     return delegateCollection().isEmpty();
/* 28:   */   }
/* 29:   */   
/* 30:   */   boolean isPartialView()
/* 31:   */   {
/* 32:57 */     return delegateCollection().isPartialView();
/* 33:   */   }
/* 34:   */   
/* 35:   */   @GwtIncompatible("serialization")
/* 36:   */   static class SerializedForm
/* 37:   */     implements Serializable
/* 38:   */   {
/* 39:   */     final ImmutableCollection<?> collection;
/* 40:   */     private static final long serialVersionUID = 0L;
/* 41:   */     
/* 42:   */     SerializedForm(ImmutableCollection<?> collection)
/* 43:   */     {
/* 44:68 */       this.collection = collection;
/* 45:   */     }
/* 46:   */     
/* 47:   */     Object readResolve()
/* 48:   */     {
/* 49:72 */       return this.collection.asList();
/* 50:   */     }
/* 51:   */   }
/* 52:   */   
/* 53:   */   @GwtIncompatible("serialization")
/* 54:   */   private void readObject(ObjectInputStream stream)
/* 55:   */     throws InvalidObjectException
/* 56:   */   {
/* 57:80 */     throw new InvalidObjectException("Use SerializedForm");
/* 58:   */   }
/* 59:   */   
/* 60:   */   @GwtIncompatible("serialization")
/* 61:   */   Object writeReplace()
/* 62:   */   {
/* 63:86 */     return new SerializedForm(delegateCollection());
/* 64:   */   }
/* 65:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableAsList
 * JD-Core Version:    0.7.0.1
 */