/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ 
/*  6:   */ @GwtCompatible(serializable=true, emulated=true)
/*  7:   */ final class SingletonImmutableSet<E>
/*  8:   */   extends ImmutableSet<E>
/*  9:   */ {
/* 10:   */   final transient E element;
/* 11:   */   private transient int cachedHashCode;
/* 12:   */   
/* 13:   */   SingletonImmutableSet(E element)
/* 14:   */   {
/* 15:43 */     this.element = Preconditions.checkNotNull(element);
/* 16:   */   }
/* 17:   */   
/* 18:   */   SingletonImmutableSet(E element, int hashCode)
/* 19:   */   {
/* 20:48 */     this.element = element;
/* 21:49 */     this.cachedHashCode = hashCode;
/* 22:   */   }
/* 23:   */   
/* 24:   */   public int size()
/* 25:   */   {
/* 26:54 */     return 1;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public boolean contains(Object target)
/* 30:   */   {
/* 31:59 */     return this.element.equals(target);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public UnmodifiableIterator<E> iterator()
/* 35:   */   {
/* 36:64 */     return Iterators.singletonIterator(this.element);
/* 37:   */   }
/* 38:   */   
/* 39:   */   boolean isPartialView()
/* 40:   */   {
/* 41:69 */     return false;
/* 42:   */   }
/* 43:   */   
/* 44:   */   int copyIntoArray(Object[] dst, int offset)
/* 45:   */   {
/* 46:74 */     dst[offset] = this.element;
/* 47:75 */     return offset + 1;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public final int hashCode()
/* 51:   */   {
/* 52:81 */     int code = this.cachedHashCode;
/* 53:82 */     if (code == 0) {
/* 54:83 */       this.cachedHashCode = (code = this.element.hashCode());
/* 55:   */     }
/* 56:85 */     return code;
/* 57:   */   }
/* 58:   */   
/* 59:   */   boolean isHashCodeFast()
/* 60:   */   {
/* 61:90 */     return this.cachedHashCode != 0;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public String toString()
/* 65:   */   {
/* 66:95 */     String elementToString = this.element.toString();
/* 67:96 */     return elementToString.length() + 2 + '[' + elementToString + ']';
/* 68:   */   }
/* 69:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.SingletonImmutableSet
 * JD-Core Version:    0.7.0.1
 */