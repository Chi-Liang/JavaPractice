/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ import java.util.NoSuchElementException;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ @GwtIncompatible("NavigableMap")
/*  14:    */ public class ImmutableRangeMap<K extends Comparable<?>, V>
/*  15:    */   implements RangeMap<K, V>, Serializable
/*  16:    */ {
/*  17: 44 */   private static final ImmutableRangeMap<Comparable<?>, Object> EMPTY = new ImmutableRangeMap(ImmutableList.of(), ImmutableList.of());
/*  18:    */   private final transient ImmutableList<Range<K>> ranges;
/*  19:    */   private final transient ImmutableList<V> values;
/*  20:    */   private static final long serialVersionUID = 0L;
/*  21:    */   
/*  22:    */   public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> of()
/*  23:    */   {
/*  24: 53 */     return EMPTY;
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> of(Range<K> range, V value)
/*  28:    */   {
/*  29: 60 */     return new ImmutableRangeMap(ImmutableList.of(range), ImmutableList.of(value));
/*  30:    */   }
/*  31:    */   
/*  32:    */   public static <K extends Comparable<?>, V> ImmutableRangeMap<K, V> copyOf(RangeMap<K, ? extends V> rangeMap)
/*  33:    */   {
/*  34: 66 */     if ((rangeMap instanceof ImmutableRangeMap)) {
/*  35: 67 */       return (ImmutableRangeMap)rangeMap;
/*  36:    */     }
/*  37: 69 */     Map<Range<K>, ? extends V> map = rangeMap.asMapOfRanges();
/*  38: 70 */     ImmutableList.Builder<Range<K>> rangesBuilder = new ImmutableList.Builder(map.size());
/*  39: 71 */     ImmutableList.Builder<V> valuesBuilder = new ImmutableList.Builder(map.size());
/*  40: 72 */     for (Map.Entry<Range<K>, ? extends V> entry : map.entrySet())
/*  41:    */     {
/*  42: 73 */       rangesBuilder.add(entry.getKey());
/*  43: 74 */       valuesBuilder.add(entry.getValue());
/*  44:    */     }
/*  45: 76 */     return new ImmutableRangeMap(rangesBuilder.build(), valuesBuilder.build());
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static <K extends Comparable<?>, V> Builder<K, V> builder()
/*  49:    */   {
/*  50: 83 */     return new Builder();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static final class Builder<K extends Comparable<?>, V>
/*  54:    */   {
/*  55:    */     private final RangeSet<K> keyRanges;
/*  56:    */     private final RangeMap<K, V> rangeMap;
/*  57:    */     
/*  58:    */     public Builder()
/*  59:    */     {
/*  60: 94 */       this.keyRanges = TreeRangeSet.create();
/*  61: 95 */       this.rangeMap = TreeRangeMap.create();
/*  62:    */     }
/*  63:    */     
/*  64:    */     public Builder<K, V> put(Range<K> range, V value)
/*  65:    */     {
/*  66:105 */       Preconditions.checkNotNull(range);
/*  67:106 */       Preconditions.checkNotNull(value);
/*  68:107 */       Preconditions.checkArgument(!range.isEmpty(), "Range must not be empty, but was %s", new Object[] { range });
/*  69:108 */       if (!this.keyRanges.complement().encloses(range)) {
/*  70:110 */         for (Map.Entry<Range<K>, V> entry : this.rangeMap.asMapOfRanges().entrySet())
/*  71:    */         {
/*  72:111 */           Range<K> key = (Range)entry.getKey();
/*  73:112 */           if ((key.isConnected(range)) && (!key.intersection(range).isEmpty())) {
/*  74:113 */             throw new IllegalArgumentException("Overlapping ranges: range " + range + " overlaps with entry " + entry);
/*  75:    */           }
/*  76:    */         }
/*  77:    */       }
/*  78:118 */       this.keyRanges.add(range);
/*  79:119 */       this.rangeMap.put(range, value);
/*  80:120 */       return this;
/*  81:    */     }
/*  82:    */     
/*  83:    */     public Builder<K, V> putAll(RangeMap<K, ? extends V> rangeMap)
/*  84:    */     {
/*  85:130 */       for (Map.Entry<Range<K>, ? extends V> entry : rangeMap.asMapOfRanges().entrySet()) {
/*  86:131 */         put((Range)entry.getKey(), entry.getValue());
/*  87:    */       }
/*  88:133 */       return this;
/*  89:    */     }
/*  90:    */     
/*  91:    */     public ImmutableRangeMap<K, V> build()
/*  92:    */     {
/*  93:141 */       Map<Range<K>, V> map = this.rangeMap.asMapOfRanges();
/*  94:142 */       ImmutableList.Builder<Range<K>> rangesBuilder = new ImmutableList.Builder(map.size());
/*  95:    */       
/*  96:144 */       ImmutableList.Builder<V> valuesBuilder = new ImmutableList.Builder(map.size());
/*  97:145 */       for (Map.Entry<Range<K>, V> entry : map.entrySet())
/*  98:    */       {
/*  99:146 */         rangesBuilder.add(entry.getKey());
/* 100:147 */         valuesBuilder.add(entry.getValue());
/* 101:    */       }
/* 102:149 */       return new ImmutableRangeMap(rangesBuilder.build(), valuesBuilder.build());
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   ImmutableRangeMap(ImmutableList<Range<K>> ranges, ImmutableList<V> values)
/* 107:    */   {
/* 108:157 */     this.ranges = ranges;
/* 109:158 */     this.values = values;
/* 110:    */   }
/* 111:    */   
/* 112:    */   @Nullable
/* 113:    */   public V get(K key)
/* 114:    */   {
/* 115:164 */     int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(key), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_LOWER);
/* 116:171 */     if (index == -1) {
/* 117:172 */       return null;
/* 118:    */     }
/* 119:174 */     Range<K> range = (Range)this.ranges.get(index);
/* 120:175 */     return range.contains(key) ? this.values.get(index) : null;
/* 121:    */   }
/* 122:    */   
/* 123:    */   @Nullable
/* 124:    */   public Map.Entry<Range<K>, V> getEntry(K key)
/* 125:    */   {
/* 126:182 */     int index = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), Cut.belowValue(key), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_LOWER);
/* 127:189 */     if (index == -1) {
/* 128:190 */       return null;
/* 129:    */     }
/* 130:192 */     Range<K> range = (Range)this.ranges.get(index);
/* 131:193 */     return range.contains(key) ? Maps.immutableEntry(range, this.values.get(index)) : null;
/* 132:    */   }
/* 133:    */   
/* 134:    */   public Range<K> span()
/* 135:    */   {
/* 136:199 */     if (this.ranges.isEmpty()) {
/* 137:200 */       throw new NoSuchElementException();
/* 138:    */     }
/* 139:202 */     Range<K> firstRange = (Range)this.ranges.get(0);
/* 140:203 */     Range<K> lastRange = (Range)this.ranges.get(this.ranges.size() - 1);
/* 141:204 */     return Range.create(firstRange.lowerBound, lastRange.upperBound);
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void put(Range<K> range, V value)
/* 145:    */   {
/* 146:209 */     throw new UnsupportedOperationException();
/* 147:    */   }
/* 148:    */   
/* 149:    */   public void putAll(RangeMap<K, V> rangeMap)
/* 150:    */   {
/* 151:214 */     throw new UnsupportedOperationException();
/* 152:    */   }
/* 153:    */   
/* 154:    */   public void clear()
/* 155:    */   {
/* 156:219 */     throw new UnsupportedOperationException();
/* 157:    */   }
/* 158:    */   
/* 159:    */   public void remove(Range<K> range)
/* 160:    */   {
/* 161:224 */     throw new UnsupportedOperationException();
/* 162:    */   }
/* 163:    */   
/* 164:    */   public ImmutableMap<Range<K>, V> asMapOfRanges()
/* 165:    */   {
/* 166:229 */     if (this.ranges.isEmpty()) {
/* 167:230 */       return ImmutableMap.of();
/* 168:    */     }
/* 169:232 */     RegularImmutableSortedSet<Range<K>> rangeSet = new RegularImmutableSortedSet(this.ranges, Range.RANGE_LEX_ORDERING);
/* 170:    */     
/* 171:234 */     return new ImmutableSortedMap(rangeSet, this.values);
/* 172:    */   }
/* 173:    */   
/* 174:    */   public ImmutableMap<Range<K>, V> asDescendingMapOfRanges()
/* 175:    */   {
/* 176:239 */     if (this.ranges.isEmpty()) {
/* 177:240 */       return ImmutableMap.of();
/* 178:    */     }
/* 179:242 */     RegularImmutableSortedSet<Range<K>> rangeSet = new RegularImmutableSortedSet(this.ranges.reverse(), Range.RANGE_LEX_ORDERING.reverse());
/* 180:    */     
/* 181:    */ 
/* 182:245 */     return new ImmutableSortedMap(rangeSet, this.values.reverse());
/* 183:    */   }
/* 184:    */   
/* 185:    */   public ImmutableRangeMap<K, V> subRangeMap(final Range<K> range)
/* 186:    */   {
/* 187:250 */     if (((Range)Preconditions.checkNotNull(range)).isEmpty()) {
/* 188:251 */       return of();
/* 189:    */     }
/* 190:252 */     if ((this.ranges.isEmpty()) || (range.encloses(span()))) {
/* 191:253 */       return this;
/* 192:    */     }
/* 193:255 */     int lowerIndex = SortedLists.binarySearch(this.ranges, Range.upperBoundFn(), range.lowerBound, SortedLists.KeyPresentBehavior.FIRST_AFTER, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 194:    */     
/* 195:    */ 
/* 196:    */ 
/* 197:    */ 
/* 198:    */ 
/* 199:    */ 
/* 200:262 */     int upperIndex = SortedLists.binarySearch(this.ranges, Range.lowerBoundFn(), range.upperBound, SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 201:269 */     if (lowerIndex >= upperIndex) {
/* 202:270 */       return of();
/* 203:    */     }
/* 204:272 */     final int off = lowerIndex;
/* 205:273 */     final int len = upperIndex - lowerIndex;
/* 206:274 */     ImmutableList<Range<K>> subRanges = new ImmutableList()
/* 207:    */     {
/* 208:    */       public int size()
/* 209:    */       {
/* 210:278 */         return len;
/* 211:    */       }
/* 212:    */       
/* 213:    */       public Range<K> get(int index)
/* 214:    */       {
/* 215:283 */         Preconditions.checkElementIndex(index, len);
/* 216:284 */         if ((index == 0) || (index == len - 1)) {
/* 217:285 */           return ((Range)ImmutableRangeMap.this.ranges.get(index + off)).intersection(range);
/* 218:    */         }
/* 219:287 */         return (Range)ImmutableRangeMap.this.ranges.get(index + off);
/* 220:    */       }
/* 221:    */       
/* 222:    */       boolean isPartialView()
/* 223:    */       {
/* 224:293 */         return true;
/* 225:    */       }
/* 226:295 */     };
/* 227:296 */     final ImmutableRangeMap<K, V> outer = this;
/* 228:297 */     new ImmutableRangeMap(subRanges, this.values.subList(lowerIndex, upperIndex))
/* 229:    */     {
/* 230:    */       public ImmutableRangeMap<K, V> subRangeMap(Range<K> subRange)
/* 231:    */       {
/* 232:300 */         if (range.isConnected(subRange)) {
/* 233:301 */           return outer.subRangeMap(subRange.intersection(range));
/* 234:    */         }
/* 235:303 */         return ImmutableRangeMap.of();
/* 236:    */       }
/* 237:    */     };
/* 238:    */   }
/* 239:    */   
/* 240:    */   public int hashCode()
/* 241:    */   {
/* 242:311 */     return asMapOfRanges().hashCode();
/* 243:    */   }
/* 244:    */   
/* 245:    */   public boolean equals(@Nullable Object o)
/* 246:    */   {
/* 247:316 */     if ((o instanceof RangeMap))
/* 248:    */     {
/* 249:317 */       RangeMap<?, ?> rangeMap = (RangeMap)o;
/* 250:318 */       return asMapOfRanges().equals(rangeMap.asMapOfRanges());
/* 251:    */     }
/* 252:320 */     return false;
/* 253:    */   }
/* 254:    */   
/* 255:    */   public String toString()
/* 256:    */   {
/* 257:325 */     return asMapOfRanges().toString();
/* 258:    */   }
/* 259:    */   
/* 260:    */   private static class SerializedForm<K extends Comparable<?>, V>
/* 261:    */     implements Serializable
/* 262:    */   {
/* 263:    */     private final ImmutableMap<Range<K>, V> mapOfRanges;
/* 264:    */     private static final long serialVersionUID = 0L;
/* 265:    */     
/* 266:    */     SerializedForm(ImmutableMap<Range<K>, V> mapOfRanges)
/* 267:    */     {
/* 268:337 */       this.mapOfRanges = mapOfRanges;
/* 269:    */     }
/* 270:    */     
/* 271:    */     Object readResolve()
/* 272:    */     {
/* 273:341 */       if (this.mapOfRanges.isEmpty()) {
/* 274:342 */         return ImmutableRangeMap.of();
/* 275:    */       }
/* 276:344 */       return createRangeMap();
/* 277:    */     }
/* 278:    */     
/* 279:    */     Object createRangeMap()
/* 280:    */     {
/* 281:349 */       ImmutableRangeMap.Builder<K, V> builder = new ImmutableRangeMap.Builder();
/* 282:350 */       for (Map.Entry<Range<K>, V> entry : this.mapOfRanges.entrySet()) {
/* 283:351 */         builder.put((Range)entry.getKey(), entry.getValue());
/* 284:    */       }
/* 285:353 */       return builder.build();
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   Object writeReplace()
/* 290:    */   {
/* 291:360 */     return new SerializedForm(asMapOfRanges());
/* 292:    */   }
/* 293:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableRangeMap
 * JD-Core Version:    0.7.0.1
 */