/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Set;
/*  14:    */ 
/*  15:    */ @Beta
/*  16:    */ @GwtIncompatible("hasn't been tested yet")
/*  17:    */ public abstract class ImmutableSortedMultiset<E>
/*  18:    */   extends ImmutableSortedMultisetFauxverideShim<E>
/*  19:    */   implements SortedMultiset<E>
/*  20:    */ {
/*  21: 54 */   private static final Comparator<Comparable> NATURAL_ORDER = ;
/*  22: 56 */   private static final ImmutableSortedMultiset<Comparable> NATURAL_EMPTY_MULTISET = new RegularImmutableSortedMultiset(NATURAL_ORDER);
/*  23:    */   transient ImmutableSortedMultiset<E> descendingMultiset;
/*  24:    */   
/*  25:    */   public static <E> ImmutableSortedMultiset<E> of()
/*  26:    */   {
/*  27: 64 */     return NATURAL_EMPTY_MULTISET;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E element)
/*  31:    */   {
/*  32: 71 */     RegularImmutableSortedSet<E> elementSet = (RegularImmutableSortedSet)ImmutableSortedSet.of(element);
/*  33:    */     
/*  34: 73 */     long[] cumulativeCounts = { 0L, 1L };
/*  35: 74 */     return new RegularImmutableSortedMultiset(elementSet, cumulativeCounts, 0, 1);
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2)
/*  39:    */   {
/*  40: 85 */     return copyOf(Ordering.natural(), Arrays.asList(new Comparable[] { e1, e2 }));
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3)
/*  44:    */   {
/*  45: 96 */     return copyOf(Ordering.natural(), Arrays.asList(new Comparable[] { e1, e2, e3 }));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4)
/*  49:    */   {
/*  50:108 */     return copyOf(Ordering.natural(), Arrays.asList(new Comparable[] { e1, e2, e3, e4 }));
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4, E e5)
/*  54:    */   {
/*  55:120 */     return copyOf(Ordering.natural(), Arrays.asList(new Comparable[] { e1, e2, e3, e4, e5 }));
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... remaining)
/*  59:    */   {
/*  60:132 */     int size = remaining.length + 6;
/*  61:133 */     List<E> all = Lists.newArrayListWithCapacity(size);
/*  62:134 */     Collections.addAll(all, new Comparable[] { e1, e2, e3, e4, e5, e6 });
/*  63:135 */     Collections.addAll(all, remaining);
/*  64:136 */     return copyOf(Ordering.natural(), all);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static <E extends Comparable<? super E>> ImmutableSortedMultiset<E> copyOf(E[] elements)
/*  68:    */   {
/*  69:146 */     return copyOf(Ordering.natural(), Arrays.asList(elements));
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static <E> ImmutableSortedMultiset<E> copyOf(Iterable<? extends E> elements)
/*  73:    */   {
/*  74:175 */     Ordering<E> naturalOrder = Ordering.natural();
/*  75:176 */     return copyOf(naturalOrder, elements);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public static <E> ImmutableSortedMultiset<E> copyOf(Iterator<? extends E> elements)
/*  79:    */   {
/*  80:193 */     Ordering<E> naturalOrder = Ordering.natural();
/*  81:194 */     return copyOf(naturalOrder, elements);
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static <E> ImmutableSortedMultiset<E> copyOf(Comparator<? super E> comparator, Iterator<? extends E> elements)
/*  85:    */   {
/*  86:205 */     Preconditions.checkNotNull(comparator);
/*  87:206 */     return new Builder(comparator).addAll(elements).build();
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static <E> ImmutableSortedMultiset<E> copyOf(Comparator<? super E> comparator, Iterable<? extends E> elements)
/*  91:    */   {
/*  92:221 */     if ((elements instanceof ImmutableSortedMultiset))
/*  93:    */     {
/*  94:223 */       ImmutableSortedMultiset<E> multiset = (ImmutableSortedMultiset)elements;
/*  95:224 */       if (comparator.equals(multiset.comparator()))
/*  96:    */       {
/*  97:225 */         if (multiset.isPartialView()) {
/*  98:226 */           return copyOfSortedEntries(comparator, multiset.entrySet().asList());
/*  99:    */         }
/* 100:228 */         return multiset;
/* 101:    */       }
/* 102:    */     }
/* 103:232 */     elements = Lists.newArrayList(elements);
/* 104:233 */     TreeMultiset<E> sortedCopy = TreeMultiset.create((Comparator)Preconditions.checkNotNull(comparator));
/* 105:234 */     Iterables.addAll(sortedCopy, elements);
/* 106:235 */     return copyOfSortedEntries(comparator, sortedCopy.entrySet());
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static <E> ImmutableSortedMultiset<E> copyOfSorted(SortedMultiset<E> sortedMultiset)
/* 110:    */   {
/* 111:253 */     return copyOfSortedEntries(sortedMultiset.comparator(), Lists.newArrayList(sortedMultiset.entrySet()));
/* 112:    */   }
/* 113:    */   
/* 114:    */   private static <E> ImmutableSortedMultiset<E> copyOfSortedEntries(Comparator<? super E> comparator, Collection<Multiset.Entry<E>> entries)
/* 115:    */   {
/* 116:259 */     if (entries.isEmpty()) {
/* 117:260 */       return emptyMultiset(comparator);
/* 118:    */     }
/* 119:262 */     ImmutableList.Builder<E> elementsBuilder = new ImmutableList.Builder(entries.size());
/* 120:263 */     long[] cumulativeCounts = new long[entries.size() + 1];
/* 121:264 */     int i = 0;
/* 122:265 */     for (Multiset.Entry<E> entry : entries)
/* 123:    */     {
/* 124:266 */       elementsBuilder.add(entry.getElement());
/* 125:267 */       cumulativeCounts[(i + 1)] = (cumulativeCounts[i] + entry.getCount());
/* 126:268 */       i++;
/* 127:    */     }
/* 128:270 */     return new RegularImmutableSortedMultiset(new RegularImmutableSortedSet(elementsBuilder.build(), comparator), cumulativeCounts, 0, entries.size());
/* 129:    */   }
/* 130:    */   
/* 131:    */   static <E> ImmutableSortedMultiset<E> emptyMultiset(Comparator<? super E> comparator)
/* 132:    */   {
/* 133:279 */     if (NATURAL_ORDER.equals(comparator)) {
/* 134:280 */       return NATURAL_EMPTY_MULTISET;
/* 135:    */     }
/* 136:282 */     return new RegularImmutableSortedMultiset(comparator);
/* 137:    */   }
/* 138:    */   
/* 139:    */   public final Comparator<? super E> comparator()
/* 140:    */   {
/* 141:290 */     return elementSet().comparator();
/* 142:    */   }
/* 143:    */   
/* 144:    */   public abstract ImmutableSortedSet<E> elementSet();
/* 145:    */   
/* 146:    */   public ImmutableSortedMultiset<E> descendingMultiset()
/* 147:    */   {
/* 148:300 */     ImmutableSortedMultiset<E> result = this.descendingMultiset;
/* 149:301 */     if (result == null) {
/* 150:302 */       return this.descendingMultiset = isEmpty() ? emptyMultiset(Ordering.from(comparator()).reverse()) : new DescendingImmutableSortedMultiset(this);
/* 151:    */     }
/* 152:307 */     return result;
/* 153:    */   }
/* 154:    */   
/* 155:    */   @Deprecated
/* 156:    */   public final Multiset.Entry<E> pollFirstEntry()
/* 157:    */   {
/* 158:321 */     throw new UnsupportedOperationException();
/* 159:    */   }
/* 160:    */   
/* 161:    */   @Deprecated
/* 162:    */   public final Multiset.Entry<E> pollLastEntry()
/* 163:    */   {
/* 164:335 */     throw new UnsupportedOperationException();
/* 165:    */   }
/* 166:    */   
/* 167:    */   public abstract ImmutableSortedMultiset<E> headMultiset(E paramE, BoundType paramBoundType);
/* 168:    */   
/* 169:    */   public ImmutableSortedMultiset<E> subMultiset(E lowerBound, BoundType lowerBoundType, E upperBound, BoundType upperBoundType)
/* 170:    */   {
/* 171:344 */     Preconditions.checkArgument(comparator().compare(lowerBound, upperBound) <= 0, "Expected lowerBound <= upperBound but %s > %s", new Object[] { lowerBound, upperBound });
/* 172:    */     
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:349 */     return tailMultiset(lowerBound, lowerBoundType).headMultiset(upperBound, upperBoundType);
/* 177:    */   }
/* 178:    */   
/* 179:    */   public abstract ImmutableSortedMultiset<E> tailMultiset(E paramE, BoundType paramBoundType);
/* 180:    */   
/* 181:    */   public static <E> Builder<E> orderedBy(Comparator<E> comparator)
/* 182:    */   {
/* 183:364 */     return new Builder(comparator);
/* 184:    */   }
/* 185:    */   
/* 186:    */   public static <E extends Comparable<?>> Builder<E> reverseOrder()
/* 187:    */   {
/* 188:376 */     return new Builder(Ordering.natural().reverse());
/* 189:    */   }
/* 190:    */   
/* 191:    */   public static <E extends Comparable<?>> Builder<E> naturalOrder()
/* 192:    */   {
/* 193:390 */     return new Builder(Ordering.natural());
/* 194:    */   }
/* 195:    */   
/* 196:    */   public static class Builder<E>
/* 197:    */     extends ImmutableMultiset.Builder<E>
/* 198:    */   {
/* 199:    */     public Builder(Comparator<? super E> comparator)
/* 200:    */     {
/* 201:418 */       super();
/* 202:    */     }
/* 203:    */     
/* 204:    */     public Builder<E> add(E element)
/* 205:    */     {
/* 206:430 */       super.add(element);
/* 207:431 */       return this;
/* 208:    */     }
/* 209:    */     
/* 210:    */     public Builder<E> addCopies(E element, int occurrences)
/* 211:    */     {
/* 212:447 */       super.addCopies(element, occurrences);
/* 213:448 */       return this;
/* 214:    */     }
/* 215:    */     
/* 216:    */     public Builder<E> setCount(E element, int count)
/* 217:    */     {
/* 218:463 */       super.setCount(element, count);
/* 219:464 */       return this;
/* 220:    */     }
/* 221:    */     
/* 222:    */     public Builder<E> add(E... elements)
/* 223:    */     {
/* 224:476 */       super.add(elements);
/* 225:477 */       return this;
/* 226:    */     }
/* 227:    */     
/* 228:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 229:    */     {
/* 230:489 */       super.addAll(elements);
/* 231:490 */       return this;
/* 232:    */     }
/* 233:    */     
/* 234:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 235:    */     {
/* 236:502 */       super.addAll(elements);
/* 237:503 */       return this;
/* 238:    */     }
/* 239:    */     
/* 240:    */     public ImmutableSortedMultiset<E> build()
/* 241:    */     {
/* 242:512 */       return ImmutableSortedMultiset.copyOfSorted((SortedMultiset)this.contents);
/* 243:    */     }
/* 244:    */   }
/* 245:    */   
/* 246:    */   private static final class SerializedForm<E>
/* 247:    */     implements Serializable
/* 248:    */   {
/* 249:    */     Comparator<? super E> comparator;
/* 250:    */     E[] elements;
/* 251:    */     int[] counts;
/* 252:    */     
/* 253:    */     SerializedForm(SortedMultiset<E> multiset)
/* 254:    */     {
/* 255:523 */       this.comparator = multiset.comparator();
/* 256:524 */       int n = multiset.entrySet().size();
/* 257:525 */       this.elements = ((Object[])new Object[n]);
/* 258:526 */       this.counts = new int[n];
/* 259:527 */       int i = 0;
/* 260:528 */       for (Multiset.Entry<E> entry : multiset.entrySet())
/* 261:    */       {
/* 262:529 */         this.elements[i] = entry.getElement();
/* 263:530 */         this.counts[i] = entry.getCount();
/* 264:531 */         i++;
/* 265:    */       }
/* 266:    */     }
/* 267:    */     
/* 268:    */     Object readResolve()
/* 269:    */     {
/* 270:536 */       int n = this.elements.length;
/* 271:537 */       ImmutableSortedMultiset.Builder<E> builder = new ImmutableSortedMultiset.Builder(this.comparator);
/* 272:538 */       for (int i = 0; i < n; i++) {
/* 273:539 */         builder.addCopies(this.elements[i], this.counts[i]);
/* 274:    */       }
/* 275:541 */       return builder.build();
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   Object writeReplace()
/* 280:    */   {
/* 281:547 */     return new SerializedForm(this);
/* 282:    */   }
/* 283:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedMultiset
 * JD-Core Version:    0.7.0.1
 */