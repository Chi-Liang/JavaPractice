/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.AbstractCollection;
/*   5:    */ import java.util.AbstractSet;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Set;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ abstract class AbstractTable<R, C, V>
/*  14:    */   implements Table<R, C, V>
/*  15:    */ {
/*  16:    */   private transient Set<Table.Cell<R, C, V>> cellSet;
/*  17:    */   private transient Collection<V> values;
/*  18:    */   
/*  19:    */   public boolean containsRow(@Nullable Object rowKey)
/*  20:    */   {
/*  21: 39 */     return Maps.safeContainsKey(rowMap(), rowKey);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public boolean containsColumn(@Nullable Object columnKey)
/*  25:    */   {
/*  26: 44 */     return Maps.safeContainsKey(columnMap(), columnKey);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public Set<R> rowKeySet()
/*  30:    */   {
/*  31: 49 */     return rowMap().keySet();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Set<C> columnKeySet()
/*  35:    */   {
/*  36: 54 */     return columnMap().keySet();
/*  37:    */   }
/*  38:    */   
/*  39:    */   public boolean containsValue(@Nullable Object value)
/*  40:    */   {
/*  41: 59 */     for (Map<C, V> row : rowMap().values()) {
/*  42: 60 */       if (row.containsValue(value)) {
/*  43: 61 */         return true;
/*  44:    */       }
/*  45:    */     }
/*  46: 64 */     return false;
/*  47:    */   }
/*  48:    */   
/*  49:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/*  50:    */   {
/*  51: 69 */     Map<C, V> row = (Map)Maps.safeGet(rowMap(), rowKey);
/*  52: 70 */     return (row != null) && (Maps.safeContainsKey(row, columnKey));
/*  53:    */   }
/*  54:    */   
/*  55:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/*  56:    */   {
/*  57: 75 */     Map<C, V> row = (Map)Maps.safeGet(rowMap(), rowKey);
/*  58: 76 */     return row == null ? null : Maps.safeGet(row, columnKey);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean isEmpty()
/*  62:    */   {
/*  63: 81 */     return size() == 0;
/*  64:    */   }
/*  65:    */   
/*  66:    */   public void clear()
/*  67:    */   {
/*  68: 86 */     Iterators.clear(cellSet().iterator());
/*  69:    */   }
/*  70:    */   
/*  71:    */   public V remove(@Nullable Object rowKey, @Nullable Object columnKey)
/*  72:    */   {
/*  73: 91 */     Map<C, V> row = (Map)Maps.safeGet(rowMap(), rowKey);
/*  74: 92 */     return row == null ? null : Maps.safeRemove(row, columnKey);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public V put(R rowKey, C columnKey, V value)
/*  78:    */   {
/*  79: 97 */     return row(rowKey).put(columnKey, value);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void putAll(Table<? extends R, ? extends C, ? extends V> table)
/*  83:    */   {
/*  84:102 */     for (Table.Cell<? extends R, ? extends C, ? extends V> cell : table.cellSet()) {
/*  85:103 */       put(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
/*  86:    */     }
/*  87:    */   }
/*  88:    */   
/*  89:    */   public Set<Table.Cell<R, C, V>> cellSet()
/*  90:    */   {
/*  91:111 */     Set<Table.Cell<R, C, V>> result = this.cellSet;
/*  92:112 */     return result == null ? (this.cellSet = createCellSet()) : result;
/*  93:    */   }
/*  94:    */   
/*  95:    */   Set<Table.Cell<R, C, V>> createCellSet()
/*  96:    */   {
/*  97:116 */     return new CellSet();
/*  98:    */   }
/*  99:    */   
/* 100:    */   abstract Iterator<Table.Cell<R, C, V>> cellIterator();
/* 101:    */   
/* 102:    */   class CellSet
/* 103:    */     extends AbstractSet<Table.Cell<R, C, V>>
/* 104:    */   {
/* 105:    */     CellSet() {}
/* 106:    */     
/* 107:    */     public boolean contains(Object o)
/* 108:    */     {
/* 109:125 */       if ((o instanceof Table.Cell))
/* 110:    */       {
/* 111:126 */         Table.Cell<?, ?, ?> cell = (Table.Cell)o;
/* 112:127 */         Map<C, V> row = (Map)Maps.safeGet(AbstractTable.this.rowMap(), cell.getRowKey());
/* 113:128 */         return (row != null) && (Collections2.safeContains(row.entrySet(), Maps.immutableEntry(cell.getColumnKey(), cell.getValue())));
/* 114:    */       }
/* 115:132 */       return false;
/* 116:    */     }
/* 117:    */     
/* 118:    */     public boolean remove(@Nullable Object o)
/* 119:    */     {
/* 120:137 */       if ((o instanceof Table.Cell))
/* 121:    */       {
/* 122:138 */         Table.Cell<?, ?, ?> cell = (Table.Cell)o;
/* 123:139 */         Map<C, V> row = (Map)Maps.safeGet(AbstractTable.this.rowMap(), cell.getRowKey());
/* 124:140 */         return (row != null) && (Collections2.safeRemove(row.entrySet(), Maps.immutableEntry(cell.getColumnKey(), cell.getValue())));
/* 125:    */       }
/* 126:144 */       return false;
/* 127:    */     }
/* 128:    */     
/* 129:    */     public void clear()
/* 130:    */     {
/* 131:149 */       AbstractTable.this.clear();
/* 132:    */     }
/* 133:    */     
/* 134:    */     public Iterator<Table.Cell<R, C, V>> iterator()
/* 135:    */     {
/* 136:154 */       return AbstractTable.this.cellIterator();
/* 137:    */     }
/* 138:    */     
/* 139:    */     public int size()
/* 140:    */     {
/* 141:159 */       return AbstractTable.this.size();
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   public Collection<V> values()
/* 146:    */   {
/* 147:167 */     Collection<V> result = this.values;
/* 148:168 */     return result == null ? (this.values = createValues()) : result;
/* 149:    */   }
/* 150:    */   
/* 151:    */   Collection<V> createValues()
/* 152:    */   {
/* 153:172 */     return new Values();
/* 154:    */   }
/* 155:    */   
/* 156:    */   Iterator<V> valuesIterator()
/* 157:    */   {
/* 158:176 */     new TransformedIterator(cellSet().iterator())
/* 159:    */     {
/* 160:    */       V transform(Table.Cell<R, C, V> cell)
/* 161:    */       {
/* 162:179 */         return cell.getValue();
/* 163:    */       }
/* 164:    */     };
/* 165:    */   }
/* 166:    */   
/* 167:    */   class Values
/* 168:    */     extends AbstractCollection<V>
/* 169:    */   {
/* 170:    */     Values() {}
/* 171:    */     
/* 172:    */     public Iterator<V> iterator()
/* 173:    */     {
/* 174:188 */       return AbstractTable.this.valuesIterator();
/* 175:    */     }
/* 176:    */     
/* 177:    */     public boolean contains(Object o)
/* 178:    */     {
/* 179:193 */       return AbstractTable.this.containsValue(o);
/* 180:    */     }
/* 181:    */     
/* 182:    */     public void clear()
/* 183:    */     {
/* 184:198 */       AbstractTable.this.clear();
/* 185:    */     }
/* 186:    */     
/* 187:    */     public int size()
/* 188:    */     {
/* 189:203 */       return AbstractTable.this.size();
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   public boolean equals(@Nullable Object obj)
/* 194:    */   {
/* 195:209 */     return Tables.equalsImpl(this, obj);
/* 196:    */   }
/* 197:    */   
/* 198:    */   public int hashCode()
/* 199:    */   {
/* 200:214 */     return cellSet().hashCode();
/* 201:    */   }
/* 202:    */   
/* 203:    */   public String toString()
/* 204:    */   {
/* 205:222 */     return rowMap().toString();
/* 206:    */   }
/* 207:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractTable
 * JD-Core Version:    0.7.0.1
 */