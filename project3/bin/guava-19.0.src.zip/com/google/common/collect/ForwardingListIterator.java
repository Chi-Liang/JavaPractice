/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.ListIterator;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public abstract class ForwardingListIterator<E>
/*  8:   */   extends ForwardingIterator<E>
/*  9:   */   implements ListIterator<E>
/* 10:   */ {
/* 11:   */   protected abstract ListIterator<E> delegate();
/* 12:   */   
/* 13:   */   public void add(E element)
/* 14:   */   {
/* 15:44 */     delegate().add(element);
/* 16:   */   }
/* 17:   */   
/* 18:   */   public boolean hasPrevious()
/* 19:   */   {
/* 20:49 */     return delegate().hasPrevious();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public int nextIndex()
/* 24:   */   {
/* 25:54 */     return delegate().nextIndex();
/* 26:   */   }
/* 27:   */   
/* 28:   */   public E previous()
/* 29:   */   {
/* 30:59 */     return delegate().previous();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public int previousIndex()
/* 34:   */   {
/* 35:64 */     return delegate().previousIndex();
/* 36:   */   }
/* 37:   */   
/* 38:   */   public void set(E element)
/* 39:   */   {
/* 40:69 */     delegate().set(element);
/* 41:   */   }
/* 42:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingListIterator
 * JD-Core Version:    0.7.0.1
 */