/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.InvalidObjectException;
/*   6:    */ import java.io.ObjectInputStream;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.RandomAccess;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public abstract class ImmutableList<E>
/*  16:    */   extends ImmutableCollection<E>
/*  17:    */   implements List<E>, RandomAccess
/*  18:    */ {
/*  19:    */   public static <E> ImmutableList<E> of()
/*  20:    */   {
/*  21: 64 */     return RegularImmutableList.EMPTY;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public static <E> ImmutableList<E> of(E element)
/*  25:    */   {
/*  26: 76 */     return new SingletonImmutableList(element);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static <E> ImmutableList<E> of(E e1, E e2)
/*  30:    */   {
/*  31: 85 */     return construct(new Object[] { e1, e2 });
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3)
/*  35:    */   {
/*  36: 94 */     return construct(new Object[] { e1, e2, e3 });
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4)
/*  40:    */   {
/*  41:103 */     return construct(new Object[] { e1, e2, e3, e4 });
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5)
/*  45:    */   {
/*  46:112 */     return construct(new Object[] { e1, e2, e3, e4, e5 });
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6)
/*  50:    */   {
/*  51:121 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6 });
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7)
/*  55:    */   {
/*  56:130 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7 });
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8)
/*  60:    */   {
/*  61:139 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8 });
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9)
/*  65:    */   {
/*  66:148 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9 });
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10)
/*  70:    */   {
/*  71:158 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9, e10 });
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10, E e11)
/*  75:    */   {
/*  76:168 */     return construct(new Object[] { e1, e2, e3, e4, e5, e6, e7, e8, e9, e10, e11 });
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static <E> ImmutableList<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E e7, E e8, E e9, E e10, E e11, E e12, E... others)
/*  80:    */   {
/*  81:182 */     Object[] array = new Object[12 + others.length];
/*  82:183 */     array[0] = e1;
/*  83:184 */     array[1] = e2;
/*  84:185 */     array[2] = e3;
/*  85:186 */     array[3] = e4;
/*  86:187 */     array[4] = e5;
/*  87:188 */     array[5] = e6;
/*  88:189 */     array[6] = e7;
/*  89:190 */     array[7] = e8;
/*  90:191 */     array[8] = e9;
/*  91:192 */     array[9] = e10;
/*  92:193 */     array[10] = e11;
/*  93:194 */     array[11] = e12;
/*  94:195 */     System.arraycopy(others, 0, array, 12, others.length);
/*  95:196 */     return construct(array);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static <E> ImmutableList<E> copyOf(Iterable<? extends E> elements)
/*  99:    */   {
/* 100:208 */     Preconditions.checkNotNull(elements);
/* 101:209 */     return (elements instanceof Collection) ? copyOf((Collection)elements) : copyOf(elements.iterator());
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static <E> ImmutableList<E> copyOf(Collection<? extends E> elements)
/* 105:    */   {
/* 106:234 */     if ((elements instanceof ImmutableCollection))
/* 107:    */     {
/* 108:236 */       ImmutableList<E> list = ((ImmutableCollection)elements).asList();
/* 109:237 */       return list.isPartialView() ? asImmutableList(list.toArray()) : list;
/* 110:    */     }
/* 111:239 */     return construct(elements.toArray());
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static <E> ImmutableList<E> copyOf(Iterator<? extends E> elements)
/* 115:    */   {
/* 116:249 */     if (!elements.hasNext()) {
/* 117:250 */       return of();
/* 118:    */     }
/* 119:252 */     E first = elements.next();
/* 120:253 */     if (!elements.hasNext()) {
/* 121:254 */       return of(first);
/* 122:    */     }
/* 123:256 */     return new Builder().add(first).addAll(elements).build();
/* 124:    */   }
/* 125:    */   
/* 126:    */   public static <E> ImmutableList<E> copyOf(E[] elements)
/* 127:    */   {
/* 128:267 */     switch (elements.length)
/* 129:    */     {
/* 130:    */     case 0: 
/* 131:269 */       return of();
/* 132:    */     case 1: 
/* 133:271 */       return new SingletonImmutableList(elements[0]);
/* 134:    */     }
/* 135:273 */     return new RegularImmutableList(ObjectArrays.checkElementsNotNull((Object[])elements.clone()));
/* 136:    */   }
/* 137:    */   
/* 138:    */   private static <E> ImmutableList<E> construct(Object... elements)
/* 139:    */   {
/* 140:281 */     return asImmutableList(ObjectArrays.checkElementsNotNull(elements));
/* 141:    */   }
/* 142:    */   
/* 143:    */   static <E> ImmutableList<E> asImmutableList(Object[] elements)
/* 144:    */   {
/* 145:290 */     return asImmutableList(elements, elements.length);
/* 146:    */   }
/* 147:    */   
/* 148:    */   static <E> ImmutableList<E> asImmutableList(Object[] elements, int length)
/* 149:    */   {
/* 150:298 */     switch (length)
/* 151:    */     {
/* 152:    */     case 0: 
/* 153:300 */       return of();
/* 154:    */     case 1: 
/* 155:303 */       ImmutableList<E> list = new SingletonImmutableList(elements[0]);
/* 156:304 */       return list;
/* 157:    */     }
/* 158:306 */     if (length < elements.length) {
/* 159:307 */       elements = ObjectArrays.arraysCopyOf(elements, length);
/* 160:    */     }
/* 161:309 */     return new RegularImmutableList(elements);
/* 162:    */   }
/* 163:    */   
/* 164:    */   public UnmodifiableIterator<E> iterator()
/* 165:    */   {
/* 166:319 */     return listIterator();
/* 167:    */   }
/* 168:    */   
/* 169:    */   public UnmodifiableListIterator<E> listIterator()
/* 170:    */   {
/* 171:324 */     return listIterator(0);
/* 172:    */   }
/* 173:    */   
/* 174:    */   public UnmodifiableListIterator<E> listIterator(int index)
/* 175:    */   {
/* 176:329 */     new AbstractIndexedListIterator(size(), index)
/* 177:    */     {
/* 178:    */       protected E get(int index)
/* 179:    */       {
/* 180:332 */         return ImmutableList.this.get(index);
/* 181:    */       }
/* 182:    */     };
/* 183:    */   }
/* 184:    */   
/* 185:    */   public int indexOf(@Nullable Object object)
/* 186:    */   {
/* 187:339 */     return object == null ? -1 : Lists.indexOfImpl(this, object);
/* 188:    */   }
/* 189:    */   
/* 190:    */   public int lastIndexOf(@Nullable Object object)
/* 191:    */   {
/* 192:344 */     return object == null ? -1 : Lists.lastIndexOfImpl(this, object);
/* 193:    */   }
/* 194:    */   
/* 195:    */   public boolean contains(@Nullable Object object)
/* 196:    */   {
/* 197:349 */     return indexOf(object) >= 0;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public ImmutableList<E> subList(int fromIndex, int toIndex)
/* 201:    */   {
/* 202:362 */     Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/* 203:363 */     int length = toIndex - fromIndex;
/* 204:364 */     if (length == size()) {
/* 205:365 */       return this;
/* 206:    */     }
/* 207:367 */     switch (length)
/* 208:    */     {
/* 209:    */     case 0: 
/* 210:369 */       return of();
/* 211:    */     case 1: 
/* 212:371 */       return of(get(fromIndex));
/* 213:    */     }
/* 214:373 */     return subListUnchecked(fromIndex, toIndex);
/* 215:    */   }
/* 216:    */   
/* 217:    */   ImmutableList<E> subListUnchecked(int fromIndex, int toIndex)
/* 218:    */   {
/* 219:383 */     return new SubList(fromIndex, toIndex - fromIndex);
/* 220:    */   }
/* 221:    */   
/* 222:    */   class SubList
/* 223:    */     extends ImmutableList<E>
/* 224:    */   {
/* 225:    */     final transient int offset;
/* 226:    */     final transient int length;
/* 227:    */     
/* 228:    */     SubList(int offset, int length)
/* 229:    */     {
/* 230:391 */       this.offset = offset;
/* 231:392 */       this.length = length;
/* 232:    */     }
/* 233:    */     
/* 234:    */     public int size()
/* 235:    */     {
/* 236:397 */       return this.length;
/* 237:    */     }
/* 238:    */     
/* 239:    */     public E get(int index)
/* 240:    */     {
/* 241:402 */       Preconditions.checkElementIndex(index, this.length);
/* 242:403 */       return ImmutableList.this.get(index + this.offset);
/* 243:    */     }
/* 244:    */     
/* 245:    */     public ImmutableList<E> subList(int fromIndex, int toIndex)
/* 246:    */     {
/* 247:408 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, this.length);
/* 248:409 */       return ImmutableList.this.subList(fromIndex + this.offset, toIndex + this.offset);
/* 249:    */     }
/* 250:    */     
/* 251:    */     boolean isPartialView()
/* 252:    */     {
/* 253:414 */       return true;
/* 254:    */     }
/* 255:    */   }
/* 256:    */   
/* 257:    */   @Deprecated
/* 258:    */   public final boolean addAll(int index, Collection<? extends E> newElements)
/* 259:    */   {
/* 260:427 */     throw new UnsupportedOperationException();
/* 261:    */   }
/* 262:    */   
/* 263:    */   @Deprecated
/* 264:    */   public final E set(int index, E element)
/* 265:    */   {
/* 266:439 */     throw new UnsupportedOperationException();
/* 267:    */   }
/* 268:    */   
/* 269:    */   @Deprecated
/* 270:    */   public final void add(int index, E element)
/* 271:    */   {
/* 272:451 */     throw new UnsupportedOperationException();
/* 273:    */   }
/* 274:    */   
/* 275:    */   @Deprecated
/* 276:    */   public final E remove(int index)
/* 277:    */   {
/* 278:463 */     throw new UnsupportedOperationException();
/* 279:    */   }
/* 280:    */   
/* 281:    */   public final ImmutableList<E> asList()
/* 282:    */   {
/* 283:473 */     return this;
/* 284:    */   }
/* 285:    */   
/* 286:    */   int copyIntoArray(Object[] dst, int offset)
/* 287:    */   {
/* 288:479 */     int size = size();
/* 289:480 */     for (int i = 0; i < size; i++) {
/* 290:481 */       dst[(offset + i)] = get(i);
/* 291:    */     }
/* 292:483 */     return offset + size;
/* 293:    */   }
/* 294:    */   
/* 295:    */   public ImmutableList<E> reverse()
/* 296:    */   {
/* 297:495 */     return size() <= 1 ? this : new ReverseImmutableList(this);
/* 298:    */   }
/* 299:    */   
/* 300:    */   private static class ReverseImmutableList<E>
/* 301:    */     extends ImmutableList<E>
/* 302:    */   {
/* 303:    */     private final transient ImmutableList<E> forwardList;
/* 304:    */     
/* 305:    */     ReverseImmutableList(ImmutableList<E> backingList)
/* 306:    */     {
/* 307:502 */       this.forwardList = backingList;
/* 308:    */     }
/* 309:    */     
/* 310:    */     private int reverseIndex(int index)
/* 311:    */     {
/* 312:506 */       return size() - 1 - index;
/* 313:    */     }
/* 314:    */     
/* 315:    */     private int reversePosition(int index)
/* 316:    */     {
/* 317:510 */       return size() - index;
/* 318:    */     }
/* 319:    */     
/* 320:    */     public ImmutableList<E> reverse()
/* 321:    */     {
/* 322:515 */       return this.forwardList;
/* 323:    */     }
/* 324:    */     
/* 325:    */     public boolean contains(@Nullable Object object)
/* 326:    */     {
/* 327:520 */       return this.forwardList.contains(object);
/* 328:    */     }
/* 329:    */     
/* 330:    */     public int indexOf(@Nullable Object object)
/* 331:    */     {
/* 332:525 */       int index = this.forwardList.lastIndexOf(object);
/* 333:526 */       return index >= 0 ? reverseIndex(index) : -1;
/* 334:    */     }
/* 335:    */     
/* 336:    */     public int lastIndexOf(@Nullable Object object)
/* 337:    */     {
/* 338:531 */       int index = this.forwardList.indexOf(object);
/* 339:532 */       return index >= 0 ? reverseIndex(index) : -1;
/* 340:    */     }
/* 341:    */     
/* 342:    */     public ImmutableList<E> subList(int fromIndex, int toIndex)
/* 343:    */     {
/* 344:537 */       Preconditions.checkPositionIndexes(fromIndex, toIndex, size());
/* 345:538 */       return this.forwardList.subList(reversePosition(toIndex), reversePosition(fromIndex)).reverse();
/* 346:    */     }
/* 347:    */     
/* 348:    */     public E get(int index)
/* 349:    */     {
/* 350:543 */       Preconditions.checkElementIndex(index, size());
/* 351:544 */       return this.forwardList.get(reverseIndex(index));
/* 352:    */     }
/* 353:    */     
/* 354:    */     public int size()
/* 355:    */     {
/* 356:549 */       return this.forwardList.size();
/* 357:    */     }
/* 358:    */     
/* 359:    */     boolean isPartialView()
/* 360:    */     {
/* 361:554 */       return this.forwardList.isPartialView();
/* 362:    */     }
/* 363:    */   }
/* 364:    */   
/* 365:    */   public boolean equals(@Nullable Object obj)
/* 366:    */   {
/* 367:560 */     return Lists.equalsImpl(this, obj);
/* 368:    */   }
/* 369:    */   
/* 370:    */   public int hashCode()
/* 371:    */   {
/* 372:565 */     int hashCode = 1;
/* 373:566 */     int n = size();
/* 374:567 */     for (int i = 0; i < n; i++)
/* 375:    */     {
/* 376:568 */       hashCode = 31 * hashCode + get(i).hashCode();
/* 377:    */       
/* 378:570 */       hashCode = hashCode ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/* 379:    */     }
/* 380:573 */     return hashCode;
/* 381:    */   }
/* 382:    */   
/* 383:    */   static class SerializedForm
/* 384:    */     implements Serializable
/* 385:    */   {
/* 386:    */     final Object[] elements;
/* 387:    */     private static final long serialVersionUID = 0L;
/* 388:    */     
/* 389:    */     SerializedForm(Object[] elements)
/* 390:    */     {
/* 391:584 */       this.elements = elements;
/* 392:    */     }
/* 393:    */     
/* 394:    */     Object readResolve()
/* 395:    */     {
/* 396:588 */       return ImmutableList.copyOf(this.elements);
/* 397:    */     }
/* 398:    */   }
/* 399:    */   
/* 400:    */   private void readObject(ObjectInputStream stream)
/* 401:    */     throws InvalidObjectException
/* 402:    */   {
/* 403:595 */     throw new InvalidObjectException("Use SerializedForm");
/* 404:    */   }
/* 405:    */   
/* 406:    */   Object writeReplace()
/* 407:    */   {
/* 408:600 */     return new SerializedForm(toArray());
/* 409:    */   }
/* 410:    */   
/* 411:    */   public static <E> Builder<E> builder()
/* 412:    */   {
/* 413:608 */     return new Builder();
/* 414:    */   }
/* 415:    */   
/* 416:    */   public static final class Builder<E>
/* 417:    */     extends ImmutableCollection.ArrayBasedBuilder<E>
/* 418:    */   {
/* 419:    */     public Builder()
/* 420:    */     {
/* 421:633 */       this(4);
/* 422:    */     }
/* 423:    */     
/* 424:    */     Builder(int capacity)
/* 425:    */     {
/* 426:638 */       super();
/* 427:    */     }
/* 428:    */     
/* 429:    */     public Builder<E> add(E element)
/* 430:    */     {
/* 431:650 */       super.add(element);
/* 432:651 */       return this;
/* 433:    */     }
/* 434:    */     
/* 435:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 436:    */     {
/* 437:664 */       super.addAll(elements);
/* 438:665 */       return this;
/* 439:    */     }
/* 440:    */     
/* 441:    */     public Builder<E> add(E... elements)
/* 442:    */     {
/* 443:678 */       super.add(elements);
/* 444:679 */       return this;
/* 445:    */     }
/* 446:    */     
/* 447:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 448:    */     {
/* 449:692 */       super.addAll(elements);
/* 450:693 */       return this;
/* 451:    */     }
/* 452:    */     
/* 453:    */     public ImmutableList<E> build()
/* 454:    */     {
/* 455:702 */       return ImmutableList.asImmutableList(this.contents, this.size);
/* 456:    */     }
/* 457:    */   }
/* 458:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableList
 * JD-Core Version:    0.7.0.1
 */