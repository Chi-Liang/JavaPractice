/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.NavigableSet;
/*   8:    */ import java.util.Set;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ @GwtCompatible(emulated=true)
/*  12:    */ public abstract class ForwardingSortedMultiset<E>
/*  13:    */   extends ForwardingMultiset<E>
/*  14:    */   implements SortedMultiset<E>
/*  15:    */ {
/*  16:    */   protected abstract SortedMultiset<E> delegate();
/*  17:    */   
/*  18:    */   public NavigableSet<E> elementSet()
/*  19:    */   {
/*  20: 54 */     return (NavigableSet)super.elementSet();
/*  21:    */   }
/*  22:    */   
/*  23:    */   protected class StandardElementSet
/*  24:    */     extends SortedMultisets.NavigableElementSet<E>
/*  25:    */   {
/*  26:    */     public StandardElementSet()
/*  27:    */     {
/*  28: 71 */       super();
/*  29:    */     }
/*  30:    */   }
/*  31:    */   
/*  32:    */   public Comparator<? super E> comparator()
/*  33:    */   {
/*  34: 77 */     return delegate().comparator();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public SortedMultiset<E> descendingMultiset()
/*  38:    */   {
/*  39: 82 */     return delegate().descendingMultiset();
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected abstract class StandardDescendingMultiset
/*  43:    */     extends DescendingMultiset<E>
/*  44:    */   {
/*  45:    */     public StandardDescendingMultiset() {}
/*  46:    */     
/*  47:    */     SortedMultiset<E> forwardMultiset()
/*  48:    */     {
/*  49:101 */       return ForwardingSortedMultiset.this;
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Multiset.Entry<E> firstEntry()
/*  54:    */   {
/*  55:107 */     return delegate().firstEntry();
/*  56:    */   }
/*  57:    */   
/*  58:    */   protected Multiset.Entry<E> standardFirstEntry()
/*  59:    */   {
/*  60:117 */     Iterator<Multiset.Entry<E>> entryIterator = entrySet().iterator();
/*  61:118 */     if (!entryIterator.hasNext()) {
/*  62:119 */       return null;
/*  63:    */     }
/*  64:121 */     Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  65:122 */     return Multisets.immutableEntry(entry.getElement(), entry.getCount());
/*  66:    */   }
/*  67:    */   
/*  68:    */   public Multiset.Entry<E> lastEntry()
/*  69:    */   {
/*  70:127 */     return delegate().lastEntry();
/*  71:    */   }
/*  72:    */   
/*  73:    */   protected Multiset.Entry<E> standardLastEntry()
/*  74:    */   {
/*  75:138 */     Iterator<Multiset.Entry<E>> entryIterator = descendingMultiset().entrySet().iterator();
/*  76:139 */     if (!entryIterator.hasNext()) {
/*  77:140 */       return null;
/*  78:    */     }
/*  79:142 */     Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  80:143 */     return Multisets.immutableEntry(entry.getElement(), entry.getCount());
/*  81:    */   }
/*  82:    */   
/*  83:    */   public Multiset.Entry<E> pollFirstEntry()
/*  84:    */   {
/*  85:148 */     return delegate().pollFirstEntry();
/*  86:    */   }
/*  87:    */   
/*  88:    */   protected Multiset.Entry<E> standardPollFirstEntry()
/*  89:    */   {
/*  90:158 */     Iterator<Multiset.Entry<E>> entryIterator = entrySet().iterator();
/*  91:159 */     if (!entryIterator.hasNext()) {
/*  92:160 */       return null;
/*  93:    */     }
/*  94:162 */     Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/*  95:163 */     entry = Multisets.immutableEntry(entry.getElement(), entry.getCount());
/*  96:164 */     entryIterator.remove();
/*  97:165 */     return entry;
/*  98:    */   }
/*  99:    */   
/* 100:    */   public Multiset.Entry<E> pollLastEntry()
/* 101:    */   {
/* 102:170 */     return delegate().pollLastEntry();
/* 103:    */   }
/* 104:    */   
/* 105:    */   protected Multiset.Entry<E> standardPollLastEntry()
/* 106:    */   {
/* 107:181 */     Iterator<Multiset.Entry<E>> entryIterator = descendingMultiset().entrySet().iterator();
/* 108:182 */     if (!entryIterator.hasNext()) {
/* 109:183 */       return null;
/* 110:    */     }
/* 111:185 */     Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/* 112:186 */     entry = Multisets.immutableEntry(entry.getElement(), entry.getCount());
/* 113:187 */     entryIterator.remove();
/* 114:188 */     return entry;
/* 115:    */   }
/* 116:    */   
/* 117:    */   public SortedMultiset<E> headMultiset(E upperBound, BoundType boundType)
/* 118:    */   {
/* 119:193 */     return delegate().headMultiset(upperBound, boundType);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public SortedMultiset<E> subMultiset(E lowerBound, BoundType lowerBoundType, E upperBound, BoundType upperBoundType)
/* 123:    */   {
/* 124:199 */     return delegate().subMultiset(lowerBound, lowerBoundType, upperBound, upperBoundType);
/* 125:    */   }
/* 126:    */   
/* 127:    */   protected SortedMultiset<E> standardSubMultiset(E lowerBound, BoundType lowerBoundType, E upperBound, BoundType upperBoundType)
/* 128:    */   {
/* 129:212 */     return tailMultiset(lowerBound, lowerBoundType).headMultiset(upperBound, upperBoundType);
/* 130:    */   }
/* 131:    */   
/* 132:    */   public SortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType)
/* 133:    */   {
/* 134:217 */     return delegate().tailMultiset(lowerBound, boundType);
/* 135:    */   }
/* 136:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingSortedMultiset
 * JD-Core Version:    0.7.0.1
 */