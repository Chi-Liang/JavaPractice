/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.ArrayList;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.List;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Set;
/*  15:    */ 
/*  16:    */ @GwtCompatible(serializable=true, emulated=true)
/*  17:    */ public final class ArrayListMultimap<K, V>
/*  18:    */   extends AbstractListMultimap<K, V>
/*  19:    */ {
/*  20:    */   private static final int DEFAULT_VALUES_PER_KEY = 3;
/*  21:    */   @VisibleForTesting
/*  22:    */   transient int expectedValuesPerKey;
/*  23:    */   @GwtIncompatible("Not needed in emulated source.")
/*  24:    */   private static final long serialVersionUID = 0L;
/*  25:    */   
/*  26:    */   public static <K, V> ArrayListMultimap<K, V> create()
/*  27:    */   {
/*  28: 78 */     return new ArrayListMultimap();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static <K, V> ArrayListMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey)
/*  32:    */   {
/*  33: 91 */     return new ArrayListMultimap(expectedKeys, expectedValuesPerKey);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static <K, V> ArrayListMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*  37:    */   {
/*  38:101 */     return new ArrayListMultimap(multimap);
/*  39:    */   }
/*  40:    */   
/*  41:    */   private ArrayListMultimap()
/*  42:    */   {
/*  43:105 */     super(new HashMap());
/*  44:106 */     this.expectedValuesPerKey = 3;
/*  45:    */   }
/*  46:    */   
/*  47:    */   private ArrayListMultimap(int expectedKeys, int expectedValuesPerKey)
/*  48:    */   {
/*  49:110 */     super(Maps.newHashMapWithExpectedSize(expectedKeys));
/*  50:111 */     CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/*  51:112 */     this.expectedValuesPerKey = expectedValuesPerKey;
/*  52:    */   }
/*  53:    */   
/*  54:    */   private ArrayListMultimap(Multimap<? extends K, ? extends V> multimap)
/*  55:    */   {
/*  56:116 */     this(multimap.keySet().size(), (multimap instanceof ArrayListMultimap) ? ((ArrayListMultimap)multimap).expectedValuesPerKey : 3);
/*  57:    */     
/*  58:    */ 
/*  59:    */ 
/*  60:    */ 
/*  61:121 */     putAll(multimap);
/*  62:    */   }
/*  63:    */   
/*  64:    */   List<V> createCollection()
/*  65:    */   {
/*  66:130 */     return new ArrayList(this.expectedValuesPerKey);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public void trimToSize()
/*  70:    */   {
/*  71:137 */     for (Collection<V> collection : backingMap().values())
/*  72:    */     {
/*  73:138 */       ArrayList<V> arrayList = (ArrayList)collection;
/*  74:139 */       arrayList.trimToSize();
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  79:    */   private void writeObject(ObjectOutputStream stream)
/*  80:    */     throws IOException
/*  81:    */   {
/*  82:150 */     stream.defaultWriteObject();
/*  83:151 */     Serialization.writeMultimap(this, stream);
/*  84:    */   }
/*  85:    */   
/*  86:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  87:    */   private void readObject(ObjectInputStream stream)
/*  88:    */     throws IOException, ClassNotFoundException
/*  89:    */   {
/*  90:156 */     stream.defaultReadObject();
/*  91:157 */     this.expectedValuesPerKey = 3;
/*  92:158 */     int distinctKeys = Serialization.readCount(stream);
/*  93:159 */     Map<K, Collection<V>> map = Maps.newHashMap();
/*  94:160 */     setMap(map);
/*  95:161 */     Serialization.populateMultimap(this, stream, distinctKeys);
/*  96:    */   }
/*  97:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ArrayListMultimap
 * JD-Core Version:    0.7.0.1
 */