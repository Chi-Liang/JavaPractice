/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.ObjectInputStream;
/*   9:    */ import java.io.ObjectOutputStream;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.HashMap;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Set;
/*  14:    */ 
/*  15:    */ @GwtCompatible(serializable=true, emulated=true)
/*  16:    */ public final class HashMultimap<K, V>
/*  17:    */   extends AbstractSetMultimap<K, V>
/*  18:    */ {
/*  19:    */   private static final int DEFAULT_VALUES_PER_KEY = 2;
/*  20:    */   @VisibleForTesting
/*  21: 53 */   transient int expectedValuesPerKey = 2;
/*  22:    */   @GwtIncompatible("Not needed in emulated source")
/*  23:    */   private static final long serialVersionUID = 0L;
/*  24:    */   
/*  25:    */   public static <K, V> HashMultimap<K, V> create()
/*  26:    */   {
/*  27: 60 */     return new HashMultimap();
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <K, V> HashMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey)
/*  31:    */   {
/*  32: 73 */     return new HashMultimap(expectedKeys, expectedValuesPerKey);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <K, V> HashMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*  36:    */   {
/*  37: 84 */     return new HashMultimap(multimap);
/*  38:    */   }
/*  39:    */   
/*  40:    */   private HashMultimap()
/*  41:    */   {
/*  42: 88 */     super(new HashMap());
/*  43:    */   }
/*  44:    */   
/*  45:    */   private HashMultimap(int expectedKeys, int expectedValuesPerKey)
/*  46:    */   {
/*  47: 92 */     super(Maps.newHashMapWithExpectedSize(expectedKeys));
/*  48: 93 */     Preconditions.checkArgument(expectedValuesPerKey >= 0);
/*  49: 94 */     this.expectedValuesPerKey = expectedValuesPerKey;
/*  50:    */   }
/*  51:    */   
/*  52:    */   private HashMultimap(Multimap<? extends K, ? extends V> multimap)
/*  53:    */   {
/*  54: 98 */     super(Maps.newHashMapWithExpectedSize(multimap.keySet().size()));
/*  55: 99 */     putAll(multimap);
/*  56:    */   }
/*  57:    */   
/*  58:    */   Set<V> createCollection()
/*  59:    */   {
/*  60:111 */     return Sets.newHashSetWithExpectedSize(this.expectedValuesPerKey);
/*  61:    */   }
/*  62:    */   
/*  63:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  64:    */   private void writeObject(ObjectOutputStream stream)
/*  65:    */     throws IOException
/*  66:    */   {
/*  67:121 */     stream.defaultWriteObject();
/*  68:122 */     Serialization.writeMultimap(this, stream);
/*  69:    */   }
/*  70:    */   
/*  71:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  72:    */   private void readObject(ObjectInputStream stream)
/*  73:    */     throws IOException, ClassNotFoundException
/*  74:    */   {
/*  75:127 */     stream.defaultReadObject();
/*  76:128 */     this.expectedValuesPerKey = 2;
/*  77:129 */     int distinctKeys = Serialization.readCount(stream);
/*  78:130 */     Map<K, Collection<V>> map = Maps.newHashMap();
/*  79:131 */     setMap(map);
/*  80:132 */     Serialization.populateMultimap(this, stream, distinctKeys);
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.HashMultimap
 * JD-Core Version:    0.7.0.1
 */