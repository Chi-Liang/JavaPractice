/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Objects;
/*  5:   */ import com.google.common.base.Preconditions;
/*  6:   */ import com.google.common.base.Predicate;
/*  7:   */ import com.google.common.base.Predicates;
/*  8:   */ import com.google.j2objc.annotations.Weak;
/*  9:   */ import java.util.AbstractCollection;
/* 10:   */ import java.util.Collection;
/* 11:   */ import java.util.Iterator;
/* 12:   */ import java.util.Map.Entry;
/* 13:   */ import javax.annotation.Nullable;
/* 14:   */ 
/* 15:   */ @GwtCompatible
/* 16:   */ final class FilteredMultimapValues<K, V>
/* 17:   */   extends AbstractCollection<V>
/* 18:   */ {
/* 19:   */   @Weak
/* 20:   */   private final FilteredMultimap<K, V> multimap;
/* 21:   */   
/* 22:   */   FilteredMultimapValues(FilteredMultimap<K, V> multimap)
/* 23:   */   {
/* 24:43 */     this.multimap = ((FilteredMultimap)Preconditions.checkNotNull(multimap));
/* 25:   */   }
/* 26:   */   
/* 27:   */   public Iterator<V> iterator()
/* 28:   */   {
/* 29:48 */     return Maps.valueIterator(this.multimap.entries().iterator());
/* 30:   */   }
/* 31:   */   
/* 32:   */   public boolean contains(@Nullable Object o)
/* 33:   */   {
/* 34:53 */     return this.multimap.containsValue(o);
/* 35:   */   }
/* 36:   */   
/* 37:   */   public int size()
/* 38:   */   {
/* 39:58 */     return this.multimap.size();
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean remove(@Nullable Object o)
/* 43:   */   {
/* 44:63 */     Predicate<? super Map.Entry<K, V>> entryPredicate = this.multimap.entryPredicate();
/* 45:64 */     Iterator<Map.Entry<K, V>> unfilteredItr = this.multimap.unfiltered().entries().iterator();
/* 46:65 */     while (unfilteredItr.hasNext())
/* 47:   */     {
/* 48:66 */       Map.Entry<K, V> entry = (Map.Entry)unfilteredItr.next();
/* 49:67 */       if ((entryPredicate.apply(entry)) && (Objects.equal(entry.getValue(), o)))
/* 50:   */       {
/* 51:68 */         unfilteredItr.remove();
/* 52:69 */         return true;
/* 53:   */       }
/* 54:   */     }
/* 55:72 */     return false;
/* 56:   */   }
/* 57:   */   
/* 58:   */   public boolean removeAll(Collection<?> c)
/* 59:   */   {
/* 60:77 */     return Iterables.removeIf(this.multimap.unfiltered().entries(), Predicates.and(this.multimap.entryPredicate(), Maps.valuePredicateOnEntries(Predicates.in(c))));
/* 61:   */   }
/* 62:   */   
/* 63:   */   public boolean retainAll(Collection<?> c)
/* 64:   */   {
/* 65:86 */     return Iterables.removeIf(this.multimap.unfiltered().entries(), Predicates.and(this.multimap.entryPredicate(), Maps.valuePredicateOnEntries(Predicates.not(Predicates.in(c)))));
/* 66:   */   }
/* 67:   */   
/* 68:   */   public void clear()
/* 69:   */   {
/* 70:96 */     this.multimap.clear();
/* 71:   */   }
/* 72:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.FilteredMultimapValues
 * JD-Core Version:    0.7.0.1
 */