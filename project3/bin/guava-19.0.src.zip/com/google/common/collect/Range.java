/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Predicate;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.Comparator;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.SortedSet;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ 
/*  13:    */ @GwtCompatible
/*  14:    */ public final class Range<C extends Comparable>
/*  15:    */   implements Predicate<C>, Serializable
/*  16:    */ {
/*  17:117 */   private static final Function<Range, Cut> LOWER_BOUND_FN = new Function()
/*  18:    */   {
/*  19:    */     public Cut apply(Range range)
/*  20:    */     {
/*  21:121 */       return range.lowerBound;
/*  22:    */     }
/*  23:    */   };
/*  24:    */   
/*  25:    */   static <C extends Comparable<?>> Function<Range<C>, Cut<C>> lowerBoundFn()
/*  26:    */   {
/*  27:127 */     return LOWER_BOUND_FN;
/*  28:    */   }
/*  29:    */   
/*  30:130 */   private static final Function<Range, Cut> UPPER_BOUND_FN = new Function()
/*  31:    */   {
/*  32:    */     public Cut apply(Range range)
/*  33:    */     {
/*  34:134 */       return range.upperBound;
/*  35:    */     }
/*  36:    */   };
/*  37:    */   
/*  38:    */   static <C extends Comparable<?>> Function<Range<C>, Cut<C>> upperBoundFn()
/*  39:    */   {
/*  40:140 */     return UPPER_BOUND_FN;
/*  41:    */   }
/*  42:    */   
/*  43:143 */   static final Ordering<Range<?>> RANGE_LEX_ORDERING = new RangeLexOrdering(null);
/*  44:    */   
/*  45:    */   static <C extends Comparable<?>> Range<C> create(Cut<C> lowerBound, Cut<C> upperBound)
/*  46:    */   {
/*  47:146 */     return new Range(lowerBound, upperBound);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static <C extends Comparable<?>> Range<C> open(C lower, C upper)
/*  51:    */   {
/*  52:158 */     return create(Cut.aboveValue(lower), Cut.belowValue(upper));
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static <C extends Comparable<?>> Range<C> closed(C lower, C upper)
/*  56:    */   {
/*  57:170 */     return create(Cut.belowValue(lower), Cut.aboveValue(upper));
/*  58:    */   }
/*  59:    */   
/*  60:    */   public static <C extends Comparable<?>> Range<C> closedOpen(C lower, C upper)
/*  61:    */   {
/*  62:182 */     return create(Cut.belowValue(lower), Cut.belowValue(upper));
/*  63:    */   }
/*  64:    */   
/*  65:    */   public static <C extends Comparable<?>> Range<C> openClosed(C lower, C upper)
/*  66:    */   {
/*  67:194 */     return create(Cut.aboveValue(lower), Cut.aboveValue(upper));
/*  68:    */   }
/*  69:    */   
/*  70:    */   public static <C extends Comparable<?>> Range<C> range(C lower, BoundType lowerType, C upper, BoundType upperType)
/*  71:    */   {
/*  72:208 */     Preconditions.checkNotNull(lowerType);
/*  73:209 */     Preconditions.checkNotNull(upperType);
/*  74:    */     
/*  75:211 */     Cut<C> lowerBound = lowerType == BoundType.OPEN ? Cut.aboveValue(lower) : Cut.belowValue(lower);
/*  76:    */     
/*  77:213 */     Cut<C> upperBound = upperType == BoundType.OPEN ? Cut.belowValue(upper) : Cut.aboveValue(upper);
/*  78:    */     
/*  79:215 */     return create(lowerBound, upperBound);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static <C extends Comparable<?>> Range<C> lessThan(C endpoint)
/*  83:    */   {
/*  84:225 */     return create(Cut.belowAll(), Cut.belowValue(endpoint));
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static <C extends Comparable<?>> Range<C> atMost(C endpoint)
/*  88:    */   {
/*  89:235 */     return create(Cut.belowAll(), Cut.aboveValue(endpoint));
/*  90:    */   }
/*  91:    */   
/*  92:    */   public static <C extends Comparable<?>> Range<C> upTo(C endpoint, BoundType boundType)
/*  93:    */   {
/*  94:245 */     switch (3.$SwitchMap$com$google$common$collect$BoundType[boundType.ordinal()])
/*  95:    */     {
/*  96:    */     case 1: 
/*  97:247 */       return lessThan(endpoint);
/*  98:    */     case 2: 
/*  99:249 */       return atMost(endpoint);
/* 100:    */     }
/* 101:251 */     throw new AssertionError();
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static <C extends Comparable<?>> Range<C> greaterThan(C endpoint)
/* 105:    */   {
/* 106:262 */     return create(Cut.aboveValue(endpoint), Cut.aboveAll());
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static <C extends Comparable<?>> Range<C> atLeast(C endpoint)
/* 110:    */   {
/* 111:272 */     return create(Cut.belowValue(endpoint), Cut.aboveAll());
/* 112:    */   }
/* 113:    */   
/* 114:    */   public static <C extends Comparable<?>> Range<C> downTo(C endpoint, BoundType boundType)
/* 115:    */   {
/* 116:282 */     switch (3.$SwitchMap$com$google$common$collect$BoundType[boundType.ordinal()])
/* 117:    */     {
/* 118:    */     case 1: 
/* 119:284 */       return greaterThan(endpoint);
/* 120:    */     case 2: 
/* 121:286 */       return atLeast(endpoint);
/* 122:    */     }
/* 123:288 */     throw new AssertionError();
/* 124:    */   }
/* 125:    */   
/* 126:292 */   private static final Range<Comparable> ALL = new Range(Cut.belowAll(), Cut.aboveAll());
/* 127:    */   final Cut<C> lowerBound;
/* 128:    */   final Cut<C> upperBound;
/* 129:    */   private static final long serialVersionUID = 0L;
/* 130:    */   
/* 131:    */   public static <C extends Comparable<?>> Range<C> all()
/* 132:    */   {
/* 133:302 */     return ALL;
/* 134:    */   }
/* 135:    */   
/* 136:    */   public static <C extends Comparable<?>> Range<C> singleton(C value)
/* 137:    */   {
/* 138:313 */     return closed(value, value);
/* 139:    */   }
/* 140:    */   
/* 141:    */   public static <C extends Comparable<?>> Range<C> encloseAll(Iterable<C> values)
/* 142:    */   {
/* 143:328 */     Preconditions.checkNotNull(values);
/* 144:329 */     if ((values instanceof ContiguousSet)) {
/* 145:330 */       return ((ContiguousSet)values).range();
/* 146:    */     }
/* 147:332 */     Iterator<C> valueIterator = values.iterator();
/* 148:333 */     C min = (Comparable)Preconditions.checkNotNull(valueIterator.next());
/* 149:334 */     C max = min;
/* 150:335 */     while (valueIterator.hasNext())
/* 151:    */     {
/* 152:336 */       C value = (Comparable)Preconditions.checkNotNull(valueIterator.next());
/* 153:337 */       min = (Comparable)Ordering.natural().min(min, value);
/* 154:338 */       max = (Comparable)Ordering.natural().max(max, value);
/* 155:    */     }
/* 156:340 */     return closed(min, max);
/* 157:    */   }
/* 158:    */   
/* 159:    */   private Range(Cut<C> lowerBound, Cut<C> upperBound)
/* 160:    */   {
/* 161:347 */     this.lowerBound = ((Cut)Preconditions.checkNotNull(lowerBound));
/* 162:348 */     this.upperBound = ((Cut)Preconditions.checkNotNull(upperBound));
/* 163:349 */     if ((lowerBound.compareTo(upperBound) > 0) || (lowerBound == Cut.aboveAll()) || (upperBound == Cut.belowAll())) {
/* 164:352 */       throw new IllegalArgumentException("Invalid range: " + toString(lowerBound, upperBound));
/* 165:    */     }
/* 166:    */   }
/* 167:    */   
/* 168:    */   public boolean hasLowerBound()
/* 169:    */   {
/* 170:360 */     return this.lowerBound != Cut.belowAll();
/* 171:    */   }
/* 172:    */   
/* 173:    */   public C lowerEndpoint()
/* 174:    */   {
/* 175:370 */     return this.lowerBound.endpoint();
/* 176:    */   }
/* 177:    */   
/* 178:    */   public BoundType lowerBoundType()
/* 179:    */   {
/* 180:381 */     return this.lowerBound.typeAsLowerBound();
/* 181:    */   }
/* 182:    */   
/* 183:    */   public boolean hasUpperBound()
/* 184:    */   {
/* 185:388 */     return this.upperBound != Cut.aboveAll();
/* 186:    */   }
/* 187:    */   
/* 188:    */   public C upperEndpoint()
/* 189:    */   {
/* 190:398 */     return this.upperBound.endpoint();
/* 191:    */   }
/* 192:    */   
/* 193:    */   public BoundType upperBoundType()
/* 194:    */   {
/* 195:409 */     return this.upperBound.typeAsUpperBound();
/* 196:    */   }
/* 197:    */   
/* 198:    */   public boolean isEmpty()
/* 199:    */   {
/* 200:422 */     return this.lowerBound.equals(this.upperBound);
/* 201:    */   }
/* 202:    */   
/* 203:    */   public boolean contains(C value)
/* 204:    */   {
/* 205:431 */     Preconditions.checkNotNull(value);
/* 206:    */     
/* 207:433 */     return (this.lowerBound.isLessThan(value)) && (!this.upperBound.isLessThan(value));
/* 208:    */   }
/* 209:    */   
/* 210:    */   @Deprecated
/* 211:    */   public boolean apply(C input)
/* 212:    */   {
/* 213:443 */     return contains(input);
/* 214:    */   }
/* 215:    */   
/* 216:    */   public boolean containsAll(Iterable<? extends C> values)
/* 217:    */   {
/* 218:451 */     if (Iterables.isEmpty(values)) {
/* 219:452 */       return true;
/* 220:    */     }
/* 221:456 */     if ((values instanceof SortedSet))
/* 222:    */     {
/* 223:457 */       SortedSet<? extends C> set = cast(values);
/* 224:458 */       Comparator<?> comparator = set.comparator();
/* 225:459 */       if ((Ordering.natural().equals(comparator)) || (comparator == null)) {
/* 226:460 */         return (contains((Comparable)set.first())) && (contains((Comparable)set.last()));
/* 227:    */       }
/* 228:    */     }
/* 229:464 */     for (C value : values) {
/* 230:465 */       if (!contains(value)) {
/* 231:466 */         return false;
/* 232:    */       }
/* 233:    */     }
/* 234:469 */     return true;
/* 235:    */   }
/* 236:    */   
/* 237:    */   public boolean encloses(Range<C> other)
/* 238:    */   {
/* 239:497 */     return (this.lowerBound.compareTo(other.lowerBound) <= 0) && (this.upperBound.compareTo(other.upperBound) >= 0);
/* 240:    */   }
/* 241:    */   
/* 242:    */   public boolean isConnected(Range<C> other)
/* 243:    */   {
/* 244:526 */     return (this.lowerBound.compareTo(other.upperBound) <= 0) && (other.lowerBound.compareTo(this.upperBound) <= 0);
/* 245:    */   }
/* 246:    */   
/* 247:    */   public Range<C> intersection(Range<C> connectedRange)
/* 248:    */   {
/* 249:547 */     int lowerCmp = this.lowerBound.compareTo(connectedRange.lowerBound);
/* 250:548 */     int upperCmp = this.upperBound.compareTo(connectedRange.upperBound);
/* 251:549 */     if ((lowerCmp >= 0) && (upperCmp <= 0)) {
/* 252:550 */       return this;
/* 253:    */     }
/* 254:551 */     if ((lowerCmp <= 0) && (upperCmp >= 0)) {
/* 255:552 */       return connectedRange;
/* 256:    */     }
/* 257:554 */     Cut<C> newLower = lowerCmp >= 0 ? this.lowerBound : connectedRange.lowerBound;
/* 258:555 */     Cut<C> newUpper = upperCmp <= 0 ? this.upperBound : connectedRange.upperBound;
/* 259:556 */     return create(newLower, newUpper);
/* 260:    */   }
/* 261:    */   
/* 262:    */   public Range<C> span(Range<C> other)
/* 263:    */   {
/* 264:572 */     int lowerCmp = this.lowerBound.compareTo(other.lowerBound);
/* 265:573 */     int upperCmp = this.upperBound.compareTo(other.upperBound);
/* 266:574 */     if ((lowerCmp <= 0) && (upperCmp >= 0)) {
/* 267:575 */       return this;
/* 268:    */     }
/* 269:576 */     if ((lowerCmp >= 0) && (upperCmp <= 0)) {
/* 270:577 */       return other;
/* 271:    */     }
/* 272:579 */     Cut<C> newLower = lowerCmp <= 0 ? this.lowerBound : other.lowerBound;
/* 273:580 */     Cut<C> newUpper = upperCmp >= 0 ? this.upperBound : other.upperBound;
/* 274:581 */     return create(newLower, newUpper);
/* 275:    */   }
/* 276:    */   
/* 277:    */   public Range<C> canonical(DiscreteDomain<C> domain)
/* 278:    */   {
/* 279:610 */     Preconditions.checkNotNull(domain);
/* 280:611 */     Cut<C> lower = this.lowerBound.canonical(domain);
/* 281:612 */     Cut<C> upper = this.upperBound.canonical(domain);
/* 282:613 */     return (lower == this.lowerBound) && (upper == this.upperBound) ? this : create(lower, upper);
/* 283:    */   }
/* 284:    */   
/* 285:    */   public boolean equals(@Nullable Object object)
/* 286:    */   {
/* 287:625 */     if ((object instanceof Range))
/* 288:    */     {
/* 289:626 */       Range<?> other = (Range)object;
/* 290:627 */       return (this.lowerBound.equals(other.lowerBound)) && (this.upperBound.equals(other.upperBound));
/* 291:    */     }
/* 292:629 */     return false;
/* 293:    */   }
/* 294:    */   
/* 295:    */   public int hashCode()
/* 296:    */   {
/* 297:635 */     return this.lowerBound.hashCode() * 31 + this.upperBound.hashCode();
/* 298:    */   }
/* 299:    */   
/* 300:    */   public String toString()
/* 301:    */   {
/* 302:644 */     return toString(this.lowerBound, this.upperBound);
/* 303:    */   }
/* 304:    */   
/* 305:    */   private static String toString(Cut<?> lowerBound, Cut<?> upperBound)
/* 306:    */   {
/* 307:648 */     StringBuilder sb = new StringBuilder(16);
/* 308:649 */     lowerBound.describeAsLowerBound(sb);
/* 309:650 */     sb.append('‥');
/* 310:651 */     upperBound.describeAsUpperBound(sb);
/* 311:652 */     return sb.toString();
/* 312:    */   }
/* 313:    */   
/* 314:    */   private static <T> SortedSet<T> cast(Iterable<T> iterable)
/* 315:    */   {
/* 316:659 */     return (SortedSet)iterable;
/* 317:    */   }
/* 318:    */   
/* 319:    */   Object readResolve()
/* 320:    */   {
/* 321:663 */     if (equals(ALL)) {
/* 322:664 */       return all();
/* 323:    */     }
/* 324:666 */     return this;
/* 325:    */   }
/* 326:    */   
/* 327:    */   static int compareOrThrow(Comparable left, Comparable right)
/* 328:    */   {
/* 329:672 */     return left.compareTo(right);
/* 330:    */   }
/* 331:    */   
/* 332:    */   private static class RangeLexOrdering
/* 333:    */     extends Ordering<Range<?>>
/* 334:    */     implements Serializable
/* 335:    */   {
/* 336:    */     private static final long serialVersionUID = 0L;
/* 337:    */     
/* 338:    */     public int compare(Range<?> left, Range<?> right)
/* 339:    */     {
/* 340:682 */       return ComparisonChain.start().compare(left.lowerBound, right.lowerBound).compare(left.upperBound, right.upperBound).result();
/* 341:    */     }
/* 342:    */   }
/* 343:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Range
 * JD-Core Version:    0.7.0.1
 */