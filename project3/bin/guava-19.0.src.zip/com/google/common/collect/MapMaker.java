/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Ascii;
/*   6:    */ import com.google.common.base.Equivalence;
/*   7:    */ import com.google.common.base.Function;
/*   8:    */ import com.google.common.base.MoreObjects;
/*   9:    */ import com.google.common.base.MoreObjects.ToStringHelper;
/*  10:    */ import com.google.common.base.Preconditions;
/*  11:    */ import com.google.common.base.Throwables;
/*  12:    */ import com.google.common.base.Ticker;
/*  13:    */ import java.io.Serializable;
/*  14:    */ import java.util.AbstractMap;
/*  15:    */ import java.util.Collections;
/*  16:    */ import java.util.Map.Entry;
/*  17:    */ import java.util.Set;
/*  18:    */ import java.util.concurrent.ConcurrentHashMap;
/*  19:    */ import java.util.concurrent.ConcurrentMap;
/*  20:    */ import java.util.concurrent.ExecutionException;
/*  21:    */ import java.util.concurrent.TimeUnit;
/*  22:    */ import javax.annotation.Nullable;
/*  23:    */ 
/*  24:    */ @GwtCompatible(emulated=true)
/*  25:    */ public final class MapMaker
/*  26:    */   extends GenericMapMaker<Object, Object>
/*  27:    */ {
/*  28:    */   private static final int DEFAULT_INITIAL_CAPACITY = 16;
/*  29:    */   private static final int DEFAULT_CONCURRENCY_LEVEL = 4;
/*  30:    */   private static final int DEFAULT_EXPIRATION_NANOS = 0;
/*  31:    */   static final int UNSET_INT = -1;
/*  32:    */   boolean useCustomMap;
/*  33:115 */   int initialCapacity = -1;
/*  34:116 */   int concurrencyLevel = -1;
/*  35:117 */   int maximumSize = -1;
/*  36:    */   MapMakerInternalMap.Strength keyStrength;
/*  37:    */   MapMakerInternalMap.Strength valueStrength;
/*  38:122 */   long expireAfterWriteNanos = -1L;
/*  39:123 */   long expireAfterAccessNanos = -1L;
/*  40:    */   RemovalCause nullRemovalCause;
/*  41:    */   Equivalence<Object> keyEquivalence;
/*  42:    */   Ticker ticker;
/*  43:    */   
/*  44:    */   @GwtIncompatible("To be supported")
/*  45:    */   MapMaker keyEquivalence(Equivalence<Object> equivalence)
/*  46:    */   {
/*  47:147 */     Preconditions.checkState(this.keyEquivalence == null, "key equivalence was already set to %s", new Object[] { this.keyEquivalence });
/*  48:148 */     this.keyEquivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/*  49:149 */     this.useCustomMap = true;
/*  50:150 */     return this;
/*  51:    */   }
/*  52:    */   
/*  53:    */   Equivalence<Object> getKeyEquivalence()
/*  54:    */   {
/*  55:154 */     return (Equivalence)MoreObjects.firstNonNull(this.keyEquivalence, getKeyStrength().defaultEquivalence());
/*  56:    */   }
/*  57:    */   
/*  58:    */   public MapMaker initialCapacity(int initialCapacity)
/*  59:    */   {
/*  60:169 */     Preconditions.checkState(this.initialCapacity == -1, "initial capacity was already set to %s", new Object[] { Integer.valueOf(this.initialCapacity) });
/*  61:    */     
/*  62:    */ 
/*  63:    */ 
/*  64:173 */     Preconditions.checkArgument(initialCapacity >= 0);
/*  65:174 */     this.initialCapacity = initialCapacity;
/*  66:175 */     return this;
/*  67:    */   }
/*  68:    */   
/*  69:    */   int getInitialCapacity()
/*  70:    */   {
/*  71:179 */     return this.initialCapacity == -1 ? 16 : this.initialCapacity;
/*  72:    */   }
/*  73:    */   
/*  74:    */   @Deprecated
/*  75:    */   MapMaker maximumSize(int size)
/*  76:    */   {
/*  77:208 */     Preconditions.checkState(this.maximumSize == -1, "maximum size was already set to %s", new Object[] { Integer.valueOf(this.maximumSize) });
/*  78:    */     
/*  79:    */ 
/*  80:    */ 
/*  81:212 */     Preconditions.checkArgument(size >= 0, "maximum size must not be negative");
/*  82:213 */     this.maximumSize = size;
/*  83:214 */     this.useCustomMap = true;
/*  84:215 */     if (this.maximumSize == 0) {
/*  85:217 */       this.nullRemovalCause = RemovalCause.SIZE;
/*  86:    */     }
/*  87:219 */     return this;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public MapMaker concurrencyLevel(int concurrencyLevel)
/*  91:    */   {
/*  92:243 */     Preconditions.checkState(this.concurrencyLevel == -1, "concurrency level was already set to %s", new Object[] { Integer.valueOf(this.concurrencyLevel) });
/*  93:    */     
/*  94:    */ 
/*  95:    */ 
/*  96:247 */     Preconditions.checkArgument(concurrencyLevel > 0);
/*  97:248 */     this.concurrencyLevel = concurrencyLevel;
/*  98:249 */     return this;
/*  99:    */   }
/* 100:    */   
/* 101:    */   int getConcurrencyLevel()
/* 102:    */   {
/* 103:253 */     return this.concurrencyLevel == -1 ? 4 : this.concurrencyLevel;
/* 104:    */   }
/* 105:    */   
/* 106:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/* 107:    */   public MapMaker weakKeys()
/* 108:    */   {
/* 109:270 */     return setKeyStrength(MapMakerInternalMap.Strength.WEAK);
/* 110:    */   }
/* 111:    */   
/* 112:    */   MapMaker setKeyStrength(MapMakerInternalMap.Strength strength)
/* 113:    */   {
/* 114:274 */     Preconditions.checkState(this.keyStrength == null, "Key strength was already set to %s", new Object[] { this.keyStrength });
/* 115:275 */     this.keyStrength = ((MapMakerInternalMap.Strength)Preconditions.checkNotNull(strength));
/* 116:276 */     Preconditions.checkArgument(this.keyStrength != MapMakerInternalMap.Strength.SOFT, "Soft keys are not supported");
/* 117:277 */     if (strength != MapMakerInternalMap.Strength.STRONG) {
/* 118:279 */       this.useCustomMap = true;
/* 119:    */     }
/* 120:281 */     return this;
/* 121:    */   }
/* 122:    */   
/* 123:    */   MapMakerInternalMap.Strength getKeyStrength()
/* 124:    */   {
/* 125:285 */     return (MapMakerInternalMap.Strength)MoreObjects.firstNonNull(this.keyStrength, MapMakerInternalMap.Strength.STRONG);
/* 126:    */   }
/* 127:    */   
/* 128:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/* 129:    */   public MapMaker weakValues()
/* 130:    */   {
/* 131:308 */     return setValueStrength(MapMakerInternalMap.Strength.WEAK);
/* 132:    */   }
/* 133:    */   
/* 134:    */   @Deprecated
/* 135:    */   @GwtIncompatible("java.lang.ref.SoftReference")
/* 136:    */   MapMaker softValues()
/* 137:    */   {
/* 138:339 */     return setValueStrength(MapMakerInternalMap.Strength.SOFT);
/* 139:    */   }
/* 140:    */   
/* 141:    */   MapMaker setValueStrength(MapMakerInternalMap.Strength strength)
/* 142:    */   {
/* 143:343 */     Preconditions.checkState(this.valueStrength == null, "Value strength was already set to %s", new Object[] { this.valueStrength });
/* 144:344 */     this.valueStrength = ((MapMakerInternalMap.Strength)Preconditions.checkNotNull(strength));
/* 145:345 */     if (strength != MapMakerInternalMap.Strength.STRONG) {
/* 146:347 */       this.useCustomMap = true;
/* 147:    */     }
/* 148:349 */     return this;
/* 149:    */   }
/* 150:    */   
/* 151:    */   MapMakerInternalMap.Strength getValueStrength()
/* 152:    */   {
/* 153:353 */     return (MapMakerInternalMap.Strength)MoreObjects.firstNonNull(this.valueStrength, MapMakerInternalMap.Strength.STRONG);
/* 154:    */   }
/* 155:    */   
/* 156:    */   @Deprecated
/* 157:    */   MapMaker expireAfterWrite(long duration, TimeUnit unit)
/* 158:    */   {
/* 159:384 */     checkExpiration(duration, unit);
/* 160:385 */     this.expireAfterWriteNanos = unit.toNanos(duration);
/* 161:386 */     if ((duration == 0L) && (this.nullRemovalCause == null)) {
/* 162:388 */       this.nullRemovalCause = RemovalCause.EXPIRED;
/* 163:    */     }
/* 164:390 */     this.useCustomMap = true;
/* 165:391 */     return this;
/* 166:    */   }
/* 167:    */   
/* 168:    */   private void checkExpiration(long duration, TimeUnit unit)
/* 169:    */   {
/* 170:395 */     Preconditions.checkState(this.expireAfterWriteNanos == -1L, "expireAfterWrite was already set to %s ns", new Object[] { Long.valueOf(this.expireAfterWriteNanos) });
/* 171:    */     
/* 172:    */ 
/* 173:    */ 
/* 174:399 */     Preconditions.checkState(this.expireAfterAccessNanos == -1L, "expireAfterAccess was already set to %s ns", new Object[] { Long.valueOf(this.expireAfterAccessNanos) });
/* 175:    */     
/* 176:    */ 
/* 177:    */ 
/* 178:403 */     Preconditions.checkArgument(duration >= 0L, "duration cannot be negative: %s %s", new Object[] { Long.valueOf(duration), unit });
/* 179:    */   }
/* 180:    */   
/* 181:    */   long getExpireAfterWriteNanos()
/* 182:    */   {
/* 183:407 */     return this.expireAfterWriteNanos == -1L ? 0L : this.expireAfterWriteNanos;
/* 184:    */   }
/* 185:    */   
/* 186:    */   @Deprecated
/* 187:    */   @GwtIncompatible("To be supported")
/* 188:    */   MapMaker expireAfterAccess(long duration, TimeUnit unit)
/* 189:    */   {
/* 190:439 */     checkExpiration(duration, unit);
/* 191:440 */     this.expireAfterAccessNanos = unit.toNanos(duration);
/* 192:441 */     if ((duration == 0L) && (this.nullRemovalCause == null)) {
/* 193:443 */       this.nullRemovalCause = RemovalCause.EXPIRED;
/* 194:    */     }
/* 195:445 */     this.useCustomMap = true;
/* 196:446 */     return this;
/* 197:    */   }
/* 198:    */   
/* 199:    */   long getExpireAfterAccessNanos()
/* 200:    */   {
/* 201:450 */     return this.expireAfterAccessNanos == -1L ? 0L : this.expireAfterAccessNanos;
/* 202:    */   }
/* 203:    */   
/* 204:    */   Ticker getTicker()
/* 205:    */   {
/* 206:456 */     return (Ticker)MoreObjects.firstNonNull(this.ticker, Ticker.systemTicker());
/* 207:    */   }
/* 208:    */   
/* 209:    */   @Deprecated
/* 210:    */   @GwtIncompatible("To be supported")
/* 211:    */   <K, V> GenericMapMaker<K, V> removalListener(RemovalListener<K, V> listener)
/* 212:    */   {
/* 213:491 */     Preconditions.checkState(this.removalListener == null);
/* 214:    */     
/* 215:    */ 
/* 216:    */ 
/* 217:495 */     GenericMapMaker<K, V> me = this;
/* 218:496 */     me.removalListener = ((RemovalListener)Preconditions.checkNotNull(listener));
/* 219:497 */     this.useCustomMap = true;
/* 220:498 */     return me;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public <K, V> ConcurrentMap<K, V> makeMap()
/* 224:    */   {
/* 225:514 */     if (!this.useCustomMap) {
/* 226:515 */       return new ConcurrentHashMap(getInitialCapacity(), 0.75F, getConcurrencyLevel());
/* 227:    */     }
/* 228:517 */     return (ConcurrentMap)(this.nullRemovalCause == null ? new MapMakerInternalMap(this) : new NullConcurrentMap(this));
/* 229:    */   }
/* 230:    */   
/* 231:    */   @GwtIncompatible("MapMakerInternalMap")
/* 232:    */   <K, V> MapMakerInternalMap<K, V> makeCustomMap()
/* 233:    */   {
/* 234:529 */     return new MapMakerInternalMap(this);
/* 235:    */   }
/* 236:    */   
/* 237:    */   @Deprecated
/* 238:    */   <K, V> ConcurrentMap<K, V> makeComputingMap(Function<? super K, ? extends V> computingFunction)
/* 239:    */   {
/* 240:592 */     return (ConcurrentMap)(this.nullRemovalCause == null ? new ComputingMapAdapter(this, computingFunction) : new NullComputingConcurrentMap(this, computingFunction));
/* 241:    */   }
/* 242:    */   
/* 243:    */   public String toString()
/* 244:    */   {
/* 245:603 */     MoreObjects.ToStringHelper s = MoreObjects.toStringHelper(this);
/* 246:604 */     if (this.initialCapacity != -1) {
/* 247:605 */       s.add("initialCapacity", this.initialCapacity);
/* 248:    */     }
/* 249:607 */     if (this.concurrencyLevel != -1) {
/* 250:608 */       s.add("concurrencyLevel", this.concurrencyLevel);
/* 251:    */     }
/* 252:610 */     if (this.maximumSize != -1) {
/* 253:611 */       s.add("maximumSize", this.maximumSize);
/* 254:    */     }
/* 255:613 */     if (this.expireAfterWriteNanos != -1L) {
/* 256:614 */       s.add("expireAfterWrite", this.expireAfterWriteNanos + "ns");
/* 257:    */     }
/* 258:616 */     if (this.expireAfterAccessNanos != -1L) {
/* 259:617 */       s.add("expireAfterAccess", this.expireAfterAccessNanos + "ns");
/* 260:    */     }
/* 261:619 */     if (this.keyStrength != null) {
/* 262:620 */       s.add("keyStrength", Ascii.toLowerCase(this.keyStrength.toString()));
/* 263:    */     }
/* 264:622 */     if (this.valueStrength != null) {
/* 265:623 */       s.add("valueStrength", Ascii.toLowerCase(this.valueStrength.toString()));
/* 266:    */     }
/* 267:625 */     if (this.keyEquivalence != null) {
/* 268:626 */       s.addValue("keyEquivalence");
/* 269:    */     }
/* 270:628 */     if (this.removalListener != null) {
/* 271:629 */       s.addValue("removalListener");
/* 272:    */     }
/* 273:631 */     return s.toString();
/* 274:    */   }
/* 275:    */   
/* 276:    */   static abstract interface RemovalListener<K, V>
/* 277:    */   {
/* 278:    */     public abstract void onRemoval(MapMaker.RemovalNotification<K, V> paramRemovalNotification);
/* 279:    */   }
/* 280:    */   
/* 281:    */   static final class RemovalNotification<K, V>
/* 282:    */     extends ImmutableEntry<K, V>
/* 283:    */   {
/* 284:    */     private static final long serialVersionUID = 0L;
/* 285:    */     private final MapMaker.RemovalCause cause;
/* 286:    */     
/* 287:    */     RemovalNotification(@Nullable K key, @Nullable V value, MapMaker.RemovalCause cause)
/* 288:    */     {
/* 289:669 */       super(value);
/* 290:670 */       this.cause = cause;
/* 291:    */     }
/* 292:    */     
/* 293:    */     public MapMaker.RemovalCause getCause()
/* 294:    */     {
/* 295:677 */       return this.cause;
/* 296:    */     }
/* 297:    */     
/* 298:    */     public boolean wasEvicted()
/* 299:    */     {
/* 300:685 */       return this.cause.wasEvicted();
/* 301:    */     }
/* 302:    */   }
/* 303:    */   
/* 304:    */   static abstract enum RemovalCause
/* 305:    */   {
/* 306:697 */     EXPLICIT,  REPLACED,  COLLECTED,  EXPIRED,  SIZE;
/* 307:    */     
/* 308:    */     private RemovalCause() {}
/* 309:    */     
/* 310:    */     abstract boolean wasEvicted();
/* 311:    */   }
/* 312:    */   
/* 313:    */   static class NullConcurrentMap<K, V>
/* 314:    */     extends AbstractMap<K, V>
/* 315:    */     implements ConcurrentMap<K, V>, Serializable
/* 316:    */   {
/* 317:    */     private static final long serialVersionUID = 0L;
/* 318:    */     private final MapMaker.RemovalListener<K, V> removalListener;
/* 319:    */     private final MapMaker.RemovalCause removalCause;
/* 320:    */     
/* 321:    */     NullConcurrentMap(MapMaker mapMaker)
/* 322:    */     {
/* 323:766 */       this.removalListener = mapMaker.getRemovalListener();
/* 324:767 */       this.removalCause = mapMaker.nullRemovalCause;
/* 325:    */     }
/* 326:    */     
/* 327:    */     public boolean containsKey(@Nullable Object key)
/* 328:    */     {
/* 329:774 */       return false;
/* 330:    */     }
/* 331:    */     
/* 332:    */     public boolean containsValue(@Nullable Object value)
/* 333:    */     {
/* 334:779 */       return false;
/* 335:    */     }
/* 336:    */     
/* 337:    */     public V get(@Nullable Object key)
/* 338:    */     {
/* 339:784 */       return null;
/* 340:    */     }
/* 341:    */     
/* 342:    */     void notifyRemoval(K key, V value)
/* 343:    */     {
/* 344:788 */       MapMaker.RemovalNotification<K, V> notification = new MapMaker.RemovalNotification(key, value, this.removalCause);
/* 345:    */       
/* 346:790 */       this.removalListener.onRemoval(notification);
/* 347:    */     }
/* 348:    */     
/* 349:    */     public V put(K key, V value)
/* 350:    */     {
/* 351:795 */       Preconditions.checkNotNull(key);
/* 352:796 */       Preconditions.checkNotNull(value);
/* 353:797 */       notifyRemoval(key, value);
/* 354:798 */       return null;
/* 355:    */     }
/* 356:    */     
/* 357:    */     public V putIfAbsent(K key, V value)
/* 358:    */     {
/* 359:803 */       return put(key, value);
/* 360:    */     }
/* 361:    */     
/* 362:    */     public V remove(@Nullable Object key)
/* 363:    */     {
/* 364:808 */       return null;
/* 365:    */     }
/* 366:    */     
/* 367:    */     public boolean remove(@Nullable Object key, @Nullable Object value)
/* 368:    */     {
/* 369:813 */       return false;
/* 370:    */     }
/* 371:    */     
/* 372:    */     public V replace(K key, V value)
/* 373:    */     {
/* 374:818 */       Preconditions.checkNotNull(key);
/* 375:819 */       Preconditions.checkNotNull(value);
/* 376:820 */       return null;
/* 377:    */     }
/* 378:    */     
/* 379:    */     public boolean replace(K key, @Nullable V oldValue, V newValue)
/* 380:    */     {
/* 381:825 */       Preconditions.checkNotNull(key);
/* 382:826 */       Preconditions.checkNotNull(newValue);
/* 383:827 */       return false;
/* 384:    */     }
/* 385:    */     
/* 386:    */     public Set<Map.Entry<K, V>> entrySet()
/* 387:    */     {
/* 388:832 */       return Collections.emptySet();
/* 389:    */     }
/* 390:    */   }
/* 391:    */   
/* 392:    */   static final class NullComputingConcurrentMap<K, V>
/* 393:    */     extends MapMaker.NullConcurrentMap<K, V>
/* 394:    */   {
/* 395:    */     private static final long serialVersionUID = 0L;
/* 396:    */     final Function<? super K, ? extends V> computingFunction;
/* 397:    */     
/* 398:    */     NullComputingConcurrentMap(MapMaker mapMaker, Function<? super K, ? extends V> computingFunction)
/* 399:    */     {
/* 400:844 */       super();
/* 401:845 */       this.computingFunction = ((Function)Preconditions.checkNotNull(computingFunction));
/* 402:    */     }
/* 403:    */     
/* 404:    */     public V get(Object k)
/* 405:    */     {
/* 406:851 */       K key = k;
/* 407:852 */       V value = compute(key);
/* 408:853 */       Preconditions.checkNotNull(value, "%s returned null for key %s.", new Object[] { this.computingFunction, key });
/* 409:854 */       notifyRemoval(key, value);
/* 410:855 */       return value;
/* 411:    */     }
/* 412:    */     
/* 413:    */     private V compute(K key)
/* 414:    */     {
/* 415:859 */       Preconditions.checkNotNull(key);
/* 416:    */       try
/* 417:    */       {
/* 418:861 */         return this.computingFunction.apply(key);
/* 419:    */       }
/* 420:    */       catch (ComputationException e)
/* 421:    */       {
/* 422:863 */         throw e;
/* 423:    */       }
/* 424:    */       catch (Throwable t)
/* 425:    */       {
/* 426:865 */         throw new ComputationException(t);
/* 427:    */       }
/* 428:    */     }
/* 429:    */   }
/* 430:    */   
/* 431:    */   static final class ComputingMapAdapter<K, V>
/* 432:    */     extends ComputingConcurrentHashMap<K, V>
/* 433:    */     implements Serializable
/* 434:    */   {
/* 435:    */     private static final long serialVersionUID = 0L;
/* 436:    */     
/* 437:    */     ComputingMapAdapter(MapMaker mapMaker, Function<? super K, ? extends V> computingFunction)
/* 438:    */     {
/* 439:883 */       super(computingFunction);
/* 440:    */     }
/* 441:    */     
/* 442:    */     public V get(Object key)
/* 443:    */     {
/* 444:    */       V value;
/* 445:    */       try
/* 446:    */       {
/* 447:891 */         value = getOrCompute(key);
/* 448:    */       }
/* 449:    */       catch (ExecutionException e)
/* 450:    */       {
/* 451:893 */         Throwable cause = e.getCause();
/* 452:894 */         Throwables.propagateIfInstanceOf(cause, ComputationException.class);
/* 453:895 */         throw new ComputationException(cause);
/* 454:    */       }
/* 455:898 */       if (value == null) {
/* 456:899 */         throw new NullPointerException(this.computingFunction + " returned null for key " + key + ".");
/* 457:    */       }
/* 458:901 */       return value;
/* 459:    */     }
/* 460:    */   }
/* 461:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.MapMaker
 * JD-Core Version:    0.7.0.1
 */