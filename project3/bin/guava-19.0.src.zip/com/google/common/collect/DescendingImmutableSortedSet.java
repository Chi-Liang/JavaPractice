/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtIncompatible;
/*   4:    */ import javax.annotation.Nullable;
/*   5:    */ 
/*   6:    */ class DescendingImmutableSortedSet<E>
/*   7:    */   extends ImmutableSortedSet<E>
/*   8:    */ {
/*   9:    */   private final ImmutableSortedSet<E> forward;
/*  10:    */   
/*  11:    */   DescendingImmutableSortedSet(ImmutableSortedSet<E> forward)
/*  12:    */   {
/*  13: 32 */     super(Ordering.from(forward.comparator()).reverse());
/*  14: 33 */     this.forward = forward;
/*  15:    */   }
/*  16:    */   
/*  17:    */   public boolean contains(@Nullable Object object)
/*  18:    */   {
/*  19: 38 */     return this.forward.contains(object);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public int size()
/*  23:    */   {
/*  24: 43 */     return this.forward.size();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public UnmodifiableIterator<E> iterator()
/*  28:    */   {
/*  29: 48 */     return this.forward.descendingIterator();
/*  30:    */   }
/*  31:    */   
/*  32:    */   ImmutableSortedSet<E> headSetImpl(E toElement, boolean inclusive)
/*  33:    */   {
/*  34: 53 */     return this.forward.tailSet(toElement, inclusive).descendingSet();
/*  35:    */   }
/*  36:    */   
/*  37:    */   ImmutableSortedSet<E> subSetImpl(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  38:    */   {
/*  39: 59 */     return this.forward.subSet(toElement, toInclusive, fromElement, fromInclusive).descendingSet();
/*  40:    */   }
/*  41:    */   
/*  42:    */   ImmutableSortedSet<E> tailSetImpl(E fromElement, boolean inclusive)
/*  43:    */   {
/*  44: 64 */     return this.forward.headSet(fromElement, inclusive).descendingSet();
/*  45:    */   }
/*  46:    */   
/*  47:    */   @GwtIncompatible("NavigableSet")
/*  48:    */   public ImmutableSortedSet<E> descendingSet()
/*  49:    */   {
/*  50: 70 */     return this.forward;
/*  51:    */   }
/*  52:    */   
/*  53:    */   @GwtIncompatible("NavigableSet")
/*  54:    */   public UnmodifiableIterator<E> descendingIterator()
/*  55:    */   {
/*  56: 76 */     return this.forward.iterator();
/*  57:    */   }
/*  58:    */   
/*  59:    */   @GwtIncompatible("NavigableSet")
/*  60:    */   ImmutableSortedSet<E> createDescendingSet()
/*  61:    */   {
/*  62: 82 */     throw new AssertionError("should never be called");
/*  63:    */   }
/*  64:    */   
/*  65:    */   public E lower(E element)
/*  66:    */   {
/*  67: 87 */     return this.forward.higher(element);
/*  68:    */   }
/*  69:    */   
/*  70:    */   public E floor(E element)
/*  71:    */   {
/*  72: 92 */     return this.forward.ceiling(element);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public E ceiling(E element)
/*  76:    */   {
/*  77: 97 */     return this.forward.floor(element);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public E higher(E element)
/*  81:    */   {
/*  82:102 */     return this.forward.lower(element);
/*  83:    */   }
/*  84:    */   
/*  85:    */   int indexOf(@Nullable Object target)
/*  86:    */   {
/*  87:107 */     int index = this.forward.indexOf(target);
/*  88:108 */     if (index == -1) {
/*  89:109 */       return index;
/*  90:    */     }
/*  91:111 */     return size() - 1 - index;
/*  92:    */   }
/*  93:    */   
/*  94:    */   boolean isPartialView()
/*  95:    */   {
/*  96:117 */     return this.forward.isPartialView();
/*  97:    */   }
/*  98:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.DescendingImmutableSortedSet
 * JD-Core Version:    0.7.0.1
 */