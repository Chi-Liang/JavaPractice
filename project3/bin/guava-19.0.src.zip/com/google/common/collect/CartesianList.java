/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.math.IntMath;
/*   6:    */ import java.util.AbstractList;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.ListIterator;
/*   9:    */ import java.util.RandomAccess;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ final class CartesianList<E>
/*  14:    */   extends AbstractList<List<E>>
/*  15:    */   implements RandomAccess
/*  16:    */ {
/*  17:    */   private final transient ImmutableList<List<E>> axes;
/*  18:    */   private final transient int[] axesSizeProduct;
/*  19:    */   
/*  20:    */   static <E> List<List<E>> create(List<? extends List<? extends E>> lists)
/*  21:    */   {
/*  22: 41 */     ImmutableList.Builder<List<E>> axesBuilder = new ImmutableList.Builder(lists.size());
/*  23: 42 */     for (List<? extends E> list : lists)
/*  24:    */     {
/*  25: 43 */       List<E> copy = ImmutableList.copyOf(list);
/*  26: 44 */       if (copy.isEmpty()) {
/*  27: 45 */         return ImmutableList.of();
/*  28:    */       }
/*  29: 47 */       axesBuilder.add(copy);
/*  30:    */     }
/*  31: 49 */     return new CartesianList(axesBuilder.build());
/*  32:    */   }
/*  33:    */   
/*  34:    */   CartesianList(ImmutableList<List<E>> axes)
/*  35:    */   {
/*  36: 53 */     this.axes = axes;
/*  37: 54 */     int[] axesSizeProduct = new int[axes.size() + 1];
/*  38: 55 */     axesSizeProduct[axes.size()] = 1;
/*  39:    */     try
/*  40:    */     {
/*  41: 57 */       for (int i = axes.size() - 1; i >= 0; i--) {
/*  42: 58 */         axesSizeProduct[i] = IntMath.checkedMultiply(axesSizeProduct[(i + 1)], ((List)axes.get(i)).size());
/*  43:    */       }
/*  44:    */     }
/*  45:    */     catch (ArithmeticException e)
/*  46:    */     {
/*  47: 61 */       throw new IllegalArgumentException("Cartesian product too large; must have size at most Integer.MAX_VALUE");
/*  48:    */     }
/*  49: 64 */     this.axesSizeProduct = axesSizeProduct;
/*  50:    */   }
/*  51:    */   
/*  52:    */   private int getAxisIndexForProductIndex(int index, int axis)
/*  53:    */   {
/*  54: 68 */     return index / this.axesSizeProduct[(axis + 1)] % ((List)this.axes.get(axis)).size();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public ImmutableList<E> get(final int index)
/*  58:    */   {
/*  59: 73 */     Preconditions.checkElementIndex(index, size());
/*  60: 74 */     new ImmutableList()
/*  61:    */     {
/*  62:    */       public int size()
/*  63:    */       {
/*  64: 78 */         return CartesianList.this.axes.size();
/*  65:    */       }
/*  66:    */       
/*  67:    */       public E get(int axis)
/*  68:    */       {
/*  69: 83 */         Preconditions.checkElementIndex(axis, size());
/*  70: 84 */         int axisIndex = CartesianList.this.getAxisIndexForProductIndex(index, axis);
/*  71: 85 */         return ((List)CartesianList.this.axes.get(axis)).get(axisIndex);
/*  72:    */       }
/*  73:    */       
/*  74:    */       boolean isPartialView()
/*  75:    */       {
/*  76: 90 */         return true;
/*  77:    */       }
/*  78:    */     };
/*  79:    */   }
/*  80:    */   
/*  81:    */   public int size()
/*  82:    */   {
/*  83: 97 */     return this.axesSizeProduct[0];
/*  84:    */   }
/*  85:    */   
/*  86:    */   public boolean contains(@Nullable Object o)
/*  87:    */   {
/*  88:102 */     if (!(o instanceof List)) {
/*  89:103 */       return false;
/*  90:    */     }
/*  91:105 */     List<?> list = (List)o;
/*  92:106 */     if (list.size() != this.axes.size()) {
/*  93:107 */       return false;
/*  94:    */     }
/*  95:109 */     ListIterator<?> itr = list.listIterator();
/*  96:110 */     while (itr.hasNext())
/*  97:    */     {
/*  98:111 */       int index = itr.nextIndex();
/*  99:112 */       if (!((List)this.axes.get(index)).contains(itr.next())) {
/* 100:113 */         return false;
/* 101:    */       }
/* 102:    */     }
/* 103:116 */     return true;
/* 104:    */   }
/* 105:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.CartesianList
 * JD-Core Version:    0.7.0.1
 */