/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.EnumMap;
/*  10:    */ import java.util.HashMap;
/*  11:    */ import java.util.Map;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(emulated=true)
/*  15:    */ public final class EnumHashBiMap<K extends Enum<K>, V>
/*  16:    */   extends AbstractBiMap<K, V>
/*  17:    */ {
/*  18:    */   private transient Class<K> keyType;
/*  19:    */   @GwtIncompatible("only needed in emulated source.")
/*  20:    */   private static final long serialVersionUID = 0L;
/*  21:    */   
/*  22:    */   public static <K extends Enum<K>, V> EnumHashBiMap<K, V> create(Class<K> keyType)
/*  23:    */   {
/*  24: 56 */     return new EnumHashBiMap(keyType);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <K extends Enum<K>, V> EnumHashBiMap<K, V> create(Map<K, ? extends V> map)
/*  28:    */   {
/*  29: 70 */     EnumHashBiMap<K, V> bimap = create(EnumBiMap.inferKeyType(map));
/*  30: 71 */     bimap.putAll(map);
/*  31: 72 */     return bimap;
/*  32:    */   }
/*  33:    */   
/*  34:    */   private EnumHashBiMap(Class<K> keyType)
/*  35:    */   {
/*  36: 76 */     super(WellBehavedMap.wrap(new EnumMap(keyType)), Maps.newHashMapWithExpectedSize(((Enum[])keyType.getEnumConstants()).length));
/*  37:    */     
/*  38:    */ 
/*  39: 79 */     this.keyType = keyType;
/*  40:    */   }
/*  41:    */   
/*  42:    */   K checkKey(K key)
/*  43:    */   {
/*  44: 86 */     return (Enum)Preconditions.checkNotNull(key);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public V put(K key, @Nullable V value)
/*  48:    */   {
/*  49: 91 */     return super.put(key, value);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public V forcePut(K key, @Nullable V value)
/*  53:    */   {
/*  54: 96 */     return super.forcePut(key, value);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Class<K> keyType()
/*  58:    */   {
/*  59:101 */     return this.keyType;
/*  60:    */   }
/*  61:    */   
/*  62:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  63:    */   private void writeObject(ObjectOutputStream stream)
/*  64:    */     throws IOException
/*  65:    */   {
/*  66:110 */     stream.defaultWriteObject();
/*  67:111 */     stream.writeObject(this.keyType);
/*  68:112 */     Serialization.writeMap(this, stream);
/*  69:    */   }
/*  70:    */   
/*  71:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  72:    */   private void readObject(ObjectInputStream stream)
/*  73:    */     throws IOException, ClassNotFoundException
/*  74:    */   {
/*  75:118 */     stream.defaultReadObject();
/*  76:119 */     this.keyType = ((Class)stream.readObject());
/*  77:120 */     setDelegates(WellBehavedMap.wrap(new EnumMap(this.keyType)), new HashMap(((Enum[])this.keyType.getEnumConstants()).length * 3 / 2));
/*  78:    */     
/*  79:    */ 
/*  80:123 */     Serialization.populateMap(this, stream);
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.EnumHashBiMap
 * JD-Core Version:    0.7.0.1
 */