/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Joiner;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Predicate;
/*   9:    */ import com.google.common.base.Predicates;
/*  10:    */ import com.google.common.math.IntMath;
/*  11:    */ import com.google.common.math.LongMath;
/*  12:    */ import java.util.AbstractCollection;
/*  13:    */ import java.util.ArrayList;
/*  14:    */ import java.util.Arrays;
/*  15:    */ import java.util.Collection;
/*  16:    */ import java.util.Collections;
/*  17:    */ import java.util.Comparator;
/*  18:    */ import java.util.Iterator;
/*  19:    */ import java.util.List;
/*  20:    */ import javax.annotation.CheckReturnValue;
/*  21:    */ import javax.annotation.Nullable;
/*  22:    */ 
/*  23:    */ @CheckReturnValue
/*  24:    */ @GwtCompatible
/*  25:    */ public final class Collections2
/*  26:    */ {
/*  27:    */   @CheckReturnValue
/*  28:    */   public static <E> Collection<E> filter(Collection<E> unfiltered, Predicate<? super E> predicate)
/*  29:    */   {
/*  30: 93 */     if ((unfiltered instanceof FilteredCollection)) {
/*  31: 96 */       return ((FilteredCollection)unfiltered).createCombined(predicate);
/*  32:    */     }
/*  33: 99 */     return new FilteredCollection((Collection)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*  34:    */   }
/*  35:    */   
/*  36:    */   static boolean safeContains(Collection<?> collection, @Nullable Object object)
/*  37:    */   {
/*  38:108 */     Preconditions.checkNotNull(collection);
/*  39:    */     try
/*  40:    */     {
/*  41:110 */       return collection.contains(object);
/*  42:    */     }
/*  43:    */     catch (ClassCastException e)
/*  44:    */     {
/*  45:112 */       return false;
/*  46:    */     }
/*  47:    */     catch (NullPointerException e) {}
/*  48:114 */     return false;
/*  49:    */   }
/*  50:    */   
/*  51:    */   static boolean safeRemove(Collection<?> collection, @Nullable Object object)
/*  52:    */   {
/*  53:124 */     Preconditions.checkNotNull(collection);
/*  54:    */     try
/*  55:    */     {
/*  56:126 */       return collection.remove(object);
/*  57:    */     }
/*  58:    */     catch (ClassCastException e)
/*  59:    */     {
/*  60:128 */       return false;
/*  61:    */     }
/*  62:    */     catch (NullPointerException e) {}
/*  63:130 */     return false;
/*  64:    */   }
/*  65:    */   
/*  66:    */   static class FilteredCollection<E>
/*  67:    */     extends AbstractCollection<E>
/*  68:    */   {
/*  69:    */     final Collection<E> unfiltered;
/*  70:    */     final Predicate<? super E> predicate;
/*  71:    */     
/*  72:    */     FilteredCollection(Collection<E> unfiltered, Predicate<? super E> predicate)
/*  73:    */     {
/*  74:139 */       this.unfiltered = unfiltered;
/*  75:140 */       this.predicate = predicate;
/*  76:    */     }
/*  77:    */     
/*  78:    */     FilteredCollection<E> createCombined(Predicate<? super E> newPredicate)
/*  79:    */     {
/*  80:144 */       return new FilteredCollection(this.unfiltered, Predicates.and(this.predicate, newPredicate));
/*  81:    */     }
/*  82:    */     
/*  83:    */     public boolean add(E element)
/*  84:    */     {
/*  85:150 */       Preconditions.checkArgument(this.predicate.apply(element));
/*  86:151 */       return this.unfiltered.add(element);
/*  87:    */     }
/*  88:    */     
/*  89:    */     public boolean addAll(Collection<? extends E> collection)
/*  90:    */     {
/*  91:156 */       for (E element : collection) {
/*  92:157 */         Preconditions.checkArgument(this.predicate.apply(element));
/*  93:    */       }
/*  94:159 */       return this.unfiltered.addAll(collection);
/*  95:    */     }
/*  96:    */     
/*  97:    */     public void clear()
/*  98:    */     {
/*  99:164 */       Iterables.removeIf(this.unfiltered, this.predicate);
/* 100:    */     }
/* 101:    */     
/* 102:    */     public boolean contains(@Nullable Object element)
/* 103:    */     {
/* 104:169 */       if (Collections2.safeContains(this.unfiltered, element))
/* 105:    */       {
/* 106:171 */         E e = element;
/* 107:172 */         return this.predicate.apply(e);
/* 108:    */       }
/* 109:174 */       return false;
/* 110:    */     }
/* 111:    */     
/* 112:    */     public boolean containsAll(Collection<?> collection)
/* 113:    */     {
/* 114:179 */       return Collections2.containsAllImpl(this, collection);
/* 115:    */     }
/* 116:    */     
/* 117:    */     public boolean isEmpty()
/* 118:    */     {
/* 119:184 */       return !Iterables.any(this.unfiltered, this.predicate);
/* 120:    */     }
/* 121:    */     
/* 122:    */     public Iterator<E> iterator()
/* 123:    */     {
/* 124:189 */       return Iterators.filter(this.unfiltered.iterator(), this.predicate);
/* 125:    */     }
/* 126:    */     
/* 127:    */     public boolean remove(Object element)
/* 128:    */     {
/* 129:194 */       return (contains(element)) && (this.unfiltered.remove(element));
/* 130:    */     }
/* 131:    */     
/* 132:    */     public boolean removeAll(Collection<?> collection)
/* 133:    */     {
/* 134:199 */       return Iterables.removeIf(this.unfiltered, Predicates.and(this.predicate, Predicates.in(collection)));
/* 135:    */     }
/* 136:    */     
/* 137:    */     public boolean retainAll(Collection<?> collection)
/* 138:    */     {
/* 139:204 */       return Iterables.removeIf(this.unfiltered, Predicates.and(this.predicate, Predicates.not(Predicates.in(collection))));
/* 140:    */     }
/* 141:    */     
/* 142:    */     public int size()
/* 143:    */     {
/* 144:209 */       return Iterators.size(iterator());
/* 145:    */     }
/* 146:    */     
/* 147:    */     public Object[] toArray()
/* 148:    */     {
/* 149:215 */       return Lists.newArrayList(iterator()).toArray();
/* 150:    */     }
/* 151:    */     
/* 152:    */     public <T> T[] toArray(T[] array)
/* 153:    */     {
/* 154:220 */       return Lists.newArrayList(iterator()).toArray(array);
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   public static <F, T> Collection<T> transform(Collection<F> fromCollection, Function<? super F, T> function)
/* 159:    */   {
/* 160:245 */     return new TransformedCollection(fromCollection, function);
/* 161:    */   }
/* 162:    */   
/* 163:    */   static class TransformedCollection<F, T>
/* 164:    */     extends AbstractCollection<T>
/* 165:    */   {
/* 166:    */     final Collection<F> fromCollection;
/* 167:    */     final Function<? super F, ? extends T> function;
/* 168:    */     
/* 169:    */     TransformedCollection(Collection<F> fromCollection, Function<? super F, ? extends T> function)
/* 170:    */     {
/* 171:253 */       this.fromCollection = ((Collection)Preconditions.checkNotNull(fromCollection));
/* 172:254 */       this.function = ((Function)Preconditions.checkNotNull(function));
/* 173:    */     }
/* 174:    */     
/* 175:    */     public void clear()
/* 176:    */     {
/* 177:259 */       this.fromCollection.clear();
/* 178:    */     }
/* 179:    */     
/* 180:    */     public boolean isEmpty()
/* 181:    */     {
/* 182:264 */       return this.fromCollection.isEmpty();
/* 183:    */     }
/* 184:    */     
/* 185:    */     public Iterator<T> iterator()
/* 186:    */     {
/* 187:269 */       return Iterators.transform(this.fromCollection.iterator(), this.function);
/* 188:    */     }
/* 189:    */     
/* 190:    */     public int size()
/* 191:    */     {
/* 192:274 */       return this.fromCollection.size();
/* 193:    */     }
/* 194:    */   }
/* 195:    */   
/* 196:    */   static boolean containsAllImpl(Collection<?> self, Collection<?> c)
/* 197:    */   {
/* 198:291 */     return Iterables.all(c, Predicates.in(self));
/* 199:    */   }
/* 200:    */   
/* 201:    */   static String toStringImpl(Collection<?> collection)
/* 202:    */   {
/* 203:298 */     StringBuilder sb = newStringBuilderForCollection(collection.size()).append('[');
/* 204:299 */     STANDARD_JOINER.appendTo(sb, Iterables.transform(collection, new Function()
/* 205:    */     {
/* 206:    */       public Object apply(Object input)
/* 207:    */       {
/* 208:306 */         return input == this.val$collection ? "(this Collection)" : input;
/* 209:    */       }
/* 210:308 */     }));
/* 211:309 */     return ']';
/* 212:    */   }
/* 213:    */   
/* 214:    */   static StringBuilder newStringBuilderForCollection(int size)
/* 215:    */   {
/* 216:316 */     CollectPreconditions.checkNonnegative(size, "size");
/* 217:317 */     return new StringBuilder((int)Math.min(size * 8L, 1073741824L));
/* 218:    */   }
/* 219:    */   
/* 220:    */   static <T> Collection<T> cast(Iterable<T> iterable)
/* 221:    */   {
/* 222:324 */     return (Collection)iterable;
/* 223:    */   }
/* 224:    */   
/* 225:327 */   static final Joiner STANDARD_JOINER = Joiner.on(", ").useForNull("null");
/* 226:    */   
/* 227:    */   @Beta
/* 228:    */   public static <E extends Comparable<? super E>> Collection<List<E>> orderedPermutations(Iterable<E> elements)
/* 229:    */   {
/* 230:359 */     return orderedPermutations(elements, Ordering.natural());
/* 231:    */   }
/* 232:    */   
/* 233:    */   @Beta
/* 234:    */   public static <E> Collection<List<E>> orderedPermutations(Iterable<E> elements, Comparator<? super E> comparator)
/* 235:    */   {
/* 236:412 */     return new OrderedPermutationCollection(elements, comparator);
/* 237:    */   }
/* 238:    */   
/* 239:    */   private static final class OrderedPermutationCollection<E>
/* 240:    */     extends AbstractCollection<List<E>>
/* 241:    */   {
/* 242:    */     final ImmutableList<E> inputList;
/* 243:    */     final Comparator<? super E> comparator;
/* 244:    */     final int size;
/* 245:    */     
/* 246:    */     OrderedPermutationCollection(Iterable<E> input, Comparator<? super E> comparator)
/* 247:    */     {
/* 248:421 */       this.inputList = Ordering.from(comparator).immutableSortedCopy(input);
/* 249:422 */       this.comparator = comparator;
/* 250:423 */       this.size = calculateSize(this.inputList, comparator);
/* 251:    */     }
/* 252:    */     
/* 253:    */     private static <E> int calculateSize(List<E> sortedInputList, Comparator<? super E> comparator)
/* 254:    */     {
/* 255:437 */       long permutations = 1L;
/* 256:438 */       int n = 1;
/* 257:439 */       int r = 1;
/* 258:440 */       while (n < sortedInputList.size())
/* 259:    */       {
/* 260:441 */         int comparison = comparator.compare(sortedInputList.get(n - 1), sortedInputList.get(n));
/* 261:442 */         if (comparison < 0)
/* 262:    */         {
/* 263:444 */           permutations *= LongMath.binomial(n, r);
/* 264:445 */           r = 0;
/* 265:446 */           if (!Collections2.isPositiveInt(permutations)) {
/* 266:447 */             return 2147483647;
/* 267:    */           }
/* 268:    */         }
/* 269:450 */         n++;
/* 270:451 */         r++;
/* 271:    */       }
/* 272:453 */       permutations *= LongMath.binomial(n, r);
/* 273:454 */       if (!Collections2.isPositiveInt(permutations)) {
/* 274:455 */         return 2147483647;
/* 275:    */       }
/* 276:457 */       return (int)permutations;
/* 277:    */     }
/* 278:    */     
/* 279:    */     public int size()
/* 280:    */     {
/* 281:462 */       return this.size;
/* 282:    */     }
/* 283:    */     
/* 284:    */     public boolean isEmpty()
/* 285:    */     {
/* 286:467 */       return false;
/* 287:    */     }
/* 288:    */     
/* 289:    */     public Iterator<List<E>> iterator()
/* 290:    */     {
/* 291:472 */       return new Collections2.OrderedPermutationIterator(this.inputList, this.comparator);
/* 292:    */     }
/* 293:    */     
/* 294:    */     public boolean contains(@Nullable Object obj)
/* 295:    */     {
/* 296:477 */       if ((obj instanceof List))
/* 297:    */       {
/* 298:478 */         List<?> list = (List)obj;
/* 299:479 */         return Collections2.isPermutation(this.inputList, list);
/* 300:    */       }
/* 301:481 */       return false;
/* 302:    */     }
/* 303:    */     
/* 304:    */     public String toString()
/* 305:    */     {
/* 306:486 */       return "orderedPermutationCollection(" + this.inputList + ")";
/* 307:    */     }
/* 308:    */   }
/* 309:    */   
/* 310:    */   private static final class OrderedPermutationIterator<E>
/* 311:    */     extends AbstractIterator<List<E>>
/* 312:    */   {
/* 313:    */     List<E> nextPermutation;
/* 314:    */     final Comparator<? super E> comparator;
/* 315:    */     
/* 316:    */     OrderedPermutationIterator(List<E> list, Comparator<? super E> comparator)
/* 317:    */     {
/* 318:496 */       this.nextPermutation = Lists.newArrayList(list);
/* 319:497 */       this.comparator = comparator;
/* 320:    */     }
/* 321:    */     
/* 322:    */     protected List<E> computeNext()
/* 323:    */     {
/* 324:502 */       if (this.nextPermutation == null) {
/* 325:503 */         return (List)endOfData();
/* 326:    */       }
/* 327:505 */       ImmutableList<E> next = ImmutableList.copyOf(this.nextPermutation);
/* 328:506 */       calculateNextPermutation();
/* 329:507 */       return next;
/* 330:    */     }
/* 331:    */     
/* 332:    */     void calculateNextPermutation()
/* 333:    */     {
/* 334:511 */       int j = findNextJ();
/* 335:512 */       if (j == -1)
/* 336:    */       {
/* 337:513 */         this.nextPermutation = null;
/* 338:514 */         return;
/* 339:    */       }
/* 340:517 */       int l = findNextL(j);
/* 341:518 */       Collections.swap(this.nextPermutation, j, l);
/* 342:519 */       int n = this.nextPermutation.size();
/* 343:520 */       Collections.reverse(this.nextPermutation.subList(j + 1, n));
/* 344:    */     }
/* 345:    */     
/* 346:    */     int findNextJ()
/* 347:    */     {
/* 348:524 */       for (int k = this.nextPermutation.size() - 2; k >= 0; k--) {
/* 349:525 */         if (this.comparator.compare(this.nextPermutation.get(k), this.nextPermutation.get(k + 1)) < 0) {
/* 350:526 */           return k;
/* 351:    */         }
/* 352:    */       }
/* 353:529 */       return -1;
/* 354:    */     }
/* 355:    */     
/* 356:    */     int findNextL(int j)
/* 357:    */     {
/* 358:533 */       E ak = this.nextPermutation.get(j);
/* 359:534 */       for (int l = this.nextPermutation.size() - 1; l > j; l--) {
/* 360:535 */         if (this.comparator.compare(ak, this.nextPermutation.get(l)) < 0) {
/* 361:536 */           return l;
/* 362:    */         }
/* 363:    */       }
/* 364:539 */       throw new AssertionError("this statement should be unreachable");
/* 365:    */     }
/* 366:    */   }
/* 367:    */   
/* 368:    */   @Beta
/* 369:    */   public static <E> Collection<List<E>> permutations(Collection<E> elements)
/* 370:    */   {
/* 371:565 */     return new PermutationCollection(ImmutableList.copyOf(elements));
/* 372:    */   }
/* 373:    */   
/* 374:    */   private static final class PermutationCollection<E>
/* 375:    */     extends AbstractCollection<List<E>>
/* 376:    */   {
/* 377:    */     final ImmutableList<E> inputList;
/* 378:    */     
/* 379:    */     PermutationCollection(ImmutableList<E> input)
/* 380:    */     {
/* 381:572 */       this.inputList = input;
/* 382:    */     }
/* 383:    */     
/* 384:    */     public int size()
/* 385:    */     {
/* 386:577 */       return IntMath.factorial(this.inputList.size());
/* 387:    */     }
/* 388:    */     
/* 389:    */     public boolean isEmpty()
/* 390:    */     {
/* 391:582 */       return false;
/* 392:    */     }
/* 393:    */     
/* 394:    */     public Iterator<List<E>> iterator()
/* 395:    */     {
/* 396:587 */       return new Collections2.PermutationIterator(this.inputList);
/* 397:    */     }
/* 398:    */     
/* 399:    */     public boolean contains(@Nullable Object obj)
/* 400:    */     {
/* 401:592 */       if ((obj instanceof List))
/* 402:    */       {
/* 403:593 */         List<?> list = (List)obj;
/* 404:594 */         return Collections2.isPermutation(this.inputList, list);
/* 405:    */       }
/* 406:596 */       return false;
/* 407:    */     }
/* 408:    */     
/* 409:    */     public String toString()
/* 410:    */     {
/* 411:601 */       return "permutations(" + this.inputList + ")";
/* 412:    */     }
/* 413:    */   }
/* 414:    */   
/* 415:    */   private static class PermutationIterator<E>
/* 416:    */     extends AbstractIterator<List<E>>
/* 417:    */   {
/* 418:    */     final List<E> list;
/* 419:    */     final int[] c;
/* 420:    */     final int[] o;
/* 421:    */     int j;
/* 422:    */     
/* 423:    */     PermutationIterator(List<E> list)
/* 424:    */     {
/* 425:612 */       this.list = new ArrayList(list);
/* 426:613 */       int n = list.size();
/* 427:614 */       this.c = new int[n];
/* 428:615 */       this.o = new int[n];
/* 429:616 */       Arrays.fill(this.c, 0);
/* 430:617 */       Arrays.fill(this.o, 1);
/* 431:618 */       this.j = 2147483647;
/* 432:    */     }
/* 433:    */     
/* 434:    */     protected List<E> computeNext()
/* 435:    */     {
/* 436:623 */       if (this.j <= 0) {
/* 437:624 */         return (List)endOfData();
/* 438:    */       }
/* 439:626 */       ImmutableList<E> next = ImmutableList.copyOf(this.list);
/* 440:627 */       calculateNextPermutation();
/* 441:628 */       return next;
/* 442:    */     }
/* 443:    */     
/* 444:    */     void calculateNextPermutation()
/* 445:    */     {
/* 446:632 */       this.j = (this.list.size() - 1);
/* 447:633 */       int s = 0;
/* 448:637 */       if (this.j == -1) {
/* 449:    */         return;
/* 450:    */       }
/* 451:    */       int q;
/* 452:    */       for (;;)
/* 453:    */       {
/* 454:642 */         q = this.c[this.j] + this.o[this.j];
/* 455:643 */         if (q < 0)
/* 456:    */         {
/* 457:644 */           switchDirection();
/* 458:    */         }
/* 459:    */         else
/* 460:    */         {
/* 461:647 */           if (q != this.j + 1) {
/* 462:    */             break;
/* 463:    */           }
/* 464:648 */           if (this.j == 0) {
/* 465:    */             return;
/* 466:    */           }
/* 467:651 */           s++;
/* 468:652 */           switchDirection();
/* 469:    */         }
/* 470:    */       }
/* 471:656 */       Collections.swap(this.list, this.j - this.c[this.j] + s, this.j - q + s);
/* 472:657 */       this.c[this.j] = q;
/* 473:    */     }
/* 474:    */     
/* 475:    */     void switchDirection()
/* 476:    */     {
/* 477:663 */       this.o[this.j] = (-this.o[this.j]);
/* 478:664 */       this.j -= 1;
/* 479:    */     }
/* 480:    */   }
/* 481:    */   
/* 482:    */   private static boolean isPermutation(List<?> first, List<?> second)
/* 483:    */   {
/* 484:672 */     if (first.size() != second.size()) {
/* 485:673 */       return false;
/* 486:    */     }
/* 487:675 */     Multiset<?> firstMultiset = HashMultiset.create(first);
/* 488:676 */     Multiset<?> secondMultiset = HashMultiset.create(second);
/* 489:677 */     return firstMultiset.equals(secondMultiset);
/* 490:    */   }
/* 491:    */   
/* 492:    */   private static boolean isPositiveInt(long n)
/* 493:    */   {
/* 494:681 */     return (n >= 0L) && (n <= 2147483647L);
/* 495:    */   }
/* 496:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Collections2
 * JD-Core Version:    0.7.0.1
 */