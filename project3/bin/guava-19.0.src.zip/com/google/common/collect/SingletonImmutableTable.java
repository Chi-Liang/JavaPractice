/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.util.Map;
/*  6:   */ 
/*  7:   */ @GwtCompatible
/*  8:   */ class SingletonImmutableTable<R, C, V>
/*  9:   */   extends ImmutableTable<R, C, V>
/* 10:   */ {
/* 11:   */   final R singleRowKey;
/* 12:   */   final C singleColumnKey;
/* 13:   */   final V singleValue;
/* 14:   */   
/* 15:   */   SingletonImmutableTable(R rowKey, C columnKey, V value)
/* 16:   */   {
/* 17:37 */     this.singleRowKey = Preconditions.checkNotNull(rowKey);
/* 18:38 */     this.singleColumnKey = Preconditions.checkNotNull(columnKey);
/* 19:39 */     this.singleValue = Preconditions.checkNotNull(value);
/* 20:   */   }
/* 21:   */   
/* 22:   */   SingletonImmutableTable(Table.Cell<R, C, V> cell)
/* 23:   */   {
/* 24:43 */     this(cell.getRowKey(), cell.getColumnKey(), cell.getValue());
/* 25:   */   }
/* 26:   */   
/* 27:   */   public ImmutableMap<R, V> column(C columnKey)
/* 28:   */   {
/* 29:48 */     Preconditions.checkNotNull(columnKey);
/* 30:49 */     return containsColumn(columnKey) ? ImmutableMap.of(this.singleRowKey, this.singleValue) : ImmutableMap.of();
/* 31:   */   }
/* 32:   */   
/* 33:   */   public ImmutableMap<C, Map<R, V>> columnMap()
/* 34:   */   {
/* 35:56 */     return ImmutableMap.of(this.singleColumnKey, ImmutableMap.of(this.singleRowKey, this.singleValue));
/* 36:   */   }
/* 37:   */   
/* 38:   */   public ImmutableMap<R, Map<C, V>> rowMap()
/* 39:   */   {
/* 40:61 */     return ImmutableMap.of(this.singleRowKey, ImmutableMap.of(this.singleColumnKey, this.singleValue));
/* 41:   */   }
/* 42:   */   
/* 43:   */   public int size()
/* 44:   */   {
/* 45:66 */     return 1;
/* 46:   */   }
/* 47:   */   
/* 48:   */   ImmutableSet<Table.Cell<R, C, V>> createCellSet()
/* 49:   */   {
/* 50:71 */     return ImmutableSet.of(cellOf(this.singleRowKey, this.singleColumnKey, this.singleValue));
/* 51:   */   }
/* 52:   */   
/* 53:   */   ImmutableCollection<V> createValues()
/* 54:   */   {
/* 55:76 */     return ImmutableSet.of(this.singleValue);
/* 56:   */   }
/* 57:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.SingletonImmutableTable
 * JD-Core Version:    0.7.0.1
 */