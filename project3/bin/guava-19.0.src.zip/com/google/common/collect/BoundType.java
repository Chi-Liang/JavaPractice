/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ 
/*  5:   */ @GwtCompatible
/*  6:   */ public enum BoundType
/*  7:   */ {
/*  8:31 */   OPEN,  CLOSED;
/*  9:   */   
/* 10:   */   private BoundType() {}
/* 11:   */   
/* 12:   */   static BoundType forBoolean(boolean inclusive)
/* 13:   */   {
/* 14:51 */     return inclusive ? CLOSED : OPEN;
/* 15:   */   }
/* 16:   */   
/* 17:   */   abstract BoundType flip();
/* 18:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.BoundType
 * JD-Core Version:    0.7.0.1
 */