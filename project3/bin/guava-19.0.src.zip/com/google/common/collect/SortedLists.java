/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.util.Comparator;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.RandomAccess;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ @Beta
/*  14:    */ final class SortedLists
/*  15:    */ {
/*  16:    */   public static abstract enum KeyPresentBehavior
/*  17:    */   {
/*  18: 53 */     ANY_PRESENT,  LAST_PRESENT,  FIRST_PRESENT,  FIRST_AFTER,  LAST_BEFORE;
/*  19:    */     
/*  20:    */     private KeyPresentBehavior() {}
/*  21:    */     
/*  22:    */     abstract <E> int resultIndex(Comparator<? super E> paramComparator, E paramE, List<? extends E> paramList, int paramInt);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static abstract enum KeyAbsentBehavior
/*  26:    */   {
/*  27:145 */     NEXT_LOWER,  NEXT_HIGHER,  INVERTED_INSERTION_INDEX;
/*  28:    */     
/*  29:    */     private KeyAbsentBehavior() {}
/*  30:    */     
/*  31:    */     abstract int resultIndex(int paramInt);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <E extends Comparable> int binarySearch(List<? extends E> list, E e, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior)
/*  35:    */   {
/*  36:195 */     Preconditions.checkNotNull(e);
/*  37:196 */     return binarySearch(list, e, Ordering.natural(), presentBehavior, absentBehavior);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <E, K extends Comparable> int binarySearch(List<E> list, Function<? super E, K> keyFunction, @Nullable K key, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior)
/*  41:    */   {
/*  42:211 */     return binarySearch(list, keyFunction, key, Ordering.natural(), presentBehavior, absentBehavior);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static <E, K> int binarySearch(List<E> list, Function<? super E, K> keyFunction, @Nullable K key, Comparator<? super K> keyComparator, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior)
/*  46:    */   {
/*  47:229 */     return binarySearch(Lists.transform(list, keyFunction), key, keyComparator, presentBehavior, absentBehavior);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static <E> int binarySearch(List<? extends E> list, @Nullable E key, Comparator<? super E> comparator, KeyPresentBehavior presentBehavior, KeyAbsentBehavior absentBehavior)
/*  51:    */   {
/*  52:262 */     Preconditions.checkNotNull(comparator);
/*  53:263 */     Preconditions.checkNotNull(list);
/*  54:264 */     Preconditions.checkNotNull(presentBehavior);
/*  55:265 */     Preconditions.checkNotNull(absentBehavior);
/*  56:266 */     if (!(list instanceof RandomAccess)) {
/*  57:267 */       list = Lists.newArrayList(list);
/*  58:    */     }
/*  59:271 */     int lower = 0;
/*  60:272 */     int upper = list.size() - 1;
/*  61:274 */     while (lower <= upper)
/*  62:    */     {
/*  63:275 */       int middle = lower + upper >>> 1;
/*  64:276 */       int c = comparator.compare(key, list.get(middle));
/*  65:277 */       if (c < 0) {
/*  66:278 */         upper = middle - 1;
/*  67:279 */       } else if (c > 0) {
/*  68:280 */         lower = middle + 1;
/*  69:    */       } else {
/*  70:282 */         return lower + presentBehavior.resultIndex(comparator, key, list.subList(lower, upper + 1), middle - lower);
/*  71:    */       }
/*  72:    */     }
/*  73:286 */     return absentBehavior.resultIndex(lower);
/*  74:    */   }
/*  75:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.SortedLists
 * JD-Core Version:    0.7.0.1
 */