/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.NoSuchElementException;
/*   6:    */ 
/*   7:    */ @GwtCompatible
/*   8:    */ public abstract class AbstractIterator<T>
/*   9:    */   extends UnmodifiableIterator<T>
/*  10:    */ {
/*  11: 65 */   private State state = State.NOT_READY;
/*  12:    */   private T next;
/*  13:    */   protected abstract T computeNext();
/*  14:    */   
/*  15:    */   private static enum State
/*  16:    */   {
/*  17: 72 */     READY,  NOT_READY,  DONE,  FAILED;
/*  18:    */     
/*  19:    */     private State() {}
/*  20:    */   }
/*  21:    */   
/*  22:    */   protected final T endOfData()
/*  23:    */   {
/*  24:124 */     this.state = State.DONE;
/*  25:125 */     return null;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public final boolean hasNext()
/*  29:    */   {
/*  30:130 */     Preconditions.checkState(this.state != State.FAILED);
/*  31:131 */     switch (1.$SwitchMap$com$google$common$collect$AbstractIterator$State[this.state.ordinal()])
/*  32:    */     {
/*  33:    */     case 1: 
/*  34:133 */       return false;
/*  35:    */     case 2: 
/*  36:135 */       return true;
/*  37:    */     }
/*  38:138 */     return tryToComputeNext();
/*  39:    */   }
/*  40:    */   
/*  41:    */   private boolean tryToComputeNext()
/*  42:    */   {
/*  43:142 */     this.state = State.FAILED;
/*  44:143 */     this.next = computeNext();
/*  45:144 */     if (this.state != State.DONE)
/*  46:    */     {
/*  47:145 */       this.state = State.READY;
/*  48:146 */       return true;
/*  49:    */     }
/*  50:148 */     return false;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public final T next()
/*  54:    */   {
/*  55:153 */     if (!hasNext()) {
/*  56:154 */       throw new NoSuchElementException();
/*  57:    */     }
/*  58:156 */     this.state = State.NOT_READY;
/*  59:157 */     T result = this.next;
/*  60:158 */     this.next = null;
/*  61:159 */     return result;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public final T peek()
/*  65:    */   {
/*  66:170 */     if (!hasNext()) {
/*  67:171 */       throw new NoSuchElementException();
/*  68:    */     }
/*  69:173 */     return this.next;
/*  70:    */   }
/*  71:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractIterator
 * JD-Core Version:    0.7.0.1
 */