/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.ListIterator;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ abstract class TransformedListIterator<F, T>
/*  8:   */   extends TransformedIterator<F, T>
/*  9:   */   implements ListIterator<T>
/* 10:   */ {
/* 11:   */   TransformedListIterator(ListIterator<? extends F> backingIterator)
/* 12:   */   {
/* 13:35 */     super(backingIterator);
/* 14:   */   }
/* 15:   */   
/* 16:   */   private ListIterator<? extends F> backingIterator()
/* 17:   */   {
/* 18:39 */     return Iterators.cast(this.backingIterator);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public final boolean hasPrevious()
/* 22:   */   {
/* 23:44 */     return backingIterator().hasPrevious();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public final T previous()
/* 27:   */   {
/* 28:49 */     return transform(backingIterator().previous());
/* 29:   */   }
/* 30:   */   
/* 31:   */   public final int nextIndex()
/* 32:   */   {
/* 33:54 */     return backingIterator().nextIndex();
/* 34:   */   }
/* 35:   */   
/* 36:   */   public final int previousIndex()
/* 37:   */   {
/* 38:59 */     return backingIterator().previousIndex();
/* 39:   */   }
/* 40:   */   
/* 41:   */   public void set(T element)
/* 42:   */   {
/* 43:64 */     throw new UnsupportedOperationException();
/* 44:   */   }
/* 45:   */   
/* 46:   */   public void add(T element)
/* 47:   */   {
/* 48:69 */     throw new UnsupportedOperationException();
/* 49:   */   }
/* 50:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.TransformedListIterator
 * JD-Core Version:    0.7.0.1
 */