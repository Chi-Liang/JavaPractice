/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @GwtCompatible(serializable=true, emulated=true)
/*  10:    */ class RegularImmutableBiMap<K, V>
/*  11:    */   extends ImmutableBiMap<K, V>
/*  12:    */ {
/*  13: 40 */   static final RegularImmutableBiMap<Object, Object> EMPTY = new RegularImmutableBiMap(null, null, (Map.Entry[])ImmutableMap.EMPTY_ENTRY_ARRAY, 0, 0);
/*  14:    */   static final double MAX_LOAD_FACTOR = 1.2D;
/*  15:    */   private final transient ImmutableMapEntry<K, V>[] keyTable;
/*  16:    */   private final transient ImmutableMapEntry<K, V>[] valueTable;
/*  17:    */   private final transient Map.Entry<K, V>[] entries;
/*  18:    */   private final transient int mask;
/*  19:    */   private final transient int hashCode;
/*  20:    */   private transient ImmutableBiMap<V, K> inverse;
/*  21:    */   
/*  22:    */   static <K, V> RegularImmutableBiMap<K, V> fromEntries(Map.Entry<K, V>... entries)
/*  23:    */   {
/*  24: 53 */     return fromEntryArray(entries.length, entries);
/*  25:    */   }
/*  26:    */   
/*  27:    */   static <K, V> RegularImmutableBiMap<K, V> fromEntryArray(int n, Map.Entry<K, V>[] entryArray)
/*  28:    */   {
/*  29: 57 */     Preconditions.checkPositionIndex(n, entryArray.length);
/*  30: 58 */     int tableSize = Hashing.closedTableSize(n, 1.2D);
/*  31: 59 */     int mask = tableSize - 1;
/*  32: 60 */     ImmutableMapEntry<K, V>[] keyTable = ImmutableMapEntry.createEntryArray(tableSize);
/*  33: 61 */     ImmutableMapEntry<K, V>[] valueTable = ImmutableMapEntry.createEntryArray(tableSize);
/*  34:    */     Map.Entry<K, V>[] entries;
/*  35:    */     Map.Entry<K, V>[] entries;
/*  36: 63 */     if (n == entryArray.length) {
/*  37: 64 */       entries = entryArray;
/*  38:    */     } else {
/*  39: 66 */       entries = ImmutableMapEntry.createEntryArray(n);
/*  40:    */     }
/*  41: 68 */     int hashCode = 0;
/*  42: 70 */     for (int i = 0; i < n; i++)
/*  43:    */     {
/*  44: 72 */       Map.Entry<K, V> entry = entryArray[i];
/*  45: 73 */       K key = entry.getKey();
/*  46: 74 */       V value = entry.getValue();
/*  47: 75 */       CollectPreconditions.checkEntryNotNull(key, value);
/*  48: 76 */       int keyHash = key.hashCode();
/*  49: 77 */       int valueHash = value.hashCode();
/*  50: 78 */       int keyBucket = Hashing.smear(keyHash) & mask;
/*  51: 79 */       int valueBucket = Hashing.smear(valueHash) & mask;
/*  52:    */       
/*  53: 81 */       ImmutableMapEntry<K, V> nextInKeyBucket = keyTable[keyBucket];
/*  54: 82 */       RegularImmutableMap.checkNoConflictInKeyBucket(key, entry, nextInKeyBucket);
/*  55: 83 */       ImmutableMapEntry<K, V> nextInValueBucket = valueTable[valueBucket];
/*  56: 84 */       checkNoConflictInValueBucket(value, entry, nextInValueBucket);
/*  57:    */       ImmutableMapEntry<K, V> newEntry;
/*  58:    */       ImmutableMapEntry<K, V> newEntry;
/*  59: 86 */       if ((nextInValueBucket == null) && (nextInKeyBucket == null))
/*  60:    */       {
/*  61: 93 */         boolean reusable = ((entry instanceof ImmutableMapEntry)) && (((ImmutableMapEntry)entry).isReusable());
/*  62:    */         
/*  63: 95 */         newEntry = reusable ? (ImmutableMapEntry)entry : new ImmutableMapEntry(key, value);
/*  64:    */       }
/*  65:    */       else
/*  66:    */       {
/*  67: 99 */         newEntry = new ImmutableMapEntry.NonTerminalImmutableBiMapEntry(key, value, nextInKeyBucket, nextInValueBucket);
/*  68:    */       }
/*  69:102 */       keyTable[keyBucket] = newEntry;
/*  70:103 */       valueTable[valueBucket] = newEntry;
/*  71:104 */       entries[i] = newEntry;
/*  72:105 */       hashCode += (keyHash ^ valueHash);
/*  73:    */     }
/*  74:107 */     return new RegularImmutableBiMap(keyTable, valueTable, entries, mask, hashCode);
/*  75:    */   }
/*  76:    */   
/*  77:    */   private RegularImmutableBiMap(ImmutableMapEntry<K, V>[] keyTable, ImmutableMapEntry<K, V>[] valueTable, Map.Entry<K, V>[] entries, int mask, int hashCode)
/*  78:    */   {
/*  79:116 */     this.keyTable = keyTable;
/*  80:117 */     this.valueTable = valueTable;
/*  81:118 */     this.entries = entries;
/*  82:119 */     this.mask = mask;
/*  83:120 */     this.hashCode = hashCode;
/*  84:    */   }
/*  85:    */   
/*  86:    */   private static void checkNoConflictInValueBucket(Object value, Map.Entry<?, ?> entry, @Nullable ImmutableMapEntry<?, ?> valueBucketHead)
/*  87:    */   {
/*  88:127 */     for (; valueBucketHead != null; valueBucketHead = valueBucketHead.getNextInValueBucket()) {
/*  89:128 */       checkNoConflict(!value.equals(valueBucketHead.getValue()), "value", entry, valueBucketHead);
/*  90:    */     }
/*  91:    */   }
/*  92:    */   
/*  93:    */   @Nullable
/*  94:    */   public V get(@Nullable Object key)
/*  95:    */   {
/*  96:135 */     return this.keyTable == null ? null : RegularImmutableMap.get(key, this.keyTable, this.mask);
/*  97:    */   }
/*  98:    */   
/*  99:    */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 100:    */   {
/* 101:140 */     return isEmpty() ? ImmutableSet.of() : new ImmutableMapEntrySet.RegularEntrySet(this, this.entries);
/* 102:    */   }
/* 103:    */   
/* 104:    */   boolean isHashCodeFast()
/* 105:    */   {
/* 106:147 */     return true;
/* 107:    */   }
/* 108:    */   
/* 109:    */   public int hashCode()
/* 110:    */   {
/* 111:152 */     return this.hashCode;
/* 112:    */   }
/* 113:    */   
/* 114:    */   boolean isPartialView()
/* 115:    */   {
/* 116:157 */     return false;
/* 117:    */   }
/* 118:    */   
/* 119:    */   public int size()
/* 120:    */   {
/* 121:162 */     return this.entries.length;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public ImmutableBiMap<V, K> inverse()
/* 125:    */   {
/* 126:169 */     if (isEmpty()) {
/* 127:170 */       return ImmutableBiMap.of();
/* 128:    */     }
/* 129:172 */     ImmutableBiMap<V, K> result = this.inverse;
/* 130:173 */     return result == null ? (this.inverse = new Inverse(null)) : result;
/* 131:    */   }
/* 132:    */   
/* 133:    */   private final class Inverse
/* 134:    */     extends ImmutableBiMap<V, K>
/* 135:    */   {
/* 136:    */     private Inverse() {}
/* 137:    */     
/* 138:    */     public int size()
/* 139:    */     {
/* 140:180 */       return inverse().size();
/* 141:    */     }
/* 142:    */     
/* 143:    */     public ImmutableBiMap<K, V> inverse()
/* 144:    */     {
/* 145:185 */       return RegularImmutableBiMap.this;
/* 146:    */     }
/* 147:    */     
/* 148:    */     public K get(@Nullable Object value)
/* 149:    */     {
/* 150:190 */       if ((value == null) || (RegularImmutableBiMap.this.valueTable == null)) {
/* 151:191 */         return null;
/* 152:    */       }
/* 153:193 */       int bucket = Hashing.smear(value.hashCode()) & RegularImmutableBiMap.this.mask;
/* 154:194 */       for (ImmutableMapEntry<K, V> entry = RegularImmutableBiMap.this.valueTable[bucket]; entry != null; entry = entry.getNextInValueBucket()) {
/* 155:197 */         if (value.equals(entry.getValue())) {
/* 156:198 */           return entry.getKey();
/* 157:    */         }
/* 158:    */       }
/* 159:201 */       return null;
/* 160:    */     }
/* 161:    */     
/* 162:    */     ImmutableSet<Map.Entry<V, K>> createEntrySet()
/* 163:    */     {
/* 164:206 */       return new InverseEntrySet();
/* 165:    */     }
/* 166:    */     
/* 167:    */     final class InverseEntrySet
/* 168:    */       extends ImmutableMapEntrySet<V, K>
/* 169:    */     {
/* 170:    */       InverseEntrySet() {}
/* 171:    */       
/* 172:    */       ImmutableMap<V, K> map()
/* 173:    */       {
/* 174:213 */         return RegularImmutableBiMap.Inverse.this;
/* 175:    */       }
/* 176:    */       
/* 177:    */       boolean isHashCodeFast()
/* 178:    */       {
/* 179:218 */         return true;
/* 180:    */       }
/* 181:    */       
/* 182:    */       public int hashCode()
/* 183:    */       {
/* 184:223 */         return RegularImmutableBiMap.this.hashCode;
/* 185:    */       }
/* 186:    */       
/* 187:    */       public UnmodifiableIterator<Map.Entry<V, K>> iterator()
/* 188:    */       {
/* 189:228 */         return asList().iterator();
/* 190:    */       }
/* 191:    */       
/* 192:    */       ImmutableList<Map.Entry<V, K>> createAsList()
/* 193:    */       {
/* 194:233 */         new ImmutableAsList()
/* 195:    */         {
/* 196:    */           public Map.Entry<V, K> get(int index)
/* 197:    */           {
/* 198:236 */             Map.Entry<K, V> entry = RegularImmutableBiMap.this.entries[index];
/* 199:237 */             return Maps.immutableEntry(entry.getValue(), entry.getKey());
/* 200:    */           }
/* 201:    */           
/* 202:    */           ImmutableCollection<Map.Entry<V, K>> delegateCollection()
/* 203:    */           {
/* 204:242 */             return RegularImmutableBiMap.Inverse.InverseEntrySet.this;
/* 205:    */           }
/* 206:    */         };
/* 207:    */       }
/* 208:    */     }
/* 209:    */     
/* 210:    */     boolean isPartialView()
/* 211:    */     {
/* 212:250 */       return false;
/* 213:    */     }
/* 214:    */     
/* 215:    */     Object writeReplace()
/* 216:    */     {
/* 217:255 */       return new RegularImmutableBiMap.InverseSerializedForm(RegularImmutableBiMap.this);
/* 218:    */     }
/* 219:    */   }
/* 220:    */   
/* 221:    */   private static class InverseSerializedForm<K, V>
/* 222:    */     implements Serializable
/* 223:    */   {
/* 224:    */     private final ImmutableBiMap<K, V> forward;
/* 225:    */     private static final long serialVersionUID = 1L;
/* 226:    */     
/* 227:    */     InverseSerializedForm(ImmutableBiMap<K, V> forward)
/* 228:    */     {
/* 229:263 */       this.forward = forward;
/* 230:    */     }
/* 231:    */     
/* 232:    */     Object readResolve()
/* 233:    */     {
/* 234:267 */       return this.forward.inverse();
/* 235:    */     }
/* 236:    */   }
/* 237:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableBiMap
 * JD-Core Version:    0.7.0.1
 */