/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Equivalence;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.lang.ref.ReferenceQueue;
/*  10:    */ import java.util.Queue;
/*  11:    */ import java.util.concurrent.ConcurrentMap;
/*  12:    */ import java.util.concurrent.ExecutionException;
/*  13:    */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ import javax.annotation.concurrent.GuardedBy;
/*  16:    */ 
/*  17:    */ class ComputingConcurrentHashMap<K, V>
/*  18:    */   extends MapMakerInternalMap<K, V>
/*  19:    */ {
/*  20:    */   final Function<? super K, ? extends V> computingFunction;
/*  21:    */   private static final long serialVersionUID = 4L;
/*  22:    */   
/*  23:    */   ComputingConcurrentHashMap(MapMaker builder, Function<? super K, ? extends V> computingFunction)
/*  24:    */   {
/*  25: 50 */     super(builder);
/*  26: 51 */     this.computingFunction = ((Function)Preconditions.checkNotNull(computingFunction));
/*  27:    */   }
/*  28:    */   
/*  29:    */   MapMakerInternalMap.Segment<K, V> createSegment(int initialCapacity, int maxSegmentSize)
/*  30:    */   {
/*  31: 56 */     return new ComputingSegment(this, initialCapacity, maxSegmentSize);
/*  32:    */   }
/*  33:    */   
/*  34:    */   ComputingSegment<K, V> segmentFor(int hash)
/*  35:    */   {
/*  36: 61 */     return (ComputingSegment)super.segmentFor(hash);
/*  37:    */   }
/*  38:    */   
/*  39:    */   V getOrCompute(K key)
/*  40:    */     throws ExecutionException
/*  41:    */   {
/*  42: 65 */     int hash = hash(Preconditions.checkNotNull(key));
/*  43: 66 */     return segmentFor(hash).getOrCompute(key, hash, this.computingFunction);
/*  44:    */   }
/*  45:    */   
/*  46:    */   static final class ComputingSegment<K, V>
/*  47:    */     extends MapMakerInternalMap.Segment<K, V>
/*  48:    */   {
/*  49:    */     ComputingSegment(MapMakerInternalMap<K, V> map, int initialCapacity, int maxSegmentSize)
/*  50:    */     {
/*  51: 72 */       super(initialCapacity, maxSegmentSize);
/*  52:    */     }
/*  53:    */     
/*  54:    */     V getOrCompute(K key, int hash, Function<? super K, ? extends V> computingFunction)
/*  55:    */       throws ExecutionException
/*  56:    */     {
/*  57:    */       try
/*  58:    */       {
/*  59:    */         MapMakerInternalMap.ReferenceEntry<K, V> e;
/*  60:    */         Object computingValueReference;
/*  61:    */         V value;
/*  62:    */         do
/*  63:    */         {
/*  64: 81 */           e = getEntry(key, hash);
/*  65: 82 */           if (e != null)
/*  66:    */           {
/*  67: 83 */             V value = getLiveValue(e);
/*  68: 84 */             if (value != null)
/*  69:    */             {
/*  70: 85 */               recordRead(e);
/*  71: 86 */               return value;
/*  72:    */             }
/*  73:    */           }
/*  74: 92 */           if ((e == null) || (!e.getValueReference().isComputingReference()))
/*  75:    */           {
/*  76: 93 */             boolean createNewEntry = true;
/*  77: 94 */             computingValueReference = null;
/*  78: 95 */             lock();
/*  79:    */             int newCount;
/*  80:    */             try
/*  81:    */             {
/*  82: 97 */               preWriteCleanup();
/*  83:    */               
/*  84: 99 */               newCount = this.count - 1;
/*  85:100 */               AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/*  86:101 */               int index = hash & table.length() - 1;
/*  87:102 */               MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/*  88:104 */               for (e = first; e != null; e = e.getNext())
/*  89:    */               {
/*  90:105 */                 K entryKey = e.getKey();
/*  91:106 */                 if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/*  92:    */                 {
/*  93:109 */                   MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/*  94:110 */                   if (valueReference.isComputingReference())
/*  95:    */                   {
/*  96:111 */                     createNewEntry = false; break;
/*  97:    */                   }
/*  98:113 */                   V value = e.getValueReference().get();
/*  99:114 */                   if (value == null)
/* 100:    */                   {
/* 101:115 */                     enqueueNotification(entryKey, hash, value, MapMaker.RemovalCause.COLLECTED);
/* 102:    */                   }
/* 103:116 */                   else if ((this.map.expires()) && (this.map.isExpired(e)))
/* 104:    */                   {
/* 105:119 */                     enqueueNotification(entryKey, hash, value, MapMaker.RemovalCause.EXPIRED);
/* 106:    */                   }
/* 107:    */                   else
/* 108:    */                   {
/* 109:121 */                     recordLockedRead(e);
/* 110:122 */                     return value;
/* 111:    */                   }
/* 112:126 */                   this.evictionQueue.remove(e);
/* 113:127 */                   this.expirationQueue.remove(e);
/* 114:128 */                   this.count = newCount;
/* 115:    */                   
/* 116:130 */                   break;
/* 117:    */                 }
/* 118:    */               }
/* 119:134 */               if (createNewEntry)
/* 120:    */               {
/* 121:135 */                 computingValueReference = new ComputingConcurrentHashMap.ComputingValueReference(computingFunction);
/* 122:137 */                 if (e == null)
/* 123:    */                 {
/* 124:138 */                   e = newEntry(key, hash, first);
/* 125:139 */                   e.setValueReference((MapMakerInternalMap.ValueReference)computingValueReference);
/* 126:140 */                   table.set(index, e);
/* 127:    */                 }
/* 128:    */                 else
/* 129:    */                 {
/* 130:142 */                   e.setValueReference((MapMakerInternalMap.ValueReference)computingValueReference);
/* 131:    */                 }
/* 132:    */               }
/* 133:    */             }
/* 134:    */             finally
/* 135:    */             {
/* 136:146 */               unlock();
/* 137:    */             }
/* 138:150 */             if (createNewEntry) {
/* 139:152 */               return compute(key, hash, e, (ComputingConcurrentHashMap.ComputingValueReference)computingValueReference);
/* 140:    */             }
/* 141:    */           }
/* 142:157 */           Preconditions.checkState(!Thread.holdsLock(e), "Recursive computation");
/* 143:    */           
/* 144:159 */           value = e.getValueReference().waitForValue();
/* 145:160 */         } while (value == null);
/* 146:161 */         recordRead(e);
/* 147:162 */         return value;
/* 148:    */       }
/* 149:    */       finally
/* 150:    */       {
/* 151:168 */         postReadCleanup();
/* 152:    */       }
/* 153:    */     }
/* 154:    */     
/* 155:    */     V compute(K key, int hash, MapMakerInternalMap.ReferenceEntry<K, V> e, ComputingConcurrentHashMap.ComputingValueReference<K, V> computingValueReference)
/* 156:    */       throws ExecutionException
/* 157:    */     {
/* 158:177 */       V value = null;
/* 159:178 */       long start = System.nanoTime();
/* 160:179 */       long end = 0L;
/* 161:    */       try
/* 162:    */       {
/* 163:184 */         synchronized (e)
/* 164:    */         {
/* 165:185 */           value = computingValueReference.compute(key, hash);
/* 166:186 */           end = System.nanoTime();
/* 167:    */         }
/* 168:    */         V oldValue;
/* 169:188 */         if (value != null)
/* 170:    */         {
/* 171:190 */           oldValue = put(key, hash, value, true);
/* 172:191 */           if (oldValue != null) {
/* 173:193 */             enqueueNotification(key, hash, value, MapMaker.RemovalCause.REPLACED);
/* 174:    */           }
/* 175:    */         }
/* 176:196 */         return value;
/* 177:    */       }
/* 178:    */       finally
/* 179:    */       {
/* 180:198 */         if (end == 0L) {
/* 181:199 */           end = System.nanoTime();
/* 182:    */         }
/* 183:201 */         if (value == null) {
/* 184:202 */           clearValue(key, hash, computingValueReference);
/* 185:    */         }
/* 186:    */       }
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   private static final class ComputationExceptionReference<K, V>
/* 191:    */     implements MapMakerInternalMap.ValueReference<K, V>
/* 192:    */   {
/* 193:    */     final Throwable t;
/* 194:    */     
/* 195:    */     ComputationExceptionReference(Throwable t)
/* 196:    */     {
/* 197:215 */       this.t = t;
/* 198:    */     }
/* 199:    */     
/* 200:    */     public V get()
/* 201:    */     {
/* 202:220 */       return null;
/* 203:    */     }
/* 204:    */     
/* 205:    */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 206:    */     {
/* 207:225 */       return null;
/* 208:    */     }
/* 209:    */     
/* 210:    */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 211:    */     {
/* 212:231 */       return this;
/* 213:    */     }
/* 214:    */     
/* 215:    */     public boolean isComputingReference()
/* 216:    */     {
/* 217:236 */       return false;
/* 218:    */     }
/* 219:    */     
/* 220:    */     public V waitForValue()
/* 221:    */       throws ExecutionException
/* 222:    */     {
/* 223:241 */       throw new ExecutionException(this.t);
/* 224:    */     }
/* 225:    */     
/* 226:    */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue) {}
/* 227:    */   }
/* 228:    */   
/* 229:    */   private static final class ComputedReference<K, V>
/* 230:    */     implements MapMakerInternalMap.ValueReference<K, V>
/* 231:    */   {
/* 232:    */     final V value;
/* 233:    */     
/* 234:    */     ComputedReference(@Nullable V value)
/* 235:    */     {
/* 236:255 */       this.value = value;
/* 237:    */     }
/* 238:    */     
/* 239:    */     public V get()
/* 240:    */     {
/* 241:260 */       return this.value;
/* 242:    */     }
/* 243:    */     
/* 244:    */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 245:    */     {
/* 246:265 */       return null;
/* 247:    */     }
/* 248:    */     
/* 249:    */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 250:    */     {
/* 251:271 */       return this;
/* 252:    */     }
/* 253:    */     
/* 254:    */     public boolean isComputingReference()
/* 255:    */     {
/* 256:276 */       return false;
/* 257:    */     }
/* 258:    */     
/* 259:    */     public V waitForValue()
/* 260:    */     {
/* 261:281 */       return get();
/* 262:    */     }
/* 263:    */     
/* 264:    */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue) {}
/* 265:    */   }
/* 266:    */   
/* 267:    */   private static final class ComputingValueReference<K, V>
/* 268:    */     implements MapMakerInternalMap.ValueReference<K, V>
/* 269:    */   {
/* 270:    */     final Function<? super K, ? extends V> computingFunction;
/* 271:    */     @GuardedBy("this")
/* 272:291 */     volatile MapMakerInternalMap.ValueReference<K, V> computedReference = MapMakerInternalMap.unset();
/* 273:    */     
/* 274:    */     public ComputingValueReference(Function<? super K, ? extends V> computingFunction)
/* 275:    */     {
/* 276:295 */       this.computingFunction = computingFunction;
/* 277:    */     }
/* 278:    */     
/* 279:    */     public V get()
/* 280:    */     {
/* 281:302 */       return null;
/* 282:    */     }
/* 283:    */     
/* 284:    */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 285:    */     {
/* 286:307 */       return null;
/* 287:    */     }
/* 288:    */     
/* 289:    */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, @Nullable V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 290:    */     {
/* 291:313 */       return this;
/* 292:    */     }
/* 293:    */     
/* 294:    */     public boolean isComputingReference()
/* 295:    */     {
/* 296:318 */       return true;
/* 297:    */     }
/* 298:    */     
/* 299:    */     public V waitForValue()
/* 300:    */       throws ExecutionException
/* 301:    */     {
/* 302:326 */       if (this.computedReference == MapMakerInternalMap.UNSET)
/* 303:    */       {
/* 304:327 */         boolean interrupted = false;
/* 305:    */         try
/* 306:    */         {
/* 307:329 */           synchronized (this)
/* 308:    */           {
/* 309:330 */             while (this.computedReference == MapMakerInternalMap.UNSET) {
/* 310:    */               try
/* 311:    */               {
/* 312:332 */                 wait();
/* 313:    */               }
/* 314:    */               catch (InterruptedException ie)
/* 315:    */               {
/* 316:334 */                 interrupted = true;
/* 317:    */               }
/* 318:    */             }
/* 319:    */           }
/* 320:    */         }
/* 321:    */         finally
/* 322:    */         {
/* 323:339 */           if (interrupted) {
/* 324:340 */             Thread.currentThread().interrupt();
/* 325:    */           }
/* 326:    */         }
/* 327:    */       }
/* 328:344 */       return this.computedReference.waitForValue();
/* 329:    */     }
/* 330:    */     
/* 331:    */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue)
/* 332:    */     {
/* 333:351 */       setValueReference(newValue);
/* 334:    */     }
/* 335:    */     
/* 336:    */     V compute(K key, int hash)
/* 337:    */       throws ExecutionException
/* 338:    */     {
/* 339:    */       V value;
/* 340:    */       try
/* 341:    */       {
/* 342:359 */         value = this.computingFunction.apply(key);
/* 343:    */       }
/* 344:    */       catch (Throwable t)
/* 345:    */       {
/* 346:361 */         setValueReference(new ComputingConcurrentHashMap.ComputationExceptionReference(t));
/* 347:362 */         throw new ExecutionException(t);
/* 348:    */       }
/* 349:365 */       setValueReference(new ComputingConcurrentHashMap.ComputedReference(value));
/* 350:366 */       return value;
/* 351:    */     }
/* 352:    */     
/* 353:    */     void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 354:    */     {
/* 355:370 */       synchronized (this)
/* 356:    */       {
/* 357:371 */         if (this.computedReference == MapMakerInternalMap.UNSET)
/* 358:    */         {
/* 359:372 */           this.computedReference = valueReference;
/* 360:373 */           notifyAll();
/* 361:    */         }
/* 362:    */       }
/* 363:    */     }
/* 364:    */   }
/* 365:    */   
/* 366:    */   Object writeReplace()
/* 367:    */   {
/* 368:385 */     return new ComputingSerializationProxy(this.keyStrength, this.valueStrength, this.keyEquivalence, this.valueEquivalence, this.expireAfterWriteNanos, this.expireAfterAccessNanos, this.maximumSize, this.concurrencyLevel, this.removalListener, this, this.computingFunction);
/* 369:    */   }
/* 370:    */   
/* 371:    */   static final class ComputingSerializationProxy<K, V>
/* 372:    */     extends MapMakerInternalMap.AbstractSerializationProxy<K, V>
/* 373:    */   {
/* 374:    */     final Function<? super K, ? extends V> computingFunction;
/* 375:    */     private static final long serialVersionUID = 4L;
/* 376:    */     
/* 377:    */     ComputingSerializationProxy(MapMakerInternalMap.Strength keyStrength, MapMakerInternalMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expireAfterWriteNanos, long expireAfterAccessNanos, int maximumSize, int concurrencyLevel, MapMaker.RemovalListener<? super K, ? super V> removalListener, ConcurrentMap<K, V> delegate, Function<? super K, ? extends V> computingFunction)
/* 378:    */     {
/* 379:415 */       super(valueStrength, keyEquivalence, valueEquivalence, expireAfterWriteNanos, expireAfterAccessNanos, maximumSize, concurrencyLevel, removalListener, delegate);
/* 380:    */       
/* 381:    */ 
/* 382:    */ 
/* 383:    */ 
/* 384:    */ 
/* 385:    */ 
/* 386:    */ 
/* 387:    */ 
/* 388:    */ 
/* 389:    */ 
/* 390:426 */       this.computingFunction = computingFunction;
/* 391:    */     }
/* 392:    */     
/* 393:    */     private void writeObject(ObjectOutputStream out)
/* 394:    */       throws IOException
/* 395:    */     {
/* 396:430 */       out.defaultWriteObject();
/* 397:431 */       writeMapTo(out);
/* 398:    */     }
/* 399:    */     
/* 400:    */     private void readObject(ObjectInputStream in)
/* 401:    */       throws IOException, ClassNotFoundException
/* 402:    */     {
/* 403:436 */       in.defaultReadObject();
/* 404:437 */       MapMaker mapMaker = readMapMaker(in);
/* 405:438 */       this.delegate = mapMaker.makeComputingMap(this.computingFunction);
/* 406:439 */       readEntries(in);
/* 407:    */     }
/* 408:    */     
/* 409:    */     Object readResolve()
/* 410:    */     {
/* 411:443 */       return this.delegate;
/* 412:    */     }
/* 413:    */   }
/* 414:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ComputingConcurrentHashMap
 * JD-Core Version:    0.7.0.1
 */