/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.ObjectInputStream;
/*   9:    */ import java.io.ObjectOutputStream;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.ConcurrentModificationException;
/*  13:    */ import java.util.Iterator;
/*  14:    */ import java.util.LinkedHashMap;
/*  15:    */ import java.util.LinkedHashSet;
/*  16:    */ import java.util.Map;
/*  17:    */ import java.util.Map.Entry;
/*  18:    */ import java.util.NoSuchElementException;
/*  19:    */ import java.util.Set;
/*  20:    */ import javax.annotation.Nullable;
/*  21:    */ 
/*  22:    */ @GwtCompatible(serializable=true, emulated=true)
/*  23:    */ public final class LinkedHashMultimap<K, V>
/*  24:    */   extends AbstractSetMultimap<K, V>
/*  25:    */ {
/*  26:    */   private static final int DEFAULT_KEY_CAPACITY = 16;
/*  27:    */   private static final int DEFAULT_VALUE_SET_CAPACITY = 2;
/*  28:    */   @VisibleForTesting
/*  29:    */   static final double VALUE_SET_LOAD_FACTOR = 1.0D;
/*  30:    */   
/*  31:    */   public static <K, V> LinkedHashMultimap<K, V> create()
/*  32:    */   {
/*  33: 90 */     return new LinkedHashMultimap(16, 2);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static <K, V> LinkedHashMultimap<K, V> create(int expectedKeys, int expectedValuesPerKey)
/*  37:    */   {
/*  38:103 */     return new LinkedHashMultimap(Maps.capacity(expectedKeys), Maps.capacity(expectedValuesPerKey));
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <K, V> LinkedHashMultimap<K, V> create(Multimap<? extends K, ? extends V> multimap)
/*  42:    */   {
/*  43:118 */     LinkedHashMultimap<K, V> result = create(multimap.keySet().size(), 2);
/*  44:119 */     result.putAll(multimap);
/*  45:120 */     return result;
/*  46:    */   }
/*  47:    */   
/*  48:    */   private static <K, V> void succeedsInValueSet(ValueSetLink<K, V> pred, ValueSetLink<K, V> succ)
/*  49:    */   {
/*  50:134 */     pred.setSuccessorInValueSet(succ);
/*  51:135 */     succ.setPredecessorInValueSet(pred);
/*  52:    */   }
/*  53:    */   
/*  54:    */   private static <K, V> void succeedsInMultimap(ValueEntry<K, V> pred, ValueEntry<K, V> succ)
/*  55:    */   {
/*  56:139 */     pred.setSuccessorInMultimap(succ);
/*  57:140 */     succ.setPredecessorInMultimap(pred);
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static <K, V> void deleteFromValueSet(ValueSetLink<K, V> entry)
/*  61:    */   {
/*  62:144 */     succeedsInValueSet(entry.getPredecessorInValueSet(), entry.getSuccessorInValueSet());
/*  63:    */   }
/*  64:    */   
/*  65:    */   private static <K, V> void deleteFromMultimap(ValueEntry<K, V> entry)
/*  66:    */   {
/*  67:148 */     succeedsInMultimap(entry.getPredecessorInMultimap(), entry.getSuccessorInMultimap());
/*  68:    */   }
/*  69:    */   
/*  70:    */   private static abstract interface ValueSetLink<K, V>
/*  71:    */   {
/*  72:    */     public abstract ValueSetLink<K, V> getPredecessorInValueSet();
/*  73:    */     
/*  74:    */     public abstract ValueSetLink<K, V> getSuccessorInValueSet();
/*  75:    */     
/*  76:    */     public abstract void setPredecessorInValueSet(ValueSetLink<K, V> paramValueSetLink);
/*  77:    */     
/*  78:    */     public abstract void setSuccessorInValueSet(ValueSetLink<K, V> paramValueSetLink);
/*  79:    */   }
/*  80:    */   
/*  81:    */   @VisibleForTesting
/*  82:    */   static final class ValueEntry<K, V>
/*  83:    */     extends ImmutableEntry<K, V>
/*  84:    */     implements LinkedHashMultimap.ValueSetLink<K, V>
/*  85:    */   {
/*  86:    */     final int smearedValueHash;
/*  87:    */     @Nullable
/*  88:    */     ValueEntry<K, V> nextInValueBucket;
/*  89:    */     LinkedHashMultimap.ValueSetLink<K, V> predecessorInValueSet;
/*  90:    */     LinkedHashMultimap.ValueSetLink<K, V> successorInValueSet;
/*  91:    */     ValueEntry<K, V> predecessorInMultimap;
/*  92:    */     ValueEntry<K, V> successorInMultimap;
/*  93:    */     
/*  94:    */     ValueEntry(@Nullable K key, @Nullable V value, int smearedValueHash, @Nullable ValueEntry<K, V> nextInValueBucket)
/*  95:    */     {
/*  96:174 */       super(value);
/*  97:175 */       this.smearedValueHash = smearedValueHash;
/*  98:176 */       this.nextInValueBucket = nextInValueBucket;
/*  99:    */     }
/* 100:    */     
/* 101:    */     boolean matchesValue(@Nullable Object v, int smearedVHash)
/* 102:    */     {
/* 103:180 */       return (this.smearedValueHash == smearedVHash) && (Objects.equal(getValue(), v));
/* 104:    */     }
/* 105:    */     
/* 106:    */     public LinkedHashMultimap.ValueSetLink<K, V> getPredecessorInValueSet()
/* 107:    */     {
/* 108:185 */       return this.predecessorInValueSet;
/* 109:    */     }
/* 110:    */     
/* 111:    */     public LinkedHashMultimap.ValueSetLink<K, V> getSuccessorInValueSet()
/* 112:    */     {
/* 113:190 */       return this.successorInValueSet;
/* 114:    */     }
/* 115:    */     
/* 116:    */     public void setPredecessorInValueSet(LinkedHashMultimap.ValueSetLink<K, V> entry)
/* 117:    */     {
/* 118:195 */       this.predecessorInValueSet = entry;
/* 119:    */     }
/* 120:    */     
/* 121:    */     public void setSuccessorInValueSet(LinkedHashMultimap.ValueSetLink<K, V> entry)
/* 122:    */     {
/* 123:200 */       this.successorInValueSet = entry;
/* 124:    */     }
/* 125:    */     
/* 126:    */     public ValueEntry<K, V> getPredecessorInMultimap()
/* 127:    */     {
/* 128:204 */       return this.predecessorInMultimap;
/* 129:    */     }
/* 130:    */     
/* 131:    */     public ValueEntry<K, V> getSuccessorInMultimap()
/* 132:    */     {
/* 133:208 */       return this.successorInMultimap;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public void setSuccessorInMultimap(ValueEntry<K, V> multimapSuccessor)
/* 137:    */     {
/* 138:212 */       this.successorInMultimap = multimapSuccessor;
/* 139:    */     }
/* 140:    */     
/* 141:    */     public void setPredecessorInMultimap(ValueEntry<K, V> multimapPredecessor)
/* 142:    */     {
/* 143:216 */       this.predecessorInMultimap = multimapPredecessor;
/* 144:    */     }
/* 145:    */   }
/* 146:    */   
/* 147:    */   @VisibleForTesting
/* 148:224 */   transient int valueSetCapacity = 2;
/* 149:    */   private transient ValueEntry<K, V> multimapHeaderEntry;
/* 150:    */   @GwtIncompatible("java serialization not supported")
/* 151:    */   private static final long serialVersionUID = 1L;
/* 152:    */   
/* 153:    */   private LinkedHashMultimap(int keyCapacity, int valueSetCapacity)
/* 154:    */   {
/* 155:228 */     super(new LinkedHashMap(keyCapacity));
/* 156:229 */     CollectPreconditions.checkNonnegative(valueSetCapacity, "expectedValuesPerKey");
/* 157:    */     
/* 158:231 */     this.valueSetCapacity = valueSetCapacity;
/* 159:232 */     this.multimapHeaderEntry = new ValueEntry(null, null, 0, null);
/* 160:233 */     succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
/* 161:    */   }
/* 162:    */   
/* 163:    */   Set<V> createCollection()
/* 164:    */   {
/* 165:247 */     return new LinkedHashSet(this.valueSetCapacity);
/* 166:    */   }
/* 167:    */   
/* 168:    */   Collection<V> createCollection(K key)
/* 169:    */   {
/* 170:261 */     return new ValueSet(key, this.valueSetCapacity);
/* 171:    */   }
/* 172:    */   
/* 173:    */   public Set<V> replaceValues(@Nullable K key, Iterable<? extends V> values)
/* 174:    */   {
/* 175:274 */     return super.replaceValues(key, values);
/* 176:    */   }
/* 177:    */   
/* 178:    */   public Set<Map.Entry<K, V>> entries()
/* 179:    */   {
/* 180:291 */     return super.entries();
/* 181:    */   }
/* 182:    */   
/* 183:    */   public Collection<V> values()
/* 184:    */   {
/* 185:303 */     return super.values();
/* 186:    */   }
/* 187:    */   
/* 188:    */   @VisibleForTesting
/* 189:    */   final class ValueSet
/* 190:    */     extends Sets.ImprovedAbstractSet<V>
/* 191:    */     implements LinkedHashMultimap.ValueSetLink<K, V>
/* 192:    */   {
/* 193:    */     private final K key;
/* 194:    */     @VisibleForTesting
/* 195:    */     LinkedHashMultimap.ValueEntry<K, V>[] hashTable;
/* 196:316 */     private int size = 0;
/* 197:317 */     private int modCount = 0;
/* 198:    */     private LinkedHashMultimap.ValueSetLink<K, V> firstEntry;
/* 199:    */     private LinkedHashMultimap.ValueSetLink<K, V> lastEntry;
/* 200:    */     
/* 201:    */     ValueSet(int key)
/* 202:    */     {
/* 203:325 */       this.key = key;
/* 204:326 */       this.firstEntry = this;
/* 205:327 */       this.lastEntry = this;
/* 206:    */       
/* 207:329 */       int tableSize = Hashing.closedTableSize(expectedValues, 1.0D);
/* 208:    */       
/* 209:    */ 
/* 210:332 */       LinkedHashMultimap.ValueEntry<K, V>[] hashTable = new LinkedHashMultimap.ValueEntry[tableSize];
/* 211:333 */       this.hashTable = hashTable;
/* 212:    */     }
/* 213:    */     
/* 214:    */     private int mask()
/* 215:    */     {
/* 216:337 */       return this.hashTable.length - 1;
/* 217:    */     }
/* 218:    */     
/* 219:    */     public LinkedHashMultimap.ValueSetLink<K, V> getPredecessorInValueSet()
/* 220:    */     {
/* 221:342 */       return this.lastEntry;
/* 222:    */     }
/* 223:    */     
/* 224:    */     public LinkedHashMultimap.ValueSetLink<K, V> getSuccessorInValueSet()
/* 225:    */     {
/* 226:347 */       return this.firstEntry;
/* 227:    */     }
/* 228:    */     
/* 229:    */     public void setPredecessorInValueSet(LinkedHashMultimap.ValueSetLink<K, V> entry)
/* 230:    */     {
/* 231:352 */       this.lastEntry = entry;
/* 232:    */     }
/* 233:    */     
/* 234:    */     public void setSuccessorInValueSet(LinkedHashMultimap.ValueSetLink<K, V> entry)
/* 235:    */     {
/* 236:357 */       this.firstEntry = entry;
/* 237:    */     }
/* 238:    */     
/* 239:    */     public Iterator<V> iterator()
/* 240:    */     {
/* 241:362 */       new Iterator()
/* 242:    */       {
/* 243:363 */         LinkedHashMultimap.ValueSetLink<K, V> nextEntry = LinkedHashMultimap.ValueSet.this.firstEntry;
/* 244:    */         LinkedHashMultimap.ValueEntry<K, V> toRemove;
/* 245:365 */         int expectedModCount = LinkedHashMultimap.ValueSet.this.modCount;
/* 246:    */         
/* 247:    */         private void checkForComodification()
/* 248:    */         {
/* 249:368 */           if (LinkedHashMultimap.ValueSet.this.modCount != this.expectedModCount) {
/* 250:369 */             throw new ConcurrentModificationException();
/* 251:    */           }
/* 252:    */         }
/* 253:    */         
/* 254:    */         public boolean hasNext()
/* 255:    */         {
/* 256:375 */           checkForComodification();
/* 257:376 */           return this.nextEntry != LinkedHashMultimap.ValueSet.this;
/* 258:    */         }
/* 259:    */         
/* 260:    */         public V next()
/* 261:    */         {
/* 262:381 */           if (!hasNext()) {
/* 263:382 */             throw new NoSuchElementException();
/* 264:    */           }
/* 265:384 */           LinkedHashMultimap.ValueEntry<K, V> entry = (LinkedHashMultimap.ValueEntry)this.nextEntry;
/* 266:385 */           V result = entry.getValue();
/* 267:386 */           this.toRemove = entry;
/* 268:387 */           this.nextEntry = entry.getSuccessorInValueSet();
/* 269:388 */           return result;
/* 270:    */         }
/* 271:    */         
/* 272:    */         public void remove()
/* 273:    */         {
/* 274:393 */           checkForComodification();
/* 275:394 */           CollectPreconditions.checkRemove(this.toRemove != null);
/* 276:395 */           LinkedHashMultimap.ValueSet.this.remove(this.toRemove.getValue());
/* 277:396 */           this.expectedModCount = LinkedHashMultimap.ValueSet.this.modCount;
/* 278:397 */           this.toRemove = null;
/* 279:    */         }
/* 280:    */       };
/* 281:    */     }
/* 282:    */     
/* 283:    */     public int size()
/* 284:    */     {
/* 285:404 */       return this.size;
/* 286:    */     }
/* 287:    */     
/* 288:    */     public boolean contains(@Nullable Object o)
/* 289:    */     {
/* 290:409 */       int smearedHash = Hashing.smearedHash(o);
/* 291:410 */       for (LinkedHashMultimap.ValueEntry<K, V> entry = this.hashTable[(smearedHash & mask())]; entry != null; entry = entry.nextInValueBucket) {
/* 292:413 */         if (entry.matchesValue(o, smearedHash)) {
/* 293:414 */           return true;
/* 294:    */         }
/* 295:    */       }
/* 296:417 */       return false;
/* 297:    */     }
/* 298:    */     
/* 299:    */     public boolean add(@Nullable V value)
/* 300:    */     {
/* 301:422 */       int smearedHash = Hashing.smearedHash(value);
/* 302:423 */       int bucket = smearedHash & mask();
/* 303:424 */       LinkedHashMultimap.ValueEntry<K, V> rowHead = this.hashTable[bucket];
/* 304:425 */       for (LinkedHashMultimap.ValueEntry<K, V> entry = rowHead; entry != null; entry = entry.nextInValueBucket) {
/* 305:426 */         if (entry.matchesValue(value, smearedHash)) {
/* 306:427 */           return false;
/* 307:    */         }
/* 308:    */       }
/* 309:431 */       LinkedHashMultimap.ValueEntry<K, V> newEntry = new LinkedHashMultimap.ValueEntry(this.key, value, smearedHash, rowHead);
/* 310:432 */       LinkedHashMultimap.succeedsInValueSet(this.lastEntry, newEntry);
/* 311:433 */       LinkedHashMultimap.succeedsInValueSet(newEntry, this);
/* 312:434 */       LinkedHashMultimap.succeedsInMultimap(LinkedHashMultimap.this.multimapHeaderEntry.getPredecessorInMultimap(), newEntry);
/* 313:435 */       LinkedHashMultimap.succeedsInMultimap(newEntry, LinkedHashMultimap.this.multimapHeaderEntry);
/* 314:436 */       this.hashTable[bucket] = newEntry;
/* 315:437 */       this.size += 1;
/* 316:438 */       this.modCount += 1;
/* 317:439 */       rehashIfNecessary();
/* 318:440 */       return true;
/* 319:    */     }
/* 320:    */     
/* 321:    */     private void rehashIfNecessary()
/* 322:    */     {
/* 323:444 */       if (Hashing.needsResizing(this.size, this.hashTable.length, 1.0D))
/* 324:    */       {
/* 325:446 */         LinkedHashMultimap.ValueEntry<K, V>[] hashTable = new LinkedHashMultimap.ValueEntry[this.hashTable.length * 2];
/* 326:447 */         this.hashTable = hashTable;
/* 327:448 */         int mask = hashTable.length - 1;
/* 328:449 */         for (LinkedHashMultimap.ValueSetLink<K, V> entry = this.firstEntry; entry != this; entry = entry.getSuccessorInValueSet())
/* 329:    */         {
/* 330:452 */           LinkedHashMultimap.ValueEntry<K, V> valueEntry = (LinkedHashMultimap.ValueEntry)entry;
/* 331:453 */           int bucket = valueEntry.smearedValueHash & mask;
/* 332:454 */           valueEntry.nextInValueBucket = hashTable[bucket];
/* 333:455 */           hashTable[bucket] = valueEntry;
/* 334:    */         }
/* 335:    */       }
/* 336:    */     }
/* 337:    */     
/* 338:    */     public boolean remove(@Nullable Object o)
/* 339:    */     {
/* 340:462 */       int smearedHash = Hashing.smearedHash(o);
/* 341:463 */       int bucket = smearedHash & mask();
/* 342:464 */       LinkedHashMultimap.ValueEntry<K, V> prev = null;
/* 343:465 */       for (LinkedHashMultimap.ValueEntry<K, V> entry = this.hashTable[bucket]; entry != null; entry = entry.nextInValueBucket)
/* 344:    */       {
/* 345:468 */         if (entry.matchesValue(o, smearedHash))
/* 346:    */         {
/* 347:469 */           if (prev == null) {
/* 348:471 */             this.hashTable[bucket] = entry.nextInValueBucket;
/* 349:    */           } else {
/* 350:473 */             prev.nextInValueBucket = entry.nextInValueBucket;
/* 351:    */           }
/* 352:475 */           LinkedHashMultimap.deleteFromValueSet(entry);
/* 353:476 */           LinkedHashMultimap.deleteFromMultimap(entry);
/* 354:477 */           this.size -= 1;
/* 355:478 */           this.modCount += 1;
/* 356:479 */           return true;
/* 357:    */         }
/* 358:467 */         prev = entry;
/* 359:    */       }
/* 360:482 */       return false;
/* 361:    */     }
/* 362:    */     
/* 363:    */     public void clear()
/* 364:    */     {
/* 365:487 */       Arrays.fill(this.hashTable, null);
/* 366:488 */       this.size = 0;
/* 367:489 */       for (LinkedHashMultimap.ValueSetLink<K, V> entry = this.firstEntry; entry != this; entry = entry.getSuccessorInValueSet())
/* 368:    */       {
/* 369:492 */         LinkedHashMultimap.ValueEntry<K, V> valueEntry = (LinkedHashMultimap.ValueEntry)entry;
/* 370:493 */         LinkedHashMultimap.deleteFromMultimap(valueEntry);
/* 371:    */       }
/* 372:495 */       LinkedHashMultimap.succeedsInValueSet(this, this);
/* 373:496 */       this.modCount += 1;
/* 374:    */     }
/* 375:    */   }
/* 376:    */   
/* 377:    */   Iterator<Map.Entry<K, V>> entryIterator()
/* 378:    */   {
/* 379:502 */     new Iterator()
/* 380:    */     {
/* 381:503 */       LinkedHashMultimap.ValueEntry<K, V> nextEntry = LinkedHashMultimap.this.multimapHeaderEntry.successorInMultimap;
/* 382:    */       LinkedHashMultimap.ValueEntry<K, V> toRemove;
/* 383:    */       
/* 384:    */       public boolean hasNext()
/* 385:    */       {
/* 386:508 */         return this.nextEntry != LinkedHashMultimap.this.multimapHeaderEntry;
/* 387:    */       }
/* 388:    */       
/* 389:    */       public Map.Entry<K, V> next()
/* 390:    */       {
/* 391:513 */         if (!hasNext()) {
/* 392:514 */           throw new NoSuchElementException();
/* 393:    */         }
/* 394:516 */         LinkedHashMultimap.ValueEntry<K, V> result = this.nextEntry;
/* 395:517 */         this.toRemove = result;
/* 396:518 */         this.nextEntry = this.nextEntry.successorInMultimap;
/* 397:519 */         return result;
/* 398:    */       }
/* 399:    */       
/* 400:    */       public void remove()
/* 401:    */       {
/* 402:524 */         CollectPreconditions.checkRemove(this.toRemove != null);
/* 403:525 */         LinkedHashMultimap.this.remove(this.toRemove.getKey(), this.toRemove.getValue());
/* 404:526 */         this.toRemove = null;
/* 405:    */       }
/* 406:    */     };
/* 407:    */   }
/* 408:    */   
/* 409:    */   Iterator<V> valueIterator()
/* 410:    */   {
/* 411:533 */     return Maps.valueIterator(entryIterator());
/* 412:    */   }
/* 413:    */   
/* 414:    */   public void clear()
/* 415:    */   {
/* 416:538 */     super.clear();
/* 417:539 */     succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
/* 418:    */   }
/* 419:    */   
/* 420:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 421:    */   private void writeObject(ObjectOutputStream stream)
/* 422:    */     throws IOException
/* 423:    */   {
/* 424:548 */     stream.defaultWriteObject();
/* 425:549 */     stream.writeInt(keySet().size());
/* 426:550 */     for (K key : keySet()) {
/* 427:551 */       stream.writeObject(key);
/* 428:    */     }
/* 429:553 */     stream.writeInt(size());
/* 430:554 */     for (Map.Entry<K, V> entry : entries())
/* 431:    */     {
/* 432:555 */       stream.writeObject(entry.getKey());
/* 433:556 */       stream.writeObject(entry.getValue());
/* 434:    */     }
/* 435:    */   }
/* 436:    */   
/* 437:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 438:    */   private void readObject(ObjectInputStream stream)
/* 439:    */     throws IOException, ClassNotFoundException
/* 440:    */   {
/* 441:562 */     stream.defaultReadObject();
/* 442:563 */     this.multimapHeaderEntry = new ValueEntry(null, null, 0, null);
/* 443:564 */     succeedsInMultimap(this.multimapHeaderEntry, this.multimapHeaderEntry);
/* 444:565 */     this.valueSetCapacity = 2;
/* 445:566 */     int distinctKeys = stream.readInt();
/* 446:567 */     Map<K, Collection<V>> map = new LinkedHashMap();
/* 447:568 */     for (int i = 0; i < distinctKeys; i++)
/* 448:    */     {
/* 449:570 */       K key = stream.readObject();
/* 450:571 */       map.put(key, createCollection(key));
/* 451:    */     }
/* 452:573 */     int entries = stream.readInt();
/* 453:574 */     for (int i = 0; i < entries; i++)
/* 454:    */     {
/* 455:576 */       K key = stream.readObject();
/* 456:    */       
/* 457:578 */       V value = stream.readObject();
/* 458:579 */       ((Collection)map.get(key)).add(value);
/* 459:    */     }
/* 460:581 */     setMap(map);
/* 461:    */   }
/* 462:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.LinkedHashMultimap
 * JD-Core Version:    0.7.0.1
 */