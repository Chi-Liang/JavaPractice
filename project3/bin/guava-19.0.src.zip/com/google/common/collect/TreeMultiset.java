/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.MoreObjects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.primitives.Ints;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.ObjectInputStream;
/*  10:    */ import java.io.ObjectOutputStream;
/*  11:    */ import java.io.Serializable;
/*  12:    */ import java.util.Comparator;
/*  13:    */ import java.util.ConcurrentModificationException;
/*  14:    */ import java.util.Iterator;
/*  15:    */ import java.util.NavigableSet;
/*  16:    */ import java.util.NoSuchElementException;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible(emulated=true)
/*  20:    */ public final class TreeMultiset<E>
/*  21:    */   extends AbstractSortedMultiset<E>
/*  22:    */   implements Serializable
/*  23:    */ {
/*  24:    */   private final transient Reference<AvlNode<E>> rootReference;
/*  25:    */   private final transient GeneralRange<E> range;
/*  26:    */   private final transient AvlNode<E> header;
/*  27:    */   @GwtIncompatible("not needed in emulated source")
/*  28:    */   private static final long serialVersionUID = 1L;
/*  29:    */   
/*  30:    */   public static <E extends Comparable> TreeMultiset<E> create()
/*  31:    */   {
/*  32: 74 */     return new TreeMultiset(Ordering.natural());
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <E> TreeMultiset<E> create(@Nullable Comparator<? super E> comparator)
/*  36:    */   {
/*  37: 91 */     return comparator == null ? new TreeMultiset(Ordering.natural()) : new TreeMultiset(comparator);
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <E extends Comparable> TreeMultiset<E> create(Iterable<? extends E> elements)
/*  41:    */   {
/*  42:106 */     TreeMultiset<E> multiset = create();
/*  43:107 */     Iterables.addAll(multiset, elements);
/*  44:108 */     return multiset;
/*  45:    */   }
/*  46:    */   
/*  47:    */   TreeMultiset(Reference<AvlNode<E>> rootReference, GeneralRange<E> range, AvlNode<E> endLink)
/*  48:    */   {
/*  49:116 */     super(range.comparator());
/*  50:117 */     this.rootReference = rootReference;
/*  51:118 */     this.range = range;
/*  52:119 */     this.header = endLink;
/*  53:    */   }
/*  54:    */   
/*  55:    */   TreeMultiset(Comparator<? super E> comparator)
/*  56:    */   {
/*  57:123 */     super(comparator);
/*  58:124 */     this.range = GeneralRange.all(comparator);
/*  59:125 */     this.header = new AvlNode(null, 1);
/*  60:126 */     successor(this.header, this.header);
/*  61:127 */     this.rootReference = new Reference(null);
/*  62:    */   }
/*  63:    */   
/*  64:    */   private static abstract enum Aggregate
/*  65:    */   {
/*  66:134 */     SIZE,  DISTINCT;
/*  67:    */     
/*  68:    */     private Aggregate() {}
/*  69:    */     
/*  70:    */     abstract int nodeAggregate(TreeMultiset.AvlNode<?> paramAvlNode);
/*  71:    */     
/*  72:    */     abstract long treeAggregate(@Nullable TreeMultiset.AvlNode<?> paramAvlNode);
/*  73:    */   }
/*  74:    */   
/*  75:    */   private long aggregateForEntries(Aggregate aggr)
/*  76:    */   {
/*  77:163 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/*  78:164 */     long total = aggr.treeAggregate(root);
/*  79:165 */     if (this.range.hasLowerBound()) {
/*  80:166 */       total -= aggregateBelowRange(aggr, root);
/*  81:    */     }
/*  82:168 */     if (this.range.hasUpperBound()) {
/*  83:169 */       total -= aggregateAboveRange(aggr, root);
/*  84:    */     }
/*  85:171 */     return total;
/*  86:    */   }
/*  87:    */   
/*  88:    */   private long aggregateBelowRange(Aggregate aggr, @Nullable AvlNode<E> node)
/*  89:    */   {
/*  90:175 */     if (node == null) {
/*  91:176 */       return 0L;
/*  92:    */     }
/*  93:178 */     int cmp = comparator().compare(this.range.getLowerEndpoint(), node.elem);
/*  94:179 */     if (cmp < 0) {
/*  95:180 */       return aggregateBelowRange(aggr, node.left);
/*  96:    */     }
/*  97:181 */     if (cmp == 0)
/*  98:    */     {
/*  99:182 */       switch (4.$SwitchMap$com$google$common$collect$BoundType[this.range.getLowerBoundType().ordinal()])
/* 100:    */       {
/* 101:    */       case 1: 
/* 102:184 */         return aggr.nodeAggregate(node) + aggr.treeAggregate(node.left);
/* 103:    */       case 2: 
/* 104:186 */         return aggr.treeAggregate(node.left);
/* 105:    */       }
/* 106:188 */       throw new AssertionError();
/* 107:    */     }
/* 108:191 */     return aggr.treeAggregate(node.left) + aggr.nodeAggregate(node) + aggregateBelowRange(aggr, node.right);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private long aggregateAboveRange(Aggregate aggr, @Nullable AvlNode<E> node)
/* 112:    */   {
/* 113:198 */     if (node == null) {
/* 114:199 */       return 0L;
/* 115:    */     }
/* 116:201 */     int cmp = comparator().compare(this.range.getUpperEndpoint(), node.elem);
/* 117:202 */     if (cmp > 0) {
/* 118:203 */       return aggregateAboveRange(aggr, node.right);
/* 119:    */     }
/* 120:204 */     if (cmp == 0)
/* 121:    */     {
/* 122:205 */       switch (4.$SwitchMap$com$google$common$collect$BoundType[this.range.getUpperBoundType().ordinal()])
/* 123:    */       {
/* 124:    */       case 1: 
/* 125:207 */         return aggr.nodeAggregate(node) + aggr.treeAggregate(node.right);
/* 126:    */       case 2: 
/* 127:209 */         return aggr.treeAggregate(node.right);
/* 128:    */       }
/* 129:211 */       throw new AssertionError();
/* 130:    */     }
/* 131:214 */     return aggr.treeAggregate(node.right) + aggr.nodeAggregate(node) + aggregateAboveRange(aggr, node.left);
/* 132:    */   }
/* 133:    */   
/* 134:    */   public int size()
/* 135:    */   {
/* 136:222 */     return Ints.saturatedCast(aggregateForEntries(Aggregate.SIZE));
/* 137:    */   }
/* 138:    */   
/* 139:    */   int distinctElements()
/* 140:    */   {
/* 141:227 */     return Ints.saturatedCast(aggregateForEntries(Aggregate.DISTINCT));
/* 142:    */   }
/* 143:    */   
/* 144:    */   public int count(@Nullable Object element)
/* 145:    */   {
/* 146:    */     try
/* 147:    */     {
/* 148:234 */       E e = element;
/* 149:235 */       AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 150:236 */       if ((!this.range.contains(e)) || (root == null)) {
/* 151:237 */         return 0;
/* 152:    */       }
/* 153:239 */       return root.count(comparator(), e);
/* 154:    */     }
/* 155:    */     catch (ClassCastException e)
/* 156:    */     {
/* 157:241 */       return 0;
/* 158:    */     }
/* 159:    */     catch (NullPointerException e) {}
/* 160:243 */     return 0;
/* 161:    */   }
/* 162:    */   
/* 163:    */   public int add(@Nullable E element, int occurrences)
/* 164:    */   {
/* 165:249 */     CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/* 166:250 */     if (occurrences == 0) {
/* 167:251 */       return count(element);
/* 168:    */     }
/* 169:253 */     Preconditions.checkArgument(this.range.contains(element));
/* 170:254 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 171:255 */     if (root == null)
/* 172:    */     {
/* 173:256 */       comparator().compare(element, element);
/* 174:257 */       AvlNode<E> newRoot = new AvlNode(element, occurrences);
/* 175:258 */       successor(this.header, newRoot, this.header);
/* 176:259 */       this.rootReference.checkAndSet(root, newRoot);
/* 177:260 */       return 0;
/* 178:    */     }
/* 179:262 */     int[] result = new int[1];
/* 180:263 */     AvlNode<E> newRoot = root.add(comparator(), element, occurrences, result);
/* 181:264 */     this.rootReference.checkAndSet(root, newRoot);
/* 182:265 */     return result[0];
/* 183:    */   }
/* 184:    */   
/* 185:    */   public int remove(@Nullable Object element, int occurrences)
/* 186:    */   {
/* 187:270 */     CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/* 188:271 */     if (occurrences == 0) {
/* 189:272 */       return count(element);
/* 190:    */     }
/* 191:274 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 192:275 */     int[] result = new int[1];
/* 193:    */     AvlNode<E> newRoot;
/* 194:    */     try
/* 195:    */     {
/* 196:279 */       E e = element;
/* 197:280 */       if ((!this.range.contains(e)) || (root == null)) {
/* 198:281 */         return 0;
/* 199:    */       }
/* 200:283 */       newRoot = root.remove(comparator(), e, occurrences, result);
/* 201:    */     }
/* 202:    */     catch (ClassCastException e)
/* 203:    */     {
/* 204:285 */       return 0;
/* 205:    */     }
/* 206:    */     catch (NullPointerException e)
/* 207:    */     {
/* 208:287 */       return 0;
/* 209:    */     }
/* 210:289 */     this.rootReference.checkAndSet(root, newRoot);
/* 211:290 */     return result[0];
/* 212:    */   }
/* 213:    */   
/* 214:    */   public int setCount(@Nullable E element, int count)
/* 215:    */   {
/* 216:295 */     CollectPreconditions.checkNonnegative(count, "count");
/* 217:296 */     if (!this.range.contains(element))
/* 218:    */     {
/* 219:297 */       Preconditions.checkArgument(count == 0);
/* 220:298 */       return 0;
/* 221:    */     }
/* 222:301 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 223:302 */     if (root == null)
/* 224:    */     {
/* 225:303 */       if (count > 0) {
/* 226:304 */         add(element, count);
/* 227:    */       }
/* 228:306 */       return 0;
/* 229:    */     }
/* 230:308 */     int[] result = new int[1];
/* 231:309 */     AvlNode<E> newRoot = root.setCount(comparator(), element, count, result);
/* 232:310 */     this.rootReference.checkAndSet(root, newRoot);
/* 233:311 */     return result[0];
/* 234:    */   }
/* 235:    */   
/* 236:    */   public boolean setCount(@Nullable E element, int oldCount, int newCount)
/* 237:    */   {
/* 238:316 */     CollectPreconditions.checkNonnegative(newCount, "newCount");
/* 239:317 */     CollectPreconditions.checkNonnegative(oldCount, "oldCount");
/* 240:318 */     Preconditions.checkArgument(this.range.contains(element));
/* 241:    */     
/* 242:320 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 243:321 */     if (root == null)
/* 244:    */     {
/* 245:322 */       if (oldCount == 0)
/* 246:    */       {
/* 247:323 */         if (newCount > 0) {
/* 248:324 */           add(element, newCount);
/* 249:    */         }
/* 250:326 */         return true;
/* 251:    */       }
/* 252:328 */       return false;
/* 253:    */     }
/* 254:331 */     int[] result = new int[1];
/* 255:332 */     AvlNode<E> newRoot = root.setCount(comparator(), element, oldCount, newCount, result);
/* 256:333 */     this.rootReference.checkAndSet(root, newRoot);
/* 257:334 */     return result[0] == oldCount;
/* 258:    */   }
/* 259:    */   
/* 260:    */   private Multiset.Entry<E> wrapEntry(final AvlNode<E> baseEntry)
/* 261:    */   {
/* 262:338 */     new Multisets.AbstractEntry()
/* 263:    */     {
/* 264:    */       public E getElement()
/* 265:    */       {
/* 266:341 */         return baseEntry.getElement();
/* 267:    */       }
/* 268:    */       
/* 269:    */       public int getCount()
/* 270:    */       {
/* 271:346 */         int result = baseEntry.getCount();
/* 272:347 */         if (result == 0) {
/* 273:348 */           return TreeMultiset.this.count(getElement());
/* 274:    */         }
/* 275:350 */         return result;
/* 276:    */       }
/* 277:    */     };
/* 278:    */   }
/* 279:    */   
/* 280:    */   @Nullable
/* 281:    */   private AvlNode<E> firstNode()
/* 282:    */   {
/* 283:361 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 284:362 */     if (root == null) {
/* 285:363 */       return null;
/* 286:    */     }
/* 287:    */     AvlNode<E> node;
/* 288:366 */     if (this.range.hasLowerBound())
/* 289:    */     {
/* 290:367 */       E endpoint = this.range.getLowerEndpoint();
/* 291:368 */       AvlNode<E> node = ((AvlNode)this.rootReference.get()).ceiling(comparator(), endpoint);
/* 292:369 */       if (node == null) {
/* 293:370 */         return null;
/* 294:    */       }
/* 295:372 */       if ((this.range.getLowerBoundType() == BoundType.OPEN) && (comparator().compare(endpoint, node.getElement()) == 0)) {
/* 296:374 */         node = node.succ;
/* 297:    */       }
/* 298:    */     }
/* 299:    */     else
/* 300:    */     {
/* 301:377 */       node = this.header.succ;
/* 302:    */     }
/* 303:379 */     return (node == this.header) || (!this.range.contains(node.getElement())) ? null : node;
/* 304:    */   }
/* 305:    */   
/* 306:    */   @Nullable
/* 307:    */   private AvlNode<E> lastNode()
/* 308:    */   {
/* 309:384 */     AvlNode<E> root = (AvlNode)this.rootReference.get();
/* 310:385 */     if (root == null) {
/* 311:386 */       return null;
/* 312:    */     }
/* 313:    */     AvlNode<E> node;
/* 314:389 */     if (this.range.hasUpperBound())
/* 315:    */     {
/* 316:390 */       E endpoint = this.range.getUpperEndpoint();
/* 317:391 */       AvlNode<E> node = ((AvlNode)this.rootReference.get()).floor(comparator(), endpoint);
/* 318:392 */       if (node == null) {
/* 319:393 */         return null;
/* 320:    */       }
/* 321:395 */       if ((this.range.getUpperBoundType() == BoundType.OPEN) && (comparator().compare(endpoint, node.getElement()) == 0)) {
/* 322:397 */         node = node.pred;
/* 323:    */       }
/* 324:    */     }
/* 325:    */     else
/* 326:    */     {
/* 327:400 */       node = this.header.pred;
/* 328:    */     }
/* 329:402 */     return (node == this.header) || (!this.range.contains(node.getElement())) ? null : node;
/* 330:    */   }
/* 331:    */   
/* 332:    */   Iterator<Multiset.Entry<E>> entryIterator()
/* 333:    */   {
/* 334:407 */     new Iterator()
/* 335:    */     {
/* 336:408 */       TreeMultiset.AvlNode<E> current = TreeMultiset.this.firstNode();
/* 337:    */       Multiset.Entry<E> prevEntry;
/* 338:    */       
/* 339:    */       public boolean hasNext()
/* 340:    */       {
/* 341:413 */         if (this.current == null) {
/* 342:414 */           return false;
/* 343:    */         }
/* 344:415 */         if (TreeMultiset.this.range.tooHigh(this.current.getElement()))
/* 345:    */         {
/* 346:416 */           this.current = null;
/* 347:417 */           return false;
/* 348:    */         }
/* 349:419 */         return true;
/* 350:    */       }
/* 351:    */       
/* 352:    */       public Multiset.Entry<E> next()
/* 353:    */       {
/* 354:425 */         if (!hasNext()) {
/* 355:426 */           throw new NoSuchElementException();
/* 356:    */         }
/* 357:428 */         Multiset.Entry<E> result = TreeMultiset.this.wrapEntry(this.current);
/* 358:429 */         this.prevEntry = result;
/* 359:430 */         if (this.current.succ == TreeMultiset.this.header) {
/* 360:431 */           this.current = null;
/* 361:    */         } else {
/* 362:433 */           this.current = this.current.succ;
/* 363:    */         }
/* 364:435 */         return result;
/* 365:    */       }
/* 366:    */       
/* 367:    */       public void remove()
/* 368:    */       {
/* 369:440 */         CollectPreconditions.checkRemove(this.prevEntry != null);
/* 370:441 */         TreeMultiset.this.setCount(this.prevEntry.getElement(), 0);
/* 371:442 */         this.prevEntry = null;
/* 372:    */       }
/* 373:    */     };
/* 374:    */   }
/* 375:    */   
/* 376:    */   Iterator<Multiset.Entry<E>> descendingEntryIterator()
/* 377:    */   {
/* 378:449 */     new Iterator()
/* 379:    */     {
/* 380:450 */       TreeMultiset.AvlNode<E> current = TreeMultiset.this.lastNode();
/* 381:451 */       Multiset.Entry<E> prevEntry = null;
/* 382:    */       
/* 383:    */       public boolean hasNext()
/* 384:    */       {
/* 385:455 */         if (this.current == null) {
/* 386:456 */           return false;
/* 387:    */         }
/* 388:457 */         if (TreeMultiset.this.range.tooLow(this.current.getElement()))
/* 389:    */         {
/* 390:458 */           this.current = null;
/* 391:459 */           return false;
/* 392:    */         }
/* 393:461 */         return true;
/* 394:    */       }
/* 395:    */       
/* 396:    */       public Multiset.Entry<E> next()
/* 397:    */       {
/* 398:467 */         if (!hasNext()) {
/* 399:468 */           throw new NoSuchElementException();
/* 400:    */         }
/* 401:470 */         Multiset.Entry<E> result = TreeMultiset.this.wrapEntry(this.current);
/* 402:471 */         this.prevEntry = result;
/* 403:472 */         if (this.current.pred == TreeMultiset.this.header) {
/* 404:473 */           this.current = null;
/* 405:    */         } else {
/* 406:475 */           this.current = this.current.pred;
/* 407:    */         }
/* 408:477 */         return result;
/* 409:    */       }
/* 410:    */       
/* 411:    */       public void remove()
/* 412:    */       {
/* 413:482 */         CollectPreconditions.checkRemove(this.prevEntry != null);
/* 414:483 */         TreeMultiset.this.setCount(this.prevEntry.getElement(), 0);
/* 415:484 */         this.prevEntry = null;
/* 416:    */       }
/* 417:    */     };
/* 418:    */   }
/* 419:    */   
/* 420:    */   public SortedMultiset<E> headMultiset(@Nullable E upperBound, BoundType boundType)
/* 421:    */   {
/* 422:491 */     return new TreeMultiset(this.rootReference, this.range.intersect(GeneralRange.upTo(comparator(), upperBound, boundType)), this.header);
/* 423:    */   }
/* 424:    */   
/* 425:    */   public SortedMultiset<E> tailMultiset(@Nullable E lowerBound, BoundType boundType)
/* 426:    */   {
/* 427:499 */     return new TreeMultiset(this.rootReference, this.range.intersect(GeneralRange.downTo(comparator(), lowerBound, boundType)), this.header);
/* 428:    */   }
/* 429:    */   
/* 430:    */   static int distinctElements(@Nullable AvlNode<?> node)
/* 431:    */   {
/* 432:506 */     return node == null ? 0 : node.distinctElements;
/* 433:    */   }
/* 434:    */   
/* 435:    */   private static final class Reference<T>
/* 436:    */   {
/* 437:    */     @Nullable
/* 438:    */     private T value;
/* 439:    */     
/* 440:    */     @Nullable
/* 441:    */     public T get()
/* 442:    */     {
/* 443:514 */       return this.value;
/* 444:    */     }
/* 445:    */     
/* 446:    */     public void checkAndSet(@Nullable T expected, T newValue)
/* 447:    */     {
/* 448:518 */       if (this.value != expected) {
/* 449:519 */         throw new ConcurrentModificationException();
/* 450:    */       }
/* 451:521 */       this.value = newValue;
/* 452:    */     }
/* 453:    */   }
/* 454:    */   
/* 455:    */   private static final class AvlNode<E>
/* 456:    */     extends Multisets.AbstractEntry<E>
/* 457:    */   {
/* 458:    */     @Nullable
/* 459:    */     private final E elem;
/* 460:    */     private int elemCount;
/* 461:    */     private int distinctElements;
/* 462:    */     private long totalCount;
/* 463:    */     private int height;
/* 464:    */     private AvlNode<E> left;
/* 465:    */     private AvlNode<E> right;
/* 466:    */     private AvlNode<E> pred;
/* 467:    */     private AvlNode<E> succ;
/* 468:    */     
/* 469:    */     AvlNode(@Nullable E elem, int elemCount)
/* 470:    */     {
/* 471:540 */       Preconditions.checkArgument(elemCount > 0);
/* 472:541 */       this.elem = elem;
/* 473:542 */       this.elemCount = elemCount;
/* 474:543 */       this.totalCount = elemCount;
/* 475:544 */       this.distinctElements = 1;
/* 476:545 */       this.height = 1;
/* 477:546 */       this.left = null;
/* 478:547 */       this.right = null;
/* 479:    */     }
/* 480:    */     
/* 481:    */     public int count(Comparator<? super E> comparator, E e)
/* 482:    */     {
/* 483:551 */       int cmp = comparator.compare(e, this.elem);
/* 484:552 */       if (cmp < 0) {
/* 485:553 */         return this.left == null ? 0 : this.left.count(comparator, e);
/* 486:    */       }
/* 487:554 */       if (cmp > 0) {
/* 488:555 */         return this.right == null ? 0 : this.right.count(comparator, e);
/* 489:    */       }
/* 490:557 */       return this.elemCount;
/* 491:    */     }
/* 492:    */     
/* 493:    */     private AvlNode<E> addRightChild(E e, int count)
/* 494:    */     {
/* 495:562 */       this.right = new AvlNode(e, count);
/* 496:563 */       TreeMultiset.successor(this, this.right, this.succ);
/* 497:564 */       this.height = Math.max(2, this.height);
/* 498:565 */       this.distinctElements += 1;
/* 499:566 */       this.totalCount += count;
/* 500:567 */       return this;
/* 501:    */     }
/* 502:    */     
/* 503:    */     private AvlNode<E> addLeftChild(E e, int count)
/* 504:    */     {
/* 505:571 */       this.left = new AvlNode(e, count);
/* 506:572 */       TreeMultiset.successor(this.pred, this.left, this);
/* 507:573 */       this.height = Math.max(2, this.height);
/* 508:574 */       this.distinctElements += 1;
/* 509:575 */       this.totalCount += count;
/* 510:576 */       return this;
/* 511:    */     }
/* 512:    */     
/* 513:    */     AvlNode<E> add(Comparator<? super E> comparator, @Nullable E e, int count, int[] result)
/* 514:    */     {
/* 515:584 */       int cmp = comparator.compare(e, this.elem);
/* 516:585 */       if (cmp < 0)
/* 517:    */       {
/* 518:586 */         AvlNode<E> initLeft = this.left;
/* 519:587 */         if (initLeft == null)
/* 520:    */         {
/* 521:588 */           result[0] = 0;
/* 522:589 */           return addLeftChild(e, count);
/* 523:    */         }
/* 524:591 */         int initHeight = initLeft.height;
/* 525:    */         
/* 526:593 */         this.left = initLeft.add(comparator, e, count, result);
/* 527:594 */         if (result[0] == 0) {
/* 528:595 */           this.distinctElements += 1;
/* 529:    */         }
/* 530:597 */         this.totalCount += count;
/* 531:598 */         return this.left.height == initHeight ? this : rebalance();
/* 532:    */       }
/* 533:599 */       if (cmp > 0)
/* 534:    */       {
/* 535:600 */         AvlNode<E> initRight = this.right;
/* 536:601 */         if (initRight == null)
/* 537:    */         {
/* 538:602 */           result[0] = 0;
/* 539:603 */           return addRightChild(e, count);
/* 540:    */         }
/* 541:605 */         int initHeight = initRight.height;
/* 542:    */         
/* 543:607 */         this.right = initRight.add(comparator, e, count, result);
/* 544:608 */         if (result[0] == 0) {
/* 545:609 */           this.distinctElements += 1;
/* 546:    */         }
/* 547:611 */         this.totalCount += count;
/* 548:612 */         return this.right.height == initHeight ? this : rebalance();
/* 549:    */       }
/* 550:616 */       result[0] = this.elemCount;
/* 551:617 */       long resultCount = this.elemCount + count;
/* 552:618 */       Preconditions.checkArgument(resultCount <= 2147483647L);
/* 553:619 */       this.elemCount += count;
/* 554:620 */       this.totalCount += count;
/* 555:621 */       return this;
/* 556:    */     }
/* 557:    */     
/* 558:    */     AvlNode<E> remove(Comparator<? super E> comparator, @Nullable E e, int count, int[] result)
/* 559:    */     {
/* 560:625 */       int cmp = comparator.compare(e, this.elem);
/* 561:626 */       if (cmp < 0)
/* 562:    */       {
/* 563:627 */         AvlNode<E> initLeft = this.left;
/* 564:628 */         if (initLeft == null)
/* 565:    */         {
/* 566:629 */           result[0] = 0;
/* 567:630 */           return this;
/* 568:    */         }
/* 569:633 */         this.left = initLeft.remove(comparator, e, count, result);
/* 570:635 */         if (result[0] > 0) {
/* 571:636 */           if (count >= result[0])
/* 572:    */           {
/* 573:637 */             this.distinctElements -= 1;
/* 574:638 */             this.totalCount -= result[0];
/* 575:    */           }
/* 576:    */           else
/* 577:    */           {
/* 578:640 */             this.totalCount -= count;
/* 579:    */           }
/* 580:    */         }
/* 581:643 */         return result[0] == 0 ? this : rebalance();
/* 582:    */       }
/* 583:644 */       if (cmp > 0)
/* 584:    */       {
/* 585:645 */         AvlNode<E> initRight = this.right;
/* 586:646 */         if (initRight == null)
/* 587:    */         {
/* 588:647 */           result[0] = 0;
/* 589:648 */           return this;
/* 590:    */         }
/* 591:651 */         this.right = initRight.remove(comparator, e, count, result);
/* 592:653 */         if (result[0] > 0) {
/* 593:654 */           if (count >= result[0])
/* 594:    */           {
/* 595:655 */             this.distinctElements -= 1;
/* 596:656 */             this.totalCount -= result[0];
/* 597:    */           }
/* 598:    */           else
/* 599:    */           {
/* 600:658 */             this.totalCount -= count;
/* 601:    */           }
/* 602:    */         }
/* 603:661 */         return rebalance();
/* 604:    */       }
/* 605:665 */       result[0] = this.elemCount;
/* 606:666 */       if (count >= this.elemCount) {
/* 607:667 */         return deleteMe();
/* 608:    */       }
/* 609:669 */       this.elemCount -= count;
/* 610:670 */       this.totalCount -= count;
/* 611:671 */       return this;
/* 612:    */     }
/* 613:    */     
/* 614:    */     AvlNode<E> setCount(Comparator<? super E> comparator, @Nullable E e, int count, int[] result)
/* 615:    */     {
/* 616:676 */       int cmp = comparator.compare(e, this.elem);
/* 617:677 */       if (cmp < 0)
/* 618:    */       {
/* 619:678 */         AvlNode<E> initLeft = this.left;
/* 620:679 */         if (initLeft == null)
/* 621:    */         {
/* 622:680 */           result[0] = 0;
/* 623:681 */           return count > 0 ? addLeftChild(e, count) : this;
/* 624:    */         }
/* 625:684 */         this.left = initLeft.setCount(comparator, e, count, result);
/* 626:686 */         if ((count == 0) && (result[0] != 0)) {
/* 627:687 */           this.distinctElements -= 1;
/* 628:688 */         } else if ((count > 0) && (result[0] == 0)) {
/* 629:689 */           this.distinctElements += 1;
/* 630:    */         }
/* 631:692 */         this.totalCount += count - result[0];
/* 632:693 */         return rebalance();
/* 633:    */       }
/* 634:694 */       if (cmp > 0)
/* 635:    */       {
/* 636:695 */         AvlNode<E> initRight = this.right;
/* 637:696 */         if (initRight == null)
/* 638:    */         {
/* 639:697 */           result[0] = 0;
/* 640:698 */           return count > 0 ? addRightChild(e, count) : this;
/* 641:    */         }
/* 642:701 */         this.right = initRight.setCount(comparator, e, count, result);
/* 643:703 */         if ((count == 0) && (result[0] != 0)) {
/* 644:704 */           this.distinctElements -= 1;
/* 645:705 */         } else if ((count > 0) && (result[0] == 0)) {
/* 646:706 */           this.distinctElements += 1;
/* 647:    */         }
/* 648:709 */         this.totalCount += count - result[0];
/* 649:710 */         return rebalance();
/* 650:    */       }
/* 651:714 */       result[0] = this.elemCount;
/* 652:715 */       if (count == 0) {
/* 653:716 */         return deleteMe();
/* 654:    */       }
/* 655:718 */       this.totalCount += count - this.elemCount;
/* 656:719 */       this.elemCount = count;
/* 657:720 */       return this;
/* 658:    */     }
/* 659:    */     
/* 660:    */     AvlNode<E> setCount(Comparator<? super E> comparator, @Nullable E e, int expectedCount, int newCount, int[] result)
/* 661:    */     {
/* 662:729 */       int cmp = comparator.compare(e, this.elem);
/* 663:730 */       if (cmp < 0)
/* 664:    */       {
/* 665:731 */         AvlNode<E> initLeft = this.left;
/* 666:732 */         if (initLeft == null)
/* 667:    */         {
/* 668:733 */           result[0] = 0;
/* 669:734 */           if ((expectedCount == 0) && (newCount > 0)) {
/* 670:735 */             return addLeftChild(e, newCount);
/* 671:    */           }
/* 672:737 */           return this;
/* 673:    */         }
/* 674:740 */         this.left = initLeft.setCount(comparator, e, expectedCount, newCount, result);
/* 675:742 */         if (result[0] == expectedCount)
/* 676:    */         {
/* 677:743 */           if ((newCount == 0) && (result[0] != 0)) {
/* 678:744 */             this.distinctElements -= 1;
/* 679:745 */           } else if ((newCount > 0) && (result[0] == 0)) {
/* 680:746 */             this.distinctElements += 1;
/* 681:    */           }
/* 682:748 */           this.totalCount += newCount - result[0];
/* 683:    */         }
/* 684:750 */         return rebalance();
/* 685:    */       }
/* 686:751 */       if (cmp > 0)
/* 687:    */       {
/* 688:752 */         AvlNode<E> initRight = this.right;
/* 689:753 */         if (initRight == null)
/* 690:    */         {
/* 691:754 */           result[0] = 0;
/* 692:755 */           if ((expectedCount == 0) && (newCount > 0)) {
/* 693:756 */             return addRightChild(e, newCount);
/* 694:    */           }
/* 695:758 */           return this;
/* 696:    */         }
/* 697:761 */         this.right = initRight.setCount(comparator, e, expectedCount, newCount, result);
/* 698:763 */         if (result[0] == expectedCount)
/* 699:    */         {
/* 700:764 */           if ((newCount == 0) && (result[0] != 0)) {
/* 701:765 */             this.distinctElements -= 1;
/* 702:766 */           } else if ((newCount > 0) && (result[0] == 0)) {
/* 703:767 */             this.distinctElements += 1;
/* 704:    */           }
/* 705:769 */           this.totalCount += newCount - result[0];
/* 706:    */         }
/* 707:771 */         return rebalance();
/* 708:    */       }
/* 709:775 */       result[0] = this.elemCount;
/* 710:776 */       if (expectedCount == this.elemCount)
/* 711:    */       {
/* 712:777 */         if (newCount == 0) {
/* 713:778 */           return deleteMe();
/* 714:    */         }
/* 715:780 */         this.totalCount += newCount - this.elemCount;
/* 716:781 */         this.elemCount = newCount;
/* 717:    */       }
/* 718:783 */       return this;
/* 719:    */     }
/* 720:    */     
/* 721:    */     private AvlNode<E> deleteMe()
/* 722:    */     {
/* 723:787 */       int oldElemCount = this.elemCount;
/* 724:788 */       this.elemCount = 0;
/* 725:789 */       TreeMultiset.successor(this.pred, this.succ);
/* 726:790 */       if (this.left == null) {
/* 727:791 */         return this.right;
/* 728:    */       }
/* 729:792 */       if (this.right == null) {
/* 730:793 */         return this.left;
/* 731:    */       }
/* 732:794 */       if (this.left.height >= this.right.height)
/* 733:    */       {
/* 734:795 */         AvlNode<E> newTop = this.pred;
/* 735:    */         
/* 736:797 */         newTop.left = this.left.removeMax(newTop);
/* 737:798 */         newTop.right = this.right;
/* 738:799 */         this.distinctElements -= 1;
/* 739:800 */         this.totalCount -= oldElemCount;
/* 740:801 */         return newTop.rebalance();
/* 741:    */       }
/* 742:803 */       AvlNode<E> newTop = this.succ;
/* 743:804 */       newTop.right = this.right.removeMin(newTop);
/* 744:805 */       newTop.left = this.left;
/* 745:806 */       this.distinctElements -= 1;
/* 746:807 */       this.totalCount -= oldElemCount;
/* 747:808 */       return newTop.rebalance();
/* 748:    */     }
/* 749:    */     
/* 750:    */     private AvlNode<E> removeMin(AvlNode<E> node)
/* 751:    */     {
/* 752:814 */       if (this.left == null) {
/* 753:815 */         return this.right;
/* 754:    */       }
/* 755:817 */       this.left = this.left.removeMin(node);
/* 756:818 */       this.distinctElements -= 1;
/* 757:819 */       this.totalCount -= node.elemCount;
/* 758:820 */       return rebalance();
/* 759:    */     }
/* 760:    */     
/* 761:    */     private AvlNode<E> removeMax(AvlNode<E> node)
/* 762:    */     {
/* 763:826 */       if (this.right == null) {
/* 764:827 */         return this.left;
/* 765:    */       }
/* 766:829 */       this.right = this.right.removeMax(node);
/* 767:830 */       this.distinctElements -= 1;
/* 768:831 */       this.totalCount -= node.elemCount;
/* 769:832 */       return rebalance();
/* 770:    */     }
/* 771:    */     
/* 772:    */     private void recomputeMultiset()
/* 773:    */     {
/* 774:837 */       this.distinctElements = (1 + TreeMultiset.distinctElements(this.left) + TreeMultiset.distinctElements(this.right));
/* 775:    */       
/* 776:839 */       this.totalCount = (this.elemCount + totalCount(this.left) + totalCount(this.right));
/* 777:    */     }
/* 778:    */     
/* 779:    */     private void recomputeHeight()
/* 780:    */     {
/* 781:843 */       this.height = (1 + Math.max(height(this.left), height(this.right)));
/* 782:    */     }
/* 783:    */     
/* 784:    */     private void recompute()
/* 785:    */     {
/* 786:847 */       recomputeMultiset();
/* 787:848 */       recomputeHeight();
/* 788:    */     }
/* 789:    */     
/* 790:    */     private AvlNode<E> rebalance()
/* 791:    */     {
/* 792:852 */       switch (balanceFactor())
/* 793:    */       {
/* 794:    */       case -2: 
/* 795:854 */         if (this.right.balanceFactor() > 0) {
/* 796:855 */           this.right = this.right.rotateRight();
/* 797:    */         }
/* 798:857 */         return rotateLeft();
/* 799:    */       case 2: 
/* 800:859 */         if (this.left.balanceFactor() < 0) {
/* 801:860 */           this.left = this.left.rotateLeft();
/* 802:    */         }
/* 803:862 */         return rotateRight();
/* 804:    */       }
/* 805:864 */       recomputeHeight();
/* 806:865 */       return this;
/* 807:    */     }
/* 808:    */     
/* 809:    */     private int balanceFactor()
/* 810:    */     {
/* 811:870 */       return height(this.left) - height(this.right);
/* 812:    */     }
/* 813:    */     
/* 814:    */     private AvlNode<E> rotateLeft()
/* 815:    */     {
/* 816:874 */       Preconditions.checkState(this.right != null);
/* 817:875 */       AvlNode<E> newTop = this.right;
/* 818:876 */       this.right = newTop.left;
/* 819:877 */       newTop.left = this;
/* 820:878 */       newTop.totalCount = this.totalCount;
/* 821:879 */       newTop.distinctElements = this.distinctElements;
/* 822:880 */       recompute();
/* 823:881 */       newTop.recomputeHeight();
/* 824:882 */       return newTop;
/* 825:    */     }
/* 826:    */     
/* 827:    */     private AvlNode<E> rotateRight()
/* 828:    */     {
/* 829:886 */       Preconditions.checkState(this.left != null);
/* 830:887 */       AvlNode<E> newTop = this.left;
/* 831:888 */       this.left = newTop.right;
/* 832:889 */       newTop.right = this;
/* 833:890 */       newTop.totalCount = this.totalCount;
/* 834:891 */       newTop.distinctElements = this.distinctElements;
/* 835:892 */       recompute();
/* 836:893 */       newTop.recomputeHeight();
/* 837:894 */       return newTop;
/* 838:    */     }
/* 839:    */     
/* 840:    */     private static long totalCount(@Nullable AvlNode<?> node)
/* 841:    */     {
/* 842:898 */       return node == null ? 0L : node.totalCount;
/* 843:    */     }
/* 844:    */     
/* 845:    */     private static int height(@Nullable AvlNode<?> node)
/* 846:    */     {
/* 847:902 */       return node == null ? 0 : node.height;
/* 848:    */     }
/* 849:    */     
/* 850:    */     @Nullable
/* 851:    */     private AvlNode<E> ceiling(Comparator<? super E> comparator, E e)
/* 852:    */     {
/* 853:907 */       int cmp = comparator.compare(e, this.elem);
/* 854:908 */       if (cmp < 0) {
/* 855:909 */         return this.left == null ? this : (AvlNode)MoreObjects.firstNonNull(this.left.ceiling(comparator, e), this);
/* 856:    */       }
/* 857:910 */       if (cmp == 0) {
/* 858:911 */         return this;
/* 859:    */       }
/* 860:913 */       return this.right == null ? null : this.right.ceiling(comparator, e);
/* 861:    */     }
/* 862:    */     
/* 863:    */     @Nullable
/* 864:    */     private AvlNode<E> floor(Comparator<? super E> comparator, E e)
/* 865:    */     {
/* 866:919 */       int cmp = comparator.compare(e, this.elem);
/* 867:920 */       if (cmp > 0) {
/* 868:921 */         return this.right == null ? this : (AvlNode)MoreObjects.firstNonNull(this.right.floor(comparator, e), this);
/* 869:    */       }
/* 870:922 */       if (cmp == 0) {
/* 871:923 */         return this;
/* 872:    */       }
/* 873:925 */       return this.left == null ? null : this.left.floor(comparator, e);
/* 874:    */     }
/* 875:    */     
/* 876:    */     public E getElement()
/* 877:    */     {
/* 878:931 */       return this.elem;
/* 879:    */     }
/* 880:    */     
/* 881:    */     public int getCount()
/* 882:    */     {
/* 883:936 */       return this.elemCount;
/* 884:    */     }
/* 885:    */     
/* 886:    */     public String toString()
/* 887:    */     {
/* 888:941 */       return Multisets.immutableEntry(getElement(), getCount()).toString();
/* 889:    */     }
/* 890:    */   }
/* 891:    */   
/* 892:    */   private static <T> void successor(AvlNode<T> a, AvlNode<T> b)
/* 893:    */   {
/* 894:946 */     a.succ = b;
/* 895:947 */     b.pred = a;
/* 896:    */   }
/* 897:    */   
/* 898:    */   private static <T> void successor(AvlNode<T> a, AvlNode<T> b, AvlNode<T> c)
/* 899:    */   {
/* 900:951 */     successor(a, b);
/* 901:952 */     successor(b, c);
/* 902:    */   }
/* 903:    */   
/* 904:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 905:    */   private void writeObject(ObjectOutputStream stream)
/* 906:    */     throws IOException
/* 907:    */   {
/* 908:967 */     stream.defaultWriteObject();
/* 909:968 */     stream.writeObject(elementSet().comparator());
/* 910:969 */     Serialization.writeMultiset(this, stream);
/* 911:    */   }
/* 912:    */   
/* 913:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 914:    */   private void readObject(ObjectInputStream stream)
/* 915:    */     throws IOException, ClassNotFoundException
/* 916:    */   {
/* 917:974 */     stream.defaultReadObject();
/* 918:    */     
/* 919:    */ 
/* 920:977 */     Comparator<? super E> comparator = (Comparator)stream.readObject();
/* 921:978 */     Serialization.getFieldSetter(AbstractSortedMultiset.class, "comparator").set(this, comparator);
/* 922:979 */     Serialization.getFieldSetter(TreeMultiset.class, "range").set(this, GeneralRange.all(comparator));
/* 923:    */     
/* 924:981 */     Serialization.getFieldSetter(TreeMultiset.class, "rootReference").set(this, new Reference(null));
/* 925:    */     
/* 926:983 */     AvlNode<E> header = new AvlNode(null, 1);
/* 927:984 */     Serialization.getFieldSetter(TreeMultiset.class, "header").set(this, header);
/* 928:985 */     successor(header, header);
/* 929:986 */     Serialization.populateMultiset(this, stream);
/* 930:    */   }
/* 931:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.TreeMultiset
 * JD-Core Version:    0.7.0.1
 */