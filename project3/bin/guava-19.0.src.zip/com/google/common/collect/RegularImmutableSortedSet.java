/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.Comparator;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.NoSuchElementException;
/*  11:    */ import java.util.Set;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ final class RegularImmutableSortedSet<E>
/*  16:    */   extends ImmutableSortedSet<E>
/*  17:    */ {
/*  18:    */   private final transient ImmutableList<E> elements;
/*  19:    */   
/*  20:    */   RegularImmutableSortedSet(ImmutableList<E> elements, Comparator<? super E> comparator)
/*  21:    */   {
/*  22: 52 */     super(comparator);
/*  23: 53 */     this.elements = elements;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public UnmodifiableIterator<E> iterator()
/*  27:    */   {
/*  28: 58 */     return this.elements.iterator();
/*  29:    */   }
/*  30:    */   
/*  31:    */   @GwtIncompatible("NavigableSet")
/*  32:    */   public UnmodifiableIterator<E> descendingIterator()
/*  33:    */   {
/*  34: 64 */     return this.elements.reverse().iterator();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public int size()
/*  38:    */   {
/*  39: 69 */     return this.elements.size();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean contains(@Nullable Object o)
/*  43:    */   {
/*  44:    */     try
/*  45:    */     {
/*  46: 75 */       return (o != null) && (unsafeBinarySearch(o) >= 0);
/*  47:    */     }
/*  48:    */     catch (ClassCastException e) {}
/*  49: 77 */     return false;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public boolean containsAll(Collection<?> targets)
/*  53:    */   {
/*  54: 87 */     if ((targets instanceof Multiset)) {
/*  55: 88 */       targets = ((Multiset)targets).elementSet();
/*  56:    */     }
/*  57: 90 */     if ((!SortedIterables.hasSameComparator(comparator(), targets)) || (targets.size() <= 1)) {
/*  58: 91 */       return super.containsAll(targets);
/*  59:    */     }
/*  60: 98 */     PeekingIterator<E> thisIterator = Iterators.peekingIterator(iterator());
/*  61: 99 */     Iterator<?> thatIterator = targets.iterator();
/*  62:100 */     Object target = thatIterator.next();
/*  63:    */     try
/*  64:    */     {
/*  65:104 */       while (thisIterator.hasNext())
/*  66:    */       {
/*  67:106 */         int cmp = unsafeCompare(thisIterator.peek(), target);
/*  68:108 */         if (cmp < 0)
/*  69:    */         {
/*  70:109 */           thisIterator.next();
/*  71:    */         }
/*  72:110 */         else if (cmp == 0)
/*  73:    */         {
/*  74:112 */           if (!thatIterator.hasNext()) {
/*  75:114 */             return true;
/*  76:    */           }
/*  77:117 */           target = thatIterator.next();
/*  78:    */         }
/*  79:119 */         else if (cmp > 0)
/*  80:    */         {
/*  81:120 */           return false;
/*  82:    */         }
/*  83:    */       }
/*  84:    */     }
/*  85:    */     catch (NullPointerException e)
/*  86:    */     {
/*  87:124 */       return false;
/*  88:    */     }
/*  89:    */     catch (ClassCastException e)
/*  90:    */     {
/*  91:126 */       return false;
/*  92:    */     }
/*  93:129 */     return false;
/*  94:    */   }
/*  95:    */   
/*  96:    */   private int unsafeBinarySearch(Object key)
/*  97:    */     throws ClassCastException
/*  98:    */   {
/*  99:133 */     return Collections.binarySearch(this.elements, key, unsafeComparator());
/* 100:    */   }
/* 101:    */   
/* 102:    */   boolean isPartialView()
/* 103:    */   {
/* 104:138 */     return this.elements.isPartialView();
/* 105:    */   }
/* 106:    */   
/* 107:    */   int copyIntoArray(Object[] dst, int offset)
/* 108:    */   {
/* 109:143 */     return this.elements.copyIntoArray(dst, offset);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean equals(@Nullable Object object)
/* 113:    */   {
/* 114:148 */     if (object == this) {
/* 115:149 */       return true;
/* 116:    */     }
/* 117:151 */     if (!(object instanceof Set)) {
/* 118:152 */       return false;
/* 119:    */     }
/* 120:155 */     Set<?> that = (Set)object;
/* 121:156 */     if (size() != that.size()) {
/* 122:157 */       return false;
/* 123:    */     }
/* 124:158 */     if (isEmpty()) {
/* 125:159 */       return true;
/* 126:    */     }
/* 127:162 */     if (SortedIterables.hasSameComparator(this.comparator, that))
/* 128:    */     {
/* 129:163 */       Iterator<?> otherIterator = that.iterator();
/* 130:    */       try
/* 131:    */       {
/* 132:165 */         Iterator<E> iterator = iterator();
/* 133:166 */         while (iterator.hasNext())
/* 134:    */         {
/* 135:167 */           Object element = iterator.next();
/* 136:168 */           Object otherElement = otherIterator.next();
/* 137:169 */           if ((otherElement == null) || (unsafeCompare(element, otherElement) != 0)) {
/* 138:170 */             return false;
/* 139:    */           }
/* 140:    */         }
/* 141:173 */         return true;
/* 142:    */       }
/* 143:    */       catch (ClassCastException e)
/* 144:    */       {
/* 145:175 */         return false;
/* 146:    */       }
/* 147:    */       catch (NoSuchElementException e)
/* 148:    */       {
/* 149:177 */         return false;
/* 150:    */       }
/* 151:    */     }
/* 152:180 */     return containsAll(that);
/* 153:    */   }
/* 154:    */   
/* 155:    */   public E first()
/* 156:    */   {
/* 157:185 */     if (isEmpty()) {
/* 158:186 */       throw new NoSuchElementException();
/* 159:    */     }
/* 160:188 */     return this.elements.get(0);
/* 161:    */   }
/* 162:    */   
/* 163:    */   public E last()
/* 164:    */   {
/* 165:193 */     if (isEmpty()) {
/* 166:194 */       throw new NoSuchElementException();
/* 167:    */     }
/* 168:196 */     return this.elements.get(size() - 1);
/* 169:    */   }
/* 170:    */   
/* 171:    */   public E lower(E element)
/* 172:    */   {
/* 173:201 */     int index = headIndex(element, false) - 1;
/* 174:202 */     return index == -1 ? null : this.elements.get(index);
/* 175:    */   }
/* 176:    */   
/* 177:    */   public E floor(E element)
/* 178:    */   {
/* 179:207 */     int index = headIndex(element, true) - 1;
/* 180:208 */     return index == -1 ? null : this.elements.get(index);
/* 181:    */   }
/* 182:    */   
/* 183:    */   public E ceiling(E element)
/* 184:    */   {
/* 185:213 */     int index = tailIndex(element, true);
/* 186:214 */     return index == size() ? null : this.elements.get(index);
/* 187:    */   }
/* 188:    */   
/* 189:    */   public E higher(E element)
/* 190:    */   {
/* 191:219 */     int index = tailIndex(element, false);
/* 192:220 */     return index == size() ? null : this.elements.get(index);
/* 193:    */   }
/* 194:    */   
/* 195:    */   ImmutableSortedSet<E> headSetImpl(E toElement, boolean inclusive)
/* 196:    */   {
/* 197:225 */     return getSubSet(0, headIndex(toElement, inclusive));
/* 198:    */   }
/* 199:    */   
/* 200:    */   int headIndex(E toElement, boolean inclusive)
/* 201:    */   {
/* 202:229 */     return SortedLists.binarySearch(this.elements, Preconditions.checkNotNull(toElement), comparator(), inclusive ? SortedLists.KeyPresentBehavior.FIRST_AFTER : SortedLists.KeyPresentBehavior.FIRST_PRESENT, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 203:    */   }
/* 204:    */   
/* 205:    */   ImmutableSortedSet<E> subSetImpl(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 206:    */   {
/* 207:240 */     return tailSetImpl(fromElement, fromInclusive).headSetImpl(toElement, toInclusive);
/* 208:    */   }
/* 209:    */   
/* 210:    */   ImmutableSortedSet<E> tailSetImpl(E fromElement, boolean inclusive)
/* 211:    */   {
/* 212:245 */     return getSubSet(tailIndex(fromElement, inclusive), size());
/* 213:    */   }
/* 214:    */   
/* 215:    */   int tailIndex(E fromElement, boolean inclusive)
/* 216:    */   {
/* 217:249 */     return SortedLists.binarySearch(this.elements, Preconditions.checkNotNull(fromElement), comparator(), inclusive ? SortedLists.KeyPresentBehavior.FIRST_PRESENT : SortedLists.KeyPresentBehavior.FIRST_AFTER, SortedLists.KeyAbsentBehavior.NEXT_HIGHER);
/* 218:    */   }
/* 219:    */   
/* 220:    */   Comparator<Object> unsafeComparator()
/* 221:    */   {
/* 222:262 */     return this.comparator;
/* 223:    */   }
/* 224:    */   
/* 225:    */   RegularImmutableSortedSet<E> getSubSet(int newFromIndex, int newToIndex)
/* 226:    */   {
/* 227:266 */     if ((newFromIndex == 0) && (newToIndex == size())) {
/* 228:267 */       return this;
/* 229:    */     }
/* 230:268 */     if (newFromIndex < newToIndex) {
/* 231:269 */       return new RegularImmutableSortedSet(this.elements.subList(newFromIndex, newToIndex), this.comparator);
/* 232:    */     }
/* 233:272 */     return emptySet(this.comparator);
/* 234:    */   }
/* 235:    */   
/* 236:    */   int indexOf(@Nullable Object target)
/* 237:    */   {
/* 238:278 */     if (target == null) {
/* 239:279 */       return -1;
/* 240:    */     }
/* 241:    */     int position;
/* 242:    */     try
/* 243:    */     {
/* 244:283 */       position = SortedLists.binarySearch(this.elements, target, unsafeComparator(), SortedLists.KeyPresentBehavior.ANY_PRESENT, SortedLists.KeyAbsentBehavior.INVERTED_INSERTION_INDEX);
/* 245:    */     }
/* 246:    */     catch (ClassCastException e)
/* 247:    */     {
/* 248:286 */       return -1;
/* 249:    */     }
/* 250:288 */     return position >= 0 ? position : -1;
/* 251:    */   }
/* 252:    */   
/* 253:    */   ImmutableList<E> createAsList()
/* 254:    */   {
/* 255:293 */     return size() <= 1 ? this.elements : new ImmutableSortedAsList(this, this.elements);
/* 256:    */   }
/* 257:    */   
/* 258:    */   ImmutableSortedSet<E> createDescendingSet()
/* 259:    */   {
/* 260:298 */     Ordering<E> reversedOrder = Ordering.from(this.comparator).reverse();
/* 261:299 */     return isEmpty() ? emptySet(reversedOrder) : new RegularImmutableSortedSet(this.elements.reverse(), reversedOrder);
/* 262:    */   }
/* 263:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableSortedSet
 * JD-Core Version:    0.7.0.1
 */