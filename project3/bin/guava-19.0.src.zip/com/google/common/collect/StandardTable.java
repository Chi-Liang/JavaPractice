/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Predicate;
/*   7:    */ import com.google.common.base.Predicates;
/*   8:    */ import com.google.common.base.Supplier;
/*   9:    */ import java.io.Serializable;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.LinkedHashMap;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Map.Entry;
/*  15:    */ import java.util.Set;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @GwtCompatible
/*  19:    */ class StandardTable<R, C, V>
/*  20:    */   extends AbstractTable<R, C, V>
/*  21:    */   implements Serializable
/*  22:    */ {
/*  23:    */   @GwtTransient
/*  24:    */   final Map<R, Map<C, V>> backingMap;
/*  25:    */   @GwtTransient
/*  26:    */   final Supplier<? extends Map<C, V>> factory;
/*  27:    */   private transient Set<C> columnKeySet;
/*  28:    */   private transient Map<R, Map<C, V>> rowMap;
/*  29:    */   private transient StandardTable<R, C, V>.ColumnMap columnMap;
/*  30:    */   private static final long serialVersionUID = 0L;
/*  31:    */   
/*  32:    */   StandardTable(Map<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory)
/*  33:    */   {
/*  34: 74 */     this.backingMap = backingMap;
/*  35: 75 */     this.factory = factory;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/*  39:    */   {
/*  40: 82 */     return (rowKey != null) && (columnKey != null) && (super.contains(rowKey, columnKey));
/*  41:    */   }
/*  42:    */   
/*  43:    */   public boolean containsColumn(@Nullable Object columnKey)
/*  44:    */   {
/*  45: 87 */     if (columnKey == null) {
/*  46: 88 */       return false;
/*  47:    */     }
/*  48: 90 */     for (Map<C, V> map : this.backingMap.values()) {
/*  49: 91 */       if (Maps.safeContainsKey(map, columnKey)) {
/*  50: 92 */         return true;
/*  51:    */       }
/*  52:    */     }
/*  53: 95 */     return false;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public boolean containsRow(@Nullable Object rowKey)
/*  57:    */   {
/*  58:100 */     return (rowKey != null) && (Maps.safeContainsKey(this.backingMap, rowKey));
/*  59:    */   }
/*  60:    */   
/*  61:    */   public boolean containsValue(@Nullable Object value)
/*  62:    */   {
/*  63:105 */     return (value != null) && (super.containsValue(value));
/*  64:    */   }
/*  65:    */   
/*  66:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/*  67:    */   {
/*  68:110 */     return (rowKey == null) || (columnKey == null) ? null : super.get(rowKey, columnKey);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public boolean isEmpty()
/*  72:    */   {
/*  73:115 */     return this.backingMap.isEmpty();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public int size()
/*  77:    */   {
/*  78:120 */     int size = 0;
/*  79:121 */     for (Map<C, V> map : this.backingMap.values()) {
/*  80:122 */       size += map.size();
/*  81:    */     }
/*  82:124 */     return size;
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void clear()
/*  86:    */   {
/*  87:131 */     this.backingMap.clear();
/*  88:    */   }
/*  89:    */   
/*  90:    */   private Map<C, V> getOrCreate(R rowKey)
/*  91:    */   {
/*  92:135 */     Map<C, V> map = (Map)this.backingMap.get(rowKey);
/*  93:136 */     if (map == null)
/*  94:    */     {
/*  95:137 */       map = (Map)this.factory.get();
/*  96:138 */       this.backingMap.put(rowKey, map);
/*  97:    */     }
/*  98:140 */     return map;
/*  99:    */   }
/* 100:    */   
/* 101:    */   public V put(R rowKey, C columnKey, V value)
/* 102:    */   {
/* 103:145 */     Preconditions.checkNotNull(rowKey);
/* 104:146 */     Preconditions.checkNotNull(columnKey);
/* 105:147 */     Preconditions.checkNotNull(value);
/* 106:148 */     return getOrCreate(rowKey).put(columnKey, value);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public V remove(@Nullable Object rowKey, @Nullable Object columnKey)
/* 110:    */   {
/* 111:153 */     if ((rowKey == null) || (columnKey == null)) {
/* 112:154 */       return null;
/* 113:    */     }
/* 114:156 */     Map<C, V> map = (Map)Maps.safeGet(this.backingMap, rowKey);
/* 115:157 */     if (map == null) {
/* 116:158 */       return null;
/* 117:    */     }
/* 118:160 */     V value = map.remove(columnKey);
/* 119:161 */     if (map.isEmpty()) {
/* 120:162 */       this.backingMap.remove(rowKey);
/* 121:    */     }
/* 122:164 */     return value;
/* 123:    */   }
/* 124:    */   
/* 125:    */   private Map<R, V> removeColumn(Object column)
/* 126:    */   {
/* 127:168 */     Map<R, V> output = new LinkedHashMap();
/* 128:169 */     Iterator<Map.Entry<R, Map<C, V>>> iterator = this.backingMap.entrySet().iterator();
/* 129:170 */     while (iterator.hasNext())
/* 130:    */     {
/* 131:171 */       Map.Entry<R, Map<C, V>> entry = (Map.Entry)iterator.next();
/* 132:172 */       V value = ((Map)entry.getValue()).remove(column);
/* 133:173 */       if (value != null)
/* 134:    */       {
/* 135:174 */         output.put(entry.getKey(), value);
/* 136:175 */         if (((Map)entry.getValue()).isEmpty()) {
/* 137:176 */           iterator.remove();
/* 138:    */         }
/* 139:    */       }
/* 140:    */     }
/* 141:180 */     return output;
/* 142:    */   }
/* 143:    */   
/* 144:    */   private boolean containsMapping(Object rowKey, Object columnKey, Object value)
/* 145:    */   {
/* 146:184 */     return (value != null) && (value.equals(get(rowKey, columnKey)));
/* 147:    */   }
/* 148:    */   
/* 149:    */   private boolean removeMapping(Object rowKey, Object columnKey, Object value)
/* 150:    */   {
/* 151:189 */     if (containsMapping(rowKey, columnKey, value))
/* 152:    */     {
/* 153:190 */       remove(rowKey, columnKey);
/* 154:191 */       return true;
/* 155:    */     }
/* 156:193 */     return false;
/* 157:    */   }
/* 158:    */   
/* 159:    */   private abstract class TableSet<T>
/* 160:    */     extends Sets.ImprovedAbstractSet<T>
/* 161:    */   {
/* 162:    */     private TableSet() {}
/* 163:    */     
/* 164:    */     public boolean isEmpty()
/* 165:    */     {
/* 166:206 */       return StandardTable.this.backingMap.isEmpty();
/* 167:    */     }
/* 168:    */     
/* 169:    */     public void clear()
/* 170:    */     {
/* 171:211 */       StandardTable.this.backingMap.clear();
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   public Set<Table.Cell<R, C, V>> cellSet()
/* 176:    */   {
/* 177:227 */     return super.cellSet();
/* 178:    */   }
/* 179:    */   
/* 180:    */   Iterator<Table.Cell<R, C, V>> cellIterator()
/* 181:    */   {
/* 182:232 */     return new CellIterator(null);
/* 183:    */   }
/* 184:    */   
/* 185:    */   private class CellIterator
/* 186:    */     implements Iterator<Table.Cell<R, C, V>>
/* 187:    */   {
/* 188:236 */     final Iterator<Map.Entry<R, Map<C, V>>> rowIterator = StandardTable.this.backingMap.entrySet().iterator();
/* 189:    */     Map.Entry<R, Map<C, V>> rowEntry;
/* 190:238 */     Iterator<Map.Entry<C, V>> columnIterator = Iterators.emptyModifiableIterator();
/* 191:    */     
/* 192:    */     private CellIterator() {}
/* 193:    */     
/* 194:    */     public boolean hasNext()
/* 195:    */     {
/* 196:242 */       return (this.rowIterator.hasNext()) || (this.columnIterator.hasNext());
/* 197:    */     }
/* 198:    */     
/* 199:    */     public Table.Cell<R, C, V> next()
/* 200:    */     {
/* 201:247 */       if (!this.columnIterator.hasNext())
/* 202:    */       {
/* 203:248 */         this.rowEntry = ((Map.Entry)this.rowIterator.next());
/* 204:249 */         this.columnIterator = ((Map)this.rowEntry.getValue()).entrySet().iterator();
/* 205:    */       }
/* 206:251 */       Map.Entry<C, V> columnEntry = (Map.Entry)this.columnIterator.next();
/* 207:252 */       return Tables.immutableCell(this.rowEntry.getKey(), columnEntry.getKey(), columnEntry.getValue());
/* 208:    */     }
/* 209:    */     
/* 210:    */     public void remove()
/* 211:    */     {
/* 212:257 */       this.columnIterator.remove();
/* 213:258 */       if (((Map)this.rowEntry.getValue()).isEmpty()) {
/* 214:259 */         this.rowIterator.remove();
/* 215:    */       }
/* 216:    */     }
/* 217:    */   }
/* 218:    */   
/* 219:    */   public Map<C, V> row(R rowKey)
/* 220:    */   {
/* 221:266 */     return new Row(rowKey);
/* 222:    */   }
/* 223:    */   
/* 224:    */   class Row
/* 225:    */     extends Maps.IteratorBasedAbstractMap<C, V>
/* 226:    */   {
/* 227:    */     final R rowKey;
/* 228:    */     Map<C, V> backingRowMap;
/* 229:    */     
/* 230:    */     Row()
/* 231:    */     {
/* 232:273 */       this.rowKey = Preconditions.checkNotNull(rowKey);
/* 233:    */     }
/* 234:    */     
/* 235:    */     Map<C, V> backingRowMap()
/* 236:    */     {
/* 237:279 */       return (this.backingRowMap == null) || ((this.backingRowMap.isEmpty()) && (StandardTable.this.backingMap.containsKey(this.rowKey))) ? (this.backingRowMap = computeBackingRowMap()) : this.backingRowMap;
/* 238:    */     }
/* 239:    */     
/* 240:    */     Map<C, V> computeBackingRowMap()
/* 241:    */     {
/* 242:285 */       return (Map)StandardTable.this.backingMap.get(this.rowKey);
/* 243:    */     }
/* 244:    */     
/* 245:    */     void maintainEmptyInvariant()
/* 246:    */     {
/* 247:290 */       if ((backingRowMap() != null) && (this.backingRowMap.isEmpty()))
/* 248:    */       {
/* 249:291 */         StandardTable.this.backingMap.remove(this.rowKey);
/* 250:292 */         this.backingRowMap = null;
/* 251:    */       }
/* 252:    */     }
/* 253:    */     
/* 254:    */     public boolean containsKey(Object key)
/* 255:    */     {
/* 256:298 */       Map<C, V> backingRowMap = backingRowMap();
/* 257:299 */       return (key != null) && (backingRowMap != null) && (Maps.safeContainsKey(backingRowMap, key));
/* 258:    */     }
/* 259:    */     
/* 260:    */     public V get(Object key)
/* 261:    */     {
/* 262:304 */       Map<C, V> backingRowMap = backingRowMap();
/* 263:305 */       return (key != null) && (backingRowMap != null) ? Maps.safeGet(backingRowMap, key) : null;
/* 264:    */     }
/* 265:    */     
/* 266:    */     public V put(C key, V value)
/* 267:    */     {
/* 268:310 */       Preconditions.checkNotNull(key);
/* 269:311 */       Preconditions.checkNotNull(value);
/* 270:312 */       if ((this.backingRowMap != null) && (!this.backingRowMap.isEmpty())) {
/* 271:313 */         return this.backingRowMap.put(key, value);
/* 272:    */       }
/* 273:315 */       return StandardTable.this.put(this.rowKey, key, value);
/* 274:    */     }
/* 275:    */     
/* 276:    */     public V remove(Object key)
/* 277:    */     {
/* 278:320 */       Map<C, V> backingRowMap = backingRowMap();
/* 279:321 */       if (backingRowMap == null) {
/* 280:322 */         return null;
/* 281:    */       }
/* 282:324 */       V result = Maps.safeRemove(backingRowMap, key);
/* 283:325 */       maintainEmptyInvariant();
/* 284:326 */       return result;
/* 285:    */     }
/* 286:    */     
/* 287:    */     public void clear()
/* 288:    */     {
/* 289:331 */       Map<C, V> backingRowMap = backingRowMap();
/* 290:332 */       if (backingRowMap != null) {
/* 291:333 */         backingRowMap.clear();
/* 292:    */       }
/* 293:335 */       maintainEmptyInvariant();
/* 294:    */     }
/* 295:    */     
/* 296:    */     public int size()
/* 297:    */     {
/* 298:340 */       Map<C, V> map = backingRowMap();
/* 299:341 */       return map == null ? 0 : map.size();
/* 300:    */     }
/* 301:    */     
/* 302:    */     Iterator<Map.Entry<C, V>> entryIterator()
/* 303:    */     {
/* 304:346 */       Map<C, V> map = backingRowMap();
/* 305:347 */       if (map == null) {
/* 306:348 */         return Iterators.emptyModifiableIterator();
/* 307:    */       }
/* 308:350 */       final Iterator<Map.Entry<C, V>> iterator = map.entrySet().iterator();
/* 309:351 */       new Iterator()
/* 310:    */       {
/* 311:    */         public boolean hasNext()
/* 312:    */         {
/* 313:354 */           return iterator.hasNext();
/* 314:    */         }
/* 315:    */         
/* 316:    */         public Map.Entry<C, V> next()
/* 317:    */         {
/* 318:359 */           final Map.Entry<C, V> entry = (Map.Entry)iterator.next();
/* 319:360 */           new ForwardingMapEntry()
/* 320:    */           {
/* 321:    */             protected Map.Entry<C, V> delegate()
/* 322:    */             {
/* 323:363 */               return entry;
/* 324:    */             }
/* 325:    */             
/* 326:    */             public V setValue(V value)
/* 327:    */             {
/* 328:368 */               return super.setValue(Preconditions.checkNotNull(value));
/* 329:    */             }
/* 330:    */             
/* 331:    */             public boolean equals(Object object)
/* 332:    */             {
/* 333:374 */               return standardEquals(object);
/* 334:    */             }
/* 335:    */           };
/* 336:    */         }
/* 337:    */         
/* 338:    */         public void remove()
/* 339:    */         {
/* 340:381 */           iterator.remove();
/* 341:382 */           StandardTable.Row.this.maintainEmptyInvariant();
/* 342:    */         }
/* 343:    */       };
/* 344:    */     }
/* 345:    */   }
/* 346:    */   
/* 347:    */   public Map<R, V> column(C columnKey)
/* 348:    */   {
/* 349:396 */     return new Column(columnKey);
/* 350:    */   }
/* 351:    */   
/* 352:    */   private class Column
/* 353:    */     extends Maps.ViewCachingAbstractMap<R, V>
/* 354:    */   {
/* 355:    */     final C columnKey;
/* 356:    */     
/* 357:    */     Column()
/* 358:    */     {
/* 359:403 */       this.columnKey = Preconditions.checkNotNull(columnKey);
/* 360:    */     }
/* 361:    */     
/* 362:    */     public V put(R key, V value)
/* 363:    */     {
/* 364:408 */       return StandardTable.this.put(key, this.columnKey, value);
/* 365:    */     }
/* 366:    */     
/* 367:    */     public V get(Object key)
/* 368:    */     {
/* 369:413 */       return StandardTable.this.get(key, this.columnKey);
/* 370:    */     }
/* 371:    */     
/* 372:    */     public boolean containsKey(Object key)
/* 373:    */     {
/* 374:418 */       return StandardTable.this.contains(key, this.columnKey);
/* 375:    */     }
/* 376:    */     
/* 377:    */     public V remove(Object key)
/* 378:    */     {
/* 379:423 */       return StandardTable.this.remove(key, this.columnKey);
/* 380:    */     }
/* 381:    */     
/* 382:    */     boolean removeFromColumnIf(Predicate<? super Map.Entry<R, V>> predicate)
/* 383:    */     {
/* 384:431 */       boolean changed = false;
/* 385:432 */       Iterator<Map.Entry<R, Map<C, V>>> iterator = StandardTable.this.backingMap.entrySet().iterator();
/* 386:433 */       while (iterator.hasNext())
/* 387:    */       {
/* 388:434 */         Map.Entry<R, Map<C, V>> entry = (Map.Entry)iterator.next();
/* 389:435 */         Map<C, V> map = (Map)entry.getValue();
/* 390:436 */         V value = map.get(this.columnKey);
/* 391:437 */         if ((value != null) && (predicate.apply(Maps.immutableEntry(entry.getKey(), value))))
/* 392:    */         {
/* 393:438 */           map.remove(this.columnKey);
/* 394:439 */           changed = true;
/* 395:440 */           if (map.isEmpty()) {
/* 396:441 */             iterator.remove();
/* 397:    */           }
/* 398:    */         }
/* 399:    */       }
/* 400:445 */       return changed;
/* 401:    */     }
/* 402:    */     
/* 403:    */     Set<Map.Entry<R, V>> createEntrySet()
/* 404:    */     {
/* 405:450 */       return new EntrySet(null);
/* 406:    */     }
/* 407:    */     
/* 408:    */     private class EntrySet
/* 409:    */       extends Sets.ImprovedAbstractSet<Map.Entry<R, V>>
/* 410:    */     {
/* 411:    */       private EntrySet() {}
/* 412:    */       
/* 413:    */       public Iterator<Map.Entry<R, V>> iterator()
/* 414:    */       {
/* 415:457 */         return new StandardTable.Column.EntrySetIterator(StandardTable.Column.this, null);
/* 416:    */       }
/* 417:    */       
/* 418:    */       public int size()
/* 419:    */       {
/* 420:462 */         int size = 0;
/* 421:463 */         for (Map<C, V> map : StandardTable.this.backingMap.values()) {
/* 422:464 */           if (map.containsKey(StandardTable.Column.this.columnKey)) {
/* 423:465 */             size++;
/* 424:    */           }
/* 425:    */         }
/* 426:468 */         return size;
/* 427:    */       }
/* 428:    */       
/* 429:    */       public boolean isEmpty()
/* 430:    */       {
/* 431:473 */         return !StandardTable.this.containsColumn(StandardTable.Column.this.columnKey);
/* 432:    */       }
/* 433:    */       
/* 434:    */       public void clear()
/* 435:    */       {
/* 436:478 */         StandardTable.Column.this.removeFromColumnIf(Predicates.alwaysTrue());
/* 437:    */       }
/* 438:    */       
/* 439:    */       public boolean contains(Object o)
/* 440:    */       {
/* 441:483 */         if ((o instanceof Map.Entry))
/* 442:    */         {
/* 443:484 */           Map.Entry<?, ?> entry = (Map.Entry)o;
/* 444:485 */           return StandardTable.this.containsMapping(entry.getKey(), StandardTable.Column.this.columnKey, entry.getValue());
/* 445:    */         }
/* 446:487 */         return false;
/* 447:    */       }
/* 448:    */       
/* 449:    */       public boolean remove(Object obj)
/* 450:    */       {
/* 451:492 */         if ((obj instanceof Map.Entry))
/* 452:    */         {
/* 453:493 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 454:494 */           return StandardTable.this.removeMapping(entry.getKey(), StandardTable.Column.this.columnKey, entry.getValue());
/* 455:    */         }
/* 456:496 */         return false;
/* 457:    */       }
/* 458:    */       
/* 459:    */       public boolean retainAll(Collection<?> c)
/* 460:    */       {
/* 461:501 */         return StandardTable.Column.this.removeFromColumnIf(Predicates.not(Predicates.in(c)));
/* 462:    */       }
/* 463:    */     }
/* 464:    */     
/* 465:    */     private class EntrySetIterator
/* 466:    */       extends AbstractIterator<Map.Entry<R, V>>
/* 467:    */     {
/* 468:506 */       final Iterator<Map.Entry<R, Map<C, V>>> iterator = StandardTable.this.backingMap.entrySet().iterator();
/* 469:    */       
/* 470:    */       private EntrySetIterator() {}
/* 471:    */       
/* 472:    */       protected Map.Entry<R, V> computeNext()
/* 473:    */       {
/* 474:510 */         while (this.iterator.hasNext())
/* 475:    */         {
/* 476:511 */           final Map.Entry<R, Map<C, V>> entry = (Map.Entry)this.iterator.next();
/* 477:512 */           if (((Map)entry.getValue()).containsKey(StandardTable.Column.this.columnKey)) {
/* 478:530 */             new AbstractMapEntry()
/* 479:    */             {
/* 480:    */               public R getKey()
/* 481:    */               {
/* 482:517 */                 return entry.getKey();
/* 483:    */               }
/* 484:    */               
/* 485:    */               public V getValue()
/* 486:    */               {
/* 487:522 */                 return ((Map)entry.getValue()).get(this.this$2.this$1.columnKey);
/* 488:    */               }
/* 489:    */               
/* 490:    */               public V setValue(V value)
/* 491:    */               {
/* 492:527 */                 return ((Map)entry.getValue()).put(this.this$2.this$1.columnKey, Preconditions.checkNotNull(value));
/* 493:    */               }
/* 494:    */             };
/* 495:    */           }
/* 496:    */         }
/* 497:533 */         return (Map.Entry)endOfData();
/* 498:    */       }
/* 499:    */     }
/* 500:    */     
/* 501:    */     Set<R> createKeySet()
/* 502:    */     {
/* 503:539 */       return new KeySet();
/* 504:    */     }
/* 505:    */     
/* 506:    */     private class KeySet
/* 507:    */       extends Maps.KeySet<R, V>
/* 508:    */     {
/* 509:    */       KeySet()
/* 510:    */       {
/* 511:545 */         super();
/* 512:    */       }
/* 513:    */       
/* 514:    */       public boolean contains(Object obj)
/* 515:    */       {
/* 516:550 */         return StandardTable.this.contains(obj, StandardTable.Column.this.columnKey);
/* 517:    */       }
/* 518:    */       
/* 519:    */       public boolean remove(Object obj)
/* 520:    */       {
/* 521:555 */         return StandardTable.this.remove(obj, StandardTable.Column.this.columnKey) != null;
/* 522:    */       }
/* 523:    */       
/* 524:    */       public boolean retainAll(Collection<?> c)
/* 525:    */       {
/* 526:560 */         return StandardTable.Column.this.removeFromColumnIf(Maps.keyPredicateOnEntries(Predicates.not(Predicates.in(c))));
/* 527:    */       }
/* 528:    */     }
/* 529:    */     
/* 530:    */     Collection<V> createValues()
/* 531:    */     {
/* 532:566 */       return new Values();
/* 533:    */     }
/* 534:    */     
/* 535:    */     private class Values
/* 536:    */       extends Maps.Values<R, V>
/* 537:    */     {
/* 538:    */       Values()
/* 539:    */       {
/* 540:572 */         super();
/* 541:    */       }
/* 542:    */       
/* 543:    */       public boolean remove(Object obj)
/* 544:    */       {
/* 545:577 */         return (obj != null) && (StandardTable.Column.this.removeFromColumnIf(Maps.valuePredicateOnEntries(Predicates.equalTo(obj))));
/* 546:    */       }
/* 547:    */       
/* 548:    */       public boolean removeAll(Collection<?> c)
/* 549:    */       {
/* 550:582 */         return StandardTable.Column.this.removeFromColumnIf(Maps.valuePredicateOnEntries(Predicates.in(c)));
/* 551:    */       }
/* 552:    */       
/* 553:    */       public boolean retainAll(Collection<?> c)
/* 554:    */       {
/* 555:587 */         return StandardTable.Column.this.removeFromColumnIf(Maps.valuePredicateOnEntries(Predicates.not(Predicates.in(c))));
/* 556:    */       }
/* 557:    */     }
/* 558:    */   }
/* 559:    */   
/* 560:    */   public Set<R> rowKeySet()
/* 561:    */   {
/* 562:594 */     return rowMap().keySet();
/* 563:    */   }
/* 564:    */   
/* 565:    */   public Set<C> columnKeySet()
/* 566:    */   {
/* 567:610 */     Set<C> result = this.columnKeySet;
/* 568:611 */     return result == null ? (this.columnKeySet = new ColumnKeySet(null)) : result;
/* 569:    */   }
/* 570:    */   
/* 571:    */   private class ColumnKeySet
/* 572:    */     extends StandardTable<R, C, V>.TableSet<C>
/* 573:    */   {
/* 574:    */     private ColumnKeySet()
/* 575:    */     {
/* 576:615 */       super(null);
/* 577:    */     }
/* 578:    */     
/* 579:    */     public Iterator<C> iterator()
/* 580:    */     {
/* 581:618 */       return StandardTable.this.createColumnKeyIterator();
/* 582:    */     }
/* 583:    */     
/* 584:    */     public int size()
/* 585:    */     {
/* 586:623 */       return Iterators.size(iterator());
/* 587:    */     }
/* 588:    */     
/* 589:    */     public boolean remove(Object obj)
/* 590:    */     {
/* 591:628 */       if (obj == null) {
/* 592:629 */         return false;
/* 593:    */       }
/* 594:631 */       boolean changed = false;
/* 595:632 */       Iterator<Map<C, V>> iterator = StandardTable.this.backingMap.values().iterator();
/* 596:633 */       while (iterator.hasNext())
/* 597:    */       {
/* 598:634 */         Map<C, V> map = (Map)iterator.next();
/* 599:635 */         if (map.keySet().remove(obj))
/* 600:    */         {
/* 601:636 */           changed = true;
/* 602:637 */           if (map.isEmpty()) {
/* 603:638 */             iterator.remove();
/* 604:    */           }
/* 605:    */         }
/* 606:    */       }
/* 607:642 */       return changed;
/* 608:    */     }
/* 609:    */     
/* 610:    */     public boolean removeAll(Collection<?> c)
/* 611:    */     {
/* 612:647 */       Preconditions.checkNotNull(c);
/* 613:648 */       boolean changed = false;
/* 614:649 */       Iterator<Map<C, V>> iterator = StandardTable.this.backingMap.values().iterator();
/* 615:650 */       while (iterator.hasNext())
/* 616:    */       {
/* 617:651 */         Map<C, V> map = (Map)iterator.next();
/* 618:654 */         if (Iterators.removeAll(map.keySet().iterator(), c))
/* 619:    */         {
/* 620:655 */           changed = true;
/* 621:656 */           if (map.isEmpty()) {
/* 622:657 */             iterator.remove();
/* 623:    */           }
/* 624:    */         }
/* 625:    */       }
/* 626:661 */       return changed;
/* 627:    */     }
/* 628:    */     
/* 629:    */     public boolean retainAll(Collection<?> c)
/* 630:    */     {
/* 631:666 */       Preconditions.checkNotNull(c);
/* 632:667 */       boolean changed = false;
/* 633:668 */       Iterator<Map<C, V>> iterator = StandardTable.this.backingMap.values().iterator();
/* 634:669 */       while (iterator.hasNext())
/* 635:    */       {
/* 636:670 */         Map<C, V> map = (Map)iterator.next();
/* 637:671 */         if (map.keySet().retainAll(c))
/* 638:    */         {
/* 639:672 */           changed = true;
/* 640:673 */           if (map.isEmpty()) {
/* 641:674 */             iterator.remove();
/* 642:    */           }
/* 643:    */         }
/* 644:    */       }
/* 645:678 */       return changed;
/* 646:    */     }
/* 647:    */     
/* 648:    */     public boolean contains(Object obj)
/* 649:    */     {
/* 650:683 */       return StandardTable.this.containsColumn(obj);
/* 651:    */     }
/* 652:    */   }
/* 653:    */   
/* 654:    */   Iterator<C> createColumnKeyIterator()
/* 655:    */   {
/* 656:692 */     return new ColumnKeyIterator(null);
/* 657:    */   }
/* 658:    */   
/* 659:    */   private class ColumnKeyIterator
/* 660:    */     extends AbstractIterator<C>
/* 661:    */   {
/* 662:698 */     final Map<C, V> seen = (Map)StandardTable.this.factory.get();
/* 663:699 */     final Iterator<Map<C, V>> mapIterator = StandardTable.this.backingMap.values().iterator();
/* 664:700 */     Iterator<Map.Entry<C, V>> entryIterator = Iterators.emptyIterator();
/* 665:    */     
/* 666:    */     private ColumnKeyIterator() {}
/* 667:    */     
/* 668:    */     protected C computeNext()
/* 669:    */     {
/* 670:    */       for (;;)
/* 671:    */       {
/* 672:705 */         if (this.entryIterator.hasNext())
/* 673:    */         {
/* 674:706 */           Map.Entry<C, V> entry = (Map.Entry)this.entryIterator.next();
/* 675:707 */           if (!this.seen.containsKey(entry.getKey()))
/* 676:    */           {
/* 677:708 */             this.seen.put(entry.getKey(), entry.getValue());
/* 678:709 */             return entry.getKey();
/* 679:    */           }
/* 680:    */         }
/* 681:    */         else
/* 682:    */         {
/* 683:711 */           if (!this.mapIterator.hasNext()) {
/* 684:    */             break;
/* 685:    */           }
/* 686:712 */           this.entryIterator = ((Map)this.mapIterator.next()).entrySet().iterator();
/* 687:    */         }
/* 688:    */       }
/* 689:714 */       return endOfData();
/* 690:    */     }
/* 691:    */   }
/* 692:    */   
/* 693:    */   public Collection<V> values()
/* 694:    */   {
/* 695:728 */     return super.values();
/* 696:    */   }
/* 697:    */   
/* 698:    */   public Map<R, Map<C, V>> rowMap()
/* 699:    */   {
/* 700:735 */     Map<R, Map<C, V>> result = this.rowMap;
/* 701:736 */     return result == null ? (this.rowMap = createRowMap()) : result;
/* 702:    */   }
/* 703:    */   
/* 704:    */   Map<R, Map<C, V>> createRowMap()
/* 705:    */   {
/* 706:740 */     return new RowMap();
/* 707:    */   }
/* 708:    */   
/* 709:    */   class RowMap
/* 710:    */     extends Maps.ViewCachingAbstractMap<R, Map<C, V>>
/* 711:    */   {
/* 712:    */     RowMap() {}
/* 713:    */     
/* 714:    */     public boolean containsKey(Object key)
/* 715:    */     {
/* 716:747 */       return StandardTable.this.containsRow(key);
/* 717:    */     }
/* 718:    */     
/* 719:    */     public Map<C, V> get(Object key)
/* 720:    */     {
/* 721:754 */       return StandardTable.this.containsRow(key) ? StandardTable.this.row(key) : null;
/* 722:    */     }
/* 723:    */     
/* 724:    */     public Map<C, V> remove(Object key)
/* 725:    */     {
/* 726:759 */       return key == null ? null : (Map)StandardTable.this.backingMap.remove(key);
/* 727:    */     }
/* 728:    */     
/* 729:    */     protected Set<Map.Entry<R, Map<C, V>>> createEntrySet()
/* 730:    */     {
/* 731:764 */       return new EntrySet();
/* 732:    */     }
/* 733:    */     
/* 734:    */     class EntrySet
/* 735:    */       extends StandardTable<R, C, V>.TableSet<Map.Entry<R, Map<C, V>>>
/* 736:    */     {
/* 737:    */       EntrySet()
/* 738:    */       {
/* 739:768 */         super(null);
/* 740:    */       }
/* 741:    */       
/* 742:    */       public Iterator<Map.Entry<R, Map<C, V>>> iterator()
/* 743:    */       {
/* 744:771 */         Maps.asMapEntryIterator(StandardTable.this.backingMap.keySet(), new Function()
/* 745:    */         {
/* 746:    */           public Map<C, V> apply(R rowKey)
/* 747:    */           {
/* 748:776 */             return StandardTable.this.row(rowKey);
/* 749:    */           }
/* 750:    */         });
/* 751:    */       }
/* 752:    */       
/* 753:    */       public int size()
/* 754:    */       {
/* 755:783 */         return StandardTable.this.backingMap.size();
/* 756:    */       }
/* 757:    */       
/* 758:    */       public boolean contains(Object obj)
/* 759:    */       {
/* 760:788 */         if ((obj instanceof Map.Entry))
/* 761:    */         {
/* 762:789 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 763:790 */           return (entry.getKey() != null) && ((entry.getValue() instanceof Map)) && (Collections2.safeContains(StandardTable.this.backingMap.entrySet(), entry));
/* 764:    */         }
/* 765:794 */         return false;
/* 766:    */       }
/* 767:    */       
/* 768:    */       public boolean remove(Object obj)
/* 769:    */       {
/* 770:799 */         if ((obj instanceof Map.Entry))
/* 771:    */         {
/* 772:800 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 773:801 */           return (entry.getKey() != null) && ((entry.getValue() instanceof Map)) && (StandardTable.this.backingMap.entrySet().remove(entry));
/* 774:    */         }
/* 775:805 */         return false;
/* 776:    */       }
/* 777:    */     }
/* 778:    */   }
/* 779:    */   
/* 780:    */   public Map<C, Map<R, V>> columnMap()
/* 781:    */   {
/* 782:814 */     StandardTable<R, C, V>.ColumnMap result = this.columnMap;
/* 783:815 */     return result == null ? (this.columnMap = new ColumnMap(null)) : result;
/* 784:    */   }
/* 785:    */   
/* 786:    */   private class ColumnMap
/* 787:    */     extends Maps.ViewCachingAbstractMap<C, Map<R, V>>
/* 788:    */   {
/* 789:    */     private ColumnMap() {}
/* 790:    */     
/* 791:    */     public Map<R, V> get(Object key)
/* 792:    */     {
/* 793:825 */       return StandardTable.this.containsColumn(key) ? StandardTable.this.column(key) : null;
/* 794:    */     }
/* 795:    */     
/* 796:    */     public boolean containsKey(Object key)
/* 797:    */     {
/* 798:830 */       return StandardTable.this.containsColumn(key);
/* 799:    */     }
/* 800:    */     
/* 801:    */     public Map<R, V> remove(Object key)
/* 802:    */     {
/* 803:835 */       return StandardTable.this.containsColumn(key) ? StandardTable.this.removeColumn(key) : null;
/* 804:    */     }
/* 805:    */     
/* 806:    */     public Set<Map.Entry<C, Map<R, V>>> createEntrySet()
/* 807:    */     {
/* 808:840 */       return new ColumnMapEntrySet();
/* 809:    */     }
/* 810:    */     
/* 811:    */     public Set<C> keySet()
/* 812:    */     {
/* 813:845 */       return StandardTable.this.columnKeySet();
/* 814:    */     }
/* 815:    */     
/* 816:    */     Collection<Map<R, V>> createValues()
/* 817:    */     {
/* 818:850 */       return new ColumnMapValues();
/* 819:    */     }
/* 820:    */     
/* 821:    */     class ColumnMapEntrySet
/* 822:    */       extends StandardTable<R, C, V>.TableSet<Map.Entry<C, Map<R, V>>>
/* 823:    */     {
/* 824:    */       ColumnMapEntrySet()
/* 825:    */       {
/* 826:854 */         super(null);
/* 827:    */       }
/* 828:    */       
/* 829:    */       public Iterator<Map.Entry<C, Map<R, V>>> iterator()
/* 830:    */       {
/* 831:857 */         Maps.asMapEntryIterator(StandardTable.this.columnKeySet(), new Function()
/* 832:    */         {
/* 833:    */           public Map<R, V> apply(C columnKey)
/* 834:    */           {
/* 835:862 */             return StandardTable.this.column(columnKey);
/* 836:    */           }
/* 837:    */         });
/* 838:    */       }
/* 839:    */       
/* 840:    */       public int size()
/* 841:    */       {
/* 842:869 */         return StandardTable.this.columnKeySet().size();
/* 843:    */       }
/* 844:    */       
/* 845:    */       public boolean contains(Object obj)
/* 846:    */       {
/* 847:874 */         if ((obj instanceof Map.Entry))
/* 848:    */         {
/* 849:875 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 850:876 */           if (StandardTable.this.containsColumn(entry.getKey()))
/* 851:    */           {
/* 852:880 */             C columnKey = entry.getKey();
/* 853:881 */             return StandardTable.ColumnMap.this.get(columnKey).equals(entry.getValue());
/* 854:    */           }
/* 855:    */         }
/* 856:884 */         return false;
/* 857:    */       }
/* 858:    */       
/* 859:    */       public boolean remove(Object obj)
/* 860:    */       {
/* 861:889 */         if (contains(obj))
/* 862:    */         {
/* 863:890 */           Map.Entry<?, ?> entry = (Map.Entry)obj;
/* 864:891 */           StandardTable.this.removeColumn(entry.getKey());
/* 865:892 */           return true;
/* 866:    */         }
/* 867:894 */         return false;
/* 868:    */       }
/* 869:    */       
/* 870:    */       public boolean removeAll(Collection<?> c)
/* 871:    */       {
/* 872:905 */         Preconditions.checkNotNull(c);
/* 873:906 */         return Sets.removeAllImpl(this, c.iterator());
/* 874:    */       }
/* 875:    */       
/* 876:    */       public boolean retainAll(Collection<?> c)
/* 877:    */       {
/* 878:911 */         Preconditions.checkNotNull(c);
/* 879:912 */         boolean changed = false;
/* 880:913 */         for (C columnKey : Lists.newArrayList(StandardTable.this.columnKeySet().iterator())) {
/* 881:914 */           if (!c.contains(Maps.immutableEntry(columnKey, StandardTable.this.column(columnKey))))
/* 882:    */           {
/* 883:915 */             StandardTable.this.removeColumn(columnKey);
/* 884:916 */             changed = true;
/* 885:    */           }
/* 886:    */         }
/* 887:919 */         return changed;
/* 888:    */       }
/* 889:    */     }
/* 890:    */     
/* 891:    */     private class ColumnMapValues
/* 892:    */       extends Maps.Values<C, Map<R, V>>
/* 893:    */     {
/* 894:    */       ColumnMapValues()
/* 895:    */       {
/* 896:926 */         super();
/* 897:    */       }
/* 898:    */       
/* 899:    */       public boolean remove(Object obj)
/* 900:    */       {
/* 901:931 */         for (Map.Entry<C, Map<R, V>> entry : StandardTable.ColumnMap.this.entrySet()) {
/* 902:932 */           if (((Map)entry.getValue()).equals(obj))
/* 903:    */           {
/* 904:933 */             StandardTable.this.removeColumn(entry.getKey());
/* 905:934 */             return true;
/* 906:    */           }
/* 907:    */         }
/* 908:937 */         return false;
/* 909:    */       }
/* 910:    */       
/* 911:    */       public boolean removeAll(Collection<?> c)
/* 912:    */       {
/* 913:942 */         Preconditions.checkNotNull(c);
/* 914:943 */         boolean changed = false;
/* 915:944 */         for (C columnKey : Lists.newArrayList(StandardTable.this.columnKeySet().iterator())) {
/* 916:945 */           if (c.contains(StandardTable.this.column(columnKey)))
/* 917:    */           {
/* 918:946 */             StandardTable.this.removeColumn(columnKey);
/* 919:947 */             changed = true;
/* 920:    */           }
/* 921:    */         }
/* 922:950 */         return changed;
/* 923:    */       }
/* 924:    */       
/* 925:    */       public boolean retainAll(Collection<?> c)
/* 926:    */       {
/* 927:955 */         Preconditions.checkNotNull(c);
/* 928:956 */         boolean changed = false;
/* 929:957 */         for (C columnKey : Lists.newArrayList(StandardTable.this.columnKeySet().iterator())) {
/* 930:958 */           if (!c.contains(StandardTable.this.column(columnKey)))
/* 931:    */           {
/* 932:959 */             StandardTable.this.removeColumn(columnKey);
/* 933:960 */             changed = true;
/* 934:    */           }
/* 935:    */         }
/* 936:963 */         return changed;
/* 937:    */       }
/* 938:    */     }
/* 939:    */   }
/* 940:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.StandardTable
 * JD-Core Version:    0.7.0.1
 */