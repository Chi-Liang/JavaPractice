/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import java.util.Comparator;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible(emulated=true)
/*  9:   */ final class ImmutableSortedAsList<E>
/* 10:   */   extends RegularImmutableAsList<E>
/* 11:   */   implements SortedIterable<E>
/* 12:   */ {
/* 13:   */   ImmutableSortedAsList(ImmutableSortedSet<E> backingSet, ImmutableList<E> backingList)
/* 14:   */   {
/* 15:35 */     super(backingSet, backingList);
/* 16:   */   }
/* 17:   */   
/* 18:   */   ImmutableSortedSet<E> delegateCollection()
/* 19:   */   {
/* 20:40 */     return (ImmutableSortedSet)super.delegateCollection();
/* 21:   */   }
/* 22:   */   
/* 23:   */   public Comparator<? super E> comparator()
/* 24:   */   {
/* 25:45 */     return delegateCollection().comparator();
/* 26:   */   }
/* 27:   */   
/* 28:   */   @GwtIncompatible("ImmutableSortedSet.indexOf")
/* 29:   */   public int indexOf(@Nullable Object target)
/* 30:   */   {
/* 31:54 */     int index = delegateCollection().indexOf(target);
/* 32:   */     
/* 33:   */ 
/* 34:   */ 
/* 35:   */ 
/* 36:   */ 
/* 37:   */ 
/* 38:61 */     return (index >= 0) && (get(index).equals(target)) ? index : -1;
/* 39:   */   }
/* 40:   */   
/* 41:   */   @GwtIncompatible("ImmutableSortedSet.indexOf")
/* 42:   */   public int lastIndexOf(@Nullable Object target)
/* 43:   */   {
/* 44:67 */     return indexOf(target);
/* 45:   */   }
/* 46:   */   
/* 47:   */   public boolean contains(Object target)
/* 48:   */   {
/* 49:73 */     return indexOf(target) >= 0;
/* 50:   */   }
/* 51:   */   
/* 52:   */   @GwtIncompatible("super.subListUnchecked does not exist; inherited subList is valid if slow")
/* 53:   */   ImmutableList<E> subListUnchecked(int fromIndex, int toIndex)
/* 54:   */   {
/* 55:84 */     ImmutableList<E> parentSubList = super.subListUnchecked(fromIndex, toIndex);
/* 56:85 */     return new RegularImmutableSortedSet(parentSubList, comparator()).asList();
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedAsList
 * JD-Core Version:    0.7.0.1
 */