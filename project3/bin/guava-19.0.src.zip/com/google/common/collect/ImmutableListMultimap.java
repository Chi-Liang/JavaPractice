/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.InvalidObjectException;
/*   8:    */ import java.io.ObjectInputStream;
/*   9:    */ import java.io.ObjectOutputStream;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Map.Entry;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @GwtCompatible(serializable=true, emulated=true)
/*  17:    */ public class ImmutableListMultimap<K, V>
/*  18:    */   extends ImmutableMultimap<K, V>
/*  19:    */   implements ListMultimap<K, V>
/*  20:    */ {
/*  21:    */   private transient ImmutableListMultimap<V, K> inverse;
/*  22:    */   @GwtIncompatible("Not needed in emulated source")
/*  23:    */   private static final long serialVersionUID = 0L;
/*  24:    */   
/*  25:    */   public static <K, V> ImmutableListMultimap<K, V> of()
/*  26:    */   {
/*  27: 52 */     return EmptyImmutableListMultimap.INSTANCE;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1)
/*  31:    */   {
/*  32: 59 */     Builder<K, V> builder = builder();
/*  33: 60 */     builder.put(k1, v1);
/*  34: 61 */     return builder.build();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2)
/*  38:    */   {
/*  39: 68 */     Builder<K, V> builder = builder();
/*  40: 69 */     builder.put(k1, v1);
/*  41: 70 */     builder.put(k2, v2);
/*  42: 71 */     return builder.build();
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  46:    */   {
/*  47: 78 */     Builder<K, V> builder = builder();
/*  48: 79 */     builder.put(k1, v1);
/*  49: 80 */     builder.put(k2, v2);
/*  50: 81 */     builder.put(k3, v3);
/*  51: 82 */     return builder.build();
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  55:    */   {
/*  56: 90 */     Builder<K, V> builder = builder();
/*  57: 91 */     builder.put(k1, v1);
/*  58: 92 */     builder.put(k2, v2);
/*  59: 93 */     builder.put(k3, v3);
/*  60: 94 */     builder.put(k4, v4);
/*  61: 95 */     return builder.build();
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static <K, V> ImmutableListMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  65:    */   {
/*  66:103 */     Builder<K, V> builder = builder();
/*  67:104 */     builder.put(k1, v1);
/*  68:105 */     builder.put(k2, v2);
/*  69:106 */     builder.put(k3, v3);
/*  70:107 */     builder.put(k4, v4);
/*  71:108 */     builder.put(k5, v5);
/*  72:109 */     return builder.build();
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static <K, V> Builder<K, V> builder()
/*  76:    */   {
/*  77:119 */     return new Builder();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static final class Builder<K, V>
/*  81:    */     extends ImmutableMultimap.Builder<K, V>
/*  82:    */   {
/*  83:    */     public Builder<K, V> put(K key, V value)
/*  84:    */     {
/*  85:149 */       super.put(key, value);
/*  86:150 */       return this;
/*  87:    */     }
/*  88:    */     
/*  89:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/*  90:    */     {
/*  91:160 */       super.put(entry);
/*  92:161 */       return this;
/*  93:    */     }
/*  94:    */     
/*  95:    */     @Beta
/*  96:    */     public Builder<K, V> putAll(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/*  97:    */     {
/*  98:172 */       super.putAll(entries);
/*  99:173 */       return this;
/* 100:    */     }
/* 101:    */     
/* 102:    */     public Builder<K, V> putAll(K key, Iterable<? extends V> values)
/* 103:    */     {
/* 104:178 */       super.putAll(key, values);
/* 105:179 */       return this;
/* 106:    */     }
/* 107:    */     
/* 108:    */     public Builder<K, V> putAll(K key, V... values)
/* 109:    */     {
/* 110:184 */       super.putAll(key, values);
/* 111:185 */       return this;
/* 112:    */     }
/* 113:    */     
/* 114:    */     public Builder<K, V> putAll(Multimap<? extends K, ? extends V> multimap)
/* 115:    */     {
/* 116:190 */       super.putAll(multimap);
/* 117:191 */       return this;
/* 118:    */     }
/* 119:    */     
/* 120:    */     public Builder<K, V> orderKeysBy(Comparator<? super K> keyComparator)
/* 121:    */     {
/* 122:201 */       super.orderKeysBy(keyComparator);
/* 123:202 */       return this;
/* 124:    */     }
/* 125:    */     
/* 126:    */     public Builder<K, V> orderValuesBy(Comparator<? super V> valueComparator)
/* 127:    */     {
/* 128:212 */       super.orderValuesBy(valueComparator);
/* 129:213 */       return this;
/* 130:    */     }
/* 131:    */     
/* 132:    */     public ImmutableListMultimap<K, V> build()
/* 133:    */     {
/* 134:221 */       return (ImmutableListMultimap)super.build();
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public static <K, V> ImmutableListMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap)
/* 139:    */   {
/* 140:239 */     if (multimap.isEmpty()) {
/* 141:240 */       return of();
/* 142:    */     }
/* 143:244 */     if ((multimap instanceof ImmutableListMultimap))
/* 144:    */     {
/* 145:246 */       ImmutableListMultimap<K, V> kvMultimap = (ImmutableListMultimap)multimap;
/* 146:247 */       if (!kvMultimap.isPartialView()) {
/* 147:248 */         return kvMultimap;
/* 148:    */       }
/* 149:    */     }
/* 150:252 */     ImmutableMap.Builder<K, ImmutableList<V>> builder = new ImmutableMap.Builder(multimap.asMap().size());
/* 151:    */     
/* 152:254 */     int size = 0;
/* 153:257 */     for (Map.Entry<? extends K, ? extends Collection<? extends V>> entry : multimap.asMap().entrySet())
/* 154:    */     {
/* 155:258 */       ImmutableList<V> list = ImmutableList.copyOf((Collection)entry.getValue());
/* 156:259 */       if (!list.isEmpty())
/* 157:    */       {
/* 158:260 */         builder.put(entry.getKey(), list);
/* 159:261 */         size += list.size();
/* 160:    */       }
/* 161:    */     }
/* 162:265 */     return new ImmutableListMultimap(builder.build(), size);
/* 163:    */   }
/* 164:    */   
/* 165:    */   @Beta
/* 166:    */   public static <K, V> ImmutableListMultimap<K, V> copyOf(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/* 167:    */   {
/* 168:280 */     return new Builder().putAll(entries).build();
/* 169:    */   }
/* 170:    */   
/* 171:    */   ImmutableListMultimap(ImmutableMap<K, ImmutableList<V>> map, int size)
/* 172:    */   {
/* 173:284 */     super(map, size);
/* 174:    */   }
/* 175:    */   
/* 176:    */   public ImmutableList<V> get(@Nullable K key)
/* 177:    */   {
/* 178:298 */     ImmutableList<V> list = (ImmutableList)this.map.get(key);
/* 179:299 */     return list == null ? ImmutableList.of() : list;
/* 180:    */   }
/* 181:    */   
/* 182:    */   public ImmutableListMultimap<V, K> inverse()
/* 183:    */   {
/* 184:316 */     ImmutableListMultimap<V, K> result = this.inverse;
/* 185:317 */     return result == null ? (this.inverse = invert()) : result;
/* 186:    */   }
/* 187:    */   
/* 188:    */   private ImmutableListMultimap<V, K> invert()
/* 189:    */   {
/* 190:321 */     Builder<V, K> builder = builder();
/* 191:322 */     for (Map.Entry<K, V> entry : entries()) {
/* 192:323 */       builder.put(entry.getValue(), entry.getKey());
/* 193:    */     }
/* 194:325 */     ImmutableListMultimap<V, K> invertedMultimap = builder.build();
/* 195:326 */     invertedMultimap.inverse = this;
/* 196:327 */     return invertedMultimap;
/* 197:    */   }
/* 198:    */   
/* 199:    */   @Deprecated
/* 200:    */   public ImmutableList<V> removeAll(Object key)
/* 201:    */   {
/* 202:339 */     throw new UnsupportedOperationException();
/* 203:    */   }
/* 204:    */   
/* 205:    */   @Deprecated
/* 206:    */   public ImmutableList<V> replaceValues(K key, Iterable<? extends V> values)
/* 207:    */   {
/* 208:351 */     throw new UnsupportedOperationException();
/* 209:    */   }
/* 210:    */   
/* 211:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 212:    */   private void writeObject(ObjectOutputStream stream)
/* 213:    */     throws IOException
/* 214:    */   {
/* 215:360 */     stream.defaultWriteObject();
/* 216:361 */     Serialization.writeMultimap(this, stream);
/* 217:    */   }
/* 218:    */   
/* 219:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 220:    */   private void readObject(ObjectInputStream stream)
/* 221:    */     throws IOException, ClassNotFoundException
/* 222:    */   {
/* 223:366 */     stream.defaultReadObject();
/* 224:367 */     int keyCount = stream.readInt();
/* 225:368 */     if (keyCount < 0) {
/* 226:369 */       throw new InvalidObjectException("Invalid key count " + keyCount);
/* 227:    */     }
/* 228:371 */     ImmutableMap.Builder<Object, ImmutableList<Object>> builder = ImmutableMap.builder();
/* 229:372 */     int tmpSize = 0;
/* 230:374 */     for (int i = 0; i < keyCount; i++)
/* 231:    */     {
/* 232:375 */       Object key = stream.readObject();
/* 233:376 */       int valueCount = stream.readInt();
/* 234:377 */       if (valueCount <= 0) {
/* 235:378 */         throw new InvalidObjectException("Invalid value count " + valueCount);
/* 236:    */       }
/* 237:381 */       ImmutableList.Builder<Object> valuesBuilder = ImmutableList.builder();
/* 238:382 */       for (int j = 0; j < valueCount; j++) {
/* 239:383 */         valuesBuilder.add(stream.readObject());
/* 240:    */       }
/* 241:385 */       builder.put(key, valuesBuilder.build());
/* 242:386 */       tmpSize += valueCount;
/* 243:    */     }
/* 244:    */     ImmutableMap<Object, ImmutableList<Object>> tmpMap;
/* 245:    */     try
/* 246:    */     {
/* 247:391 */       tmpMap = builder.build();
/* 248:    */     }
/* 249:    */     catch (IllegalArgumentException e)
/* 250:    */     {
/* 251:393 */       throw ((InvalidObjectException)new InvalidObjectException(e.getMessage()).initCause(e));
/* 252:    */     }
/* 253:396 */     ImmutableMultimap.FieldSettersHolder.MAP_FIELD_SETTER.set(this, tmpMap);
/* 254:397 */     ImmutableMultimap.FieldSettersHolder.SIZE_FIELD_SETTER.set(this, tmpSize);
/* 255:    */   }
/* 256:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableListMultimap
 * JD-Core Version:    0.7.0.1
 */