/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.io.IOException;
/*   8:    */ import java.io.ObjectInputStream;
/*   9:    */ import java.io.ObjectOutputStream;
/*  10:    */ import java.io.Serializable;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Map.Entry;
/*  15:    */ import java.util.Set;
/*  16:    */ import javax.annotation.Nullable;
/*  17:    */ 
/*  18:    */ @GwtCompatible(emulated=true)
/*  19:    */ abstract class AbstractBiMap<K, V>
/*  20:    */   extends ForwardingMap<K, V>
/*  21:    */   implements BiMap<K, V>, Serializable
/*  22:    */ {
/*  23:    */   private transient Map<K, V> delegate;
/*  24:    */   transient AbstractBiMap<V, K> inverse;
/*  25:    */   private transient Set<K> keySet;
/*  26:    */   private transient Set<V> valueSet;
/*  27:    */   private transient Set<Map.Entry<K, V>> entrySet;
/*  28:    */   @GwtIncompatible("Not needed in emulated source.")
/*  29:    */   private static final long serialVersionUID = 0L;
/*  30:    */   
/*  31:    */   AbstractBiMap(Map<K, V> forward, Map<V, K> backward)
/*  32:    */   {
/*  33: 58 */     setDelegates(forward, backward);
/*  34:    */   }
/*  35:    */   
/*  36:    */   private AbstractBiMap(Map<K, V> backward, AbstractBiMap<V, K> forward)
/*  37:    */   {
/*  38: 63 */     this.delegate = backward;
/*  39: 64 */     this.inverse = forward;
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected Map<K, V> delegate()
/*  43:    */   {
/*  44: 69 */     return this.delegate;
/*  45:    */   }
/*  46:    */   
/*  47:    */   K checkKey(@Nullable K key)
/*  48:    */   {
/*  49: 76 */     return key;
/*  50:    */   }
/*  51:    */   
/*  52:    */   V checkValue(@Nullable V value)
/*  53:    */   {
/*  54: 83 */     return value;
/*  55:    */   }
/*  56:    */   
/*  57:    */   void setDelegates(Map<K, V> forward, Map<V, K> backward)
/*  58:    */   {
/*  59: 91 */     Preconditions.checkState(this.delegate == null);
/*  60: 92 */     Preconditions.checkState(this.inverse == null);
/*  61: 93 */     Preconditions.checkArgument(forward.isEmpty());
/*  62: 94 */     Preconditions.checkArgument(backward.isEmpty());
/*  63: 95 */     Preconditions.checkArgument(forward != backward);
/*  64: 96 */     this.delegate = forward;
/*  65: 97 */     this.inverse = new Inverse(backward, this, null);
/*  66:    */   }
/*  67:    */   
/*  68:    */   void setInverse(AbstractBiMap<V, K> inverse)
/*  69:    */   {
/*  70:101 */     this.inverse = inverse;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public boolean containsValue(@Nullable Object value)
/*  74:    */   {
/*  75:108 */     return this.inverse.containsKey(value);
/*  76:    */   }
/*  77:    */   
/*  78:    */   public V put(@Nullable K key, @Nullable V value)
/*  79:    */   {
/*  80:115 */     return putInBothMaps(key, value, false);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public V forcePut(@Nullable K key, @Nullable V value)
/*  84:    */   {
/*  85:120 */     return putInBothMaps(key, value, true);
/*  86:    */   }
/*  87:    */   
/*  88:    */   private V putInBothMaps(@Nullable K key, @Nullable V value, boolean force)
/*  89:    */   {
/*  90:124 */     checkKey(key);
/*  91:125 */     checkValue(value);
/*  92:126 */     boolean containedKey = containsKey(key);
/*  93:127 */     if ((containedKey) && (Objects.equal(value, get(key)))) {
/*  94:128 */       return value;
/*  95:    */     }
/*  96:130 */     if (force) {
/*  97:131 */       inverse().remove(value);
/*  98:    */     } else {
/*  99:133 */       Preconditions.checkArgument(!containsValue(value), "value already present: %s", new Object[] { value });
/* 100:    */     }
/* 101:135 */     V oldValue = this.delegate.put(key, value);
/* 102:136 */     updateInverseMap(key, containedKey, oldValue, value);
/* 103:137 */     return oldValue;
/* 104:    */   }
/* 105:    */   
/* 106:    */   private void updateInverseMap(K key, boolean containedKey, V oldValue, V newValue)
/* 107:    */   {
/* 108:141 */     if (containedKey) {
/* 109:142 */       removeFromInverseMap(oldValue);
/* 110:    */     }
/* 111:144 */     this.inverse.delegate.put(newValue, key);
/* 112:    */   }
/* 113:    */   
/* 114:    */   public V remove(@Nullable Object key)
/* 115:    */   {
/* 116:149 */     return containsKey(key) ? removeFromBothMaps(key) : null;
/* 117:    */   }
/* 118:    */   
/* 119:    */   private V removeFromBothMaps(Object key)
/* 120:    */   {
/* 121:153 */     V oldValue = this.delegate.remove(key);
/* 122:154 */     removeFromInverseMap(oldValue);
/* 123:155 */     return oldValue;
/* 124:    */   }
/* 125:    */   
/* 126:    */   private void removeFromInverseMap(V oldValue)
/* 127:    */   {
/* 128:159 */     this.inverse.delegate.remove(oldValue);
/* 129:    */   }
/* 130:    */   
/* 131:    */   public void putAll(Map<? extends K, ? extends V> map)
/* 132:    */   {
/* 133:166 */     for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
/* 134:167 */       put(entry.getKey(), entry.getValue());
/* 135:    */     }
/* 136:    */   }
/* 137:    */   
/* 138:    */   public void clear()
/* 139:    */   {
/* 140:173 */     this.delegate.clear();
/* 141:174 */     this.inverse.delegate.clear();
/* 142:    */   }
/* 143:    */   
/* 144:    */   public BiMap<V, K> inverse()
/* 145:    */   {
/* 146:181 */     return this.inverse;
/* 147:    */   }
/* 148:    */   
/* 149:    */   public Set<K> keySet()
/* 150:    */   {
/* 151:188 */     Set<K> result = this.keySet;
/* 152:189 */     return result == null ? (this.keySet = new KeySet(null)) : result;
/* 153:    */   }
/* 154:    */   
/* 155:    */   private class KeySet
/* 156:    */     extends ForwardingSet<K>
/* 157:    */   {
/* 158:    */     private KeySet() {}
/* 159:    */     
/* 160:    */     protected Set<K> delegate()
/* 161:    */     {
/* 162:196 */       return AbstractBiMap.this.delegate.keySet();
/* 163:    */     }
/* 164:    */     
/* 165:    */     public void clear()
/* 166:    */     {
/* 167:201 */       AbstractBiMap.this.clear();
/* 168:    */     }
/* 169:    */     
/* 170:    */     public boolean remove(Object key)
/* 171:    */     {
/* 172:206 */       if (!contains(key)) {
/* 173:207 */         return false;
/* 174:    */       }
/* 175:209 */       AbstractBiMap.this.removeFromBothMaps(key);
/* 176:210 */       return true;
/* 177:    */     }
/* 178:    */     
/* 179:    */     public boolean removeAll(Collection<?> keysToRemove)
/* 180:    */     {
/* 181:215 */       return standardRemoveAll(keysToRemove);
/* 182:    */     }
/* 183:    */     
/* 184:    */     public boolean retainAll(Collection<?> keysToRetain)
/* 185:    */     {
/* 186:220 */       return standardRetainAll(keysToRetain);
/* 187:    */     }
/* 188:    */     
/* 189:    */     public Iterator<K> iterator()
/* 190:    */     {
/* 191:225 */       return Maps.keyIterator(AbstractBiMap.this.entrySet().iterator());
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public Set<V> values()
/* 196:    */   {
/* 197:237 */     Set<V> result = this.valueSet;
/* 198:238 */     return result == null ? (this.valueSet = new ValueSet(null)) : result;
/* 199:    */   }
/* 200:    */   
/* 201:    */   private class ValueSet
/* 202:    */     extends ForwardingSet<V>
/* 203:    */   {
/* 204:243 */     final Set<V> valuesDelegate = AbstractBiMap.this.inverse.keySet();
/* 205:    */     
/* 206:    */     private ValueSet() {}
/* 207:    */     
/* 208:    */     protected Set<V> delegate()
/* 209:    */     {
/* 210:247 */       return this.valuesDelegate;
/* 211:    */     }
/* 212:    */     
/* 213:    */     public Iterator<V> iterator()
/* 214:    */     {
/* 215:252 */       return Maps.valueIterator(AbstractBiMap.this.entrySet().iterator());
/* 216:    */     }
/* 217:    */     
/* 218:    */     public Object[] toArray()
/* 219:    */     {
/* 220:257 */       return standardToArray();
/* 221:    */     }
/* 222:    */     
/* 223:    */     public <T> T[] toArray(T[] array)
/* 224:    */     {
/* 225:262 */       return standardToArray(array);
/* 226:    */     }
/* 227:    */     
/* 228:    */     public String toString()
/* 229:    */     {
/* 230:267 */       return standardToString();
/* 231:    */     }
/* 232:    */   }
/* 233:    */   
/* 234:    */   public Set<Map.Entry<K, V>> entrySet()
/* 235:    */   {
/* 236:275 */     Set<Map.Entry<K, V>> result = this.entrySet;
/* 237:276 */     return result == null ? (this.entrySet = new EntrySet(null)) : result;
/* 238:    */   }
/* 239:    */   
/* 240:    */   private class EntrySet
/* 241:    */     extends ForwardingSet<Map.Entry<K, V>>
/* 242:    */   {
/* 243:281 */     final Set<Map.Entry<K, V>> esDelegate = AbstractBiMap.this.delegate.entrySet();
/* 244:    */     
/* 245:    */     private EntrySet() {}
/* 246:    */     
/* 247:    */     protected Set<Map.Entry<K, V>> delegate()
/* 248:    */     {
/* 249:285 */       return this.esDelegate;
/* 250:    */     }
/* 251:    */     
/* 252:    */     public void clear()
/* 253:    */     {
/* 254:290 */       AbstractBiMap.this.clear();
/* 255:    */     }
/* 256:    */     
/* 257:    */     public boolean remove(Object object)
/* 258:    */     {
/* 259:295 */       if (!this.esDelegate.contains(object)) {
/* 260:296 */         return false;
/* 261:    */       }
/* 262:300 */       Map.Entry<?, ?> entry = (Map.Entry)object;
/* 263:301 */       AbstractBiMap.this.inverse.delegate.remove(entry.getValue());
/* 264:    */       
/* 265:    */ 
/* 266:    */ 
/* 267:    */ 
/* 268:    */ 
/* 269:307 */       this.esDelegate.remove(entry);
/* 270:308 */       return true;
/* 271:    */     }
/* 272:    */     
/* 273:    */     public Iterator<Map.Entry<K, V>> iterator()
/* 274:    */     {
/* 275:313 */       final Iterator<Map.Entry<K, V>> iterator = this.esDelegate.iterator();
/* 276:314 */       new Iterator()
/* 277:    */       {
/* 278:    */         Map.Entry<K, V> entry;
/* 279:    */         
/* 280:    */         public boolean hasNext()
/* 281:    */         {
/* 282:319 */           return iterator.hasNext();
/* 283:    */         }
/* 284:    */         
/* 285:    */         public Map.Entry<K, V> next()
/* 286:    */         {
/* 287:324 */           this.entry = ((Map.Entry)iterator.next());
/* 288:325 */           final Map.Entry<K, V> finalEntry = this.entry;
/* 289:    */           
/* 290:327 */           new ForwardingMapEntry()
/* 291:    */           {
/* 292:    */             protected Map.Entry<K, V> delegate()
/* 293:    */             {
/* 294:330 */               return finalEntry;
/* 295:    */             }
/* 296:    */             
/* 297:    */             public V setValue(V value)
/* 298:    */             {
/* 299:336 */               Preconditions.checkState(AbstractBiMap.EntrySet.this.contains(this), "entry no longer in map");
/* 300:338 */               if (Objects.equal(value, getValue())) {
/* 301:339 */                 return value;
/* 302:    */               }
/* 303:341 */               Preconditions.checkArgument(!AbstractBiMap.this.containsValue(value), "value already present: %s", new Object[] { value });
/* 304:342 */               V oldValue = finalEntry.setValue(value);
/* 305:343 */               Preconditions.checkState(Objects.equal(value, AbstractBiMap.this.get(getKey())), "entry no longer in map");
/* 306:344 */               AbstractBiMap.this.updateInverseMap(getKey(), true, oldValue, value);
/* 307:345 */               return oldValue;
/* 308:    */             }
/* 309:    */           };
/* 310:    */         }
/* 311:    */         
/* 312:    */         public void remove()
/* 313:    */         {
/* 314:352 */           CollectPreconditions.checkRemove(this.entry != null);
/* 315:353 */           V value = this.entry.getValue();
/* 316:354 */           iterator.remove();
/* 317:355 */           AbstractBiMap.this.removeFromInverseMap(value);
/* 318:    */         }
/* 319:    */       };
/* 320:    */     }
/* 321:    */     
/* 322:    */     public Object[] toArray()
/* 323:    */     {
/* 324:364 */       return standardToArray();
/* 325:    */     }
/* 326:    */     
/* 327:    */     public <T> T[] toArray(T[] array)
/* 328:    */     {
/* 329:369 */       return standardToArray(array);
/* 330:    */     }
/* 331:    */     
/* 332:    */     public boolean contains(Object o)
/* 333:    */     {
/* 334:374 */       return Maps.containsEntryImpl(delegate(), o);
/* 335:    */     }
/* 336:    */     
/* 337:    */     public boolean containsAll(Collection<?> c)
/* 338:    */     {
/* 339:379 */       return standardContainsAll(c);
/* 340:    */     }
/* 341:    */     
/* 342:    */     public boolean removeAll(Collection<?> c)
/* 343:    */     {
/* 344:384 */       return standardRemoveAll(c);
/* 345:    */     }
/* 346:    */     
/* 347:    */     public boolean retainAll(Collection<?> c)
/* 348:    */     {
/* 349:389 */       return standardRetainAll(c);
/* 350:    */     }
/* 351:    */   }
/* 352:    */   
/* 353:    */   private static class Inverse<K, V>
/* 354:    */     extends AbstractBiMap<K, V>
/* 355:    */   {
/* 356:    */     @GwtIncompatible("Not needed in emulated source.")
/* 357:    */     private static final long serialVersionUID = 0L;
/* 358:    */     
/* 359:    */     private Inverse(Map<K, V> backward, AbstractBiMap<V, K> forward)
/* 360:    */     {
/* 361:396 */       super(forward, null);
/* 362:    */     }
/* 363:    */     
/* 364:    */     K checkKey(K key)
/* 365:    */     {
/* 366:410 */       return this.inverse.checkValue(key);
/* 367:    */     }
/* 368:    */     
/* 369:    */     V checkValue(V value)
/* 370:    */     {
/* 371:415 */       return this.inverse.checkKey(value);
/* 372:    */     }
/* 373:    */     
/* 374:    */     @GwtIncompatible("java.io.ObjectOuputStream")
/* 375:    */     private void writeObject(ObjectOutputStream stream)
/* 376:    */       throws IOException
/* 377:    */     {
/* 378:423 */       stream.defaultWriteObject();
/* 379:424 */       stream.writeObject(inverse());
/* 380:    */     }
/* 381:    */     
/* 382:    */     @GwtIncompatible("java.io.ObjectInputStream")
/* 383:    */     private void readObject(ObjectInputStream stream)
/* 384:    */       throws IOException, ClassNotFoundException
/* 385:    */     {
/* 386:430 */       stream.defaultReadObject();
/* 387:431 */       setInverse((AbstractBiMap)stream.readObject());
/* 388:    */     }
/* 389:    */     
/* 390:    */     @GwtIncompatible("Not needed in the emulated source.")
/* 391:    */     Object readResolve()
/* 392:    */     {
/* 393:436 */       return inverse().inverse();
/* 394:    */     }
/* 395:    */   }
/* 396:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractBiMap
 * JD-Core Version:    0.7.0.1
 */