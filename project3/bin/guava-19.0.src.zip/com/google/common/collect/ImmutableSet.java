/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.EnumSet;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.Set;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public abstract class ImmutableSet<E>
/*  16:    */   extends ImmutableCollection<E>
/*  17:    */   implements Set<E>
/*  18:    */ {
/*  19:    */   static final int MAX_TABLE_SIZE = 1073741824;
/*  20:    */   private static final double DESIRED_LOAD_FACTOR = 0.7D;
/*  21:    */   private static final int CUTOFF = 751619276;
/*  22:    */   
/*  23:    */   public static <E> ImmutableSet<E> of()
/*  24:    */   {
/*  25: 51 */     return RegularImmutableSet.EMPTY;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <E> ImmutableSet<E> of(E element)
/*  29:    */   {
/*  30: 60 */     return new SingletonImmutableSet(element);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static <E> ImmutableSet<E> of(E e1, E e2)
/*  34:    */   {
/*  35: 69 */     return construct(2, new Object[] { e1, e2 });
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3)
/*  39:    */   {
/*  40: 78 */     return construct(3, new Object[] { e1, e2, e3 });
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4)
/*  44:    */   {
/*  45: 87 */     return construct(4, new Object[] { e1, e2, e3, e4 });
/*  46:    */   }
/*  47:    */   
/*  48:    */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4, E e5)
/*  49:    */   {
/*  50: 96 */     return construct(5, new Object[] { e1, e2, e3, e4, e5 });
/*  51:    */   }
/*  52:    */   
/*  53:    */   public static <E> ImmutableSet<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... others)
/*  54:    */   {
/*  55:107 */     int paramCount = 6;
/*  56:108 */     Object[] elements = new Object[6 + others.length];
/*  57:109 */     elements[0] = e1;
/*  58:110 */     elements[1] = e2;
/*  59:111 */     elements[2] = e3;
/*  60:112 */     elements[3] = e4;
/*  61:113 */     elements[4] = e5;
/*  62:114 */     elements[5] = e6;
/*  63:115 */     System.arraycopy(others, 0, elements, 6, others.length);
/*  64:116 */     return construct(elements.length, elements);
/*  65:    */   }
/*  66:    */   
/*  67:    */   private static <E> ImmutableSet<E> construct(int n, Object... elements)
/*  68:    */   {
/*  69:135 */     switch (n)
/*  70:    */     {
/*  71:    */     case 0: 
/*  72:137 */       return of();
/*  73:    */     case 1: 
/*  74:140 */       E elem = elements[0];
/*  75:141 */       return of(elem);
/*  76:    */     }
/*  77:145 */     int tableSize = chooseTableSize(n);
/*  78:146 */     Object[] table = new Object[tableSize];
/*  79:147 */     int mask = tableSize - 1;
/*  80:148 */     int hashCode = 0;
/*  81:149 */     int uniques = 0;
/*  82:150 */     for (int i = 0; i < n; i++)
/*  83:    */     {
/*  84:151 */       Object element = ObjectArrays.checkElementNotNull(elements[i], i);
/*  85:152 */       int hash = element.hashCode();
/*  86:153 */       for (int j = Hashing.smear(hash);; j++)
/*  87:    */       {
/*  88:154 */         int index = j & mask;
/*  89:155 */         Object value = table[index];
/*  90:156 */         if (value == null)
/*  91:    */         {
/*  92:158 */           elements[(uniques++)] = element;
/*  93:159 */           table[index] = element;
/*  94:160 */           hashCode += hash;
/*  95:    */         }
/*  96:    */         else
/*  97:    */         {
/*  98:162 */           if (value.equals(element)) {
/*  99:    */             break;
/* 100:    */           }
/* 101:    */         }
/* 102:    */       }
/* 103:    */     }
/* 104:167 */     Arrays.fill(elements, uniques, n, null);
/* 105:168 */     if (uniques == 1)
/* 106:    */     {
/* 107:171 */       E element = elements[0];
/* 108:172 */       return new SingletonImmutableSet(element, hashCode);
/* 109:    */     }
/* 110:173 */     if (tableSize != chooseTableSize(uniques)) {
/* 111:176 */       return construct(uniques, elements);
/* 112:    */     }
/* 113:178 */     Object[] uniqueElements = uniques < elements.length ? ObjectArrays.arraysCopyOf(elements, uniques) : elements;
/* 114:    */     
/* 115:    */ 
/* 116:    */ 
/* 117:182 */     return new RegularImmutableSet(uniqueElements, hashCode, table, mask);
/* 118:    */   }
/* 119:    */   
/* 120:    */   @VisibleForTesting
/* 121:    */   static int chooseTableSize(int setSize)
/* 122:    */   {
/* 123:206 */     if (setSize < 751619276)
/* 124:    */     {
/* 125:208 */       int tableSize = Integer.highestOneBit(setSize - 1) << 1;
/* 126:209 */       while (tableSize * 0.7D < setSize) {
/* 127:210 */         tableSize <<= 1;
/* 128:    */       }
/* 129:212 */       return tableSize;
/* 130:    */     }
/* 131:216 */     Preconditions.checkArgument(setSize < 1073741824, "collection too large");
/* 132:217 */     return 1073741824;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static <E> ImmutableSet<E> copyOf(Collection<? extends E> elements)
/* 136:    */   {
/* 137:237 */     if (((elements instanceof ImmutableSet)) && (!(elements instanceof ImmutableSortedSet)))
/* 138:    */     {
/* 139:239 */       ImmutableSet<E> set = (ImmutableSet)elements;
/* 140:240 */       if (!set.isPartialView()) {
/* 141:241 */         return set;
/* 142:    */       }
/* 143:    */     }
/* 144:243 */     else if ((elements instanceof EnumSet))
/* 145:    */     {
/* 146:244 */       return copyOfEnumSet((EnumSet)elements);
/* 147:    */     }
/* 148:246 */     Object[] array = elements.toArray();
/* 149:247 */     return construct(array.length, array);
/* 150:    */   }
/* 151:    */   
/* 152:    */   public static <E> ImmutableSet<E> copyOf(Iterable<? extends E> elements)
/* 153:    */   {
/* 154:263 */     return (elements instanceof Collection) ? copyOf((Collection)elements) : copyOf(elements.iterator());
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static <E> ImmutableSet<E> copyOf(Iterator<? extends E> elements)
/* 158:    */   {
/* 159:276 */     if (!elements.hasNext()) {
/* 160:277 */       return of();
/* 161:    */     }
/* 162:279 */     E first = elements.next();
/* 163:280 */     if (!elements.hasNext()) {
/* 164:281 */       return of(first);
/* 165:    */     }
/* 166:283 */     return new Builder().add(first).addAll(elements).build();
/* 167:    */   }
/* 168:    */   
/* 169:    */   public static <E> ImmutableSet<E> copyOf(E[] elements)
/* 170:    */   {
/* 171:298 */     switch (elements.length)
/* 172:    */     {
/* 173:    */     case 0: 
/* 174:300 */       return of();
/* 175:    */     case 1: 
/* 176:302 */       return of(elements[0]);
/* 177:    */     }
/* 178:304 */     return construct(elements.length, (Object[])elements.clone());
/* 179:    */   }
/* 180:    */   
/* 181:    */   private static ImmutableSet copyOfEnumSet(EnumSet enumSet)
/* 182:    */   {
/* 183:310 */     return ImmutableEnumSet.asImmutable(EnumSet.copyOf(enumSet));
/* 184:    */   }
/* 185:    */   
/* 186:    */   boolean isHashCodeFast()
/* 187:    */   {
/* 188:317 */     return false;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public boolean equals(@Nullable Object object)
/* 192:    */   {
/* 193:322 */     if (object == this) {
/* 194:323 */       return true;
/* 195:    */     }
/* 196:324 */     if (((object instanceof ImmutableSet)) && (isHashCodeFast()) && (((ImmutableSet)object).isHashCodeFast()) && (hashCode() != object.hashCode())) {
/* 197:328 */       return false;
/* 198:    */     }
/* 199:330 */     return Sets.equalsImpl(this, object);
/* 200:    */   }
/* 201:    */   
/* 202:    */   public int hashCode()
/* 203:    */   {
/* 204:335 */     return Sets.hashCodeImpl(this);
/* 205:    */   }
/* 206:    */   
/* 207:    */   public abstract UnmodifiableIterator<E> iterator();
/* 208:    */   
/* 209:    */   static abstract class Indexed<E>
/* 210:    */     extends ImmutableSet<E>
/* 211:    */   {
/* 212:    */     abstract E get(int paramInt);
/* 213:    */     
/* 214:    */     public UnmodifiableIterator<E> iterator()
/* 215:    */     {
/* 216:348 */       return asList().iterator();
/* 217:    */     }
/* 218:    */     
/* 219:    */     ImmutableList<E> createAsList()
/* 220:    */     {
/* 221:353 */       new ImmutableAsList()
/* 222:    */       {
/* 223:    */         public E get(int index)
/* 224:    */         {
/* 225:356 */           return ImmutableSet.Indexed.this.get(index);
/* 226:    */         }
/* 227:    */         
/* 228:    */         ImmutableSet.Indexed<E> delegateCollection()
/* 229:    */         {
/* 230:361 */           return ImmutableSet.Indexed.this;
/* 231:    */         }
/* 232:    */       };
/* 233:    */     }
/* 234:    */   }
/* 235:    */   
/* 236:    */   private static class SerializedForm
/* 237:    */     implements Serializable
/* 238:    */   {
/* 239:    */     final Object[] elements;
/* 240:    */     private static final long serialVersionUID = 0L;
/* 241:    */     
/* 242:    */     SerializedForm(Object[] elements)
/* 243:    */     {
/* 244:378 */       this.elements = elements;
/* 245:    */     }
/* 246:    */     
/* 247:    */     Object readResolve()
/* 248:    */     {
/* 249:382 */       return ImmutableSet.copyOf(this.elements);
/* 250:    */     }
/* 251:    */   }
/* 252:    */   
/* 253:    */   Object writeReplace()
/* 254:    */   {
/* 255:390 */     return new SerializedForm(toArray());
/* 256:    */   }
/* 257:    */   
/* 258:    */   public static <E> Builder<E> builder()
/* 259:    */   {
/* 260:398 */     return new Builder();
/* 261:    */   }
/* 262:    */   
/* 263:    */   public static class Builder<E>
/* 264:    */     extends ImmutableCollection.ArrayBasedBuilder<E>
/* 265:    */   {
/* 266:    */     public Builder()
/* 267:    */     {
/* 268:422 */       this(4);
/* 269:    */     }
/* 270:    */     
/* 271:    */     Builder(int capacity)
/* 272:    */     {
/* 273:426 */       super();
/* 274:    */     }
/* 275:    */     
/* 276:    */     public Builder<E> add(E element)
/* 277:    */     {
/* 278:440 */       super.add(element);
/* 279:441 */       return this;
/* 280:    */     }
/* 281:    */     
/* 282:    */     public Builder<E> add(E... elements)
/* 283:    */     {
/* 284:455 */       super.add(elements);
/* 285:456 */       return this;
/* 286:    */     }
/* 287:    */     
/* 288:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 289:    */     {
/* 290:470 */       super.addAll(elements);
/* 291:471 */       return this;
/* 292:    */     }
/* 293:    */     
/* 294:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 295:    */     {
/* 296:485 */       super.addAll(elements);
/* 297:486 */       return this;
/* 298:    */     }
/* 299:    */     
/* 300:    */     public ImmutableSet<E> build()
/* 301:    */     {
/* 302:495 */       ImmutableSet<E> result = ImmutableSet.construct(this.size, this.contents);
/* 303:    */       
/* 304:    */ 
/* 305:498 */       this.size = result.size();
/* 306:499 */       return result;
/* 307:    */     }
/* 308:    */   }
/* 309:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableSet
 * JD-Core Version:    0.7.0.1
 */