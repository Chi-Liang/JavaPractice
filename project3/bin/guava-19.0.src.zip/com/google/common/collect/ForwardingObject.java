/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ 
/*  5:   */ @GwtCompatible
/*  6:   */ public abstract class ForwardingObject
/*  7:   */ {
/*  8:   */   protected abstract Object delegate();
/*  9:   */   
/* 10:   */   public String toString()
/* 11:   */   {
/* 12:73 */     return delegate().toString();
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingObject
 * JD-Core Version:    0.7.0.1
 */