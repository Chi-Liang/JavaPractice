/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Comparator;
/*  10:    */ import java.util.EnumMap;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Map.Entry;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @GwtCompatible(serializable=true, emulated=true)
/*  17:    */ public abstract class ImmutableMap<K, V>
/*  18:    */   implements Map<K, V>, Serializable
/*  19:    */ {
/*  20:    */   public static <K, V> ImmutableMap<K, V> of()
/*  21:    */   {
/*  22: 60 */     return ImmutableBiMap.of();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1)
/*  26:    */   {
/*  27: 70 */     return ImmutableBiMap.of(k1, v1);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2)
/*  31:    */   {
/*  32: 79 */     return RegularImmutableMap.fromEntries(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2) });
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  36:    */   {
/*  37: 88 */     return RegularImmutableMap.fromEntries(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3) });
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  41:    */   {
/*  42: 97 */     return RegularImmutableMap.fromEntries(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4) });
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static <K, V> ImmutableMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  46:    */   {
/*  47:108 */     return RegularImmutableMap.fromEntries(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5) });
/*  48:    */   }
/*  49:    */   
/*  50:    */   static <K, V> ImmutableMapEntry<K, V> entryOf(K key, V value)
/*  51:    */   {
/*  52:122 */     return new ImmutableMapEntry(key, value);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static <K, V> Builder<K, V> builder()
/*  56:    */   {
/*  57:130 */     return new Builder();
/*  58:    */   }
/*  59:    */   
/*  60:    */   static void checkNoConflict(boolean safe, String conflictDescription, Map.Entry<?, ?> entry1, Map.Entry<?, ?> entry2)
/*  61:    */   {
/*  62:135 */     if (!safe) {
/*  63:136 */       throw new IllegalArgumentException("Multiple entries with same " + conflictDescription + ": " + entry1 + " and " + entry2);
/*  64:    */     }
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static class Builder<K, V>
/*  68:    */   {
/*  69:    */     Comparator<? super V> valueComparator;
/*  70:    */     ImmutableMapEntry<K, V>[] entries;
/*  71:    */     int size;
/*  72:    */     boolean entriesUsed;
/*  73:    */     
/*  74:    */     public Builder()
/*  75:    */     {
/*  76:172 */       this(4);
/*  77:    */     }
/*  78:    */     
/*  79:    */     Builder(int initialCapacity)
/*  80:    */     {
/*  81:177 */       this.entries = new ImmutableMapEntry[initialCapacity];
/*  82:178 */       this.size = 0;
/*  83:179 */       this.entriesUsed = false;
/*  84:    */     }
/*  85:    */     
/*  86:    */     private void ensureCapacity(int minCapacity)
/*  87:    */     {
/*  88:183 */       if (minCapacity > this.entries.length)
/*  89:    */       {
/*  90:184 */         this.entries = ((ImmutableMapEntry[])ObjectArrays.arraysCopyOf(this.entries, ImmutableCollection.Builder.expandedCapacity(this.entries.length, minCapacity)));
/*  91:    */         
/*  92:    */ 
/*  93:187 */         this.entriesUsed = false;
/*  94:    */       }
/*  95:    */     }
/*  96:    */     
/*  97:    */     public Builder<K, V> put(K key, V value)
/*  98:    */     {
/*  99:196 */       ensureCapacity(this.size + 1);
/* 100:197 */       ImmutableMapEntry<K, V> entry = ImmutableMap.entryOf(key, value);
/* 101:    */       
/* 102:199 */       this.entries[(this.size++)] = entry;
/* 103:200 */       return this;
/* 104:    */     }
/* 105:    */     
/* 106:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/* 107:    */     {
/* 108:211 */       return put(entry.getKey(), entry.getValue());
/* 109:    */     }
/* 110:    */     
/* 111:    */     public Builder<K, V> putAll(Map<? extends K, ? extends V> map)
/* 112:    */     {
/* 113:221 */       return putAll(map.entrySet());
/* 114:    */     }
/* 115:    */     
/* 116:    */     @Beta
/* 117:    */     public Builder<K, V> putAll(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/* 118:    */     {
/* 119:233 */       if ((entries instanceof Collection)) {
/* 120:234 */         ensureCapacity(this.size + ((Collection)entries).size());
/* 121:    */       }
/* 122:236 */       for (Map.Entry<? extends K, ? extends V> entry : entries) {
/* 123:237 */         put(entry);
/* 124:    */       }
/* 125:239 */       return this;
/* 126:    */     }
/* 127:    */     
/* 128:    */     @Beta
/* 129:    */     public Builder<K, V> orderEntriesByValue(Comparator<? super V> valueComparator)
/* 130:    */     {
/* 131:255 */       Preconditions.checkState(this.valueComparator == null, "valueComparator was already set");
/* 132:256 */       this.valueComparator = ((Comparator)Preconditions.checkNotNull(valueComparator, "valueComparator"));
/* 133:257 */       return this;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public ImmutableMap<K, V> build()
/* 137:    */     {
/* 138:271 */       switch (this.size)
/* 139:    */       {
/* 140:    */       case 0: 
/* 141:273 */         return ImmutableMap.of();
/* 142:    */       case 1: 
/* 143:275 */         return ImmutableMap.of(this.entries[0].getKey(), this.entries[0].getValue());
/* 144:    */       }
/* 145:284 */       if (this.valueComparator != null)
/* 146:    */       {
/* 147:285 */         if (this.entriesUsed) {
/* 148:286 */           this.entries = ((ImmutableMapEntry[])ObjectArrays.arraysCopyOf(this.entries, this.size));
/* 149:    */         }
/* 150:288 */         Arrays.sort(this.entries, 0, this.size, Ordering.from(this.valueComparator).onResultOf(Maps.valueFunction()));
/* 151:    */       }
/* 152:294 */       this.entriesUsed = (this.size == this.entries.length);
/* 153:295 */       return RegularImmutableMap.fromEntryArray(this.size, this.entries);
/* 154:    */     }
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static <K, V> ImmutableMap<K, V> copyOf(Map<? extends K, ? extends V> map)
/* 158:    */   {
/* 159:313 */     if (((map instanceof ImmutableMap)) && (!(map instanceof ImmutableSortedMap)))
/* 160:    */     {
/* 161:318 */       ImmutableMap<K, V> kvMap = (ImmutableMap)map;
/* 162:319 */       if (!kvMap.isPartialView()) {
/* 163:320 */         return kvMap;
/* 164:    */       }
/* 165:    */     }
/* 166:322 */     else if ((map instanceof EnumMap))
/* 167:    */     {
/* 168:324 */       ImmutableMap<K, V> kvMap = copyOfEnumMap((EnumMap)map);
/* 169:325 */       return kvMap;
/* 170:    */     }
/* 171:327 */     return copyOf(map.entrySet());
/* 172:    */   }
/* 173:    */   
/* 174:    */   @Beta
/* 175:    */   public static <K, V> ImmutableMap<K, V> copyOf(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/* 176:    */   {
/* 177:342 */     Map.Entry<K, V>[] entryArray = (Map.Entry[])Iterables.toArray(entries, EMPTY_ENTRY_ARRAY);
/* 178:343 */     switch (entryArray.length)
/* 179:    */     {
/* 180:    */     case 0: 
/* 181:345 */       return of();
/* 182:    */     case 1: 
/* 183:347 */       Map.Entry<K, V> onlyEntry = entryArray[0];
/* 184:348 */       return of(onlyEntry.getKey(), onlyEntry.getValue());
/* 185:    */     }
/* 186:354 */     return RegularImmutableMap.fromEntries(entryArray);
/* 187:    */   }
/* 188:    */   
/* 189:    */   private static <K extends Enum<K>, V> ImmutableMap<K, V> copyOfEnumMap(EnumMap<K, ? extends V> original)
/* 190:    */   {
/* 191:360 */     EnumMap<K, V> copy = new EnumMap(original);
/* 192:361 */     for (Map.Entry<?, ?> entry : copy.entrySet()) {
/* 193:362 */       CollectPreconditions.checkEntryNotNull(entry.getKey(), entry.getValue());
/* 194:    */     }
/* 195:364 */     return ImmutableEnumMap.asImmutable(copy);
/* 196:    */   }
/* 197:    */   
/* 198:367 */   static final Map.Entry<?, ?>[] EMPTY_ENTRY_ARRAY = new Map.Entry[0];
/* 199:    */   private transient ImmutableSet<Map.Entry<K, V>> entrySet;
/* 200:    */   private transient ImmutableSet<K> keySet;
/* 201:    */   private transient ImmutableCollection<V> values;
/* 202:    */   private transient ImmutableSetMultimap<K, V> multimapView;
/* 203:    */   
/* 204:    */   static abstract class IteratorBasedImmutableMap<K, V>
/* 205:    */     extends ImmutableMap<K, V>
/* 206:    */   {
/* 207:    */     abstract UnmodifiableIterator<Map.Entry<K, V>> entryIterator();
/* 208:    */     
/* 209:    */     ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 210:    */     {
/* 211:386 */       new ImmutableMapEntrySet()
/* 212:    */       {
/* 213:    */         ImmutableMap<K, V> map()
/* 214:    */         {
/* 215:378 */           return ImmutableMap.IteratorBasedImmutableMap.this;
/* 216:    */         }
/* 217:    */         
/* 218:    */         public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/* 219:    */         {
/* 220:383 */           return ImmutableMap.IteratorBasedImmutableMap.this.entryIterator();
/* 221:    */         }
/* 222:    */       };
/* 223:    */     }
/* 224:    */   }
/* 225:    */   
/* 226:    */   @Deprecated
/* 227:    */   public final V put(K k, V v)
/* 228:    */   {
/* 229:401 */     throw new UnsupportedOperationException();
/* 230:    */   }
/* 231:    */   
/* 232:    */   @Deprecated
/* 233:    */   public final V remove(Object o)
/* 234:    */   {
/* 235:413 */     throw new UnsupportedOperationException();
/* 236:    */   }
/* 237:    */   
/* 238:    */   @Deprecated
/* 239:    */   public final void putAll(Map<? extends K, ? extends V> map)
/* 240:    */   {
/* 241:425 */     throw new UnsupportedOperationException();
/* 242:    */   }
/* 243:    */   
/* 244:    */   @Deprecated
/* 245:    */   public final void clear()
/* 246:    */   {
/* 247:437 */     throw new UnsupportedOperationException();
/* 248:    */   }
/* 249:    */   
/* 250:    */   public boolean isEmpty()
/* 251:    */   {
/* 252:442 */     return size() == 0;
/* 253:    */   }
/* 254:    */   
/* 255:    */   public boolean containsKey(@Nullable Object key)
/* 256:    */   {
/* 257:447 */     return get(key) != null;
/* 258:    */   }
/* 259:    */   
/* 260:    */   public boolean containsValue(@Nullable Object value)
/* 261:    */   {
/* 262:452 */     return values().contains(value);
/* 263:    */   }
/* 264:    */   
/* 265:    */   public abstract V get(@Nullable Object paramObject);
/* 266:    */   
/* 267:    */   public ImmutableSet<Map.Entry<K, V>> entrySet()
/* 268:    */   {
/* 269:467 */     ImmutableSet<Map.Entry<K, V>> result = this.entrySet;
/* 270:468 */     return result == null ? (this.entrySet = createEntrySet()) : result;
/* 271:    */   }
/* 272:    */   
/* 273:    */   abstract ImmutableSet<Map.Entry<K, V>> createEntrySet();
/* 274:    */   
/* 275:    */   public ImmutableSet<K> keySet()
/* 276:    */   {
/* 277:481 */     ImmutableSet<K> result = this.keySet;
/* 278:482 */     return result == null ? (this.keySet = createKeySet()) : result;
/* 279:    */   }
/* 280:    */   
/* 281:    */   ImmutableSet<K> createKeySet()
/* 282:    */   {
/* 283:486 */     return isEmpty() ? ImmutableSet.of() : new ImmutableMapKeySet(this);
/* 284:    */   }
/* 285:    */   
/* 286:    */   UnmodifiableIterator<K> keyIterator()
/* 287:    */   {
/* 288:490 */     final UnmodifiableIterator<Map.Entry<K, V>> entryIterator = entrySet().iterator();
/* 289:491 */     new UnmodifiableIterator()
/* 290:    */     {
/* 291:    */       public boolean hasNext()
/* 292:    */       {
/* 293:494 */         return entryIterator.hasNext();
/* 294:    */       }
/* 295:    */       
/* 296:    */       public K next()
/* 297:    */       {
/* 298:499 */         return ((Map.Entry)entryIterator.next()).getKey();
/* 299:    */       }
/* 300:    */     };
/* 301:    */   }
/* 302:    */   
/* 303:    */   public ImmutableCollection<V> values()
/* 304:    */   {
/* 305:512 */     ImmutableCollection<V> result = this.values;
/* 306:513 */     return result == null ? (this.values = new ImmutableMapValues(this)) : result;
/* 307:    */   }
/* 308:    */   
/* 309:    */   @Beta
/* 310:    */   public ImmutableSetMultimap<K, V> asMultimap()
/* 311:    */   {
/* 312:526 */     if (isEmpty()) {
/* 313:527 */       return ImmutableSetMultimap.of();
/* 314:    */     }
/* 315:529 */     ImmutableSetMultimap<K, V> result = this.multimapView;
/* 316:530 */     return result == null ? (this.multimapView = new ImmutableSetMultimap(new MapViewOfValuesAsSingletonSets(null), size(), null)) : result;
/* 317:    */   }
/* 318:    */   
/* 319:    */   private final class MapViewOfValuesAsSingletonSets
/* 320:    */     extends ImmutableMap.IteratorBasedImmutableMap<K, ImmutableSet<V>>
/* 321:    */   {
/* 322:    */     private MapViewOfValuesAsSingletonSets() {}
/* 323:    */     
/* 324:    */     public int size()
/* 325:    */     {
/* 326:542 */       return ImmutableMap.this.size();
/* 327:    */     }
/* 328:    */     
/* 329:    */     public ImmutableSet<K> keySet()
/* 330:    */     {
/* 331:547 */       return ImmutableMap.this.keySet();
/* 332:    */     }
/* 333:    */     
/* 334:    */     public boolean containsKey(@Nullable Object key)
/* 335:    */     {
/* 336:552 */       return ImmutableMap.this.containsKey(key);
/* 337:    */     }
/* 338:    */     
/* 339:    */     public ImmutableSet<V> get(@Nullable Object key)
/* 340:    */     {
/* 341:557 */       V outerValue = ImmutableMap.this.get(key);
/* 342:558 */       return outerValue == null ? null : ImmutableSet.of(outerValue);
/* 343:    */     }
/* 344:    */     
/* 345:    */     boolean isPartialView()
/* 346:    */     {
/* 347:563 */       return ImmutableMap.this.isPartialView();
/* 348:    */     }
/* 349:    */     
/* 350:    */     public int hashCode()
/* 351:    */     {
/* 352:569 */       return ImmutableMap.this.hashCode();
/* 353:    */     }
/* 354:    */     
/* 355:    */     boolean isHashCodeFast()
/* 356:    */     {
/* 357:574 */       return ImmutableMap.this.isHashCodeFast();
/* 358:    */     }
/* 359:    */     
/* 360:    */     UnmodifiableIterator<Map.Entry<K, ImmutableSet<V>>> entryIterator()
/* 361:    */     {
/* 362:579 */       final Iterator<Map.Entry<K, V>> backingIterator = ImmutableMap.this.entrySet().iterator();
/* 363:580 */       new UnmodifiableIterator()
/* 364:    */       {
/* 365:    */         public boolean hasNext()
/* 366:    */         {
/* 367:583 */           return backingIterator.hasNext();
/* 368:    */         }
/* 369:    */         
/* 370:    */         public Map.Entry<K, ImmutableSet<V>> next()
/* 371:    */         {
/* 372:588 */           final Map.Entry<K, V> backingEntry = (Map.Entry)backingIterator.next();
/* 373:589 */           new AbstractMapEntry()
/* 374:    */           {
/* 375:    */             public K getKey()
/* 376:    */             {
/* 377:592 */               return backingEntry.getKey();
/* 378:    */             }
/* 379:    */             
/* 380:    */             public ImmutableSet<V> getValue()
/* 381:    */             {
/* 382:597 */               return ImmutableSet.of(backingEntry.getValue());
/* 383:    */             }
/* 384:    */           };
/* 385:    */         }
/* 386:    */       };
/* 387:    */     }
/* 388:    */   }
/* 389:    */   
/* 390:    */   public boolean equals(@Nullable Object object)
/* 391:    */   {
/* 392:607 */     return Maps.equalsImpl(this, object);
/* 393:    */   }
/* 394:    */   
/* 395:    */   abstract boolean isPartialView();
/* 396:    */   
/* 397:    */   public int hashCode()
/* 398:    */   {
/* 399:614 */     return Sets.hashCodeImpl(entrySet());
/* 400:    */   }
/* 401:    */   
/* 402:    */   boolean isHashCodeFast()
/* 403:    */   {
/* 404:618 */     return false;
/* 405:    */   }
/* 406:    */   
/* 407:    */   public String toString()
/* 408:    */   {
/* 409:623 */     return Maps.toStringImpl(this);
/* 410:    */   }
/* 411:    */   
/* 412:    */   static class SerializedForm
/* 413:    */     implements Serializable
/* 414:    */   {
/* 415:    */     private final Object[] keys;
/* 416:    */     private final Object[] values;
/* 417:    */     private static final long serialVersionUID = 0L;
/* 418:    */     
/* 419:    */     SerializedForm(ImmutableMap<?, ?> map)
/* 420:    */     {
/* 421:636 */       this.keys = new Object[map.size()];
/* 422:637 */       this.values = new Object[map.size()];
/* 423:638 */       int i = 0;
/* 424:639 */       for (Map.Entry<?, ?> entry : map.entrySet())
/* 425:    */       {
/* 426:640 */         this.keys[i] = entry.getKey();
/* 427:641 */         this.values[i] = entry.getValue();
/* 428:642 */         i++;
/* 429:    */       }
/* 430:    */     }
/* 431:    */     
/* 432:    */     Object readResolve()
/* 433:    */     {
/* 434:647 */       ImmutableMap.Builder<Object, Object> builder = new ImmutableMap.Builder(this.keys.length);
/* 435:648 */       return createMap(builder);
/* 436:    */     }
/* 437:    */     
/* 438:    */     Object createMap(ImmutableMap.Builder<Object, Object> builder)
/* 439:    */     {
/* 440:652 */       for (int i = 0; i < this.keys.length; i++) {
/* 441:653 */         builder.put(this.keys[i], this.values[i]);
/* 442:    */       }
/* 443:655 */       return builder.build();
/* 444:    */     }
/* 445:    */   }
/* 446:    */   
/* 447:    */   Object writeReplace()
/* 448:    */   {
/* 449:662 */     return new SerializedForm(this);
/* 450:    */   }
/* 451:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableMap
 * JD-Core Version:    0.7.0.1
 */