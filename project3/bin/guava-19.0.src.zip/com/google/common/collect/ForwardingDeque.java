/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import java.util.Deque;
/*   4:    */ import java.util.Iterator;
/*   5:    */ 
/*   6:    */ public abstract class ForwardingDeque<E>
/*   7:    */   extends ForwardingQueue<E>
/*   8:    */   implements Deque<E>
/*   9:    */ {
/*  10:    */   protected abstract Deque<E> delegate();
/*  11:    */   
/*  12:    */   public void addFirst(E e)
/*  13:    */   {
/*  14: 47 */     delegate().addFirst(e);
/*  15:    */   }
/*  16:    */   
/*  17:    */   public void addLast(E e)
/*  18:    */   {
/*  19: 52 */     delegate().addLast(e);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public Iterator<E> descendingIterator()
/*  23:    */   {
/*  24: 57 */     return delegate().descendingIterator();
/*  25:    */   }
/*  26:    */   
/*  27:    */   public E getFirst()
/*  28:    */   {
/*  29: 62 */     return delegate().getFirst();
/*  30:    */   }
/*  31:    */   
/*  32:    */   public E getLast()
/*  33:    */   {
/*  34: 67 */     return delegate().getLast();
/*  35:    */   }
/*  36:    */   
/*  37:    */   public boolean offerFirst(E e)
/*  38:    */   {
/*  39: 72 */     return delegate().offerFirst(e);
/*  40:    */   }
/*  41:    */   
/*  42:    */   public boolean offerLast(E e)
/*  43:    */   {
/*  44: 77 */     return delegate().offerLast(e);
/*  45:    */   }
/*  46:    */   
/*  47:    */   public E peekFirst()
/*  48:    */   {
/*  49: 82 */     return delegate().peekFirst();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public E peekLast()
/*  53:    */   {
/*  54: 87 */     return delegate().peekLast();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public E pollFirst()
/*  58:    */   {
/*  59: 92 */     return delegate().pollFirst();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public E pollLast()
/*  63:    */   {
/*  64: 97 */     return delegate().pollLast();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public E pop()
/*  68:    */   {
/*  69:102 */     return delegate().pop();
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void push(E e)
/*  73:    */   {
/*  74:107 */     delegate().push(e);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public E removeFirst()
/*  78:    */   {
/*  79:112 */     return delegate().removeFirst();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public E removeLast()
/*  83:    */   {
/*  84:117 */     return delegate().removeLast();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public boolean removeFirstOccurrence(Object o)
/*  88:    */   {
/*  89:122 */     return delegate().removeFirstOccurrence(o);
/*  90:    */   }
/*  91:    */   
/*  92:    */   public boolean removeLastOccurrence(Object o)
/*  93:    */   {
/*  94:127 */     return delegate().removeLastOccurrence(o);
/*  95:    */   }
/*  96:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingDeque
 * JD-Core Version:    0.7.0.1
 */