/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.math.IntMath;
/*   7:    */ import com.google.common.primitives.Ints;
/*   8:    */ import java.io.IOException;
/*   9:    */ import java.io.ObjectInputStream;
/*  10:    */ import java.io.ObjectOutputStream;
/*  11:    */ import java.io.Serializable;
/*  12:    */ import java.util.Collection;
/*  13:    */ import java.util.Iterator;
/*  14:    */ import java.util.List;
/*  15:    */ import java.util.Map.Entry;
/*  16:    */ import java.util.Set;
/*  17:    */ import java.util.concurrent.ConcurrentHashMap;
/*  18:    */ import java.util.concurrent.ConcurrentMap;
/*  19:    */ import java.util.concurrent.atomic.AtomicInteger;
/*  20:    */ import javax.annotation.Nullable;
/*  21:    */ 
/*  22:    */ public final class ConcurrentHashMultiset<E>
/*  23:    */   extends AbstractMultiset<E>
/*  24:    */   implements Serializable
/*  25:    */ {
/*  26:    */   private final transient ConcurrentMap<E, AtomicInteger> countMap;
/*  27:    */   private static final long serialVersionUID = 1L;
/*  28:    */   
/*  29:    */   private static class FieldSettersHolder
/*  30:    */   {
/*  31: 76 */     static final Serialization.FieldSetter<ConcurrentHashMultiset> COUNT_MAP_FIELD_SETTER = Serialization.getFieldSetter(ConcurrentHashMultiset.class, "countMap");
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <E> ConcurrentHashMultiset<E> create()
/*  35:    */   {
/*  36: 88 */     return new ConcurrentHashMultiset(new ConcurrentHashMap());
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static <E> ConcurrentHashMultiset<E> create(Iterable<? extends E> elements)
/*  40:    */   {
/*  41:100 */     ConcurrentHashMultiset<E> multiset = create();
/*  42:101 */     Iterables.addAll(multiset, elements);
/*  43:102 */     return multiset;
/*  44:    */   }
/*  45:    */   
/*  46:    */   @Beta
/*  47:    */   public static <E> ConcurrentHashMultiset<E> create(MapMaker mapMaker)
/*  48:    */   {
/*  49:128 */     return new ConcurrentHashMultiset(mapMaker.makeMap());
/*  50:    */   }
/*  51:    */   
/*  52:    */   @VisibleForTesting
/*  53:    */   ConcurrentHashMultiset(ConcurrentMap<E, AtomicInteger> countMap)
/*  54:    */   {
/*  55:143 */     Preconditions.checkArgument(countMap.isEmpty());
/*  56:144 */     this.countMap = countMap;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public int count(@Nullable Object element)
/*  60:    */   {
/*  61:157 */     AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/*  62:158 */     return existingCounter == null ? 0 : existingCounter.get();
/*  63:    */   }
/*  64:    */   
/*  65:    */   public int size()
/*  66:    */   {
/*  67:169 */     long sum = 0L;
/*  68:170 */     for (AtomicInteger value : this.countMap.values()) {
/*  69:171 */       sum += value.get();
/*  70:    */     }
/*  71:173 */     return Ints.saturatedCast(sum);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public Object[] toArray()
/*  75:    */   {
/*  76:183 */     return snapshot().toArray();
/*  77:    */   }
/*  78:    */   
/*  79:    */   public <T> T[] toArray(T[] array)
/*  80:    */   {
/*  81:188 */     return snapshot().toArray(array);
/*  82:    */   }
/*  83:    */   
/*  84:    */   private List<E> snapshot()
/*  85:    */   {
/*  86:196 */     List<E> list = Lists.newArrayListWithExpectedSize(size());
/*  87:197 */     for (Multiset.Entry<E> entry : entrySet())
/*  88:    */     {
/*  89:198 */       E element = entry.getElement();
/*  90:199 */       for (int i = entry.getCount(); i > 0; i--) {
/*  91:200 */         list.add(element);
/*  92:    */       }
/*  93:    */     }
/*  94:203 */     return list;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public int add(E element, int occurrences)
/*  98:    */   {
/*  99:219 */     Preconditions.checkNotNull(element);
/* 100:220 */     if (occurrences == 0) {
/* 101:221 */       return count(element);
/* 102:    */     }
/* 103:223 */     CollectPreconditions.checkPositive(occurrences, "occurences");
/* 104:    */     for (;;)
/* 105:    */     {
/* 106:226 */       AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 107:227 */       if (existingCounter == null)
/* 108:    */       {
/* 109:228 */         existingCounter = (AtomicInteger)this.countMap.putIfAbsent(element, new AtomicInteger(occurrences));
/* 110:229 */         if (existingCounter == null) {
/* 111:230 */           return 0;
/* 112:    */         }
/* 113:    */       }
/* 114:    */       for (;;)
/* 115:    */       {
/* 116:236 */         int oldValue = existingCounter.get();
/* 117:237 */         if (oldValue != 0)
/* 118:    */         {
/* 119:    */           try
/* 120:    */           {
/* 121:239 */             int newValue = IntMath.checkedAdd(oldValue, occurrences);
/* 122:240 */             if (existingCounter.compareAndSet(oldValue, newValue)) {
/* 123:242 */               return oldValue;
/* 124:    */             }
/* 125:    */           }
/* 126:    */           catch (ArithmeticException overflow)
/* 127:    */           {
/* 128:245 */             throw new IllegalArgumentException("Overflow adding " + occurrences + " occurrences to a count of " + oldValue);
/* 129:    */           }
/* 130:    */         }
/* 131:    */         else
/* 132:    */         {
/* 133:252 */           AtomicInteger newCounter = new AtomicInteger(occurrences);
/* 134:253 */           if ((this.countMap.putIfAbsent(element, newCounter) != null) && (!this.countMap.replace(element, existingCounter, newCounter))) {
/* 135:    */             break;
/* 136:    */           }
/* 137:255 */           return 0;
/* 138:    */         }
/* 139:    */       }
/* 140:    */     }
/* 141:    */   }
/* 142:    */   
/* 143:    */   public int remove(@Nullable Object element, int occurrences)
/* 144:    */   {
/* 145:285 */     if (occurrences == 0) {
/* 146:286 */       return count(element);
/* 147:    */     }
/* 148:288 */     CollectPreconditions.checkPositive(occurrences, "occurences");
/* 149:    */     
/* 150:290 */     AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 151:291 */     if (existingCounter == null) {
/* 152:292 */       return 0;
/* 153:    */     }
/* 154:    */     for (;;)
/* 155:    */     {
/* 156:295 */       int oldValue = existingCounter.get();
/* 157:296 */       if (oldValue != 0)
/* 158:    */       {
/* 159:297 */         int newValue = Math.max(0, oldValue - occurrences);
/* 160:298 */         if (existingCounter.compareAndSet(oldValue, newValue))
/* 161:    */         {
/* 162:299 */           if (newValue == 0) {
/* 163:302 */             this.countMap.remove(element, existingCounter);
/* 164:    */           }
/* 165:304 */           return oldValue;
/* 166:    */         }
/* 167:    */       }
/* 168:    */       else
/* 169:    */       {
/* 170:307 */         return 0;
/* 171:    */       }
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   public boolean removeExactly(@Nullable Object element, int occurrences)
/* 176:    */   {
/* 177:325 */     if (occurrences == 0) {
/* 178:326 */       return true;
/* 179:    */     }
/* 180:328 */     CollectPreconditions.checkPositive(occurrences, "occurences");
/* 181:    */     
/* 182:330 */     AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 183:331 */     if (existingCounter == null) {
/* 184:332 */       return false;
/* 185:    */     }
/* 186:    */     for (;;)
/* 187:    */     {
/* 188:335 */       int oldValue = existingCounter.get();
/* 189:336 */       if (oldValue < occurrences) {
/* 190:337 */         return false;
/* 191:    */       }
/* 192:339 */       int newValue = oldValue - occurrences;
/* 193:340 */       if (existingCounter.compareAndSet(oldValue, newValue))
/* 194:    */       {
/* 195:341 */         if (newValue == 0) {
/* 196:344 */           this.countMap.remove(element, existingCounter);
/* 197:    */         }
/* 198:346 */         return true;
/* 199:    */       }
/* 200:    */     }
/* 201:    */   }
/* 202:    */   
/* 203:    */   public int setCount(E element, int count)
/* 204:    */   {
/* 205:360 */     Preconditions.checkNotNull(element);
/* 206:361 */     CollectPreconditions.checkNonnegative(count, "count");
/* 207:    */     for (;;)
/* 208:    */     {
/* 209:363 */       AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 210:364 */       if (existingCounter == null)
/* 211:    */       {
/* 212:365 */         if (count == 0) {
/* 213:366 */           return 0;
/* 214:    */         }
/* 215:368 */         existingCounter = (AtomicInteger)this.countMap.putIfAbsent(element, new AtomicInteger(count));
/* 216:369 */         if (existingCounter == null) {
/* 217:370 */           return 0;
/* 218:    */         }
/* 219:    */       }
/* 220:    */       for (;;)
/* 221:    */       {
/* 222:377 */         int oldValue = existingCounter.get();
/* 223:378 */         if (oldValue == 0)
/* 224:    */         {
/* 225:379 */           if (count == 0) {
/* 226:380 */             return 0;
/* 227:    */           }
/* 228:382 */           AtomicInteger newCounter = new AtomicInteger(count);
/* 229:383 */           if ((this.countMap.putIfAbsent(element, newCounter) == null) || (this.countMap.replace(element, existingCounter, newCounter))) {
/* 230:385 */             return 0;
/* 231:    */           }
/* 232:388 */           break;
/* 233:    */         }
/* 234:390 */         if (existingCounter.compareAndSet(oldValue, count))
/* 235:    */         {
/* 236:391 */           if (count == 0) {
/* 237:394 */             this.countMap.remove(element, existingCounter);
/* 238:    */           }
/* 239:396 */           return oldValue;
/* 240:    */         }
/* 241:    */       }
/* 242:    */     }
/* 243:    */   }
/* 244:    */   
/* 245:    */   public boolean setCount(E element, int expectedOldCount, int newCount)
/* 246:    */   {
/* 247:416 */     Preconditions.checkNotNull(element);
/* 248:417 */     CollectPreconditions.checkNonnegative(expectedOldCount, "oldCount");
/* 249:418 */     CollectPreconditions.checkNonnegative(newCount, "newCount");
/* 250:    */     
/* 251:420 */     AtomicInteger existingCounter = (AtomicInteger)Maps.safeGet(this.countMap, element);
/* 252:421 */     if (existingCounter == null)
/* 253:    */     {
/* 254:422 */       if (expectedOldCount != 0) {
/* 255:423 */         return false;
/* 256:    */       }
/* 257:424 */       if (newCount == 0) {
/* 258:425 */         return true;
/* 259:    */       }
/* 260:428 */       return this.countMap.putIfAbsent(element, new AtomicInteger(newCount)) == null;
/* 261:    */     }
/* 262:431 */     int oldValue = existingCounter.get();
/* 263:432 */     if (oldValue == expectedOldCount)
/* 264:    */     {
/* 265:433 */       if (oldValue == 0)
/* 266:    */       {
/* 267:434 */         if (newCount == 0)
/* 268:    */         {
/* 269:436 */           this.countMap.remove(element, existingCounter);
/* 270:437 */           return true;
/* 271:    */         }
/* 272:439 */         AtomicInteger newCounter = new AtomicInteger(newCount);
/* 273:440 */         return (this.countMap.putIfAbsent(element, newCounter) == null) || (this.countMap.replace(element, existingCounter, newCounter));
/* 274:    */       }
/* 275:444 */       if (existingCounter.compareAndSet(oldValue, newCount))
/* 276:    */       {
/* 277:445 */         if (newCount == 0) {
/* 278:448 */           this.countMap.remove(element, existingCounter);
/* 279:    */         }
/* 280:450 */         return true;
/* 281:    */       }
/* 282:    */     }
/* 283:454 */     return false;
/* 284:    */   }
/* 285:    */   
/* 286:    */   Set<E> createElementSet()
/* 287:    */   {
/* 288:461 */     final Set<E> delegate = this.countMap.keySet();
/* 289:462 */     new ForwardingSet()
/* 290:    */     {
/* 291:    */       protected Set<E> delegate()
/* 292:    */       {
/* 293:465 */         return delegate;
/* 294:    */       }
/* 295:    */       
/* 296:    */       public boolean contains(@Nullable Object object)
/* 297:    */       {
/* 298:470 */         return (object != null) && (Collections2.safeContains(delegate, object));
/* 299:    */       }
/* 300:    */       
/* 301:    */       public boolean containsAll(Collection<?> collection)
/* 302:    */       {
/* 303:475 */         return standardContainsAll(collection);
/* 304:    */       }
/* 305:    */       
/* 306:    */       public boolean remove(Object object)
/* 307:    */       {
/* 308:480 */         return (object != null) && (Collections2.safeRemove(delegate, object));
/* 309:    */       }
/* 310:    */       
/* 311:    */       public boolean removeAll(Collection<?> c)
/* 312:    */       {
/* 313:485 */         return standardRemoveAll(c);
/* 314:    */       }
/* 315:    */     };
/* 316:    */   }
/* 317:    */   
/* 318:    */   public Set<Multiset.Entry<E>> createEntrySet()
/* 319:    */   {
/* 320:492 */     return new EntrySet(null);
/* 321:    */   }
/* 322:    */   
/* 323:    */   int distinctElements()
/* 324:    */   {
/* 325:497 */     return this.countMap.size();
/* 326:    */   }
/* 327:    */   
/* 328:    */   public boolean isEmpty()
/* 329:    */   {
/* 330:502 */     return this.countMap.isEmpty();
/* 331:    */   }
/* 332:    */   
/* 333:    */   Iterator<Multiset.Entry<E>> entryIterator()
/* 334:    */   {
/* 335:509 */     final Iterator<Multiset.Entry<E>> readOnlyIterator = new AbstractIterator()
/* 336:    */     {
/* 337:511 */       private Iterator<Map.Entry<E, AtomicInteger>> mapEntries = ConcurrentHashMultiset.this.countMap.entrySet().iterator();
/* 338:    */       
/* 339:    */       protected Multiset.Entry<E> computeNext()
/* 340:    */       {
/* 341:    */         for (;;)
/* 342:    */         {
/* 343:516 */           if (!this.mapEntries.hasNext()) {
/* 344:517 */             return (Multiset.Entry)endOfData();
/* 345:    */           }
/* 346:519 */           Map.Entry<E, AtomicInteger> mapEntry = (Map.Entry)this.mapEntries.next();
/* 347:520 */           int count = ((AtomicInteger)mapEntry.getValue()).get();
/* 348:521 */           if (count != 0) {
/* 349:522 */             return Multisets.immutableEntry(mapEntry.getKey(), count);
/* 350:    */           }
/* 351:    */         }
/* 352:    */       }
/* 353:527 */     };
/* 354:528 */     new ForwardingIterator()
/* 355:    */     {
/* 356:    */       private Multiset.Entry<E> last;
/* 357:    */       
/* 358:    */       protected Iterator<Multiset.Entry<E>> delegate()
/* 359:    */       {
/* 360:533 */         return readOnlyIterator;
/* 361:    */       }
/* 362:    */       
/* 363:    */       public Multiset.Entry<E> next()
/* 364:    */       {
/* 365:538 */         this.last = ((Multiset.Entry)super.next());
/* 366:539 */         return this.last;
/* 367:    */       }
/* 368:    */       
/* 369:    */       public void remove()
/* 370:    */       {
/* 371:544 */         CollectPreconditions.checkRemove(this.last != null);
/* 372:545 */         ConcurrentHashMultiset.this.setCount(this.last.getElement(), 0);
/* 373:546 */         this.last = null;
/* 374:    */       }
/* 375:    */     };
/* 376:    */   }
/* 377:    */   
/* 378:    */   public void clear()
/* 379:    */   {
/* 380:553 */     this.countMap.clear();
/* 381:    */   }
/* 382:    */   
/* 383:    */   private class EntrySet
/* 384:    */     extends AbstractMultiset<E>.EntrySet
/* 385:    */   {
/* 386:    */     private EntrySet()
/* 387:    */     {
/* 388:557 */       super();
/* 389:    */     }
/* 390:    */     
/* 391:    */     ConcurrentHashMultiset<E> multiset()
/* 392:    */     {
/* 393:560 */       return ConcurrentHashMultiset.this;
/* 394:    */     }
/* 395:    */     
/* 396:    */     public Object[] toArray()
/* 397:    */     {
/* 398:570 */       return snapshot().toArray();
/* 399:    */     }
/* 400:    */     
/* 401:    */     public <T> T[] toArray(T[] array)
/* 402:    */     {
/* 403:575 */       return snapshot().toArray(array);
/* 404:    */     }
/* 405:    */     
/* 406:    */     private List<Multiset.Entry<E>> snapshot()
/* 407:    */     {
/* 408:579 */       List<Multiset.Entry<E>> list = Lists.newArrayListWithExpectedSize(size());
/* 409:    */       
/* 410:581 */       Iterators.addAll(list, iterator());
/* 411:582 */       return list;
/* 412:    */     }
/* 413:    */   }
/* 414:    */   
/* 415:    */   private void writeObject(ObjectOutputStream stream)
/* 416:    */     throws IOException
/* 417:    */   {
/* 418:590 */     stream.defaultWriteObject();
/* 419:591 */     stream.writeObject(this.countMap);
/* 420:    */   }
/* 421:    */   
/* 422:    */   private void readObject(ObjectInputStream stream)
/* 423:    */     throws IOException, ClassNotFoundException
/* 424:    */   {
/* 425:595 */     stream.defaultReadObject();
/* 426:    */     
/* 427:597 */     ConcurrentMap<E, Integer> deserializedCountMap = (ConcurrentMap)stream.readObject();
/* 428:    */     
/* 429:599 */     FieldSettersHolder.COUNT_MAP_FIELD_SETTER.set(this, deserializedCountMap);
/* 430:    */   }
/* 431:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ConcurrentHashMultiset
 * JD-Core Version:    0.7.0.1
 */