/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import javax.annotation.Nullable;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ final class Hashing
/*  8:   */ {
/*  9:   */   private static final int C1 = -862048943;
/* 10:   */   private static final int C2 = 461845907;
/* 11:   */   
/* 12:   */   static int smear(int hashCode)
/* 13:   */   {
/* 14:47 */     return 461845907 * Integer.rotateLeft(hashCode * -862048943, 15);
/* 15:   */   }
/* 16:   */   
/* 17:   */   static int smearedHash(@Nullable Object o)
/* 18:   */   {
/* 19:51 */     return smear(o == null ? 0 : o.hashCode());
/* 20:   */   }
/* 21:   */   
/* 22:54 */   private static int MAX_TABLE_SIZE = 1073741824;
/* 23:   */   
/* 24:   */   static int closedTableSize(int expectedEntries, double loadFactor)
/* 25:   */   {
/* 26:59 */     expectedEntries = Math.max(expectedEntries, 2);
/* 27:60 */     int tableSize = Integer.highestOneBit(expectedEntries);
/* 28:62 */     if (expectedEntries > (int)(loadFactor * tableSize))
/* 29:   */     {
/* 30:63 */       tableSize <<= 1;
/* 31:64 */       return tableSize > 0 ? tableSize : MAX_TABLE_SIZE;
/* 32:   */     }
/* 33:66 */     return tableSize;
/* 34:   */   }
/* 35:   */   
/* 36:   */   static boolean needsResizing(int size, int tableSize, double loadFactor)
/* 37:   */   {
/* 38:70 */     return (size > loadFactor * tableSize) && (tableSize < MAX_TABLE_SIZE);
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Hashing
 * JD-Core Version:    0.7.0.1
 */