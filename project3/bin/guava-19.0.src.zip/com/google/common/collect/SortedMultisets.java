/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.j2objc.annotations.Weak;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.NavigableSet;
/*   9:    */ import java.util.NoSuchElementException;
/*  10:    */ import java.util.SortedSet;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ 
/*  13:    */ @GwtCompatible(emulated=true)
/*  14:    */ final class SortedMultisets
/*  15:    */ {
/*  16:    */   static class ElementSet<E>
/*  17:    */     extends Multisets.ElementSet<E>
/*  18:    */     implements SortedSet<E>
/*  19:    */   {
/*  20:    */     @Weak
/*  21:    */     private final SortedMultiset<E> multiset;
/*  22:    */     
/*  23:    */     ElementSet(SortedMultiset<E> multiset)
/*  24:    */     {
/*  25: 52 */       this.multiset = multiset;
/*  26:    */     }
/*  27:    */     
/*  28:    */     final SortedMultiset<E> multiset()
/*  29:    */     {
/*  30: 57 */       return this.multiset;
/*  31:    */     }
/*  32:    */     
/*  33:    */     public Comparator<? super E> comparator()
/*  34:    */     {
/*  35: 62 */       return multiset().comparator();
/*  36:    */     }
/*  37:    */     
/*  38:    */     public SortedSet<E> subSet(E fromElement, E toElement)
/*  39:    */     {
/*  40: 67 */       return multiset().subMultiset(fromElement, BoundType.CLOSED, toElement, BoundType.OPEN).elementSet();
/*  41:    */     }
/*  42:    */     
/*  43:    */     public SortedSet<E> headSet(E toElement)
/*  44:    */     {
/*  45: 72 */       return multiset().headMultiset(toElement, BoundType.OPEN).elementSet();
/*  46:    */     }
/*  47:    */     
/*  48:    */     public SortedSet<E> tailSet(E fromElement)
/*  49:    */     {
/*  50: 77 */       return multiset().tailMultiset(fromElement, BoundType.CLOSED).elementSet();
/*  51:    */     }
/*  52:    */     
/*  53:    */     public E first()
/*  54:    */     {
/*  55: 82 */       return SortedMultisets.getElementOrThrow(multiset().firstEntry());
/*  56:    */     }
/*  57:    */     
/*  58:    */     public E last()
/*  59:    */     {
/*  60: 87 */       return SortedMultisets.getElementOrThrow(multiset().lastEntry());
/*  61:    */     }
/*  62:    */   }
/*  63:    */   
/*  64:    */   @GwtIncompatible("Navigable")
/*  65:    */   static class NavigableElementSet<E>
/*  66:    */     extends SortedMultisets.ElementSet<E>
/*  67:    */     implements NavigableSet<E>
/*  68:    */   {
/*  69:    */     NavigableElementSet(SortedMultiset<E> multiset)
/*  70:    */     {
/*  71: 97 */       super();
/*  72:    */     }
/*  73:    */     
/*  74:    */     public E lower(E e)
/*  75:    */     {
/*  76:102 */       return SortedMultisets.getElementOrNull(multiset().headMultiset(e, BoundType.OPEN).lastEntry());
/*  77:    */     }
/*  78:    */     
/*  79:    */     public E floor(E e)
/*  80:    */     {
/*  81:107 */       return SortedMultisets.getElementOrNull(multiset().headMultiset(e, BoundType.CLOSED).lastEntry());
/*  82:    */     }
/*  83:    */     
/*  84:    */     public E ceiling(E e)
/*  85:    */     {
/*  86:112 */       return SortedMultisets.getElementOrNull(multiset().tailMultiset(e, BoundType.CLOSED).firstEntry());
/*  87:    */     }
/*  88:    */     
/*  89:    */     public E higher(E e)
/*  90:    */     {
/*  91:117 */       return SortedMultisets.getElementOrNull(multiset().tailMultiset(e, BoundType.OPEN).firstEntry());
/*  92:    */     }
/*  93:    */     
/*  94:    */     public NavigableSet<E> descendingSet()
/*  95:    */     {
/*  96:122 */       return new NavigableElementSet(multiset().descendingMultiset());
/*  97:    */     }
/*  98:    */     
/*  99:    */     public Iterator<E> descendingIterator()
/* 100:    */     {
/* 101:127 */       return descendingSet().iterator();
/* 102:    */     }
/* 103:    */     
/* 104:    */     public E pollFirst()
/* 105:    */     {
/* 106:132 */       return SortedMultisets.getElementOrNull(multiset().pollFirstEntry());
/* 107:    */     }
/* 108:    */     
/* 109:    */     public E pollLast()
/* 110:    */     {
/* 111:137 */       return SortedMultisets.getElementOrNull(multiset().pollLastEntry());
/* 112:    */     }
/* 113:    */     
/* 114:    */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 115:    */     {
/* 116:143 */       return new NavigableElementSet(multiset().subMultiset(fromElement, BoundType.forBoolean(fromInclusive), toElement, BoundType.forBoolean(toInclusive)));
/* 117:    */     }
/* 118:    */     
/* 119:    */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/* 120:    */     {
/* 121:151 */       return new NavigableElementSet(multiset().headMultiset(toElement, BoundType.forBoolean(inclusive)));
/* 122:    */     }
/* 123:    */     
/* 124:    */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/* 125:    */     {
/* 126:157 */       return new NavigableElementSet(multiset().tailMultiset(fromElement, BoundType.forBoolean(inclusive)));
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static <E> E getElementOrThrow(Multiset.Entry<E> entry)
/* 131:    */   {
/* 132:163 */     if (entry == null) {
/* 133:164 */       throw new NoSuchElementException();
/* 134:    */     }
/* 135:166 */     return entry.getElement();
/* 136:    */   }
/* 137:    */   
/* 138:    */   private static <E> E getElementOrNull(@Nullable Multiset.Entry<E> entry)
/* 139:    */   {
/* 140:170 */     return entry == null ? null : entry.getElement();
/* 141:    */   }
/* 142:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.SortedMultisets
 * JD-Core Version:    0.7.0.1
 */