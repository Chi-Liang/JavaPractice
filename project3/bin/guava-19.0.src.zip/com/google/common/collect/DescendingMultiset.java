/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Comparator;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.NavigableSet;
/*   7:    */ import java.util.Set;
/*   8:    */ 
/*   9:    */ @GwtCompatible(emulated=true)
/*  10:    */ abstract class DescendingMultiset<E>
/*  11:    */   extends ForwardingMultiset<E>
/*  12:    */   implements SortedMultiset<E>
/*  13:    */ {
/*  14:    */   private transient Comparator<? super E> comparator;
/*  15:    */   private transient NavigableSet<E> elementSet;
/*  16:    */   private transient Set<Multiset.Entry<E>> entrySet;
/*  17:    */   
/*  18:    */   abstract SortedMultiset<E> forwardMultiset();
/*  19:    */   
/*  20:    */   public Comparator<? super E> comparator()
/*  21:    */   {
/*  22: 41 */     Comparator<? super E> result = this.comparator;
/*  23: 42 */     if (result == null) {
/*  24: 43 */       return this.comparator = Ordering.from(forwardMultiset().comparator()).reverse();
/*  25:    */     }
/*  26: 45 */     return result;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public NavigableSet<E> elementSet()
/*  30:    */   {
/*  31: 52 */     NavigableSet<E> result = this.elementSet;
/*  32: 53 */     if (result == null) {
/*  33: 54 */       return this.elementSet = new SortedMultisets.NavigableElementSet(this);
/*  34:    */     }
/*  35: 56 */     return result;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Multiset.Entry<E> pollFirstEntry()
/*  39:    */   {
/*  40: 61 */     return forwardMultiset().pollLastEntry();
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Multiset.Entry<E> pollLastEntry()
/*  44:    */   {
/*  45: 66 */     return forwardMultiset().pollFirstEntry();
/*  46:    */   }
/*  47:    */   
/*  48:    */   public SortedMultiset<E> headMultiset(E toElement, BoundType boundType)
/*  49:    */   {
/*  50: 71 */     return forwardMultiset().tailMultiset(toElement, boundType).descendingMultiset();
/*  51:    */   }
/*  52:    */   
/*  53:    */   public SortedMultiset<E> subMultiset(E fromElement, BoundType fromBoundType, E toElement, BoundType toBoundType)
/*  54:    */   {
/*  55: 77 */     return forwardMultiset().subMultiset(toElement, toBoundType, fromElement, fromBoundType).descendingMultiset();
/*  56:    */   }
/*  57:    */   
/*  58:    */   public SortedMultiset<E> tailMultiset(E fromElement, BoundType boundType)
/*  59:    */   {
/*  60: 84 */     return forwardMultiset().headMultiset(fromElement, boundType).descendingMultiset();
/*  61:    */   }
/*  62:    */   
/*  63:    */   protected Multiset<E> delegate()
/*  64:    */   {
/*  65: 89 */     return forwardMultiset();
/*  66:    */   }
/*  67:    */   
/*  68:    */   public SortedMultiset<E> descendingMultiset()
/*  69:    */   {
/*  70: 94 */     return forwardMultiset();
/*  71:    */   }
/*  72:    */   
/*  73:    */   public Multiset.Entry<E> firstEntry()
/*  74:    */   {
/*  75: 99 */     return forwardMultiset().lastEntry();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public Multiset.Entry<E> lastEntry()
/*  79:    */   {
/*  80:104 */     return forwardMultiset().firstEntry();
/*  81:    */   }
/*  82:    */   
/*  83:    */   abstract Iterator<Multiset.Entry<E>> entryIterator();
/*  84:    */   
/*  85:    */   public Set<Multiset.Entry<E>> entrySet()
/*  86:    */   {
/*  87:113 */     Set<Multiset.Entry<E>> result = this.entrySet;
/*  88:114 */     return result == null ? (this.entrySet = createEntrySet()) : result;
/*  89:    */   }
/*  90:    */   
/*  91:    */   Set<Multiset.Entry<E>> createEntrySet()
/*  92:    */   {
/*  93:135 */     new Multisets.EntrySet()
/*  94:    */     {
/*  95:    */       Multiset<E> multiset()
/*  96:    */       {
/*  97:122 */         return DescendingMultiset.this;
/*  98:    */       }
/*  99:    */       
/* 100:    */       public Iterator<Multiset.Entry<E>> iterator()
/* 101:    */       {
/* 102:127 */         return DescendingMultiset.this.entryIterator();
/* 103:    */       }
/* 104:    */       
/* 105:    */       public int size()
/* 106:    */       {
/* 107:132 */         return DescendingMultiset.this.forwardMultiset().entrySet().size();
/* 108:    */       }
/* 109:    */     };
/* 110:    */   }
/* 111:    */   
/* 112:    */   public Iterator<E> iterator()
/* 113:    */   {
/* 114:140 */     return Multisets.iteratorImpl(this);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public Object[] toArray()
/* 118:    */   {
/* 119:145 */     return standardToArray();
/* 120:    */   }
/* 121:    */   
/* 122:    */   public <T> T[] toArray(T[] array)
/* 123:    */   {
/* 124:150 */     return standardToArray(array);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public String toString()
/* 128:    */   {
/* 129:155 */     return entrySet().toString();
/* 130:    */   }
/* 131:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.DescendingMultiset
 * JD-Core Version:    0.7.0.1
 */