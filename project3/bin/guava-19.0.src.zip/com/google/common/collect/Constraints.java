/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Collection;
/*   6:    */ import java.util.List;
/*   7:    */ import java.util.ListIterator;
/*   8:    */ import java.util.RandomAccess;
/*   9:    */ import java.util.Set;
/*  10:    */ import java.util.SortedSet;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ final class Constraints
/*  14:    */ {
/*  15:    */   public static <E> Collection<E> constrainedCollection(Collection<E> collection, Constraint<? super E> constraint)
/*  16:    */   {
/*  17: 54 */     return new ConstrainedCollection(collection, constraint);
/*  18:    */   }
/*  19:    */   
/*  20:    */   static class ConstrainedCollection<E>
/*  21:    */     extends ForwardingCollection<E>
/*  22:    */   {
/*  23:    */     private final Collection<E> delegate;
/*  24:    */     private final Constraint<? super E> constraint;
/*  25:    */     
/*  26:    */     public ConstrainedCollection(Collection<E> delegate, Constraint<? super E> constraint)
/*  27:    */     {
/*  28: 63 */       this.delegate = ((Collection)Preconditions.checkNotNull(delegate));
/*  29: 64 */       this.constraint = ((Constraint)Preconditions.checkNotNull(constraint));
/*  30:    */     }
/*  31:    */     
/*  32:    */     protected Collection<E> delegate()
/*  33:    */     {
/*  34: 69 */       return this.delegate;
/*  35:    */     }
/*  36:    */     
/*  37:    */     public boolean add(E element)
/*  38:    */     {
/*  39: 74 */       this.constraint.checkElement(element);
/*  40: 75 */       return this.delegate.add(element);
/*  41:    */     }
/*  42:    */     
/*  43:    */     public boolean addAll(Collection<? extends E> elements)
/*  44:    */     {
/*  45: 80 */       return this.delegate.addAll(Constraints.checkElements(elements, this.constraint));
/*  46:    */     }
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static <E> Set<E> constrainedSet(Set<E> set, Constraint<? super E> constraint)
/*  50:    */   {
/*  51: 97 */     return new ConstrainedSet(set, constraint);
/*  52:    */   }
/*  53:    */   
/*  54:    */   static class ConstrainedSet<E>
/*  55:    */     extends ForwardingSet<E>
/*  56:    */   {
/*  57:    */     private final Set<E> delegate;
/*  58:    */     private final Constraint<? super E> constraint;
/*  59:    */     
/*  60:    */     public ConstrainedSet(Set<E> delegate, Constraint<? super E> constraint)
/*  61:    */     {
/*  62:106 */       this.delegate = ((Set)Preconditions.checkNotNull(delegate));
/*  63:107 */       this.constraint = ((Constraint)Preconditions.checkNotNull(constraint));
/*  64:    */     }
/*  65:    */     
/*  66:    */     protected Set<E> delegate()
/*  67:    */     {
/*  68:112 */       return this.delegate;
/*  69:    */     }
/*  70:    */     
/*  71:    */     public boolean add(E element)
/*  72:    */     {
/*  73:117 */       this.constraint.checkElement(element);
/*  74:118 */       return this.delegate.add(element);
/*  75:    */     }
/*  76:    */     
/*  77:    */     public boolean addAll(Collection<? extends E> elements)
/*  78:    */     {
/*  79:123 */       return this.delegate.addAll(Constraints.checkElements(elements, this.constraint));
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public static <E> SortedSet<E> constrainedSortedSet(SortedSet<E> sortedSet, Constraint<? super E> constraint)
/*  84:    */   {
/*  85:141 */     return new ConstrainedSortedSet(sortedSet, constraint);
/*  86:    */   }
/*  87:    */   
/*  88:    */   private static class ConstrainedSortedSet<E>
/*  89:    */     extends ForwardingSortedSet<E>
/*  90:    */   {
/*  91:    */     final SortedSet<E> delegate;
/*  92:    */     final Constraint<? super E> constraint;
/*  93:    */     
/*  94:    */     ConstrainedSortedSet(SortedSet<E> delegate, Constraint<? super E> constraint)
/*  95:    */     {
/*  96:150 */       this.delegate = ((SortedSet)Preconditions.checkNotNull(delegate));
/*  97:151 */       this.constraint = ((Constraint)Preconditions.checkNotNull(constraint));
/*  98:    */     }
/*  99:    */     
/* 100:    */     protected SortedSet<E> delegate()
/* 101:    */     {
/* 102:156 */       return this.delegate;
/* 103:    */     }
/* 104:    */     
/* 105:    */     public SortedSet<E> headSet(E toElement)
/* 106:    */     {
/* 107:161 */       return Constraints.constrainedSortedSet(this.delegate.headSet(toElement), this.constraint);
/* 108:    */     }
/* 109:    */     
/* 110:    */     public SortedSet<E> subSet(E fromElement, E toElement)
/* 111:    */     {
/* 112:166 */       return Constraints.constrainedSortedSet(this.delegate.subSet(fromElement, toElement), this.constraint);
/* 113:    */     }
/* 114:    */     
/* 115:    */     public SortedSet<E> tailSet(E fromElement)
/* 116:    */     {
/* 117:171 */       return Constraints.constrainedSortedSet(this.delegate.tailSet(fromElement), this.constraint);
/* 118:    */     }
/* 119:    */     
/* 120:    */     public boolean add(E element)
/* 121:    */     {
/* 122:176 */       this.constraint.checkElement(element);
/* 123:177 */       return this.delegate.add(element);
/* 124:    */     }
/* 125:    */     
/* 126:    */     public boolean addAll(Collection<? extends E> elements)
/* 127:    */     {
/* 128:182 */       return this.delegate.addAll(Constraints.checkElements(elements, this.constraint));
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   public static <E> List<E> constrainedList(List<E> list, Constraint<? super E> constraint)
/* 133:    */   {
/* 134:200 */     return (list instanceof RandomAccess) ? new ConstrainedRandomAccessList(list, constraint) : new ConstrainedList(list, constraint);
/* 135:    */   }
/* 136:    */   
/* 137:    */   @GwtCompatible
/* 138:    */   private static class ConstrainedList<E>
/* 139:    */     extends ForwardingList<E>
/* 140:    */   {
/* 141:    */     final List<E> delegate;
/* 142:    */     final Constraint<? super E> constraint;
/* 143:    */     
/* 144:    */     ConstrainedList(List<E> delegate, Constraint<? super E> constraint)
/* 145:    */     {
/* 146:212 */       this.delegate = ((List)Preconditions.checkNotNull(delegate));
/* 147:213 */       this.constraint = ((Constraint)Preconditions.checkNotNull(constraint));
/* 148:    */     }
/* 149:    */     
/* 150:    */     protected List<E> delegate()
/* 151:    */     {
/* 152:218 */       return this.delegate;
/* 153:    */     }
/* 154:    */     
/* 155:    */     public boolean add(E element)
/* 156:    */     {
/* 157:223 */       this.constraint.checkElement(element);
/* 158:224 */       return this.delegate.add(element);
/* 159:    */     }
/* 160:    */     
/* 161:    */     public void add(int index, E element)
/* 162:    */     {
/* 163:229 */       this.constraint.checkElement(element);
/* 164:230 */       this.delegate.add(index, element);
/* 165:    */     }
/* 166:    */     
/* 167:    */     public boolean addAll(Collection<? extends E> elements)
/* 168:    */     {
/* 169:235 */       return this.delegate.addAll(Constraints.checkElements(elements, this.constraint));
/* 170:    */     }
/* 171:    */     
/* 172:    */     public boolean addAll(int index, Collection<? extends E> elements)
/* 173:    */     {
/* 174:240 */       return this.delegate.addAll(index, Constraints.checkElements(elements, this.constraint));
/* 175:    */     }
/* 176:    */     
/* 177:    */     public ListIterator<E> listIterator()
/* 178:    */     {
/* 179:245 */       return Constraints.constrainedListIterator(this.delegate.listIterator(), this.constraint);
/* 180:    */     }
/* 181:    */     
/* 182:    */     public ListIterator<E> listIterator(int index)
/* 183:    */     {
/* 184:250 */       return Constraints.constrainedListIterator(this.delegate.listIterator(index), this.constraint);
/* 185:    */     }
/* 186:    */     
/* 187:    */     public E set(int index, E element)
/* 188:    */     {
/* 189:255 */       this.constraint.checkElement(element);
/* 190:256 */       return this.delegate.set(index, element);
/* 191:    */     }
/* 192:    */     
/* 193:    */     public List<E> subList(int fromIndex, int toIndex)
/* 194:    */     {
/* 195:261 */       return Constraints.constrainedList(this.delegate.subList(fromIndex, toIndex), this.constraint);
/* 196:    */     }
/* 197:    */   }
/* 198:    */   
/* 199:    */   static class ConstrainedRandomAccessList<E>
/* 200:    */     extends Constraints.ConstrainedList<E>
/* 201:    */     implements RandomAccess
/* 202:    */   {
/* 203:    */     ConstrainedRandomAccessList(List<E> delegate, Constraint<? super E> constraint)
/* 204:    */     {
/* 205:268 */       super(constraint);
/* 206:    */     }
/* 207:    */   }
/* 208:    */   
/* 209:    */   private static <E> ListIterator<E> constrainedListIterator(ListIterator<E> listIterator, Constraint<? super E> constraint)
/* 210:    */   {
/* 211:283 */     return new ConstrainedListIterator(listIterator, constraint);
/* 212:    */   }
/* 213:    */   
/* 214:    */   static class ConstrainedListIterator<E>
/* 215:    */     extends ForwardingListIterator<E>
/* 216:    */   {
/* 217:    */     private final ListIterator<E> delegate;
/* 218:    */     private final Constraint<? super E> constraint;
/* 219:    */     
/* 220:    */     public ConstrainedListIterator(ListIterator<E> delegate, Constraint<? super E> constraint)
/* 221:    */     {
/* 222:292 */       this.delegate = delegate;
/* 223:293 */       this.constraint = constraint;
/* 224:    */     }
/* 225:    */     
/* 226:    */     protected ListIterator<E> delegate()
/* 227:    */     {
/* 228:298 */       return this.delegate;
/* 229:    */     }
/* 230:    */     
/* 231:    */     public void add(E element)
/* 232:    */     {
/* 233:303 */       this.constraint.checkElement(element);
/* 234:304 */       this.delegate.add(element);
/* 235:    */     }
/* 236:    */     
/* 237:    */     public void set(E element)
/* 238:    */     {
/* 239:309 */       this.constraint.checkElement(element);
/* 240:310 */       this.delegate.set(element);
/* 241:    */     }
/* 242:    */   }
/* 243:    */   
/* 244:    */   static <E> Collection<E> constrainedTypePreservingCollection(Collection<E> collection, Constraint<E> constraint)
/* 245:    */   {
/* 246:316 */     if ((collection instanceof SortedSet)) {
/* 247:317 */       return constrainedSortedSet((SortedSet)collection, constraint);
/* 248:    */     }
/* 249:318 */     if ((collection instanceof Set)) {
/* 250:319 */       return constrainedSet((Set)collection, constraint);
/* 251:    */     }
/* 252:320 */     if ((collection instanceof List)) {
/* 253:321 */       return constrainedList((List)collection, constraint);
/* 254:    */     }
/* 255:323 */     return constrainedCollection(collection, constraint);
/* 256:    */   }
/* 257:    */   
/* 258:    */   private static <E> Collection<E> checkElements(Collection<E> elements, Constraint<? super E> constraint)
/* 259:    */   {
/* 260:334 */     Collection<E> copy = Lists.newArrayList(elements);
/* 261:335 */     for (E element : copy) {
/* 262:336 */       constraint.checkElement(element);
/* 263:    */     }
/* 264:338 */     return copy;
/* 265:    */   }
/* 266:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Constraints
 * JD-Core Version:    0.7.0.1
 */