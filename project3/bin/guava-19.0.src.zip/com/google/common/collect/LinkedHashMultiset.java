/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import java.io.IOException;
/*   6:    */ import java.io.ObjectInputStream;
/*   7:    */ import java.io.ObjectOutputStream;
/*   8:    */ import java.util.LinkedHashMap;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true, emulated=true)
/*  11:    */ public final class LinkedHashMultiset<E>
/*  12:    */   extends AbstractMapBasedMultiset<E>
/*  13:    */ {
/*  14:    */   @GwtIncompatible("not needed in emulated source")
/*  15:    */   private static final long serialVersionUID = 0L;
/*  16:    */   
/*  17:    */   public static <E> LinkedHashMultiset<E> create()
/*  18:    */   {
/*  19: 52 */     return new LinkedHashMultiset();
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static <E> LinkedHashMultiset<E> create(int distinctElements)
/*  23:    */   {
/*  24: 63 */     return new LinkedHashMultiset(distinctElements);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static <E> LinkedHashMultiset<E> create(Iterable<? extends E> elements)
/*  28:    */   {
/*  29: 75 */     LinkedHashMultiset<E> multiset = create(Multisets.inferDistinctElements(elements));
/*  30: 76 */     Iterables.addAll(multiset, elements);
/*  31: 77 */     return multiset;
/*  32:    */   }
/*  33:    */   
/*  34:    */   private LinkedHashMultiset()
/*  35:    */   {
/*  36: 81 */     super(new LinkedHashMap());
/*  37:    */   }
/*  38:    */   
/*  39:    */   private LinkedHashMultiset(int distinctElements)
/*  40:    */   {
/*  41: 85 */     super(Maps.newLinkedHashMapWithExpectedSize(distinctElements));
/*  42:    */   }
/*  43:    */   
/*  44:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  45:    */   private void writeObject(ObjectOutputStream stream)
/*  46:    */     throws IOException
/*  47:    */   {
/*  48: 94 */     stream.defaultWriteObject();
/*  49: 95 */     Serialization.writeMultiset(this, stream);
/*  50:    */   }
/*  51:    */   
/*  52:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  53:    */   private void readObject(ObjectInputStream stream)
/*  54:    */     throws IOException, ClassNotFoundException
/*  55:    */   {
/*  56:100 */     stream.defaultReadObject();
/*  57:101 */     int distinctElements = Serialization.readCount(stream);
/*  58:102 */     setBackingMap(new LinkedHashMap());
/*  59:103 */     Serialization.populateMultiset(this, stream, distinctElements);
/*  60:    */   }
/*  61:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.LinkedHashMultiset
 * JD-Core Version:    0.7.0.1
 */