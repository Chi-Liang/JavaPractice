/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.GwtCompatible;
/*    4:     */ import com.google.common.annotations.GwtIncompatible;
/*    5:     */ import com.google.common.annotations.VisibleForTesting;
/*    6:     */ import com.google.common.base.Preconditions;
/*    7:     */ import java.io.IOException;
/*    8:     */ import java.io.ObjectOutputStream;
/*    9:     */ import java.io.Serializable;
/*   10:     */ import java.util.Collection;
/*   11:     */ import java.util.Comparator;
/*   12:     */ import java.util.Deque;
/*   13:     */ import java.util.Iterator;
/*   14:     */ import java.util.List;
/*   15:     */ import java.util.ListIterator;
/*   16:     */ import java.util.Map;
/*   17:     */ import java.util.Map.Entry;
/*   18:     */ import java.util.NavigableMap;
/*   19:     */ import java.util.NavigableSet;
/*   20:     */ import java.util.Queue;
/*   21:     */ import java.util.RandomAccess;
/*   22:     */ import java.util.Set;
/*   23:     */ import java.util.SortedMap;
/*   24:     */ import java.util.SortedSet;
/*   25:     */ import javax.annotation.Nullable;
/*   26:     */ 
/*   27:     */ @GwtCompatible(emulated=true)
/*   28:     */ final class Synchronized
/*   29:     */ {
/*   30:     */   static class SynchronizedObject
/*   31:     */     implements Serializable
/*   32:     */   {
/*   33:     */     final Object delegate;
/*   34:     */     final Object mutex;
/*   35:     */     @GwtIncompatible("not needed in emulated source")
/*   36:     */     private static final long serialVersionUID = 0L;
/*   37:     */     
/*   38:     */     SynchronizedObject(Object delegate, @Nullable Object mutex)
/*   39:     */     {
/*   40:  68 */       this.delegate = Preconditions.checkNotNull(delegate);
/*   41:  69 */       this.mutex = (mutex == null ? this : mutex);
/*   42:     */     }
/*   43:     */     
/*   44:     */     Object delegate()
/*   45:     */     {
/*   46:  73 */       return this.delegate;
/*   47:     */     }
/*   48:     */     
/*   49:     */     public String toString()
/*   50:     */     {
/*   51:  80 */       synchronized (this.mutex)
/*   52:     */       {
/*   53:  81 */         return this.delegate.toString();
/*   54:     */       }
/*   55:     */     }
/*   56:     */     
/*   57:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*   58:     */     private void writeObject(ObjectOutputStream stream)
/*   59:     */       throws IOException
/*   60:     */     {
/*   61:  92 */       synchronized (this.mutex)
/*   62:     */       {
/*   63:  93 */         stream.defaultWriteObject();
/*   64:     */       }
/*   65:     */     }
/*   66:     */   }
/*   67:     */   
/*   68:     */   private static <E> Collection<E> collection(Collection<E> collection, @Nullable Object mutex)
/*   69:     */   {
/*   70: 102 */     return new SynchronizedCollection(collection, mutex, null);
/*   71:     */   }
/*   72:     */   
/*   73:     */   @VisibleForTesting
/*   74:     */   static class SynchronizedCollection<E>
/*   75:     */     extends Synchronized.SynchronizedObject
/*   76:     */     implements Collection<E>
/*   77:     */   {
/*   78:     */     private static final long serialVersionUID = 0L;
/*   79:     */     
/*   80:     */     private SynchronizedCollection(Collection<E> delegate, @Nullable Object mutex)
/*   81:     */     {
/*   82: 108 */       super(mutex);
/*   83:     */     }
/*   84:     */     
/*   85:     */     Collection<E> delegate()
/*   86:     */     {
/*   87: 114 */       return (Collection)super.delegate();
/*   88:     */     }
/*   89:     */     
/*   90:     */     public boolean add(E e)
/*   91:     */     {
/*   92: 119 */       synchronized (this.mutex)
/*   93:     */       {
/*   94: 120 */         return delegate().add(e);
/*   95:     */       }
/*   96:     */     }
/*   97:     */     
/*   98:     */     public boolean addAll(Collection<? extends E> c)
/*   99:     */     {
/*  100: 126 */       synchronized (this.mutex)
/*  101:     */       {
/*  102: 127 */         return delegate().addAll(c);
/*  103:     */       }
/*  104:     */     }
/*  105:     */     
/*  106:     */     public void clear()
/*  107:     */     {
/*  108: 133 */       synchronized (this.mutex)
/*  109:     */       {
/*  110: 134 */         delegate().clear();
/*  111:     */       }
/*  112:     */     }
/*  113:     */     
/*  114:     */     public boolean contains(Object o)
/*  115:     */     {
/*  116: 140 */       synchronized (this.mutex)
/*  117:     */       {
/*  118: 141 */         return delegate().contains(o);
/*  119:     */       }
/*  120:     */     }
/*  121:     */     
/*  122:     */     public boolean containsAll(Collection<?> c)
/*  123:     */     {
/*  124: 147 */       synchronized (this.mutex)
/*  125:     */       {
/*  126: 148 */         return delegate().containsAll(c);
/*  127:     */       }
/*  128:     */     }
/*  129:     */     
/*  130:     */     public boolean isEmpty()
/*  131:     */     {
/*  132: 154 */       synchronized (this.mutex)
/*  133:     */       {
/*  134: 155 */         return delegate().isEmpty();
/*  135:     */       }
/*  136:     */     }
/*  137:     */     
/*  138:     */     public Iterator<E> iterator()
/*  139:     */     {
/*  140: 161 */       return delegate().iterator();
/*  141:     */     }
/*  142:     */     
/*  143:     */     public boolean remove(Object o)
/*  144:     */     {
/*  145: 166 */       synchronized (this.mutex)
/*  146:     */       {
/*  147: 167 */         return delegate().remove(o);
/*  148:     */       }
/*  149:     */     }
/*  150:     */     
/*  151:     */     public boolean removeAll(Collection<?> c)
/*  152:     */     {
/*  153: 173 */       synchronized (this.mutex)
/*  154:     */       {
/*  155: 174 */         return delegate().removeAll(c);
/*  156:     */       }
/*  157:     */     }
/*  158:     */     
/*  159:     */     public boolean retainAll(Collection<?> c)
/*  160:     */     {
/*  161: 180 */       synchronized (this.mutex)
/*  162:     */       {
/*  163: 181 */         return delegate().retainAll(c);
/*  164:     */       }
/*  165:     */     }
/*  166:     */     
/*  167:     */     public int size()
/*  168:     */     {
/*  169: 187 */       synchronized (this.mutex)
/*  170:     */       {
/*  171: 188 */         return delegate().size();
/*  172:     */       }
/*  173:     */     }
/*  174:     */     
/*  175:     */     public Object[] toArray()
/*  176:     */     {
/*  177: 194 */       synchronized (this.mutex)
/*  178:     */       {
/*  179: 195 */         return delegate().toArray();
/*  180:     */       }
/*  181:     */     }
/*  182:     */     
/*  183:     */     public <T> T[] toArray(T[] a)
/*  184:     */     {
/*  185: 201 */       synchronized (this.mutex)
/*  186:     */       {
/*  187: 202 */         return delegate().toArray(a);
/*  188:     */       }
/*  189:     */     }
/*  190:     */   }
/*  191:     */   
/*  192:     */   @VisibleForTesting
/*  193:     */   static <E> Set<E> set(Set<E> set, @Nullable Object mutex)
/*  194:     */   {
/*  195: 211 */     return new SynchronizedSet(set, mutex);
/*  196:     */   }
/*  197:     */   
/*  198:     */   static class SynchronizedSet<E>
/*  199:     */     extends Synchronized.SynchronizedCollection<E>
/*  200:     */     implements Set<E>
/*  201:     */   {
/*  202:     */     private static final long serialVersionUID = 0L;
/*  203:     */     
/*  204:     */     SynchronizedSet(Set<E> delegate, @Nullable Object mutex)
/*  205:     */     {
/*  206: 217 */       super(mutex, null);
/*  207:     */     }
/*  208:     */     
/*  209:     */     Set<E> delegate()
/*  210:     */     {
/*  211: 222 */       return (Set)super.delegate();
/*  212:     */     }
/*  213:     */     
/*  214:     */     public boolean equals(Object o)
/*  215:     */     {
/*  216: 227 */       if (o == this) {
/*  217: 228 */         return true;
/*  218:     */       }
/*  219: 230 */       synchronized (this.mutex)
/*  220:     */       {
/*  221: 231 */         return delegate().equals(o);
/*  222:     */       }
/*  223:     */     }
/*  224:     */     
/*  225:     */     public int hashCode()
/*  226:     */     {
/*  227: 237 */       synchronized (this.mutex)
/*  228:     */       {
/*  229: 238 */         return delegate().hashCode();
/*  230:     */       }
/*  231:     */     }
/*  232:     */   }
/*  233:     */   
/*  234:     */   private static <E> SortedSet<E> sortedSet(SortedSet<E> set, @Nullable Object mutex)
/*  235:     */   {
/*  236: 246 */     return new SynchronizedSortedSet(set, mutex);
/*  237:     */   }
/*  238:     */   
/*  239:     */   static class SynchronizedSortedSet<E>
/*  240:     */     extends Synchronized.SynchronizedSet<E>
/*  241:     */     implements SortedSet<E>
/*  242:     */   {
/*  243:     */     private static final long serialVersionUID = 0L;
/*  244:     */     
/*  245:     */     SynchronizedSortedSet(SortedSet<E> delegate, @Nullable Object mutex)
/*  246:     */     {
/*  247: 251 */       super(mutex);
/*  248:     */     }
/*  249:     */     
/*  250:     */     SortedSet<E> delegate()
/*  251:     */     {
/*  252: 256 */       return (SortedSet)super.delegate();
/*  253:     */     }
/*  254:     */     
/*  255:     */     public Comparator<? super E> comparator()
/*  256:     */     {
/*  257: 261 */       synchronized (this.mutex)
/*  258:     */       {
/*  259: 262 */         return delegate().comparator();
/*  260:     */       }
/*  261:     */     }
/*  262:     */     
/*  263:     */     public SortedSet<E> subSet(E fromElement, E toElement)
/*  264:     */     {
/*  265: 268 */       synchronized (this.mutex)
/*  266:     */       {
/*  267: 269 */         return Synchronized.sortedSet(delegate().subSet(fromElement, toElement), this.mutex);
/*  268:     */       }
/*  269:     */     }
/*  270:     */     
/*  271:     */     public SortedSet<E> headSet(E toElement)
/*  272:     */     {
/*  273: 275 */       synchronized (this.mutex)
/*  274:     */       {
/*  275: 276 */         return Synchronized.sortedSet(delegate().headSet(toElement), this.mutex);
/*  276:     */       }
/*  277:     */     }
/*  278:     */     
/*  279:     */     public SortedSet<E> tailSet(E fromElement)
/*  280:     */     {
/*  281: 282 */       synchronized (this.mutex)
/*  282:     */       {
/*  283: 283 */         return Synchronized.sortedSet(delegate().tailSet(fromElement), this.mutex);
/*  284:     */       }
/*  285:     */     }
/*  286:     */     
/*  287:     */     public E first()
/*  288:     */     {
/*  289: 289 */       synchronized (this.mutex)
/*  290:     */       {
/*  291: 290 */         return delegate().first();
/*  292:     */       }
/*  293:     */     }
/*  294:     */     
/*  295:     */     public E last()
/*  296:     */     {
/*  297: 296 */       synchronized (this.mutex)
/*  298:     */       {
/*  299: 297 */         return delegate().last();
/*  300:     */       }
/*  301:     */     }
/*  302:     */   }
/*  303:     */   
/*  304:     */   private static <E> List<E> list(List<E> list, @Nullable Object mutex)
/*  305:     */   {
/*  306: 305 */     return (list instanceof RandomAccess) ? new SynchronizedRandomAccessList(list, mutex) : new SynchronizedList(list, mutex);
/*  307:     */   }
/*  308:     */   
/*  309:     */   private static class SynchronizedList<E>
/*  310:     */     extends Synchronized.SynchronizedCollection<E>
/*  311:     */     implements List<E>
/*  312:     */   {
/*  313:     */     private static final long serialVersionUID = 0L;
/*  314:     */     
/*  315:     */     SynchronizedList(List<E> delegate, @Nullable Object mutex)
/*  316:     */     {
/*  317: 312 */       super(mutex, null);
/*  318:     */     }
/*  319:     */     
/*  320:     */     List<E> delegate()
/*  321:     */     {
/*  322: 317 */       return (List)super.delegate();
/*  323:     */     }
/*  324:     */     
/*  325:     */     public void add(int index, E element)
/*  326:     */     {
/*  327: 322 */       synchronized (this.mutex)
/*  328:     */       {
/*  329: 323 */         delegate().add(index, element);
/*  330:     */       }
/*  331:     */     }
/*  332:     */     
/*  333:     */     public boolean addAll(int index, Collection<? extends E> c)
/*  334:     */     {
/*  335: 329 */       synchronized (this.mutex)
/*  336:     */       {
/*  337: 330 */         return delegate().addAll(index, c);
/*  338:     */       }
/*  339:     */     }
/*  340:     */     
/*  341:     */     public E get(int index)
/*  342:     */     {
/*  343: 336 */       synchronized (this.mutex)
/*  344:     */       {
/*  345: 337 */         return delegate().get(index);
/*  346:     */       }
/*  347:     */     }
/*  348:     */     
/*  349:     */     public int indexOf(Object o)
/*  350:     */     {
/*  351: 343 */       synchronized (this.mutex)
/*  352:     */       {
/*  353: 344 */         return delegate().indexOf(o);
/*  354:     */       }
/*  355:     */     }
/*  356:     */     
/*  357:     */     public int lastIndexOf(Object o)
/*  358:     */     {
/*  359: 350 */       synchronized (this.mutex)
/*  360:     */       {
/*  361: 351 */         return delegate().lastIndexOf(o);
/*  362:     */       }
/*  363:     */     }
/*  364:     */     
/*  365:     */     public ListIterator<E> listIterator()
/*  366:     */     {
/*  367: 357 */       return delegate().listIterator();
/*  368:     */     }
/*  369:     */     
/*  370:     */     public ListIterator<E> listIterator(int index)
/*  371:     */     {
/*  372: 362 */       return delegate().listIterator(index);
/*  373:     */     }
/*  374:     */     
/*  375:     */     public E remove(int index)
/*  376:     */     {
/*  377: 367 */       synchronized (this.mutex)
/*  378:     */       {
/*  379: 368 */         return delegate().remove(index);
/*  380:     */       }
/*  381:     */     }
/*  382:     */     
/*  383:     */     public E set(int index, E element)
/*  384:     */     {
/*  385: 374 */       synchronized (this.mutex)
/*  386:     */       {
/*  387: 375 */         return delegate().set(index, element);
/*  388:     */       }
/*  389:     */     }
/*  390:     */     
/*  391:     */     public List<E> subList(int fromIndex, int toIndex)
/*  392:     */     {
/*  393: 381 */       synchronized (this.mutex)
/*  394:     */       {
/*  395: 382 */         return Synchronized.list(delegate().subList(fromIndex, toIndex), this.mutex);
/*  396:     */       }
/*  397:     */     }
/*  398:     */     
/*  399:     */     public boolean equals(Object o)
/*  400:     */     {
/*  401: 388 */       if (o == this) {
/*  402: 389 */         return true;
/*  403:     */       }
/*  404: 391 */       synchronized (this.mutex)
/*  405:     */       {
/*  406: 392 */         return delegate().equals(o);
/*  407:     */       }
/*  408:     */     }
/*  409:     */     
/*  410:     */     public int hashCode()
/*  411:     */     {
/*  412: 398 */       synchronized (this.mutex)
/*  413:     */       {
/*  414: 399 */         return delegate().hashCode();
/*  415:     */       }
/*  416:     */     }
/*  417:     */   }
/*  418:     */   
/*  419:     */   private static class SynchronizedRandomAccessList<E>
/*  420:     */     extends Synchronized.SynchronizedList<E>
/*  421:     */     implements RandomAccess
/*  422:     */   {
/*  423:     */     private static final long serialVersionUID = 0L;
/*  424:     */     
/*  425:     */     SynchronizedRandomAccessList(List<E> list, @Nullable Object mutex)
/*  426:     */     {
/*  427: 409 */       super(mutex);
/*  428:     */     }
/*  429:     */   }
/*  430:     */   
/*  431:     */   static <E> Multiset<E> multiset(Multiset<E> multiset, @Nullable Object mutex)
/*  432:     */   {
/*  433: 416 */     if (((multiset instanceof SynchronizedMultiset)) || ((multiset instanceof ImmutableMultiset))) {
/*  434: 417 */       return multiset;
/*  435:     */     }
/*  436: 419 */     return new SynchronizedMultiset(multiset, mutex);
/*  437:     */   }
/*  438:     */   
/*  439:     */   private static class SynchronizedMultiset<E>
/*  440:     */     extends Synchronized.SynchronizedCollection<E>
/*  441:     */     implements Multiset<E>
/*  442:     */   {
/*  443:     */     transient Set<E> elementSet;
/*  444:     */     transient Set<Multiset.Entry<E>> entrySet;
/*  445:     */     private static final long serialVersionUID = 0L;
/*  446:     */     
/*  447:     */     SynchronizedMultiset(Multiset<E> delegate, @Nullable Object mutex)
/*  448:     */     {
/*  449: 428 */       super(mutex, null);
/*  450:     */     }
/*  451:     */     
/*  452:     */     Multiset<E> delegate()
/*  453:     */     {
/*  454: 433 */       return (Multiset)super.delegate();
/*  455:     */     }
/*  456:     */     
/*  457:     */     public int count(Object o)
/*  458:     */     {
/*  459: 438 */       synchronized (this.mutex)
/*  460:     */       {
/*  461: 439 */         return delegate().count(o);
/*  462:     */       }
/*  463:     */     }
/*  464:     */     
/*  465:     */     public int add(E e, int n)
/*  466:     */     {
/*  467: 445 */       synchronized (this.mutex)
/*  468:     */       {
/*  469: 446 */         return delegate().add(e, n);
/*  470:     */       }
/*  471:     */     }
/*  472:     */     
/*  473:     */     public int remove(Object o, int n)
/*  474:     */     {
/*  475: 452 */       synchronized (this.mutex)
/*  476:     */       {
/*  477: 453 */         return delegate().remove(o, n);
/*  478:     */       }
/*  479:     */     }
/*  480:     */     
/*  481:     */     public int setCount(E element, int count)
/*  482:     */     {
/*  483: 459 */       synchronized (this.mutex)
/*  484:     */       {
/*  485: 460 */         return delegate().setCount(element, count);
/*  486:     */       }
/*  487:     */     }
/*  488:     */     
/*  489:     */     public boolean setCount(E element, int oldCount, int newCount)
/*  490:     */     {
/*  491: 466 */       synchronized (this.mutex)
/*  492:     */       {
/*  493: 467 */         return delegate().setCount(element, oldCount, newCount);
/*  494:     */       }
/*  495:     */     }
/*  496:     */     
/*  497:     */     public Set<E> elementSet()
/*  498:     */     {
/*  499: 473 */       synchronized (this.mutex)
/*  500:     */       {
/*  501: 474 */         if (this.elementSet == null) {
/*  502: 475 */           this.elementSet = Synchronized.typePreservingSet(delegate().elementSet(), this.mutex);
/*  503:     */         }
/*  504: 477 */         return this.elementSet;
/*  505:     */       }
/*  506:     */     }
/*  507:     */     
/*  508:     */     public Set<Multiset.Entry<E>> entrySet()
/*  509:     */     {
/*  510: 483 */       synchronized (this.mutex)
/*  511:     */       {
/*  512: 484 */         if (this.entrySet == null) {
/*  513: 485 */           this.entrySet = Synchronized.typePreservingSet(delegate().entrySet(), this.mutex);
/*  514:     */         }
/*  515: 487 */         return this.entrySet;
/*  516:     */       }
/*  517:     */     }
/*  518:     */     
/*  519:     */     public boolean equals(Object o)
/*  520:     */     {
/*  521: 493 */       if (o == this) {
/*  522: 494 */         return true;
/*  523:     */       }
/*  524: 496 */       synchronized (this.mutex)
/*  525:     */       {
/*  526: 497 */         return delegate().equals(o);
/*  527:     */       }
/*  528:     */     }
/*  529:     */     
/*  530:     */     public int hashCode()
/*  531:     */     {
/*  532: 503 */       synchronized (this.mutex)
/*  533:     */       {
/*  534: 504 */         return delegate().hashCode();
/*  535:     */       }
/*  536:     */     }
/*  537:     */   }
/*  538:     */   
/*  539:     */   static <K, V> Multimap<K, V> multimap(Multimap<K, V> multimap, @Nullable Object mutex)
/*  540:     */   {
/*  541: 512 */     if (((multimap instanceof SynchronizedMultimap)) || ((multimap instanceof ImmutableMultimap))) {
/*  542: 513 */       return multimap;
/*  543:     */     }
/*  544: 515 */     return new SynchronizedMultimap(multimap, mutex);
/*  545:     */   }
/*  546:     */   
/*  547:     */   private static class SynchronizedMultimap<K, V>
/*  548:     */     extends Synchronized.SynchronizedObject
/*  549:     */     implements Multimap<K, V>
/*  550:     */   {
/*  551:     */     transient Set<K> keySet;
/*  552:     */     transient Collection<V> valuesCollection;
/*  553:     */     transient Collection<Map.Entry<K, V>> entries;
/*  554:     */     transient Map<K, Collection<V>> asMap;
/*  555:     */     transient Multiset<K> keys;
/*  556:     */     private static final long serialVersionUID = 0L;
/*  557:     */     
/*  558:     */     Multimap<K, V> delegate()
/*  559:     */     {
/*  560: 529 */       return (Multimap)super.delegate();
/*  561:     */     }
/*  562:     */     
/*  563:     */     SynchronizedMultimap(Multimap<K, V> delegate, @Nullable Object mutex)
/*  564:     */     {
/*  565: 533 */       super(mutex);
/*  566:     */     }
/*  567:     */     
/*  568:     */     public int size()
/*  569:     */     {
/*  570: 538 */       synchronized (this.mutex)
/*  571:     */       {
/*  572: 539 */         return delegate().size();
/*  573:     */       }
/*  574:     */     }
/*  575:     */     
/*  576:     */     public boolean isEmpty()
/*  577:     */     {
/*  578: 545 */       synchronized (this.mutex)
/*  579:     */       {
/*  580: 546 */         return delegate().isEmpty();
/*  581:     */       }
/*  582:     */     }
/*  583:     */     
/*  584:     */     public boolean containsKey(Object key)
/*  585:     */     {
/*  586: 552 */       synchronized (this.mutex)
/*  587:     */       {
/*  588: 553 */         return delegate().containsKey(key);
/*  589:     */       }
/*  590:     */     }
/*  591:     */     
/*  592:     */     public boolean containsValue(Object value)
/*  593:     */     {
/*  594: 559 */       synchronized (this.mutex)
/*  595:     */       {
/*  596: 560 */         return delegate().containsValue(value);
/*  597:     */       }
/*  598:     */     }
/*  599:     */     
/*  600:     */     public boolean containsEntry(Object key, Object value)
/*  601:     */     {
/*  602: 566 */       synchronized (this.mutex)
/*  603:     */       {
/*  604: 567 */         return delegate().containsEntry(key, value);
/*  605:     */       }
/*  606:     */     }
/*  607:     */     
/*  608:     */     public Collection<V> get(K key)
/*  609:     */     {
/*  610: 573 */       synchronized (this.mutex)
/*  611:     */       {
/*  612: 574 */         return Synchronized.typePreservingCollection(delegate().get(key), this.mutex);
/*  613:     */       }
/*  614:     */     }
/*  615:     */     
/*  616:     */     public boolean put(K key, V value)
/*  617:     */     {
/*  618: 580 */       synchronized (this.mutex)
/*  619:     */       {
/*  620: 581 */         return delegate().put(key, value);
/*  621:     */       }
/*  622:     */     }
/*  623:     */     
/*  624:     */     public boolean putAll(K key, Iterable<? extends V> values)
/*  625:     */     {
/*  626: 587 */       synchronized (this.mutex)
/*  627:     */       {
/*  628: 588 */         return delegate().putAll(key, values);
/*  629:     */       }
/*  630:     */     }
/*  631:     */     
/*  632:     */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*  633:     */     {
/*  634: 594 */       synchronized (this.mutex)
/*  635:     */       {
/*  636: 595 */         return delegate().putAll(multimap);
/*  637:     */       }
/*  638:     */     }
/*  639:     */     
/*  640:     */     public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/*  641:     */     {
/*  642: 601 */       synchronized (this.mutex)
/*  643:     */       {
/*  644: 602 */         return delegate().replaceValues(key, values);
/*  645:     */       }
/*  646:     */     }
/*  647:     */     
/*  648:     */     public boolean remove(Object key, Object value)
/*  649:     */     {
/*  650: 608 */       synchronized (this.mutex)
/*  651:     */       {
/*  652: 609 */         return delegate().remove(key, value);
/*  653:     */       }
/*  654:     */     }
/*  655:     */     
/*  656:     */     public Collection<V> removeAll(Object key)
/*  657:     */     {
/*  658: 615 */       synchronized (this.mutex)
/*  659:     */       {
/*  660: 616 */         return delegate().removeAll(key);
/*  661:     */       }
/*  662:     */     }
/*  663:     */     
/*  664:     */     public void clear()
/*  665:     */     {
/*  666: 622 */       synchronized (this.mutex)
/*  667:     */       {
/*  668: 623 */         delegate().clear();
/*  669:     */       }
/*  670:     */     }
/*  671:     */     
/*  672:     */     public Set<K> keySet()
/*  673:     */     {
/*  674: 629 */       synchronized (this.mutex)
/*  675:     */       {
/*  676: 630 */         if (this.keySet == null) {
/*  677: 631 */           this.keySet = Synchronized.typePreservingSet(delegate().keySet(), this.mutex);
/*  678:     */         }
/*  679: 633 */         return this.keySet;
/*  680:     */       }
/*  681:     */     }
/*  682:     */     
/*  683:     */     public Collection<V> values()
/*  684:     */     {
/*  685: 639 */       synchronized (this.mutex)
/*  686:     */       {
/*  687: 640 */         if (this.valuesCollection == null) {
/*  688: 641 */           this.valuesCollection = Synchronized.collection(delegate().values(), this.mutex);
/*  689:     */         }
/*  690: 643 */         return this.valuesCollection;
/*  691:     */       }
/*  692:     */     }
/*  693:     */     
/*  694:     */     public Collection<Map.Entry<K, V>> entries()
/*  695:     */     {
/*  696: 649 */       synchronized (this.mutex)
/*  697:     */       {
/*  698: 650 */         if (this.entries == null) {
/*  699: 651 */           this.entries = Synchronized.typePreservingCollection(delegate().entries(), this.mutex);
/*  700:     */         }
/*  701: 653 */         return this.entries;
/*  702:     */       }
/*  703:     */     }
/*  704:     */     
/*  705:     */     public Map<K, Collection<V>> asMap()
/*  706:     */     {
/*  707: 659 */       synchronized (this.mutex)
/*  708:     */       {
/*  709: 660 */         if (this.asMap == null) {
/*  710: 661 */           this.asMap = new Synchronized.SynchronizedAsMap(delegate().asMap(), this.mutex);
/*  711:     */         }
/*  712: 663 */         return this.asMap;
/*  713:     */       }
/*  714:     */     }
/*  715:     */     
/*  716:     */     public Multiset<K> keys()
/*  717:     */     {
/*  718: 669 */       synchronized (this.mutex)
/*  719:     */       {
/*  720: 670 */         if (this.keys == null) {
/*  721: 671 */           this.keys = Synchronized.multiset(delegate().keys(), this.mutex);
/*  722:     */         }
/*  723: 673 */         return this.keys;
/*  724:     */       }
/*  725:     */     }
/*  726:     */     
/*  727:     */     public boolean equals(Object o)
/*  728:     */     {
/*  729: 679 */       if (o == this) {
/*  730: 680 */         return true;
/*  731:     */       }
/*  732: 682 */       synchronized (this.mutex)
/*  733:     */       {
/*  734: 683 */         return delegate().equals(o);
/*  735:     */       }
/*  736:     */     }
/*  737:     */     
/*  738:     */     public int hashCode()
/*  739:     */     {
/*  740: 689 */       synchronized (this.mutex)
/*  741:     */       {
/*  742: 690 */         return delegate().hashCode();
/*  743:     */       }
/*  744:     */     }
/*  745:     */   }
/*  746:     */   
/*  747:     */   static <K, V> ListMultimap<K, V> listMultimap(ListMultimap<K, V> multimap, @Nullable Object mutex)
/*  748:     */   {
/*  749: 699 */     if (((multimap instanceof SynchronizedListMultimap)) || ((multimap instanceof ImmutableListMultimap))) {
/*  750: 700 */       return multimap;
/*  751:     */     }
/*  752: 702 */     return new SynchronizedListMultimap(multimap, mutex);
/*  753:     */   }
/*  754:     */   
/*  755:     */   private static class SynchronizedListMultimap<K, V>
/*  756:     */     extends Synchronized.SynchronizedMultimap<K, V>
/*  757:     */     implements ListMultimap<K, V>
/*  758:     */   {
/*  759:     */     private static final long serialVersionUID = 0L;
/*  760:     */     
/*  761:     */     SynchronizedListMultimap(ListMultimap<K, V> delegate, @Nullable Object mutex)
/*  762:     */     {
/*  763: 708 */       super(mutex);
/*  764:     */     }
/*  765:     */     
/*  766:     */     ListMultimap<K, V> delegate()
/*  767:     */     {
/*  768: 713 */       return (ListMultimap)super.delegate();
/*  769:     */     }
/*  770:     */     
/*  771:     */     public List<V> get(K key)
/*  772:     */     {
/*  773: 718 */       synchronized (this.mutex)
/*  774:     */       {
/*  775: 719 */         return Synchronized.list(delegate().get(key), this.mutex);
/*  776:     */       }
/*  777:     */     }
/*  778:     */     
/*  779:     */     public List<V> removeAll(Object key)
/*  780:     */     {
/*  781: 725 */       synchronized (this.mutex)
/*  782:     */       {
/*  783: 726 */         return delegate().removeAll(key);
/*  784:     */       }
/*  785:     */     }
/*  786:     */     
/*  787:     */     public List<V> replaceValues(K key, Iterable<? extends V> values)
/*  788:     */     {
/*  789: 732 */       synchronized (this.mutex)
/*  790:     */       {
/*  791: 733 */         return delegate().replaceValues(key, values);
/*  792:     */       }
/*  793:     */     }
/*  794:     */   }
/*  795:     */   
/*  796:     */   static <K, V> SetMultimap<K, V> setMultimap(SetMultimap<K, V> multimap, @Nullable Object mutex)
/*  797:     */   {
/*  798: 741 */     if (((multimap instanceof SynchronizedSetMultimap)) || ((multimap instanceof ImmutableSetMultimap))) {
/*  799: 742 */       return multimap;
/*  800:     */     }
/*  801: 744 */     return new SynchronizedSetMultimap(multimap, mutex);
/*  802:     */   }
/*  803:     */   
/*  804:     */   private static class SynchronizedSetMultimap<K, V>
/*  805:     */     extends Synchronized.SynchronizedMultimap<K, V>
/*  806:     */     implements SetMultimap<K, V>
/*  807:     */   {
/*  808:     */     transient Set<Map.Entry<K, V>> entrySet;
/*  809:     */     private static final long serialVersionUID = 0L;
/*  810:     */     
/*  811:     */     SynchronizedSetMultimap(SetMultimap<K, V> delegate, @Nullable Object mutex)
/*  812:     */     {
/*  813: 752 */       super(mutex);
/*  814:     */     }
/*  815:     */     
/*  816:     */     SetMultimap<K, V> delegate()
/*  817:     */     {
/*  818: 757 */       return (SetMultimap)super.delegate();
/*  819:     */     }
/*  820:     */     
/*  821:     */     public Set<V> get(K key)
/*  822:     */     {
/*  823: 762 */       synchronized (this.mutex)
/*  824:     */       {
/*  825: 763 */         return Synchronized.set(delegate().get(key), this.mutex);
/*  826:     */       }
/*  827:     */     }
/*  828:     */     
/*  829:     */     public Set<V> removeAll(Object key)
/*  830:     */     {
/*  831: 769 */       synchronized (this.mutex)
/*  832:     */       {
/*  833: 770 */         return delegate().removeAll(key);
/*  834:     */       }
/*  835:     */     }
/*  836:     */     
/*  837:     */     public Set<V> replaceValues(K key, Iterable<? extends V> values)
/*  838:     */     {
/*  839: 776 */       synchronized (this.mutex)
/*  840:     */       {
/*  841: 777 */         return delegate().replaceValues(key, values);
/*  842:     */       }
/*  843:     */     }
/*  844:     */     
/*  845:     */     public Set<Map.Entry<K, V>> entries()
/*  846:     */     {
/*  847: 783 */       synchronized (this.mutex)
/*  848:     */       {
/*  849: 784 */         if (this.entrySet == null) {
/*  850: 785 */           this.entrySet = Synchronized.set(delegate().entries(), this.mutex);
/*  851:     */         }
/*  852: 787 */         return this.entrySet;
/*  853:     */       }
/*  854:     */     }
/*  855:     */   }
/*  856:     */   
/*  857:     */   static <K, V> SortedSetMultimap<K, V> sortedSetMultimap(SortedSetMultimap<K, V> multimap, @Nullable Object mutex)
/*  858:     */   {
/*  859: 796 */     if ((multimap instanceof SynchronizedSortedSetMultimap)) {
/*  860: 797 */       return multimap;
/*  861:     */     }
/*  862: 799 */     return new SynchronizedSortedSetMultimap(multimap, mutex);
/*  863:     */   }
/*  864:     */   
/*  865:     */   private static class SynchronizedSortedSetMultimap<K, V>
/*  866:     */     extends Synchronized.SynchronizedSetMultimap<K, V>
/*  867:     */     implements SortedSetMultimap<K, V>
/*  868:     */   {
/*  869:     */     private static final long serialVersionUID = 0L;
/*  870:     */     
/*  871:     */     SynchronizedSortedSetMultimap(SortedSetMultimap<K, V> delegate, @Nullable Object mutex)
/*  872:     */     {
/*  873: 805 */       super(mutex);
/*  874:     */     }
/*  875:     */     
/*  876:     */     SortedSetMultimap<K, V> delegate()
/*  877:     */     {
/*  878: 810 */       return (SortedSetMultimap)super.delegate();
/*  879:     */     }
/*  880:     */     
/*  881:     */     public SortedSet<V> get(K key)
/*  882:     */     {
/*  883: 815 */       synchronized (this.mutex)
/*  884:     */       {
/*  885: 816 */         return Synchronized.sortedSet(delegate().get(key), this.mutex);
/*  886:     */       }
/*  887:     */     }
/*  888:     */     
/*  889:     */     public SortedSet<V> removeAll(Object key)
/*  890:     */     {
/*  891: 822 */       synchronized (this.mutex)
/*  892:     */       {
/*  893: 823 */         return delegate().removeAll(key);
/*  894:     */       }
/*  895:     */     }
/*  896:     */     
/*  897:     */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values)
/*  898:     */     {
/*  899: 829 */       synchronized (this.mutex)
/*  900:     */       {
/*  901: 830 */         return delegate().replaceValues(key, values);
/*  902:     */       }
/*  903:     */     }
/*  904:     */     
/*  905:     */     public Comparator<? super V> valueComparator()
/*  906:     */     {
/*  907: 836 */       synchronized (this.mutex)
/*  908:     */       {
/*  909: 837 */         return delegate().valueComparator();
/*  910:     */       }
/*  911:     */     }
/*  912:     */   }
/*  913:     */   
/*  914:     */   private static <E> Collection<E> typePreservingCollection(Collection<E> collection, @Nullable Object mutex)
/*  915:     */   {
/*  916: 846 */     if ((collection instanceof SortedSet)) {
/*  917: 847 */       return sortedSet((SortedSet)collection, mutex);
/*  918:     */     }
/*  919: 849 */     if ((collection instanceof Set)) {
/*  920: 850 */       return set((Set)collection, mutex);
/*  921:     */     }
/*  922: 852 */     if ((collection instanceof List)) {
/*  923: 853 */       return list((List)collection, mutex);
/*  924:     */     }
/*  925: 855 */     return collection(collection, mutex);
/*  926:     */   }
/*  927:     */   
/*  928:     */   private static <E> Set<E> typePreservingSet(Set<E> set, @Nullable Object mutex)
/*  929:     */   {
/*  930: 859 */     if ((set instanceof SortedSet)) {
/*  931: 860 */       return sortedSet((SortedSet)set, mutex);
/*  932:     */     }
/*  933: 862 */     return set(set, mutex);
/*  934:     */   }
/*  935:     */   
/*  936:     */   private static class SynchronizedAsMapEntries<K, V>
/*  937:     */     extends Synchronized.SynchronizedSet<Map.Entry<K, Collection<V>>>
/*  938:     */   {
/*  939:     */     private static final long serialVersionUID = 0L;
/*  940:     */     
/*  941:     */     SynchronizedAsMapEntries(Set<Map.Entry<K, Collection<V>>> delegate, @Nullable Object mutex)
/*  942:     */     {
/*  943: 869 */       super(mutex);
/*  944:     */     }
/*  945:     */     
/*  946:     */     public Iterator<Map.Entry<K, Collection<V>>> iterator()
/*  947:     */     {
/*  948: 875 */       new TransformedIterator(super.iterator())
/*  949:     */       {
/*  950:     */         Map.Entry<K, Collection<V>> transform(final Map.Entry<K, Collection<V>> entry)
/*  951:     */         {
/*  952: 879 */           new ForwardingMapEntry()
/*  953:     */           {
/*  954:     */             protected Map.Entry<K, Collection<V>> delegate()
/*  955:     */             {
/*  956: 882 */               return entry;
/*  957:     */             }
/*  958:     */             
/*  959:     */             public Collection<V> getValue()
/*  960:     */             {
/*  961: 887 */               return Synchronized.typePreservingCollection((Collection)entry.getValue(), Synchronized.SynchronizedAsMapEntries.this.mutex);
/*  962:     */             }
/*  963:     */           };
/*  964:     */         }
/*  965:     */       };
/*  966:     */     }
/*  967:     */     
/*  968:     */     public Object[] toArray()
/*  969:     */     {
/*  970: 898 */       synchronized (this.mutex)
/*  971:     */       {
/*  972: 899 */         return ObjectArrays.toArrayImpl(delegate());
/*  973:     */       }
/*  974:     */     }
/*  975:     */     
/*  976:     */     public <T> T[] toArray(T[] array)
/*  977:     */     {
/*  978: 905 */       synchronized (this.mutex)
/*  979:     */       {
/*  980: 906 */         return ObjectArrays.toArrayImpl(delegate(), array);
/*  981:     */       }
/*  982:     */     }
/*  983:     */     
/*  984:     */     public boolean contains(Object o)
/*  985:     */     {
/*  986: 912 */       synchronized (this.mutex)
/*  987:     */       {
/*  988: 913 */         return Maps.containsEntryImpl(delegate(), o);
/*  989:     */       }
/*  990:     */     }
/*  991:     */     
/*  992:     */     public boolean containsAll(Collection<?> c)
/*  993:     */     {
/*  994: 919 */       synchronized (this.mutex)
/*  995:     */       {
/*  996: 920 */         return Collections2.containsAllImpl(delegate(), c);
/*  997:     */       }
/*  998:     */     }
/*  999:     */     
/* 1000:     */     public boolean equals(Object o)
/* 1001:     */     {
/* 1002: 926 */       if (o == this) {
/* 1003: 927 */         return true;
/* 1004:     */       }
/* 1005: 929 */       synchronized (this.mutex)
/* 1006:     */       {
/* 1007: 930 */         return Sets.equalsImpl(delegate(), o);
/* 1008:     */       }
/* 1009:     */     }
/* 1010:     */     
/* 1011:     */     public boolean remove(Object o)
/* 1012:     */     {
/* 1013: 936 */       synchronized (this.mutex)
/* 1014:     */       {
/* 1015: 937 */         return Maps.removeEntryImpl(delegate(), o);
/* 1016:     */       }
/* 1017:     */     }
/* 1018:     */     
/* 1019:     */     public boolean removeAll(Collection<?> c)
/* 1020:     */     {
/* 1021: 943 */       synchronized (this.mutex)
/* 1022:     */       {
/* 1023: 944 */         return Iterators.removeAll(delegate().iterator(), c);
/* 1024:     */       }
/* 1025:     */     }
/* 1026:     */     
/* 1027:     */     public boolean retainAll(Collection<?> c)
/* 1028:     */     {
/* 1029: 950 */       synchronized (this.mutex)
/* 1030:     */       {
/* 1031: 951 */         return Iterators.retainAll(delegate().iterator(), c);
/* 1032:     */       }
/* 1033:     */     }
/* 1034:     */   }
/* 1035:     */   
/* 1036:     */   @VisibleForTesting
/* 1037:     */   static <K, V> Map<K, V> map(Map<K, V> map, @Nullable Object mutex)
/* 1038:     */   {
/* 1039: 960 */     return new SynchronizedMap(map, mutex);
/* 1040:     */   }
/* 1041:     */   
/* 1042:     */   private static class SynchronizedMap<K, V>
/* 1043:     */     extends Synchronized.SynchronizedObject
/* 1044:     */     implements Map<K, V>
/* 1045:     */   {
/* 1046:     */     transient Set<K> keySet;
/* 1047:     */     transient Collection<V> values;
/* 1048:     */     transient Set<Map.Entry<K, V>> entrySet;
/* 1049:     */     private static final long serialVersionUID = 0L;
/* 1050:     */     
/* 1051:     */     SynchronizedMap(Map<K, V> delegate, @Nullable Object mutex)
/* 1052:     */     {
/* 1053: 969 */       super(mutex);
/* 1054:     */     }
/* 1055:     */     
/* 1056:     */     Map<K, V> delegate()
/* 1057:     */     {
/* 1058: 975 */       return (Map)super.delegate();
/* 1059:     */     }
/* 1060:     */     
/* 1061:     */     public void clear()
/* 1062:     */     {
/* 1063: 980 */       synchronized (this.mutex)
/* 1064:     */       {
/* 1065: 981 */         delegate().clear();
/* 1066:     */       }
/* 1067:     */     }
/* 1068:     */     
/* 1069:     */     public boolean containsKey(Object key)
/* 1070:     */     {
/* 1071: 987 */       synchronized (this.mutex)
/* 1072:     */       {
/* 1073: 988 */         return delegate().containsKey(key);
/* 1074:     */       }
/* 1075:     */     }
/* 1076:     */     
/* 1077:     */     public boolean containsValue(Object value)
/* 1078:     */     {
/* 1079: 994 */       synchronized (this.mutex)
/* 1080:     */       {
/* 1081: 995 */         return delegate().containsValue(value);
/* 1082:     */       }
/* 1083:     */     }
/* 1084:     */     
/* 1085:     */     public Set<Map.Entry<K, V>> entrySet()
/* 1086:     */     {
/* 1087:1001 */       synchronized (this.mutex)
/* 1088:     */       {
/* 1089:1002 */         if (this.entrySet == null) {
/* 1090:1003 */           this.entrySet = Synchronized.set(delegate().entrySet(), this.mutex);
/* 1091:     */         }
/* 1092:1005 */         return this.entrySet;
/* 1093:     */       }
/* 1094:     */     }
/* 1095:     */     
/* 1096:     */     public V get(Object key)
/* 1097:     */     {
/* 1098:1011 */       synchronized (this.mutex)
/* 1099:     */       {
/* 1100:1012 */         return delegate().get(key);
/* 1101:     */       }
/* 1102:     */     }
/* 1103:     */     
/* 1104:     */     public boolean isEmpty()
/* 1105:     */     {
/* 1106:1018 */       synchronized (this.mutex)
/* 1107:     */       {
/* 1108:1019 */         return delegate().isEmpty();
/* 1109:     */       }
/* 1110:     */     }
/* 1111:     */     
/* 1112:     */     public Set<K> keySet()
/* 1113:     */     {
/* 1114:1025 */       synchronized (this.mutex)
/* 1115:     */       {
/* 1116:1026 */         if (this.keySet == null) {
/* 1117:1027 */           this.keySet = Synchronized.set(delegate().keySet(), this.mutex);
/* 1118:     */         }
/* 1119:1029 */         return this.keySet;
/* 1120:     */       }
/* 1121:     */     }
/* 1122:     */     
/* 1123:     */     public V put(K key, V value)
/* 1124:     */     {
/* 1125:1035 */       synchronized (this.mutex)
/* 1126:     */       {
/* 1127:1036 */         return delegate().put(key, value);
/* 1128:     */       }
/* 1129:     */     }
/* 1130:     */     
/* 1131:     */     public void putAll(Map<? extends K, ? extends V> map)
/* 1132:     */     {
/* 1133:1042 */       synchronized (this.mutex)
/* 1134:     */       {
/* 1135:1043 */         delegate().putAll(map);
/* 1136:     */       }
/* 1137:     */     }
/* 1138:     */     
/* 1139:     */     public V remove(Object key)
/* 1140:     */     {
/* 1141:1049 */       synchronized (this.mutex)
/* 1142:     */       {
/* 1143:1050 */         return delegate().remove(key);
/* 1144:     */       }
/* 1145:     */     }
/* 1146:     */     
/* 1147:     */     public int size()
/* 1148:     */     {
/* 1149:1056 */       synchronized (this.mutex)
/* 1150:     */       {
/* 1151:1057 */         return delegate().size();
/* 1152:     */       }
/* 1153:     */     }
/* 1154:     */     
/* 1155:     */     public Collection<V> values()
/* 1156:     */     {
/* 1157:1063 */       synchronized (this.mutex)
/* 1158:     */       {
/* 1159:1064 */         if (this.values == null) {
/* 1160:1065 */           this.values = Synchronized.collection(delegate().values(), this.mutex);
/* 1161:     */         }
/* 1162:1067 */         return this.values;
/* 1163:     */       }
/* 1164:     */     }
/* 1165:     */     
/* 1166:     */     public boolean equals(Object o)
/* 1167:     */     {
/* 1168:1073 */       if (o == this) {
/* 1169:1074 */         return true;
/* 1170:     */       }
/* 1171:1076 */       synchronized (this.mutex)
/* 1172:     */       {
/* 1173:1077 */         return delegate().equals(o);
/* 1174:     */       }
/* 1175:     */     }
/* 1176:     */     
/* 1177:     */     public int hashCode()
/* 1178:     */     {
/* 1179:1083 */       synchronized (this.mutex)
/* 1180:     */       {
/* 1181:1084 */         return delegate().hashCode();
/* 1182:     */       }
/* 1183:     */     }
/* 1184:     */   }
/* 1185:     */   
/* 1186:     */   static <K, V> SortedMap<K, V> sortedMap(SortedMap<K, V> sortedMap, @Nullable Object mutex)
/* 1187:     */   {
/* 1188:1092 */     return new SynchronizedSortedMap(sortedMap, mutex);
/* 1189:     */   }
/* 1190:     */   
/* 1191:     */   static class SynchronizedSortedMap<K, V>
/* 1192:     */     extends Synchronized.SynchronizedMap<K, V>
/* 1193:     */     implements SortedMap<K, V>
/* 1194:     */   {
/* 1195:     */     private static final long serialVersionUID = 0L;
/* 1196:     */     
/* 1197:     */     SynchronizedSortedMap(SortedMap<K, V> delegate, @Nullable Object mutex)
/* 1198:     */     {
/* 1199:1099 */       super(mutex);
/* 1200:     */     }
/* 1201:     */     
/* 1202:     */     SortedMap<K, V> delegate()
/* 1203:     */     {
/* 1204:1104 */       return (SortedMap)super.delegate();
/* 1205:     */     }
/* 1206:     */     
/* 1207:     */     public Comparator<? super K> comparator()
/* 1208:     */     {
/* 1209:1109 */       synchronized (this.mutex)
/* 1210:     */       {
/* 1211:1110 */         return delegate().comparator();
/* 1212:     */       }
/* 1213:     */     }
/* 1214:     */     
/* 1215:     */     public K firstKey()
/* 1216:     */     {
/* 1217:1116 */       synchronized (this.mutex)
/* 1218:     */       {
/* 1219:1117 */         return delegate().firstKey();
/* 1220:     */       }
/* 1221:     */     }
/* 1222:     */     
/* 1223:     */     public SortedMap<K, V> headMap(K toKey)
/* 1224:     */     {
/* 1225:1123 */       synchronized (this.mutex)
/* 1226:     */       {
/* 1227:1124 */         return Synchronized.sortedMap(delegate().headMap(toKey), this.mutex);
/* 1228:     */       }
/* 1229:     */     }
/* 1230:     */     
/* 1231:     */     public K lastKey()
/* 1232:     */     {
/* 1233:1130 */       synchronized (this.mutex)
/* 1234:     */       {
/* 1235:1131 */         return delegate().lastKey();
/* 1236:     */       }
/* 1237:     */     }
/* 1238:     */     
/* 1239:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 1240:     */     {
/* 1241:1137 */       synchronized (this.mutex)
/* 1242:     */       {
/* 1243:1138 */         return Synchronized.sortedMap(delegate().subMap(fromKey, toKey), this.mutex);
/* 1244:     */       }
/* 1245:     */     }
/* 1246:     */     
/* 1247:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 1248:     */     {
/* 1249:1144 */       synchronized (this.mutex)
/* 1250:     */       {
/* 1251:1145 */         return Synchronized.sortedMap(delegate().tailMap(fromKey), this.mutex);
/* 1252:     */       }
/* 1253:     */     }
/* 1254:     */   }
/* 1255:     */   
/* 1256:     */   static <K, V> BiMap<K, V> biMap(BiMap<K, V> bimap, @Nullable Object mutex)
/* 1257:     */   {
/* 1258:1153 */     if (((bimap instanceof SynchronizedBiMap)) || ((bimap instanceof ImmutableBiMap))) {
/* 1259:1154 */       return bimap;
/* 1260:     */     }
/* 1261:1156 */     return new SynchronizedBiMap(bimap, mutex, null, null);
/* 1262:     */   }
/* 1263:     */   
/* 1264:     */   @VisibleForTesting
/* 1265:     */   static class SynchronizedBiMap<K, V>
/* 1266:     */     extends Synchronized.SynchronizedMap<K, V>
/* 1267:     */     implements BiMap<K, V>, Serializable
/* 1268:     */   {
/* 1269:     */     private transient Set<V> valueSet;
/* 1270:     */     private transient BiMap<V, K> inverse;
/* 1271:     */     private static final long serialVersionUID = 0L;
/* 1272:     */     
/* 1273:     */     private SynchronizedBiMap(BiMap<K, V> delegate, @Nullable Object mutex, @Nullable BiMap<V, K> inverse)
/* 1274:     */     {
/* 1275:1167 */       super(mutex);
/* 1276:1168 */       this.inverse = inverse;
/* 1277:     */     }
/* 1278:     */     
/* 1279:     */     BiMap<K, V> delegate()
/* 1280:     */     {
/* 1281:1173 */       return (BiMap)super.delegate();
/* 1282:     */     }
/* 1283:     */     
/* 1284:     */     public Set<V> values()
/* 1285:     */     {
/* 1286:1178 */       synchronized (this.mutex)
/* 1287:     */       {
/* 1288:1179 */         if (this.valueSet == null) {
/* 1289:1180 */           this.valueSet = Synchronized.set(delegate().values(), this.mutex);
/* 1290:     */         }
/* 1291:1182 */         return this.valueSet;
/* 1292:     */       }
/* 1293:     */     }
/* 1294:     */     
/* 1295:     */     public V forcePut(K key, V value)
/* 1296:     */     {
/* 1297:1188 */       synchronized (this.mutex)
/* 1298:     */       {
/* 1299:1189 */         return delegate().forcePut(key, value);
/* 1300:     */       }
/* 1301:     */     }
/* 1302:     */     
/* 1303:     */     public BiMap<V, K> inverse()
/* 1304:     */     {
/* 1305:1195 */       synchronized (this.mutex)
/* 1306:     */       {
/* 1307:1196 */         if (this.inverse == null) {
/* 1308:1197 */           this.inverse = new SynchronizedBiMap(delegate().inverse(), this.mutex, this);
/* 1309:     */         }
/* 1310:1199 */         return this.inverse;
/* 1311:     */       }
/* 1312:     */     }
/* 1313:     */   }
/* 1314:     */   
/* 1315:     */   private static class SynchronizedAsMap<K, V>
/* 1316:     */     extends Synchronized.SynchronizedMap<K, Collection<V>>
/* 1317:     */   {
/* 1318:     */     transient Set<Map.Entry<K, Collection<V>>> asMapEntrySet;
/* 1319:     */     transient Collection<Collection<V>> asMapValues;
/* 1320:     */     private static final long serialVersionUID = 0L;
/* 1321:     */     
/* 1322:     */     SynchronizedAsMap(Map<K, Collection<V>> delegate, @Nullable Object mutex)
/* 1323:     */     {
/* 1324:1211 */       super(mutex);
/* 1325:     */     }
/* 1326:     */     
/* 1327:     */     public Collection<V> get(Object key)
/* 1328:     */     {
/* 1329:1216 */       synchronized (this.mutex)
/* 1330:     */       {
/* 1331:1217 */         Collection<V> collection = (Collection)super.get(key);
/* 1332:1218 */         return collection == null ? null : Synchronized.typePreservingCollection(collection, this.mutex);
/* 1333:     */       }
/* 1334:     */     }
/* 1335:     */     
/* 1336:     */     public Set<Map.Entry<K, Collection<V>>> entrySet()
/* 1337:     */     {
/* 1338:1224 */       synchronized (this.mutex)
/* 1339:     */       {
/* 1340:1225 */         if (this.asMapEntrySet == null) {
/* 1341:1226 */           this.asMapEntrySet = new Synchronized.SynchronizedAsMapEntries(delegate().entrySet(), this.mutex);
/* 1342:     */         }
/* 1343:1228 */         return this.asMapEntrySet;
/* 1344:     */       }
/* 1345:     */     }
/* 1346:     */     
/* 1347:     */     public Collection<Collection<V>> values()
/* 1348:     */     {
/* 1349:1234 */       synchronized (this.mutex)
/* 1350:     */       {
/* 1351:1235 */         if (this.asMapValues == null) {
/* 1352:1236 */           this.asMapValues = new Synchronized.SynchronizedAsMapValues(delegate().values(), this.mutex);
/* 1353:     */         }
/* 1354:1238 */         return this.asMapValues;
/* 1355:     */       }
/* 1356:     */     }
/* 1357:     */     
/* 1358:     */     public boolean containsValue(Object o)
/* 1359:     */     {
/* 1360:1245 */       return values().contains(o);
/* 1361:     */     }
/* 1362:     */   }
/* 1363:     */   
/* 1364:     */   private static class SynchronizedAsMapValues<V>
/* 1365:     */     extends Synchronized.SynchronizedCollection<Collection<V>>
/* 1366:     */   {
/* 1367:     */     private static final long serialVersionUID = 0L;
/* 1368:     */     
/* 1369:     */     SynchronizedAsMapValues(Collection<Collection<V>> delegate, @Nullable Object mutex)
/* 1370:     */     {
/* 1371:1253 */       super(mutex, null);
/* 1372:     */     }
/* 1373:     */     
/* 1374:     */     public Iterator<Collection<V>> iterator()
/* 1375:     */     {
/* 1376:1259 */       new TransformedIterator(super.iterator())
/* 1377:     */       {
/* 1378:     */         Collection<V> transform(Collection<V> from)
/* 1379:     */         {
/* 1380:1262 */           return Synchronized.typePreservingCollection(from, Synchronized.SynchronizedAsMapValues.this.mutex);
/* 1381:     */         }
/* 1382:     */       };
/* 1383:     */     }
/* 1384:     */   }
/* 1385:     */   
/* 1386:     */   @GwtIncompatible("NavigableSet")
/* 1387:     */   @VisibleForTesting
/* 1388:     */   static class SynchronizedNavigableSet<E>
/* 1389:     */     extends Synchronized.SynchronizedSortedSet<E>
/* 1390:     */     implements NavigableSet<E>
/* 1391:     */   {
/* 1392:     */     transient NavigableSet<E> descendingSet;
/* 1393:     */     private static final long serialVersionUID = 0L;
/* 1394:     */     
/* 1395:     */     SynchronizedNavigableSet(NavigableSet<E> delegate, @Nullable Object mutex)
/* 1396:     */     {
/* 1397:1275 */       super(mutex);
/* 1398:     */     }
/* 1399:     */     
/* 1400:     */     NavigableSet<E> delegate()
/* 1401:     */     {
/* 1402:1280 */       return (NavigableSet)super.delegate();
/* 1403:     */     }
/* 1404:     */     
/* 1405:     */     public E ceiling(E e)
/* 1406:     */     {
/* 1407:1285 */       synchronized (this.mutex)
/* 1408:     */       {
/* 1409:1286 */         return delegate().ceiling(e);
/* 1410:     */       }
/* 1411:     */     }
/* 1412:     */     
/* 1413:     */     public Iterator<E> descendingIterator()
/* 1414:     */     {
/* 1415:1292 */       return delegate().descendingIterator();
/* 1416:     */     }
/* 1417:     */     
/* 1418:     */     public NavigableSet<E> descendingSet()
/* 1419:     */     {
/* 1420:1299 */       synchronized (this.mutex)
/* 1421:     */       {
/* 1422:1300 */         if (this.descendingSet == null)
/* 1423:     */         {
/* 1424:1301 */           NavigableSet<E> dS = Synchronized.navigableSet(delegate().descendingSet(), this.mutex);
/* 1425:1302 */           this.descendingSet = dS;
/* 1426:1303 */           return dS;
/* 1427:     */         }
/* 1428:1305 */         return this.descendingSet;
/* 1429:     */       }
/* 1430:     */     }
/* 1431:     */     
/* 1432:     */     public E floor(E e)
/* 1433:     */     {
/* 1434:1311 */       synchronized (this.mutex)
/* 1435:     */       {
/* 1436:1312 */         return delegate().floor(e);
/* 1437:     */       }
/* 1438:     */     }
/* 1439:     */     
/* 1440:     */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/* 1441:     */     {
/* 1442:1318 */       synchronized (this.mutex)
/* 1443:     */       {
/* 1444:1319 */         return Synchronized.navigableSet(delegate().headSet(toElement, inclusive), this.mutex);
/* 1445:     */       }
/* 1446:     */     }
/* 1447:     */     
/* 1448:     */     public E higher(E e)
/* 1449:     */     {
/* 1450:1325 */       synchronized (this.mutex)
/* 1451:     */       {
/* 1452:1326 */         return delegate().higher(e);
/* 1453:     */       }
/* 1454:     */     }
/* 1455:     */     
/* 1456:     */     public E lower(E e)
/* 1457:     */     {
/* 1458:1332 */       synchronized (this.mutex)
/* 1459:     */       {
/* 1460:1333 */         return delegate().lower(e);
/* 1461:     */       }
/* 1462:     */     }
/* 1463:     */     
/* 1464:     */     public E pollFirst()
/* 1465:     */     {
/* 1466:1339 */       synchronized (this.mutex)
/* 1467:     */       {
/* 1468:1340 */         return delegate().pollFirst();
/* 1469:     */       }
/* 1470:     */     }
/* 1471:     */     
/* 1472:     */     public E pollLast()
/* 1473:     */     {
/* 1474:1346 */       synchronized (this.mutex)
/* 1475:     */       {
/* 1476:1347 */         return delegate().pollLast();
/* 1477:     */       }
/* 1478:     */     }
/* 1479:     */     
/* 1480:     */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 1481:     */     {
/* 1482:1354 */       synchronized (this.mutex)
/* 1483:     */       {
/* 1484:1355 */         return Synchronized.navigableSet(delegate().subSet(fromElement, fromInclusive, toElement, toInclusive), this.mutex);
/* 1485:     */       }
/* 1486:     */     }
/* 1487:     */     
/* 1488:     */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/* 1489:     */     {
/* 1490:1362 */       synchronized (this.mutex)
/* 1491:     */       {
/* 1492:1363 */         return Synchronized.navigableSet(delegate().tailSet(fromElement, inclusive), this.mutex);
/* 1493:     */       }
/* 1494:     */     }
/* 1495:     */     
/* 1496:     */     public SortedSet<E> headSet(E toElement)
/* 1497:     */     {
/* 1498:1369 */       return headSet(toElement, false);
/* 1499:     */     }
/* 1500:     */     
/* 1501:     */     public SortedSet<E> subSet(E fromElement, E toElement)
/* 1502:     */     {
/* 1503:1374 */       return subSet(fromElement, true, toElement, false);
/* 1504:     */     }
/* 1505:     */     
/* 1506:     */     public SortedSet<E> tailSet(E fromElement)
/* 1507:     */     {
/* 1508:1379 */       return tailSet(fromElement, true);
/* 1509:     */     }
/* 1510:     */   }
/* 1511:     */   
/* 1512:     */   @GwtIncompatible("NavigableSet")
/* 1513:     */   static <E> NavigableSet<E> navigableSet(NavigableSet<E> navigableSet, @Nullable Object mutex)
/* 1514:     */   {
/* 1515:1387 */     return new SynchronizedNavigableSet(navigableSet, mutex);
/* 1516:     */   }
/* 1517:     */   
/* 1518:     */   @GwtIncompatible("NavigableSet")
/* 1519:     */   static <E> NavigableSet<E> navigableSet(NavigableSet<E> navigableSet)
/* 1520:     */   {
/* 1521:1392 */     return navigableSet(navigableSet, null);
/* 1522:     */   }
/* 1523:     */   
/* 1524:     */   @GwtIncompatible("NavigableMap")
/* 1525:     */   static <K, V> NavigableMap<K, V> navigableMap(NavigableMap<K, V> navigableMap)
/* 1526:     */   {
/* 1527:1397 */     return navigableMap(navigableMap, null);
/* 1528:     */   }
/* 1529:     */   
/* 1530:     */   @GwtIncompatible("NavigableMap")
/* 1531:     */   static <K, V> NavigableMap<K, V> navigableMap(NavigableMap<K, V> navigableMap, @Nullable Object mutex)
/* 1532:     */   {
/* 1533:1403 */     return new SynchronizedNavigableMap(navigableMap, mutex);
/* 1534:     */   }
/* 1535:     */   
/* 1536:     */   @GwtIncompatible("NavigableMap")
/* 1537:     */   @VisibleForTesting
/* 1538:     */   static class SynchronizedNavigableMap<K, V>
/* 1539:     */     extends Synchronized.SynchronizedSortedMap<K, V>
/* 1540:     */     implements NavigableMap<K, V>
/* 1541:     */   {
/* 1542:     */     transient NavigableSet<K> descendingKeySet;
/* 1543:     */     transient NavigableMap<K, V> descendingMap;
/* 1544:     */     transient NavigableSet<K> navigableKeySet;
/* 1545:     */     private static final long serialVersionUID = 0L;
/* 1546:     */     
/* 1547:     */     SynchronizedNavigableMap(NavigableMap<K, V> delegate, @Nullable Object mutex)
/* 1548:     */     {
/* 1549:1412 */       super(mutex);
/* 1550:     */     }
/* 1551:     */     
/* 1552:     */     NavigableMap<K, V> delegate()
/* 1553:     */     {
/* 1554:1417 */       return (NavigableMap)super.delegate();
/* 1555:     */     }
/* 1556:     */     
/* 1557:     */     public Map.Entry<K, V> ceilingEntry(K key)
/* 1558:     */     {
/* 1559:1422 */       synchronized (this.mutex)
/* 1560:     */       {
/* 1561:1423 */         return Synchronized.nullableSynchronizedEntry(delegate().ceilingEntry(key), this.mutex);
/* 1562:     */       }
/* 1563:     */     }
/* 1564:     */     
/* 1565:     */     public K ceilingKey(K key)
/* 1566:     */     {
/* 1567:1429 */       synchronized (this.mutex)
/* 1568:     */       {
/* 1569:1430 */         return delegate().ceilingKey(key);
/* 1570:     */       }
/* 1571:     */     }
/* 1572:     */     
/* 1573:     */     public NavigableSet<K> descendingKeySet()
/* 1574:     */     {
/* 1575:1438 */       synchronized (this.mutex)
/* 1576:     */       {
/* 1577:1439 */         if (this.descendingKeySet == null) {
/* 1578:1440 */           return this.descendingKeySet = Synchronized.navigableSet(delegate().descendingKeySet(), this.mutex);
/* 1579:     */         }
/* 1580:1442 */         return this.descendingKeySet;
/* 1581:     */       }
/* 1582:     */     }
/* 1583:     */     
/* 1584:     */     public NavigableMap<K, V> descendingMap()
/* 1585:     */     {
/* 1586:1450 */       synchronized (this.mutex)
/* 1587:     */       {
/* 1588:1451 */         if (this.descendingMap == null) {
/* 1589:1452 */           return this.descendingMap = Synchronized.navigableMap(delegate().descendingMap(), this.mutex);
/* 1590:     */         }
/* 1591:1454 */         return this.descendingMap;
/* 1592:     */       }
/* 1593:     */     }
/* 1594:     */     
/* 1595:     */     public Map.Entry<K, V> firstEntry()
/* 1596:     */     {
/* 1597:1460 */       synchronized (this.mutex)
/* 1598:     */       {
/* 1599:1461 */         return Synchronized.nullableSynchronizedEntry(delegate().firstEntry(), this.mutex);
/* 1600:     */       }
/* 1601:     */     }
/* 1602:     */     
/* 1603:     */     public Map.Entry<K, V> floorEntry(K key)
/* 1604:     */     {
/* 1605:1467 */       synchronized (this.mutex)
/* 1606:     */       {
/* 1607:1468 */         return Synchronized.nullableSynchronizedEntry(delegate().floorEntry(key), this.mutex);
/* 1608:     */       }
/* 1609:     */     }
/* 1610:     */     
/* 1611:     */     public K floorKey(K key)
/* 1612:     */     {
/* 1613:1474 */       synchronized (this.mutex)
/* 1614:     */       {
/* 1615:1475 */         return delegate().floorKey(key);
/* 1616:     */       }
/* 1617:     */     }
/* 1618:     */     
/* 1619:     */     public NavigableMap<K, V> headMap(K toKey, boolean inclusive)
/* 1620:     */     {
/* 1621:1481 */       synchronized (this.mutex)
/* 1622:     */       {
/* 1623:1482 */         return Synchronized.navigableMap(delegate().headMap(toKey, inclusive), this.mutex);
/* 1624:     */       }
/* 1625:     */     }
/* 1626:     */     
/* 1627:     */     public Map.Entry<K, V> higherEntry(K key)
/* 1628:     */     {
/* 1629:1488 */       synchronized (this.mutex)
/* 1630:     */       {
/* 1631:1489 */         return Synchronized.nullableSynchronizedEntry(delegate().higherEntry(key), this.mutex);
/* 1632:     */       }
/* 1633:     */     }
/* 1634:     */     
/* 1635:     */     public K higherKey(K key)
/* 1636:     */     {
/* 1637:1495 */       synchronized (this.mutex)
/* 1638:     */       {
/* 1639:1496 */         return delegate().higherKey(key);
/* 1640:     */       }
/* 1641:     */     }
/* 1642:     */     
/* 1643:     */     public Map.Entry<K, V> lastEntry()
/* 1644:     */     {
/* 1645:1502 */       synchronized (this.mutex)
/* 1646:     */       {
/* 1647:1503 */         return Synchronized.nullableSynchronizedEntry(delegate().lastEntry(), this.mutex);
/* 1648:     */       }
/* 1649:     */     }
/* 1650:     */     
/* 1651:     */     public Map.Entry<K, V> lowerEntry(K key)
/* 1652:     */     {
/* 1653:1509 */       synchronized (this.mutex)
/* 1654:     */       {
/* 1655:1510 */         return Synchronized.nullableSynchronizedEntry(delegate().lowerEntry(key), this.mutex);
/* 1656:     */       }
/* 1657:     */     }
/* 1658:     */     
/* 1659:     */     public K lowerKey(K key)
/* 1660:     */     {
/* 1661:1516 */       synchronized (this.mutex)
/* 1662:     */       {
/* 1663:1517 */         return delegate().lowerKey(key);
/* 1664:     */       }
/* 1665:     */     }
/* 1666:     */     
/* 1667:     */     public Set<K> keySet()
/* 1668:     */     {
/* 1669:1523 */       return navigableKeySet();
/* 1670:     */     }
/* 1671:     */     
/* 1672:     */     public NavigableSet<K> navigableKeySet()
/* 1673:     */     {
/* 1674:1530 */       synchronized (this.mutex)
/* 1675:     */       {
/* 1676:1531 */         if (this.navigableKeySet == null) {
/* 1677:1532 */           return this.navigableKeySet = Synchronized.navigableSet(delegate().navigableKeySet(), this.mutex);
/* 1678:     */         }
/* 1679:1534 */         return this.navigableKeySet;
/* 1680:     */       }
/* 1681:     */     }
/* 1682:     */     
/* 1683:     */     public Map.Entry<K, V> pollFirstEntry()
/* 1684:     */     {
/* 1685:1540 */       synchronized (this.mutex)
/* 1686:     */       {
/* 1687:1541 */         return Synchronized.nullableSynchronizedEntry(delegate().pollFirstEntry(), this.mutex);
/* 1688:     */       }
/* 1689:     */     }
/* 1690:     */     
/* 1691:     */     public Map.Entry<K, V> pollLastEntry()
/* 1692:     */     {
/* 1693:1547 */       synchronized (this.mutex)
/* 1694:     */       {
/* 1695:1548 */         return Synchronized.nullableSynchronizedEntry(delegate().pollLastEntry(), this.mutex);
/* 1696:     */       }
/* 1697:     */     }
/* 1698:     */     
/* 1699:     */     public NavigableMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 1700:     */     {
/* 1701:1555 */       synchronized (this.mutex)
/* 1702:     */       {
/* 1703:1556 */         return Synchronized.navigableMap(delegate().subMap(fromKey, fromInclusive, toKey, toInclusive), this.mutex);
/* 1704:     */       }
/* 1705:     */     }
/* 1706:     */     
/* 1707:     */     public NavigableMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 1708:     */     {
/* 1709:1562 */       synchronized (this.mutex)
/* 1710:     */       {
/* 1711:1563 */         return Synchronized.navigableMap(delegate().tailMap(fromKey, inclusive), this.mutex);
/* 1712:     */       }
/* 1713:     */     }
/* 1714:     */     
/* 1715:     */     public SortedMap<K, V> headMap(K toKey)
/* 1716:     */     {
/* 1717:1569 */       return headMap(toKey, false);
/* 1718:     */     }
/* 1719:     */     
/* 1720:     */     public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 1721:     */     {
/* 1722:1574 */       return subMap(fromKey, true, toKey, false);
/* 1723:     */     }
/* 1724:     */     
/* 1725:     */     public SortedMap<K, V> tailMap(K fromKey)
/* 1726:     */     {
/* 1727:1579 */       return tailMap(fromKey, true);
/* 1728:     */     }
/* 1729:     */   }
/* 1730:     */   
/* 1731:     */   @GwtIncompatible("works but is needed only for NavigableMap")
/* 1732:     */   private static <K, V> Map.Entry<K, V> nullableSynchronizedEntry(@Nullable Map.Entry<K, V> entry, @Nullable Object mutex)
/* 1733:     */   {
/* 1734:1588 */     if (entry == null) {
/* 1735:1589 */       return null;
/* 1736:     */     }
/* 1737:1591 */     return new SynchronizedEntry(entry, mutex);
/* 1738:     */   }
/* 1739:     */   
/* 1740:     */   @GwtIncompatible("works but is needed only for NavigableMap")
/* 1741:     */   private static class SynchronizedEntry<K, V>
/* 1742:     */     extends Synchronized.SynchronizedObject
/* 1743:     */     implements Map.Entry<K, V>
/* 1744:     */   {
/* 1745:     */     private static final long serialVersionUID = 0L;
/* 1746:     */     
/* 1747:     */     SynchronizedEntry(Map.Entry<K, V> delegate, @Nullable Object mutex)
/* 1748:     */     {
/* 1749:1598 */       super(mutex);
/* 1750:     */     }
/* 1751:     */     
/* 1752:     */     Map.Entry<K, V> delegate()
/* 1753:     */     {
/* 1754:1604 */       return (Map.Entry)super.delegate();
/* 1755:     */     }
/* 1756:     */     
/* 1757:     */     public boolean equals(Object obj)
/* 1758:     */     {
/* 1759:1609 */       synchronized (this.mutex)
/* 1760:     */       {
/* 1761:1610 */         return delegate().equals(obj);
/* 1762:     */       }
/* 1763:     */     }
/* 1764:     */     
/* 1765:     */     public int hashCode()
/* 1766:     */     {
/* 1767:1616 */       synchronized (this.mutex)
/* 1768:     */       {
/* 1769:1617 */         return delegate().hashCode();
/* 1770:     */       }
/* 1771:     */     }
/* 1772:     */     
/* 1773:     */     public K getKey()
/* 1774:     */     {
/* 1775:1623 */       synchronized (this.mutex)
/* 1776:     */       {
/* 1777:1624 */         return delegate().getKey();
/* 1778:     */       }
/* 1779:     */     }
/* 1780:     */     
/* 1781:     */     public V getValue()
/* 1782:     */     {
/* 1783:1630 */       synchronized (this.mutex)
/* 1784:     */       {
/* 1785:1631 */         return delegate().getValue();
/* 1786:     */       }
/* 1787:     */     }
/* 1788:     */     
/* 1789:     */     public V setValue(V value)
/* 1790:     */     {
/* 1791:1637 */       synchronized (this.mutex)
/* 1792:     */       {
/* 1793:1638 */         return delegate().setValue(value);
/* 1794:     */       }
/* 1795:     */     }
/* 1796:     */   }
/* 1797:     */   
/* 1798:     */   static <E> Queue<E> queue(Queue<E> queue, @Nullable Object mutex)
/* 1799:     */   {
/* 1800:1646 */     return (queue instanceof SynchronizedQueue) ? queue : new SynchronizedQueue(queue, mutex);
/* 1801:     */   }
/* 1802:     */   
/* 1803:     */   private static class SynchronizedQueue<E>
/* 1804:     */     extends Synchronized.SynchronizedCollection<E>
/* 1805:     */     implements Queue<E>
/* 1806:     */   {
/* 1807:     */     private static final long serialVersionUID = 0L;
/* 1808:     */     
/* 1809:     */     SynchronizedQueue(Queue<E> delegate, @Nullable Object mutex)
/* 1810:     */     {
/* 1811:1652 */       super(mutex, null);
/* 1812:     */     }
/* 1813:     */     
/* 1814:     */     Queue<E> delegate()
/* 1815:     */     {
/* 1816:1657 */       return (Queue)super.delegate();
/* 1817:     */     }
/* 1818:     */     
/* 1819:     */     public E element()
/* 1820:     */     {
/* 1821:1662 */       synchronized (this.mutex)
/* 1822:     */       {
/* 1823:1663 */         return delegate().element();
/* 1824:     */       }
/* 1825:     */     }
/* 1826:     */     
/* 1827:     */     public boolean offer(E e)
/* 1828:     */     {
/* 1829:1669 */       synchronized (this.mutex)
/* 1830:     */       {
/* 1831:1670 */         return delegate().offer(e);
/* 1832:     */       }
/* 1833:     */     }
/* 1834:     */     
/* 1835:     */     public E peek()
/* 1836:     */     {
/* 1837:1676 */       synchronized (this.mutex)
/* 1838:     */       {
/* 1839:1677 */         return delegate().peek();
/* 1840:     */       }
/* 1841:     */     }
/* 1842:     */     
/* 1843:     */     public E poll()
/* 1844:     */     {
/* 1845:1683 */       synchronized (this.mutex)
/* 1846:     */       {
/* 1847:1684 */         return delegate().poll();
/* 1848:     */       }
/* 1849:     */     }
/* 1850:     */     
/* 1851:     */     public E remove()
/* 1852:     */     {
/* 1853:1690 */       synchronized (this.mutex)
/* 1854:     */       {
/* 1855:1691 */         return delegate().remove();
/* 1856:     */       }
/* 1857:     */     }
/* 1858:     */   }
/* 1859:     */   
/* 1860:     */   @GwtIncompatible("Deque")
/* 1861:     */   static <E> Deque<E> deque(Deque<E> deque, @Nullable Object mutex)
/* 1862:     */   {
/* 1863:1700 */     return new SynchronizedDeque(deque, mutex);
/* 1864:     */   }
/* 1865:     */   
/* 1866:     */   @GwtIncompatible("Deque")
/* 1867:     */   private static final class SynchronizedDeque<E>
/* 1868:     */     extends Synchronized.SynchronizedQueue<E>
/* 1869:     */     implements Deque<E>
/* 1870:     */   {
/* 1871:     */     private static final long serialVersionUID = 0L;
/* 1872:     */     
/* 1873:     */     SynchronizedDeque(Deque<E> delegate, @Nullable Object mutex)
/* 1874:     */     {
/* 1875:1707 */       super(mutex);
/* 1876:     */     }
/* 1877:     */     
/* 1878:     */     Deque<E> delegate()
/* 1879:     */     {
/* 1880:1712 */       return (Deque)super.delegate();
/* 1881:     */     }
/* 1882:     */     
/* 1883:     */     public void addFirst(E e)
/* 1884:     */     {
/* 1885:1717 */       synchronized (this.mutex)
/* 1886:     */       {
/* 1887:1718 */         delegate().addFirst(e);
/* 1888:     */       }
/* 1889:     */     }
/* 1890:     */     
/* 1891:     */     public void addLast(E e)
/* 1892:     */     {
/* 1893:1724 */       synchronized (this.mutex)
/* 1894:     */       {
/* 1895:1725 */         delegate().addLast(e);
/* 1896:     */       }
/* 1897:     */     }
/* 1898:     */     
/* 1899:     */     public boolean offerFirst(E e)
/* 1900:     */     {
/* 1901:1731 */       synchronized (this.mutex)
/* 1902:     */       {
/* 1903:1732 */         return delegate().offerFirst(e);
/* 1904:     */       }
/* 1905:     */     }
/* 1906:     */     
/* 1907:     */     public boolean offerLast(E e)
/* 1908:     */     {
/* 1909:1738 */       synchronized (this.mutex)
/* 1910:     */       {
/* 1911:1739 */         return delegate().offerLast(e);
/* 1912:     */       }
/* 1913:     */     }
/* 1914:     */     
/* 1915:     */     public E removeFirst()
/* 1916:     */     {
/* 1917:1745 */       synchronized (this.mutex)
/* 1918:     */       {
/* 1919:1746 */         return delegate().removeFirst();
/* 1920:     */       }
/* 1921:     */     }
/* 1922:     */     
/* 1923:     */     public E removeLast()
/* 1924:     */     {
/* 1925:1752 */       synchronized (this.mutex)
/* 1926:     */       {
/* 1927:1753 */         return delegate().removeLast();
/* 1928:     */       }
/* 1929:     */     }
/* 1930:     */     
/* 1931:     */     public E pollFirst()
/* 1932:     */     {
/* 1933:1759 */       synchronized (this.mutex)
/* 1934:     */       {
/* 1935:1760 */         return delegate().pollFirst();
/* 1936:     */       }
/* 1937:     */     }
/* 1938:     */     
/* 1939:     */     public E pollLast()
/* 1940:     */     {
/* 1941:1766 */       synchronized (this.mutex)
/* 1942:     */       {
/* 1943:1767 */         return delegate().pollLast();
/* 1944:     */       }
/* 1945:     */     }
/* 1946:     */     
/* 1947:     */     public E getFirst()
/* 1948:     */     {
/* 1949:1773 */       synchronized (this.mutex)
/* 1950:     */       {
/* 1951:1774 */         return delegate().getFirst();
/* 1952:     */       }
/* 1953:     */     }
/* 1954:     */     
/* 1955:     */     public E getLast()
/* 1956:     */     {
/* 1957:1780 */       synchronized (this.mutex)
/* 1958:     */       {
/* 1959:1781 */         return delegate().getLast();
/* 1960:     */       }
/* 1961:     */     }
/* 1962:     */     
/* 1963:     */     public E peekFirst()
/* 1964:     */     {
/* 1965:1787 */       synchronized (this.mutex)
/* 1966:     */       {
/* 1967:1788 */         return delegate().peekFirst();
/* 1968:     */       }
/* 1969:     */     }
/* 1970:     */     
/* 1971:     */     public E peekLast()
/* 1972:     */     {
/* 1973:1794 */       synchronized (this.mutex)
/* 1974:     */       {
/* 1975:1795 */         return delegate().peekLast();
/* 1976:     */       }
/* 1977:     */     }
/* 1978:     */     
/* 1979:     */     public boolean removeFirstOccurrence(Object o)
/* 1980:     */     {
/* 1981:1801 */       synchronized (this.mutex)
/* 1982:     */       {
/* 1983:1802 */         return delegate().removeFirstOccurrence(o);
/* 1984:     */       }
/* 1985:     */     }
/* 1986:     */     
/* 1987:     */     public boolean removeLastOccurrence(Object o)
/* 1988:     */     {
/* 1989:1808 */       synchronized (this.mutex)
/* 1990:     */       {
/* 1991:1809 */         return delegate().removeLastOccurrence(o);
/* 1992:     */       }
/* 1993:     */     }
/* 1994:     */     
/* 1995:     */     public void push(E e)
/* 1996:     */     {
/* 1997:1815 */       synchronized (this.mutex)
/* 1998:     */       {
/* 1999:1816 */         delegate().push(e);
/* 2000:     */       }
/* 2001:     */     }
/* 2002:     */     
/* 2003:     */     public E pop()
/* 2004:     */     {
/* 2005:1822 */       synchronized (this.mutex)
/* 2006:     */       {
/* 2007:1823 */         return delegate().pop();
/* 2008:     */       }
/* 2009:     */     }
/* 2010:     */     
/* 2011:     */     public Iterator<E> descendingIterator()
/* 2012:     */     {
/* 2013:1829 */       synchronized (this.mutex)
/* 2014:     */       {
/* 2015:1830 */         return delegate().descendingIterator();
/* 2016:     */       }
/* 2017:     */     }
/* 2018:     */   }
/* 2019:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Synchronized
 * JD-Core Version:    0.7.0.1
 */