/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import java.util.Iterator;
/*   4:    */ import java.util.Map.Entry;
/*   5:    */ import java.util.NavigableMap;
/*   6:    */ import java.util.NavigableSet;
/*   7:    */ import java.util.NoSuchElementException;
/*   8:    */ import java.util.Set;
/*   9:    */ import java.util.SortedMap;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ abstract class AbstractNavigableMap<K, V>
/*  13:    */   extends Maps.IteratorBasedAbstractMap<K, V>
/*  14:    */   implements NavigableMap<K, V>
/*  15:    */ {
/*  16:    */   @Nullable
/*  17:    */   public abstract V get(@Nullable Object paramObject);
/*  18:    */   
/*  19:    */   @Nullable
/*  20:    */   public Map.Entry<K, V> firstEntry()
/*  21:    */   {
/*  22: 45 */     return (Map.Entry)Iterators.getNext(entryIterator(), null);
/*  23:    */   }
/*  24:    */   
/*  25:    */   @Nullable
/*  26:    */   public Map.Entry<K, V> lastEntry()
/*  27:    */   {
/*  28: 51 */     return (Map.Entry)Iterators.getNext(descendingEntryIterator(), null);
/*  29:    */   }
/*  30:    */   
/*  31:    */   @Nullable
/*  32:    */   public Map.Entry<K, V> pollFirstEntry()
/*  33:    */   {
/*  34: 57 */     return (Map.Entry)Iterators.pollNext(entryIterator());
/*  35:    */   }
/*  36:    */   
/*  37:    */   @Nullable
/*  38:    */   public Map.Entry<K, V> pollLastEntry()
/*  39:    */   {
/*  40: 63 */     return (Map.Entry)Iterators.pollNext(descendingEntryIterator());
/*  41:    */   }
/*  42:    */   
/*  43:    */   public K firstKey()
/*  44:    */   {
/*  45: 68 */     Map.Entry<K, V> entry = firstEntry();
/*  46: 69 */     if (entry == null) {
/*  47: 70 */       throw new NoSuchElementException();
/*  48:    */     }
/*  49: 72 */     return entry.getKey();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public K lastKey()
/*  53:    */   {
/*  54: 78 */     Map.Entry<K, V> entry = lastEntry();
/*  55: 79 */     if (entry == null) {
/*  56: 80 */       throw new NoSuchElementException();
/*  57:    */     }
/*  58: 82 */     return entry.getKey();
/*  59:    */   }
/*  60:    */   
/*  61:    */   @Nullable
/*  62:    */   public Map.Entry<K, V> lowerEntry(K key)
/*  63:    */   {
/*  64: 89 */     return headMap(key, false).lastEntry();
/*  65:    */   }
/*  66:    */   
/*  67:    */   @Nullable
/*  68:    */   public Map.Entry<K, V> floorEntry(K key)
/*  69:    */   {
/*  70: 95 */     return headMap(key, true).lastEntry();
/*  71:    */   }
/*  72:    */   
/*  73:    */   @Nullable
/*  74:    */   public Map.Entry<K, V> ceilingEntry(K key)
/*  75:    */   {
/*  76:101 */     return tailMap(key, true).firstEntry();
/*  77:    */   }
/*  78:    */   
/*  79:    */   @Nullable
/*  80:    */   public Map.Entry<K, V> higherEntry(K key)
/*  81:    */   {
/*  82:107 */     return tailMap(key, false).firstEntry();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public K lowerKey(K key)
/*  86:    */   {
/*  87:112 */     return Maps.keyOrNull(lowerEntry(key));
/*  88:    */   }
/*  89:    */   
/*  90:    */   public K floorKey(K key)
/*  91:    */   {
/*  92:117 */     return Maps.keyOrNull(floorEntry(key));
/*  93:    */   }
/*  94:    */   
/*  95:    */   public K ceilingKey(K key)
/*  96:    */   {
/*  97:122 */     return Maps.keyOrNull(ceilingEntry(key));
/*  98:    */   }
/*  99:    */   
/* 100:    */   public K higherKey(K key)
/* 101:    */   {
/* 102:127 */     return Maps.keyOrNull(higherEntry(key));
/* 103:    */   }
/* 104:    */   
/* 105:    */   abstract Iterator<Map.Entry<K, V>> descendingEntryIterator();
/* 106:    */   
/* 107:    */   public SortedMap<K, V> subMap(K fromKey, K toKey)
/* 108:    */   {
/* 109:134 */     return subMap(fromKey, true, toKey, false);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public SortedMap<K, V> headMap(K toKey)
/* 113:    */   {
/* 114:139 */     return headMap(toKey, false);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public SortedMap<K, V> tailMap(K fromKey)
/* 118:    */   {
/* 119:144 */     return tailMap(fromKey, true);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public NavigableSet<K> navigableKeySet()
/* 123:    */   {
/* 124:149 */     return new Maps.NavigableKeySet(this);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public Set<K> keySet()
/* 128:    */   {
/* 129:154 */     return navigableKeySet();
/* 130:    */   }
/* 131:    */   
/* 132:    */   public NavigableSet<K> descendingKeySet()
/* 133:    */   {
/* 134:159 */     return descendingMap().navigableKeySet();
/* 135:    */   }
/* 136:    */   
/* 137:    */   public NavigableMap<K, V> descendingMap()
/* 138:    */   {
/* 139:164 */     return new DescendingMap(null);
/* 140:    */   }
/* 141:    */   
/* 142:    */   private final class DescendingMap
/* 143:    */     extends Maps.DescendingMap<K, V>
/* 144:    */   {
/* 145:    */     private DescendingMap() {}
/* 146:    */     
/* 147:    */     NavigableMap<K, V> forward()
/* 148:    */     {
/* 149:170 */       return AbstractNavigableMap.this;
/* 150:    */     }
/* 151:    */     
/* 152:    */     Iterator<Map.Entry<K, V>> entryIterator()
/* 153:    */     {
/* 154:175 */       return AbstractNavigableMap.this.descendingEntryIterator();
/* 155:    */     }
/* 156:    */   }
/* 157:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractNavigableMap
 * JD-Core Version:    0.7.0.1
 */