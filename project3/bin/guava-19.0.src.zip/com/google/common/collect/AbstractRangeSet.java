/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import java.util.Set;
/*   4:    */ import javax.annotation.Nullable;
/*   5:    */ 
/*   6:    */ abstract class AbstractRangeSet<C extends Comparable>
/*   7:    */   implements RangeSet<C>
/*   8:    */ {
/*   9:    */   public boolean contains(C value)
/*  10:    */   {
/*  11: 29 */     return rangeContaining(value) != null;
/*  12:    */   }
/*  13:    */   
/*  14:    */   public abstract Range<C> rangeContaining(C paramC);
/*  15:    */   
/*  16:    */   public boolean isEmpty()
/*  17:    */   {
/*  18: 37 */     return asRanges().isEmpty();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public void add(Range<C> range)
/*  22:    */   {
/*  23: 42 */     throw new UnsupportedOperationException();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public void remove(Range<C> range)
/*  27:    */   {
/*  28: 47 */     throw new UnsupportedOperationException();
/*  29:    */   }
/*  30:    */   
/*  31:    */   public void clear()
/*  32:    */   {
/*  33: 52 */     remove(Range.all());
/*  34:    */   }
/*  35:    */   
/*  36:    */   public boolean enclosesAll(RangeSet<C> other)
/*  37:    */   {
/*  38: 57 */     for (Range<C> range : other.asRanges()) {
/*  39: 58 */       if (!encloses(range)) {
/*  40: 59 */         return false;
/*  41:    */       }
/*  42:    */     }
/*  43: 62 */     return true;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public void addAll(RangeSet<C> other)
/*  47:    */   {
/*  48: 67 */     for (Range<C> range : other.asRanges()) {
/*  49: 68 */       add(range);
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   public void removeAll(RangeSet<C> other)
/*  54:    */   {
/*  55: 74 */     for (Range<C> range : other.asRanges()) {
/*  56: 75 */       remove(range);
/*  57:    */     }
/*  58:    */   }
/*  59:    */   
/*  60:    */   public abstract boolean encloses(Range<C> paramRange);
/*  61:    */   
/*  62:    */   public boolean equals(@Nullable Object obj)
/*  63:    */   {
/*  64: 84 */     if (obj == this) {
/*  65: 85 */       return true;
/*  66:    */     }
/*  67: 86 */     if ((obj instanceof RangeSet))
/*  68:    */     {
/*  69: 87 */       RangeSet<?> other = (RangeSet)obj;
/*  70: 88 */       return asRanges().equals(other.asRanges());
/*  71:    */     }
/*  72: 90 */     return false;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public final int hashCode()
/*  76:    */   {
/*  77: 95 */     return asRanges().hashCode();
/*  78:    */   }
/*  79:    */   
/*  80:    */   public final String toString()
/*  81:    */   {
/*  82:100 */     return asRanges().toString();
/*  83:    */   }
/*  84:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractRangeSet
 * JD-Core Version:    0.7.0.1
 */