/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Predicate;
/*   6:    */ import java.lang.reflect.Array;
/*   7:    */ import java.util.ArrayDeque;
/*   8:    */ import java.util.Collections;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.NavigableMap;
/*  12:    */ import java.util.NavigableSet;
/*  13:    */ import java.util.Queue;
/*  14:    */ import java.util.Set;
/*  15:    */ import java.util.SortedMap;
/*  16:    */ import java.util.SortedSet;
/*  17:    */ 
/*  18:    */ @GwtCompatible(emulated=true)
/*  19:    */ final class Platform
/*  20:    */ {
/*  21:    */   static <T> T[] newArray(T[] reference, int length)
/*  22:    */   {
/*  23: 50 */     Class<?> type = reference.getClass().getComponentType();
/*  24:    */     
/*  25:    */ 
/*  26:    */ 
/*  27:    */ 
/*  28: 55 */     T[] result = (Object[])Array.newInstance(type, length);
/*  29: 56 */     return result;
/*  30:    */   }
/*  31:    */   
/*  32:    */   static <E> Set<E> newSetFromMap(Map<E, Boolean> map)
/*  33:    */   {
/*  34: 60 */     return Collections.newSetFromMap(map);
/*  35:    */   }
/*  36:    */   
/*  37:    */   static MapMaker tryWeakKeys(MapMaker mapMaker)
/*  38:    */   {
/*  39: 70 */     return mapMaker.weakKeys();
/*  40:    */   }
/*  41:    */   
/*  42:    */   static <K, V1, V2> SortedMap<K, V2> mapsTransformEntriesSortedMap(SortedMap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  43:    */   {
/*  44: 75 */     return (fromMap instanceof NavigableMap) ? Maps.transformEntries((NavigableMap)fromMap, transformer) : Maps.transformEntriesIgnoreNavigable(fromMap, transformer);
/*  45:    */   }
/*  46:    */   
/*  47:    */   static <K, V> SortedMap<K, V> mapsAsMapSortedSet(SortedSet<K> set, Function<? super K, V> function)
/*  48:    */   {
/*  49: 82 */     return (set instanceof NavigableSet) ? Maps.asMap((NavigableSet)set, function) : Maps.asMapSortedIgnoreNavigable(set, function);
/*  50:    */   }
/*  51:    */   
/*  52:    */   static <E> SortedSet<E> setsFilterSortedSet(SortedSet<E> set, Predicate<? super E> predicate)
/*  53:    */   {
/*  54: 88 */     return (set instanceof NavigableSet) ? Sets.filter((NavigableSet)set, predicate) : Sets.filterSortedIgnoreNavigable(set, predicate);
/*  55:    */   }
/*  56:    */   
/*  57:    */   static <K, V> SortedMap<K, V> mapsFilterSortedMap(SortedMap<K, V> map, Predicate<? super Map.Entry<K, V>> predicate)
/*  58:    */   {
/*  59: 95 */     return (map instanceof NavigableMap) ? Maps.filterEntries((NavigableMap)map, predicate) : Maps.filterSortedIgnoreNavigable(map, predicate);
/*  60:    */   }
/*  61:    */   
/*  62:    */   static <E> Queue<E> newFastestQueue(int initialCapacity)
/*  63:    */   {
/*  64:101 */     return new ArrayDeque(initialCapacity);
/*  65:    */   }
/*  66:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Platform
 * JD-Core Version:    0.7.0.1
 */