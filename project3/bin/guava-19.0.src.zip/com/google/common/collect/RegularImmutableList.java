/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ 
/*  6:   */ @GwtCompatible(serializable=true, emulated=true)
/*  7:   */ class RegularImmutableList<E>
/*  8:   */   extends ImmutableList<E>
/*  9:   */ {
/* 10:30 */   static final ImmutableList<Object> EMPTY = new RegularImmutableList(ObjectArrays.EMPTY_ARRAY);
/* 11:   */   private final transient int offset;
/* 12:   */   private final transient int size;
/* 13:   */   private final transient Object[] array;
/* 14:   */   
/* 15:   */   RegularImmutableList(Object[] array, int offset, int size)
/* 16:   */   {
/* 17:38 */     this.offset = offset;
/* 18:39 */     this.size = size;
/* 19:40 */     this.array = array;
/* 20:   */   }
/* 21:   */   
/* 22:   */   RegularImmutableList(Object[] array)
/* 23:   */   {
/* 24:44 */     this(array, 0, array.length);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public int size()
/* 28:   */   {
/* 29:49 */     return this.size;
/* 30:   */   }
/* 31:   */   
/* 32:   */   boolean isPartialView()
/* 33:   */   {
/* 34:54 */     return this.size != this.array.length;
/* 35:   */   }
/* 36:   */   
/* 37:   */   int copyIntoArray(Object[] dst, int dstOff)
/* 38:   */   {
/* 39:59 */     System.arraycopy(this.array, this.offset, dst, dstOff, this.size);
/* 40:60 */     return dstOff + this.size;
/* 41:   */   }
/* 42:   */   
/* 43:   */   public E get(int index)
/* 44:   */   {
/* 45:67 */     Preconditions.checkElementIndex(index, this.size);
/* 46:68 */     return this.array[(index + this.offset)];
/* 47:   */   }
/* 48:   */   
/* 49:   */   ImmutableList<E> subListUnchecked(int fromIndex, int toIndex)
/* 50:   */   {
/* 51:73 */     return new RegularImmutableList(this.array, this.offset + fromIndex, toIndex - fromIndex);
/* 52:   */   }
/* 53:   */   
/* 54:   */   public UnmodifiableListIterator<E> listIterator(int index)
/* 55:   */   {
/* 56:81 */     return Iterators.forArray(this.array, this.offset, this.size, index);
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableList
 * JD-Core Version:    0.7.0.1
 */