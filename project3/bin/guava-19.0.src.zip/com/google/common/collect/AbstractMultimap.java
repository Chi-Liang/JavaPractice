/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.AbstractCollection;
/*   6:    */ import java.util.Collection;
/*   7:    */ import java.util.Iterator;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.Set;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ 
/*  13:    */ @GwtCompatible
/*  14:    */ abstract class AbstractMultimap<K, V>
/*  15:    */   implements Multimap<K, V>
/*  16:    */ {
/*  17:    */   private transient Collection<Map.Entry<K, V>> entries;
/*  18:    */   private transient Set<K> keySet;
/*  19:    */   private transient Multiset<K> keys;
/*  20:    */   private transient Collection<V> values;
/*  21:    */   private transient Map<K, Collection<V>> asMap;
/*  22:    */   
/*  23:    */   public boolean isEmpty()
/*  24:    */   {
/*  25: 42 */     return size() == 0;
/*  26:    */   }
/*  27:    */   
/*  28:    */   public boolean containsValue(@Nullable Object value)
/*  29:    */   {
/*  30: 47 */     for (Collection<V> collection : asMap().values()) {
/*  31: 48 */       if (collection.contains(value)) {
/*  32: 49 */         return true;
/*  33:    */       }
/*  34:    */     }
/*  35: 53 */     return false;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public boolean containsEntry(@Nullable Object key, @Nullable Object value)
/*  39:    */   {
/*  40: 58 */     Collection<V> collection = (Collection)asMap().get(key);
/*  41: 59 */     return (collection != null) && (collection.contains(value));
/*  42:    */   }
/*  43:    */   
/*  44:    */   public boolean remove(@Nullable Object key, @Nullable Object value)
/*  45:    */   {
/*  46: 64 */     Collection<V> collection = (Collection)asMap().get(key);
/*  47: 65 */     return (collection != null) && (collection.remove(value));
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean put(@Nullable K key, @Nullable V value)
/*  51:    */   {
/*  52: 70 */     return get(key).add(value);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public boolean putAll(@Nullable K key, Iterable<? extends V> values)
/*  56:    */   {
/*  57: 75 */     Preconditions.checkNotNull(values);
/*  58: 78 */     if ((values instanceof Collection))
/*  59:    */     {
/*  60: 79 */       Collection<? extends V> valueCollection = (Collection)values;
/*  61: 80 */       return (!valueCollection.isEmpty()) && (get(key).addAll(valueCollection));
/*  62:    */     }
/*  63: 82 */     Iterator<? extends V> valueItr = values.iterator();
/*  64: 83 */     return (valueItr.hasNext()) && (Iterators.addAll(get(key), valueItr));
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*  68:    */   {
/*  69: 89 */     boolean changed = false;
/*  70: 90 */     for (Map.Entry<? extends K, ? extends V> entry : multimap.entries()) {
/*  71: 91 */       changed |= put(entry.getKey(), entry.getValue());
/*  72:    */     }
/*  73: 93 */     return changed;
/*  74:    */   }
/*  75:    */   
/*  76:    */   public Collection<V> replaceValues(@Nullable K key, Iterable<? extends V> values)
/*  77:    */   {
/*  78: 98 */     Preconditions.checkNotNull(values);
/*  79: 99 */     Collection<V> result = removeAll(key);
/*  80:100 */     putAll(key, values);
/*  81:101 */     return result;
/*  82:    */   }
/*  83:    */   
/*  84:    */   public Collection<Map.Entry<K, V>> entries()
/*  85:    */   {
/*  86:108 */     Collection<Map.Entry<K, V>> result = this.entries;
/*  87:109 */     return result == null ? (this.entries = createEntries()) : result;
/*  88:    */   }
/*  89:    */   
/*  90:    */   Collection<Map.Entry<K, V>> createEntries()
/*  91:    */   {
/*  92:113 */     if ((this instanceof SetMultimap)) {
/*  93:114 */       return new EntrySet(null);
/*  94:    */     }
/*  95:116 */     return new Entries(null);
/*  96:    */   }
/*  97:    */   
/*  98:    */   abstract Iterator<Map.Entry<K, V>> entryIterator();
/*  99:    */   
/* 100:    */   private class Entries
/* 101:    */     extends Multimaps.Entries<K, V>
/* 102:    */   {
/* 103:    */     private Entries() {}
/* 104:    */     
/* 105:    */     Multimap<K, V> multimap()
/* 106:    */     {
/* 107:124 */       return AbstractMultimap.this;
/* 108:    */     }
/* 109:    */     
/* 110:    */     public Iterator<Map.Entry<K, V>> iterator()
/* 111:    */     {
/* 112:129 */       return AbstractMultimap.this.entryIterator();
/* 113:    */     }
/* 114:    */   }
/* 115:    */   
/* 116:    */   private class EntrySet
/* 117:    */     extends AbstractMultimap<K, V>.Entries
/* 118:    */     implements Set<Map.Entry<K, V>>
/* 119:    */   {
/* 120:    */     private EntrySet()
/* 121:    */     {
/* 122:134 */       super(null);
/* 123:    */     }
/* 124:    */     
/* 125:    */     public int hashCode()
/* 126:    */     {
/* 127:137 */       return Sets.hashCodeImpl(this);
/* 128:    */     }
/* 129:    */     
/* 130:    */     public boolean equals(@Nullable Object obj)
/* 131:    */     {
/* 132:142 */       return Sets.equalsImpl(this, obj);
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   public Set<K> keySet()
/* 137:    */   {
/* 138:152 */     Set<K> result = this.keySet;
/* 139:153 */     return result == null ? (this.keySet = createKeySet()) : result;
/* 140:    */   }
/* 141:    */   
/* 142:    */   Set<K> createKeySet()
/* 143:    */   {
/* 144:157 */     return new Maps.KeySet(asMap());
/* 145:    */   }
/* 146:    */   
/* 147:    */   public Multiset<K> keys()
/* 148:    */   {
/* 149:164 */     Multiset<K> result = this.keys;
/* 150:165 */     return result == null ? (this.keys = createKeys()) : result;
/* 151:    */   }
/* 152:    */   
/* 153:    */   Multiset<K> createKeys()
/* 154:    */   {
/* 155:169 */     return new Multimaps.Keys(this);
/* 156:    */   }
/* 157:    */   
/* 158:    */   public Collection<V> values()
/* 159:    */   {
/* 160:176 */     Collection<V> result = this.values;
/* 161:177 */     return result == null ? (this.values = createValues()) : result;
/* 162:    */   }
/* 163:    */   
/* 164:    */   Collection<V> createValues()
/* 165:    */   {
/* 166:181 */     return new Values();
/* 167:    */   }
/* 168:    */   
/* 169:    */   class Values
/* 170:    */     extends AbstractCollection<V>
/* 171:    */   {
/* 172:    */     Values() {}
/* 173:    */     
/* 174:    */     public Iterator<V> iterator()
/* 175:    */     {
/* 176:188 */       return AbstractMultimap.this.valueIterator();
/* 177:    */     }
/* 178:    */     
/* 179:    */     public int size()
/* 180:    */     {
/* 181:193 */       return AbstractMultimap.this.size();
/* 182:    */     }
/* 183:    */     
/* 184:    */     public boolean contains(@Nullable Object o)
/* 185:    */     {
/* 186:198 */       return AbstractMultimap.this.containsValue(o);
/* 187:    */     }
/* 188:    */     
/* 189:    */     public void clear()
/* 190:    */     {
/* 191:203 */       AbstractMultimap.this.clear();
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   Iterator<V> valueIterator()
/* 196:    */   {
/* 197:208 */     return Maps.valueIterator(entries().iterator());
/* 198:    */   }
/* 199:    */   
/* 200:    */   public Map<K, Collection<V>> asMap()
/* 201:    */   {
/* 202:215 */     Map<K, Collection<V>> result = this.asMap;
/* 203:216 */     return result == null ? (this.asMap = createAsMap()) : result;
/* 204:    */   }
/* 205:    */   
/* 206:    */   abstract Map<K, Collection<V>> createAsMap();
/* 207:    */   
/* 208:    */   public boolean equals(@Nullable Object object)
/* 209:    */   {
/* 210:225 */     return Multimaps.equalsImpl(this, object);
/* 211:    */   }
/* 212:    */   
/* 213:    */   public int hashCode()
/* 214:    */   {
/* 215:238 */     return asMap().hashCode();
/* 216:    */   }
/* 217:    */   
/* 218:    */   public String toString()
/* 219:    */   {
/* 220:249 */     return asMap().toString();
/* 221:    */   }
/* 222:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractMultimap
 * JD-Core Version:    0.7.0.1
 */