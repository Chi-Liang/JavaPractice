/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.lang.reflect.Array;
/*   7:    */ import java.util.Collection;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ public final class ObjectArrays
/*  12:    */ {
/*  13: 37 */   static final Object[] EMPTY_ARRAY = new Object[0];
/*  14:    */   
/*  15:    */   @GwtIncompatible("Array.newInstance(Class, int)")
/*  16:    */   public static <T> T[] newArray(Class<T> type, int length)
/*  17:    */   {
/*  18: 50 */     return (Object[])Array.newInstance(type, length);
/*  19:    */   }
/*  20:    */   
/*  21:    */   public static <T> T[] newArray(T[] reference, int length)
/*  22:    */   {
/*  23: 61 */     return Platform.newArray(reference, length);
/*  24:    */   }
/*  25:    */   
/*  26:    */   @GwtIncompatible("Array.newInstance(Class, int)")
/*  27:    */   public static <T> T[] concat(T[] first, T[] second, Class<T> type)
/*  28:    */   {
/*  29: 73 */     T[] result = newArray(type, first.length + second.length);
/*  30: 74 */     System.arraycopy(first, 0, result, 0, first.length);
/*  31: 75 */     System.arraycopy(second, 0, result, first.length, second.length);
/*  32: 76 */     return result;
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <T> T[] concat(@Nullable T element, T[] array)
/*  36:    */   {
/*  37: 89 */     T[] result = newArray(array, array.length + 1);
/*  38: 90 */     result[0] = element;
/*  39: 91 */     System.arraycopy(array, 0, result, 1, array.length);
/*  40: 92 */     return result;
/*  41:    */   }
/*  42:    */   
/*  43:    */   public static <T> T[] concat(T[] array, @Nullable T element)
/*  44:    */   {
/*  45:105 */     T[] result = arraysCopyOf(array, array.length + 1);
/*  46:106 */     result[array.length] = element;
/*  47:107 */     return result;
/*  48:    */   }
/*  49:    */   
/*  50:    */   static <T> T[] arraysCopyOf(T[] original, int newLength)
/*  51:    */   {
/*  52:112 */     T[] copy = newArray(original, newLength);
/*  53:113 */     System.arraycopy(original, 0, copy, 0, Math.min(original.length, newLength));
/*  54:114 */     return copy;
/*  55:    */   }
/*  56:    */   
/*  57:    */   static <T> T[] toArrayImpl(Collection<?> c, T[] array)
/*  58:    */   {
/*  59:142 */     int size = c.size();
/*  60:143 */     if (array.length < size) {
/*  61:144 */       array = newArray(array, size);
/*  62:    */     }
/*  63:146 */     fillArray(c, array);
/*  64:147 */     if (array.length > size) {
/*  65:148 */       array[size] = null;
/*  66:    */     }
/*  67:150 */     return array;
/*  68:    */   }
/*  69:    */   
/*  70:    */   static <T> T[] toArrayImpl(Object[] src, int offset, int len, T[] dst)
/*  71:    */   {
/*  72:165 */     Preconditions.checkPositionIndexes(offset, offset + len, src.length);
/*  73:166 */     if (dst.length < len) {
/*  74:167 */       dst = newArray(dst, len);
/*  75:168 */     } else if (dst.length > len) {
/*  76:169 */       dst[len] = null;
/*  77:    */     }
/*  78:171 */     System.arraycopy(src, offset, dst, 0, len);
/*  79:172 */     return dst;
/*  80:    */   }
/*  81:    */   
/*  82:    */   static Object[] toArrayImpl(Collection<?> c)
/*  83:    */   {
/*  84:190 */     return fillArray(c, new Object[c.size()]);
/*  85:    */   }
/*  86:    */   
/*  87:    */   static Object[] copyAsObjectArray(Object[] elements, int offset, int length)
/*  88:    */   {
/*  89:198 */     Preconditions.checkPositionIndexes(offset, offset + length, elements.length);
/*  90:199 */     if (length == 0) {
/*  91:200 */       return EMPTY_ARRAY;
/*  92:    */     }
/*  93:202 */     Object[] result = new Object[length];
/*  94:203 */     System.arraycopy(elements, offset, result, 0, length);
/*  95:204 */     return result;
/*  96:    */   }
/*  97:    */   
/*  98:    */   private static Object[] fillArray(Iterable<?> elements, Object[] array)
/*  99:    */   {
/* 100:208 */     int i = 0;
/* 101:209 */     for (Object element : elements) {
/* 102:210 */       array[(i++)] = element;
/* 103:    */     }
/* 104:212 */     return array;
/* 105:    */   }
/* 106:    */   
/* 107:    */   static void swap(Object[] array, int i, int j)
/* 108:    */   {
/* 109:219 */     Object temp = array[i];
/* 110:220 */     array[i] = array[j];
/* 111:221 */     array[j] = temp;
/* 112:    */   }
/* 113:    */   
/* 114:    */   static Object[] checkElementsNotNull(Object... array)
/* 115:    */   {
/* 116:225 */     return checkElementsNotNull(array, array.length);
/* 117:    */   }
/* 118:    */   
/* 119:    */   static Object[] checkElementsNotNull(Object[] array, int length)
/* 120:    */   {
/* 121:229 */     for (int i = 0; i < length; i++) {
/* 122:230 */       checkElementNotNull(array[i], i);
/* 123:    */     }
/* 124:232 */     return array;
/* 125:    */   }
/* 126:    */   
/* 127:    */   static Object checkElementNotNull(Object element, int index)
/* 128:    */   {
/* 129:238 */     if (element == null) {
/* 130:239 */       throw new NullPointerException("at index " + index);
/* 131:    */     }
/* 132:241 */     return element;
/* 133:    */   }
/* 134:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ObjectArrays
 * JD-Core Version:    0.7.0.1
 */