/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import java.util.Set;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ public abstract class ForwardingSetMultimap<K, V>
/* 10:   */   extends ForwardingMultimap<K, V>
/* 11:   */   implements SetMultimap<K, V>
/* 12:   */ {
/* 13:   */   protected abstract SetMultimap<K, V> delegate();
/* 14:   */   
/* 15:   */   public Set<Map.Entry<K, V>> entries()
/* 16:   */   {
/* 17:44 */     return delegate().entries();
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Set<V> get(@Nullable K key)
/* 21:   */   {
/* 22:49 */     return delegate().get(key);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Set<V> removeAll(@Nullable Object key)
/* 26:   */   {
/* 27:54 */     return delegate().removeAll(key);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public Set<V> replaceValues(K key, Iterable<? extends V> values)
/* 31:   */   {
/* 32:59 */     return delegate().replaceValues(key, values);
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingSetMultimap
 * JD-Core Version:    0.7.0.1
 */