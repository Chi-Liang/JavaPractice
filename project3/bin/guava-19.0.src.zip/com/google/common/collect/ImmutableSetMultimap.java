/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.MoreObjects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.j2objc.annotations.Weak;
/*   9:    */ import java.io.IOException;
/*  10:    */ import java.io.InvalidObjectException;
/*  11:    */ import java.io.ObjectInputStream;
/*  12:    */ import java.io.ObjectOutputStream;
/*  13:    */ import java.util.Arrays;
/*  14:    */ import java.util.Collection;
/*  15:    */ import java.util.Comparator;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.Map;
/*  18:    */ import java.util.Map.Entry;
/*  19:    */ import javax.annotation.Nullable;
/*  20:    */ 
/*  21:    */ @GwtCompatible(serializable=true, emulated=true)
/*  22:    */ public class ImmutableSetMultimap<K, V>
/*  23:    */   extends ImmutableMultimap<K, V>
/*  24:    */   implements SetMultimap<K, V>
/*  25:    */ {
/*  26:    */   private final transient ImmutableSet<V> emptySet;
/*  27:    */   private transient ImmutableSetMultimap<V, K> inverse;
/*  28:    */   private transient ImmutableSet<Map.Entry<K, V>> entries;
/*  29:    */   @GwtIncompatible("not needed in emulated source.")
/*  30:    */   private static final long serialVersionUID = 0L;
/*  31:    */   
/*  32:    */   public static <K, V> ImmutableSetMultimap<K, V> of()
/*  33:    */   {
/*  34: 59 */     return EmptyImmutableSetMultimap.INSTANCE;
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1)
/*  38:    */   {
/*  39: 66 */     Builder<K, V> builder = builder();
/*  40: 67 */     builder.put(k1, v1);
/*  41: 68 */     return builder.build();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2)
/*  45:    */   {
/*  46: 77 */     Builder<K, V> builder = builder();
/*  47: 78 */     builder.put(k1, v1);
/*  48: 79 */     builder.put(k2, v2);
/*  49: 80 */     return builder.build();
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  53:    */   {
/*  54: 89 */     Builder<K, V> builder = builder();
/*  55: 90 */     builder.put(k1, v1);
/*  56: 91 */     builder.put(k2, v2);
/*  57: 92 */     builder.put(k3, v3);
/*  58: 93 */     return builder.build();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  62:    */   {
/*  63:103 */     Builder<K, V> builder = builder();
/*  64:104 */     builder.put(k1, v1);
/*  65:105 */     builder.put(k2, v2);
/*  66:106 */     builder.put(k3, v3);
/*  67:107 */     builder.put(k4, v4);
/*  68:108 */     return builder.build();
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static <K, V> ImmutableSetMultimap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  72:    */   {
/*  73:118 */     Builder<K, V> builder = builder();
/*  74:119 */     builder.put(k1, v1);
/*  75:120 */     builder.put(k2, v2);
/*  76:121 */     builder.put(k3, v3);
/*  77:122 */     builder.put(k4, v4);
/*  78:123 */     builder.put(k5, v5);
/*  79:124 */     return builder.build();
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static <K, V> Builder<K, V> builder()
/*  83:    */   {
/*  84:133 */     return new Builder();
/*  85:    */   }
/*  86:    */   
/*  87:    */   public static final class Builder<K, V>
/*  88:    */     extends ImmutableMultimap.Builder<K, V>
/*  89:    */   {
/*  90:    */     public Builder()
/*  91:    */     {
/*  92:160 */       super();
/*  93:    */     }
/*  94:    */     
/*  95:    */     public Builder<K, V> put(K key, V value)
/*  96:    */     {
/*  97:169 */       this.builderMultimap.put(Preconditions.checkNotNull(key), Preconditions.checkNotNull(value));
/*  98:170 */       return this;
/*  99:    */     }
/* 100:    */     
/* 101:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/* 102:    */     {
/* 103:180 */       this.builderMultimap.put(Preconditions.checkNotNull(entry.getKey()), Preconditions.checkNotNull(entry.getValue()));
/* 104:181 */       return this;
/* 105:    */     }
/* 106:    */     
/* 107:    */     @Beta
/* 108:    */     public Builder<K, V> putAll(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/* 109:    */     {
/* 110:192 */       super.putAll(entries);
/* 111:193 */       return this;
/* 112:    */     }
/* 113:    */     
/* 114:    */     public Builder<K, V> putAll(K key, Iterable<? extends V> values)
/* 115:    */     {
/* 116:198 */       Collection<V> collection = this.builderMultimap.get(Preconditions.checkNotNull(key));
/* 117:199 */       for (V value : values) {
/* 118:200 */         collection.add(Preconditions.checkNotNull(value));
/* 119:    */       }
/* 120:202 */       return this;
/* 121:    */     }
/* 122:    */     
/* 123:    */     public Builder<K, V> putAll(K key, V... values)
/* 124:    */     {
/* 125:207 */       return putAll(key, Arrays.asList(values));
/* 126:    */     }
/* 127:    */     
/* 128:    */     public Builder<K, V> putAll(Multimap<? extends K, ? extends V> multimap)
/* 129:    */     {
/* 130:213 */       for (Map.Entry<? extends K, ? extends Collection<? extends V>> entry : multimap.asMap().entrySet()) {
/* 131:214 */         putAll(entry.getKey(), (Iterable)entry.getValue());
/* 132:    */       }
/* 133:216 */       return this;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public Builder<K, V> orderKeysBy(Comparator<? super K> keyComparator)
/* 137:    */     {
/* 138:226 */       this.keyComparator = ((Comparator)Preconditions.checkNotNull(keyComparator));
/* 139:227 */       return this;
/* 140:    */     }
/* 141:    */     
/* 142:    */     public Builder<K, V> orderValuesBy(Comparator<? super V> valueComparator)
/* 143:    */     {
/* 144:244 */       super.orderValuesBy(valueComparator);
/* 145:245 */       return this;
/* 146:    */     }
/* 147:    */     
/* 148:    */     public ImmutableSetMultimap<K, V> build()
/* 149:    */     {
/* 150:253 */       if (this.keyComparator != null)
/* 151:    */       {
/* 152:254 */         Multimap<K, V> sortedCopy = MultimapBuilder.linkedHashKeys().linkedHashSetValues().build();
/* 153:    */         
/* 154:256 */         List<Map.Entry<K, Collection<V>>> entries = Ordering.from(this.keyComparator).onKeys().immutableSortedCopy(this.builderMultimap.asMap().entrySet());
/* 155:260 */         for (Map.Entry<K, Collection<V>> entry : entries) {
/* 156:261 */           sortedCopy.putAll(entry.getKey(), (Iterable)entry.getValue());
/* 157:    */         }
/* 158:263 */         this.builderMultimap = sortedCopy;
/* 159:    */       }
/* 160:265 */       return ImmutableSetMultimap.copyOf(this.builderMultimap, this.valueComparator);
/* 161:    */     }
/* 162:    */   }
/* 163:    */   
/* 164:    */   public static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap)
/* 165:    */   {
/* 166:285 */     return copyOf(multimap, null);
/* 167:    */   }
/* 168:    */   
/* 169:    */   private static <K, V> ImmutableSetMultimap<K, V> copyOf(Multimap<? extends K, ? extends V> multimap, Comparator<? super V> valueComparator)
/* 170:    */   {
/* 171:290 */     Preconditions.checkNotNull(multimap);
/* 172:291 */     if ((multimap.isEmpty()) && (valueComparator == null)) {
/* 173:292 */       return of();
/* 174:    */     }
/* 175:295 */     if ((multimap instanceof ImmutableSetMultimap))
/* 176:    */     {
/* 177:297 */       ImmutableSetMultimap<K, V> kvMultimap = (ImmutableSetMultimap)multimap;
/* 178:298 */       if (!kvMultimap.isPartialView()) {
/* 179:299 */         return kvMultimap;
/* 180:    */       }
/* 181:    */     }
/* 182:303 */     ImmutableMap.Builder<K, ImmutableSet<V>> builder = new ImmutableMap.Builder(multimap.asMap().size());
/* 183:    */     
/* 184:305 */     int size = 0;
/* 185:308 */     for (Map.Entry<? extends K, ? extends Collection<? extends V>> entry : multimap.asMap().entrySet())
/* 186:    */     {
/* 187:309 */       K key = entry.getKey();
/* 188:310 */       Collection<? extends V> values = (Collection)entry.getValue();
/* 189:311 */       ImmutableSet<V> set = valueSet(valueComparator, values);
/* 190:312 */       if (!set.isEmpty())
/* 191:    */       {
/* 192:313 */         builder.put(key, set);
/* 193:314 */         size += set.size();
/* 194:    */       }
/* 195:    */     }
/* 196:318 */     return new ImmutableSetMultimap(builder.build(), size, valueComparator);
/* 197:    */   }
/* 198:    */   
/* 199:    */   @Beta
/* 200:    */   public static <K, V> ImmutableSetMultimap<K, V> copyOf(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/* 201:    */   {
/* 202:334 */     return new Builder().putAll(entries).build();
/* 203:    */   }
/* 204:    */   
/* 205:    */   ImmutableSetMultimap(ImmutableMap<K, ImmutableSet<V>> map, int size, @Nullable Comparator<? super V> valueComparator)
/* 206:    */   {
/* 207:347 */     super(map, size);
/* 208:348 */     this.emptySet = emptySet(valueComparator);
/* 209:    */   }
/* 210:    */   
/* 211:    */   public ImmutableSet<V> get(@Nullable K key)
/* 212:    */   {
/* 213:362 */     ImmutableSet<V> set = (ImmutableSet)this.map.get(key);
/* 214:363 */     return (ImmutableSet)MoreObjects.firstNonNull(set, this.emptySet);
/* 215:    */   }
/* 216:    */   
/* 217:    */   public ImmutableSetMultimap<V, K> inverse()
/* 218:    */   {
/* 219:379 */     ImmutableSetMultimap<V, K> result = this.inverse;
/* 220:380 */     return result == null ? (this.inverse = invert()) : result;
/* 221:    */   }
/* 222:    */   
/* 223:    */   private ImmutableSetMultimap<V, K> invert()
/* 224:    */   {
/* 225:384 */     Builder<V, K> builder = builder();
/* 226:385 */     for (Map.Entry<K, V> entry : entries()) {
/* 227:386 */       builder.put(entry.getValue(), entry.getKey());
/* 228:    */     }
/* 229:388 */     ImmutableSetMultimap<V, K> invertedMultimap = builder.build();
/* 230:389 */     invertedMultimap.inverse = this;
/* 231:390 */     return invertedMultimap;
/* 232:    */   }
/* 233:    */   
/* 234:    */   @Deprecated
/* 235:    */   public ImmutableSet<V> removeAll(Object key)
/* 236:    */   {
/* 237:402 */     throw new UnsupportedOperationException();
/* 238:    */   }
/* 239:    */   
/* 240:    */   @Deprecated
/* 241:    */   public ImmutableSet<V> replaceValues(K key, Iterable<? extends V> values)
/* 242:    */   {
/* 243:414 */     throw new UnsupportedOperationException();
/* 244:    */   }
/* 245:    */   
/* 246:    */   public ImmutableSet<Map.Entry<K, V>> entries()
/* 247:    */   {
/* 248:426 */     ImmutableSet<Map.Entry<K, V>> result = this.entries;
/* 249:427 */     return result == null ? (this.entries = new EntrySet(this)) : result;
/* 250:    */   }
/* 251:    */   
/* 252:    */   private static final class EntrySet<K, V>
/* 253:    */     extends ImmutableSet<Map.Entry<K, V>>
/* 254:    */   {
/* 255:    */     @Weak
/* 256:    */     private final transient ImmutableSetMultimap<K, V> multimap;
/* 257:    */     
/* 258:    */     EntrySet(ImmutableSetMultimap<K, V> multimap)
/* 259:    */     {
/* 260:436 */       this.multimap = multimap;
/* 261:    */     }
/* 262:    */     
/* 263:    */     public boolean contains(@Nullable Object object)
/* 264:    */     {
/* 265:441 */       if ((object instanceof Map.Entry))
/* 266:    */       {
/* 267:442 */         Map.Entry<?, ?> entry = (Map.Entry)object;
/* 268:443 */         return this.multimap.containsEntry(entry.getKey(), entry.getValue());
/* 269:    */       }
/* 270:445 */       return false;
/* 271:    */     }
/* 272:    */     
/* 273:    */     public int size()
/* 274:    */     {
/* 275:450 */       return this.multimap.size();
/* 276:    */     }
/* 277:    */     
/* 278:    */     public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/* 279:    */     {
/* 280:455 */       return this.multimap.entryIterator();
/* 281:    */     }
/* 282:    */     
/* 283:    */     boolean isPartialView()
/* 284:    */     {
/* 285:460 */       return false;
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   private static <V> ImmutableSet<V> valueSet(@Nullable Comparator<? super V> valueComparator, Collection<? extends V> values)
/* 290:    */   {
/* 291:466 */     return valueComparator == null ? ImmutableSet.copyOf(values) : ImmutableSortedSet.copyOf(valueComparator, values);
/* 292:    */   }
/* 293:    */   
/* 294:    */   private static <V> ImmutableSet<V> emptySet(@Nullable Comparator<? super V> valueComparator)
/* 295:    */   {
/* 296:472 */     return valueComparator == null ? ImmutableSet.of() : ImmutableSortedSet.emptySet(valueComparator);
/* 297:    */   }
/* 298:    */   
/* 299:    */   private static <V> ImmutableSet.Builder<V> valuesBuilder(@Nullable Comparator<? super V> valueComparator)
/* 300:    */   {
/* 301:479 */     return valueComparator == null ? new ImmutableSet.Builder() : new ImmutableSortedSet.Builder(valueComparator);
/* 302:    */   }
/* 303:    */   
/* 304:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/* 305:    */   private void writeObject(ObjectOutputStream stream)
/* 306:    */     throws IOException
/* 307:    */   {
/* 308:490 */     stream.defaultWriteObject();
/* 309:491 */     stream.writeObject(valueComparator());
/* 310:492 */     Serialization.writeMultimap(this, stream);
/* 311:    */   }
/* 312:    */   
/* 313:    */   @Nullable
/* 314:    */   Comparator<? super V> valueComparator()
/* 315:    */   {
/* 316:497 */     return (this.emptySet instanceof ImmutableSortedSet) ? ((ImmutableSortedSet)this.emptySet).comparator() : null;
/* 317:    */   }
/* 318:    */   
/* 319:    */   @GwtIncompatible("java.io.ObjectInputStream")
/* 320:    */   private void readObject(ObjectInputStream stream)
/* 321:    */     throws IOException, ClassNotFoundException
/* 322:    */   {
/* 323:506 */     stream.defaultReadObject();
/* 324:507 */     Comparator<Object> valueComparator = (Comparator)stream.readObject();
/* 325:508 */     int keyCount = stream.readInt();
/* 326:509 */     if (keyCount < 0) {
/* 327:510 */       throw new InvalidObjectException("Invalid key count " + keyCount);
/* 328:    */     }
/* 329:512 */     ImmutableMap.Builder<Object, ImmutableSet<Object>> builder = ImmutableMap.builder();
/* 330:513 */     int tmpSize = 0;
/* 331:515 */     for (int i = 0; i < keyCount; i++)
/* 332:    */     {
/* 333:516 */       Object key = stream.readObject();
/* 334:517 */       int valueCount = stream.readInt();
/* 335:518 */       if (valueCount <= 0) {
/* 336:519 */         throw new InvalidObjectException("Invalid value count " + valueCount);
/* 337:    */       }
/* 338:522 */       ImmutableSet.Builder<Object> valuesBuilder = valuesBuilder(valueComparator);
/* 339:523 */       for (int j = 0; j < valueCount; j++) {
/* 340:524 */         valuesBuilder.add(stream.readObject());
/* 341:    */       }
/* 342:526 */       ImmutableSet<Object> valueSet = valuesBuilder.build();
/* 343:527 */       if (valueSet.size() != valueCount) {
/* 344:528 */         throw new InvalidObjectException("Duplicate key-value pairs exist for key " + key);
/* 345:    */       }
/* 346:530 */       builder.put(key, valueSet);
/* 347:531 */       tmpSize += valueCount;
/* 348:    */     }
/* 349:    */     ImmutableMap<Object, ImmutableSet<Object>> tmpMap;
/* 350:    */     try
/* 351:    */     {
/* 352:536 */       tmpMap = builder.build();
/* 353:    */     }
/* 354:    */     catch (IllegalArgumentException e)
/* 355:    */     {
/* 356:538 */       throw ((InvalidObjectException)new InvalidObjectException(e.getMessage()).initCause(e));
/* 357:    */     }
/* 358:541 */     ImmutableMultimap.FieldSettersHolder.MAP_FIELD_SETTER.set(this, tmpMap);
/* 359:542 */     ImmutableMultimap.FieldSettersHolder.SIZE_FIELD_SETTER.set(this, tmpSize);
/* 360:543 */     ImmutableMultimap.FieldSettersHolder.EMPTY_SET_FIELD_SETTER.set(this, emptySet(valueComparator));
/* 361:    */   }
/* 362:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableSetMultimap
 * JD-Core Version:    0.7.0.1
 */