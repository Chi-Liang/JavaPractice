/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible(serializable=true)
/*  8:   */ final class NullsLastOrdering<T>
/*  9:   */   extends Ordering<T>
/* 10:   */   implements Serializable
/* 11:   */ {
/* 12:   */   final Ordering<? super T> ordering;
/* 13:   */   private static final long serialVersionUID = 0L;
/* 14:   */   
/* 15:   */   NullsLastOrdering(Ordering<? super T> ordering)
/* 16:   */   {
/* 17:31 */     this.ordering = ordering;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public int compare(@Nullable T left, @Nullable T right)
/* 21:   */   {
/* 22:36 */     if (left == right) {
/* 23:37 */       return 0;
/* 24:   */     }
/* 25:39 */     if (left == null) {
/* 26:40 */       return 1;
/* 27:   */     }
/* 28:42 */     if (right == null) {
/* 29:43 */       return -1;
/* 30:   */     }
/* 31:45 */     return this.ordering.compare(left, right);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public <S extends T> Ordering<S> reverse()
/* 35:   */   {
/* 36:51 */     return this.ordering.reverse().nullsFirst();
/* 37:   */   }
/* 38:   */   
/* 39:   */   public <S extends T> Ordering<S> nullsFirst()
/* 40:   */   {
/* 41:56 */     return this.ordering.nullsFirst();
/* 42:   */   }
/* 43:   */   
/* 44:   */   public <S extends T> Ordering<S> nullsLast()
/* 45:   */   {
/* 46:62 */     return this;
/* 47:   */   }
/* 48:   */   
/* 49:   */   public boolean equals(@Nullable Object object)
/* 50:   */   {
/* 51:67 */     if (object == this) {
/* 52:68 */       return true;
/* 53:   */     }
/* 54:70 */     if ((object instanceof NullsLastOrdering))
/* 55:   */     {
/* 56:71 */       NullsLastOrdering<?> that = (NullsLastOrdering)object;
/* 57:72 */       return this.ordering.equals(that.ordering);
/* 58:   */     }
/* 59:74 */     return false;
/* 60:   */   }
/* 61:   */   
/* 62:   */   public int hashCode()
/* 63:   */   {
/* 64:79 */     return this.ordering.hashCode() ^ 0xC9177248;
/* 65:   */   }
/* 66:   */   
/* 67:   */   public String toString()
/* 68:   */   {
/* 69:84 */     return this.ordering + ".nullsLast()";
/* 70:   */   }
/* 71:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.NullsLastOrdering
 * JD-Core Version:    0.7.0.1
 */