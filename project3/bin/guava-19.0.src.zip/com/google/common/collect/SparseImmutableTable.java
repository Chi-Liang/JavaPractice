/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.LinkedHashMap;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import javax.annotation.concurrent.Immutable;
/*   8:    */ 
/*   9:    */ @GwtCompatible
/*  10:    */ @Immutable
/*  11:    */ final class SparseImmutableTable<R, C, V>
/*  12:    */   extends RegularImmutableTable<R, C, V>
/*  13:    */ {
/*  14:    */   private final ImmutableMap<R, Map<C, V>> rowMap;
/*  15:    */   private final ImmutableMap<C, Map<R, V>> columnMap;
/*  16:    */   private final int[] iterationOrderRow;
/*  17:    */   private final int[] iterationOrderColumn;
/*  18:    */   
/*  19:    */   SparseImmutableTable(ImmutableList<Table.Cell<R, C, V>> cellList, ImmutableSet<R> rowSpace, ImmutableSet<C> columnSpace)
/*  20:    */   {
/*  21: 40 */     Map<R, Integer> rowIndex = Maps.indexMap(rowSpace);
/*  22: 41 */     Map<R, Map<C, V>> rows = Maps.newLinkedHashMap();
/*  23: 42 */     for (R row : rowSpace) {
/*  24: 43 */       rows.put(row, new LinkedHashMap());
/*  25:    */     }
/*  26: 45 */     Map<C, Map<R, V>> columns = Maps.newLinkedHashMap();
/*  27: 46 */     for (C col : columnSpace) {
/*  28: 47 */       columns.put(col, new LinkedHashMap());
/*  29:    */     }
/*  30: 49 */     int[] iterationOrderRow = new int[cellList.size()];
/*  31: 50 */     int[] iterationOrderColumn = new int[cellList.size()];
/*  32: 51 */     for (int i = 0; i < cellList.size(); i++)
/*  33:    */     {
/*  34: 52 */       Table.Cell<R, C, V> cell = (Table.Cell)cellList.get(i);
/*  35: 53 */       R rowKey = cell.getRowKey();
/*  36: 54 */       C columnKey = cell.getColumnKey();
/*  37: 55 */       V value = cell.getValue();
/*  38:    */       
/*  39: 57 */       iterationOrderRow[i] = ((Integer)rowIndex.get(rowKey)).intValue();
/*  40: 58 */       Map<C, V> thisRow = (Map)rows.get(rowKey);
/*  41: 59 */       iterationOrderColumn[i] = thisRow.size();
/*  42: 60 */       V oldValue = thisRow.put(columnKey, value);
/*  43: 61 */       if (oldValue != null) {
/*  44: 62 */         throw new IllegalArgumentException("Duplicate value for row=" + rowKey + ", column=" + columnKey + ": " + value + ", " + oldValue);
/*  45:    */       }
/*  46: 66 */       ((Map)columns.get(columnKey)).put(rowKey, value);
/*  47:    */     }
/*  48: 68 */     this.iterationOrderRow = iterationOrderRow;
/*  49: 69 */     this.iterationOrderColumn = iterationOrderColumn;
/*  50: 70 */     ImmutableMap.Builder<R, Map<C, V>> rowBuilder = new ImmutableMap.Builder(rows.size());
/*  51: 72 */     for (Map.Entry<R, Map<C, V>> row : rows.entrySet()) {
/*  52: 73 */       rowBuilder.put(row.getKey(), ImmutableMap.copyOf((Map)row.getValue()));
/*  53:    */     }
/*  54: 75 */     this.rowMap = rowBuilder.build();
/*  55:    */     
/*  56: 77 */     ImmutableMap.Builder<C, Map<R, V>> columnBuilder = new ImmutableMap.Builder(columns.size());
/*  57: 79 */     for (Map.Entry<C, Map<R, V>> col : columns.entrySet()) {
/*  58: 80 */       columnBuilder.put(col.getKey(), ImmutableMap.copyOf((Map)col.getValue()));
/*  59:    */     }
/*  60: 82 */     this.columnMap = columnBuilder.build();
/*  61:    */   }
/*  62:    */   
/*  63:    */   public ImmutableMap<C, Map<R, V>> columnMap()
/*  64:    */   {
/*  65: 87 */     return this.columnMap;
/*  66:    */   }
/*  67:    */   
/*  68:    */   public ImmutableMap<R, Map<C, V>> rowMap()
/*  69:    */   {
/*  70: 92 */     return this.rowMap;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public int size()
/*  74:    */   {
/*  75: 97 */     return this.iterationOrderRow.length;
/*  76:    */   }
/*  77:    */   
/*  78:    */   Table.Cell<R, C, V> getCell(int index)
/*  79:    */   {
/*  80:102 */     int rowIndex = this.iterationOrderRow[index];
/*  81:103 */     Map.Entry<R, Map<C, V>> rowEntry = (Map.Entry)this.rowMap.entrySet().asList().get(rowIndex);
/*  82:104 */     ImmutableMap<C, V> row = (ImmutableMap)rowEntry.getValue();
/*  83:105 */     int columnIndex = this.iterationOrderColumn[index];
/*  84:106 */     Map.Entry<C, V> colEntry = (Map.Entry)row.entrySet().asList().get(columnIndex);
/*  85:107 */     return cellOf(rowEntry.getKey(), colEntry.getKey(), colEntry.getValue());
/*  86:    */   }
/*  87:    */   
/*  88:    */   V getValue(int index)
/*  89:    */   {
/*  90:112 */     int rowIndex = this.iterationOrderRow[index];
/*  91:113 */     ImmutableMap<C, V> row = (ImmutableMap)this.rowMap.values().asList().get(rowIndex);
/*  92:114 */     int columnIndex = this.iterationOrderColumn[index];
/*  93:115 */     return row.values().asList().get(columnIndex);
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.SparseImmutableTable
 * JD-Core Version:    0.7.0.1
 */