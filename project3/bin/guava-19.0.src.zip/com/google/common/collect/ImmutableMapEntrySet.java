/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.j2objc.annotations.Weak;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ abstract class ImmutableMapEntrySet<K, V>
/*  12:    */   extends ImmutableSet<Map.Entry<K, V>>
/*  13:    */ {
/*  14:    */   abstract ImmutableMap<K, V> map();
/*  15:    */   
/*  16:    */   static final class RegularEntrySet<K, V>
/*  17:    */     extends ImmutableMapEntrySet<K, V>
/*  18:    */   {
/*  19:    */     @Weak
/*  20:    */     private final transient ImmutableMap<K, V> map;
/*  21:    */     private final transient Map.Entry<K, V>[] entries;
/*  22:    */     
/*  23:    */     RegularEntrySet(ImmutableMap<K, V> map, Map.Entry<K, V>[] entries)
/*  24:    */     {
/*  25: 41 */       this.map = map;
/*  26: 42 */       this.entries = entries;
/*  27:    */     }
/*  28:    */     
/*  29:    */     ImmutableMap<K, V> map()
/*  30:    */     {
/*  31: 47 */       return this.map;
/*  32:    */     }
/*  33:    */     
/*  34:    */     public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/*  35:    */     {
/*  36: 52 */       return asList().iterator();
/*  37:    */     }
/*  38:    */     
/*  39:    */     ImmutableList<Map.Entry<K, V>> createAsList()
/*  40:    */     {
/*  41: 57 */       return new RegularImmutableAsList(this, this.entries);
/*  42:    */     }
/*  43:    */   }
/*  44:    */   
/*  45:    */   public int size()
/*  46:    */   {
/*  47: 67 */     return map().size();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public boolean contains(@Nullable Object object)
/*  51:    */   {
/*  52: 72 */     if ((object instanceof Map.Entry))
/*  53:    */     {
/*  54: 73 */       Map.Entry<?, ?> entry = (Map.Entry)object;
/*  55: 74 */       V value = map().get(entry.getKey());
/*  56: 75 */       return (value != null) && (value.equals(entry.getValue()));
/*  57:    */     }
/*  58: 77 */     return false;
/*  59:    */   }
/*  60:    */   
/*  61:    */   boolean isPartialView()
/*  62:    */   {
/*  63: 82 */     return map().isPartialView();
/*  64:    */   }
/*  65:    */   
/*  66:    */   @GwtIncompatible("not used in GWT")
/*  67:    */   boolean isHashCodeFast()
/*  68:    */   {
/*  69: 88 */     return map().isHashCodeFast();
/*  70:    */   }
/*  71:    */   
/*  72:    */   public int hashCode()
/*  73:    */   {
/*  74: 93 */     return map().hashCode();
/*  75:    */   }
/*  76:    */   
/*  77:    */   @GwtIncompatible("serialization")
/*  78:    */   Object writeReplace()
/*  79:    */   {
/*  80: 99 */     return new EntrySetSerializedForm(map());
/*  81:    */   }
/*  82:    */   
/*  83:    */   @GwtIncompatible("serialization")
/*  84:    */   private static class EntrySetSerializedForm<K, V>
/*  85:    */     implements Serializable
/*  86:    */   {
/*  87:    */     final ImmutableMap<K, V> map;
/*  88:    */     private static final long serialVersionUID = 0L;
/*  89:    */     
/*  90:    */     EntrySetSerializedForm(ImmutableMap<K, V> map)
/*  91:    */     {
/*  92:107 */       this.map = map;
/*  93:    */     }
/*  94:    */     
/*  95:    */     Object readResolve()
/*  96:    */     {
/*  97:111 */       return this.map.entrySet();
/*  98:    */     }
/*  99:    */   }
/* 100:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableMapEntrySet
 * JD-Core Version:    0.7.0.1
 */