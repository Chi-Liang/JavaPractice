/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible
/*  8:   */ final class Count
/*  9:   */   implements Serializable
/* 10:   */ {
/* 11:   */   private int value;
/* 12:   */   
/* 13:   */   Count(int value)
/* 14:   */   {
/* 15:33 */     this.value = value;
/* 16:   */   }
/* 17:   */   
/* 18:   */   public int get()
/* 19:   */   {
/* 20:37 */     return this.value;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public int getAndAdd(int delta)
/* 24:   */   {
/* 25:41 */     int result = this.value;
/* 26:42 */     this.value = (result + delta);
/* 27:43 */     return result;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public int addAndGet(int delta)
/* 31:   */   {
/* 32:47 */     return this.value += delta;
/* 33:   */   }
/* 34:   */   
/* 35:   */   public void set(int newValue)
/* 36:   */   {
/* 37:51 */     this.value = newValue;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public int getAndSet(int newValue)
/* 41:   */   {
/* 42:55 */     int result = this.value;
/* 43:56 */     this.value = newValue;
/* 44:57 */     return result;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public int hashCode()
/* 48:   */   {
/* 49:62 */     return this.value;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public boolean equals(@Nullable Object obj)
/* 53:   */   {
/* 54:67 */     return ((obj instanceof Count)) && (((Count)obj).value == this.value);
/* 55:   */   }
/* 56:   */   
/* 57:   */   public String toString()
/* 58:   */   {
/* 59:72 */     return Integer.toString(this.value);
/* 60:   */   }
/* 61:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Count
 * JD-Core Version:    0.7.0.1
 */