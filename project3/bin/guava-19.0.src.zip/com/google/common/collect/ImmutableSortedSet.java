/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.InvalidObjectException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.Serializable;
/*   9:    */ import java.util.Arrays;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.NavigableSet;
/*  14:    */ import java.util.SortedSet;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ @GwtCompatible(serializable=true, emulated=true)
/*  18:    */ public abstract class ImmutableSortedSet<E>
/*  19:    */   extends ImmutableSortedSetFauxverideShim<E>
/*  20:    */   implements NavigableSet<E>, SortedIterable<E>
/*  21:    */ {
/*  22: 62 */   private static final Comparator<Comparable> NATURAL_ORDER = ;
/*  23: 64 */   private static final RegularImmutableSortedSet<Comparable> NATURAL_EMPTY_SET = new RegularImmutableSortedSet(ImmutableList.of(), NATURAL_ORDER);
/*  24:    */   final transient Comparator<? super E> comparator;
/*  25:    */   @GwtIncompatible("NavigableSet")
/*  26:    */   transient ImmutableSortedSet<E> descendingSet;
/*  27:    */   
/*  28:    */   static <E> RegularImmutableSortedSet<E> emptySet(Comparator<? super E> comparator)
/*  29:    */   {
/*  30: 68 */     if (NATURAL_ORDER.equals(comparator)) {
/*  31: 69 */       return NATURAL_EMPTY_SET;
/*  32:    */     }
/*  33: 71 */     return new RegularImmutableSortedSet(ImmutableList.of(), comparator);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static <E> ImmutableSortedSet<E> of()
/*  37:    */   {
/*  38: 79 */     return NATURAL_EMPTY_SET;
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E element)
/*  42:    */   {
/*  43: 86 */     return new RegularImmutableSortedSet(ImmutableList.of(element), Ordering.natural());
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2)
/*  47:    */   {
/*  48: 98 */     return construct(Ordering.natural(), 2, new Comparable[] { e1, e2 });
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3)
/*  52:    */   {
/*  53:110 */     return construct(Ordering.natural(), 3, new Comparable[] { e1, e2, e3 });
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4)
/*  57:    */   {
/*  58:122 */     return construct(Ordering.natural(), 4, new Comparable[] { e1, e2, e3, e4 });
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4, E e5)
/*  62:    */   {
/*  63:135 */     return construct(Ordering.natural(), 5, new Comparable[] { e1, e2, e3, e4, e5 });
/*  64:    */   }
/*  65:    */   
/*  66:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... remaining)
/*  67:    */   {
/*  68:149 */     Comparable[] contents = new Comparable[6 + remaining.length];
/*  69:150 */     contents[0] = e1;
/*  70:151 */     contents[1] = e2;
/*  71:152 */     contents[2] = e3;
/*  72:153 */     contents[3] = e4;
/*  73:154 */     contents[4] = e5;
/*  74:155 */     contents[5] = e6;
/*  75:156 */     System.arraycopy(remaining, 0, contents, 6, remaining.length);
/*  76:157 */     return construct(Ordering.natural(), contents.length, (Comparable[])contents);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static <E extends Comparable<? super E>> ImmutableSortedSet<E> copyOf(E[] elements)
/*  80:    */   {
/*  81:171 */     return construct(Ordering.natural(), elements.length, (Object[])elements.clone());
/*  82:    */   }
/*  83:    */   
/*  84:    */   public static <E> ImmutableSortedSet<E> copyOf(Iterable<? extends E> elements)
/*  85:    */   {
/*  86:204 */     Ordering<E> naturalOrder = Ordering.natural();
/*  87:205 */     return copyOf(naturalOrder, elements);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static <E> ImmutableSortedSet<E> copyOf(Collection<? extends E> elements)
/*  91:    */   {
/*  92:241 */     Ordering<E> naturalOrder = Ordering.natural();
/*  93:242 */     return copyOf(naturalOrder, elements);
/*  94:    */   }
/*  95:    */   
/*  96:    */   public static <E> ImmutableSortedSet<E> copyOf(Iterator<? extends E> elements)
/*  97:    */   {
/*  98:260 */     Ordering<E> naturalOrder = Ordering.natural();
/*  99:261 */     return copyOf(naturalOrder, elements);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Iterator<? extends E> elements)
/* 103:    */   {
/* 104:275 */     return new Builder(comparator).addAll(elements).build();
/* 105:    */   }
/* 106:    */   
/* 107:    */   public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Iterable<? extends E> elements)
/* 108:    */   {
/* 109:293 */     Preconditions.checkNotNull(comparator);
/* 110:294 */     boolean hasSameComparator = SortedIterables.hasSameComparator(comparator, elements);
/* 111:296 */     if ((hasSameComparator) && ((elements instanceof ImmutableSortedSet)))
/* 112:    */     {
/* 113:298 */       ImmutableSortedSet<E> original = (ImmutableSortedSet)elements;
/* 114:299 */       if (!original.isPartialView()) {
/* 115:300 */         return original;
/* 116:    */       }
/* 117:    */     }
/* 118:304 */     E[] array = (Object[])Iterables.toArray(elements);
/* 119:305 */     return construct(comparator, array.length, array);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public static <E> ImmutableSortedSet<E> copyOf(Comparator<? super E> comparator, Collection<? extends E> elements)
/* 123:    */   {
/* 124:328 */     return copyOf(comparator, elements);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public static <E> ImmutableSortedSet<E> copyOfSorted(SortedSet<E> sortedSet)
/* 128:    */   {
/* 129:349 */     Comparator<? super E> comparator = SortedIterables.comparator(sortedSet);
/* 130:350 */     ImmutableList<E> list = ImmutableList.copyOf(sortedSet);
/* 131:351 */     if (list.isEmpty()) {
/* 132:352 */       return emptySet(comparator);
/* 133:    */     }
/* 134:354 */     return new RegularImmutableSortedSet(list, comparator);
/* 135:    */   }
/* 136:    */   
/* 137:    */   static <E> ImmutableSortedSet<E> construct(Comparator<? super E> comparator, int n, E... contents)
/* 138:    */   {
/* 139:372 */     if (n == 0) {
/* 140:373 */       return emptySet(comparator);
/* 141:    */     }
/* 142:375 */     ObjectArrays.checkElementsNotNull(contents, n);
/* 143:376 */     Arrays.sort(contents, 0, n, comparator);
/* 144:377 */     int uniques = 1;
/* 145:378 */     for (int i = 1; i < n; i++)
/* 146:    */     {
/* 147:379 */       E cur = contents[i];
/* 148:380 */       E prev = contents[(uniques - 1)];
/* 149:381 */       if (comparator.compare(cur, prev) != 0) {
/* 150:382 */         contents[(uniques++)] = cur;
/* 151:    */       }
/* 152:    */     }
/* 153:385 */     Arrays.fill(contents, uniques, n, null);
/* 154:386 */     return new RegularImmutableSortedSet(ImmutableList.asImmutableList(contents, uniques), comparator);
/* 155:    */   }
/* 156:    */   
/* 157:    */   public static <E> Builder<E> orderedBy(Comparator<E> comparator)
/* 158:    */   {
/* 159:399 */     return new Builder(comparator);
/* 160:    */   }
/* 161:    */   
/* 162:    */   public static <E extends Comparable<?>> Builder<E> reverseOrder()
/* 163:    */   {
/* 164:407 */     return new Builder(Ordering.natural().reverse());
/* 165:    */   }
/* 166:    */   
/* 167:    */   public static <E extends Comparable<?>> Builder<E> naturalOrder()
/* 168:    */   {
/* 169:418 */     return new Builder(Ordering.natural());
/* 170:    */   }
/* 171:    */   
/* 172:    */   public static final class Builder<E>
/* 173:    */     extends ImmutableSet.Builder<E>
/* 174:    */   {
/* 175:    */     private final Comparator<? super E> comparator;
/* 176:    */     
/* 177:    */     public Builder(Comparator<? super E> comparator)
/* 178:    */     {
/* 179:446 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/* 180:    */     }
/* 181:    */     
/* 182:    */     public Builder<E> add(E element)
/* 183:    */     {
/* 184:461 */       super.add(element);
/* 185:462 */       return this;
/* 186:    */     }
/* 187:    */     
/* 188:    */     public Builder<E> add(E... elements)
/* 189:    */     {
/* 190:475 */       super.add(elements);
/* 191:476 */       return this;
/* 192:    */     }
/* 193:    */     
/* 194:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 195:    */     {
/* 196:489 */       super.addAll(elements);
/* 197:490 */       return this;
/* 198:    */     }
/* 199:    */     
/* 200:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 201:    */     {
/* 202:503 */       super.addAll(elements);
/* 203:504 */       return this;
/* 204:    */     }
/* 205:    */     
/* 206:    */     public ImmutableSortedSet<E> build()
/* 207:    */     {
/* 208:514 */       E[] contentsArray = (Object[])this.contents;
/* 209:515 */       ImmutableSortedSet<E> result = ImmutableSortedSet.construct(this.comparator, this.size, contentsArray);
/* 210:516 */       this.size = result.size();
/* 211:517 */       return result;
/* 212:    */     }
/* 213:    */   }
/* 214:    */   
/* 215:    */   int unsafeCompare(Object a, Object b)
/* 216:    */   {
/* 217:522 */     return unsafeCompare(this.comparator, a, b);
/* 218:    */   }
/* 219:    */   
/* 220:    */   static int unsafeCompare(Comparator<?> comparator, Object a, Object b)
/* 221:    */   {
/* 222:530 */     Comparator<Object> unsafeComparator = comparator;
/* 223:531 */     return unsafeComparator.compare(a, b);
/* 224:    */   }
/* 225:    */   
/* 226:    */   ImmutableSortedSet(Comparator<? super E> comparator)
/* 227:    */   {
/* 228:537 */     this.comparator = comparator;
/* 229:    */   }
/* 230:    */   
/* 231:    */   public Comparator<? super E> comparator()
/* 232:    */   {
/* 233:549 */     return this.comparator;
/* 234:    */   }
/* 235:    */   
/* 236:    */   public abstract UnmodifiableIterator<E> iterator();
/* 237:    */   
/* 238:    */   public ImmutableSortedSet<E> headSet(E toElement)
/* 239:    */   {
/* 240:568 */     return headSet(toElement, false);
/* 241:    */   }
/* 242:    */   
/* 243:    */   @GwtIncompatible("NavigableSet")
/* 244:    */   public ImmutableSortedSet<E> headSet(E toElement, boolean inclusive)
/* 245:    */   {
/* 246:577 */     return headSetImpl(Preconditions.checkNotNull(toElement), inclusive);
/* 247:    */   }
/* 248:    */   
/* 249:    */   public ImmutableSortedSet<E> subSet(E fromElement, E toElement)
/* 250:    */   {
/* 251:595 */     return subSet(fromElement, true, toElement, false);
/* 252:    */   }
/* 253:    */   
/* 254:    */   @GwtIncompatible("NavigableSet")
/* 255:    */   public ImmutableSortedSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 256:    */   {
/* 257:605 */     Preconditions.checkNotNull(fromElement);
/* 258:606 */     Preconditions.checkNotNull(toElement);
/* 259:607 */     Preconditions.checkArgument(this.comparator.compare(fromElement, toElement) <= 0);
/* 260:608 */     return subSetImpl(fromElement, fromInclusive, toElement, toInclusive);
/* 261:    */   }
/* 262:    */   
/* 263:    */   public ImmutableSortedSet<E> tailSet(E fromElement)
/* 264:    */   {
/* 265:624 */     return tailSet(fromElement, true);
/* 266:    */   }
/* 267:    */   
/* 268:    */   @GwtIncompatible("NavigableSet")
/* 269:    */   public ImmutableSortedSet<E> tailSet(E fromElement, boolean inclusive)
/* 270:    */   {
/* 271:633 */     return tailSetImpl(Preconditions.checkNotNull(fromElement), inclusive);
/* 272:    */   }
/* 273:    */   
/* 274:    */   abstract ImmutableSortedSet<E> headSetImpl(E paramE, boolean paramBoolean);
/* 275:    */   
/* 276:    */   abstract ImmutableSortedSet<E> subSetImpl(E paramE1, boolean paramBoolean1, E paramE2, boolean paramBoolean2);
/* 277:    */   
/* 278:    */   abstract ImmutableSortedSet<E> tailSetImpl(E paramE, boolean paramBoolean);
/* 279:    */   
/* 280:    */   @GwtIncompatible("NavigableSet")
/* 281:    */   public E lower(E e)
/* 282:    */   {
/* 283:653 */     return Iterators.getNext(headSet(e, false).descendingIterator(), null);
/* 284:    */   }
/* 285:    */   
/* 286:    */   @GwtIncompatible("NavigableSet")
/* 287:    */   public E floor(E e)
/* 288:    */   {
/* 289:662 */     return Iterators.getNext(headSet(e, true).descendingIterator(), null);
/* 290:    */   }
/* 291:    */   
/* 292:    */   @GwtIncompatible("NavigableSet")
/* 293:    */   public E ceiling(E e)
/* 294:    */   {
/* 295:671 */     return Iterables.getFirst(tailSet(e, true), null);
/* 296:    */   }
/* 297:    */   
/* 298:    */   @GwtIncompatible("NavigableSet")
/* 299:    */   public E higher(E e)
/* 300:    */   {
/* 301:680 */     return Iterables.getFirst(tailSet(e, false), null);
/* 302:    */   }
/* 303:    */   
/* 304:    */   public E first()
/* 305:    */   {
/* 306:685 */     return iterator().next();
/* 307:    */   }
/* 308:    */   
/* 309:    */   public E last()
/* 310:    */   {
/* 311:690 */     return descendingIterator().next();
/* 312:    */   }
/* 313:    */   
/* 314:    */   @Deprecated
/* 315:    */   @GwtIncompatible("NavigableSet")
/* 316:    */   public final E pollFirst()
/* 317:    */   {
/* 318:704 */     throw new UnsupportedOperationException();
/* 319:    */   }
/* 320:    */   
/* 321:    */   @Deprecated
/* 322:    */   @GwtIncompatible("NavigableSet")
/* 323:    */   public final E pollLast()
/* 324:    */   {
/* 325:718 */     throw new UnsupportedOperationException();
/* 326:    */   }
/* 327:    */   
/* 328:    */   @GwtIncompatible("NavigableSet")
/* 329:    */   public ImmutableSortedSet<E> descendingSet()
/* 330:    */   {
/* 331:731 */     ImmutableSortedSet<E> result = this.descendingSet;
/* 332:732 */     if (result == null)
/* 333:    */     {
/* 334:733 */       result = this.descendingSet = createDescendingSet();
/* 335:734 */       result.descendingSet = this;
/* 336:    */     }
/* 337:736 */     return result;
/* 338:    */   }
/* 339:    */   
/* 340:    */   @GwtIncompatible("NavigableSet")
/* 341:    */   ImmutableSortedSet<E> createDescendingSet()
/* 342:    */   {
/* 343:741 */     return new DescendingImmutableSortedSet(this);
/* 344:    */   }
/* 345:    */   
/* 346:    */   @GwtIncompatible("NavigableSet")
/* 347:    */   public abstract UnmodifiableIterator<E> descendingIterator();
/* 348:    */   
/* 349:    */   abstract int indexOf(@Nullable Object paramObject);
/* 350:    */   
/* 351:    */   private static class SerializedForm<E>
/* 352:    */     implements Serializable
/* 353:    */   {
/* 354:    */     final Comparator<? super E> comparator;
/* 355:    */     final Object[] elements;
/* 356:    */     private static final long serialVersionUID = 0L;
/* 357:    */     
/* 358:    */     public SerializedForm(Comparator<? super E> comparator, Object[] elements)
/* 359:    */     {
/* 360:767 */       this.comparator = comparator;
/* 361:768 */       this.elements = elements;
/* 362:    */     }
/* 363:    */     
/* 364:    */     Object readResolve()
/* 365:    */     {
/* 366:773 */       return new ImmutableSortedSet.Builder(this.comparator).add((Object[])this.elements).build();
/* 367:    */     }
/* 368:    */   }
/* 369:    */   
/* 370:    */   private void readObject(ObjectInputStream stream)
/* 371:    */     throws InvalidObjectException
/* 372:    */   {
/* 373:780 */     throw new InvalidObjectException("Use SerializedForm");
/* 374:    */   }
/* 375:    */   
/* 376:    */   Object writeReplace()
/* 377:    */   {
/* 378:785 */     return new SerializedForm(this.comparator, toArray());
/* 379:    */   }
/* 380:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedSet
 * JD-Core Version:    0.7.0.1
 */