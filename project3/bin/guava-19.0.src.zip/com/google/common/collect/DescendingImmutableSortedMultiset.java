/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import javax.annotation.Nullable;
/*  4:   */ 
/*  5:   */ final class DescendingImmutableSortedMultiset<E>
/*  6:   */   extends ImmutableSortedMultiset<E>
/*  7:   */ {
/*  8:   */   private final transient ImmutableSortedMultiset<E> forward;
/*  9:   */   
/* 10:   */   DescendingImmutableSortedMultiset(ImmutableSortedMultiset<E> forward)
/* 11:   */   {
/* 12:29 */     this.forward = forward;
/* 13:   */   }
/* 14:   */   
/* 15:   */   public int count(@Nullable Object element)
/* 16:   */   {
/* 17:34 */     return this.forward.count(element);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Multiset.Entry<E> firstEntry()
/* 21:   */   {
/* 22:39 */     return this.forward.lastEntry();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Multiset.Entry<E> lastEntry()
/* 26:   */   {
/* 27:44 */     return this.forward.firstEntry();
/* 28:   */   }
/* 29:   */   
/* 30:   */   public int size()
/* 31:   */   {
/* 32:49 */     return this.forward.size();
/* 33:   */   }
/* 34:   */   
/* 35:   */   public ImmutableSortedSet<E> elementSet()
/* 36:   */   {
/* 37:54 */     return this.forward.elementSet().descendingSet();
/* 38:   */   }
/* 39:   */   
/* 40:   */   Multiset.Entry<E> getEntry(int index)
/* 41:   */   {
/* 42:59 */     return (Multiset.Entry)this.forward.entrySet().asList().reverse().get(index);
/* 43:   */   }
/* 44:   */   
/* 45:   */   public ImmutableSortedMultiset<E> descendingMultiset()
/* 46:   */   {
/* 47:68 */     return this.forward;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public ImmutableSortedMultiset<E> headMultiset(E upperBound, BoundType boundType)
/* 51:   */   {
/* 52:73 */     return this.forward.tailMultiset(upperBound, boundType).descendingMultiset();
/* 53:   */   }
/* 54:   */   
/* 55:   */   public ImmutableSortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType)
/* 56:   */   {
/* 57:78 */     return this.forward.headMultiset(lowerBound, boundType).descendingMultiset();
/* 58:   */   }
/* 59:   */   
/* 60:   */   boolean isPartialView()
/* 61:   */   {
/* 62:83 */     return this.forward.isPartialView();
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.DescendingImmutableSortedMultiset
 * JD-Core Version:    0.7.0.1
 */