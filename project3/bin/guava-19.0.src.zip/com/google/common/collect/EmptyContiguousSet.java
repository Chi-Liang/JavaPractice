/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.NoSuchElementException;
/*   7:    */ import java.util.Set;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ final class EmptyContiguousSet<C extends Comparable>
/*  12:    */   extends ContiguousSet<C>
/*  13:    */ {
/*  14:    */   EmptyContiguousSet(DiscreteDomain<C> domain)
/*  15:    */   {
/*  16: 34 */     super(domain);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public C first()
/*  20:    */   {
/*  21: 39 */     throw new NoSuchElementException();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public C last()
/*  25:    */   {
/*  26: 44 */     throw new NoSuchElementException();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public int size()
/*  30:    */   {
/*  31: 49 */     return 0;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public ContiguousSet<C> intersection(ContiguousSet<C> other)
/*  35:    */   {
/*  36: 54 */     return this;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Range<C> range()
/*  40:    */   {
/*  41: 59 */     throw new NoSuchElementException();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Range<C> range(BoundType lowerBoundType, BoundType upperBoundType)
/*  45:    */   {
/*  46: 64 */     throw new NoSuchElementException();
/*  47:    */   }
/*  48:    */   
/*  49:    */   ContiguousSet<C> headSetImpl(C toElement, boolean inclusive)
/*  50:    */   {
/*  51: 69 */     return this;
/*  52:    */   }
/*  53:    */   
/*  54:    */   ContiguousSet<C> subSetImpl(C fromElement, boolean fromInclusive, C toElement, boolean toInclusive)
/*  55:    */   {
/*  56: 75 */     return this;
/*  57:    */   }
/*  58:    */   
/*  59:    */   ContiguousSet<C> tailSetImpl(C fromElement, boolean fromInclusive)
/*  60:    */   {
/*  61: 80 */     return this;
/*  62:    */   }
/*  63:    */   
/*  64:    */   public boolean contains(Object object)
/*  65:    */   {
/*  66: 85 */     return false;
/*  67:    */   }
/*  68:    */   
/*  69:    */   @GwtIncompatible("not used by GWT emulation")
/*  70:    */   int indexOf(Object target)
/*  71:    */   {
/*  72: 91 */     return -1;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public UnmodifiableIterator<C> iterator()
/*  76:    */   {
/*  77: 96 */     return Iterators.emptyIterator();
/*  78:    */   }
/*  79:    */   
/*  80:    */   @GwtIncompatible("NavigableSet")
/*  81:    */   public UnmodifiableIterator<C> descendingIterator()
/*  82:    */   {
/*  83:102 */     return Iterators.emptyIterator();
/*  84:    */   }
/*  85:    */   
/*  86:    */   boolean isPartialView()
/*  87:    */   {
/*  88:107 */     return false;
/*  89:    */   }
/*  90:    */   
/*  91:    */   public boolean isEmpty()
/*  92:    */   {
/*  93:112 */     return true;
/*  94:    */   }
/*  95:    */   
/*  96:    */   public ImmutableList<C> asList()
/*  97:    */   {
/*  98:117 */     return ImmutableList.of();
/*  99:    */   }
/* 100:    */   
/* 101:    */   public String toString()
/* 102:    */   {
/* 103:122 */     return "[]";
/* 104:    */   }
/* 105:    */   
/* 106:    */   public boolean equals(@Nullable Object object)
/* 107:    */   {
/* 108:127 */     if ((object instanceof Set))
/* 109:    */     {
/* 110:128 */       Set<?> that = (Set)object;
/* 111:129 */       return that.isEmpty();
/* 112:    */     }
/* 113:131 */     return false;
/* 114:    */   }
/* 115:    */   
/* 116:    */   @GwtIncompatible("not used in GWT")
/* 117:    */   boolean isHashCodeFast()
/* 118:    */   {
/* 119:137 */     return true;
/* 120:    */   }
/* 121:    */   
/* 122:    */   public int hashCode()
/* 123:    */   {
/* 124:142 */     return 0;
/* 125:    */   }
/* 126:    */   
/* 127:    */   @GwtIncompatible("serialization")
/* 128:    */   private static final class SerializedForm<C extends Comparable>
/* 129:    */     implements Serializable
/* 130:    */   {
/* 131:    */     private final DiscreteDomain<C> domain;
/* 132:    */     private static final long serialVersionUID = 0L;
/* 133:    */     
/* 134:    */     private SerializedForm(DiscreteDomain<C> domain)
/* 135:    */     {
/* 136:150 */       this.domain = domain;
/* 137:    */     }
/* 138:    */     
/* 139:    */     private Object readResolve()
/* 140:    */     {
/* 141:154 */       return new EmptyContiguousSet(this.domain);
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   @GwtIncompatible("serialization")
/* 146:    */   Object writeReplace()
/* 147:    */   {
/* 148:163 */     return new SerializedForm(this.domain, null);
/* 149:    */   }
/* 150:    */   
/* 151:    */   @GwtIncompatible("NavigableSet")
/* 152:    */   ImmutableSortedSet<C> createDescendingSet()
/* 153:    */   {
/* 154:168 */     return ImmutableSortedSet.emptySet(Ordering.natural().reverse());
/* 155:    */   }
/* 156:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.EmptyContiguousSet
 * JD-Core Version:    0.7.0.1
 */