/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ abstract class ImmutableSortedSetFauxverideShim<E>
/*   4:    */   extends ImmutableSet<E>
/*   5:    */ {
/*   6:    */   @Deprecated
/*   7:    */   public static <E> ImmutableSortedSet.Builder<E> builder()
/*   8:    */   {
/*   9: 47 */     throw new UnsupportedOperationException();
/*  10:    */   }
/*  11:    */   
/*  12:    */   @Deprecated
/*  13:    */   public static <E> ImmutableSortedSet<E> of(E element)
/*  14:    */   {
/*  15: 61 */     throw new UnsupportedOperationException();
/*  16:    */   }
/*  17:    */   
/*  18:    */   @Deprecated
/*  19:    */   public static <E> ImmutableSortedSet<E> of(E e1, E e2)
/*  20:    */   {
/*  21: 75 */     throw new UnsupportedOperationException();
/*  22:    */   }
/*  23:    */   
/*  24:    */   @Deprecated
/*  25:    */   public static <E> ImmutableSortedSet<E> of(E e1, E e2, E e3)
/*  26:    */   {
/*  27: 89 */     throw new UnsupportedOperationException();
/*  28:    */   }
/*  29:    */   
/*  30:    */   @Deprecated
/*  31:    */   public static <E> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4)
/*  32:    */   {
/*  33:104 */     throw new UnsupportedOperationException();
/*  34:    */   }
/*  35:    */   
/*  36:    */   @Deprecated
/*  37:    */   public static <E> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4, E e5)
/*  38:    */   {
/*  39:119 */     throw new UnsupportedOperationException();
/*  40:    */   }
/*  41:    */   
/*  42:    */   @Deprecated
/*  43:    */   public static <E> ImmutableSortedSet<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... remaining)
/*  44:    */   {
/*  45:134 */     throw new UnsupportedOperationException();
/*  46:    */   }
/*  47:    */   
/*  48:    */   @Deprecated
/*  49:    */   public static <E> ImmutableSortedSet<E> copyOf(E[] elements)
/*  50:    */   {
/*  51:148 */     throw new UnsupportedOperationException();
/*  52:    */   }
/*  53:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedSetFauxverideShim
 * JD-Core Version:    0.7.0.1
 */