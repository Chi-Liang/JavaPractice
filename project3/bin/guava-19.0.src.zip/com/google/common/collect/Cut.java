/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.primitives.Booleans;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.NoSuchElementException;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ abstract class Cut<C extends Comparable>
/*  12:    */   implements Comparable<Cut<C>>, Serializable
/*  13:    */ {
/*  14:    */   final C endpoint;
/*  15:    */   private static final long serialVersionUID = 0L;
/*  16:    */   
/*  17:    */   Cut(@Nullable C endpoint)
/*  18:    */   {
/*  19: 41 */     this.endpoint = endpoint;
/*  20:    */   }
/*  21:    */   
/*  22:    */   abstract boolean isLessThan(C paramC);
/*  23:    */   
/*  24:    */   abstract BoundType typeAsLowerBound();
/*  25:    */   
/*  26:    */   abstract BoundType typeAsUpperBound();
/*  27:    */   
/*  28:    */   abstract Cut<C> withLowerBoundType(BoundType paramBoundType, DiscreteDomain<C> paramDiscreteDomain);
/*  29:    */   
/*  30:    */   abstract Cut<C> withUpperBoundType(BoundType paramBoundType, DiscreteDomain<C> paramDiscreteDomain);
/*  31:    */   
/*  32:    */   abstract void describeAsLowerBound(StringBuilder paramStringBuilder);
/*  33:    */   
/*  34:    */   abstract void describeAsUpperBound(StringBuilder paramStringBuilder);
/*  35:    */   
/*  36:    */   abstract C leastValueAbove(DiscreteDomain<C> paramDiscreteDomain);
/*  37:    */   
/*  38:    */   abstract C greatestValueBelow(DiscreteDomain<C> paramDiscreteDomain);
/*  39:    */   
/*  40:    */   Cut<C> canonical(DiscreteDomain<C> domain)
/*  41:    */   {
/*  42: 67 */     return this;
/*  43:    */   }
/*  44:    */   
/*  45:    */   public int compareTo(Cut<C> that)
/*  46:    */   {
/*  47: 73 */     if (that == belowAll()) {
/*  48: 74 */       return 1;
/*  49:    */     }
/*  50: 76 */     if (that == aboveAll()) {
/*  51: 77 */       return -1;
/*  52:    */     }
/*  53: 79 */     int result = Range.compareOrThrow(this.endpoint, that.endpoint);
/*  54: 80 */     if (result != 0) {
/*  55: 81 */       return result;
/*  56:    */     }
/*  57: 84 */     return Booleans.compare(this instanceof AboveValue, that instanceof AboveValue);
/*  58:    */   }
/*  59:    */   
/*  60:    */   C endpoint()
/*  61:    */   {
/*  62: 88 */     return this.endpoint;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public boolean equals(Object obj)
/*  66:    */   {
/*  67: 94 */     if ((obj instanceof Cut))
/*  68:    */     {
/*  69: 96 */       Cut<C> that = (Cut)obj;
/*  70:    */       try
/*  71:    */       {
/*  72: 98 */         int compareResult = compareTo(that);
/*  73: 99 */         return compareResult == 0;
/*  74:    */       }
/*  75:    */       catch (ClassCastException ignored) {}
/*  76:    */     }
/*  77:103 */     return false;
/*  78:    */   }
/*  79:    */   
/*  80:    */   static <C extends Comparable> Cut<C> belowAll()
/*  81:    */   {
/*  82:112 */     return BelowAll.INSTANCE;
/*  83:    */   }
/*  84:    */   
/*  85:    */   private static final class BelowAll
/*  86:    */     extends Cut<Comparable<?>>
/*  87:    */   {
/*  88:118 */     private static final BelowAll INSTANCE = new BelowAll();
/*  89:    */     private static final long serialVersionUID = 0L;
/*  90:    */     
/*  91:    */     private BelowAll()
/*  92:    */     {
/*  93:121 */       super();
/*  94:    */     }
/*  95:    */     
/*  96:    */     Comparable<?> endpoint()
/*  97:    */     {
/*  98:126 */       throw new IllegalStateException("range unbounded on this side");
/*  99:    */     }
/* 100:    */     
/* 101:    */     boolean isLessThan(Comparable<?> value)
/* 102:    */     {
/* 103:131 */       return true;
/* 104:    */     }
/* 105:    */     
/* 106:    */     BoundType typeAsLowerBound()
/* 107:    */     {
/* 108:136 */       throw new IllegalStateException();
/* 109:    */     }
/* 110:    */     
/* 111:    */     BoundType typeAsUpperBound()
/* 112:    */     {
/* 113:141 */       throw new AssertionError("this statement should be unreachable");
/* 114:    */     }
/* 115:    */     
/* 116:    */     Cut<Comparable<?>> withLowerBoundType(BoundType boundType, DiscreteDomain<Comparable<?>> domain)
/* 117:    */     {
/* 118:147 */       throw new IllegalStateException();
/* 119:    */     }
/* 120:    */     
/* 121:    */     Cut<Comparable<?>> withUpperBoundType(BoundType boundType, DiscreteDomain<Comparable<?>> domain)
/* 122:    */     {
/* 123:153 */       throw new AssertionError("this statement should be unreachable");
/* 124:    */     }
/* 125:    */     
/* 126:    */     void describeAsLowerBound(StringBuilder sb)
/* 127:    */     {
/* 128:158 */       sb.append("(-∞");
/* 129:    */     }
/* 130:    */     
/* 131:    */     void describeAsUpperBound(StringBuilder sb)
/* 132:    */     {
/* 133:163 */       throw new AssertionError();
/* 134:    */     }
/* 135:    */     
/* 136:    */     Comparable<?> leastValueAbove(DiscreteDomain<Comparable<?>> domain)
/* 137:    */     {
/* 138:168 */       return domain.minValue();
/* 139:    */     }
/* 140:    */     
/* 141:    */     Comparable<?> greatestValueBelow(DiscreteDomain<Comparable<?>> domain)
/* 142:    */     {
/* 143:173 */       throw new AssertionError();
/* 144:    */     }
/* 145:    */     
/* 146:    */     Cut<Comparable<?>> canonical(DiscreteDomain<Comparable<?>> domain)
/* 147:    */     {
/* 148:    */       try
/* 149:    */       {
/* 150:179 */         return Cut.belowValue(domain.minValue());
/* 151:    */       }
/* 152:    */       catch (NoSuchElementException e) {}
/* 153:181 */       return this;
/* 154:    */     }
/* 155:    */     
/* 156:    */     public int compareTo(Cut<Comparable<?>> o)
/* 157:    */     {
/* 158:187 */       return o == this ? 0 : -1;
/* 159:    */     }
/* 160:    */     
/* 161:    */     public String toString()
/* 162:    */     {
/* 163:192 */       return "-∞";
/* 164:    */     }
/* 165:    */     
/* 166:    */     private Object readResolve()
/* 167:    */     {
/* 168:196 */       return INSTANCE;
/* 169:    */     }
/* 170:    */   }
/* 171:    */   
/* 172:    */   static <C extends Comparable> Cut<C> aboveAll()
/* 173:    */   {
/* 174:208 */     return AboveAll.INSTANCE;
/* 175:    */   }
/* 176:    */   
/* 177:    */   private static final class AboveAll
/* 178:    */     extends Cut<Comparable<?>>
/* 179:    */   {
/* 180:212 */     private static final AboveAll INSTANCE = new AboveAll();
/* 181:    */     private static final long serialVersionUID = 0L;
/* 182:    */     
/* 183:    */     private AboveAll()
/* 184:    */     {
/* 185:215 */       super();
/* 186:    */     }
/* 187:    */     
/* 188:    */     Comparable<?> endpoint()
/* 189:    */     {
/* 190:220 */       throw new IllegalStateException("range unbounded on this side");
/* 191:    */     }
/* 192:    */     
/* 193:    */     boolean isLessThan(Comparable<?> value)
/* 194:    */     {
/* 195:225 */       return false;
/* 196:    */     }
/* 197:    */     
/* 198:    */     BoundType typeAsLowerBound()
/* 199:    */     {
/* 200:230 */       throw new AssertionError("this statement should be unreachable");
/* 201:    */     }
/* 202:    */     
/* 203:    */     BoundType typeAsUpperBound()
/* 204:    */     {
/* 205:235 */       throw new IllegalStateException();
/* 206:    */     }
/* 207:    */     
/* 208:    */     Cut<Comparable<?>> withLowerBoundType(BoundType boundType, DiscreteDomain<Comparable<?>> domain)
/* 209:    */     {
/* 210:241 */       throw new AssertionError("this statement should be unreachable");
/* 211:    */     }
/* 212:    */     
/* 213:    */     Cut<Comparable<?>> withUpperBoundType(BoundType boundType, DiscreteDomain<Comparable<?>> domain)
/* 214:    */     {
/* 215:247 */       throw new IllegalStateException();
/* 216:    */     }
/* 217:    */     
/* 218:    */     void describeAsLowerBound(StringBuilder sb)
/* 219:    */     {
/* 220:252 */       throw new AssertionError();
/* 221:    */     }
/* 222:    */     
/* 223:    */     void describeAsUpperBound(StringBuilder sb)
/* 224:    */     {
/* 225:257 */       sb.append("+∞)");
/* 226:    */     }
/* 227:    */     
/* 228:    */     Comparable<?> leastValueAbove(DiscreteDomain<Comparable<?>> domain)
/* 229:    */     {
/* 230:262 */       throw new AssertionError();
/* 231:    */     }
/* 232:    */     
/* 233:    */     Comparable<?> greatestValueBelow(DiscreteDomain<Comparable<?>> domain)
/* 234:    */     {
/* 235:267 */       return domain.maxValue();
/* 236:    */     }
/* 237:    */     
/* 238:    */     public int compareTo(Cut<Comparable<?>> o)
/* 239:    */     {
/* 240:272 */       return o == this ? 0 : 1;
/* 241:    */     }
/* 242:    */     
/* 243:    */     public String toString()
/* 244:    */     {
/* 245:277 */       return "+∞";
/* 246:    */     }
/* 247:    */     
/* 248:    */     private Object readResolve()
/* 249:    */     {
/* 250:281 */       return INSTANCE;
/* 251:    */     }
/* 252:    */   }
/* 253:    */   
/* 254:    */   static <C extends Comparable> Cut<C> belowValue(C endpoint)
/* 255:    */   {
/* 256:288 */     return new BelowValue(endpoint);
/* 257:    */   }
/* 258:    */   
/* 259:    */   private static final class BelowValue<C extends Comparable>
/* 260:    */     extends Cut<C>
/* 261:    */   {
/* 262:    */     private static final long serialVersionUID = 0L;
/* 263:    */     
/* 264:    */     BelowValue(C endpoint)
/* 265:    */     {
/* 266:293 */       super();
/* 267:    */     }
/* 268:    */     
/* 269:    */     boolean isLessThan(C value)
/* 270:    */     {
/* 271:298 */       return Range.compareOrThrow(this.endpoint, value) <= 0;
/* 272:    */     }
/* 273:    */     
/* 274:    */     BoundType typeAsLowerBound()
/* 275:    */     {
/* 276:303 */       return BoundType.CLOSED;
/* 277:    */     }
/* 278:    */     
/* 279:    */     BoundType typeAsUpperBound()
/* 280:    */     {
/* 281:308 */       return BoundType.OPEN;
/* 282:    */     }
/* 283:    */     
/* 284:    */     Cut<C> withLowerBoundType(BoundType boundType, DiscreteDomain<C> domain)
/* 285:    */     {
/* 286:313 */       switch (Cut.1.$SwitchMap$com$google$common$collect$BoundType[boundType.ordinal()])
/* 287:    */       {
/* 288:    */       case 1: 
/* 289:315 */         return this;
/* 290:    */       case 2: 
/* 291:317 */         C previous = domain.previous(this.endpoint);
/* 292:318 */         return previous == null ? Cut.belowAll() : new Cut.AboveValue(previous);
/* 293:    */       }
/* 294:320 */       throw new AssertionError();
/* 295:    */     }
/* 296:    */     
/* 297:    */     Cut<C> withUpperBoundType(BoundType boundType, DiscreteDomain<C> domain)
/* 298:    */     {
/* 299:326 */       switch (Cut.1.$SwitchMap$com$google$common$collect$BoundType[boundType.ordinal()])
/* 300:    */       {
/* 301:    */       case 1: 
/* 302:328 */         C previous = domain.previous(this.endpoint);
/* 303:329 */         return previous == null ? Cut.aboveAll() : new Cut.AboveValue(previous);
/* 304:    */       case 2: 
/* 305:331 */         return this;
/* 306:    */       }
/* 307:333 */       throw new AssertionError();
/* 308:    */     }
/* 309:    */     
/* 310:    */     void describeAsLowerBound(StringBuilder sb)
/* 311:    */     {
/* 312:339 */       sb.append('[').append(this.endpoint);
/* 313:    */     }
/* 314:    */     
/* 315:    */     void describeAsUpperBound(StringBuilder sb)
/* 316:    */     {
/* 317:344 */       sb.append(this.endpoint).append(')');
/* 318:    */     }
/* 319:    */     
/* 320:    */     C leastValueAbove(DiscreteDomain<C> domain)
/* 321:    */     {
/* 322:349 */       return this.endpoint;
/* 323:    */     }
/* 324:    */     
/* 325:    */     C greatestValueBelow(DiscreteDomain<C> domain)
/* 326:    */     {
/* 327:354 */       return domain.previous(this.endpoint);
/* 328:    */     }
/* 329:    */     
/* 330:    */     public int hashCode()
/* 331:    */     {
/* 332:359 */       return this.endpoint.hashCode();
/* 333:    */     }
/* 334:    */     
/* 335:    */     public String toString()
/* 336:    */     {
/* 337:364 */       return "\\" + this.endpoint + "/";
/* 338:    */     }
/* 339:    */   }
/* 340:    */   
/* 341:    */   static <C extends Comparable> Cut<C> aboveValue(C endpoint)
/* 342:    */   {
/* 343:371 */     return new AboveValue(endpoint);
/* 344:    */   }
/* 345:    */   
/* 346:    */   private static final class AboveValue<C extends Comparable>
/* 347:    */     extends Cut<C>
/* 348:    */   {
/* 349:    */     private static final long serialVersionUID = 0L;
/* 350:    */     
/* 351:    */     AboveValue(C endpoint)
/* 352:    */     {
/* 353:376 */       super();
/* 354:    */     }
/* 355:    */     
/* 356:    */     boolean isLessThan(C value)
/* 357:    */     {
/* 358:381 */       return Range.compareOrThrow(this.endpoint, value) < 0;
/* 359:    */     }
/* 360:    */     
/* 361:    */     BoundType typeAsLowerBound()
/* 362:    */     {
/* 363:386 */       return BoundType.OPEN;
/* 364:    */     }
/* 365:    */     
/* 366:    */     BoundType typeAsUpperBound()
/* 367:    */     {
/* 368:391 */       return BoundType.CLOSED;
/* 369:    */     }
/* 370:    */     
/* 371:    */     Cut<C> withLowerBoundType(BoundType boundType, DiscreteDomain<C> domain)
/* 372:    */     {
/* 373:396 */       switch (Cut.1.$SwitchMap$com$google$common$collect$BoundType[boundType.ordinal()])
/* 374:    */       {
/* 375:    */       case 2: 
/* 376:398 */         return this;
/* 377:    */       case 1: 
/* 378:400 */         C next = domain.next(this.endpoint);
/* 379:401 */         return next == null ? Cut.belowAll() : belowValue(next);
/* 380:    */       }
/* 381:403 */       throw new AssertionError();
/* 382:    */     }
/* 383:    */     
/* 384:    */     Cut<C> withUpperBoundType(BoundType boundType, DiscreteDomain<C> domain)
/* 385:    */     {
/* 386:409 */       switch (Cut.1.$SwitchMap$com$google$common$collect$BoundType[boundType.ordinal()])
/* 387:    */       {
/* 388:    */       case 2: 
/* 389:411 */         C next = domain.next(this.endpoint);
/* 390:412 */         return next == null ? Cut.aboveAll() : belowValue(next);
/* 391:    */       case 1: 
/* 392:414 */         return this;
/* 393:    */       }
/* 394:416 */       throw new AssertionError();
/* 395:    */     }
/* 396:    */     
/* 397:    */     void describeAsLowerBound(StringBuilder sb)
/* 398:    */     {
/* 399:422 */       sb.append('(').append(this.endpoint);
/* 400:    */     }
/* 401:    */     
/* 402:    */     void describeAsUpperBound(StringBuilder sb)
/* 403:    */     {
/* 404:427 */       sb.append(this.endpoint).append(']');
/* 405:    */     }
/* 406:    */     
/* 407:    */     C leastValueAbove(DiscreteDomain<C> domain)
/* 408:    */     {
/* 409:432 */       return domain.next(this.endpoint);
/* 410:    */     }
/* 411:    */     
/* 412:    */     C greatestValueBelow(DiscreteDomain<C> domain)
/* 413:    */     {
/* 414:437 */       return this.endpoint;
/* 415:    */     }
/* 416:    */     
/* 417:    */     Cut<C> canonical(DiscreteDomain<C> domain)
/* 418:    */     {
/* 419:442 */       C next = leastValueAbove(domain);
/* 420:443 */       return next != null ? belowValue(next) : Cut.aboveAll();
/* 421:    */     }
/* 422:    */     
/* 423:    */     public int hashCode()
/* 424:    */     {
/* 425:448 */       return this.endpoint.hashCode() ^ 0xFFFFFFFF;
/* 426:    */     }
/* 427:    */     
/* 428:    */     public String toString()
/* 429:    */     {
/* 430:453 */       return "/" + this.endpoint + "\\";
/* 431:    */     }
/* 432:    */   }
/* 433:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Cut
 * JD-Core Version:    0.7.0.1
 */