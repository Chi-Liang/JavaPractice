/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ 
/*  6:   */ @GwtCompatible(serializable=true, emulated=true)
/*  7:   */ final class SingletonImmutableList<E>
/*  8:   */   extends ImmutableList<E>
/*  9:   */ {
/* 10:   */   final transient E element;
/* 11:   */   
/* 12:   */   SingletonImmutableList(E element)
/* 13:   */   {
/* 14:36 */     this.element = Preconditions.checkNotNull(element);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public E get(int index)
/* 18:   */   {
/* 19:41 */     Preconditions.checkElementIndex(index, 1);
/* 20:42 */     return this.element;
/* 21:   */   }
/* 22:   */   
/* 23:   */   public UnmodifiableIterator<E> iterator()
/* 24:   */   {
/* 25:47 */     return Iterators.singletonIterator(this.element);
/* 26:   */   }
/* 27:   */   
/* 28:   */   public int size()
/* 29:   */   {
/* 30:52 */     return 1;
/* 31:   */   }
/* 32:   */   
/* 33:   */   public ImmutableList<E> subList(int fromIndex, int toIndex)
/* 34:   */   {
/* 35:57 */     Preconditions.checkPositionIndexes(fromIndex, toIndex, 1);
/* 36:58 */     return fromIndex == toIndex ? ImmutableList.of() : this;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public String toString()
/* 40:   */   {
/* 41:63 */     String elementToString = this.element.toString();
/* 42:64 */     return elementToString.length() + 2 + '[' + elementToString + ']';
/* 43:   */   }
/* 44:   */   
/* 45:   */   boolean isPartialView()
/* 46:   */   {
/* 47:73 */     return false;
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.SingletonImmutableList
 * JD-Core Version:    0.7.0.1
 */