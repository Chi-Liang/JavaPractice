/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.Map.Entry;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible(serializable=true, emulated=true)
/*  8:   */ final class SingletonImmutableBiMap<K, V>
/*  9:   */   extends ImmutableBiMap<K, V>
/* 10:   */ {
/* 11:   */   final transient K singleKey;
/* 12:   */   final transient V singleValue;
/* 13:   */   transient ImmutableBiMap<V, K> inverse;
/* 14:   */   
/* 15:   */   SingletonImmutableBiMap(K singleKey, V singleValue)
/* 16:   */   {
/* 17:39 */     CollectPreconditions.checkEntryNotNull(singleKey, singleValue);
/* 18:40 */     this.singleKey = singleKey;
/* 19:41 */     this.singleValue = singleValue;
/* 20:   */   }
/* 21:   */   
/* 22:   */   private SingletonImmutableBiMap(K singleKey, V singleValue, ImmutableBiMap<V, K> inverse)
/* 23:   */   {
/* 24:45 */     this.singleKey = singleKey;
/* 25:46 */     this.singleValue = singleValue;
/* 26:47 */     this.inverse = inverse;
/* 27:   */   }
/* 28:   */   
/* 29:   */   public V get(@Nullable Object key)
/* 30:   */   {
/* 31:52 */     return this.singleKey.equals(key) ? this.singleValue : null;
/* 32:   */   }
/* 33:   */   
/* 34:   */   public int size()
/* 35:   */   {
/* 36:57 */     return 1;
/* 37:   */   }
/* 38:   */   
/* 39:   */   public boolean containsKey(@Nullable Object key)
/* 40:   */   {
/* 41:62 */     return this.singleKey.equals(key);
/* 42:   */   }
/* 43:   */   
/* 44:   */   public boolean containsValue(@Nullable Object value)
/* 45:   */   {
/* 46:67 */     return this.singleValue.equals(value);
/* 47:   */   }
/* 48:   */   
/* 49:   */   boolean isPartialView()
/* 50:   */   {
/* 51:72 */     return false;
/* 52:   */   }
/* 53:   */   
/* 54:   */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 55:   */   {
/* 56:77 */     return ImmutableSet.of(Maps.immutableEntry(this.singleKey, this.singleValue));
/* 57:   */   }
/* 58:   */   
/* 59:   */   ImmutableSet<K> createKeySet()
/* 60:   */   {
/* 61:82 */     return ImmutableSet.of(this.singleKey);
/* 62:   */   }
/* 63:   */   
/* 64:   */   public ImmutableBiMap<V, K> inverse()
/* 65:   */   {
/* 66:90 */     ImmutableBiMap<V, K> result = this.inverse;
/* 67:91 */     if (result == null) {
/* 68:92 */       return this.inverse = new SingletonImmutableBiMap(this.singleValue, this.singleKey, this);
/* 69:   */     }
/* 70:94 */     return result;
/* 71:   */   }
/* 72:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.SingletonImmutableBiMap
 * JD-Core Version:    0.7.0.1
 */