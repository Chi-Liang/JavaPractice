/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.math.IntMath;
/*   7:    */ import com.google.j2objc.annotations.Weak;
/*   8:    */ import java.util.AbstractQueue;
/*   9:    */ import java.util.ArrayDeque;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Collection;
/*  12:    */ import java.util.Collections;
/*  13:    */ import java.util.Comparator;
/*  14:    */ import java.util.ConcurrentModificationException;
/*  15:    */ import java.util.Iterator;
/*  16:    */ import java.util.List;
/*  17:    */ import java.util.NoSuchElementException;
/*  18:    */ import java.util.Queue;
/*  19:    */ 
/*  20:    */ @Beta
/*  21:    */ public final class MinMaxPriorityQueue<E>
/*  22:    */   extends AbstractQueue<E>
/*  23:    */ {
/*  24:    */   private final MinMaxPriorityQueue<E>.Heap minHeap;
/*  25:    */   private final MinMaxPriorityQueue<E>.Heap maxHeap;
/*  26:    */   @VisibleForTesting
/*  27:    */   final int maximumSize;
/*  28:    */   private Object[] queue;
/*  29:    */   private int size;
/*  30:    */   private int modCount;
/*  31:    */   private static final int EVEN_POWERS_OF_TWO = 1431655765;
/*  32:    */   private static final int ODD_POWERS_OF_TWO = -1431655766;
/*  33:    */   private static final int DEFAULT_CAPACITY = 11;
/*  34:    */   
/*  35:    */   public static <E extends Comparable<E>> MinMaxPriorityQueue<E> create()
/*  36:    */   {
/*  37:112 */     return new Builder(Ordering.natural(), null).create();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <E extends Comparable<E>> MinMaxPriorityQueue<E> create(Iterable<? extends E> initialContents)
/*  41:    */   {
/*  42:121 */     return new Builder(Ordering.natural(), null).create(initialContents);
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static <B> Builder<B> orderedBy(Comparator<B> comparator)
/*  46:    */   {
/*  47:130 */     return new Builder(comparator, null);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static Builder<Comparable> expectedSize(int expectedSize)
/*  51:    */   {
/*  52:139 */     return new Builder(Ordering.natural(), null).expectedSize(expectedSize);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public static Builder<Comparable> maximumSize(int maximumSize)
/*  56:    */   {
/*  57:150 */     return new Builder(Ordering.natural(), null).maximumSize(maximumSize);
/*  58:    */   }
/*  59:    */   
/*  60:    */   @Beta
/*  61:    */   public static final class Builder<B>
/*  62:    */   {
/*  63:    */     private static final int UNSET_EXPECTED_SIZE = -1;
/*  64:    */     private final Comparator<B> comparator;
/*  65:175 */     private int expectedSize = -1;
/*  66:176 */     private int maximumSize = 2147483647;
/*  67:    */     
/*  68:    */     private Builder(Comparator<B> comparator)
/*  69:    */     {
/*  70:179 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/*  71:    */     }
/*  72:    */     
/*  73:    */     public Builder<B> expectedSize(int expectedSize)
/*  74:    */     {
/*  75:187 */       Preconditions.checkArgument(expectedSize >= 0);
/*  76:188 */       this.expectedSize = expectedSize;
/*  77:189 */       return this;
/*  78:    */     }
/*  79:    */     
/*  80:    */     public Builder<B> maximumSize(int maximumSize)
/*  81:    */     {
/*  82:199 */       Preconditions.checkArgument(maximumSize > 0);
/*  83:200 */       this.maximumSize = maximumSize;
/*  84:201 */       return this;
/*  85:    */     }
/*  86:    */     
/*  87:    */     public <T extends B> MinMaxPriorityQueue<T> create()
/*  88:    */     {
/*  89:209 */       return create(Collections.emptySet());
/*  90:    */     }
/*  91:    */     
/*  92:    */     public <T extends B> MinMaxPriorityQueue<T> create(Iterable<? extends T> initialContents)
/*  93:    */     {
/*  94:217 */       MinMaxPriorityQueue<T> queue = new MinMaxPriorityQueue(this, MinMaxPriorityQueue.initialQueueSize(this.expectedSize, this.maximumSize, initialContents), null);
/*  95:220 */       for (T element : initialContents) {
/*  96:221 */         queue.offer(element);
/*  97:    */       }
/*  98:223 */       return queue;
/*  99:    */     }
/* 100:    */     
/* 101:    */     private <T extends B> Ordering<T> ordering()
/* 102:    */     {
/* 103:228 */       return Ordering.from(this.comparator);
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   private MinMaxPriorityQueue(Builder<? super E> builder, int queueSize)
/* 108:    */   {
/* 109:240 */     Ordering<E> ordering = builder.ordering();
/* 110:241 */     this.minHeap = new Heap(ordering);
/* 111:242 */     this.maxHeap = new Heap(ordering.reverse());
/* 112:243 */     this.minHeap.otherHeap = this.maxHeap;
/* 113:244 */     this.maxHeap.otherHeap = this.minHeap;
/* 114:    */     
/* 115:246 */     this.maximumSize = builder.maximumSize;
/* 116:    */     
/* 117:248 */     this.queue = new Object[queueSize];
/* 118:    */   }
/* 119:    */   
/* 120:    */   public int size()
/* 121:    */   {
/* 122:253 */     return this.size;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public boolean add(E element)
/* 126:    */   {
/* 127:266 */     offer(element);
/* 128:267 */     return true;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public boolean addAll(Collection<? extends E> newElements)
/* 132:    */   {
/* 133:272 */     boolean modified = false;
/* 134:273 */     for (E element : newElements)
/* 135:    */     {
/* 136:274 */       offer(element);
/* 137:275 */       modified = true;
/* 138:    */     }
/* 139:277 */     return modified;
/* 140:    */   }
/* 141:    */   
/* 142:    */   public boolean offer(E element)
/* 143:    */   {
/* 144:288 */     Preconditions.checkNotNull(element);
/* 145:289 */     this.modCount += 1;
/* 146:290 */     int insertIndex = this.size++;
/* 147:    */     
/* 148:292 */     growIfNeeded();
/* 149:    */     
/* 150:    */ 
/* 151:    */ 
/* 152:296 */     heapForIndex(insertIndex).bubbleUp(insertIndex, element);
/* 153:297 */     return (this.size <= this.maximumSize) || (pollLast() != element);
/* 154:    */   }
/* 155:    */   
/* 156:    */   public E poll()
/* 157:    */   {
/* 158:302 */     return isEmpty() ? null : removeAndGet(0);
/* 159:    */   }
/* 160:    */   
/* 161:    */   E elementData(int index)
/* 162:    */   {
/* 163:307 */     return this.queue[index];
/* 164:    */   }
/* 165:    */   
/* 166:    */   public E peek()
/* 167:    */   {
/* 168:312 */     return isEmpty() ? null : elementData(0);
/* 169:    */   }
/* 170:    */   
/* 171:    */   private int getMaxElementIndex()
/* 172:    */   {
/* 173:319 */     switch (this.size)
/* 174:    */     {
/* 175:    */     case 1: 
/* 176:321 */       return 0;
/* 177:    */     case 2: 
/* 178:323 */       return 1;
/* 179:    */     }
/* 180:327 */     return this.maxHeap.compareElements(1, 2) <= 0 ? 1 : 2;
/* 181:    */   }
/* 182:    */   
/* 183:    */   public E pollFirst()
/* 184:    */   {
/* 185:336 */     return poll();
/* 186:    */   }
/* 187:    */   
/* 188:    */   public E removeFirst()
/* 189:    */   {
/* 190:345 */     return remove();
/* 191:    */   }
/* 192:    */   
/* 193:    */   public E peekFirst()
/* 194:    */   {
/* 195:353 */     return peek();
/* 196:    */   }
/* 197:    */   
/* 198:    */   public E pollLast()
/* 199:    */   {
/* 200:361 */     return isEmpty() ? null : removeAndGet(getMaxElementIndex());
/* 201:    */   }
/* 202:    */   
/* 203:    */   public E removeLast()
/* 204:    */   {
/* 205:370 */     if (isEmpty()) {
/* 206:371 */       throw new NoSuchElementException();
/* 207:    */     }
/* 208:373 */     return removeAndGet(getMaxElementIndex());
/* 209:    */   }
/* 210:    */   
/* 211:    */   public E peekLast()
/* 212:    */   {
/* 213:381 */     return isEmpty() ? null : elementData(getMaxElementIndex());
/* 214:    */   }
/* 215:    */   
/* 216:    */   @VisibleForTesting
/* 217:    */   MoveDesc<E> removeAt(int index)
/* 218:    */   {
/* 219:401 */     Preconditions.checkPositionIndex(index, this.size);
/* 220:402 */     this.modCount += 1;
/* 221:403 */     this.size -= 1;
/* 222:404 */     if (this.size == index)
/* 223:    */     {
/* 224:405 */       this.queue[this.size] = null;
/* 225:406 */       return null;
/* 226:    */     }
/* 227:408 */     E actualLastElement = elementData(this.size);
/* 228:409 */     int lastElementAt = heapForIndex(this.size).getCorrectLastElement(actualLastElement);
/* 229:410 */     E toTrickle = elementData(this.size);
/* 230:411 */     this.queue[this.size] = null;
/* 231:412 */     MoveDesc<E> changes = fillHole(index, toTrickle);
/* 232:413 */     if (lastElementAt < index)
/* 233:    */     {
/* 234:415 */       if (changes == null) {
/* 235:417 */         return new MoveDesc(actualLastElement, toTrickle);
/* 236:    */       }
/* 237:421 */       return new MoveDesc(actualLastElement, changes.replaced);
/* 238:    */     }
/* 239:425 */     return changes;
/* 240:    */   }
/* 241:    */   
/* 242:    */   private MoveDesc<E> fillHole(int index, E toTrickle)
/* 243:    */   {
/* 244:429 */     MinMaxPriorityQueue<E>.Heap heap = heapForIndex(index);
/* 245:    */     
/* 246:    */ 
/* 247:    */ 
/* 248:    */ 
/* 249:    */ 
/* 250:    */ 
/* 251:    */ 
/* 252:437 */     int vacated = heap.fillHoleAt(index);
/* 253:    */     
/* 254:439 */     int bubbledTo = heap.bubbleUpAlternatingLevels(vacated, toTrickle);
/* 255:440 */     if (bubbledTo == vacated) {
/* 256:444 */       return heap.tryCrossOverAndBubbleUp(index, vacated, toTrickle);
/* 257:    */     }
/* 258:446 */     return bubbledTo < index ? new MoveDesc(toTrickle, elementData(index)) : null;
/* 259:    */   }
/* 260:    */   
/* 261:    */   static class MoveDesc<E>
/* 262:    */   {
/* 263:    */     final E toTrickle;
/* 264:    */     final E replaced;
/* 265:    */     
/* 266:    */     MoveDesc(E toTrickle, E replaced)
/* 267:    */     {
/* 268:456 */       this.toTrickle = toTrickle;
/* 269:457 */       this.replaced = replaced;
/* 270:    */     }
/* 271:    */   }
/* 272:    */   
/* 273:    */   private E removeAndGet(int index)
/* 274:    */   {
/* 275:465 */     E value = elementData(index);
/* 276:466 */     removeAt(index);
/* 277:467 */     return value;
/* 278:    */   }
/* 279:    */   
/* 280:    */   private MinMaxPriorityQueue<E>.Heap heapForIndex(int i)
/* 281:    */   {
/* 282:471 */     return isEvenLevel(i) ? this.minHeap : this.maxHeap;
/* 283:    */   }
/* 284:    */   
/* 285:    */   @VisibleForTesting
/* 286:    */   static boolean isEvenLevel(int index)
/* 287:    */   {
/* 288:479 */     int oneBased = index + 1;
/* 289:480 */     Preconditions.checkState(oneBased > 0, "negative index");
/* 290:481 */     return (oneBased & 0x55555555) > (oneBased & 0xAAAAAAAA);
/* 291:    */   }
/* 292:    */   
/* 293:    */   @VisibleForTesting
/* 294:    */   boolean isIntact()
/* 295:    */   {
/* 296:492 */     for (int i = 1; i < this.size; i++) {
/* 297:493 */       if (!heapForIndex(i).verifyIndex(i)) {
/* 298:494 */         return false;
/* 299:    */       }
/* 300:    */     }
/* 301:497 */     return true;
/* 302:    */   }
/* 303:    */   
/* 304:    */   private class Heap
/* 305:    */   {
/* 306:    */     final Ordering<E> ordering;
/* 307:    */     @Weak
/* 308:    */     MinMaxPriorityQueue<E>.Heap otherHeap;
/* 309:    */     
/* 310:    */     Heap()
/* 311:    */     {
/* 312:512 */       this.ordering = ordering;
/* 313:    */     }
/* 314:    */     
/* 315:    */     int compareElements(int a, int b)
/* 316:    */     {
/* 317:516 */       return this.ordering.compare(MinMaxPriorityQueue.this.elementData(a), MinMaxPriorityQueue.this.elementData(b));
/* 318:    */     }
/* 319:    */     
/* 320:    */     MinMaxPriorityQueue.MoveDesc<E> tryCrossOverAndBubbleUp(int removeIndex, int vacated, E toTrickle)
/* 321:    */     {
/* 322:525 */       int crossOver = crossOver(vacated, toTrickle);
/* 323:526 */       if (crossOver == vacated) {
/* 324:527 */         return null;
/* 325:    */       }
/* 326:    */       E parent;
/* 327:    */       E parent;
/* 328:535 */       if (crossOver < removeIndex) {
/* 329:538 */         parent = MinMaxPriorityQueue.this.elementData(removeIndex);
/* 330:    */       } else {
/* 331:540 */         parent = MinMaxPriorityQueue.this.elementData(getParentIndex(removeIndex));
/* 332:    */       }
/* 333:543 */       if (this.otherHeap.bubbleUpAlternatingLevels(crossOver, toTrickle) < removeIndex) {
/* 334:544 */         return new MinMaxPriorityQueue.MoveDesc(toTrickle, parent);
/* 335:    */       }
/* 336:546 */       return null;
/* 337:    */     }
/* 338:    */     
/* 339:    */     void bubbleUp(int index, E x)
/* 340:    */     {
/* 341:554 */       int crossOver = crossOverUp(index, x);
/* 342:    */       MinMaxPriorityQueue<E>.Heap heap;
/* 343:    */       MinMaxPriorityQueue<E>.Heap heap;
/* 344:557 */       if (crossOver == index)
/* 345:    */       {
/* 346:558 */         heap = this;
/* 347:    */       }
/* 348:    */       else
/* 349:    */       {
/* 350:560 */         index = crossOver;
/* 351:561 */         heap = this.otherHeap;
/* 352:    */       }
/* 353:563 */       heap.bubbleUpAlternatingLevels(index, x);
/* 354:    */     }
/* 355:    */     
/* 356:    */     int bubbleUpAlternatingLevels(int index, E x)
/* 357:    */     {
/* 358:571 */       while (index > 2)
/* 359:    */       {
/* 360:572 */         int grandParentIndex = getGrandparentIndex(index);
/* 361:573 */         E e = MinMaxPriorityQueue.this.elementData(grandParentIndex);
/* 362:574 */         if (this.ordering.compare(e, x) <= 0) {
/* 363:    */           break;
/* 364:    */         }
/* 365:577 */         MinMaxPriorityQueue.this.queue[index] = e;
/* 366:578 */         index = grandParentIndex;
/* 367:    */       }
/* 368:580 */       MinMaxPriorityQueue.this.queue[index] = x;
/* 369:581 */       return index;
/* 370:    */     }
/* 371:    */     
/* 372:    */     int findMin(int index, int len)
/* 373:    */     {
/* 374:590 */       if (index >= MinMaxPriorityQueue.this.size) {
/* 375:591 */         return -1;
/* 376:    */       }
/* 377:593 */       Preconditions.checkState(index > 0);
/* 378:594 */       int limit = Math.min(index, MinMaxPriorityQueue.this.size - len) + len;
/* 379:595 */       int minIndex = index;
/* 380:596 */       for (int i = index + 1; i < limit; i++) {
/* 381:597 */         if (compareElements(i, minIndex) < 0) {
/* 382:598 */           minIndex = i;
/* 383:    */         }
/* 384:    */       }
/* 385:601 */       return minIndex;
/* 386:    */     }
/* 387:    */     
/* 388:    */     int findMinChild(int index)
/* 389:    */     {
/* 390:608 */       return findMin(getLeftChildIndex(index), 2);
/* 391:    */     }
/* 392:    */     
/* 393:    */     int findMinGrandChild(int index)
/* 394:    */     {
/* 395:615 */       int leftChildIndex = getLeftChildIndex(index);
/* 396:616 */       if (leftChildIndex < 0) {
/* 397:617 */         return -1;
/* 398:    */       }
/* 399:619 */       return findMin(getLeftChildIndex(leftChildIndex), 4);
/* 400:    */     }
/* 401:    */     
/* 402:    */     int crossOverUp(int index, E x)
/* 403:    */     {
/* 404:628 */       if (index == 0)
/* 405:    */       {
/* 406:629 */         MinMaxPriorityQueue.this.queue[0] = x;
/* 407:630 */         return 0;
/* 408:    */       }
/* 409:632 */       int parentIndex = getParentIndex(index);
/* 410:633 */       E parentElement = MinMaxPriorityQueue.this.elementData(parentIndex);
/* 411:634 */       if (parentIndex != 0)
/* 412:    */       {
/* 413:639 */         int grandparentIndex = getParentIndex(parentIndex);
/* 414:640 */         int uncleIndex = getRightChildIndex(grandparentIndex);
/* 415:641 */         if ((uncleIndex != parentIndex) && (getLeftChildIndex(uncleIndex) >= MinMaxPriorityQueue.this.size))
/* 416:    */         {
/* 417:642 */           E uncleElement = MinMaxPriorityQueue.this.elementData(uncleIndex);
/* 418:643 */           if (this.ordering.compare(uncleElement, parentElement) < 0)
/* 419:    */           {
/* 420:644 */             parentIndex = uncleIndex;
/* 421:645 */             parentElement = uncleElement;
/* 422:    */           }
/* 423:    */         }
/* 424:    */       }
/* 425:649 */       if (this.ordering.compare(parentElement, x) < 0)
/* 426:    */       {
/* 427:650 */         MinMaxPriorityQueue.this.queue[index] = parentElement;
/* 428:651 */         MinMaxPriorityQueue.this.queue[parentIndex] = x;
/* 429:652 */         return parentIndex;
/* 430:    */       }
/* 431:654 */       MinMaxPriorityQueue.this.queue[index] = x;
/* 432:655 */       return index;
/* 433:    */     }
/* 434:    */     
/* 435:    */     int getCorrectLastElement(E actualLastElement)
/* 436:    */     {
/* 437:668 */       int parentIndex = getParentIndex(MinMaxPriorityQueue.this.size);
/* 438:669 */       if (parentIndex != 0)
/* 439:    */       {
/* 440:670 */         int grandparentIndex = getParentIndex(parentIndex);
/* 441:671 */         int uncleIndex = getRightChildIndex(grandparentIndex);
/* 442:672 */         if ((uncleIndex != parentIndex) && (getLeftChildIndex(uncleIndex) >= MinMaxPriorityQueue.this.size))
/* 443:    */         {
/* 444:673 */           E uncleElement = MinMaxPriorityQueue.this.elementData(uncleIndex);
/* 445:674 */           if (this.ordering.compare(uncleElement, actualLastElement) < 0)
/* 446:    */           {
/* 447:675 */             MinMaxPriorityQueue.this.queue[uncleIndex] = actualLastElement;
/* 448:676 */             MinMaxPriorityQueue.this.queue[MinMaxPriorityQueue.this.size] = uncleElement;
/* 449:677 */             return uncleIndex;
/* 450:    */           }
/* 451:    */         }
/* 452:    */       }
/* 453:681 */       return MinMaxPriorityQueue.this.size;
/* 454:    */     }
/* 455:    */     
/* 456:    */     int crossOver(int index, E x)
/* 457:    */     {
/* 458:691 */       int minChildIndex = findMinChild(index);
/* 459:694 */       if ((minChildIndex > 0) && (this.ordering.compare(MinMaxPriorityQueue.this.elementData(minChildIndex), x) < 0))
/* 460:    */       {
/* 461:695 */         MinMaxPriorityQueue.this.queue[index] = MinMaxPriorityQueue.this.elementData(minChildIndex);
/* 462:696 */         MinMaxPriorityQueue.this.queue[minChildIndex] = x;
/* 463:697 */         return minChildIndex;
/* 464:    */       }
/* 465:699 */       return crossOverUp(index, x);
/* 466:    */     }
/* 467:    */     
/* 468:    */     int fillHoleAt(int index)
/* 469:    */     {
/* 470:    */       int minGrandchildIndex;
/* 471:712 */       while ((minGrandchildIndex = findMinGrandChild(index)) > 0)
/* 472:    */       {
/* 473:713 */         MinMaxPriorityQueue.this.queue[index] = MinMaxPriorityQueue.this.elementData(minGrandchildIndex);
/* 474:714 */         index = minGrandchildIndex;
/* 475:    */       }
/* 476:716 */       return index;
/* 477:    */     }
/* 478:    */     
/* 479:    */     private boolean verifyIndex(int i)
/* 480:    */     {
/* 481:720 */       if ((getLeftChildIndex(i) < MinMaxPriorityQueue.this.size) && (compareElements(i, getLeftChildIndex(i)) > 0)) {
/* 482:721 */         return false;
/* 483:    */       }
/* 484:723 */       if ((getRightChildIndex(i) < MinMaxPriorityQueue.this.size) && (compareElements(i, getRightChildIndex(i)) > 0)) {
/* 485:724 */         return false;
/* 486:    */       }
/* 487:726 */       if ((i > 0) && (compareElements(i, getParentIndex(i)) > 0)) {
/* 488:727 */         return false;
/* 489:    */       }
/* 490:729 */       if ((i > 2) && (compareElements(getGrandparentIndex(i), i) > 0)) {
/* 491:730 */         return false;
/* 492:    */       }
/* 493:732 */       return true;
/* 494:    */     }
/* 495:    */     
/* 496:    */     private int getLeftChildIndex(int i)
/* 497:    */     {
/* 498:738 */       return i * 2 + 1;
/* 499:    */     }
/* 500:    */     
/* 501:    */     private int getRightChildIndex(int i)
/* 502:    */     {
/* 503:742 */       return i * 2 + 2;
/* 504:    */     }
/* 505:    */     
/* 506:    */     private int getParentIndex(int i)
/* 507:    */     {
/* 508:746 */       return (i - 1) / 2;
/* 509:    */     }
/* 510:    */     
/* 511:    */     private int getGrandparentIndex(int i)
/* 512:    */     {
/* 513:750 */       return getParentIndex(getParentIndex(i));
/* 514:    */     }
/* 515:    */   }
/* 516:    */   
/* 517:    */   private class QueueIterator
/* 518:    */     implements Iterator<E>
/* 519:    */   {
/* 520:761 */     private int cursor = -1;
/* 521:762 */     private int expectedModCount = MinMaxPriorityQueue.this.modCount;
/* 522:    */     private Queue<E> forgetMeNot;
/* 523:    */     private List<E> skipMe;
/* 524:    */     private E lastFromForgetMeNot;
/* 525:    */     private boolean canRemove;
/* 526:    */     
/* 527:    */     private QueueIterator() {}
/* 528:    */     
/* 529:    */     public boolean hasNext()
/* 530:    */     {
/* 531:770 */       checkModCount();
/* 532:771 */       return (nextNotInSkipMe(this.cursor + 1) < MinMaxPriorityQueue.this.size()) || ((this.forgetMeNot != null) && (!this.forgetMeNot.isEmpty()));
/* 533:    */     }
/* 534:    */     
/* 535:    */     public E next()
/* 536:    */     {
/* 537:777 */       checkModCount();
/* 538:778 */       int tempCursor = nextNotInSkipMe(this.cursor + 1);
/* 539:779 */       if (tempCursor < MinMaxPriorityQueue.this.size())
/* 540:    */       {
/* 541:780 */         this.cursor = tempCursor;
/* 542:781 */         this.canRemove = true;
/* 543:782 */         return MinMaxPriorityQueue.this.elementData(this.cursor);
/* 544:    */       }
/* 545:783 */       if (this.forgetMeNot != null)
/* 546:    */       {
/* 547:784 */         this.cursor = MinMaxPriorityQueue.this.size();
/* 548:785 */         this.lastFromForgetMeNot = this.forgetMeNot.poll();
/* 549:786 */         if (this.lastFromForgetMeNot != null)
/* 550:    */         {
/* 551:787 */           this.canRemove = true;
/* 552:788 */           return this.lastFromForgetMeNot;
/* 553:    */         }
/* 554:    */       }
/* 555:791 */       throw new NoSuchElementException("iterator moved past last element in queue.");
/* 556:    */     }
/* 557:    */     
/* 558:    */     public void remove()
/* 559:    */     {
/* 560:796 */       CollectPreconditions.checkRemove(this.canRemove);
/* 561:797 */       checkModCount();
/* 562:798 */       this.canRemove = false;
/* 563:799 */       this.expectedModCount += 1;
/* 564:800 */       if (this.cursor < MinMaxPriorityQueue.this.size())
/* 565:    */       {
/* 566:801 */         MinMaxPriorityQueue.MoveDesc<E> moved = MinMaxPriorityQueue.this.removeAt(this.cursor);
/* 567:802 */         if (moved != null)
/* 568:    */         {
/* 569:803 */           if (this.forgetMeNot == null)
/* 570:    */           {
/* 571:804 */             this.forgetMeNot = new ArrayDeque();
/* 572:805 */             this.skipMe = new ArrayList(3);
/* 573:    */           }
/* 574:807 */           this.forgetMeNot.add(moved.toTrickle);
/* 575:808 */           this.skipMe.add(moved.replaced);
/* 576:    */         }
/* 577:810 */         this.cursor -= 1;
/* 578:    */       }
/* 579:    */       else
/* 580:    */       {
/* 581:812 */         Preconditions.checkState(removeExact(this.lastFromForgetMeNot));
/* 582:813 */         this.lastFromForgetMeNot = null;
/* 583:    */       }
/* 584:    */     }
/* 585:    */     
/* 586:    */     private boolean containsExact(Iterable<E> elements, E target)
/* 587:    */     {
/* 588:819 */       for (E element : elements) {
/* 589:820 */         if (element == target) {
/* 590:821 */           return true;
/* 591:    */         }
/* 592:    */       }
/* 593:824 */       return false;
/* 594:    */     }
/* 595:    */     
/* 596:    */     boolean removeExact(Object target)
/* 597:    */     {
/* 598:829 */       for (int i = 0; i < MinMaxPriorityQueue.this.size; i++) {
/* 599:830 */         if (MinMaxPriorityQueue.this.queue[i] == target)
/* 600:    */         {
/* 601:831 */           MinMaxPriorityQueue.this.removeAt(i);
/* 602:832 */           return true;
/* 603:    */         }
/* 604:    */       }
/* 605:835 */       return false;
/* 606:    */     }
/* 607:    */     
/* 608:    */     void checkModCount()
/* 609:    */     {
/* 610:839 */       if (MinMaxPriorityQueue.this.modCount != this.expectedModCount) {
/* 611:840 */         throw new ConcurrentModificationException();
/* 612:    */       }
/* 613:    */     }
/* 614:    */     
/* 615:    */     private int nextNotInSkipMe(int c)
/* 616:    */     {
/* 617:849 */       if (this.skipMe != null) {
/* 618:850 */         while ((c < MinMaxPriorityQueue.this.size()) && (containsExact(this.skipMe, MinMaxPriorityQueue.this.elementData(c)))) {
/* 619:851 */           c++;
/* 620:    */         }
/* 621:    */       }
/* 622:854 */       return c;
/* 623:    */     }
/* 624:    */   }
/* 625:    */   
/* 626:    */   public Iterator<E> iterator()
/* 627:    */   {
/* 628:882 */     return new QueueIterator(null);
/* 629:    */   }
/* 630:    */   
/* 631:    */   public void clear()
/* 632:    */   {
/* 633:887 */     for (int i = 0; i < this.size; i++) {
/* 634:888 */       this.queue[i] = null;
/* 635:    */     }
/* 636:890 */     this.size = 0;
/* 637:    */   }
/* 638:    */   
/* 639:    */   public Object[] toArray()
/* 640:    */   {
/* 641:895 */     Object[] copyTo = new Object[this.size];
/* 642:896 */     System.arraycopy(this.queue, 0, copyTo, 0, this.size);
/* 643:897 */     return copyTo;
/* 644:    */   }
/* 645:    */   
/* 646:    */   public Comparator<? super E> comparator()
/* 647:    */   {
/* 648:906 */     return this.minHeap.ordering;
/* 649:    */   }
/* 650:    */   
/* 651:    */   @VisibleForTesting
/* 652:    */   int capacity()
/* 653:    */   {
/* 654:911 */     return this.queue.length;
/* 655:    */   }
/* 656:    */   
/* 657:    */   @VisibleForTesting
/* 658:    */   static int initialQueueSize(int configuredExpectedSize, int maximumSize, Iterable<?> initialContents)
/* 659:    */   {
/* 660:922 */     int result = configuredExpectedSize == -1 ? 11 : configuredExpectedSize;
/* 661:928 */     if ((initialContents instanceof Collection))
/* 662:    */     {
/* 663:929 */       int initialSize = ((Collection)initialContents).size();
/* 664:930 */       result = Math.max(result, initialSize);
/* 665:    */     }
/* 666:934 */     return capAtMaximumSize(result, maximumSize);
/* 667:    */   }
/* 668:    */   
/* 669:    */   private void growIfNeeded()
/* 670:    */   {
/* 671:938 */     if (this.size > this.queue.length)
/* 672:    */     {
/* 673:939 */       int newCapacity = calculateNewCapacity();
/* 674:940 */       Object[] newQueue = new Object[newCapacity];
/* 675:941 */       System.arraycopy(this.queue, 0, newQueue, 0, this.queue.length);
/* 676:942 */       this.queue = newQueue;
/* 677:    */     }
/* 678:    */   }
/* 679:    */   
/* 680:    */   private int calculateNewCapacity()
/* 681:    */   {
/* 682:948 */     int oldCapacity = this.queue.length;
/* 683:949 */     int newCapacity = oldCapacity < 64 ? (oldCapacity + 1) * 2 : IntMath.checkedMultiply(oldCapacity / 2, 3);
/* 684:    */     
/* 685:    */ 
/* 686:    */ 
/* 687:953 */     return capAtMaximumSize(newCapacity, this.maximumSize);
/* 688:    */   }
/* 689:    */   
/* 690:    */   private static int capAtMaximumSize(int queueSize, int maximumSize)
/* 691:    */   {
/* 692:958 */     return Math.min(queueSize - 1, maximumSize) + 1;
/* 693:    */   }
/* 694:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.MinMaxPriorityQueue
 * JD-Core Version:    0.7.0.1
 */