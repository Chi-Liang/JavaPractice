/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Collections;
/*  11:    */ import java.util.Comparator;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.List;
/*  14:    */ import java.util.Map;
/*  15:    */ import java.util.Map.Entry;
/*  16:    */ import java.util.concurrent.atomic.AtomicInteger;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible
/*  20:    */ public abstract class Ordering<T>
/*  21:    */   implements Comparator<T>
/*  22:    */ {
/*  23:    */   static final int LEFT_IS_GREATER = 1;
/*  24:    */   static final int RIGHT_IS_GREATER = -1;
/*  25:    */   
/*  26:    */   @GwtCompatible(serializable=true)
/*  27:    */   public static <C extends Comparable> Ordering<C> natural()
/*  28:    */   {
/*  29:147 */     return NaturalOrdering.INSTANCE;
/*  30:    */   }
/*  31:    */   
/*  32:    */   @GwtCompatible(serializable=true)
/*  33:    */   public static <T> Ordering<T> from(Comparator<T> comparator)
/*  34:    */   {
/*  35:165 */     return (comparator instanceof Ordering) ? (Ordering)comparator : new ComparatorOrdering(comparator);
/*  36:    */   }
/*  37:    */   
/*  38:    */   @Deprecated
/*  39:    */   @GwtCompatible(serializable=true)
/*  40:    */   public static <T> Ordering<T> from(Ordering<T> ordering)
/*  41:    */   {
/*  42:178 */     return (Ordering)Preconditions.checkNotNull(ordering);
/*  43:    */   }
/*  44:    */   
/*  45:    */   @GwtCompatible(serializable=true)
/*  46:    */   public static <T> Ordering<T> explicit(List<T> valuesInOrder)
/*  47:    */   {
/*  48:204 */     return new ExplicitOrdering(valuesInOrder);
/*  49:    */   }
/*  50:    */   
/*  51:    */   @GwtCompatible(serializable=true)
/*  52:    */   public static <T> Ordering<T> explicit(T leastValue, T... remainingValuesInOrder)
/*  53:    */   {
/*  54:232 */     return explicit(Lists.asList(leastValue, remainingValuesInOrder));
/*  55:    */   }
/*  56:    */   
/*  57:    */   @GwtCompatible(serializable=true)
/*  58:    */   public static Ordering<Object> allEqual()
/*  59:    */   {
/*  60:266 */     return AllEqualOrdering.INSTANCE;
/*  61:    */   }
/*  62:    */   
/*  63:    */   @GwtCompatible(serializable=true)
/*  64:    */   public static Ordering<Object> usingToString()
/*  65:    */   {
/*  66:278 */     return UsingToStringOrdering.INSTANCE;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static Ordering<Object> arbitrary()
/*  70:    */   {
/*  71:298 */     return ArbitraryOrderingHolder.ARBITRARY_ORDERING;
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static class ArbitraryOrderingHolder
/*  75:    */   {
/*  76:302 */     static final Ordering<Object> ARBITRARY_ORDERING = new Ordering.ArbitraryOrdering();
/*  77:    */   }
/*  78:    */   
/*  79:    */   @VisibleForTesting
/*  80:    */   static class ArbitraryOrdering
/*  81:    */     extends Ordering<Object>
/*  82:    */   {
/*  83:308 */     private Map<Object, Integer> uids = Platform.tryWeakKeys(new MapMaker()).makeComputingMap(new Function()
/*  84:    */     {
/*  85:313 */       final AtomicInteger counter = new AtomicInteger(0);
/*  86:    */       
/*  87:    */       public Integer apply(Object from)
/*  88:    */       {
/*  89:317 */         return Integer.valueOf(this.counter.getAndIncrement());
/*  90:    */       }
/*  91:308 */     });
/*  92:    */     
/*  93:    */     public int compare(Object left, Object right)
/*  94:    */     {
/*  95:323 */       if (left == right) {
/*  96:324 */         return 0;
/*  97:    */       }
/*  98:325 */       if (left == null) {
/*  99:326 */         return -1;
/* 100:    */       }
/* 101:327 */       if (right == null) {
/* 102:328 */         return 1;
/* 103:    */       }
/* 104:330 */       int leftCode = identityHashCode(left);
/* 105:331 */       int rightCode = identityHashCode(right);
/* 106:332 */       if (leftCode != rightCode) {
/* 107:333 */         return leftCode < rightCode ? -1 : 1;
/* 108:    */       }
/* 109:337 */       int result = ((Integer)this.uids.get(left)).compareTo((Integer)this.uids.get(right));
/* 110:338 */       if (result == 0) {
/* 111:339 */         throw new AssertionError();
/* 112:    */       }
/* 113:341 */       return result;
/* 114:    */     }
/* 115:    */     
/* 116:    */     public String toString()
/* 117:    */     {
/* 118:346 */       return "Ordering.arbitrary()";
/* 119:    */     }
/* 120:    */     
/* 121:    */     int identityHashCode(Object object)
/* 122:    */     {
/* 123:358 */       return System.identityHashCode(object);
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   @GwtCompatible(serializable=true)
/* 128:    */   public <S extends T> Ordering<S> reverse()
/* 129:    */   {
/* 130:380 */     return new ReverseOrdering(this);
/* 131:    */   }
/* 132:    */   
/* 133:    */   @GwtCompatible(serializable=true)
/* 134:    */   public <S extends T> Ordering<S> nullsFirst()
/* 135:    */   {
/* 136:391 */     return new NullsFirstOrdering(this);
/* 137:    */   }
/* 138:    */   
/* 139:    */   @GwtCompatible(serializable=true)
/* 140:    */   public <S extends T> Ordering<S> nullsLast()
/* 141:    */   {
/* 142:402 */     return new NullsLastOrdering(this);
/* 143:    */   }
/* 144:    */   
/* 145:    */   @GwtCompatible(serializable=true)
/* 146:    */   public <F> Ordering<F> onResultOf(Function<F, ? extends T> function)
/* 147:    */   {
/* 148:416 */     return new ByFunctionOrdering(function, this);
/* 149:    */   }
/* 150:    */   
/* 151:    */   <T2 extends T> Ordering<Map.Entry<T2, ?>> onKeys()
/* 152:    */   {
/* 153:420 */     return onResultOf(Maps.keyFunction());
/* 154:    */   }
/* 155:    */   
/* 156:    */   @GwtCompatible(serializable=true)
/* 157:    */   public <U extends T> Ordering<U> compound(Comparator<? super U> secondaryComparator)
/* 158:    */   {
/* 159:436 */     return new CompoundOrdering(this, (Comparator)Preconditions.checkNotNull(secondaryComparator));
/* 160:    */   }
/* 161:    */   
/* 162:    */   @GwtCompatible(serializable=true)
/* 163:    */   public static <T> Ordering<T> compound(Iterable<? extends Comparator<? super T>> comparators)
/* 164:    */   {
/* 165:456 */     return new CompoundOrdering(comparators);
/* 166:    */   }
/* 167:    */   
/* 168:    */   @GwtCompatible(serializable=true)
/* 169:    */   public <S extends T> Ordering<Iterable<S>> lexicographical()
/* 170:    */   {
/* 171:485 */     return new LexicographicalOrdering(this);
/* 172:    */   }
/* 173:    */   
/* 174:    */   public abstract int compare(@Nullable T paramT1, @Nullable T paramT2);
/* 175:    */   
/* 176:    */   public <E extends T> E min(Iterator<E> iterator)
/* 177:    */   {
/* 178:509 */     E minSoFar = iterator.next();
/* 179:511 */     while (iterator.hasNext()) {
/* 180:512 */       minSoFar = min(minSoFar, iterator.next());
/* 181:    */     }
/* 182:515 */     return minSoFar;
/* 183:    */   }
/* 184:    */   
/* 185:    */   public <E extends T> E min(Iterable<E> iterable)
/* 186:    */   {
/* 187:528 */     return min(iterable.iterator());
/* 188:    */   }
/* 189:    */   
/* 190:    */   public <E extends T> E min(@Nullable E a, @Nullable E b)
/* 191:    */   {
/* 192:545 */     return compare(a, b) <= 0 ? a : b;
/* 193:    */   }
/* 194:    */   
/* 195:    */   public <E extends T> E min(@Nullable E a, @Nullable E b, @Nullable E c, E... rest)
/* 196:    */   {
/* 197:560 */     E minSoFar = min(min(a, b), c);
/* 198:562 */     for (E r : rest) {
/* 199:563 */       minSoFar = min(minSoFar, r);
/* 200:    */     }
/* 201:566 */     return minSoFar;
/* 202:    */   }
/* 203:    */   
/* 204:    */   public <E extends T> E max(Iterator<E> iterator)
/* 205:    */   {
/* 206:584 */     E maxSoFar = iterator.next();
/* 207:586 */     while (iterator.hasNext()) {
/* 208:587 */       maxSoFar = max(maxSoFar, iterator.next());
/* 209:    */     }
/* 210:590 */     return maxSoFar;
/* 211:    */   }
/* 212:    */   
/* 213:    */   public <E extends T> E max(Iterable<E> iterable)
/* 214:    */   {
/* 215:603 */     return max(iterable.iterator());
/* 216:    */   }
/* 217:    */   
/* 218:    */   public <E extends T> E max(@Nullable E a, @Nullable E b)
/* 219:    */   {
/* 220:620 */     return compare(a, b) >= 0 ? a : b;
/* 221:    */   }
/* 222:    */   
/* 223:    */   public <E extends T> E max(@Nullable E a, @Nullable E b, @Nullable E c, E... rest)
/* 224:    */   {
/* 225:635 */     E maxSoFar = max(max(a, b), c);
/* 226:637 */     for (E r : rest) {
/* 227:638 */       maxSoFar = max(maxSoFar, r);
/* 228:    */     }
/* 229:641 */     return maxSoFar;
/* 230:    */   }
/* 231:    */   
/* 232:    */   public <E extends T> List<E> leastOf(Iterable<E> iterable, int k)
/* 233:    */   {
/* 234:659 */     if ((iterable instanceof Collection))
/* 235:    */     {
/* 236:660 */       Collection<E> collection = (Collection)iterable;
/* 237:661 */       if (collection.size() <= 2L * k)
/* 238:    */       {
/* 239:667 */         E[] array = (Object[])collection.toArray();
/* 240:668 */         Arrays.sort(array, this);
/* 241:669 */         if (array.length > k) {
/* 242:670 */           array = ObjectArrays.arraysCopyOf(array, k);
/* 243:    */         }
/* 244:672 */         return Collections.unmodifiableList(Arrays.asList(array));
/* 245:    */       }
/* 246:    */     }
/* 247:675 */     return leastOf(iterable.iterator(), k);
/* 248:    */   }
/* 249:    */   
/* 250:    */   public <E extends T> List<E> leastOf(Iterator<E> elements, int k)
/* 251:    */   {
/* 252:693 */     Preconditions.checkNotNull(elements);
/* 253:694 */     CollectPreconditions.checkNonnegative(k, "k");
/* 254:696 */     if ((k == 0) || (!elements.hasNext())) {
/* 255:697 */       return ImmutableList.of();
/* 256:    */     }
/* 257:698 */     if (k >= 1073741823)
/* 258:    */     {
/* 259:700 */       ArrayList<E> list = Lists.newArrayList(elements);
/* 260:701 */       Collections.sort(list, this);
/* 261:702 */       if (list.size() > k) {
/* 262:703 */         list.subList(k, list.size()).clear();
/* 263:    */       }
/* 264:705 */       list.trimToSize();
/* 265:706 */       return Collections.unmodifiableList(list);
/* 266:    */     }
/* 267:723 */     int bufferCap = k * 2;
/* 268:    */     
/* 269:725 */     E[] buffer = (Object[])new Object[bufferCap];
/* 270:726 */     E threshold = elements.next();
/* 271:727 */     buffer[0] = threshold;
/* 272:728 */     int bufferSize = 1;
/* 273:732 */     while ((bufferSize < k) && (elements.hasNext()))
/* 274:    */     {
/* 275:733 */       E e = elements.next();
/* 276:734 */       buffer[(bufferSize++)] = e;
/* 277:735 */       threshold = max(threshold, e);
/* 278:    */     }
/* 279:738 */     while (elements.hasNext())
/* 280:    */     {
/* 281:739 */       E e = elements.next();
/* 282:740 */       if (compare(e, threshold) < 0)
/* 283:    */       {
/* 284:744 */         buffer[(bufferSize++)] = e;
/* 285:745 */         if (bufferSize == bufferCap)
/* 286:    */         {
/* 287:748 */           int left = 0;
/* 288:749 */           int right = bufferCap - 1;
/* 289:    */           
/* 290:751 */           int minThresholdPosition = 0;
/* 291:755 */           while (left < right)
/* 292:    */           {
/* 293:756 */             int pivotIndex = left + right + 1 >>> 1;
/* 294:757 */             int pivotNewIndex = partition(buffer, left, right, pivotIndex);
/* 295:758 */             if (pivotNewIndex > k)
/* 296:    */             {
/* 297:759 */               right = pivotNewIndex - 1;
/* 298:    */             }
/* 299:    */             else
/* 300:    */             {
/* 301:760 */               if (pivotNewIndex >= k) {
/* 302:    */                 break;
/* 303:    */               }
/* 304:761 */               left = Math.max(pivotNewIndex, left + 1);
/* 305:762 */               minThresholdPosition = pivotNewIndex;
/* 306:    */             }
/* 307:    */           }
/* 308:767 */           bufferSize = k;
/* 309:    */           
/* 310:769 */           threshold = buffer[minThresholdPosition];
/* 311:770 */           for (int i = minThresholdPosition + 1; i < bufferSize; i++) {
/* 312:771 */             threshold = max(threshold, buffer[i]);
/* 313:    */           }
/* 314:    */         }
/* 315:    */       }
/* 316:    */     }
/* 317:776 */     Arrays.sort(buffer, 0, bufferSize, this);
/* 318:    */     
/* 319:778 */     bufferSize = Math.min(bufferSize, k);
/* 320:779 */     return Collections.unmodifiableList(Arrays.asList(ObjectArrays.arraysCopyOf(buffer, bufferSize)));
/* 321:    */   }
/* 322:    */   
/* 323:    */   private <E extends T> int partition(E[] values, int left, int right, int pivotIndex)
/* 324:    */   {
/* 325:785 */     E pivotValue = values[pivotIndex];
/* 326:    */     
/* 327:787 */     values[pivotIndex] = values[right];
/* 328:788 */     values[right] = pivotValue;
/* 329:    */     
/* 330:790 */     int storeIndex = left;
/* 331:791 */     for (int i = left; i < right; i++) {
/* 332:792 */       if (compare(values[i], pivotValue) < 0)
/* 333:    */       {
/* 334:793 */         ObjectArrays.swap(values, storeIndex, i);
/* 335:794 */         storeIndex++;
/* 336:    */       }
/* 337:    */     }
/* 338:797 */     ObjectArrays.swap(values, right, storeIndex);
/* 339:798 */     return storeIndex;
/* 340:    */   }
/* 341:    */   
/* 342:    */   public <E extends T> List<E> greatestOf(Iterable<E> iterable, int k)
/* 343:    */   {
/* 344:818 */     return reverse().leastOf(iterable, k);
/* 345:    */   }
/* 346:    */   
/* 347:    */   public <E extends T> List<E> greatestOf(Iterator<E> iterator, int k)
/* 348:    */   {
/* 349:836 */     return reverse().leastOf(iterator, k);
/* 350:    */   }
/* 351:    */   
/* 352:    */   public <E extends T> List<E> sortedCopy(Iterable<E> elements)
/* 353:    */   {
/* 354:859 */     E[] array = (Object[])Iterables.toArray(elements);
/* 355:860 */     Arrays.sort(array, this);
/* 356:861 */     return Lists.newArrayList(Arrays.asList(array));
/* 357:    */   }
/* 358:    */   
/* 359:    */   public <E extends T> ImmutableList<E> immutableSortedCopy(Iterable<E> elements)
/* 360:    */   {
/* 361:884 */     E[] array = (Object[])Iterables.toArray(elements);
/* 362:885 */     for (E e : array) {
/* 363:886 */       Preconditions.checkNotNull(e);
/* 364:    */     }
/* 365:888 */     Arrays.sort(array, this);
/* 366:889 */     return ImmutableList.asImmutableList(array);
/* 367:    */   }
/* 368:    */   
/* 369:    */   public boolean isOrdered(Iterable<? extends T> iterable)
/* 370:    */   {
/* 371:899 */     Iterator<? extends T> it = iterable.iterator();
/* 372:900 */     if (it.hasNext())
/* 373:    */     {
/* 374:901 */       T prev = it.next();
/* 375:902 */       while (it.hasNext())
/* 376:    */       {
/* 377:903 */         T next = it.next();
/* 378:904 */         if (compare(prev, next) > 0) {
/* 379:905 */           return false;
/* 380:    */         }
/* 381:907 */         prev = next;
/* 382:    */       }
/* 383:    */     }
/* 384:910 */     return true;
/* 385:    */   }
/* 386:    */   
/* 387:    */   public boolean isStrictlyOrdered(Iterable<? extends T> iterable)
/* 388:    */   {
/* 389:920 */     Iterator<? extends T> it = iterable.iterator();
/* 390:921 */     if (it.hasNext())
/* 391:    */     {
/* 392:922 */       T prev = it.next();
/* 393:923 */       while (it.hasNext())
/* 394:    */       {
/* 395:924 */         T next = it.next();
/* 396:925 */         if (compare(prev, next) >= 0) {
/* 397:926 */           return false;
/* 398:    */         }
/* 399:928 */         prev = next;
/* 400:    */       }
/* 401:    */     }
/* 402:931 */     return true;
/* 403:    */   }
/* 404:    */   
/* 405:    */   public int binarySearch(List<? extends T> sortedList, @Nullable T key)
/* 406:    */   {
/* 407:943 */     return Collections.binarySearch(sortedList, key, this);
/* 408:    */   }
/* 409:    */   
/* 410:    */   @VisibleForTesting
/* 411:    */   static class IncomparableValueException
/* 412:    */     extends ClassCastException
/* 413:    */   {
/* 414:    */     final Object value;
/* 415:    */     private static final long serialVersionUID = 0L;
/* 416:    */     
/* 417:    */     IncomparableValueException(Object value)
/* 418:    */     {
/* 419:958 */       super();
/* 420:959 */       this.value = value;
/* 421:    */     }
/* 422:    */   }
/* 423:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Ordering
 * JD-Core Version:    0.7.0.1
 */