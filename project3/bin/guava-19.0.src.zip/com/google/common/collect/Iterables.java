/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Function;
/*    7:     */ import com.google.common.base.Optional;
/*    8:     */ import com.google.common.base.Preconditions;
/*    9:     */ import com.google.common.base.Predicate;
/*   10:     */ import java.util.Collection;
/*   11:     */ import java.util.Comparator;
/*   12:     */ import java.util.Iterator;
/*   13:     */ import java.util.List;
/*   14:     */ import java.util.NoSuchElementException;
/*   15:     */ import java.util.Queue;
/*   16:     */ import java.util.RandomAccess;
/*   17:     */ import java.util.Set;
/*   18:     */ import javax.annotation.CheckReturnValue;
/*   19:     */ import javax.annotation.Nullable;
/*   20:     */ 
/*   21:     */ @GwtCompatible(emulated=true)
/*   22:     */ public final class Iterables
/*   23:     */ {
/*   24:     */   public static <T> Iterable<T> unmodifiableIterable(Iterable<T> iterable)
/*   25:     */   {
/*   26:  66 */     Preconditions.checkNotNull(iterable);
/*   27:  67 */     if (((iterable instanceof UnmodifiableIterable)) || ((iterable instanceof ImmutableCollection))) {
/*   28:  68 */       return iterable;
/*   29:     */     }
/*   30:  70 */     return new UnmodifiableIterable(iterable, null);
/*   31:     */   }
/*   32:     */   
/*   33:     */   @Deprecated
/*   34:     */   public static <E> Iterable<E> unmodifiableIterable(ImmutableCollection<E> iterable)
/*   35:     */   {
/*   36:  81 */     return (Iterable)Preconditions.checkNotNull(iterable);
/*   37:     */   }
/*   38:     */   
/*   39:     */   private static final class UnmodifiableIterable<T>
/*   40:     */     extends FluentIterable<T>
/*   41:     */   {
/*   42:     */     private final Iterable<T> iterable;
/*   43:     */     
/*   44:     */     private UnmodifiableIterable(Iterable<T> iterable)
/*   45:     */     {
/*   46:  88 */       this.iterable = iterable;
/*   47:     */     }
/*   48:     */     
/*   49:     */     public Iterator<T> iterator()
/*   50:     */     {
/*   51:  93 */       return Iterators.unmodifiableIterator(this.iterable.iterator());
/*   52:     */     }
/*   53:     */     
/*   54:     */     public String toString()
/*   55:     */     {
/*   56:  98 */       return this.iterable.toString();
/*   57:     */     }
/*   58:     */   }
/*   59:     */   
/*   60:     */   public static int size(Iterable<?> iterable)
/*   61:     */   {
/*   62: 107 */     return (iterable instanceof Collection) ? ((Collection)iterable).size() : Iterators.size(iterable.iterator());
/*   63:     */   }
/*   64:     */   
/*   65:     */   public static boolean contains(Iterable<?> iterable, @Nullable Object element)
/*   66:     */   {
/*   67: 117 */     if ((iterable instanceof Collection))
/*   68:     */     {
/*   69: 118 */       Collection<?> collection = (Collection)iterable;
/*   70: 119 */       return Collections2.safeContains(collection, element);
/*   71:     */     }
/*   72: 121 */     return Iterators.contains(iterable.iterator(), element);
/*   73:     */   }
/*   74:     */   
/*   75:     */   public static boolean removeAll(Iterable<?> removeFrom, Collection<?> elementsToRemove)
/*   76:     */   {
/*   77: 136 */     return (removeFrom instanceof Collection) ? ((Collection)removeFrom).removeAll((Collection)Preconditions.checkNotNull(elementsToRemove)) : Iterators.removeAll(removeFrom.iterator(), elementsToRemove);
/*   78:     */   }
/*   79:     */   
/*   80:     */   public static boolean retainAll(Iterable<?> removeFrom, Collection<?> elementsToRetain)
/*   81:     */   {
/*   82: 153 */     return (removeFrom instanceof Collection) ? ((Collection)removeFrom).retainAll((Collection)Preconditions.checkNotNull(elementsToRetain)) : Iterators.retainAll(removeFrom.iterator(), elementsToRetain);
/*   83:     */   }
/*   84:     */   
/*   85:     */   public static <T> boolean removeIf(Iterable<T> removeFrom, Predicate<? super T> predicate)
/*   86:     */   {
/*   87: 172 */     if (((removeFrom instanceof RandomAccess)) && ((removeFrom instanceof List))) {
/*   88: 173 */       return removeIfFromRandomAccessList((List)removeFrom, (Predicate)Preconditions.checkNotNull(predicate));
/*   89:     */     }
/*   90: 175 */     return Iterators.removeIf(removeFrom.iterator(), predicate);
/*   91:     */   }
/*   92:     */   
/*   93:     */   private static <T> boolean removeIfFromRandomAccessList(List<T> list, Predicate<? super T> predicate)
/*   94:     */   {
/*   95: 182 */     int from = 0;
/*   96: 183 */     int to = 0;
/*   97: 185 */     for (; from < list.size(); from++)
/*   98:     */     {
/*   99: 186 */       T element = list.get(from);
/*  100: 187 */       if (!predicate.apply(element))
/*  101:     */       {
/*  102: 188 */         if (from > to) {
/*  103:     */           try
/*  104:     */           {
/*  105: 190 */             list.set(to, element);
/*  106:     */           }
/*  107:     */           catch (UnsupportedOperationException e)
/*  108:     */           {
/*  109: 192 */             slowRemoveIfForRemainingElements(list, predicate, to, from);
/*  110: 193 */             return true;
/*  111:     */           }
/*  112:     */         }
/*  113: 196 */         to++;
/*  114:     */       }
/*  115:     */     }
/*  116: 201 */     list.subList(to, list.size()).clear();
/*  117: 202 */     return from != to;
/*  118:     */   }
/*  119:     */   
/*  120:     */   private static <T> void slowRemoveIfForRemainingElements(List<T> list, Predicate<? super T> predicate, int to, int from)
/*  121:     */   {
/*  122: 217 */     for (int n = list.size() - 1; n > from; n--) {
/*  123: 218 */       if (predicate.apply(list.get(n))) {
/*  124: 219 */         list.remove(n);
/*  125:     */       }
/*  126:     */     }
/*  127: 223 */     for (int n = from - 1; n >= to; n--) {
/*  128: 224 */       list.remove(n);
/*  129:     */     }
/*  130:     */   }
/*  131:     */   
/*  132:     */   @Nullable
/*  133:     */   static <T> T removeFirstMatching(Iterable<T> removeFrom, Predicate<? super T> predicate)
/*  134:     */   {
/*  135: 233 */     Preconditions.checkNotNull(predicate);
/*  136: 234 */     Iterator<T> iterator = removeFrom.iterator();
/*  137: 235 */     while (iterator.hasNext())
/*  138:     */     {
/*  139: 236 */       T next = iterator.next();
/*  140: 237 */       if (predicate.apply(next))
/*  141:     */       {
/*  142: 238 */         iterator.remove();
/*  143: 239 */         return next;
/*  144:     */       }
/*  145:     */     }
/*  146: 242 */     return null;
/*  147:     */   }
/*  148:     */   
/*  149:     */   @CheckReturnValue
/*  150:     */   public static boolean elementsEqual(Iterable<?> iterable1, Iterable<?> iterable2)
/*  151:     */   {
/*  152: 254 */     if (((iterable1 instanceof Collection)) && ((iterable2 instanceof Collection)))
/*  153:     */     {
/*  154: 255 */       Collection<?> collection1 = (Collection)iterable1;
/*  155: 256 */       Collection<?> collection2 = (Collection)iterable2;
/*  156: 257 */       if (collection1.size() != collection2.size()) {
/*  157: 258 */         return false;
/*  158:     */       }
/*  159:     */     }
/*  160: 261 */     return Iterators.elementsEqual(iterable1.iterator(), iterable2.iterator());
/*  161:     */   }
/*  162:     */   
/*  163:     */   public static String toString(Iterable<?> iterable)
/*  164:     */   {
/*  165: 273 */     return Iterators.toString(iterable.iterator());
/*  166:     */   }
/*  167:     */   
/*  168:     */   public static <T> T getOnlyElement(Iterable<T> iterable)
/*  169:     */   {
/*  170: 284 */     return Iterators.getOnlyElement(iterable.iterator());
/*  171:     */   }
/*  172:     */   
/*  173:     */   @Nullable
/*  174:     */   public static <T> T getOnlyElement(Iterable<? extends T> iterable, @Nullable T defaultValue)
/*  175:     */   {
/*  176: 296 */     return Iterators.getOnlyElement(iterable.iterator(), defaultValue);
/*  177:     */   }
/*  178:     */   
/*  179:     */   @GwtIncompatible("Array.newInstance(Class, int)")
/*  180:     */   public static <T> T[] toArray(Iterable<? extends T> iterable, Class<T> type)
/*  181:     */   {
/*  182: 309 */     Collection<? extends T> collection = toCollection(iterable);
/*  183: 310 */     T[] array = ObjectArrays.newArray(type, collection.size());
/*  184: 311 */     return collection.toArray(array);
/*  185:     */   }
/*  186:     */   
/*  187:     */   static <T> T[] toArray(Iterable<? extends T> iterable, T[] array)
/*  188:     */   {
/*  189: 315 */     Collection<? extends T> collection = toCollection(iterable);
/*  190: 316 */     return collection.toArray(array);
/*  191:     */   }
/*  192:     */   
/*  193:     */   static Object[] toArray(Iterable<?> iterable)
/*  194:     */   {
/*  195: 327 */     return toCollection(iterable).toArray();
/*  196:     */   }
/*  197:     */   
/*  198:     */   private static <E> Collection<E> toCollection(Iterable<E> iterable)
/*  199:     */   {
/*  200: 336 */     return (iterable instanceof Collection) ? (Collection)iterable : Lists.newArrayList(iterable.iterator());
/*  201:     */   }
/*  202:     */   
/*  203:     */   public static <T> boolean addAll(Collection<T> addTo, Iterable<? extends T> elementsToAdd)
/*  204:     */   {
/*  205: 348 */     if ((elementsToAdd instanceof Collection))
/*  206:     */     {
/*  207: 349 */       Collection<? extends T> c = Collections2.cast(elementsToAdd);
/*  208: 350 */       return addTo.addAll(c);
/*  209:     */     }
/*  210: 352 */     return Iterators.addAll(addTo, ((Iterable)Preconditions.checkNotNull(elementsToAdd)).iterator());
/*  211:     */   }
/*  212:     */   
/*  213:     */   public static int frequency(Iterable<?> iterable, @Nullable Object element)
/*  214:     */   {
/*  215: 363 */     if ((iterable instanceof Multiset)) {
/*  216: 364 */       return ((Multiset)iterable).count(element);
/*  217:     */     }
/*  218: 365 */     if ((iterable instanceof Set)) {
/*  219: 366 */       return ((Set)iterable).contains(element) ? 1 : 0;
/*  220:     */     }
/*  221: 368 */     return Iterators.frequency(iterable.iterator(), element);
/*  222:     */   }
/*  223:     */   
/*  224:     */   public static <T> Iterable<T> cycle(Iterable<T> iterable)
/*  225:     */   {
/*  226: 389 */     Preconditions.checkNotNull(iterable);
/*  227: 390 */     new FluentIterable()
/*  228:     */     {
/*  229:     */       public Iterator<T> iterator()
/*  230:     */       {
/*  231: 393 */         return Iterators.cycle(this.val$iterable);
/*  232:     */       }
/*  233:     */       
/*  234:     */       public String toString()
/*  235:     */       {
/*  236: 398 */         return this.val$iterable.toString() + " (cycled)";
/*  237:     */       }
/*  238:     */     };
/*  239:     */   }
/*  240:     */   
/*  241:     */   public static <T> Iterable<T> cycle(T... elements)
/*  242:     */   {
/*  243: 422 */     return cycle(Lists.newArrayList(elements));
/*  244:     */   }
/*  245:     */   
/*  246:     */   public static <T> Iterable<T> concat(Iterable<? extends T> a, Iterable<? extends T> b)
/*  247:     */   {
/*  248: 434 */     return concat(ImmutableList.of(a, b));
/*  249:     */   }
/*  250:     */   
/*  251:     */   public static <T> Iterable<T> concat(Iterable<? extends T> a, Iterable<? extends T> b, Iterable<? extends T> c)
/*  252:     */   {
/*  253: 448 */     return concat(ImmutableList.of(a, b, c));
/*  254:     */   }
/*  255:     */   
/*  256:     */   public static <T> Iterable<T> concat(Iterable<? extends T> a, Iterable<? extends T> b, Iterable<? extends T> c, Iterable<? extends T> d)
/*  257:     */   {
/*  258: 466 */     return concat(ImmutableList.of(a, b, c, d));
/*  259:     */   }
/*  260:     */   
/*  261:     */   public static <T> Iterable<T> concat(Iterable<? extends T>... inputs)
/*  262:     */   {
/*  263: 480 */     return concat(ImmutableList.copyOf(inputs));
/*  264:     */   }
/*  265:     */   
/*  266:     */   public static <T> Iterable<T> concat(Iterable<? extends Iterable<? extends T>> inputs)
/*  267:     */   {
/*  268: 494 */     Preconditions.checkNotNull(inputs);
/*  269: 495 */     new FluentIterable()
/*  270:     */     {
/*  271:     */       public Iterator<T> iterator()
/*  272:     */       {
/*  273: 498 */         return Iterators.concat(Iterables.iterators(this.val$inputs));
/*  274:     */       }
/*  275:     */     };
/*  276:     */   }
/*  277:     */   
/*  278:     */   private static <T> Iterator<Iterator<? extends T>> iterators(Iterable<? extends Iterable<? extends T>> iterables)
/*  279:     */   {
/*  280: 508 */     new TransformedIterator(iterables.iterator())
/*  281:     */     {
/*  282:     */       Iterator<? extends T> transform(Iterable<? extends T> from)
/*  283:     */       {
/*  284: 512 */         return from.iterator();
/*  285:     */       }
/*  286:     */     };
/*  287:     */   }
/*  288:     */   
/*  289:     */   public static <T> Iterable<List<T>> partition(Iterable<T> iterable, final int size)
/*  290:     */   {
/*  291: 538 */     Preconditions.checkNotNull(iterable);
/*  292: 539 */     Preconditions.checkArgument(size > 0);
/*  293: 540 */     new FluentIterable()
/*  294:     */     {
/*  295:     */       public Iterator<List<T>> iterator()
/*  296:     */       {
/*  297: 543 */         return Iterators.partition(this.val$iterable.iterator(), size);
/*  298:     */       }
/*  299:     */     };
/*  300:     */   }
/*  301:     */   
/*  302:     */   public static <T> Iterable<List<T>> paddedPartition(Iterable<T> iterable, final int size)
/*  303:     */   {
/*  304: 566 */     Preconditions.checkNotNull(iterable);
/*  305: 567 */     Preconditions.checkArgument(size > 0);
/*  306: 568 */     new FluentIterable()
/*  307:     */     {
/*  308:     */       public Iterator<List<T>> iterator()
/*  309:     */       {
/*  310: 571 */         return Iterators.paddedPartition(this.val$iterable.iterator(), size);
/*  311:     */       }
/*  312:     */     };
/*  313:     */   }
/*  314:     */   
/*  315:     */   @CheckReturnValue
/*  316:     */   public static <T> Iterable<T> filter(Iterable<T> unfiltered, final Predicate<? super T> predicate)
/*  317:     */   {
/*  318: 583 */     Preconditions.checkNotNull(unfiltered);
/*  319: 584 */     Preconditions.checkNotNull(predicate);
/*  320: 585 */     new FluentIterable()
/*  321:     */     {
/*  322:     */       public Iterator<T> iterator()
/*  323:     */       {
/*  324: 588 */         return Iterators.filter(this.val$unfiltered.iterator(), predicate);
/*  325:     */       }
/*  326:     */     };
/*  327:     */   }
/*  328:     */   
/*  329:     */   @CheckReturnValue
/*  330:     */   @GwtIncompatible("Class.isInstance")
/*  331:     */   public static <T> Iterable<T> filter(Iterable<?> unfiltered, final Class<T> type)
/*  332:     */   {
/*  333: 607 */     Preconditions.checkNotNull(unfiltered);
/*  334: 608 */     Preconditions.checkNotNull(type);
/*  335: 609 */     new FluentIterable()
/*  336:     */     {
/*  337:     */       public Iterator<T> iterator()
/*  338:     */       {
/*  339: 612 */         return Iterators.filter(this.val$unfiltered.iterator(), type);
/*  340:     */       }
/*  341:     */     };
/*  342:     */   }
/*  343:     */   
/*  344:     */   public static <T> boolean any(Iterable<T> iterable, Predicate<? super T> predicate)
/*  345:     */   {
/*  346: 621 */     return Iterators.any(iterable.iterator(), predicate);
/*  347:     */   }
/*  348:     */   
/*  349:     */   public static <T> boolean all(Iterable<T> iterable, Predicate<? super T> predicate)
/*  350:     */   {
/*  351: 629 */     return Iterators.all(iterable.iterator(), predicate);
/*  352:     */   }
/*  353:     */   
/*  354:     */   public static <T> T find(Iterable<T> iterable, Predicate<? super T> predicate)
/*  355:     */   {
/*  356: 642 */     return Iterators.find(iterable.iterator(), predicate);
/*  357:     */   }
/*  358:     */   
/*  359:     */   @Nullable
/*  360:     */   public static <T> T find(Iterable<? extends T> iterable, Predicate<? super T> predicate, @Nullable T defaultValue)
/*  361:     */   {
/*  362: 656 */     return Iterators.find(iterable.iterator(), predicate, defaultValue);
/*  363:     */   }
/*  364:     */   
/*  365:     */   public static <T> Optional<T> tryFind(Iterable<T> iterable, Predicate<? super T> predicate)
/*  366:     */   {
/*  367: 670 */     return Iterators.tryFind(iterable.iterator(), predicate);
/*  368:     */   }
/*  369:     */   
/*  370:     */   public static <T> int indexOf(Iterable<T> iterable, Predicate<? super T> predicate)
/*  371:     */   {
/*  372: 685 */     return Iterators.indexOf(iterable.iterator(), predicate);
/*  373:     */   }
/*  374:     */   
/*  375:     */   @CheckReturnValue
/*  376:     */   public static <F, T> Iterable<T> transform(Iterable<F> fromIterable, final Function<? super F, ? extends T> function)
/*  377:     */   {
/*  378: 703 */     Preconditions.checkNotNull(fromIterable);
/*  379: 704 */     Preconditions.checkNotNull(function);
/*  380: 705 */     new FluentIterable()
/*  381:     */     {
/*  382:     */       public Iterator<T> iterator()
/*  383:     */       {
/*  384: 708 */         return Iterators.transform(this.val$fromIterable.iterator(), function);
/*  385:     */       }
/*  386:     */     };
/*  387:     */   }
/*  388:     */   
/*  389:     */   public static <T> T get(Iterable<T> iterable, int position)
/*  390:     */   {
/*  391: 722 */     Preconditions.checkNotNull(iterable);
/*  392: 723 */     return (iterable instanceof List) ? ((List)iterable).get(position) : Iterators.get(iterable.iterator(), position);
/*  393:     */   }
/*  394:     */   
/*  395:     */   @Nullable
/*  396:     */   public static <T> T get(Iterable<? extends T> iterable, int position, @Nullable T defaultValue)
/*  397:     */   {
/*  398: 743 */     Preconditions.checkNotNull(iterable);
/*  399: 744 */     Iterators.checkNonnegative(position);
/*  400: 745 */     if ((iterable instanceof List))
/*  401:     */     {
/*  402: 746 */       List<? extends T> list = Lists.cast(iterable);
/*  403: 747 */       return position < list.size() ? list.get(position) : defaultValue;
/*  404:     */     }
/*  405: 749 */     Iterator<? extends T> iterator = iterable.iterator();
/*  406: 750 */     Iterators.advance(iterator, position);
/*  407: 751 */     return Iterators.getNext(iterator, defaultValue);
/*  408:     */   }
/*  409:     */   
/*  410:     */   @Nullable
/*  411:     */   public static <T> T getFirst(Iterable<? extends T> iterable, @Nullable T defaultValue)
/*  412:     */   {
/*  413: 770 */     return Iterators.getNext(iterable.iterator(), defaultValue);
/*  414:     */   }
/*  415:     */   
/*  416:     */   public static <T> T getLast(Iterable<T> iterable)
/*  417:     */   {
/*  418: 781 */     if ((iterable instanceof List))
/*  419:     */     {
/*  420: 782 */       List<T> list = (List)iterable;
/*  421: 783 */       if (list.isEmpty()) {
/*  422: 784 */         throw new NoSuchElementException();
/*  423:     */       }
/*  424: 786 */       return getLastInNonemptyList(list);
/*  425:     */     }
/*  426: 789 */     return Iterators.getLast(iterable.iterator());
/*  427:     */   }
/*  428:     */   
/*  429:     */   @Nullable
/*  430:     */   public static <T> T getLast(Iterable<? extends T> iterable, @Nullable T defaultValue)
/*  431:     */   {
/*  432: 802 */     if ((iterable instanceof Collection))
/*  433:     */     {
/*  434: 803 */       Collection<? extends T> c = Collections2.cast(iterable);
/*  435: 804 */       if (c.isEmpty()) {
/*  436: 805 */         return defaultValue;
/*  437:     */       }
/*  438: 806 */       if ((iterable instanceof List)) {
/*  439: 807 */         return getLastInNonemptyList(Lists.cast(iterable));
/*  440:     */       }
/*  441:     */     }
/*  442: 811 */     return Iterators.getLast(iterable.iterator(), defaultValue);
/*  443:     */   }
/*  444:     */   
/*  445:     */   private static <T> T getLastInNonemptyList(List<T> list)
/*  446:     */   {
/*  447: 815 */     return list.get(list.size() - 1);
/*  448:     */   }
/*  449:     */   
/*  450:     */   public static <T> Iterable<T> skip(Iterable<T> iterable, final int numberToSkip)
/*  451:     */   {
/*  452: 839 */     Preconditions.checkNotNull(iterable);
/*  453: 840 */     Preconditions.checkArgument(numberToSkip >= 0, "number to skip cannot be negative");
/*  454: 842 */     if ((iterable instanceof List))
/*  455:     */     {
/*  456: 843 */       List<T> list = (List)iterable;
/*  457: 844 */       new FluentIterable()
/*  458:     */       {
/*  459:     */         public Iterator<T> iterator()
/*  460:     */         {
/*  461: 848 */           int toSkip = Math.min(this.val$list.size(), numberToSkip);
/*  462: 849 */           return this.val$list.subList(toSkip, this.val$list.size()).iterator();
/*  463:     */         }
/*  464:     */       };
/*  465:     */     }
/*  466: 854 */     new FluentIterable()
/*  467:     */     {
/*  468:     */       public Iterator<T> iterator()
/*  469:     */       {
/*  470: 857 */         final Iterator<T> iterator = this.val$iterable.iterator();
/*  471:     */         
/*  472: 859 */         Iterators.advance(iterator, numberToSkip);
/*  473:     */         
/*  474:     */ 
/*  475:     */ 
/*  476:     */ 
/*  477:     */ 
/*  478:     */ 
/*  479: 866 */         new Iterator()
/*  480:     */         {
/*  481: 867 */           boolean atStart = true;
/*  482:     */           
/*  483:     */           public boolean hasNext()
/*  484:     */           {
/*  485: 871 */             return iterator.hasNext();
/*  486:     */           }
/*  487:     */           
/*  488:     */           public T next()
/*  489:     */           {
/*  490: 876 */             T result = iterator.next();
/*  491: 877 */             this.atStart = false;
/*  492: 878 */             return result;
/*  493:     */           }
/*  494:     */           
/*  495:     */           public void remove()
/*  496:     */           {
/*  497: 883 */             CollectPreconditions.checkRemove(!this.atStart);
/*  498: 884 */             iterator.remove();
/*  499:     */           }
/*  500:     */         };
/*  501:     */       }
/*  502:     */     };
/*  503:     */   }
/*  504:     */   
/*  505:     */   public static <T> Iterable<T> limit(Iterable<T> iterable, final int limitSize)
/*  506:     */   {
/*  507: 904 */     Preconditions.checkNotNull(iterable);
/*  508: 905 */     Preconditions.checkArgument(limitSize >= 0, "limit is negative");
/*  509: 906 */     new FluentIterable()
/*  510:     */     {
/*  511:     */       public Iterator<T> iterator()
/*  512:     */       {
/*  513: 909 */         return Iterators.limit(this.val$iterable.iterator(), limitSize);
/*  514:     */       }
/*  515:     */     };
/*  516:     */   }
/*  517:     */   
/*  518:     */   public static <T> Iterable<T> consumingIterable(Iterable<T> iterable)
/*  519:     */   {
/*  520: 934 */     if ((iterable instanceof Queue)) {
/*  521: 935 */       new FluentIterable()
/*  522:     */       {
/*  523:     */         public Iterator<T> iterator()
/*  524:     */         {
/*  525: 938 */           return new ConsumingQueueIterator((Queue)this.val$iterable);
/*  526:     */         }
/*  527:     */         
/*  528:     */         public String toString()
/*  529:     */         {
/*  530: 943 */           return "Iterables.consumingIterable(...)";
/*  531:     */         }
/*  532:     */       };
/*  533:     */     }
/*  534: 948 */     Preconditions.checkNotNull(iterable);
/*  535:     */     
/*  536: 950 */     new FluentIterable()
/*  537:     */     {
/*  538:     */       public Iterator<T> iterator()
/*  539:     */       {
/*  540: 953 */         return Iterators.consumingIterator(this.val$iterable.iterator());
/*  541:     */       }
/*  542:     */       
/*  543:     */       public String toString()
/*  544:     */       {
/*  545: 958 */         return "Iterables.consumingIterable(...)";
/*  546:     */       }
/*  547:     */     };
/*  548:     */   }
/*  549:     */   
/*  550:     */   public static boolean isEmpty(Iterable<?> iterable)
/*  551:     */   {
/*  552: 975 */     if ((iterable instanceof Collection)) {
/*  553: 976 */       return ((Collection)iterable).isEmpty();
/*  554:     */     }
/*  555: 978 */     return !iterable.iterator().hasNext();
/*  556:     */   }
/*  557:     */   
/*  558:     */   @Beta
/*  559:     */   public static <T> Iterable<T> mergeSorted(Iterable<? extends Iterable<? extends T>> iterables, final Comparator<? super T> comparator)
/*  560:     */   {
/*  561: 997 */     Preconditions.checkNotNull(iterables, "iterables");
/*  562: 998 */     Preconditions.checkNotNull(comparator, "comparator");
/*  563: 999 */     Iterable<T> iterable = new FluentIterable()
/*  564:     */     {
/*  565:     */       public Iterator<T> iterator()
/*  566:     */       {
/*  567:1003 */         return Iterators.mergeSorted(Iterables.transform(this.val$iterables, Iterables.access$200()), comparator);
/*  568:     */       }
/*  569:1007 */     };
/*  570:1008 */     return new UnmodifiableIterable(iterable, null);
/*  571:     */   }
/*  572:     */   
/*  573:     */   private static <T> Function<Iterable<? extends T>, Iterator<? extends T>> toIterator()
/*  574:     */   {
/*  575:1014 */     new Function()
/*  576:     */     {
/*  577:     */       public Iterator<? extends T> apply(Iterable<? extends T> iterable)
/*  578:     */       {
/*  579:1017 */         return iterable.iterator();
/*  580:     */       }
/*  581:     */     };
/*  582:     */   }
/*  583:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Iterables
 * JD-Core Version:    0.7.0.1
 */