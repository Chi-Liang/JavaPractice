/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Collections;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.Set;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public abstract class ImmutableMultiset<E>
/*  16:    */   extends ImmutableCollection<E>
/*  17:    */   implements Multiset<E>
/*  18:    */ {
/*  19:    */   private transient ImmutableSet<Multiset.Entry<E>> entrySet;
/*  20:    */   
/*  21:    */   public static <E> ImmutableMultiset<E> of()
/*  22:    */   {
/*  23: 59 */     return RegularImmutableMultiset.EMPTY;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static <E> ImmutableMultiset<E> of(E element)
/*  27:    */   {
/*  28: 70 */     return copyFromElements(new Object[] { element });
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2)
/*  32:    */   {
/*  33: 81 */     return copyFromElements(new Object[] { e1, e2 });
/*  34:    */   }
/*  35:    */   
/*  36:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3)
/*  37:    */   {
/*  38: 93 */     return copyFromElements(new Object[] { e1, e2, e3 });
/*  39:    */   }
/*  40:    */   
/*  41:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4)
/*  42:    */   {
/*  43:105 */     return copyFromElements(new Object[] { e1, e2, e3, e4 });
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5)
/*  47:    */   {
/*  48:117 */     return copyFromElements(new Object[] { e1, e2, e3, e4, e5 });
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static <E> ImmutableMultiset<E> of(E e1, E e2, E e3, E e4, E e5, E e6, E... others)
/*  52:    */   {
/*  53:129 */     return new Builder().add(e1).add(e2).add(e3).add(e4).add(e5).add(e6).add(others).build();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static <E> ImmutableMultiset<E> copyOf(E[] elements)
/*  57:    */   {
/*  58:148 */     return copyFromElements(elements);
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <E> ImmutableMultiset<E> copyOf(Iterable<? extends E> elements)
/*  62:    */   {
/*  63:158 */     if ((elements instanceof ImmutableMultiset))
/*  64:    */     {
/*  65:160 */       ImmutableMultiset<E> result = (ImmutableMultiset)elements;
/*  66:161 */       if (!result.isPartialView()) {
/*  67:162 */         return result;
/*  68:    */       }
/*  69:    */     }
/*  70:166 */     Multiset<? extends E> multiset = (elements instanceof Multiset) ? Multisets.cast(elements) : LinkedHashMultiset.create(elements);
/*  71:    */     
/*  72:    */ 
/*  73:    */ 
/*  74:    */ 
/*  75:171 */     return copyFromEntries(multiset.entrySet());
/*  76:    */   }
/*  77:    */   
/*  78:    */   private static <E> ImmutableMultiset<E> copyFromElements(E... elements)
/*  79:    */   {
/*  80:175 */     Multiset<E> multiset = LinkedHashMultiset.create();
/*  81:176 */     Collections.addAll(multiset, elements);
/*  82:177 */     return copyFromEntries(multiset.entrySet());
/*  83:    */   }
/*  84:    */   
/*  85:    */   static <E> ImmutableMultiset<E> copyFromEntries(Collection<? extends Multiset.Entry<? extends E>> entries)
/*  86:    */   {
/*  87:182 */     if (entries.isEmpty()) {
/*  88:183 */       return of();
/*  89:    */     }
/*  90:185 */     return new RegularImmutableMultiset(entries);
/*  91:    */   }
/*  92:    */   
/*  93:    */   public static <E> ImmutableMultiset<E> copyOf(Iterator<? extends E> elements)
/*  94:    */   {
/*  95:196 */     Multiset<E> multiset = LinkedHashMultiset.create();
/*  96:197 */     Iterators.addAll(multiset, elements);
/*  97:198 */     return copyFromEntries(multiset.entrySet());
/*  98:    */   }
/*  99:    */   
/* 100:    */   public UnmodifiableIterator<E> iterator()
/* 101:    */   {
/* 102:205 */     final Iterator<Multiset.Entry<E>> entryIterator = entrySet().iterator();
/* 103:206 */     new UnmodifiableIterator()
/* 104:    */     {
/* 105:    */       int remaining;
/* 106:    */       E element;
/* 107:    */       
/* 108:    */       public boolean hasNext()
/* 109:    */       {
/* 110:212 */         return (this.remaining > 0) || (entryIterator.hasNext());
/* 111:    */       }
/* 112:    */       
/* 113:    */       public E next()
/* 114:    */       {
/* 115:217 */         if (this.remaining <= 0)
/* 116:    */         {
/* 117:218 */           Multiset.Entry<E> entry = (Multiset.Entry)entryIterator.next();
/* 118:219 */           this.element = entry.getElement();
/* 119:220 */           this.remaining = entry.getCount();
/* 120:    */         }
/* 121:222 */         this.remaining -= 1;
/* 122:223 */         return this.element;
/* 123:    */       }
/* 124:    */     };
/* 125:    */   }
/* 126:    */   
/* 127:    */   public boolean contains(@Nullable Object object)
/* 128:    */   {
/* 129:230 */     return count(object) > 0;
/* 130:    */   }
/* 131:    */   
/* 132:    */   @Deprecated
/* 133:    */   public final int add(E element, int occurrences)
/* 134:    */   {
/* 135:242 */     throw new UnsupportedOperationException();
/* 136:    */   }
/* 137:    */   
/* 138:    */   @Deprecated
/* 139:    */   public final int remove(Object element, int occurrences)
/* 140:    */   {
/* 141:254 */     throw new UnsupportedOperationException();
/* 142:    */   }
/* 143:    */   
/* 144:    */   @Deprecated
/* 145:    */   public final int setCount(E element, int count)
/* 146:    */   {
/* 147:266 */     throw new UnsupportedOperationException();
/* 148:    */   }
/* 149:    */   
/* 150:    */   @Deprecated
/* 151:    */   public final boolean setCount(E element, int oldCount, int newCount)
/* 152:    */   {
/* 153:278 */     throw new UnsupportedOperationException();
/* 154:    */   }
/* 155:    */   
/* 156:    */   @GwtIncompatible("not present in emulated superclass")
/* 157:    */   int copyIntoArray(Object[] dst, int offset)
/* 158:    */   {
/* 159:284 */     for (Multiset.Entry<E> entry : entrySet())
/* 160:    */     {
/* 161:285 */       Arrays.fill(dst, offset, offset + entry.getCount(), entry.getElement());
/* 162:286 */       offset += entry.getCount();
/* 163:    */     }
/* 164:288 */     return offset;
/* 165:    */   }
/* 166:    */   
/* 167:    */   public boolean equals(@Nullable Object object)
/* 168:    */   {
/* 169:293 */     return Multisets.equalsImpl(this, object);
/* 170:    */   }
/* 171:    */   
/* 172:    */   public int hashCode()
/* 173:    */   {
/* 174:298 */     return Sets.hashCodeImpl(entrySet());
/* 175:    */   }
/* 176:    */   
/* 177:    */   public String toString()
/* 178:    */   {
/* 179:303 */     return entrySet().toString();
/* 180:    */   }
/* 181:    */   
/* 182:    */   public ImmutableSet<Multiset.Entry<E>> entrySet()
/* 183:    */   {
/* 184:310 */     ImmutableSet<Multiset.Entry<E>> es = this.entrySet;
/* 185:311 */     return es == null ? (this.entrySet = createEntrySet()) : es;
/* 186:    */   }
/* 187:    */   
/* 188:    */   private final ImmutableSet<Multiset.Entry<E>> createEntrySet()
/* 189:    */   {
/* 190:315 */     return isEmpty() ? ImmutableSet.of() : new EntrySet(null);
/* 191:    */   }
/* 192:    */   
/* 193:    */   abstract Multiset.Entry<E> getEntry(int paramInt);
/* 194:    */   
/* 195:    */   private final class EntrySet
/* 196:    */     extends ImmutableSet.Indexed<Multiset.Entry<E>>
/* 197:    */   {
/* 198:    */     private static final long serialVersionUID = 0L;
/* 199:    */     
/* 200:    */     private EntrySet() {}
/* 201:    */     
/* 202:    */     boolean isPartialView()
/* 203:    */     {
/* 204:324 */       return ImmutableMultiset.this.isPartialView();
/* 205:    */     }
/* 206:    */     
/* 207:    */     Multiset.Entry<E> get(int index)
/* 208:    */     {
/* 209:329 */       return ImmutableMultiset.this.getEntry(index);
/* 210:    */     }
/* 211:    */     
/* 212:    */     public int size()
/* 213:    */     {
/* 214:334 */       return ImmutableMultiset.this.elementSet().size();
/* 215:    */     }
/* 216:    */     
/* 217:    */     public boolean contains(Object o)
/* 218:    */     {
/* 219:339 */       if ((o instanceof Multiset.Entry))
/* 220:    */       {
/* 221:340 */         Multiset.Entry<?> entry = (Multiset.Entry)o;
/* 222:341 */         if (entry.getCount() <= 0) {
/* 223:342 */           return false;
/* 224:    */         }
/* 225:344 */         int count = ImmutableMultiset.this.count(entry.getElement());
/* 226:345 */         return count == entry.getCount();
/* 227:    */       }
/* 228:347 */       return false;
/* 229:    */     }
/* 230:    */     
/* 231:    */     public int hashCode()
/* 232:    */     {
/* 233:352 */       return ImmutableMultiset.this.hashCode();
/* 234:    */     }
/* 235:    */     
/* 236:    */     Object writeReplace()
/* 237:    */     {
/* 238:359 */       return new ImmutableMultiset.EntrySetSerializedForm(ImmutableMultiset.this);
/* 239:    */     }
/* 240:    */   }
/* 241:    */   
/* 242:    */   static class EntrySetSerializedForm<E>
/* 243:    */     implements Serializable
/* 244:    */   {
/* 245:    */     final ImmutableMultiset<E> multiset;
/* 246:    */     
/* 247:    */     EntrySetSerializedForm(ImmutableMultiset<E> multiset)
/* 248:    */     {
/* 249:369 */       this.multiset = multiset;
/* 250:    */     }
/* 251:    */     
/* 252:    */     Object readResolve()
/* 253:    */     {
/* 254:373 */       return this.multiset.entrySet();
/* 255:    */     }
/* 256:    */   }
/* 257:    */   
/* 258:    */   private static class SerializedForm
/* 259:    */     implements Serializable
/* 260:    */   {
/* 261:    */     final Object[] elements;
/* 262:    */     final int[] counts;
/* 263:    */     private static final long serialVersionUID = 0L;
/* 264:    */     
/* 265:    */     SerializedForm(Multiset<?> multiset)
/* 266:    */     {
/* 267:382 */       int distinct = multiset.entrySet().size();
/* 268:383 */       this.elements = new Object[distinct];
/* 269:384 */       this.counts = new int[distinct];
/* 270:385 */       int i = 0;
/* 271:386 */       for (Multiset.Entry<?> entry : multiset.entrySet())
/* 272:    */       {
/* 273:387 */         this.elements[i] = entry.getElement();
/* 274:388 */         this.counts[i] = entry.getCount();
/* 275:389 */         i++;
/* 276:    */       }
/* 277:    */     }
/* 278:    */     
/* 279:    */     Object readResolve()
/* 280:    */     {
/* 281:394 */       LinkedHashMultiset<Object> multiset = LinkedHashMultiset.create(this.elements.length);
/* 282:395 */       for (int i = 0; i < this.elements.length; i++) {
/* 283:396 */         multiset.add(this.elements[i], this.counts[i]);
/* 284:    */       }
/* 285:398 */       return ImmutableMultiset.copyOf(multiset);
/* 286:    */     }
/* 287:    */   }
/* 288:    */   
/* 289:    */   Object writeReplace()
/* 290:    */   {
/* 291:407 */     return new SerializedForm(this);
/* 292:    */   }
/* 293:    */   
/* 294:    */   public static <E> Builder<E> builder()
/* 295:    */   {
/* 296:415 */     return new Builder();
/* 297:    */   }
/* 298:    */   
/* 299:    */   public static class Builder<E>
/* 300:    */     extends ImmutableCollection.Builder<E>
/* 301:    */   {
/* 302:    */     final Multiset<E> contents;
/* 303:    */     
/* 304:    */     public Builder()
/* 305:    */     {
/* 306:444 */       this(LinkedHashMultiset.create());
/* 307:    */     }
/* 308:    */     
/* 309:    */     Builder(Multiset<E> contents)
/* 310:    */     {
/* 311:448 */       this.contents = contents;
/* 312:    */     }
/* 313:    */     
/* 314:    */     public Builder<E> add(E element)
/* 315:    */     {
/* 316:460 */       this.contents.add(Preconditions.checkNotNull(element));
/* 317:461 */       return this;
/* 318:    */     }
/* 319:    */     
/* 320:    */     public Builder<E> addCopies(E element, int occurrences)
/* 321:    */     {
/* 322:478 */       this.contents.add(Preconditions.checkNotNull(element), occurrences);
/* 323:479 */       return this;
/* 324:    */     }
/* 325:    */     
/* 326:    */     public Builder<E> setCount(E element, int count)
/* 327:    */     {
/* 328:493 */       this.contents.setCount(Preconditions.checkNotNull(element), count);
/* 329:494 */       return this;
/* 330:    */     }
/* 331:    */     
/* 332:    */     public Builder<E> add(E... elements)
/* 333:    */     {
/* 334:507 */       super.add(elements);
/* 335:508 */       return this;
/* 336:    */     }
/* 337:    */     
/* 338:    */     public Builder<E> addAll(Iterable<? extends E> elements)
/* 339:    */     {
/* 340:522 */       if ((elements instanceof Multiset))
/* 341:    */       {
/* 342:523 */         Multiset<? extends E> multiset = Multisets.cast(elements);
/* 343:524 */         for (Multiset.Entry<? extends E> entry : multiset.entrySet()) {
/* 344:525 */           addCopies(entry.getElement(), entry.getCount());
/* 345:    */         }
/* 346:    */       }
/* 347:    */       else
/* 348:    */       {
/* 349:528 */         super.addAll(elements);
/* 350:    */       }
/* 351:530 */       return this;
/* 352:    */     }
/* 353:    */     
/* 354:    */     public Builder<E> addAll(Iterator<? extends E> elements)
/* 355:    */     {
/* 356:543 */       super.addAll(elements);
/* 357:544 */       return this;
/* 358:    */     }
/* 359:    */     
/* 360:    */     public ImmutableMultiset<E> build()
/* 361:    */     {
/* 362:553 */       return ImmutableMultiset.copyOf(this.contents);
/* 363:    */     }
/* 364:    */   }
/* 365:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableMultiset
 * JD-Core Version:    0.7.0.1
 */