/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.ListIterator;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public abstract class UnmodifiableListIterator<E>
/*  8:   */   extends UnmodifiableIterator<E>
/*  9:   */   implements ListIterator<E>
/* 10:   */ {
/* 11:   */   @Deprecated
/* 12:   */   public final void add(E e)
/* 13:   */   {
/* 14:45 */     throw new UnsupportedOperationException();
/* 15:   */   }
/* 16:   */   
/* 17:   */   @Deprecated
/* 18:   */   public final void set(E e)
/* 19:   */   {
/* 20:57 */     throw new UnsupportedOperationException();
/* 21:   */   }
/* 22:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.UnmodifiableListIterator
 * JD-Core Version:    0.7.0.1
 */