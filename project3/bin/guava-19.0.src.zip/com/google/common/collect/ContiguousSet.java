/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.util.Comparator;
/*   8:    */ import java.util.NoSuchElementException;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ @GwtCompatible(emulated=true)
/*  12:    */ public abstract class ContiguousSet<C extends Comparable>
/*  13:    */   extends ImmutableSortedSet<C>
/*  14:    */ {
/*  15:    */   final DiscreteDomain<C> domain;
/*  16:    */   
/*  17:    */   public static <C extends Comparable> ContiguousSet<C> create(Range<C> range, DiscreteDomain<C> domain)
/*  18:    */   {
/*  19: 54 */     Preconditions.checkNotNull(range);
/*  20: 55 */     Preconditions.checkNotNull(domain);
/*  21: 56 */     Range<C> effectiveRange = range;
/*  22:    */     try
/*  23:    */     {
/*  24: 58 */       if (!range.hasLowerBound()) {
/*  25: 59 */         effectiveRange = effectiveRange.intersection(Range.atLeast(domain.minValue()));
/*  26:    */       }
/*  27: 61 */       if (!range.hasUpperBound()) {
/*  28: 62 */         effectiveRange = effectiveRange.intersection(Range.atMost(domain.maxValue()));
/*  29:    */       }
/*  30:    */     }
/*  31:    */     catch (NoSuchElementException e)
/*  32:    */     {
/*  33: 65 */       throw new IllegalArgumentException(e);
/*  34:    */     }
/*  35: 69 */     boolean empty = (effectiveRange.isEmpty()) || (Range.compareOrThrow(range.lowerBound.leastValueAbove(domain), range.upperBound.greatestValueBelow(domain)) > 0);
/*  36:    */     
/*  37:    */ 
/*  38:    */ 
/*  39:    */ 
/*  40:    */ 
/*  41:    */ 
/*  42: 76 */     return empty ? new EmptyContiguousSet(domain) : new RegularContiguousSet(effectiveRange, domain);
/*  43:    */   }
/*  44:    */   
/*  45:    */   ContiguousSet(DiscreteDomain<C> domain)
/*  46:    */   {
/*  47: 84 */     super(Ordering.natural());
/*  48: 85 */     this.domain = domain;
/*  49:    */   }
/*  50:    */   
/*  51:    */   public ContiguousSet<C> headSet(C toElement)
/*  52:    */   {
/*  53: 90 */     return headSetImpl((Comparable)Preconditions.checkNotNull(toElement), false);
/*  54:    */   }
/*  55:    */   
/*  56:    */   @GwtIncompatible("NavigableSet")
/*  57:    */   public ContiguousSet<C> headSet(C toElement, boolean inclusive)
/*  58:    */   {
/*  59: 99 */     return headSetImpl((Comparable)Preconditions.checkNotNull(toElement), inclusive);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public ContiguousSet<C> subSet(C fromElement, C toElement)
/*  63:    */   {
/*  64:104 */     Preconditions.checkNotNull(fromElement);
/*  65:105 */     Preconditions.checkNotNull(toElement);
/*  66:106 */     Preconditions.checkArgument(comparator().compare(fromElement, toElement) <= 0);
/*  67:107 */     return subSetImpl(fromElement, true, toElement, false);
/*  68:    */   }
/*  69:    */   
/*  70:    */   @GwtIncompatible("NavigableSet")
/*  71:    */   public ContiguousSet<C> subSet(C fromElement, boolean fromInclusive, C toElement, boolean toInclusive)
/*  72:    */   {
/*  73:117 */     Preconditions.checkNotNull(fromElement);
/*  74:118 */     Preconditions.checkNotNull(toElement);
/*  75:119 */     Preconditions.checkArgument(comparator().compare(fromElement, toElement) <= 0);
/*  76:120 */     return subSetImpl(fromElement, fromInclusive, toElement, toInclusive);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public ContiguousSet<C> tailSet(C fromElement)
/*  80:    */   {
/*  81:125 */     return tailSetImpl((Comparable)Preconditions.checkNotNull(fromElement), true);
/*  82:    */   }
/*  83:    */   
/*  84:    */   @GwtIncompatible("NavigableSet")
/*  85:    */   public ContiguousSet<C> tailSet(C fromElement, boolean inclusive)
/*  86:    */   {
/*  87:134 */     return tailSetImpl((Comparable)Preconditions.checkNotNull(fromElement), inclusive);
/*  88:    */   }
/*  89:    */   
/*  90:    */   abstract ContiguousSet<C> headSetImpl(C paramC, boolean paramBoolean);
/*  91:    */   
/*  92:    */   abstract ContiguousSet<C> subSetImpl(C paramC1, boolean paramBoolean1, C paramC2, boolean paramBoolean2);
/*  93:    */   
/*  94:    */   abstract ContiguousSet<C> tailSetImpl(C paramC, boolean paramBoolean);
/*  95:    */   
/*  96:    */   public abstract ContiguousSet<C> intersection(ContiguousSet<C> paramContiguousSet);
/*  97:    */   
/*  98:    */   public abstract Range<C> range();
/*  99:    */   
/* 100:    */   public abstract Range<C> range(BoundType paramBoundType1, BoundType paramBoundType2);
/* 101:    */   
/* 102:    */   public String toString()
/* 103:    */   {
/* 104:183 */     return range().toString();
/* 105:    */   }
/* 106:    */   
/* 107:    */   @Deprecated
/* 108:    */   public static <E> ImmutableSortedSet.Builder<E> builder()
/* 109:    */   {
/* 110:196 */     throw new UnsupportedOperationException();
/* 111:    */   }
/* 112:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ContiguousSet
 * JD-Core Version:    0.7.0.1
 */