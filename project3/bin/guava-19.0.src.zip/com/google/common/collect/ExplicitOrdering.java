/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import java.util.List;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible(serializable=true)
/*  9:   */ final class ExplicitOrdering<T>
/* 10:   */   extends Ordering<T>
/* 11:   */   implements Serializable
/* 12:   */ {
/* 13:   */   final ImmutableMap<T, Integer> rankMap;
/* 14:   */   private static final long serialVersionUID = 0L;
/* 15:   */   
/* 16:   */   ExplicitOrdering(List<T> valuesInOrder)
/* 17:   */   {
/* 18:32 */     this(Maps.indexMap(valuesInOrder));
/* 19:   */   }
/* 20:   */   
/* 21:   */   ExplicitOrdering(ImmutableMap<T, Integer> rankMap)
/* 22:   */   {
/* 23:36 */     this.rankMap = rankMap;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public int compare(T left, T right)
/* 27:   */   {
/* 28:41 */     return rank(left) - rank(right);
/* 29:   */   }
/* 30:   */   
/* 31:   */   private int rank(T value)
/* 32:   */   {
/* 33:45 */     Integer rank = (Integer)this.rankMap.get(value);
/* 34:46 */     if (rank == null) {
/* 35:47 */       throw new Ordering.IncomparableValueException(value);
/* 36:   */     }
/* 37:49 */     return rank.intValue();
/* 38:   */   }
/* 39:   */   
/* 40:   */   public boolean equals(@Nullable Object object)
/* 41:   */   {
/* 42:54 */     if ((object instanceof ExplicitOrdering))
/* 43:   */     {
/* 44:55 */       ExplicitOrdering<?> that = (ExplicitOrdering)object;
/* 45:56 */       return this.rankMap.equals(that.rankMap);
/* 46:   */     }
/* 47:58 */     return false;
/* 48:   */   }
/* 49:   */   
/* 50:   */   public int hashCode()
/* 51:   */   {
/* 52:63 */     return this.rankMap.hashCode();
/* 53:   */   }
/* 54:   */   
/* 55:   */   public String toString()
/* 56:   */   {
/* 57:68 */     return "Ordering.explicit(" + this.rankMap.keySet() + ")";
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ExplicitOrdering
 * JD-Core Version:    0.7.0.1
 */