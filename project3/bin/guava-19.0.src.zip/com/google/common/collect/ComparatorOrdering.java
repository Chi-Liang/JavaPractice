/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.io.Serializable;
/*  6:   */ import java.util.Comparator;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @GwtCompatible(serializable=true)
/* 10:   */ final class ComparatorOrdering<T>
/* 11:   */   extends Ordering<T>
/* 12:   */   implements Serializable
/* 13:   */ {
/* 14:   */   final Comparator<T> comparator;
/* 15:   */   private static final long serialVersionUID = 0L;
/* 16:   */   
/* 17:   */   ComparatorOrdering(Comparator<T> comparator)
/* 18:   */   {
/* 19:34 */     this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/* 20:   */   }
/* 21:   */   
/* 22:   */   public int compare(T a, T b)
/* 23:   */   {
/* 24:39 */     return this.comparator.compare(a, b);
/* 25:   */   }
/* 26:   */   
/* 27:   */   public boolean equals(@Nullable Object object)
/* 28:   */   {
/* 29:44 */     if (object == this) {
/* 30:45 */       return true;
/* 31:   */     }
/* 32:47 */     if ((object instanceof ComparatorOrdering))
/* 33:   */     {
/* 34:48 */       ComparatorOrdering<?> that = (ComparatorOrdering)object;
/* 35:49 */       return this.comparator.equals(that.comparator);
/* 36:   */     }
/* 37:51 */     return false;
/* 38:   */   }
/* 39:   */   
/* 40:   */   public int hashCode()
/* 41:   */   {
/* 42:56 */     return this.comparator.hashCode();
/* 43:   */   }
/* 44:   */   
/* 45:   */   public String toString()
/* 46:   */   {
/* 47:61 */     return this.comparator.toString();
/* 48:   */   }
/* 49:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ComparatorOrdering
 * JD-Core Version:    0.7.0.1
 */