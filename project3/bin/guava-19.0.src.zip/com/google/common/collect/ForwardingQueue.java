/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.NoSuchElementException;
/*   5:    */ import java.util.Queue;
/*   6:    */ 
/*   7:    */ @GwtCompatible
/*   8:    */ public abstract class ForwardingQueue<E>
/*   9:    */   extends ForwardingCollection<E>
/*  10:    */   implements Queue<E>
/*  11:    */ {
/*  12:    */   protected abstract Queue<E> delegate();
/*  13:    */   
/*  14:    */   public boolean offer(E o)
/*  15:    */   {
/*  16: 55 */     return delegate().offer(o);
/*  17:    */   }
/*  18:    */   
/*  19:    */   public E poll()
/*  20:    */   {
/*  21: 60 */     return delegate().poll();
/*  22:    */   }
/*  23:    */   
/*  24:    */   public E remove()
/*  25:    */   {
/*  26: 65 */     return delegate().remove();
/*  27:    */   }
/*  28:    */   
/*  29:    */   public E peek()
/*  30:    */   {
/*  31: 70 */     return delegate().peek();
/*  32:    */   }
/*  33:    */   
/*  34:    */   public E element()
/*  35:    */   {
/*  36: 75 */     return delegate().element();
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected boolean standardOffer(E e)
/*  40:    */   {
/*  41:    */     try
/*  42:    */     {
/*  43: 87 */       return add(e);
/*  44:    */     }
/*  45:    */     catch (IllegalStateException caught) {}
/*  46: 89 */     return false;
/*  47:    */   }
/*  48:    */   
/*  49:    */   protected E standardPeek()
/*  50:    */   {
/*  51:    */     try
/*  52:    */     {
/*  53:102 */       return element();
/*  54:    */     }
/*  55:    */     catch (NoSuchElementException caught) {}
/*  56:104 */     return null;
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected E standardPoll()
/*  60:    */   {
/*  61:    */     try
/*  62:    */     {
/*  63:117 */       return remove();
/*  64:    */     }
/*  65:    */     catch (NoSuchElementException caught) {}
/*  66:119 */     return null;
/*  67:    */   }
/*  68:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingQueue
 * JD-Core Version:    0.7.0.1
 */