/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.util.Collections;
/*  6:   */ import java.util.Queue;
/*  7:   */ 
/*  8:   */ @GwtCompatible
/*  9:   */ class ConsumingQueueIterator<T>
/* 10:   */   extends AbstractIterator<T>
/* 11:   */ {
/* 12:   */   private final Queue<T> queue;
/* 13:   */   
/* 14:   */   ConsumingQueueIterator(T... elements)
/* 15:   */   {
/* 16:34 */     this.queue = Lists.newLinkedList();
/* 17:35 */     Collections.addAll(this.queue, elements);
/* 18:   */   }
/* 19:   */   
/* 20:   */   ConsumingQueueIterator(Queue<T> queue)
/* 21:   */   {
/* 22:39 */     this.queue = ((Queue)Preconditions.checkNotNull(queue));
/* 23:   */   }
/* 24:   */   
/* 25:   */   public T computeNext()
/* 26:   */   {
/* 27:44 */     return this.queue.isEmpty() ? endOfData() : this.queue.remove();
/* 28:   */   }
/* 29:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ConsumingQueueIterator
 * JD-Core Version:    0.7.0.1
 */