/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Map;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ import javax.annotation.concurrent.Immutable;
/*   9:    */ 
/*  10:    */ @GwtCompatible
/*  11:    */ @Immutable
/*  12:    */ final class DenseImmutableTable<R, C, V>
/*  13:    */   extends RegularImmutableTable<R, C, V>
/*  14:    */ {
/*  15:    */   private final ImmutableMap<R, Integer> rowKeyToIndex;
/*  16:    */   private final ImmutableMap<C, Integer> columnKeyToIndex;
/*  17:    */   private final ImmutableMap<R, Map<C, V>> rowMap;
/*  18:    */   private final ImmutableMap<C, Map<R, V>> columnMap;
/*  19:    */   private final int[] rowCounts;
/*  20:    */   private final int[] columnCounts;
/*  21:    */   private final V[][] values;
/*  22:    */   private final int[] iterationOrderRow;
/*  23:    */   private final int[] iterationOrderColumn;
/*  24:    */   
/*  25:    */   DenseImmutableTable(ImmutableList<Table.Cell<R, C, V>> cellList, ImmutableSet<R> rowSpace, ImmutableSet<C> columnSpace)
/*  26:    */   {
/*  27: 50 */     V[][] array = (Object[][])new Object[rowSpace.size()][columnSpace.size()];
/*  28: 51 */     this.values = array;
/*  29: 52 */     this.rowKeyToIndex = Maps.indexMap(rowSpace);
/*  30: 53 */     this.columnKeyToIndex = Maps.indexMap(columnSpace);
/*  31: 54 */     this.rowCounts = new int[this.rowKeyToIndex.size()];
/*  32: 55 */     this.columnCounts = new int[this.columnKeyToIndex.size()];
/*  33: 56 */     int[] iterationOrderRow = new int[cellList.size()];
/*  34: 57 */     int[] iterationOrderColumn = new int[cellList.size()];
/*  35: 58 */     for (int i = 0; i < cellList.size(); i++)
/*  36:    */     {
/*  37: 59 */       Table.Cell<R, C, V> cell = (Table.Cell)cellList.get(i);
/*  38: 60 */       R rowKey = cell.getRowKey();
/*  39: 61 */       C columnKey = cell.getColumnKey();
/*  40: 62 */       int rowIndex = ((Integer)this.rowKeyToIndex.get(rowKey)).intValue();
/*  41: 63 */       int columnIndex = ((Integer)this.columnKeyToIndex.get(columnKey)).intValue();
/*  42: 64 */       V existingValue = this.values[rowIndex][columnIndex];
/*  43: 65 */       Preconditions.checkArgument(existingValue == null, "duplicate key: (%s, %s)", new Object[] { rowKey, columnKey });
/*  44: 66 */       this.values[rowIndex][columnIndex] = cell.getValue();
/*  45: 67 */       this.rowCounts[rowIndex] += 1;
/*  46: 68 */       this.columnCounts[columnIndex] += 1;
/*  47: 69 */       iterationOrderRow[i] = rowIndex;
/*  48: 70 */       iterationOrderColumn[i] = columnIndex;
/*  49:    */     }
/*  50: 72 */     this.iterationOrderRow = iterationOrderRow;
/*  51: 73 */     this.iterationOrderColumn = iterationOrderColumn;
/*  52: 74 */     this.rowMap = new RowMap(null);
/*  53: 75 */     this.columnMap = new ColumnMap(null);
/*  54:    */   }
/*  55:    */   
/*  56:    */   private static abstract class ImmutableArrayMap<K, V>
/*  57:    */     extends ImmutableMap.IteratorBasedImmutableMap<K, V>
/*  58:    */   {
/*  59:    */     private final int size;
/*  60:    */     
/*  61:    */     ImmutableArrayMap(int size)
/*  62:    */     {
/*  63: 85 */       this.size = size;
/*  64:    */     }
/*  65:    */     
/*  66:    */     abstract ImmutableMap<K, Integer> keyToIndex();
/*  67:    */     
/*  68:    */     private boolean isFull()
/*  69:    */     {
/*  70: 92 */       return this.size == keyToIndex().size();
/*  71:    */     }
/*  72:    */     
/*  73:    */     K getKey(int index)
/*  74:    */     {
/*  75: 96 */       return keyToIndex().keySet().asList().get(index);
/*  76:    */     }
/*  77:    */     
/*  78:    */     @Nullable
/*  79:    */     abstract V getValue(int paramInt);
/*  80:    */     
/*  81:    */     ImmutableSet<K> createKeySet()
/*  82:    */     {
/*  83:104 */       return isFull() ? keyToIndex().keySet() : super.createKeySet();
/*  84:    */     }
/*  85:    */     
/*  86:    */     public int size()
/*  87:    */     {
/*  88:109 */       return this.size;
/*  89:    */     }
/*  90:    */     
/*  91:    */     public V get(@Nullable Object key)
/*  92:    */     {
/*  93:114 */       Integer keyIndex = (Integer)keyToIndex().get(key);
/*  94:115 */       return keyIndex == null ? null : getValue(keyIndex.intValue());
/*  95:    */     }
/*  96:    */     
/*  97:    */     UnmodifiableIterator<Map.Entry<K, V>> entryIterator()
/*  98:    */     {
/*  99:120 */       new AbstractIterator()
/* 100:    */       {
/* 101:121 */         private int index = -1;
/* 102:122 */         private final int maxIndex = DenseImmutableTable.ImmutableArrayMap.this.keyToIndex().size();
/* 103:    */         
/* 104:    */         protected Map.Entry<K, V> computeNext()
/* 105:    */         {
/* 106:126 */           for (this.index += 1; this.index < this.maxIndex; this.index += 1)
/* 107:    */           {
/* 108:127 */             V value = DenseImmutableTable.ImmutableArrayMap.this.getValue(this.index);
/* 109:128 */             if (value != null) {
/* 110:129 */               return Maps.immutableEntry(DenseImmutableTable.ImmutableArrayMap.this.getKey(this.index), value);
/* 111:    */             }
/* 112:    */           }
/* 113:132 */           return (Map.Entry)endOfData();
/* 114:    */         }
/* 115:    */       };
/* 116:    */     }
/* 117:    */   }
/* 118:    */   
/* 119:    */   private final class Row
/* 120:    */     extends DenseImmutableTable.ImmutableArrayMap<C, V>
/* 121:    */   {
/* 122:    */     private final int rowIndex;
/* 123:    */     
/* 124:    */     Row(int rowIndex)
/* 125:    */     {
/* 126:142 */       super();
/* 127:143 */       this.rowIndex = rowIndex;
/* 128:    */     }
/* 129:    */     
/* 130:    */     ImmutableMap<C, Integer> keyToIndex()
/* 131:    */     {
/* 132:148 */       return DenseImmutableTable.this.columnKeyToIndex;
/* 133:    */     }
/* 134:    */     
/* 135:    */     V getValue(int keyIndex)
/* 136:    */     {
/* 137:153 */       return DenseImmutableTable.this.values[this.rowIndex][keyIndex];
/* 138:    */     }
/* 139:    */     
/* 140:    */     boolean isPartialView()
/* 141:    */     {
/* 142:158 */       return true;
/* 143:    */     }
/* 144:    */   }
/* 145:    */   
/* 146:    */   private final class Column
/* 147:    */     extends DenseImmutableTable.ImmutableArrayMap<R, V>
/* 148:    */   {
/* 149:    */     private final int columnIndex;
/* 150:    */     
/* 151:    */     Column(int columnIndex)
/* 152:    */     {
/* 153:166 */       super();
/* 154:167 */       this.columnIndex = columnIndex;
/* 155:    */     }
/* 156:    */     
/* 157:    */     ImmutableMap<R, Integer> keyToIndex()
/* 158:    */     {
/* 159:172 */       return DenseImmutableTable.this.rowKeyToIndex;
/* 160:    */     }
/* 161:    */     
/* 162:    */     V getValue(int keyIndex)
/* 163:    */     {
/* 164:177 */       return DenseImmutableTable.this.values[keyIndex][this.columnIndex];
/* 165:    */     }
/* 166:    */     
/* 167:    */     boolean isPartialView()
/* 168:    */     {
/* 169:182 */       return true;
/* 170:    */     }
/* 171:    */   }
/* 172:    */   
/* 173:    */   private final class RowMap
/* 174:    */     extends DenseImmutableTable.ImmutableArrayMap<R, Map<C, V>>
/* 175:    */   {
/* 176:    */     private RowMap()
/* 177:    */     {
/* 178:189 */       super();
/* 179:    */     }
/* 180:    */     
/* 181:    */     ImmutableMap<R, Integer> keyToIndex()
/* 182:    */     {
/* 183:194 */       return DenseImmutableTable.this.rowKeyToIndex;
/* 184:    */     }
/* 185:    */     
/* 186:    */     Map<C, V> getValue(int keyIndex)
/* 187:    */     {
/* 188:199 */       return new DenseImmutableTable.Row(DenseImmutableTable.this, keyIndex);
/* 189:    */     }
/* 190:    */     
/* 191:    */     boolean isPartialView()
/* 192:    */     {
/* 193:204 */       return false;
/* 194:    */     }
/* 195:    */   }
/* 196:    */   
/* 197:    */   private final class ColumnMap
/* 198:    */     extends DenseImmutableTable.ImmutableArrayMap<C, Map<R, V>>
/* 199:    */   {
/* 200:    */     private ColumnMap()
/* 201:    */     {
/* 202:211 */       super();
/* 203:    */     }
/* 204:    */     
/* 205:    */     ImmutableMap<C, Integer> keyToIndex()
/* 206:    */     {
/* 207:216 */       return DenseImmutableTable.this.columnKeyToIndex;
/* 208:    */     }
/* 209:    */     
/* 210:    */     Map<R, V> getValue(int keyIndex)
/* 211:    */     {
/* 212:221 */       return new DenseImmutableTable.Column(DenseImmutableTable.this, keyIndex);
/* 213:    */     }
/* 214:    */     
/* 215:    */     boolean isPartialView()
/* 216:    */     {
/* 217:226 */       return false;
/* 218:    */     }
/* 219:    */   }
/* 220:    */   
/* 221:    */   public ImmutableMap<C, Map<R, V>> columnMap()
/* 222:    */   {
/* 223:232 */     return this.columnMap;
/* 224:    */   }
/* 225:    */   
/* 226:    */   public ImmutableMap<R, Map<C, V>> rowMap()
/* 227:    */   {
/* 228:237 */     return this.rowMap;
/* 229:    */   }
/* 230:    */   
/* 231:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/* 232:    */   {
/* 233:242 */     Integer rowIndex = (Integer)this.rowKeyToIndex.get(rowKey);
/* 234:243 */     Integer columnIndex = (Integer)this.columnKeyToIndex.get(columnKey);
/* 235:244 */     return (rowIndex == null) || (columnIndex == null) ? null : this.values[rowIndex.intValue()][columnIndex.intValue()];
/* 236:    */   }
/* 237:    */   
/* 238:    */   public int size()
/* 239:    */   {
/* 240:249 */     return this.iterationOrderRow.length;
/* 241:    */   }
/* 242:    */   
/* 243:    */   Table.Cell<R, C, V> getCell(int index)
/* 244:    */   {
/* 245:254 */     int rowIndex = this.iterationOrderRow[index];
/* 246:255 */     int columnIndex = this.iterationOrderColumn[index];
/* 247:256 */     R rowKey = rowKeySet().asList().get(rowIndex);
/* 248:257 */     C columnKey = columnKeySet().asList().get(columnIndex);
/* 249:258 */     V value = this.values[rowIndex][columnIndex];
/* 250:259 */     return cellOf(rowKey, columnKey, value);
/* 251:    */   }
/* 252:    */   
/* 253:    */   V getValue(int index)
/* 254:    */   {
/* 255:264 */     return this.values[this.iterationOrderRow[index]][this.iterationOrderColumn[index]];
/* 256:    */   }
/* 257:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.DenseImmutableTable
 * JD-Core Version:    0.7.0.1
 */