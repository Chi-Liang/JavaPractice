/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Function;
/*    7:     */ import com.google.common.base.Preconditions;
/*    8:     */ import com.google.common.base.Predicate;
/*    9:     */ import com.google.common.base.Predicates;
/*   10:     */ import com.google.common.base.Supplier;
/*   11:     */ import com.google.j2objc.annotations.Weak;
/*   12:     */ import java.io.IOException;
/*   13:     */ import java.io.ObjectInputStream;
/*   14:     */ import java.io.ObjectOutputStream;
/*   15:     */ import java.io.Serializable;
/*   16:     */ import java.util.AbstractCollection;
/*   17:     */ import java.util.Collection;
/*   18:     */ import java.util.Collections;
/*   19:     */ import java.util.Comparator;
/*   20:     */ import java.util.HashSet;
/*   21:     */ import java.util.Iterator;
/*   22:     */ import java.util.List;
/*   23:     */ import java.util.Map;
/*   24:     */ import java.util.Map.Entry;
/*   25:     */ import java.util.NoSuchElementException;
/*   26:     */ import java.util.Set;
/*   27:     */ import java.util.SortedSet;
/*   28:     */ import javax.annotation.CheckReturnValue;
/*   29:     */ import javax.annotation.Nullable;
/*   30:     */ 
/*   31:     */ @GwtCompatible(emulated=true)
/*   32:     */ public final class Multimaps
/*   33:     */ {
/*   34:     */   public static <K, V> Multimap<K, V> newMultimap(Map<K, Collection<V>> map, Supplier<? extends Collection<V>> factory)
/*   35:     */   {
/*   36: 116 */     return new CustomMultimap(map, factory);
/*   37:     */   }
/*   38:     */   
/*   39:     */   private static class CustomMultimap<K, V>
/*   40:     */     extends AbstractMapBasedMultimap<K, V>
/*   41:     */   {
/*   42:     */     transient Supplier<? extends Collection<V>> factory;
/*   43:     */     @GwtIncompatible("java serialization not supported")
/*   44:     */     private static final long serialVersionUID = 0L;
/*   45:     */     
/*   46:     */     CustomMultimap(Map<K, Collection<V>> map, Supplier<? extends Collection<V>> factory)
/*   47:     */     {
/*   48: 123 */       super();
/*   49: 124 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*   50:     */     }
/*   51:     */     
/*   52:     */     protected Collection<V> createCollection()
/*   53:     */     {
/*   54: 129 */       return (Collection)this.factory.get();
/*   55:     */     }
/*   56:     */     
/*   57:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*   58:     */     private void writeObject(ObjectOutputStream stream)
/*   59:     */       throws IOException
/*   60:     */     {
/*   61: 138 */       stream.defaultWriteObject();
/*   62: 139 */       stream.writeObject(this.factory);
/*   63: 140 */       stream.writeObject(backingMap());
/*   64:     */     }
/*   65:     */     
/*   66:     */     @GwtIncompatible("java.io.ObjectInputStream")
/*   67:     */     private void readObject(ObjectInputStream stream)
/*   68:     */       throws IOException, ClassNotFoundException
/*   69:     */     {
/*   70: 146 */       stream.defaultReadObject();
/*   71: 147 */       this.factory = ((Supplier)stream.readObject());
/*   72: 148 */       Map<K, Collection<V>> map = (Map)stream.readObject();
/*   73: 149 */       setMap(map);
/*   74:     */     }
/*   75:     */   }
/*   76:     */   
/*   77:     */   public static <K, V> ListMultimap<K, V> newListMultimap(Map<K, Collection<V>> map, Supplier<? extends List<V>> factory)
/*   78:     */   {
/*   79: 196 */     return new CustomListMultimap(map, factory);
/*   80:     */   }
/*   81:     */   
/*   82:     */   private static class CustomListMultimap<K, V>
/*   83:     */     extends AbstractListMultimap<K, V>
/*   84:     */   {
/*   85:     */     transient Supplier<? extends List<V>> factory;
/*   86:     */     @GwtIncompatible("java serialization not supported")
/*   87:     */     private static final long serialVersionUID = 0L;
/*   88:     */     
/*   89:     */     CustomListMultimap(Map<K, Collection<V>> map, Supplier<? extends List<V>> factory)
/*   90:     */     {
/*   91: 203 */       super();
/*   92: 204 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*   93:     */     }
/*   94:     */     
/*   95:     */     protected List<V> createCollection()
/*   96:     */     {
/*   97: 209 */       return (List)this.factory.get();
/*   98:     */     }
/*   99:     */     
/*  100:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*  101:     */     private void writeObject(ObjectOutputStream stream)
/*  102:     */       throws IOException
/*  103:     */     {
/*  104: 215 */       stream.defaultWriteObject();
/*  105: 216 */       stream.writeObject(this.factory);
/*  106: 217 */       stream.writeObject(backingMap());
/*  107:     */     }
/*  108:     */     
/*  109:     */     @GwtIncompatible("java.io.ObjectInputStream")
/*  110:     */     private void readObject(ObjectInputStream stream)
/*  111:     */       throws IOException, ClassNotFoundException
/*  112:     */     {
/*  113: 223 */       stream.defaultReadObject();
/*  114: 224 */       this.factory = ((Supplier)stream.readObject());
/*  115: 225 */       Map<K, Collection<V>> map = (Map)stream.readObject();
/*  116: 226 */       setMap(map);
/*  117:     */     }
/*  118:     */   }
/*  119:     */   
/*  120:     */   public static <K, V> SetMultimap<K, V> newSetMultimap(Map<K, Collection<V>> map, Supplier<? extends Set<V>> factory)
/*  121:     */   {
/*  122: 272 */     return new CustomSetMultimap(map, factory);
/*  123:     */   }
/*  124:     */   
/*  125:     */   private static class CustomSetMultimap<K, V>
/*  126:     */     extends AbstractSetMultimap<K, V>
/*  127:     */   {
/*  128:     */     transient Supplier<? extends Set<V>> factory;
/*  129:     */     @GwtIncompatible("not needed in emulated source")
/*  130:     */     private static final long serialVersionUID = 0L;
/*  131:     */     
/*  132:     */     CustomSetMultimap(Map<K, Collection<V>> map, Supplier<? extends Set<V>> factory)
/*  133:     */     {
/*  134: 279 */       super();
/*  135: 280 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*  136:     */     }
/*  137:     */     
/*  138:     */     protected Set<V> createCollection()
/*  139:     */     {
/*  140: 285 */       return (Set)this.factory.get();
/*  141:     */     }
/*  142:     */     
/*  143:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*  144:     */     private void writeObject(ObjectOutputStream stream)
/*  145:     */       throws IOException
/*  146:     */     {
/*  147: 291 */       stream.defaultWriteObject();
/*  148: 292 */       stream.writeObject(this.factory);
/*  149: 293 */       stream.writeObject(backingMap());
/*  150:     */     }
/*  151:     */     
/*  152:     */     @GwtIncompatible("java.io.ObjectInputStream")
/*  153:     */     private void readObject(ObjectInputStream stream)
/*  154:     */       throws IOException, ClassNotFoundException
/*  155:     */     {
/*  156: 299 */       stream.defaultReadObject();
/*  157: 300 */       this.factory = ((Supplier)stream.readObject());
/*  158: 301 */       Map<K, Collection<V>> map = (Map)stream.readObject();
/*  159: 302 */       setMap(map);
/*  160:     */     }
/*  161:     */   }
/*  162:     */   
/*  163:     */   public static <K, V> SortedSetMultimap<K, V> newSortedSetMultimap(Map<K, Collection<V>> map, Supplier<? extends SortedSet<V>> factory)
/*  164:     */   {
/*  165: 347 */     return new CustomSortedSetMultimap(map, factory);
/*  166:     */   }
/*  167:     */   
/*  168:     */   private static class CustomSortedSetMultimap<K, V>
/*  169:     */     extends AbstractSortedSetMultimap<K, V>
/*  170:     */   {
/*  171:     */     transient Supplier<? extends SortedSet<V>> factory;
/*  172:     */     transient Comparator<? super V> valueComparator;
/*  173:     */     @GwtIncompatible("not needed in emulated source")
/*  174:     */     private static final long serialVersionUID = 0L;
/*  175:     */     
/*  176:     */     CustomSortedSetMultimap(Map<K, Collection<V>> map, Supplier<? extends SortedSet<V>> factory)
/*  177:     */     {
/*  178: 355 */       super();
/*  179: 356 */       this.factory = ((Supplier)Preconditions.checkNotNull(factory));
/*  180: 357 */       this.valueComparator = ((SortedSet)factory.get()).comparator();
/*  181:     */     }
/*  182:     */     
/*  183:     */     protected SortedSet<V> createCollection()
/*  184:     */     {
/*  185: 362 */       return (SortedSet)this.factory.get();
/*  186:     */     }
/*  187:     */     
/*  188:     */     public Comparator<? super V> valueComparator()
/*  189:     */     {
/*  190: 367 */       return this.valueComparator;
/*  191:     */     }
/*  192:     */     
/*  193:     */     @GwtIncompatible("java.io.ObjectOutputStream")
/*  194:     */     private void writeObject(ObjectOutputStream stream)
/*  195:     */       throws IOException
/*  196:     */     {
/*  197: 373 */       stream.defaultWriteObject();
/*  198: 374 */       stream.writeObject(this.factory);
/*  199: 375 */       stream.writeObject(backingMap());
/*  200:     */     }
/*  201:     */     
/*  202:     */     @GwtIncompatible("java.io.ObjectInputStream")
/*  203:     */     private void readObject(ObjectInputStream stream)
/*  204:     */       throws IOException, ClassNotFoundException
/*  205:     */     {
/*  206: 381 */       stream.defaultReadObject();
/*  207: 382 */       this.factory = ((Supplier)stream.readObject());
/*  208: 383 */       this.valueComparator = ((SortedSet)this.factory.get()).comparator();
/*  209: 384 */       Map<K, Collection<V>> map = (Map)stream.readObject();
/*  210: 385 */       setMap(map);
/*  211:     */     }
/*  212:     */   }
/*  213:     */   
/*  214:     */   public static <K, V, M extends Multimap<K, V>> M invertFrom(Multimap<? extends V, ? extends K> source, M dest)
/*  215:     */   {
/*  216: 405 */     Preconditions.checkNotNull(dest);
/*  217: 406 */     for (Map.Entry<? extends V, ? extends K> entry : source.entries()) {
/*  218: 407 */       dest.put(entry.getValue(), entry.getKey());
/*  219:     */     }
/*  220: 409 */     return dest;
/*  221:     */   }
/*  222:     */   
/*  223:     */   public static <K, V> Multimap<K, V> synchronizedMultimap(Multimap<K, V> multimap)
/*  224:     */   {
/*  225: 446 */     return Synchronized.multimap(multimap, null);
/*  226:     */   }
/*  227:     */   
/*  228:     */   public static <K, V> Multimap<K, V> unmodifiableMultimap(Multimap<K, V> delegate)
/*  229:     */   {
/*  230: 467 */     if (((delegate instanceof UnmodifiableMultimap)) || ((delegate instanceof ImmutableMultimap))) {
/*  231: 468 */       return delegate;
/*  232:     */     }
/*  233: 470 */     return new UnmodifiableMultimap(delegate);
/*  234:     */   }
/*  235:     */   
/*  236:     */   @Deprecated
/*  237:     */   public static <K, V> Multimap<K, V> unmodifiableMultimap(ImmutableMultimap<K, V> delegate)
/*  238:     */   {
/*  239: 481 */     return (Multimap)Preconditions.checkNotNull(delegate);
/*  240:     */   }
/*  241:     */   
/*  242:     */   private static class UnmodifiableMultimap<K, V>
/*  243:     */     extends ForwardingMultimap<K, V>
/*  244:     */     implements Serializable
/*  245:     */   {
/*  246:     */     final Multimap<K, V> delegate;
/*  247:     */     transient Collection<Map.Entry<K, V>> entries;
/*  248:     */     transient Multiset<K> keys;
/*  249:     */     transient Set<K> keySet;
/*  250:     */     transient Collection<V> values;
/*  251:     */     transient Map<K, Collection<V>> map;
/*  252:     */     private static final long serialVersionUID = 0L;
/*  253:     */     
/*  254:     */     UnmodifiableMultimap(Multimap<K, V> delegate)
/*  255:     */     {
/*  256: 494 */       this.delegate = ((Multimap)Preconditions.checkNotNull(delegate));
/*  257:     */     }
/*  258:     */     
/*  259:     */     protected Multimap<K, V> delegate()
/*  260:     */     {
/*  261: 499 */       return this.delegate;
/*  262:     */     }
/*  263:     */     
/*  264:     */     public void clear()
/*  265:     */     {
/*  266: 504 */       throw new UnsupportedOperationException();
/*  267:     */     }
/*  268:     */     
/*  269:     */     public Map<K, Collection<V>> asMap()
/*  270:     */     {
/*  271: 509 */       Map<K, Collection<V>> result = this.map;
/*  272: 510 */       if (result == null) {
/*  273: 511 */         result = this.map = Collections.unmodifiableMap(Maps.transformValues(this.delegate.asMap(), new Function()
/*  274:     */         {
/*  275:     */           public Collection<V> apply(Collection<V> collection)
/*  276:     */           {
/*  277: 518 */             return Multimaps.unmodifiableValueCollection(collection);
/*  278:     */           }
/*  279:     */         }));
/*  280:     */       }
/*  281: 522 */       return result;
/*  282:     */     }
/*  283:     */     
/*  284:     */     public Collection<Map.Entry<K, V>> entries()
/*  285:     */     {
/*  286: 527 */       Collection<Map.Entry<K, V>> result = this.entries;
/*  287: 528 */       if (result == null) {
/*  288: 529 */         this.entries = (result = Multimaps.unmodifiableEntries(this.delegate.entries()));
/*  289:     */       }
/*  290: 531 */       return result;
/*  291:     */     }
/*  292:     */     
/*  293:     */     public Collection<V> get(K key)
/*  294:     */     {
/*  295: 536 */       return Multimaps.unmodifiableValueCollection(this.delegate.get(key));
/*  296:     */     }
/*  297:     */     
/*  298:     */     public Multiset<K> keys()
/*  299:     */     {
/*  300: 541 */       Multiset<K> result = this.keys;
/*  301: 542 */       if (result == null) {
/*  302: 543 */         this.keys = (result = Multisets.unmodifiableMultiset(this.delegate.keys()));
/*  303:     */       }
/*  304: 545 */       return result;
/*  305:     */     }
/*  306:     */     
/*  307:     */     public Set<K> keySet()
/*  308:     */     {
/*  309: 550 */       Set<K> result = this.keySet;
/*  310: 551 */       if (result == null) {
/*  311: 552 */         this.keySet = (result = Collections.unmodifiableSet(this.delegate.keySet()));
/*  312:     */       }
/*  313: 554 */       return result;
/*  314:     */     }
/*  315:     */     
/*  316:     */     public boolean put(K key, V value)
/*  317:     */     {
/*  318: 559 */       throw new UnsupportedOperationException();
/*  319:     */     }
/*  320:     */     
/*  321:     */     public boolean putAll(K key, Iterable<? extends V> values)
/*  322:     */     {
/*  323: 564 */       throw new UnsupportedOperationException();
/*  324:     */     }
/*  325:     */     
/*  326:     */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*  327:     */     {
/*  328: 569 */       throw new UnsupportedOperationException();
/*  329:     */     }
/*  330:     */     
/*  331:     */     public boolean remove(Object key, Object value)
/*  332:     */     {
/*  333: 574 */       throw new UnsupportedOperationException();
/*  334:     */     }
/*  335:     */     
/*  336:     */     public Collection<V> removeAll(Object key)
/*  337:     */     {
/*  338: 579 */       throw new UnsupportedOperationException();
/*  339:     */     }
/*  340:     */     
/*  341:     */     public Collection<V> replaceValues(K key, Iterable<? extends V> values)
/*  342:     */     {
/*  343: 584 */       throw new UnsupportedOperationException();
/*  344:     */     }
/*  345:     */     
/*  346:     */     public Collection<V> values()
/*  347:     */     {
/*  348: 589 */       Collection<V> result = this.values;
/*  349: 590 */       if (result == null) {
/*  350: 591 */         this.values = (result = Collections.unmodifiableCollection(this.delegate.values()));
/*  351:     */       }
/*  352: 593 */       return result;
/*  353:     */     }
/*  354:     */   }
/*  355:     */   
/*  356:     */   private static class UnmodifiableListMultimap<K, V>
/*  357:     */     extends Multimaps.UnmodifiableMultimap<K, V>
/*  358:     */     implements ListMultimap<K, V>
/*  359:     */   {
/*  360:     */     private static final long serialVersionUID = 0L;
/*  361:     */     
/*  362:     */     UnmodifiableListMultimap(ListMultimap<K, V> delegate)
/*  363:     */     {
/*  364: 602 */       super();
/*  365:     */     }
/*  366:     */     
/*  367:     */     public ListMultimap<K, V> delegate()
/*  368:     */     {
/*  369: 607 */       return (ListMultimap)super.delegate();
/*  370:     */     }
/*  371:     */     
/*  372:     */     public List<V> get(K key)
/*  373:     */     {
/*  374: 612 */       return Collections.unmodifiableList(delegate().get(key));
/*  375:     */     }
/*  376:     */     
/*  377:     */     public List<V> removeAll(Object key)
/*  378:     */     {
/*  379: 617 */       throw new UnsupportedOperationException();
/*  380:     */     }
/*  381:     */     
/*  382:     */     public List<V> replaceValues(K key, Iterable<? extends V> values)
/*  383:     */     {
/*  384: 622 */       throw new UnsupportedOperationException();
/*  385:     */     }
/*  386:     */   }
/*  387:     */   
/*  388:     */   private static class UnmodifiableSetMultimap<K, V>
/*  389:     */     extends Multimaps.UnmodifiableMultimap<K, V>
/*  390:     */     implements SetMultimap<K, V>
/*  391:     */   {
/*  392:     */     private static final long serialVersionUID = 0L;
/*  393:     */     
/*  394:     */     UnmodifiableSetMultimap(SetMultimap<K, V> delegate)
/*  395:     */     {
/*  396: 631 */       super();
/*  397:     */     }
/*  398:     */     
/*  399:     */     public SetMultimap<K, V> delegate()
/*  400:     */     {
/*  401: 636 */       return (SetMultimap)super.delegate();
/*  402:     */     }
/*  403:     */     
/*  404:     */     public Set<V> get(K key)
/*  405:     */     {
/*  406: 645 */       return Collections.unmodifiableSet(delegate().get(key));
/*  407:     */     }
/*  408:     */     
/*  409:     */     public Set<Map.Entry<K, V>> entries()
/*  410:     */     {
/*  411: 650 */       return Maps.unmodifiableEntrySet(delegate().entries());
/*  412:     */     }
/*  413:     */     
/*  414:     */     public Set<V> removeAll(Object key)
/*  415:     */     {
/*  416: 655 */       throw new UnsupportedOperationException();
/*  417:     */     }
/*  418:     */     
/*  419:     */     public Set<V> replaceValues(K key, Iterable<? extends V> values)
/*  420:     */     {
/*  421: 660 */       throw new UnsupportedOperationException();
/*  422:     */     }
/*  423:     */   }
/*  424:     */   
/*  425:     */   private static class UnmodifiableSortedSetMultimap<K, V>
/*  426:     */     extends Multimaps.UnmodifiableSetMultimap<K, V>
/*  427:     */     implements SortedSetMultimap<K, V>
/*  428:     */   {
/*  429:     */     private static final long serialVersionUID = 0L;
/*  430:     */     
/*  431:     */     UnmodifiableSortedSetMultimap(SortedSetMultimap<K, V> delegate)
/*  432:     */     {
/*  433: 669 */       super();
/*  434:     */     }
/*  435:     */     
/*  436:     */     public SortedSetMultimap<K, V> delegate()
/*  437:     */     {
/*  438: 674 */       return (SortedSetMultimap)super.delegate();
/*  439:     */     }
/*  440:     */     
/*  441:     */     public SortedSet<V> get(K key)
/*  442:     */     {
/*  443: 679 */       return Collections.unmodifiableSortedSet(delegate().get(key));
/*  444:     */     }
/*  445:     */     
/*  446:     */     public SortedSet<V> removeAll(Object key)
/*  447:     */     {
/*  448: 684 */       throw new UnsupportedOperationException();
/*  449:     */     }
/*  450:     */     
/*  451:     */     public SortedSet<V> replaceValues(K key, Iterable<? extends V> values)
/*  452:     */     {
/*  453: 689 */       throw new UnsupportedOperationException();
/*  454:     */     }
/*  455:     */     
/*  456:     */     public Comparator<? super V> valueComparator()
/*  457:     */     {
/*  458: 694 */       return delegate().valueComparator();
/*  459:     */     }
/*  460:     */   }
/*  461:     */   
/*  462:     */   public static <K, V> SetMultimap<K, V> synchronizedSetMultimap(SetMultimap<K, V> multimap)
/*  463:     */   {
/*  464: 713 */     return Synchronized.setMultimap(multimap, null);
/*  465:     */   }
/*  466:     */   
/*  467:     */   public static <K, V> SetMultimap<K, V> unmodifiableSetMultimap(SetMultimap<K, V> delegate)
/*  468:     */   {
/*  469: 735 */     if (((delegate instanceof UnmodifiableSetMultimap)) || ((delegate instanceof ImmutableSetMultimap))) {
/*  470: 736 */       return delegate;
/*  471:     */     }
/*  472: 738 */     return new UnmodifiableSetMultimap(delegate);
/*  473:     */   }
/*  474:     */   
/*  475:     */   @Deprecated
/*  476:     */   public static <K, V> SetMultimap<K, V> unmodifiableSetMultimap(ImmutableSetMultimap<K, V> delegate)
/*  477:     */   {
/*  478: 750 */     return (SetMultimap)Preconditions.checkNotNull(delegate);
/*  479:     */   }
/*  480:     */   
/*  481:     */   public static <K, V> SortedSetMultimap<K, V> synchronizedSortedSetMultimap(SortedSetMultimap<K, V> multimap)
/*  482:     */   {
/*  483: 767 */     return Synchronized.sortedSetMultimap(multimap, null);
/*  484:     */   }
/*  485:     */   
/*  486:     */   public static <K, V> SortedSetMultimap<K, V> unmodifiableSortedSetMultimap(SortedSetMultimap<K, V> delegate)
/*  487:     */   {
/*  488: 790 */     if ((delegate instanceof UnmodifiableSortedSetMultimap)) {
/*  489: 791 */       return delegate;
/*  490:     */     }
/*  491: 793 */     return new UnmodifiableSortedSetMultimap(delegate);
/*  492:     */   }
/*  493:     */   
/*  494:     */   public static <K, V> ListMultimap<K, V> synchronizedListMultimap(ListMultimap<K, V> multimap)
/*  495:     */   {
/*  496: 806 */     return Synchronized.listMultimap(multimap, null);
/*  497:     */   }
/*  498:     */   
/*  499:     */   public static <K, V> ListMultimap<K, V> unmodifiableListMultimap(ListMultimap<K, V> delegate)
/*  500:     */   {
/*  501: 828 */     if (((delegate instanceof UnmodifiableListMultimap)) || ((delegate instanceof ImmutableListMultimap))) {
/*  502: 829 */       return delegate;
/*  503:     */     }
/*  504: 831 */     return new UnmodifiableListMultimap(delegate);
/*  505:     */   }
/*  506:     */   
/*  507:     */   @Deprecated
/*  508:     */   public static <K, V> ListMultimap<K, V> unmodifiableListMultimap(ImmutableListMultimap<K, V> delegate)
/*  509:     */   {
/*  510: 843 */     return (ListMultimap)Preconditions.checkNotNull(delegate);
/*  511:     */   }
/*  512:     */   
/*  513:     */   private static <V> Collection<V> unmodifiableValueCollection(Collection<V> collection)
/*  514:     */   {
/*  515: 855 */     if ((collection instanceof SortedSet)) {
/*  516: 856 */       return Collections.unmodifiableSortedSet((SortedSet)collection);
/*  517:     */     }
/*  518: 857 */     if ((collection instanceof Set)) {
/*  519: 858 */       return Collections.unmodifiableSet((Set)collection);
/*  520:     */     }
/*  521: 859 */     if ((collection instanceof List)) {
/*  522: 860 */       return Collections.unmodifiableList((List)collection);
/*  523:     */     }
/*  524: 862 */     return Collections.unmodifiableCollection(collection);
/*  525:     */   }
/*  526:     */   
/*  527:     */   private static <K, V> Collection<Map.Entry<K, V>> unmodifiableEntries(Collection<Map.Entry<K, V>> entries)
/*  528:     */   {
/*  529: 876 */     if ((entries instanceof Set)) {
/*  530: 877 */       return Maps.unmodifiableEntrySet((Set)entries);
/*  531:     */     }
/*  532: 879 */     return new Maps.UnmodifiableEntries(Collections.unmodifiableCollection(entries));
/*  533:     */   }
/*  534:     */   
/*  535:     */   @Beta
/*  536:     */   public static <K, V> Map<K, List<V>> asMap(ListMultimap<K, V> multimap)
/*  537:     */   {
/*  538: 892 */     return multimap.asMap();
/*  539:     */   }
/*  540:     */   
/*  541:     */   @Beta
/*  542:     */   public static <K, V> Map<K, Set<V>> asMap(SetMultimap<K, V> multimap)
/*  543:     */   {
/*  544: 905 */     return multimap.asMap();
/*  545:     */   }
/*  546:     */   
/*  547:     */   @Beta
/*  548:     */   public static <K, V> Map<K, SortedSet<V>> asMap(SortedSetMultimap<K, V> multimap)
/*  549:     */   {
/*  550: 919 */     return multimap.asMap();
/*  551:     */   }
/*  552:     */   
/*  553:     */   @Beta
/*  554:     */   public static <K, V> Map<K, Collection<V>> asMap(Multimap<K, V> multimap)
/*  555:     */   {
/*  556: 930 */     return multimap.asMap();
/*  557:     */   }
/*  558:     */   
/*  559:     */   public static <K, V> SetMultimap<K, V> forMap(Map<K, V> map)
/*  560:     */   {
/*  561: 951 */     return new MapMultimap(map);
/*  562:     */   }
/*  563:     */   
/*  564:     */   private static class MapMultimap<K, V>
/*  565:     */     extends AbstractMultimap<K, V>
/*  566:     */     implements SetMultimap<K, V>, Serializable
/*  567:     */   {
/*  568:     */     final Map<K, V> map;
/*  569:     */     private static final long serialVersionUID = 7845222491160860175L;
/*  570:     */     
/*  571:     */     MapMultimap(Map<K, V> map)
/*  572:     */     {
/*  573: 960 */       this.map = ((Map)Preconditions.checkNotNull(map));
/*  574:     */     }
/*  575:     */     
/*  576:     */     public int size()
/*  577:     */     {
/*  578: 965 */       return this.map.size();
/*  579:     */     }
/*  580:     */     
/*  581:     */     public boolean containsKey(Object key)
/*  582:     */     {
/*  583: 970 */       return this.map.containsKey(key);
/*  584:     */     }
/*  585:     */     
/*  586:     */     public boolean containsValue(Object value)
/*  587:     */     {
/*  588: 975 */       return this.map.containsValue(value);
/*  589:     */     }
/*  590:     */     
/*  591:     */     public boolean containsEntry(Object key, Object value)
/*  592:     */     {
/*  593: 980 */       return this.map.entrySet().contains(Maps.immutableEntry(key, value));
/*  594:     */     }
/*  595:     */     
/*  596:     */     public Set<V> get(final K key)
/*  597:     */     {
/*  598: 985 */       new Sets.ImprovedAbstractSet()
/*  599:     */       {
/*  600:     */         public Iterator<V> iterator()
/*  601:     */         {
/*  602: 988 */           new Iterator()
/*  603:     */           {
/*  604:     */             int i;
/*  605:     */             
/*  606:     */             public boolean hasNext()
/*  607:     */             {
/*  608: 993 */               return (this.i == 0) && (Multimaps.MapMultimap.this.map.containsKey(Multimaps.MapMultimap.1.this.val$key));
/*  609:     */             }
/*  610:     */             
/*  611:     */             public V next()
/*  612:     */             {
/*  613: 998 */               if (!hasNext()) {
/*  614: 999 */                 throw new NoSuchElementException();
/*  615:     */               }
/*  616:1001 */               this.i += 1;
/*  617:1002 */               return Multimaps.MapMultimap.this.map.get(Multimaps.MapMultimap.1.this.val$key);
/*  618:     */             }
/*  619:     */             
/*  620:     */             public void remove()
/*  621:     */             {
/*  622:1007 */               CollectPreconditions.checkRemove(this.i == 1);
/*  623:1008 */               this.i = -1;
/*  624:1009 */               Multimaps.MapMultimap.this.map.remove(Multimaps.MapMultimap.1.this.val$key);
/*  625:     */             }
/*  626:     */           };
/*  627:     */         }
/*  628:     */         
/*  629:     */         public int size()
/*  630:     */         {
/*  631:1016 */           return Multimaps.MapMultimap.this.map.containsKey(key) ? 1 : 0;
/*  632:     */         }
/*  633:     */       };
/*  634:     */     }
/*  635:     */     
/*  636:     */     public boolean put(K key, V value)
/*  637:     */     {
/*  638:1023 */       throw new UnsupportedOperationException();
/*  639:     */     }
/*  640:     */     
/*  641:     */     public boolean putAll(K key, Iterable<? extends V> values)
/*  642:     */     {
/*  643:1028 */       throw new UnsupportedOperationException();
/*  644:     */     }
/*  645:     */     
/*  646:     */     public boolean putAll(Multimap<? extends K, ? extends V> multimap)
/*  647:     */     {
/*  648:1033 */       throw new UnsupportedOperationException();
/*  649:     */     }
/*  650:     */     
/*  651:     */     public Set<V> replaceValues(K key, Iterable<? extends V> values)
/*  652:     */     {
/*  653:1038 */       throw new UnsupportedOperationException();
/*  654:     */     }
/*  655:     */     
/*  656:     */     public boolean remove(Object key, Object value)
/*  657:     */     {
/*  658:1043 */       return this.map.entrySet().remove(Maps.immutableEntry(key, value));
/*  659:     */     }
/*  660:     */     
/*  661:     */     public Set<V> removeAll(Object key)
/*  662:     */     {
/*  663:1048 */       Set<V> values = new HashSet(2);
/*  664:1049 */       if (!this.map.containsKey(key)) {
/*  665:1050 */         return values;
/*  666:     */       }
/*  667:1052 */       values.add(this.map.remove(key));
/*  668:1053 */       return values;
/*  669:     */     }
/*  670:     */     
/*  671:     */     public void clear()
/*  672:     */     {
/*  673:1058 */       this.map.clear();
/*  674:     */     }
/*  675:     */     
/*  676:     */     public Set<K> keySet()
/*  677:     */     {
/*  678:1063 */       return this.map.keySet();
/*  679:     */     }
/*  680:     */     
/*  681:     */     public Collection<V> values()
/*  682:     */     {
/*  683:1068 */       return this.map.values();
/*  684:     */     }
/*  685:     */     
/*  686:     */     public Set<Map.Entry<K, V>> entries()
/*  687:     */     {
/*  688:1073 */       return this.map.entrySet();
/*  689:     */     }
/*  690:     */     
/*  691:     */     Iterator<Map.Entry<K, V>> entryIterator()
/*  692:     */     {
/*  693:1078 */       return this.map.entrySet().iterator();
/*  694:     */     }
/*  695:     */     
/*  696:     */     Map<K, Collection<V>> createAsMap()
/*  697:     */     {
/*  698:1083 */       return new Multimaps.AsMap(this);
/*  699:     */     }
/*  700:     */     
/*  701:     */     public int hashCode()
/*  702:     */     {
/*  703:1088 */       return this.map.hashCode();
/*  704:     */     }
/*  705:     */   }
/*  706:     */   
/*  707:     */   public static <K, V1, V2> Multimap<K, V2> transformValues(Multimap<K, V1> fromMultimap, Function<? super V1, V2> function)
/*  708:     */   {
/*  709:1140 */     Preconditions.checkNotNull(function);
/*  710:1141 */     Maps.EntryTransformer<K, V1, V2> transformer = Maps.asEntryTransformer(function);
/*  711:1142 */     return transformEntries(fromMultimap, transformer);
/*  712:     */   }
/*  713:     */   
/*  714:     */   public static <K, V1, V2> Multimap<K, V2> transformEntries(Multimap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  715:     */   {
/*  716:1202 */     return new TransformedEntriesMultimap(fromMap, transformer);
/*  717:     */   }
/*  718:     */   
/*  719:     */   private static class TransformedEntriesMultimap<K, V1, V2>
/*  720:     */     extends AbstractMultimap<K, V2>
/*  721:     */   {
/*  722:     */     final Multimap<K, V1> fromMultimap;
/*  723:     */     final Maps.EntryTransformer<? super K, ? super V1, V2> transformer;
/*  724:     */     
/*  725:     */     TransformedEntriesMultimap(Multimap<K, V1> fromMultimap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  726:     */     {
/*  727:1212 */       this.fromMultimap = ((Multimap)Preconditions.checkNotNull(fromMultimap));
/*  728:1213 */       this.transformer = ((Maps.EntryTransformer)Preconditions.checkNotNull(transformer));
/*  729:     */     }
/*  730:     */     
/*  731:     */     Collection<V2> transform(K key, Collection<V1> values)
/*  732:     */     {
/*  733:1217 */       Function<? super V1, V2> function = Maps.asValueToValueFunction(this.transformer, key);
/*  734:1218 */       if ((values instanceof List)) {
/*  735:1219 */         return Lists.transform((List)values, function);
/*  736:     */       }
/*  737:1221 */       return Collections2.transform(values, function);
/*  738:     */     }
/*  739:     */     
/*  740:     */     Map<K, Collection<V2>> createAsMap()
/*  741:     */     {
/*  742:1227 */       Maps.transformEntries(this.fromMultimap.asMap(), new Maps.EntryTransformer()
/*  743:     */       {
/*  744:     */         public Collection<V2> transformEntry(K key, Collection<V1> value)
/*  745:     */         {
/*  746:1232 */           return Multimaps.TransformedEntriesMultimap.this.transform(key, value);
/*  747:     */         }
/*  748:     */       });
/*  749:     */     }
/*  750:     */     
/*  751:     */     public void clear()
/*  752:     */     {
/*  753:1239 */       this.fromMultimap.clear();
/*  754:     */     }
/*  755:     */     
/*  756:     */     public boolean containsKey(Object key)
/*  757:     */     {
/*  758:1244 */       return this.fromMultimap.containsKey(key);
/*  759:     */     }
/*  760:     */     
/*  761:     */     Iterator<Map.Entry<K, V2>> entryIterator()
/*  762:     */     {
/*  763:1249 */       return Iterators.transform(this.fromMultimap.entries().iterator(), Maps.asEntryToEntryFunction(this.transformer));
/*  764:     */     }
/*  765:     */     
/*  766:     */     public Collection<V2> get(K key)
/*  767:     */     {
/*  768:1255 */       return transform(key, this.fromMultimap.get(key));
/*  769:     */     }
/*  770:     */     
/*  771:     */     public boolean isEmpty()
/*  772:     */     {
/*  773:1260 */       return this.fromMultimap.isEmpty();
/*  774:     */     }
/*  775:     */     
/*  776:     */     public Set<K> keySet()
/*  777:     */     {
/*  778:1265 */       return this.fromMultimap.keySet();
/*  779:     */     }
/*  780:     */     
/*  781:     */     public Multiset<K> keys()
/*  782:     */     {
/*  783:1270 */       return this.fromMultimap.keys();
/*  784:     */     }
/*  785:     */     
/*  786:     */     public boolean put(K key, V2 value)
/*  787:     */     {
/*  788:1275 */       throw new UnsupportedOperationException();
/*  789:     */     }
/*  790:     */     
/*  791:     */     public boolean putAll(K key, Iterable<? extends V2> values)
/*  792:     */     {
/*  793:1280 */       throw new UnsupportedOperationException();
/*  794:     */     }
/*  795:     */     
/*  796:     */     public boolean putAll(Multimap<? extends K, ? extends V2> multimap)
/*  797:     */     {
/*  798:1285 */       throw new UnsupportedOperationException();
/*  799:     */     }
/*  800:     */     
/*  801:     */     public boolean remove(Object key, Object value)
/*  802:     */     {
/*  803:1291 */       return get(key).remove(value);
/*  804:     */     }
/*  805:     */     
/*  806:     */     public Collection<V2> removeAll(Object key)
/*  807:     */     {
/*  808:1297 */       return transform(key, this.fromMultimap.removeAll(key));
/*  809:     */     }
/*  810:     */     
/*  811:     */     public Collection<V2> replaceValues(K key, Iterable<? extends V2> values)
/*  812:     */     {
/*  813:1302 */       throw new UnsupportedOperationException();
/*  814:     */     }
/*  815:     */     
/*  816:     */     public int size()
/*  817:     */     {
/*  818:1307 */       return this.fromMultimap.size();
/*  819:     */     }
/*  820:     */     
/*  821:     */     Collection<V2> createValues()
/*  822:     */     {
/*  823:1312 */       return Collections2.transform(this.fromMultimap.entries(), Maps.asEntryToValueFunction(this.transformer));
/*  824:     */     }
/*  825:     */   }
/*  826:     */   
/*  827:     */   public static <K, V1, V2> ListMultimap<K, V2> transformValues(ListMultimap<K, V1> fromMultimap, Function<? super V1, V2> function)
/*  828:     */   {
/*  829:1360 */     Preconditions.checkNotNull(function);
/*  830:1361 */     Maps.EntryTransformer<K, V1, V2> transformer = Maps.asEntryTransformer(function);
/*  831:1362 */     return transformEntries(fromMultimap, transformer);
/*  832:     */   }
/*  833:     */   
/*  834:     */   public static <K, V1, V2> ListMultimap<K, V2> transformEntries(ListMultimap<K, V1> fromMap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  835:     */   {
/*  836:1419 */     return new TransformedEntriesListMultimap(fromMap, transformer);
/*  837:     */   }
/*  838:     */   
/*  839:     */   private static final class TransformedEntriesListMultimap<K, V1, V2>
/*  840:     */     extends Multimaps.TransformedEntriesMultimap<K, V1, V2>
/*  841:     */     implements ListMultimap<K, V2>
/*  842:     */   {
/*  843:     */     TransformedEntriesListMultimap(ListMultimap<K, V1> fromMultimap, Maps.EntryTransformer<? super K, ? super V1, V2> transformer)
/*  844:     */     {
/*  845:1427 */       super(transformer);
/*  846:     */     }
/*  847:     */     
/*  848:     */     List<V2> transform(K key, Collection<V1> values)
/*  849:     */     {
/*  850:1432 */       return Lists.transform((List)values, Maps.asValueToValueFunction(this.transformer, key));
/*  851:     */     }
/*  852:     */     
/*  853:     */     public List<V2> get(K key)
/*  854:     */     {
/*  855:1437 */       return transform(key, this.fromMultimap.get(key));
/*  856:     */     }
/*  857:     */     
/*  858:     */     public List<V2> removeAll(Object key)
/*  859:     */     {
/*  860:1443 */       return transform(key, this.fromMultimap.removeAll(key));
/*  861:     */     }
/*  862:     */     
/*  863:     */     public List<V2> replaceValues(K key, Iterable<? extends V2> values)
/*  864:     */     {
/*  865:1448 */       throw new UnsupportedOperationException();
/*  866:     */     }
/*  867:     */   }
/*  868:     */   
/*  869:     */   public static <K, V> ImmutableListMultimap<K, V> index(Iterable<V> values, Function<? super V, K> keyFunction)
/*  870:     */   {
/*  871:1496 */     return index(values.iterator(), keyFunction);
/*  872:     */   }
/*  873:     */   
/*  874:     */   public static <K, V> ImmutableListMultimap<K, V> index(Iterator<V> values, Function<? super V, K> keyFunction)
/*  875:     */   {
/*  876:1544 */     Preconditions.checkNotNull(keyFunction);
/*  877:1545 */     ImmutableListMultimap.Builder<K, V> builder = ImmutableListMultimap.builder();
/*  878:1546 */     while (values.hasNext())
/*  879:     */     {
/*  880:1547 */       V value = values.next();
/*  881:1548 */       Preconditions.checkNotNull(value, values);
/*  882:1549 */       builder.put(keyFunction.apply(value), value);
/*  883:     */     }
/*  884:1551 */     return builder.build();
/*  885:     */   }
/*  886:     */   
/*  887:     */   static class Keys<K, V>
/*  888:     */     extends AbstractMultiset<K>
/*  889:     */   {
/*  890:     */     @Weak
/*  891:     */     final Multimap<K, V> multimap;
/*  892:     */     
/*  893:     */     Keys(Multimap<K, V> multimap)
/*  894:     */     {
/*  895:1558 */       this.multimap = multimap;
/*  896:     */     }
/*  897:     */     
/*  898:     */     Iterator<Multiset.Entry<K>> entryIterator()
/*  899:     */     {
/*  900:1563 */       new TransformedIterator(this.multimap.asMap().entrySet().iterator())
/*  901:     */       {
/*  902:     */         Multiset.Entry<K> transform(final Map.Entry<K, Collection<V>> backingEntry)
/*  903:     */         {
/*  904:1567 */           new Multisets.AbstractEntry()
/*  905:     */           {
/*  906:     */             public K getElement()
/*  907:     */             {
/*  908:1570 */               return backingEntry.getKey();
/*  909:     */             }
/*  910:     */             
/*  911:     */             public int getCount()
/*  912:     */             {
/*  913:1575 */               return ((Collection)backingEntry.getValue()).size();
/*  914:     */             }
/*  915:     */           };
/*  916:     */         }
/*  917:     */       };
/*  918:     */     }
/*  919:     */     
/*  920:     */     int distinctElements()
/*  921:     */     {
/*  922:1584 */       return this.multimap.asMap().size();
/*  923:     */     }
/*  924:     */     
/*  925:     */     Set<Multiset.Entry<K>> createEntrySet()
/*  926:     */     {
/*  927:1589 */       return new KeysEntrySet();
/*  928:     */     }
/*  929:     */     
/*  930:     */     class KeysEntrySet
/*  931:     */       extends Multisets.EntrySet<K>
/*  932:     */     {
/*  933:     */       KeysEntrySet() {}
/*  934:     */       
/*  935:     */       Multiset<K> multiset()
/*  936:     */       {
/*  937:1596 */         return Multimaps.Keys.this;
/*  938:     */       }
/*  939:     */       
/*  940:     */       public Iterator<Multiset.Entry<K>> iterator()
/*  941:     */       {
/*  942:1601 */         return Multimaps.Keys.this.entryIterator();
/*  943:     */       }
/*  944:     */       
/*  945:     */       public int size()
/*  946:     */       {
/*  947:1606 */         return Multimaps.Keys.this.distinctElements();
/*  948:     */       }
/*  949:     */       
/*  950:     */       public boolean isEmpty()
/*  951:     */       {
/*  952:1611 */         return Multimaps.Keys.this.multimap.isEmpty();
/*  953:     */       }
/*  954:     */       
/*  955:     */       public boolean contains(@Nullable Object o)
/*  956:     */       {
/*  957:1616 */         if ((o instanceof Multiset.Entry))
/*  958:     */         {
/*  959:1617 */           Multiset.Entry<?> entry = (Multiset.Entry)o;
/*  960:1618 */           Collection<V> collection = (Collection)Multimaps.Keys.this.multimap.asMap().get(entry.getElement());
/*  961:1619 */           return (collection != null) && (collection.size() == entry.getCount());
/*  962:     */         }
/*  963:1621 */         return false;
/*  964:     */       }
/*  965:     */       
/*  966:     */       public boolean remove(@Nullable Object o)
/*  967:     */       {
/*  968:1626 */         if ((o instanceof Multiset.Entry))
/*  969:     */         {
/*  970:1627 */           Multiset.Entry<?> entry = (Multiset.Entry)o;
/*  971:1628 */           Collection<V> collection = (Collection)Multimaps.Keys.this.multimap.asMap().get(entry.getElement());
/*  972:1629 */           if ((collection != null) && (collection.size() == entry.getCount()))
/*  973:     */           {
/*  974:1630 */             collection.clear();
/*  975:1631 */             return true;
/*  976:     */           }
/*  977:     */         }
/*  978:1634 */         return false;
/*  979:     */       }
/*  980:     */     }
/*  981:     */     
/*  982:     */     public boolean contains(@Nullable Object element)
/*  983:     */     {
/*  984:1640 */       return this.multimap.containsKey(element);
/*  985:     */     }
/*  986:     */     
/*  987:     */     public Iterator<K> iterator()
/*  988:     */     {
/*  989:1645 */       return Maps.keyIterator(this.multimap.entries().iterator());
/*  990:     */     }
/*  991:     */     
/*  992:     */     public int count(@Nullable Object element)
/*  993:     */     {
/*  994:1650 */       Collection<V> values = (Collection)Maps.safeGet(this.multimap.asMap(), element);
/*  995:1651 */       return values == null ? 0 : values.size();
/*  996:     */     }
/*  997:     */     
/*  998:     */     public int remove(@Nullable Object element, int occurrences)
/*  999:     */     {
/* 1000:1656 */       CollectPreconditions.checkNonnegative(occurrences, "occurrences");
/* 1001:1657 */       if (occurrences == 0) {
/* 1002:1658 */         return count(element);
/* 1003:     */       }
/* 1004:1661 */       Collection<V> values = (Collection)Maps.safeGet(this.multimap.asMap(), element);
/* 1005:1663 */       if (values == null) {
/* 1006:1664 */         return 0;
/* 1007:     */       }
/* 1008:1667 */       int oldCount = values.size();
/* 1009:1668 */       if (occurrences >= oldCount)
/* 1010:     */       {
/* 1011:1669 */         values.clear();
/* 1012:     */       }
/* 1013:     */       else
/* 1014:     */       {
/* 1015:1671 */         Iterator<V> iterator = values.iterator();
/* 1016:1672 */         for (int i = 0; i < occurrences; i++)
/* 1017:     */         {
/* 1018:1673 */           iterator.next();
/* 1019:1674 */           iterator.remove();
/* 1020:     */         }
/* 1021:     */       }
/* 1022:1677 */       return oldCount;
/* 1023:     */     }
/* 1024:     */     
/* 1025:     */     public void clear()
/* 1026:     */     {
/* 1027:1682 */       this.multimap.clear();
/* 1028:     */     }
/* 1029:     */     
/* 1030:     */     public Set<K> elementSet()
/* 1031:     */     {
/* 1032:1687 */       return this.multimap.keySet();
/* 1033:     */     }
/* 1034:     */   }
/* 1035:     */   
/* 1036:     */   static abstract class Entries<K, V>
/* 1037:     */     extends AbstractCollection<Map.Entry<K, V>>
/* 1038:     */   {
/* 1039:     */     abstract Multimap<K, V> multimap();
/* 1040:     */     
/* 1041:     */     public int size()
/* 1042:     */     {
/* 1043:1699 */       return multimap().size();
/* 1044:     */     }
/* 1045:     */     
/* 1046:     */     public boolean contains(@Nullable Object o)
/* 1047:     */     {
/* 1048:1704 */       if ((o instanceof Map.Entry))
/* 1049:     */       {
/* 1050:1705 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 1051:1706 */         return multimap().containsEntry(entry.getKey(), entry.getValue());
/* 1052:     */       }
/* 1053:1708 */       return false;
/* 1054:     */     }
/* 1055:     */     
/* 1056:     */     public boolean remove(@Nullable Object o)
/* 1057:     */     {
/* 1058:1713 */       if ((o instanceof Map.Entry))
/* 1059:     */       {
/* 1060:1714 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 1061:1715 */         return multimap().remove(entry.getKey(), entry.getValue());
/* 1062:     */       }
/* 1063:1717 */       return false;
/* 1064:     */     }
/* 1065:     */     
/* 1066:     */     public void clear()
/* 1067:     */     {
/* 1068:1722 */       multimap().clear();
/* 1069:     */     }
/* 1070:     */   }
/* 1071:     */   
/* 1072:     */   static final class AsMap<K, V>
/* 1073:     */     extends Maps.ViewCachingAbstractMap<K, Collection<V>>
/* 1074:     */   {
/* 1075:     */     @Weak
/* 1076:     */     private final Multimap<K, V> multimap;
/* 1077:     */     
/* 1078:     */     AsMap(Multimap<K, V> multimap)
/* 1079:     */     {
/* 1080:1733 */       this.multimap = ((Multimap)Preconditions.checkNotNull(multimap));
/* 1081:     */     }
/* 1082:     */     
/* 1083:     */     public int size()
/* 1084:     */     {
/* 1085:1738 */       return this.multimap.keySet().size();
/* 1086:     */     }
/* 1087:     */     
/* 1088:     */     protected Set<Map.Entry<K, Collection<V>>> createEntrySet()
/* 1089:     */     {
/* 1090:1743 */       return new EntrySet();
/* 1091:     */     }
/* 1092:     */     
/* 1093:     */     void removeValuesForKey(Object key)
/* 1094:     */     {
/* 1095:1747 */       this.multimap.keySet().remove(key);
/* 1096:     */     }
/* 1097:     */     
/* 1098:     */     class EntrySet
/* 1099:     */       extends Maps.EntrySet<K, Collection<V>>
/* 1100:     */     {
/* 1101:     */       EntrySet() {}
/* 1102:     */       
/* 1103:     */       Map<K, Collection<V>> map()
/* 1104:     */       {
/* 1105:1754 */         return Multimaps.AsMap.this;
/* 1106:     */       }
/* 1107:     */       
/* 1108:     */       public Iterator<Map.Entry<K, Collection<V>>> iterator()
/* 1109:     */       {
/* 1110:1759 */         Maps.asMapEntryIterator(Multimaps.AsMap.this.multimap.keySet(), new Function()
/* 1111:     */         {
/* 1112:     */           public Collection<V> apply(K key)
/* 1113:     */           {
/* 1114:1764 */             return Multimaps.AsMap.this.multimap.get(key);
/* 1115:     */           }
/* 1116:     */         });
/* 1117:     */       }
/* 1118:     */       
/* 1119:     */       public boolean remove(Object o)
/* 1120:     */       {
/* 1121:1771 */         if (!contains(o)) {
/* 1122:1772 */           return false;
/* 1123:     */         }
/* 1124:1774 */         Map.Entry<?, ?> entry = (Map.Entry)o;
/* 1125:1775 */         Multimaps.AsMap.this.removeValuesForKey(entry.getKey());
/* 1126:1776 */         return true;
/* 1127:     */       }
/* 1128:     */     }
/* 1129:     */     
/* 1130:     */     public Collection<V> get(Object key)
/* 1131:     */     {
/* 1132:1783 */       return containsKey(key) ? this.multimap.get(key) : null;
/* 1133:     */     }
/* 1134:     */     
/* 1135:     */     public Collection<V> remove(Object key)
/* 1136:     */     {
/* 1137:1788 */       return containsKey(key) ? this.multimap.removeAll(key) : null;
/* 1138:     */     }
/* 1139:     */     
/* 1140:     */     public Set<K> keySet()
/* 1141:     */     {
/* 1142:1793 */       return this.multimap.keySet();
/* 1143:     */     }
/* 1144:     */     
/* 1145:     */     public boolean isEmpty()
/* 1146:     */     {
/* 1147:1798 */       return this.multimap.isEmpty();
/* 1148:     */     }
/* 1149:     */     
/* 1150:     */     public boolean containsKey(Object key)
/* 1151:     */     {
/* 1152:1803 */       return this.multimap.containsKey(key);
/* 1153:     */     }
/* 1154:     */     
/* 1155:     */     public void clear()
/* 1156:     */     {
/* 1157:1808 */       this.multimap.clear();
/* 1158:     */     }
/* 1159:     */   }
/* 1160:     */   
/* 1161:     */   @CheckReturnValue
/* 1162:     */   public static <K, V> Multimap<K, V> filterKeys(Multimap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1163:     */   {
/* 1164:1845 */     if ((unfiltered instanceof SetMultimap)) {
/* 1165:1846 */       return filterKeys((SetMultimap)unfiltered, keyPredicate);
/* 1166:     */     }
/* 1167:1847 */     if ((unfiltered instanceof ListMultimap)) {
/* 1168:1848 */       return filterKeys((ListMultimap)unfiltered, keyPredicate);
/* 1169:     */     }
/* 1170:1849 */     if ((unfiltered instanceof FilteredKeyMultimap))
/* 1171:     */     {
/* 1172:1850 */       FilteredKeyMultimap<K, V> prev = (FilteredKeyMultimap)unfiltered;
/* 1173:1851 */       return new FilteredKeyMultimap(prev.unfiltered, Predicates.and(prev.keyPredicate, keyPredicate));
/* 1174:     */     }
/* 1175:1853 */     if ((unfiltered instanceof FilteredMultimap))
/* 1176:     */     {
/* 1177:1854 */       FilteredMultimap<K, V> prev = (FilteredMultimap)unfiltered;
/* 1178:1855 */       return filterFiltered(prev, Maps.keyPredicateOnEntries(keyPredicate));
/* 1179:     */     }
/* 1180:1857 */     return new FilteredKeyMultimap(unfiltered, keyPredicate);
/* 1181:     */   }
/* 1182:     */   
/* 1183:     */   @CheckReturnValue
/* 1184:     */   public static <K, V> SetMultimap<K, V> filterKeys(SetMultimap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1185:     */   {
/* 1186:1894 */     if ((unfiltered instanceof FilteredKeySetMultimap))
/* 1187:     */     {
/* 1188:1895 */       FilteredKeySetMultimap<K, V> prev = (FilteredKeySetMultimap)unfiltered;
/* 1189:1896 */       return new FilteredKeySetMultimap(prev.unfiltered(), Predicates.and(prev.keyPredicate, keyPredicate));
/* 1190:     */     }
/* 1191:1898 */     if ((unfiltered instanceof FilteredSetMultimap))
/* 1192:     */     {
/* 1193:1899 */       FilteredSetMultimap<K, V> prev = (FilteredSetMultimap)unfiltered;
/* 1194:1900 */       return filterFiltered(prev, Maps.keyPredicateOnEntries(keyPredicate));
/* 1195:     */     }
/* 1196:1902 */     return new FilteredKeySetMultimap(unfiltered, keyPredicate);
/* 1197:     */   }
/* 1198:     */   
/* 1199:     */   @CheckReturnValue
/* 1200:     */   public static <K, V> ListMultimap<K, V> filterKeys(ListMultimap<K, V> unfiltered, Predicate<? super K> keyPredicate)
/* 1201:     */   {
/* 1202:1939 */     if ((unfiltered instanceof FilteredKeyListMultimap))
/* 1203:     */     {
/* 1204:1940 */       FilteredKeyListMultimap<K, V> prev = (FilteredKeyListMultimap)unfiltered;
/* 1205:1941 */       return new FilteredKeyListMultimap(prev.unfiltered(), Predicates.and(prev.keyPredicate, keyPredicate));
/* 1206:     */     }
/* 1207:1944 */     return new FilteredKeyListMultimap(unfiltered, keyPredicate);
/* 1208:     */   }
/* 1209:     */   
/* 1210:     */   @CheckReturnValue
/* 1211:     */   public static <K, V> Multimap<K, V> filterValues(Multimap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1212:     */   {
/* 1213:1981 */     return filterEntries(unfiltered, Maps.valuePredicateOnEntries(valuePredicate));
/* 1214:     */   }
/* 1215:     */   
/* 1216:     */   @CheckReturnValue
/* 1217:     */   public static <K, V> SetMultimap<K, V> filterValues(SetMultimap<K, V> unfiltered, Predicate<? super V> valuePredicate)
/* 1218:     */   {
/* 1219:2017 */     return filterEntries(unfiltered, Maps.valuePredicateOnEntries(valuePredicate));
/* 1220:     */   }
/* 1221:     */   
/* 1222:     */   @CheckReturnValue
/* 1223:     */   public static <K, V> Multimap<K, V> filterEntries(Multimap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1224:     */   {
/* 1225:2051 */     Preconditions.checkNotNull(entryPredicate);
/* 1226:2052 */     if ((unfiltered instanceof SetMultimap)) {
/* 1227:2053 */       return filterEntries((SetMultimap)unfiltered, entryPredicate);
/* 1228:     */     }
/* 1229:2055 */     return (unfiltered instanceof FilteredMultimap) ? filterFiltered((FilteredMultimap)unfiltered, entryPredicate) : new FilteredEntryMultimap((Multimap)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1230:     */   }
/* 1231:     */   
/* 1232:     */   @CheckReturnValue
/* 1233:     */   public static <K, V> SetMultimap<K, V> filterEntries(SetMultimap<K, V> unfiltered, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1234:     */   {
/* 1235:2091 */     Preconditions.checkNotNull(entryPredicate);
/* 1236:2092 */     return (unfiltered instanceof FilteredSetMultimap) ? filterFiltered((FilteredSetMultimap)unfiltered, entryPredicate) : new FilteredEntrySetMultimap((SetMultimap)Preconditions.checkNotNull(unfiltered), entryPredicate);
/* 1237:     */   }
/* 1238:     */   
/* 1239:     */   private static <K, V> Multimap<K, V> filterFiltered(FilteredMultimap<K, V> multimap, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1240:     */   {
/* 1241:2106 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(multimap.entryPredicate(), entryPredicate);
/* 1242:2107 */     return new FilteredEntryMultimap(multimap.unfiltered(), predicate);
/* 1243:     */   }
/* 1244:     */   
/* 1245:     */   private static <K, V> SetMultimap<K, V> filterFiltered(FilteredSetMultimap<K, V> multimap, Predicate<? super Map.Entry<K, V>> entryPredicate)
/* 1246:     */   {
/* 1247:2118 */     Predicate<Map.Entry<K, V>> predicate = Predicates.and(multimap.entryPredicate(), entryPredicate);
/* 1248:2119 */     return new FilteredEntrySetMultimap(multimap.unfiltered(), predicate);
/* 1249:     */   }
/* 1250:     */   
/* 1251:     */   static boolean equalsImpl(Multimap<?, ?> multimap, @Nullable Object object)
/* 1252:     */   {
/* 1253:2123 */     if (object == multimap) {
/* 1254:2124 */       return true;
/* 1255:     */     }
/* 1256:2126 */     if ((object instanceof Multimap))
/* 1257:     */     {
/* 1258:2127 */       Multimap<?, ?> that = (Multimap)object;
/* 1259:2128 */       return multimap.asMap().equals(that.asMap());
/* 1260:     */     }
/* 1261:2130 */     return false;
/* 1262:     */   }
/* 1263:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Multimaps
 * JD-Core Version:    0.7.0.1
 */