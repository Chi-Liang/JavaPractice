/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtIncompatible;
/*   4:    */ import javax.annotation.Nullable;
/*   5:    */ 
/*   6:    */ @GwtIncompatible("unnecessary")
/*   7:    */ class ImmutableMapEntry<K, V>
/*   8:    */   extends ImmutableEntry<K, V>
/*   9:    */ {
/*  10:    */   static <K, V> ImmutableMapEntry<K, V>[] createEntryArray(int size)
/*  11:    */   {
/*  12: 45 */     return new ImmutableMapEntry[size];
/*  13:    */   }
/*  14:    */   
/*  15:    */   ImmutableMapEntry(K key, V value)
/*  16:    */   {
/*  17: 49 */     super(key, value);
/*  18: 50 */     CollectPreconditions.checkEntryNotNull(key, value);
/*  19:    */   }
/*  20:    */   
/*  21:    */   ImmutableMapEntry(ImmutableMapEntry<K, V> contents)
/*  22:    */   {
/*  23: 54 */     super(contents.getKey(), contents.getValue());
/*  24:    */   }
/*  25:    */   
/*  26:    */   @Nullable
/*  27:    */   ImmutableMapEntry<K, V> getNextInKeyBucket()
/*  28:    */   {
/*  29: 60 */     return null;
/*  30:    */   }
/*  31:    */   
/*  32:    */   @Nullable
/*  33:    */   ImmutableMapEntry<K, V> getNextInValueBucket()
/*  34:    */   {
/*  35: 65 */     return null;
/*  36:    */   }
/*  37:    */   
/*  38:    */   boolean isReusable()
/*  39:    */   {
/*  40: 73 */     return true;
/*  41:    */   }
/*  42:    */   
/*  43:    */   static class NonTerminalImmutableMapEntry<K, V>
/*  44:    */     extends ImmutableMapEntry<K, V>
/*  45:    */   {
/*  46:    */     private final transient ImmutableMapEntry<K, V> nextInKeyBucket;
/*  47:    */     
/*  48:    */     NonTerminalImmutableMapEntry(K key, V value, ImmutableMapEntry<K, V> nextInKeyBucket)
/*  49:    */     {
/*  50: 80 */       super(value);
/*  51: 81 */       this.nextInKeyBucket = nextInKeyBucket;
/*  52:    */     }
/*  53:    */     
/*  54:    */     @Nullable
/*  55:    */     final ImmutableMapEntry<K, V> getNextInKeyBucket()
/*  56:    */     {
/*  57: 87 */       return this.nextInKeyBucket;
/*  58:    */     }
/*  59:    */     
/*  60:    */     final boolean isReusable()
/*  61:    */     {
/*  62: 92 */       return false;
/*  63:    */     }
/*  64:    */   }
/*  65:    */   
/*  66:    */   static final class NonTerminalImmutableBiMapEntry<K, V>
/*  67:    */     extends ImmutableMapEntry.NonTerminalImmutableMapEntry<K, V>
/*  68:    */   {
/*  69:    */     private final transient ImmutableMapEntry<K, V> nextInValueBucket;
/*  70:    */     
/*  71:    */     NonTerminalImmutableBiMapEntry(K key, V value, ImmutableMapEntry<K, V> nextInKeyBucket, ImmutableMapEntry<K, V> nextInValueBucket)
/*  72:    */     {
/*  73:105 */       super(value, nextInKeyBucket);
/*  74:106 */       this.nextInValueBucket = nextInValueBucket;
/*  75:    */     }
/*  76:    */     
/*  77:    */     @Nullable
/*  78:    */     ImmutableMapEntry<K, V> getNextInValueBucket()
/*  79:    */     {
/*  80:112 */       return this.nextInValueBucket;
/*  81:    */     }
/*  82:    */   }
/*  83:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableMapEntry
 * JD-Core Version:    0.7.0.1
 */