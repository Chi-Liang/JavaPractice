/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Collections;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.LinkedHashSet;
/*   8:    */ import java.util.List;
/*   9:    */ import java.util.Set;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @GwtCompatible
/*  13:    */ abstract class RegularImmutableTable<R, C, V>
/*  14:    */   extends ImmutableTable<R, C, V>
/*  15:    */ {
/*  16:    */   abstract Table.Cell<R, C, V> getCell(int paramInt);
/*  17:    */   
/*  18:    */   final ImmutableSet<Table.Cell<R, C, V>> createCellSet()
/*  19:    */   {
/*  20: 45 */     return isEmpty() ? ImmutableSet.of() : new CellSet(null);
/*  21:    */   }
/*  22:    */   
/*  23:    */   abstract V getValue(int paramInt);
/*  24:    */   
/*  25:    */   private final class CellSet
/*  26:    */     extends ImmutableSet.Indexed<Table.Cell<R, C, V>>
/*  27:    */   {
/*  28:    */     private CellSet() {}
/*  29:    */     
/*  30:    */     public int size()
/*  31:    */     {
/*  32: 52 */       return RegularImmutableTable.this.size();
/*  33:    */     }
/*  34:    */     
/*  35:    */     Table.Cell<R, C, V> get(int index)
/*  36:    */     {
/*  37: 57 */       return RegularImmutableTable.this.getCell(index);
/*  38:    */     }
/*  39:    */     
/*  40:    */     public boolean contains(@Nullable Object object)
/*  41:    */     {
/*  42: 62 */       if ((object instanceof Table.Cell))
/*  43:    */       {
/*  44: 63 */         Table.Cell<?, ?, ?> cell = (Table.Cell)object;
/*  45: 64 */         Object value = RegularImmutableTable.this.get(cell.getRowKey(), cell.getColumnKey());
/*  46: 65 */         return (value != null) && (value.equals(cell.getValue()));
/*  47:    */       }
/*  48: 67 */       return false;
/*  49:    */     }
/*  50:    */     
/*  51:    */     boolean isPartialView()
/*  52:    */     {
/*  53: 72 */       return false;
/*  54:    */     }
/*  55:    */   }
/*  56:    */   
/*  57:    */   final ImmutableCollection<V> createValues()
/*  58:    */   {
/*  59: 80 */     return isEmpty() ? ImmutableList.of() : new Values(null);
/*  60:    */   }
/*  61:    */   
/*  62:    */   private final class Values
/*  63:    */     extends ImmutableList<V>
/*  64:    */   {
/*  65:    */     private Values() {}
/*  66:    */     
/*  67:    */     public int size()
/*  68:    */     {
/*  69: 87 */       return RegularImmutableTable.this.size();
/*  70:    */     }
/*  71:    */     
/*  72:    */     public V get(int index)
/*  73:    */     {
/*  74: 92 */       return RegularImmutableTable.this.getValue(index);
/*  75:    */     }
/*  76:    */     
/*  77:    */     boolean isPartialView()
/*  78:    */     {
/*  79: 97 */       return true;
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   static <R, C, V> RegularImmutableTable<R, C, V> forCells(List<Table.Cell<R, C, V>> cells, @Nullable Comparator<? super R> rowComparator, @Nullable final Comparator<? super C> columnComparator)
/*  84:    */   {
/*  85:105 */     Preconditions.checkNotNull(cells);
/*  86:106 */     if ((rowComparator != null) || (columnComparator != null))
/*  87:    */     {
/*  88:114 */       Comparator<Table.Cell<R, C, V>> comparator = new Comparator()
/*  89:    */       {
/*  90:    */         public int compare(Table.Cell<R, C, V> cell1, Table.Cell<R, C, V> cell2)
/*  91:    */         {
/*  92:118 */           int rowCompare = this.val$rowComparator == null ? 0 : this.val$rowComparator.compare(cell1.getRowKey(), cell2.getRowKey());
/*  93:122 */           if (rowCompare != 0) {
/*  94:123 */             return rowCompare;
/*  95:    */           }
/*  96:125 */           return columnComparator == null ? 0 : columnComparator.compare(cell1.getColumnKey(), cell2.getColumnKey());
/*  97:    */         }
/*  98:129 */       };
/*  99:130 */       Collections.sort(cells, comparator);
/* 100:    */     }
/* 101:132 */     return forCellsInternal(cells, rowComparator, columnComparator);
/* 102:    */   }
/* 103:    */   
/* 104:    */   static <R, C, V> RegularImmutableTable<R, C, V> forCells(Iterable<Table.Cell<R, C, V>> cells)
/* 105:    */   {
/* 106:136 */     return forCellsInternal(cells, null, null);
/* 107:    */   }
/* 108:    */   
/* 109:    */   private static final <R, C, V> RegularImmutableTable<R, C, V> forCellsInternal(Iterable<Table.Cell<R, C, V>> cells, @Nullable Comparator<? super R> rowComparator, @Nullable Comparator<? super C> columnComparator)
/* 110:    */   {
/* 111:147 */     Set<R> rowSpaceBuilder = new LinkedHashSet();
/* 112:148 */     Set<C> columnSpaceBuilder = new LinkedHashSet();
/* 113:149 */     ImmutableList<Table.Cell<R, C, V>> cellList = ImmutableList.copyOf(cells);
/* 114:150 */     for (Table.Cell<R, C, V> cell : cells)
/* 115:    */     {
/* 116:151 */       rowSpaceBuilder.add(cell.getRowKey());
/* 117:152 */       columnSpaceBuilder.add(cell.getColumnKey());
/* 118:    */     }
/* 119:155 */     ImmutableSet<R> rowSpace = rowComparator == null ? ImmutableSet.copyOf(rowSpaceBuilder) : ImmutableSet.copyOf(Ordering.from(rowComparator).immutableSortedCopy(rowSpaceBuilder));
/* 120:    */     
/* 121:    */ 
/* 122:    */ 
/* 123:    */ 
/* 124:160 */     ImmutableSet<C> columnSpace = columnComparator == null ? ImmutableSet.copyOf(columnSpaceBuilder) : ImmutableSet.copyOf(Ordering.from(columnComparator).immutableSortedCopy(columnSpaceBuilder));
/* 125:    */     
/* 126:    */ 
/* 127:    */ 
/* 128:    */ 
/* 129:    */ 
/* 130:    */ 
/* 131:    */ 
/* 132:168 */     return cellList.size() > rowSpace.size() * columnSpace.size() / 2L ? new DenseImmutableTable(cellList, rowSpace, columnSpace) : new SparseImmutableTable(cellList, rowSpace, columnSpace);
/* 133:    */   }
/* 134:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableTable
 * JD-Core Version:    0.7.0.1
 */