/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ 
/*  5:   */ @GwtCompatible(serializable=true)
/*  6:   */ class EmptyImmutableSetMultimap
/*  7:   */   extends ImmutableSetMultimap<Object, Object>
/*  8:   */ {
/*  9:28 */   static final EmptyImmutableSetMultimap INSTANCE = new EmptyImmutableSetMultimap();
/* 10:   */   private static final long serialVersionUID = 0L;
/* 11:   */   
/* 12:   */   private EmptyImmutableSetMultimap()
/* 13:   */   {
/* 14:31 */     super(ImmutableMap.of(), 0, null);
/* 15:   */   }
/* 16:   */   
/* 17:   */   private Object readResolve()
/* 18:   */   {
/* 19:35 */     return INSTANCE;
/* 20:   */   }
/* 21:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.EmptyImmutableSetMultimap
 * JD-Core Version:    0.7.0.1
 */