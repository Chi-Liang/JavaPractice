/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.GwtCompatible;
/*    4:     */ import com.google.common.annotations.GwtIncompatible;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.base.Predicate;
/*    7:     */ import com.google.common.base.Predicates;
/*    8:     */ import java.io.Serializable;
/*    9:     */ import java.util.AbstractSet;
/*   10:     */ import java.util.Arrays;
/*   11:     */ import java.util.Collection;
/*   12:     */ import java.util.Collections;
/*   13:     */ import java.util.Comparator;
/*   14:     */ import java.util.EnumSet;
/*   15:     */ import java.util.HashSet;
/*   16:     */ import java.util.Iterator;
/*   17:     */ import java.util.LinkedHashSet;
/*   18:     */ import java.util.List;
/*   19:     */ import java.util.Map;
/*   20:     */ import java.util.NavigableSet;
/*   21:     */ import java.util.NoSuchElementException;
/*   22:     */ import java.util.Set;
/*   23:     */ import java.util.SortedSet;
/*   24:     */ import java.util.TreeSet;
/*   25:     */ import java.util.concurrent.ConcurrentHashMap;
/*   26:     */ import java.util.concurrent.CopyOnWriteArraySet;
/*   27:     */ import javax.annotation.CheckReturnValue;
/*   28:     */ import javax.annotation.Nullable;
/*   29:     */ 
/*   30:     */ @GwtCompatible(emulated=true)
/*   31:     */ public final class Sets
/*   32:     */ {
/*   33:     */   static abstract class ImprovedAbstractSet<E>
/*   34:     */     extends AbstractSet<E>
/*   35:     */   {
/*   36:     */     public boolean removeAll(Collection<?> c)
/*   37:     */     {
/*   38:  75 */       return Sets.removeAllImpl(this, c);
/*   39:     */     }
/*   40:     */     
/*   41:     */     public boolean retainAll(Collection<?> c)
/*   42:     */     {
/*   43:  80 */       return super.retainAll((Collection)Preconditions.checkNotNull(c));
/*   44:     */     }
/*   45:     */   }
/*   46:     */   
/*   47:     */   @GwtCompatible(serializable=true)
/*   48:     */   public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(E anElement, E... otherElements)
/*   49:     */   {
/*   50:  99 */     return ImmutableEnumSet.asImmutable(EnumSet.of(anElement, otherElements));
/*   51:     */   }
/*   52:     */   
/*   53:     */   @GwtCompatible(serializable=true)
/*   54:     */   public static <E extends Enum<E>> ImmutableSet<E> immutableEnumSet(Iterable<E> elements)
/*   55:     */   {
/*   56: 116 */     if ((elements instanceof ImmutableEnumSet)) {
/*   57: 117 */       return (ImmutableEnumSet)elements;
/*   58:     */     }
/*   59: 118 */     if ((elements instanceof Collection))
/*   60:     */     {
/*   61: 119 */       Collection<E> collection = (Collection)elements;
/*   62: 120 */       if (collection.isEmpty()) {
/*   63: 121 */         return ImmutableSet.of();
/*   64:     */       }
/*   65: 123 */       return ImmutableEnumSet.asImmutable(EnumSet.copyOf(collection));
/*   66:     */     }
/*   67: 126 */     Iterator<E> itr = elements.iterator();
/*   68: 127 */     if (itr.hasNext())
/*   69:     */     {
/*   70: 128 */       EnumSet<E> enumSet = EnumSet.of((Enum)itr.next());
/*   71: 129 */       Iterators.addAll(enumSet, itr);
/*   72: 130 */       return ImmutableEnumSet.asImmutable(enumSet);
/*   73:     */     }
/*   74: 132 */     return ImmutableSet.of();
/*   75:     */   }
/*   76:     */   
/*   77:     */   public static <E extends Enum<E>> EnumSet<E> newEnumSet(Iterable<E> iterable, Class<E> elementType)
/*   78:     */   {
/*   79: 144 */     EnumSet<E> set = EnumSet.noneOf(elementType);
/*   80: 145 */     Iterables.addAll(set, iterable);
/*   81: 146 */     return set;
/*   82:     */   }
/*   83:     */   
/*   84:     */   public static <E> HashSet<E> newHashSet()
/*   85:     */   {
/*   86: 164 */     return new HashSet();
/*   87:     */   }
/*   88:     */   
/*   89:     */   public static <E> HashSet<E> newHashSet(E... elements)
/*   90:     */   {
/*   91: 181 */     HashSet<E> set = newHashSetWithExpectedSize(elements.length);
/*   92: 182 */     Collections.addAll(set, elements);
/*   93: 183 */     return set;
/*   94:     */   }
/*   95:     */   
/*   96:     */   public static <E> HashSet<E> newHashSetWithExpectedSize(int expectedSize)
/*   97:     */   {
/*   98: 199 */     return new HashSet(Maps.capacity(expectedSize));
/*   99:     */   }
/*  100:     */   
/*  101:     */   public static <E> HashSet<E> newHashSet(Iterable<? extends E> elements)
/*  102:     */   {
/*  103: 221 */     return (elements instanceof Collection) ? new HashSet(Collections2.cast(elements)) : newHashSet(elements.iterator());
/*  104:     */   }
/*  105:     */   
/*  106:     */   public static <E> HashSet<E> newHashSet(Iterator<? extends E> elements)
/*  107:     */   {
/*  108: 239 */     HashSet<E> set = newHashSet();
/*  109: 240 */     Iterators.addAll(set, elements);
/*  110: 241 */     return set;
/*  111:     */   }
/*  112:     */   
/*  113:     */   public static <E> Set<E> newConcurrentHashSet()
/*  114:     */   {
/*  115: 256 */     return newSetFromMap(new ConcurrentHashMap());
/*  116:     */   }
/*  117:     */   
/*  118:     */   public static <E> Set<E> newConcurrentHashSet(Iterable<? extends E> elements)
/*  119:     */   {
/*  120: 274 */     Set<E> set = newConcurrentHashSet();
/*  121: 275 */     Iterables.addAll(set, elements);
/*  122: 276 */     return set;
/*  123:     */   }
/*  124:     */   
/*  125:     */   public static <E> LinkedHashSet<E> newLinkedHashSet()
/*  126:     */   {
/*  127: 290 */     return new LinkedHashSet();
/*  128:     */   }
/*  129:     */   
/*  130:     */   public static <E> LinkedHashSet<E> newLinkedHashSetWithExpectedSize(int expectedSize)
/*  131:     */   {
/*  132: 308 */     return new LinkedHashSet(Maps.capacity(expectedSize));
/*  133:     */   }
/*  134:     */   
/*  135:     */   public static <E> LinkedHashSet<E> newLinkedHashSet(Iterable<? extends E> elements)
/*  136:     */   {
/*  137: 323 */     if ((elements instanceof Collection)) {
/*  138: 324 */       return new LinkedHashSet(Collections2.cast(elements));
/*  139:     */     }
/*  140: 326 */     LinkedHashSet<E> set = newLinkedHashSet();
/*  141: 327 */     Iterables.addAll(set, elements);
/*  142: 328 */     return set;
/*  143:     */   }
/*  144:     */   
/*  145:     */   public static <E extends Comparable> TreeSet<E> newTreeSet()
/*  146:     */   {
/*  147: 343 */     return new TreeSet();
/*  148:     */   }
/*  149:     */   
/*  150:     */   public static <E extends Comparable> TreeSet<E> newTreeSet(Iterable<? extends E> elements)
/*  151:     */   {
/*  152: 362 */     TreeSet<E> set = newTreeSet();
/*  153: 363 */     Iterables.addAll(set, elements);
/*  154: 364 */     return set;
/*  155:     */   }
/*  156:     */   
/*  157:     */   public static <E> TreeSet<E> newTreeSet(Comparator<? super E> comparator)
/*  158:     */   {
/*  159: 379 */     return new TreeSet((Comparator)Preconditions.checkNotNull(comparator));
/*  160:     */   }
/*  161:     */   
/*  162:     */   public static <E> Set<E> newIdentityHashSet()
/*  163:     */   {
/*  164: 393 */     return newSetFromMap(Maps.newIdentityHashMap());
/*  165:     */   }
/*  166:     */   
/*  167:     */   @GwtIncompatible("CopyOnWriteArraySet")
/*  168:     */   public static <E> CopyOnWriteArraySet<E> newCopyOnWriteArraySet()
/*  169:     */   {
/*  170: 407 */     return new CopyOnWriteArraySet();
/*  171:     */   }
/*  172:     */   
/*  173:     */   @GwtIncompatible("CopyOnWriteArraySet")
/*  174:     */   public static <E> CopyOnWriteArraySet<E> newCopyOnWriteArraySet(Iterable<? extends E> elements)
/*  175:     */   {
/*  176: 421 */     Collection<? extends E> elementsCollection = (elements instanceof Collection) ? Collections2.cast(elements) : Lists.newArrayList(elements);
/*  177:     */     
/*  178:     */ 
/*  179:     */ 
/*  180: 425 */     return new CopyOnWriteArraySet(elementsCollection);
/*  181:     */   }
/*  182:     */   
/*  183:     */   public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection)
/*  184:     */   {
/*  185: 444 */     if ((collection instanceof EnumSet)) {
/*  186: 445 */       return EnumSet.complementOf((EnumSet)collection);
/*  187:     */     }
/*  188: 447 */     Preconditions.checkArgument(!collection.isEmpty(), "collection is empty; use the other version of this method");
/*  189:     */     
/*  190: 449 */     Class<E> type = ((Enum)collection.iterator().next()).getDeclaringClass();
/*  191: 450 */     return makeComplementByHand(collection, type);
/*  192:     */   }
/*  193:     */   
/*  194:     */   public static <E extends Enum<E>> EnumSet<E> complementOf(Collection<E> collection, Class<E> type)
/*  195:     */   {
/*  196: 467 */     Preconditions.checkNotNull(collection);
/*  197: 468 */     return (collection instanceof EnumSet) ? EnumSet.complementOf((EnumSet)collection) : makeComplementByHand(collection, type);
/*  198:     */   }
/*  199:     */   
/*  200:     */   private static <E extends Enum<E>> EnumSet<E> makeComplementByHand(Collection<E> collection, Class<E> type)
/*  201:     */   {
/*  202: 475 */     EnumSet<E> result = EnumSet.allOf(type);
/*  203: 476 */     result.removeAll(collection);
/*  204: 477 */     return result;
/*  205:     */   }
/*  206:     */   
/*  207:     */   @Deprecated
/*  208:     */   public static <E> Set<E> newSetFromMap(Map<E, Boolean> map)
/*  209:     */   {
/*  210: 513 */     return Platform.newSetFromMap(map);
/*  211:     */   }
/*  212:     */   
/*  213:     */   public static abstract class SetView<E>
/*  214:     */     extends AbstractSet<E>
/*  215:     */   {
/*  216:     */     public ImmutableSet<E> immutableCopy()
/*  217:     */     {
/*  218: 539 */       return ImmutableSet.copyOf(this);
/*  219:     */     }
/*  220:     */     
/*  221:     */     public <S extends Set<E>> S copyInto(S set)
/*  222:     */     {
/*  223: 552 */       set.addAll(this);
/*  224: 553 */       return set;
/*  225:     */     }
/*  226:     */   }
/*  227:     */   
/*  228:     */   public static <E> SetView<E> union(Set<? extends E> set1, final Set<? extends E> set2)
/*  229:     */   {
/*  230: 578 */     Preconditions.checkNotNull(set1, "set1");
/*  231: 579 */     Preconditions.checkNotNull(set2, "set2");
/*  232:     */     
/*  233: 581 */     final Set<? extends E> set2minus1 = difference(set2, set1);
/*  234:     */     
/*  235: 583 */     new SetView(set1)
/*  236:     */     {
/*  237:     */       public int size()
/*  238:     */       {
/*  239: 586 */         return this.val$set1.size() + set2minus1.size();
/*  240:     */       }
/*  241:     */       
/*  242:     */       public boolean isEmpty()
/*  243:     */       {
/*  244: 591 */         return (this.val$set1.isEmpty()) && (set2.isEmpty());
/*  245:     */       }
/*  246:     */       
/*  247:     */       public Iterator<E> iterator()
/*  248:     */       {
/*  249: 596 */         return Iterators.unmodifiableIterator(Iterators.concat(this.val$set1.iterator(), set2minus1.iterator()));
/*  250:     */       }
/*  251:     */       
/*  252:     */       public boolean contains(Object object)
/*  253:     */       {
/*  254: 602 */         return (this.val$set1.contains(object)) || (set2.contains(object));
/*  255:     */       }
/*  256:     */       
/*  257:     */       public <S extends Set<E>> S copyInto(S set)
/*  258:     */       {
/*  259: 607 */         set.addAll(this.val$set1);
/*  260: 608 */         set.addAll(set2);
/*  261: 609 */         return set;
/*  262:     */       }
/*  263:     */       
/*  264:     */       public ImmutableSet<E> immutableCopy()
/*  265:     */       {
/*  266: 614 */         return new ImmutableSet.Builder().addAll(this.val$set1).addAll(set2).build();
/*  267:     */       }
/*  268:     */     };
/*  269:     */   }
/*  270:     */   
/*  271:     */   public static <E> SetView<E> intersection(Set<E> set1, final Set<?> set2)
/*  272:     */   {
/*  273: 646 */     Preconditions.checkNotNull(set1, "set1");
/*  274: 647 */     Preconditions.checkNotNull(set2, "set2");
/*  275:     */     
/*  276: 649 */     final Predicate<Object> inSet2 = Predicates.in(set2);
/*  277: 650 */     new SetView(set1)
/*  278:     */     {
/*  279:     */       public Iterator<E> iterator()
/*  280:     */       {
/*  281: 653 */         return Iterators.filter(this.val$set1.iterator(), inSet2);
/*  282:     */       }
/*  283:     */       
/*  284:     */       public int size()
/*  285:     */       {
/*  286: 658 */         return Iterators.size(iterator());
/*  287:     */       }
/*  288:     */       
/*  289:     */       public boolean isEmpty()
/*  290:     */       {
/*  291: 663 */         return !iterator().hasNext();
/*  292:     */       }
/*  293:     */       
/*  294:     */       public boolean contains(Object object)
/*  295:     */       {
/*  296: 668 */         return (this.val$set1.contains(object)) && (set2.contains(object));
/*  297:     */       }
/*  298:     */       
/*  299:     */       public boolean containsAll(Collection<?> collection)
/*  300:     */       {
/*  301: 673 */         return (this.val$set1.containsAll(collection)) && (set2.containsAll(collection));
/*  302:     */       }
/*  303:     */     };
/*  304:     */   }
/*  305:     */   
/*  306:     */   public static <E> SetView<E> difference(Set<E> set1, final Set<?> set2)
/*  307:     */   {
/*  308: 690 */     Preconditions.checkNotNull(set1, "set1");
/*  309: 691 */     Preconditions.checkNotNull(set2, "set2");
/*  310:     */     
/*  311: 693 */     final Predicate<Object> notInSet2 = Predicates.not(Predicates.in(set2));
/*  312: 694 */     new SetView(set1)
/*  313:     */     {
/*  314:     */       public Iterator<E> iterator()
/*  315:     */       {
/*  316: 697 */         return Iterators.filter(this.val$set1.iterator(), notInSet2);
/*  317:     */       }
/*  318:     */       
/*  319:     */       public int size()
/*  320:     */       {
/*  321: 702 */         return Iterators.size(iterator());
/*  322:     */       }
/*  323:     */       
/*  324:     */       public boolean isEmpty()
/*  325:     */       {
/*  326: 707 */         return set2.containsAll(this.val$set1);
/*  327:     */       }
/*  328:     */       
/*  329:     */       public boolean contains(Object element)
/*  330:     */       {
/*  331: 712 */         return (this.val$set1.contains(element)) && (!set2.contains(element));
/*  332:     */       }
/*  333:     */     };
/*  334:     */   }
/*  335:     */   
/*  336:     */   public static <E> SetView<E> symmetricDifference(Set<? extends E> set1, final Set<? extends E> set2)
/*  337:     */   {
/*  338: 731 */     Preconditions.checkNotNull(set1, "set1");
/*  339: 732 */     Preconditions.checkNotNull(set2, "set2");
/*  340:     */     
/*  341: 734 */     new SetView(set1)
/*  342:     */     {
/*  343:     */       public Iterator<E> iterator()
/*  344:     */       {
/*  345: 737 */         final Iterator<? extends E> itr1 = this.val$set1.iterator();
/*  346: 738 */         final Iterator<? extends E> itr2 = set2.iterator();
/*  347: 739 */         new AbstractIterator()
/*  348:     */         {
/*  349:     */           public E computeNext()
/*  350:     */           {
/*  351: 742 */             while (itr1.hasNext())
/*  352:     */             {
/*  353: 743 */               E elem1 = itr1.next();
/*  354: 744 */               if (!Sets.4.this.val$set2.contains(elem1)) {
/*  355: 745 */                 return elem1;
/*  356:     */               }
/*  357:     */             }
/*  358: 748 */             while (itr2.hasNext())
/*  359:     */             {
/*  360: 749 */               E elem2 = itr2.next();
/*  361: 750 */               if (!Sets.4.this.val$set1.contains(elem2)) {
/*  362: 751 */                 return elem2;
/*  363:     */               }
/*  364:     */             }
/*  365: 754 */             return endOfData();
/*  366:     */           }
/*  367:     */         };
/*  368:     */       }
/*  369:     */       
/*  370:     */       public int size()
/*  371:     */       {
/*  372: 761 */         return Iterators.size(iterator());
/*  373:     */       }
/*  374:     */       
/*  375:     */       public boolean isEmpty()
/*  376:     */       {
/*  377: 766 */         return this.val$set1.equals(set2);
/*  378:     */       }
/*  379:     */       
/*  380:     */       public boolean contains(Object element)
/*  381:     */       {
/*  382: 771 */         return this.val$set1.contains(element) ^ set2.contains(element);
/*  383:     */       }
/*  384:     */     };
/*  385:     */   }
/*  386:     */   
/*  387:     */   @CheckReturnValue
/*  388:     */   public static <E> Set<E> filter(Set<E> unfiltered, Predicate<? super E> predicate)
/*  389:     */   {
/*  390: 805 */     if ((unfiltered instanceof SortedSet)) {
/*  391: 806 */       return filter((SortedSet)unfiltered, predicate);
/*  392:     */     }
/*  393: 808 */     if ((unfiltered instanceof FilteredSet))
/*  394:     */     {
/*  395: 811 */       FilteredSet<E> filtered = (FilteredSet)unfiltered;
/*  396: 812 */       Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*  397: 813 */       return new FilteredSet((Set)filtered.unfiltered, combinedPredicate);
/*  398:     */     }
/*  399: 816 */     return new FilteredSet((Set)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*  400:     */   }
/*  401:     */   
/*  402:     */   private static class FilteredSet<E>
/*  403:     */     extends Collections2.FilteredCollection<E>
/*  404:     */     implements Set<E>
/*  405:     */   {
/*  406:     */     FilteredSet(Set<E> unfiltered, Predicate<? super E> predicate)
/*  407:     */     {
/*  408: 821 */       super(predicate);
/*  409:     */     }
/*  410:     */     
/*  411:     */     public boolean equals(@Nullable Object object)
/*  412:     */     {
/*  413: 826 */       return Sets.equalsImpl(this, object);
/*  414:     */     }
/*  415:     */     
/*  416:     */     public int hashCode()
/*  417:     */     {
/*  418: 831 */       return Sets.hashCodeImpl(this);
/*  419:     */     }
/*  420:     */   }
/*  421:     */   
/*  422:     */   @CheckReturnValue
/*  423:     */   public static <E> SortedSet<E> filter(SortedSet<E> unfiltered, Predicate<? super E> predicate)
/*  424:     */   {
/*  425: 866 */     return Platform.setsFilterSortedSet(unfiltered, predicate);
/*  426:     */   }
/*  427:     */   
/*  428:     */   static <E> SortedSet<E> filterSortedIgnoreNavigable(SortedSet<E> unfiltered, Predicate<? super E> predicate)
/*  429:     */   {
/*  430: 871 */     if ((unfiltered instanceof FilteredSet))
/*  431:     */     {
/*  432: 874 */       FilteredSet<E> filtered = (FilteredSet)unfiltered;
/*  433: 875 */       Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*  434: 876 */       return new FilteredSortedSet((SortedSet)filtered.unfiltered, combinedPredicate);
/*  435:     */     }
/*  436: 879 */     return new FilteredSortedSet((SortedSet)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*  437:     */   }
/*  438:     */   
/*  439:     */   private static class FilteredSortedSet<E>
/*  440:     */     extends Sets.FilteredSet<E>
/*  441:     */     implements SortedSet<E>
/*  442:     */   {
/*  443:     */     FilteredSortedSet(SortedSet<E> unfiltered, Predicate<? super E> predicate)
/*  444:     */     {
/*  445: 885 */       super(predicate);
/*  446:     */     }
/*  447:     */     
/*  448:     */     public Comparator<? super E> comparator()
/*  449:     */     {
/*  450: 890 */       return ((SortedSet)this.unfiltered).comparator();
/*  451:     */     }
/*  452:     */     
/*  453:     */     public SortedSet<E> subSet(E fromElement, E toElement)
/*  454:     */     {
/*  455: 895 */       return new FilteredSortedSet(((SortedSet)this.unfiltered).subSet(fromElement, toElement), this.predicate);
/*  456:     */     }
/*  457:     */     
/*  458:     */     public SortedSet<E> headSet(E toElement)
/*  459:     */     {
/*  460: 901 */       return new FilteredSortedSet(((SortedSet)this.unfiltered).headSet(toElement), this.predicate);
/*  461:     */     }
/*  462:     */     
/*  463:     */     public SortedSet<E> tailSet(E fromElement)
/*  464:     */     {
/*  465: 906 */       return new FilteredSortedSet(((SortedSet)this.unfiltered).tailSet(fromElement), this.predicate);
/*  466:     */     }
/*  467:     */     
/*  468:     */     public E first()
/*  469:     */     {
/*  470: 911 */       return iterator().next();
/*  471:     */     }
/*  472:     */     
/*  473:     */     public E last()
/*  474:     */     {
/*  475: 916 */       SortedSet<E> sortedUnfiltered = (SortedSet)this.unfiltered;
/*  476:     */       for (;;)
/*  477:     */       {
/*  478: 918 */         E element = sortedUnfiltered.last();
/*  479: 919 */         if (this.predicate.apply(element)) {
/*  480: 920 */           return element;
/*  481:     */         }
/*  482: 922 */         sortedUnfiltered = sortedUnfiltered.headSet(element);
/*  483:     */       }
/*  484:     */     }
/*  485:     */   }
/*  486:     */   
/*  487:     */   @CheckReturnValue
/*  488:     */   @GwtIncompatible("NavigableSet")
/*  489:     */   public static <E> NavigableSet<E> filter(NavigableSet<E> unfiltered, Predicate<? super E> predicate)
/*  490:     */   {
/*  491: 961 */     if ((unfiltered instanceof FilteredSet))
/*  492:     */     {
/*  493: 964 */       FilteredSet<E> filtered = (FilteredSet)unfiltered;
/*  494: 965 */       Predicate<E> combinedPredicate = Predicates.and(filtered.predicate, predicate);
/*  495: 966 */       return new FilteredNavigableSet((NavigableSet)filtered.unfiltered, combinedPredicate);
/*  496:     */     }
/*  497: 969 */     return new FilteredNavigableSet((NavigableSet)Preconditions.checkNotNull(unfiltered), (Predicate)Preconditions.checkNotNull(predicate));
/*  498:     */   }
/*  499:     */   
/*  500:     */   @GwtIncompatible("NavigableSet")
/*  501:     */   private static class FilteredNavigableSet<E>
/*  502:     */     extends Sets.FilteredSortedSet<E>
/*  503:     */     implements NavigableSet<E>
/*  504:     */   {
/*  505:     */     FilteredNavigableSet(NavigableSet<E> unfiltered, Predicate<? super E> predicate)
/*  506:     */     {
/*  507: 976 */       super(predicate);
/*  508:     */     }
/*  509:     */     
/*  510:     */     NavigableSet<E> unfiltered()
/*  511:     */     {
/*  512: 980 */       return (NavigableSet)this.unfiltered;
/*  513:     */     }
/*  514:     */     
/*  515:     */     @Nullable
/*  516:     */     public E lower(E e)
/*  517:     */     {
/*  518: 986 */       return Iterators.getNext(headSet(e, false).descendingIterator(), null);
/*  519:     */     }
/*  520:     */     
/*  521:     */     @Nullable
/*  522:     */     public E floor(E e)
/*  523:     */     {
/*  524: 992 */       return Iterators.getNext(headSet(e, true).descendingIterator(), null);
/*  525:     */     }
/*  526:     */     
/*  527:     */     public E ceiling(E e)
/*  528:     */     {
/*  529: 997 */       return Iterables.getFirst(tailSet(e, true), null);
/*  530:     */     }
/*  531:     */     
/*  532:     */     public E higher(E e)
/*  533:     */     {
/*  534:1002 */       return Iterables.getFirst(tailSet(e, false), null);
/*  535:     */     }
/*  536:     */     
/*  537:     */     public E pollFirst()
/*  538:     */     {
/*  539:1007 */       return Iterables.removeFirstMatching(unfiltered(), this.predicate);
/*  540:     */     }
/*  541:     */     
/*  542:     */     public E pollLast()
/*  543:     */     {
/*  544:1012 */       return Iterables.removeFirstMatching(unfiltered().descendingSet(), this.predicate);
/*  545:     */     }
/*  546:     */     
/*  547:     */     public NavigableSet<E> descendingSet()
/*  548:     */     {
/*  549:1017 */       return Sets.filter(unfiltered().descendingSet(), this.predicate);
/*  550:     */     }
/*  551:     */     
/*  552:     */     public Iterator<E> descendingIterator()
/*  553:     */     {
/*  554:1022 */       return Iterators.filter(unfiltered().descendingIterator(), this.predicate);
/*  555:     */     }
/*  556:     */     
/*  557:     */     public E last()
/*  558:     */     {
/*  559:1027 */       return descendingIterator().next();
/*  560:     */     }
/*  561:     */     
/*  562:     */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  563:     */     {
/*  564:1033 */       return Sets.filter(unfiltered().subSet(fromElement, fromInclusive, toElement, toInclusive), this.predicate);
/*  565:     */     }
/*  566:     */     
/*  567:     */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/*  568:     */     {
/*  569:1039 */       return Sets.filter(unfiltered().headSet(toElement, inclusive), this.predicate);
/*  570:     */     }
/*  571:     */     
/*  572:     */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/*  573:     */     {
/*  574:1044 */       return Sets.filter(unfiltered().tailSet(fromElement, inclusive), this.predicate);
/*  575:     */     }
/*  576:     */   }
/*  577:     */   
/*  578:     */   public static <B> Set<List<B>> cartesianProduct(List<? extends Set<? extends B>> sets)
/*  579:     */   {
/*  580:1104 */     return CartesianSet.create(sets);
/*  581:     */   }
/*  582:     */   
/*  583:     */   public static <B> Set<List<B>> cartesianProduct(Set<? extends B>... sets)
/*  584:     */   {
/*  585:1163 */     return cartesianProduct(Arrays.asList(sets));
/*  586:     */   }
/*  587:     */   
/*  588:     */   private static final class CartesianSet<E>
/*  589:     */     extends ForwardingCollection<List<E>>
/*  590:     */     implements Set<List<E>>
/*  591:     */   {
/*  592:     */     private final transient ImmutableList<ImmutableSet<E>> axes;
/*  593:     */     private final transient CartesianList<E> delegate;
/*  594:     */     
/*  595:     */     static <E> Set<List<E>> create(List<? extends Set<? extends E>> sets)
/*  596:     */     {
/*  597:1172 */       ImmutableList.Builder<ImmutableSet<E>> axesBuilder = new ImmutableList.Builder(sets.size());
/*  598:1174 */       for (Set<? extends E> set : sets)
/*  599:     */       {
/*  600:1175 */         ImmutableSet<E> copy = ImmutableSet.copyOf(set);
/*  601:1176 */         if (copy.isEmpty()) {
/*  602:1177 */           return ImmutableSet.of();
/*  603:     */         }
/*  604:1179 */         axesBuilder.add(copy);
/*  605:     */       }
/*  606:1181 */       ImmutableList<ImmutableSet<E>> axes = axesBuilder.build();
/*  607:1182 */       ImmutableList<List<E>> listAxes = new ImmutableList()
/*  608:     */       {
/*  609:     */         public int size()
/*  610:     */         {
/*  611:1186 */           return this.val$axes.size();
/*  612:     */         }
/*  613:     */         
/*  614:     */         public List<E> get(int index)
/*  615:     */         {
/*  616:1191 */           return ((ImmutableSet)this.val$axes.get(index)).asList();
/*  617:     */         }
/*  618:     */         
/*  619:     */         boolean isPartialView()
/*  620:     */         {
/*  621:1196 */           return true;
/*  622:     */         }
/*  623:1198 */       };
/*  624:1199 */       return new CartesianSet(axes, new CartesianList(listAxes));
/*  625:     */     }
/*  626:     */     
/*  627:     */     private CartesianSet(ImmutableList<ImmutableSet<E>> axes, CartesianList<E> delegate)
/*  628:     */     {
/*  629:1203 */       this.axes = axes;
/*  630:1204 */       this.delegate = delegate;
/*  631:     */     }
/*  632:     */     
/*  633:     */     protected Collection<List<E>> delegate()
/*  634:     */     {
/*  635:1209 */       return this.delegate;
/*  636:     */     }
/*  637:     */     
/*  638:     */     public boolean equals(@Nullable Object object)
/*  639:     */     {
/*  640:1216 */       if ((object instanceof CartesianSet))
/*  641:     */       {
/*  642:1217 */         CartesianSet<?> that = (CartesianSet)object;
/*  643:1218 */         return this.axes.equals(that.axes);
/*  644:     */       }
/*  645:1220 */       return super.equals(object);
/*  646:     */     }
/*  647:     */     
/*  648:     */     public int hashCode()
/*  649:     */     {
/*  650:1229 */       int adjust = size() - 1;
/*  651:1230 */       for (int i = 0; i < this.axes.size(); i++)
/*  652:     */       {
/*  653:1231 */         adjust *= 31;
/*  654:1232 */         adjust = adjust ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  655:     */       }
/*  656:1235 */       int hash = 1;
/*  657:1236 */       for (Set<E> axis : this.axes)
/*  658:     */       {
/*  659:1237 */         hash = 31 * hash + size() / axis.size() * axis.hashCode();
/*  660:     */         
/*  661:1239 */         hash = hash ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  662:     */       }
/*  663:1241 */       hash += adjust;
/*  664:1242 */       return hash ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  665:     */     }
/*  666:     */   }
/*  667:     */   
/*  668:     */   @GwtCompatible(serializable=false)
/*  669:     */   public static <E> Set<Set<E>> powerSet(Set<E> set)
/*  670:     */   {
/*  671:1277 */     return new PowerSet(set);
/*  672:     */   }
/*  673:     */   
/*  674:     */   private static final class SubSet<E>
/*  675:     */     extends AbstractSet<E>
/*  676:     */   {
/*  677:     */     private final ImmutableMap<E, Integer> inputSet;
/*  678:     */     private final int mask;
/*  679:     */     
/*  680:     */     SubSet(ImmutableMap<E, Integer> inputSet, int mask)
/*  681:     */     {
/*  682:1285 */       this.inputSet = inputSet;
/*  683:1286 */       this.mask = mask;
/*  684:     */     }
/*  685:     */     
/*  686:     */     public Iterator<E> iterator()
/*  687:     */     {
/*  688:1291 */       new UnmodifiableIterator()
/*  689:     */       {
/*  690:1292 */         final ImmutableList<E> elements = Sets.SubSet.this.inputSet.keySet().asList();
/*  691:1293 */         int remainingSetBits = Sets.SubSet.this.mask;
/*  692:     */         
/*  693:     */         public boolean hasNext()
/*  694:     */         {
/*  695:1297 */           return this.remainingSetBits != 0;
/*  696:     */         }
/*  697:     */         
/*  698:     */         public E next()
/*  699:     */         {
/*  700:1302 */           int index = Integer.numberOfTrailingZeros(this.remainingSetBits);
/*  701:1303 */           if (index == 32) {
/*  702:1304 */             throw new NoSuchElementException();
/*  703:     */           }
/*  704:1306 */           this.remainingSetBits &= (1 << index ^ 0xFFFFFFFF);
/*  705:1307 */           return this.elements.get(index);
/*  706:     */         }
/*  707:     */       };
/*  708:     */     }
/*  709:     */     
/*  710:     */     public int size()
/*  711:     */     {
/*  712:1314 */       return Integer.bitCount(this.mask);
/*  713:     */     }
/*  714:     */     
/*  715:     */     public boolean contains(@Nullable Object o)
/*  716:     */     {
/*  717:1319 */       Integer index = (Integer)this.inputSet.get(o);
/*  718:1320 */       return (index != null) && ((this.mask & 1 << index.intValue()) != 0);
/*  719:     */     }
/*  720:     */   }
/*  721:     */   
/*  722:     */   private static final class PowerSet<E>
/*  723:     */     extends AbstractSet<Set<E>>
/*  724:     */   {
/*  725:     */     final ImmutableMap<E, Integer> inputSet;
/*  726:     */     
/*  727:     */     PowerSet(Set<E> input)
/*  728:     */     {
/*  729:1328 */       this.inputSet = Maps.indexMap(input);
/*  730:1329 */       Preconditions.checkArgument(this.inputSet.size() <= 30, "Too many elements to create power set: %s > 30", new Object[] { Integer.valueOf(this.inputSet.size()) });
/*  731:     */     }
/*  732:     */     
/*  733:     */     public int size()
/*  734:     */     {
/*  735:1335 */       return 1 << this.inputSet.size();
/*  736:     */     }
/*  737:     */     
/*  738:     */     public boolean isEmpty()
/*  739:     */     {
/*  740:1340 */       return false;
/*  741:     */     }
/*  742:     */     
/*  743:     */     public Iterator<Set<E>> iterator()
/*  744:     */     {
/*  745:1345 */       new AbstractIndexedListIterator(size())
/*  746:     */       {
/*  747:     */         protected Set<E> get(int setBits)
/*  748:     */         {
/*  749:1348 */           return new Sets.SubSet(Sets.PowerSet.this.inputSet, setBits);
/*  750:     */         }
/*  751:     */       };
/*  752:     */     }
/*  753:     */     
/*  754:     */     public boolean contains(@Nullable Object obj)
/*  755:     */     {
/*  756:1355 */       if ((obj instanceof Set))
/*  757:     */       {
/*  758:1356 */         Set<?> set = (Set)obj;
/*  759:1357 */         return this.inputSet.keySet().containsAll(set);
/*  760:     */       }
/*  761:1359 */       return false;
/*  762:     */     }
/*  763:     */     
/*  764:     */     public boolean equals(@Nullable Object obj)
/*  765:     */     {
/*  766:1364 */       if ((obj instanceof PowerSet))
/*  767:     */       {
/*  768:1365 */         PowerSet<?> that = (PowerSet)obj;
/*  769:1366 */         return this.inputSet.equals(that.inputSet);
/*  770:     */       }
/*  771:1368 */       return super.equals(obj);
/*  772:     */     }
/*  773:     */     
/*  774:     */     public int hashCode()
/*  775:     */     {
/*  776:1378 */       return this.inputSet.keySet().hashCode() << this.inputSet.size() - 1;
/*  777:     */     }
/*  778:     */     
/*  779:     */     public String toString()
/*  780:     */     {
/*  781:1383 */       return "powerSet(" + this.inputSet + ")";
/*  782:     */     }
/*  783:     */   }
/*  784:     */   
/*  785:     */   static int hashCodeImpl(Set<?> s)
/*  786:     */   {
/*  787:1391 */     int hashCode = 0;
/*  788:1392 */     for (Object o : s)
/*  789:     */     {
/*  790:1393 */       hashCode += (o != null ? o.hashCode() : 0);
/*  791:     */       
/*  792:1395 */       hashCode = hashCode ^ 0xFFFFFFFF ^ 0xFFFFFFFF;
/*  793:     */     }
/*  794:1398 */     return hashCode;
/*  795:     */   }
/*  796:     */   
/*  797:     */   static boolean equalsImpl(Set<?> s, @Nullable Object object)
/*  798:     */   {
/*  799:1405 */     if (s == object) {
/*  800:1406 */       return true;
/*  801:     */     }
/*  802:1408 */     if ((object instanceof Set))
/*  803:     */     {
/*  804:1409 */       Set<?> o = (Set)object;
/*  805:     */       try
/*  806:     */       {
/*  807:1412 */         return (s.size() == o.size()) && (s.containsAll(o));
/*  808:     */       }
/*  809:     */       catch (NullPointerException ignored)
/*  810:     */       {
/*  811:1414 */         return false;
/*  812:     */       }
/*  813:     */       catch (ClassCastException ignored)
/*  814:     */       {
/*  815:1416 */         return false;
/*  816:     */       }
/*  817:     */     }
/*  818:1419 */     return false;
/*  819:     */   }
/*  820:     */   
/*  821:     */   @GwtIncompatible("NavigableSet")
/*  822:     */   public static <E> NavigableSet<E> unmodifiableNavigableSet(NavigableSet<E> set)
/*  823:     */   {
/*  824:1440 */     if (((set instanceof ImmutableSortedSet)) || ((set instanceof UnmodifiableNavigableSet))) {
/*  825:1441 */       return set;
/*  826:     */     }
/*  827:1443 */     return new UnmodifiableNavigableSet(set);
/*  828:     */   }
/*  829:     */   
/*  830:     */   @GwtIncompatible("NavigableSet")
/*  831:     */   static final class UnmodifiableNavigableSet<E>
/*  832:     */     extends ForwardingSortedSet<E>
/*  833:     */     implements NavigableSet<E>, Serializable
/*  834:     */   {
/*  835:     */     private final NavigableSet<E> delegate;
/*  836:     */     private transient UnmodifiableNavigableSet<E> descendingSet;
/*  837:     */     private static final long serialVersionUID = 0L;
/*  838:     */     
/*  839:     */     UnmodifiableNavigableSet(NavigableSet<E> delegate)
/*  840:     */     {
/*  841:1452 */       this.delegate = ((NavigableSet)Preconditions.checkNotNull(delegate));
/*  842:     */     }
/*  843:     */     
/*  844:     */     protected SortedSet<E> delegate()
/*  845:     */     {
/*  846:1457 */       return Collections.unmodifiableSortedSet(this.delegate);
/*  847:     */     }
/*  848:     */     
/*  849:     */     public E lower(E e)
/*  850:     */     {
/*  851:1462 */       return this.delegate.lower(e);
/*  852:     */     }
/*  853:     */     
/*  854:     */     public E floor(E e)
/*  855:     */     {
/*  856:1467 */       return this.delegate.floor(e);
/*  857:     */     }
/*  858:     */     
/*  859:     */     public E ceiling(E e)
/*  860:     */     {
/*  861:1472 */       return this.delegate.ceiling(e);
/*  862:     */     }
/*  863:     */     
/*  864:     */     public E higher(E e)
/*  865:     */     {
/*  866:1477 */       return this.delegate.higher(e);
/*  867:     */     }
/*  868:     */     
/*  869:     */     public E pollFirst()
/*  870:     */     {
/*  871:1482 */       throw new UnsupportedOperationException();
/*  872:     */     }
/*  873:     */     
/*  874:     */     public E pollLast()
/*  875:     */     {
/*  876:1487 */       throw new UnsupportedOperationException();
/*  877:     */     }
/*  878:     */     
/*  879:     */     public NavigableSet<E> descendingSet()
/*  880:     */     {
/*  881:1494 */       UnmodifiableNavigableSet<E> result = this.descendingSet;
/*  882:1495 */       if (result == null)
/*  883:     */       {
/*  884:1496 */         result = this.descendingSet = new UnmodifiableNavigableSet(this.delegate.descendingSet());
/*  885:1497 */         result.descendingSet = this;
/*  886:     */       }
/*  887:1499 */       return result;
/*  888:     */     }
/*  889:     */     
/*  890:     */     public Iterator<E> descendingIterator()
/*  891:     */     {
/*  892:1504 */       return Iterators.unmodifiableIterator(this.delegate.descendingIterator());
/*  893:     */     }
/*  894:     */     
/*  895:     */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  896:     */     {
/*  897:1510 */       return Sets.unmodifiableNavigableSet(this.delegate.subSet(fromElement, fromInclusive, toElement, toInclusive));
/*  898:     */     }
/*  899:     */     
/*  900:     */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/*  901:     */     {
/*  902:1516 */       return Sets.unmodifiableNavigableSet(this.delegate.headSet(toElement, inclusive));
/*  903:     */     }
/*  904:     */     
/*  905:     */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/*  906:     */     {
/*  907:1521 */       return Sets.unmodifiableNavigableSet(this.delegate.tailSet(fromElement, inclusive));
/*  908:     */     }
/*  909:     */   }
/*  910:     */   
/*  911:     */   @GwtIncompatible("NavigableSet")
/*  912:     */   public static <E> NavigableSet<E> synchronizedNavigableSet(NavigableSet<E> navigableSet)
/*  913:     */   {
/*  914:1572 */     return Synchronized.navigableSet(navigableSet);
/*  915:     */   }
/*  916:     */   
/*  917:     */   static boolean removeAllImpl(Set<?> set, Iterator<?> iterator)
/*  918:     */   {
/*  919:1579 */     boolean changed = false;
/*  920:1580 */     while (iterator.hasNext()) {
/*  921:1581 */       changed |= set.remove(iterator.next());
/*  922:     */     }
/*  923:1583 */     return changed;
/*  924:     */   }
/*  925:     */   
/*  926:     */   static boolean removeAllImpl(Set<?> set, Collection<?> collection)
/*  927:     */   {
/*  928:1587 */     Preconditions.checkNotNull(collection);
/*  929:1588 */     if ((collection instanceof Multiset)) {
/*  930:1589 */       collection = ((Multiset)collection).elementSet();
/*  931:     */     }
/*  932:1598 */     if (((collection instanceof Set)) && (collection.size() > set.size())) {
/*  933:1599 */       return Iterators.removeAll(set.iterator(), collection);
/*  934:     */     }
/*  935:1601 */     return removeAllImpl(set, collection.iterator());
/*  936:     */   }
/*  937:     */   
/*  938:     */   @GwtIncompatible("NavigableSet")
/*  939:     */   static class DescendingSet<E>
/*  940:     */     extends ForwardingNavigableSet<E>
/*  941:     */   {
/*  942:     */     private final NavigableSet<E> forward;
/*  943:     */     
/*  944:     */     DescendingSet(NavigableSet<E> forward)
/*  945:     */     {
/*  946:1610 */       this.forward = forward;
/*  947:     */     }
/*  948:     */     
/*  949:     */     protected NavigableSet<E> delegate()
/*  950:     */     {
/*  951:1615 */       return this.forward;
/*  952:     */     }
/*  953:     */     
/*  954:     */     public E lower(E e)
/*  955:     */     {
/*  956:1620 */       return this.forward.higher(e);
/*  957:     */     }
/*  958:     */     
/*  959:     */     public E floor(E e)
/*  960:     */     {
/*  961:1625 */       return this.forward.ceiling(e);
/*  962:     */     }
/*  963:     */     
/*  964:     */     public E ceiling(E e)
/*  965:     */     {
/*  966:1630 */       return this.forward.floor(e);
/*  967:     */     }
/*  968:     */     
/*  969:     */     public E higher(E e)
/*  970:     */     {
/*  971:1635 */       return this.forward.lower(e);
/*  972:     */     }
/*  973:     */     
/*  974:     */     public E pollFirst()
/*  975:     */     {
/*  976:1640 */       return this.forward.pollLast();
/*  977:     */     }
/*  978:     */     
/*  979:     */     public E pollLast()
/*  980:     */     {
/*  981:1645 */       return this.forward.pollFirst();
/*  982:     */     }
/*  983:     */     
/*  984:     */     public NavigableSet<E> descendingSet()
/*  985:     */     {
/*  986:1650 */       return this.forward;
/*  987:     */     }
/*  988:     */     
/*  989:     */     public Iterator<E> descendingIterator()
/*  990:     */     {
/*  991:1655 */       return this.forward.iterator();
/*  992:     */     }
/*  993:     */     
/*  994:     */     public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/*  995:     */     {
/*  996:1661 */       return this.forward.subSet(toElement, toInclusive, fromElement, fromInclusive).descendingSet();
/*  997:     */     }
/*  998:     */     
/*  999:     */     public NavigableSet<E> headSet(E toElement, boolean inclusive)
/* 1000:     */     {
/* 1001:1666 */       return this.forward.tailSet(toElement, inclusive).descendingSet();
/* 1002:     */     }
/* 1003:     */     
/* 1004:     */     public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/* 1005:     */     {
/* 1006:1671 */       return this.forward.headSet(fromElement, inclusive).descendingSet();
/* 1007:     */     }
/* 1008:     */     
/* 1009:     */     public Comparator<? super E> comparator()
/* 1010:     */     {
/* 1011:1677 */       Comparator<? super E> forwardComparator = this.forward.comparator();
/* 1012:1678 */       if (forwardComparator == null) {
/* 1013:1679 */         return Ordering.natural().reverse();
/* 1014:     */       }
/* 1015:1681 */       return reverse(forwardComparator);
/* 1016:     */     }
/* 1017:     */     
/* 1018:     */     private static <T> Ordering<T> reverse(Comparator<T> forward)
/* 1019:     */     {
/* 1020:1687 */       return Ordering.from(forward).reverse();
/* 1021:     */     }
/* 1022:     */     
/* 1023:     */     public E first()
/* 1024:     */     {
/* 1025:1692 */       return this.forward.last();
/* 1026:     */     }
/* 1027:     */     
/* 1028:     */     public SortedSet<E> headSet(E toElement)
/* 1029:     */     {
/* 1030:1697 */       return standardHeadSet(toElement);
/* 1031:     */     }
/* 1032:     */     
/* 1033:     */     public E last()
/* 1034:     */     {
/* 1035:1702 */       return this.forward.first();
/* 1036:     */     }
/* 1037:     */     
/* 1038:     */     public SortedSet<E> subSet(E fromElement, E toElement)
/* 1039:     */     {
/* 1040:1707 */       return standardSubSet(fromElement, toElement);
/* 1041:     */     }
/* 1042:     */     
/* 1043:     */     public SortedSet<E> tailSet(E fromElement)
/* 1044:     */     {
/* 1045:1712 */       return standardTailSet(fromElement);
/* 1046:     */     }
/* 1047:     */     
/* 1048:     */     public Iterator<E> iterator()
/* 1049:     */     {
/* 1050:1717 */       return this.forward.descendingIterator();
/* 1051:     */     }
/* 1052:     */     
/* 1053:     */     public Object[] toArray()
/* 1054:     */     {
/* 1055:1722 */       return standardToArray();
/* 1056:     */     }
/* 1057:     */     
/* 1058:     */     public <T> T[] toArray(T[] array)
/* 1059:     */     {
/* 1060:1727 */       return standardToArray(array);
/* 1061:     */     }
/* 1062:     */     
/* 1063:     */     public String toString()
/* 1064:     */     {
/* 1065:1732 */       return standardToString();
/* 1066:     */     }
/* 1067:     */   }
/* 1068:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Sets
 * JD-Core Version:    0.7.0.1
 */