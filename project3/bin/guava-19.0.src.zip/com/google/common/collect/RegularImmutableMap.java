/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Map.Entry;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible(serializable=true, emulated=true)
/*   9:    */ final class RegularImmutableMap<K, V>
/*  10:    */   extends ImmutableMap<K, V>
/*  11:    */ {
/*  12:    */   private final transient Map.Entry<K, V>[] entries;
/*  13:    */   private final transient ImmutableMapEntry<K, V>[] table;
/*  14:    */   private final transient int mask;
/*  15:    */   private static final double MAX_LOAD_FACTOR = 1.2D;
/*  16:    */   private static final long serialVersionUID = 0L;
/*  17:    */   
/*  18:    */   static <K, V> RegularImmutableMap<K, V> fromEntries(Map.Entry<K, V>... entries)
/*  19:    */   {
/*  20: 46 */     return fromEntryArray(entries.length, entries);
/*  21:    */   }
/*  22:    */   
/*  23:    */   static <K, V> RegularImmutableMap<K, V> fromEntryArray(int n, Map.Entry<K, V>[] entryArray)
/*  24:    */   {
/*  25: 55 */     Preconditions.checkPositionIndex(n, entryArray.length);
/*  26:    */     Map.Entry<K, V>[] entries;
/*  27:    */     Map.Entry<K, V>[] entries;
/*  28: 57 */     if (n == entryArray.length) {
/*  29: 58 */       entries = entryArray;
/*  30:    */     } else {
/*  31: 60 */       entries = ImmutableMapEntry.createEntryArray(n);
/*  32:    */     }
/*  33: 62 */     int tableSize = Hashing.closedTableSize(n, 1.2D);
/*  34: 63 */     ImmutableMapEntry<K, V>[] table = ImmutableMapEntry.createEntryArray(tableSize);
/*  35: 64 */     int mask = tableSize - 1;
/*  36: 65 */     for (int entryIndex = 0; entryIndex < n; entryIndex++)
/*  37:    */     {
/*  38: 66 */       Map.Entry<K, V> entry = entryArray[entryIndex];
/*  39: 67 */       K key = entry.getKey();
/*  40: 68 */       V value = entry.getValue();
/*  41: 69 */       CollectPreconditions.checkEntryNotNull(key, value);
/*  42: 70 */       int tableIndex = Hashing.smear(key.hashCode()) & mask;
/*  43: 71 */       ImmutableMapEntry<K, V> existing = table[tableIndex];
/*  44:    */       ImmutableMapEntry<K, V> newEntry;
/*  45:    */       ImmutableMapEntry<K, V> newEntry;
/*  46: 74 */       if (existing == null)
/*  47:    */       {
/*  48: 75 */         boolean reusable = ((entry instanceof ImmutableMapEntry)) && (((ImmutableMapEntry)entry).isReusable());
/*  49:    */         
/*  50: 77 */         newEntry = reusable ? (ImmutableMapEntry)entry : new ImmutableMapEntry(key, value);
/*  51:    */       }
/*  52:    */       else
/*  53:    */       {
/*  54: 80 */         newEntry = new ImmutableMapEntry.NonTerminalImmutableMapEntry(key, value, existing);
/*  55:    */       }
/*  56: 82 */       table[tableIndex] = newEntry;
/*  57: 83 */       entries[entryIndex] = newEntry;
/*  58: 84 */       checkNoConflictInKeyBucket(key, newEntry, existing);
/*  59:    */     }
/*  60: 86 */     return new RegularImmutableMap(entries, table, mask);
/*  61:    */   }
/*  62:    */   
/*  63:    */   private RegularImmutableMap(Map.Entry<K, V>[] entries, ImmutableMapEntry<K, V>[] table, int mask)
/*  64:    */   {
/*  65: 90 */     this.entries = entries;
/*  66: 91 */     this.table = table;
/*  67: 92 */     this.mask = mask;
/*  68:    */   }
/*  69:    */   
/*  70:    */   static void checkNoConflictInKeyBucket(Object key, Map.Entry<?, ?> entry, @Nullable ImmutableMapEntry<?, ?> keyBucketHead)
/*  71:    */   {
/*  72: 97 */     for (; keyBucketHead != null; keyBucketHead = keyBucketHead.getNextInKeyBucket()) {
/*  73: 98 */       checkNoConflict(!key.equals(keyBucketHead.getKey()), "key", entry, keyBucketHead);
/*  74:    */     }
/*  75:    */   }
/*  76:    */   
/*  77:    */   public V get(@Nullable Object key)
/*  78:    */   {
/*  79:111 */     return get(key, this.table, this.mask);
/*  80:    */   }
/*  81:    */   
/*  82:    */   @Nullable
/*  83:    */   static <V> V get(@Nullable Object key, ImmutableMapEntry<?, V>[] keyTable, int mask)
/*  84:    */   {
/*  85:116 */     if (key == null) {
/*  86:117 */       return null;
/*  87:    */     }
/*  88:119 */     int index = Hashing.smear(key.hashCode()) & mask;
/*  89:120 */     for (ImmutableMapEntry<?, V> entry = keyTable[index]; entry != null; entry = entry.getNextInKeyBucket())
/*  90:    */     {
/*  91:123 */       Object candidateKey = entry.getKey();
/*  92:131 */       if (key.equals(candidateKey)) {
/*  93:132 */         return entry.getValue();
/*  94:    */       }
/*  95:    */     }
/*  96:135 */     return null;
/*  97:    */   }
/*  98:    */   
/*  99:    */   public int size()
/* 100:    */   {
/* 101:140 */     return this.entries.length;
/* 102:    */   }
/* 103:    */   
/* 104:    */   boolean isPartialView()
/* 105:    */   {
/* 106:145 */     return false;
/* 107:    */   }
/* 108:    */   
/* 109:    */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 110:    */   {
/* 111:150 */     return new ImmutableMapEntrySet.RegularEntrySet(this, this.entries);
/* 112:    */   }
/* 113:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableMap
 * JD-Core Version:    0.7.0.1
 */