/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.io.ObjectInputStream;
/*   8:    */ import java.io.ObjectOutputStream;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.EnumMap;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Set;
/*  14:    */ 
/*  15:    */ @GwtCompatible(emulated=true)
/*  16:    */ public final class EnumBiMap<K extends Enum<K>, V extends Enum<V>>
/*  17:    */   extends AbstractBiMap<K, V>
/*  18:    */ {
/*  19:    */   private transient Class<K> keyType;
/*  20:    */   private transient Class<V> valueType;
/*  21:    */   @GwtIncompatible("not needed in emulated source.")
/*  22:    */   private static final long serialVersionUID = 0L;
/*  23:    */   
/*  24:    */   public static <K extends Enum<K>, V extends Enum<V>> EnumBiMap<K, V> create(Class<K> keyType, Class<V> valueType)
/*  25:    */   {
/*  26: 57 */     return new EnumBiMap(keyType, valueType);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public static <K extends Enum<K>, V extends Enum<V>> EnumBiMap<K, V> create(Map<K, V> map)
/*  30:    */   {
/*  31: 71 */     EnumBiMap<K, V> bimap = create(inferKeyType(map), inferValueType(map));
/*  32: 72 */     bimap.putAll(map);
/*  33: 73 */     return bimap;
/*  34:    */   }
/*  35:    */   
/*  36:    */   private EnumBiMap(Class<K> keyType, Class<V> valueType)
/*  37:    */   {
/*  38: 77 */     super(WellBehavedMap.wrap(new EnumMap(keyType)), WellBehavedMap.wrap(new EnumMap(valueType)));
/*  39:    */     
/*  40:    */ 
/*  41: 80 */     this.keyType = keyType;
/*  42: 81 */     this.valueType = valueType;
/*  43:    */   }
/*  44:    */   
/*  45:    */   static <K extends Enum<K>> Class<K> inferKeyType(Map<K, ?> map)
/*  46:    */   {
/*  47: 85 */     if ((map instanceof EnumBiMap)) {
/*  48: 86 */       return ((EnumBiMap)map).keyType();
/*  49:    */     }
/*  50: 88 */     if ((map instanceof EnumHashBiMap)) {
/*  51: 89 */       return ((EnumHashBiMap)map).keyType();
/*  52:    */     }
/*  53: 91 */     Preconditions.checkArgument(!map.isEmpty());
/*  54: 92 */     return ((Enum)map.keySet().iterator().next()).getDeclaringClass();
/*  55:    */   }
/*  56:    */   
/*  57:    */   private static <V extends Enum<V>> Class<V> inferValueType(Map<?, V> map)
/*  58:    */   {
/*  59:100 */     if ((map instanceof EnumBiMap)) {
/*  60:101 */       return ((EnumBiMap)map).valueType;
/*  61:    */     }
/*  62:103 */     Preconditions.checkArgument(!map.isEmpty());
/*  63:104 */     return ((Enum)map.values().iterator().next()).getDeclaringClass();
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Class<K> keyType()
/*  67:    */   {
/*  68:113 */     return this.keyType;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public Class<V> valueType()
/*  72:    */   {
/*  73:118 */     return this.valueType;
/*  74:    */   }
/*  75:    */   
/*  76:    */   K checkKey(K key)
/*  77:    */   {
/*  78:123 */     return (Enum)Preconditions.checkNotNull(key);
/*  79:    */   }
/*  80:    */   
/*  81:    */   V checkValue(V value)
/*  82:    */   {
/*  83:128 */     return (Enum)Preconditions.checkNotNull(value);
/*  84:    */   }
/*  85:    */   
/*  86:    */   @GwtIncompatible("java.io.ObjectOutputStream")
/*  87:    */   private void writeObject(ObjectOutputStream stream)
/*  88:    */     throws IOException
/*  89:    */   {
/*  90:137 */     stream.defaultWriteObject();
/*  91:138 */     stream.writeObject(this.keyType);
/*  92:139 */     stream.writeObject(this.valueType);
/*  93:140 */     Serialization.writeMap(this, stream);
/*  94:    */   }
/*  95:    */   
/*  96:    */   @GwtIncompatible("java.io.ObjectInputStream")
/*  97:    */   private void readObject(ObjectInputStream stream)
/*  98:    */     throws IOException, ClassNotFoundException
/*  99:    */   {
/* 100:146 */     stream.defaultReadObject();
/* 101:147 */     this.keyType = ((Class)stream.readObject());
/* 102:148 */     this.valueType = ((Class)stream.readObject());
/* 103:149 */     setDelegates(WellBehavedMap.wrap(new EnumMap(this.keyType)), WellBehavedMap.wrap(new EnumMap(this.valueType)));
/* 104:    */     
/* 105:    */ 
/* 106:152 */     Serialization.populateMap(this, stream);
/* 107:    */   }
/* 108:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.EnumBiMap
 * JD-Core Version:    0.7.0.1
 */