/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.Arrays;
/*   7:    */ import java.util.Comparator;
/*   8:    */ import java.util.Map;
/*   9:    */ import java.util.Map.Entry;
/*  10:    */ import java.util.NavigableMap;
/*  11:    */ import java.util.SortedMap;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible(serializable=true, emulated=true)
/*  15:    */ public final class ImmutableSortedMap<K, V>
/*  16:    */   extends ImmutableSortedMapFauxverideShim<K, V>
/*  17:    */   implements NavigableMap<K, V>
/*  18:    */ {
/*  19: 64 */   private static final Comparator<Comparable> NATURAL_ORDER = ;
/*  20: 66 */   private static final ImmutableSortedMap<Comparable, Object> NATURAL_EMPTY_MAP = new ImmutableSortedMap(ImmutableSortedSet.emptySet(Ordering.natural()), ImmutableList.of());
/*  21:    */   private final transient RegularImmutableSortedSet<K> keySet;
/*  22:    */   private final transient ImmutableList<V> valueList;
/*  23:    */   private transient ImmutableSortedMap<K, V> descendingMap;
/*  24:    */   private static final long serialVersionUID = 0L;
/*  25:    */   
/*  26:    */   static <K, V> ImmutableSortedMap<K, V> emptyMap(Comparator<? super K> comparator)
/*  27:    */   {
/*  28: 71 */     if (Ordering.natural().equals(comparator)) {
/*  29: 72 */       return of();
/*  30:    */     }
/*  31: 74 */     return new ImmutableSortedMap(ImmutableSortedSet.emptySet(comparator), ImmutableList.of());
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static <K, V> ImmutableSortedMap<K, V> of()
/*  35:    */   {
/*  36: 86 */     return NATURAL_EMPTY_MAP;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1)
/*  40:    */   {
/*  41: 93 */     return of(Ordering.natural(), k1, v1);
/*  42:    */   }
/*  43:    */   
/*  44:    */   private static <K, V> ImmutableSortedMap<K, V> of(Comparator<? super K> comparator, K k1, V v1)
/*  45:    */   {
/*  46:100 */     return new ImmutableSortedMap(new RegularImmutableSortedSet(ImmutableList.of(k1), (Comparator)Preconditions.checkNotNull(comparator)), ImmutableList.of(v1));
/*  47:    */   }
/*  48:    */   
/*  49:    */   private static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> ofEntries(ImmutableMapEntry<K, V>... entries)
/*  50:    */   {
/*  51:107 */     return fromEntries(Ordering.natural(), false, entries, entries.length);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2)
/*  55:    */   {
/*  56:120 */     return ofEntries(new ImmutableMapEntry[] { entryOf(k1, v1), entryOf(k2, v2) });
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  60:    */   {
/*  61:133 */     return ofEntries(new ImmutableMapEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3) });
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  65:    */   {
/*  66:146 */     return ofEntries(new ImmutableMapEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4) });
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static <K extends Comparable<? super K>, V> ImmutableSortedMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  70:    */   {
/*  71:159 */     return ofEntries(new ImmutableMapEntry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5) });
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map)
/*  75:    */   {
/*  76:184 */     Ordering<K> naturalOrder = (Ordering)NATURAL_ORDER;
/*  77:185 */     return copyOfInternal(map, naturalOrder);
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static <K, V> ImmutableSortedMap<K, V> copyOf(Map<? extends K, ? extends V> map, Comparator<? super K> comparator)
/*  81:    */   {
/*  82:202 */     return copyOfInternal(map, (Comparator)Preconditions.checkNotNull(comparator));
/*  83:    */   }
/*  84:    */   
/*  85:    */   @Beta
/*  86:    */   public static <K, V> ImmutableSortedMap<K, V> copyOf(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/*  87:    */   {
/*  88:223 */     Ordering<K> naturalOrder = (Ordering)NATURAL_ORDER;
/*  89:224 */     return copyOf(entries, naturalOrder);
/*  90:    */   }
/*  91:    */   
/*  92:    */   @Beta
/*  93:    */   public static <K, V> ImmutableSortedMap<K, V> copyOf(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries, Comparator<? super K> comparator)
/*  94:    */   {
/*  95:240 */     return fromEntries((Comparator)Preconditions.checkNotNull(comparator), false, entries);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static <K, V> ImmutableSortedMap<K, V> copyOfSorted(SortedMap<K, ? extends V> map)
/*  99:    */   {
/* 100:255 */     Comparator<? super K> comparator = map.comparator();
/* 101:256 */     if (comparator == null) {
/* 102:259 */       comparator = NATURAL_ORDER;
/* 103:    */     }
/* 104:261 */     if ((map instanceof ImmutableSortedMap))
/* 105:    */     {
/* 106:265 */       ImmutableSortedMap<K, V> kvMap = (ImmutableSortedMap)map;
/* 107:266 */       if (!kvMap.isPartialView()) {
/* 108:267 */         return kvMap;
/* 109:    */       }
/* 110:    */     }
/* 111:270 */     return fromEntries(comparator, true, map.entrySet());
/* 112:    */   }
/* 113:    */   
/* 114:    */   private static <K, V> ImmutableSortedMap<K, V> copyOfInternal(Map<? extends K, ? extends V> map, Comparator<? super K> comparator)
/* 115:    */   {
/* 116:275 */     boolean sameComparator = false;
/* 117:276 */     if ((map instanceof SortedMap))
/* 118:    */     {
/* 119:277 */       SortedMap<?, ?> sortedMap = (SortedMap)map;
/* 120:278 */       Comparator<?> comparator2 = sortedMap.comparator();
/* 121:279 */       sameComparator = comparator2 == null ? false : comparator == NATURAL_ORDER ? true : comparator.equals(comparator2);
/* 122:    */     }
/* 123:285 */     if ((sameComparator) && ((map instanceof ImmutableSortedMap)))
/* 124:    */     {
/* 125:289 */       ImmutableSortedMap<K, V> kvMap = (ImmutableSortedMap)map;
/* 126:290 */       if (!kvMap.isPartialView()) {
/* 127:291 */         return kvMap;
/* 128:    */       }
/* 129:    */     }
/* 130:294 */     return fromEntries(comparator, sameComparator, map.entrySet());
/* 131:    */   }
/* 132:    */   
/* 133:    */   private static <K, V> ImmutableSortedMap<K, V> fromEntries(Comparator<? super K> comparator, boolean sameComparator, Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/* 134:    */   {
/* 135:309 */     Map.Entry<K, V>[] entryArray = (Map.Entry[])Iterables.toArray(entries, EMPTY_ENTRY_ARRAY);
/* 136:310 */     return fromEntries(comparator, sameComparator, entryArray, entryArray.length);
/* 137:    */   }
/* 138:    */   
/* 139:    */   private static <K, V> ImmutableSortedMap<K, V> fromEntries(Comparator<? super K> comparator, boolean sameComparator, Map.Entry<K, V>[] entryArray, int size)
/* 140:    */   {
/* 141:318 */     switch (size)
/* 142:    */     {
/* 143:    */     case 0: 
/* 144:320 */       return emptyMap(comparator);
/* 145:    */     case 1: 
/* 146:322 */       return of(comparator, entryArray[0].getKey(), entryArray[0].getValue());
/* 147:    */     }
/* 148:325 */     Object[] keys = new Object[size];
/* 149:326 */     Object[] values = new Object[size];
/* 150:327 */     if (sameComparator)
/* 151:    */     {
/* 152:329 */       for (int i = 0; i < size; i++)
/* 153:    */       {
/* 154:330 */         Object key = entryArray[i].getKey();
/* 155:331 */         Object value = entryArray[i].getValue();
/* 156:332 */         CollectPreconditions.checkEntryNotNull(key, value);
/* 157:333 */         keys[i] = key;
/* 158:334 */         values[i] = value;
/* 159:    */       }
/* 160:    */     }
/* 161:    */     else
/* 162:    */     {
/* 163:338 */       Arrays.sort(entryArray, 0, size, Ordering.from(comparator).onKeys());
/* 164:339 */       K prevKey = entryArray[0].getKey();
/* 165:340 */       keys[0] = prevKey;
/* 166:341 */       values[0] = entryArray[0].getValue();
/* 167:342 */       for (int i = 1; i < size; i++)
/* 168:    */       {
/* 169:343 */         K key = entryArray[i].getKey();
/* 170:344 */         V value = entryArray[i].getValue();
/* 171:345 */         CollectPreconditions.checkEntryNotNull(key, value);
/* 172:346 */         keys[i] = key;
/* 173:347 */         values[i] = value;
/* 174:348 */         checkNoConflict(comparator.compare(prevKey, key) != 0, "key", entryArray[(i - 1)], entryArray[i]);
/* 175:    */         
/* 176:350 */         prevKey = key;
/* 177:    */       }
/* 178:    */     }
/* 179:353 */     return new ImmutableSortedMap(new RegularImmutableSortedSet(new RegularImmutableList(keys), comparator), new RegularImmutableList(values));
/* 180:    */   }
/* 181:    */   
/* 182:    */   public static <K extends Comparable<?>, V> Builder<K, V> naturalOrder()
/* 183:    */   {
/* 184:365 */     return new Builder(Ordering.natural());
/* 185:    */   }
/* 186:    */   
/* 187:    */   public static <K, V> Builder<K, V> orderedBy(Comparator<K> comparator)
/* 188:    */   {
/* 189:377 */     return new Builder(comparator);
/* 190:    */   }
/* 191:    */   
/* 192:    */   public static <K extends Comparable<?>, V> Builder<K, V> reverseOrder()
/* 193:    */   {
/* 194:385 */     return new Builder(Ordering.natural().reverse());
/* 195:    */   }
/* 196:    */   
/* 197:    */   public static class Builder<K, V>
/* 198:    */     extends ImmutableMap.Builder<K, V>
/* 199:    */   {
/* 200:    */     private final Comparator<? super K> comparator;
/* 201:    */     
/* 202:    */     public Builder(Comparator<? super K> comparator)
/* 203:    */     {
/* 204:417 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/* 205:    */     }
/* 206:    */     
/* 207:    */     public Builder<K, V> put(K key, V value)
/* 208:    */     {
/* 209:427 */       super.put(key, value);
/* 210:428 */       return this;
/* 211:    */     }
/* 212:    */     
/* 213:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/* 214:    */     {
/* 215:441 */       super.put(entry);
/* 216:442 */       return this;
/* 217:    */     }
/* 218:    */     
/* 219:    */     public Builder<K, V> putAll(Map<? extends K, ? extends V> map)
/* 220:    */     {
/* 221:454 */       super.putAll(map);
/* 222:455 */       return this;
/* 223:    */     }
/* 224:    */     
/* 225:    */     @Beta
/* 226:    */     public Builder<K, V> putAll(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/* 227:    */     {
/* 228:469 */       super.putAll(entries);
/* 229:470 */       return this;
/* 230:    */     }
/* 231:    */     
/* 232:    */     @Deprecated
/* 233:    */     @Beta
/* 234:    */     public Builder<K, V> orderEntriesByValue(Comparator<? super V> valueComparator)
/* 235:    */     {
/* 236:483 */       throw new UnsupportedOperationException("Not available on ImmutableSortedMap.Builder");
/* 237:    */     }
/* 238:    */     
/* 239:    */     public ImmutableSortedMap<K, V> build()
/* 240:    */     {
/* 241:494 */       switch (this.size)
/* 242:    */       {
/* 243:    */       case 0: 
/* 244:496 */         return ImmutableSortedMap.emptyMap(this.comparator);
/* 245:    */       case 1: 
/* 246:498 */         return ImmutableSortedMap.of(this.comparator, this.entries[0].getKey(), this.entries[0].getValue());
/* 247:    */       }
/* 248:500 */       return ImmutableSortedMap.fromEntries(this.comparator, false, this.entries, this.size);
/* 249:    */     }
/* 250:    */   }
/* 251:    */   
/* 252:    */   ImmutableSortedMap(RegularImmutableSortedSet<K> keySet, ImmutableList<V> valueList)
/* 253:    */   {
/* 254:510 */     this(keySet, valueList, null);
/* 255:    */   }
/* 256:    */   
/* 257:    */   ImmutableSortedMap(RegularImmutableSortedSet<K> keySet, ImmutableList<V> valueList, ImmutableSortedMap<K, V> descendingMap)
/* 258:    */   {
/* 259:517 */     this.keySet = keySet;
/* 260:518 */     this.valueList = valueList;
/* 261:519 */     this.descendingMap = descendingMap;
/* 262:    */   }
/* 263:    */   
/* 264:    */   public int size()
/* 265:    */   {
/* 266:524 */     return this.valueList.size();
/* 267:    */   }
/* 268:    */   
/* 269:    */   public V get(@Nullable Object key)
/* 270:    */   {
/* 271:529 */     int index = this.keySet.indexOf(key);
/* 272:530 */     return index == -1 ? null : this.valueList.get(index);
/* 273:    */   }
/* 274:    */   
/* 275:    */   boolean isPartialView()
/* 276:    */   {
/* 277:535 */     return (this.keySet.isPartialView()) || (this.valueList.isPartialView());
/* 278:    */   }
/* 279:    */   
/* 280:    */   public ImmutableSet<Map.Entry<K, V>> entrySet()
/* 281:    */   {
/* 282:544 */     return super.entrySet();
/* 283:    */   }
/* 284:    */   
/* 285:    */   ImmutableSet<Map.Entry<K, V>> createEntrySet()
/* 286:    */   {
/* 287:576 */     isEmpty() ? ImmutableSet.of() : new ImmutableMapEntrySet()
/* 288:    */     {
/* 289:    */       public UnmodifiableIterator<Map.Entry<K, V>> iterator()
/* 290:    */       {
/* 291:553 */         return asList().iterator();
/* 292:    */       }
/* 293:    */       
/* 294:    */       ImmutableList<Map.Entry<K, V>> createAsList()
/* 295:    */       {
/* 296:558 */         new ImmutableAsList()
/* 297:    */         {
/* 298:    */           public Map.Entry<K, V> get(int index)
/* 299:    */           {
/* 300:561 */             return Maps.immutableEntry(ImmutableSortedMap.this.keySet.asList().get(index), ImmutableSortedMap.this.valueList.get(index));
/* 301:    */           }
/* 302:    */           
/* 303:    */           ImmutableCollection<Map.Entry<K, V>> delegateCollection()
/* 304:    */           {
/* 305:566 */             return ImmutableSortedMap.1EntrySet.this;
/* 306:    */           }
/* 307:    */         };
/* 308:    */       }
/* 309:    */       
/* 310:    */       ImmutableMap<K, V> map()
/* 311:    */       {
/* 312:573 */         return ImmutableSortedMap.this;
/* 313:    */       }
/* 314:    */     };
/* 315:    */   }
/* 316:    */   
/* 317:    */   public ImmutableSortedSet<K> keySet()
/* 318:    */   {
/* 319:584 */     return this.keySet;
/* 320:    */   }
/* 321:    */   
/* 322:    */   public ImmutableCollection<V> values()
/* 323:    */   {
/* 324:593 */     return this.valueList;
/* 325:    */   }
/* 326:    */   
/* 327:    */   public Comparator<? super K> comparator()
/* 328:    */   {
/* 329:604 */     return keySet().comparator();
/* 330:    */   }
/* 331:    */   
/* 332:    */   public K firstKey()
/* 333:    */   {
/* 334:609 */     return keySet().first();
/* 335:    */   }
/* 336:    */   
/* 337:    */   public K lastKey()
/* 338:    */   {
/* 339:614 */     return keySet().last();
/* 340:    */   }
/* 341:    */   
/* 342:    */   private ImmutableSortedMap<K, V> getSubMap(int fromIndex, int toIndex)
/* 343:    */   {
/* 344:618 */     if ((fromIndex == 0) && (toIndex == size())) {
/* 345:619 */       return this;
/* 346:    */     }
/* 347:620 */     if (fromIndex == toIndex) {
/* 348:621 */       return emptyMap(comparator());
/* 349:    */     }
/* 350:623 */     return new ImmutableSortedMap(this.keySet.getSubSet(fromIndex, toIndex), this.valueList.subList(fromIndex, toIndex));
/* 351:    */   }
/* 352:    */   
/* 353:    */   public ImmutableSortedMap<K, V> headMap(K toKey)
/* 354:    */   {
/* 355:640 */     return headMap(toKey, false);
/* 356:    */   }
/* 357:    */   
/* 358:    */   public ImmutableSortedMap<K, V> headMap(K toKey, boolean inclusive)
/* 359:    */   {
/* 360:657 */     return getSubMap(0, this.keySet.headIndex(Preconditions.checkNotNull(toKey), inclusive));
/* 361:    */   }
/* 362:    */   
/* 363:    */   public ImmutableSortedMap<K, V> subMap(K fromKey, K toKey)
/* 364:    */   {
/* 365:675 */     return subMap(fromKey, true, toKey, false);
/* 366:    */   }
/* 367:    */   
/* 368:    */   public ImmutableSortedMap<K, V> subMap(K fromKey, boolean fromInclusive, K toKey, boolean toInclusive)
/* 369:    */   {
/* 370:696 */     Preconditions.checkNotNull(fromKey);
/* 371:697 */     Preconditions.checkNotNull(toKey);
/* 372:698 */     Preconditions.checkArgument(comparator().compare(fromKey, toKey) <= 0, "expected fromKey <= toKey but %s > %s", new Object[] { fromKey, toKey });
/* 373:    */     
/* 374:    */ 
/* 375:    */ 
/* 376:    */ 
/* 377:703 */     return headMap(toKey, toInclusive).tailMap(fromKey, fromInclusive);
/* 378:    */   }
/* 379:    */   
/* 380:    */   public ImmutableSortedMap<K, V> tailMap(K fromKey)
/* 381:    */   {
/* 382:718 */     return tailMap(fromKey, true);
/* 383:    */   }
/* 384:    */   
/* 385:    */   public ImmutableSortedMap<K, V> tailMap(K fromKey, boolean inclusive)
/* 386:    */   {
/* 387:736 */     return getSubMap(this.keySet.tailIndex(Preconditions.checkNotNull(fromKey), inclusive), size());
/* 388:    */   }
/* 389:    */   
/* 390:    */   public Map.Entry<K, V> lowerEntry(K key)
/* 391:    */   {
/* 392:741 */     return headMap(key, false).lastEntry();
/* 393:    */   }
/* 394:    */   
/* 395:    */   public K lowerKey(K key)
/* 396:    */   {
/* 397:746 */     return Maps.keyOrNull(lowerEntry(key));
/* 398:    */   }
/* 399:    */   
/* 400:    */   public Map.Entry<K, V> floorEntry(K key)
/* 401:    */   {
/* 402:751 */     return headMap(key, true).lastEntry();
/* 403:    */   }
/* 404:    */   
/* 405:    */   public K floorKey(K key)
/* 406:    */   {
/* 407:756 */     return Maps.keyOrNull(floorEntry(key));
/* 408:    */   }
/* 409:    */   
/* 410:    */   public Map.Entry<K, V> ceilingEntry(K key)
/* 411:    */   {
/* 412:761 */     return tailMap(key, true).firstEntry();
/* 413:    */   }
/* 414:    */   
/* 415:    */   public K ceilingKey(K key)
/* 416:    */   {
/* 417:766 */     return Maps.keyOrNull(ceilingEntry(key));
/* 418:    */   }
/* 419:    */   
/* 420:    */   public Map.Entry<K, V> higherEntry(K key)
/* 421:    */   {
/* 422:771 */     return tailMap(key, false).firstEntry();
/* 423:    */   }
/* 424:    */   
/* 425:    */   public K higherKey(K key)
/* 426:    */   {
/* 427:776 */     return Maps.keyOrNull(higherEntry(key));
/* 428:    */   }
/* 429:    */   
/* 430:    */   public Map.Entry<K, V> firstEntry()
/* 431:    */   {
/* 432:781 */     return isEmpty() ? null : (Map.Entry)entrySet().asList().get(0);
/* 433:    */   }
/* 434:    */   
/* 435:    */   public Map.Entry<K, V> lastEntry()
/* 436:    */   {
/* 437:786 */     return isEmpty() ? null : (Map.Entry)entrySet().asList().get(size() - 1);
/* 438:    */   }
/* 439:    */   
/* 440:    */   @Deprecated
/* 441:    */   public final Map.Entry<K, V> pollFirstEntry()
/* 442:    */   {
/* 443:798 */     throw new UnsupportedOperationException();
/* 444:    */   }
/* 445:    */   
/* 446:    */   @Deprecated
/* 447:    */   public final Map.Entry<K, V> pollLastEntry()
/* 448:    */   {
/* 449:810 */     throw new UnsupportedOperationException();
/* 450:    */   }
/* 451:    */   
/* 452:    */   public ImmutableSortedMap<K, V> descendingMap()
/* 453:    */   {
/* 454:817 */     ImmutableSortedMap<K, V> result = this.descendingMap;
/* 455:818 */     if (result == null)
/* 456:    */     {
/* 457:819 */       if (isEmpty()) {
/* 458:820 */         return result = emptyMap(Ordering.from(comparator()).reverse());
/* 459:    */       }
/* 460:822 */       return result = new ImmutableSortedMap((RegularImmutableSortedSet)this.keySet.descendingSet(), this.valueList.reverse(), this);
/* 461:    */     }
/* 462:827 */     return result;
/* 463:    */   }
/* 464:    */   
/* 465:    */   public ImmutableSortedSet<K> navigableKeySet()
/* 466:    */   {
/* 467:832 */     return this.keySet;
/* 468:    */   }
/* 469:    */   
/* 470:    */   public ImmutableSortedSet<K> descendingKeySet()
/* 471:    */   {
/* 472:837 */     return this.keySet.descendingSet();
/* 473:    */   }
/* 474:    */   
/* 475:    */   private static class SerializedForm
/* 476:    */     extends ImmutableMap.SerializedForm
/* 477:    */   {
/* 478:    */     private final Comparator<Object> comparator;
/* 479:    */     private static final long serialVersionUID = 0L;
/* 480:    */     
/* 481:    */     SerializedForm(ImmutableSortedMap<?, ?> sortedMap)
/* 482:    */     {
/* 483:851 */       super();
/* 484:852 */       this.comparator = sortedMap.comparator();
/* 485:    */     }
/* 486:    */     
/* 487:    */     Object readResolve()
/* 488:    */     {
/* 489:857 */       ImmutableSortedMap.Builder<Object, Object> builder = new ImmutableSortedMap.Builder(this.comparator);
/* 490:858 */       return createMap(builder);
/* 491:    */     }
/* 492:    */   }
/* 493:    */   
/* 494:    */   Object writeReplace()
/* 495:    */   {
/* 496:866 */     return new SerializedForm(this);
/* 497:    */   }
/* 498:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableSortedMap
 * JD-Core Version:    0.7.0.1
 */