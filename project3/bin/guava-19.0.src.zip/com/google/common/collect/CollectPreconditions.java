/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ final class CollectPreconditions
/*  8:   */ {
/*  9:   */   static void checkEntryNotNull(Object key, Object value)
/* 10:   */   {
/* 11:30 */     if (key == null) {
/* 12:31 */       throw new NullPointerException("null key in entry: null=" + value);
/* 13:   */     }
/* 14:32 */     if (value == null) {
/* 15:33 */       throw new NullPointerException("null value in entry: " + key + "=null");
/* 16:   */     }
/* 17:   */   }
/* 18:   */   
/* 19:   */   static int checkNonnegative(int value, String name)
/* 20:   */   {
/* 21:38 */     if (value < 0) {
/* 22:39 */       throw new IllegalArgumentException(name + " cannot be negative but was: " + value);
/* 23:   */     }
/* 24:41 */     return value;
/* 25:   */   }
/* 26:   */   
/* 27:   */   static void checkPositive(int value, String name)
/* 28:   */   {
/* 29:45 */     if (value <= 0) {
/* 30:46 */       throw new IllegalArgumentException(name + " must be positive but was: " + value);
/* 31:   */     }
/* 32:   */   }
/* 33:   */   
/* 34:   */   static void checkRemove(boolean canRemove)
/* 35:   */   {
/* 36:55 */     Preconditions.checkState(canRemove, "no calls to next() since the last call to remove()");
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.CollectPreconditions
 * JD-Core Version:    0.7.0.1
 */