/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.annotations.GwtIncompatible;
/*  5:   */ import com.google.j2objc.annotations.Weak;
/*  6:   */ import java.io.Serializable;
/*  7:   */ import java.util.Map.Entry;
/*  8:   */ import javax.annotation.Nullable;
/*  9:   */ 
/* 10:   */ @GwtCompatible(emulated=true)
/* 11:   */ final class ImmutableMapKeySet<K, V>
/* 12:   */   extends ImmutableSet.Indexed<K>
/* 13:   */ {
/* 14:   */   @Weak
/* 15:   */   private final ImmutableMap<K, V> map;
/* 16:   */   
/* 17:   */   ImmutableMapKeySet(ImmutableMap<K, V> map)
/* 18:   */   {
/* 19:38 */     this.map = map;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public int size()
/* 23:   */   {
/* 24:43 */     return this.map.size();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public UnmodifiableIterator<K> iterator()
/* 28:   */   {
/* 29:48 */     return this.map.keyIterator();
/* 30:   */   }
/* 31:   */   
/* 32:   */   public boolean contains(@Nullable Object object)
/* 33:   */   {
/* 34:53 */     return this.map.containsKey(object);
/* 35:   */   }
/* 36:   */   
/* 37:   */   K get(int index)
/* 38:   */   {
/* 39:58 */     return ((Map.Entry)this.map.entrySet().asList().get(index)).getKey();
/* 40:   */   }
/* 41:   */   
/* 42:   */   boolean isPartialView()
/* 43:   */   {
/* 44:63 */     return true;
/* 45:   */   }
/* 46:   */   
/* 47:   */   @GwtIncompatible("serialization")
/* 48:   */   Object writeReplace()
/* 49:   */   {
/* 50:69 */     return new KeySetSerializedForm(this.map);
/* 51:   */   }
/* 52:   */   
/* 53:   */   @GwtIncompatible("serialization")
/* 54:   */   private static class KeySetSerializedForm<K>
/* 55:   */     implements Serializable
/* 56:   */   {
/* 57:   */     final ImmutableMap<K, ?> map;
/* 58:   */     private static final long serialVersionUID = 0L;
/* 59:   */     
/* 60:   */     KeySetSerializedForm(ImmutableMap<K, ?> map)
/* 61:   */     {
/* 62:77 */       this.map = map;
/* 63:   */     }
/* 64:   */     
/* 65:   */     Object readResolve()
/* 66:   */     {
/* 67:81 */       return this.map.keySet();
/* 68:   */     }
/* 69:   */   }
/* 70:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableMapKeySet
 * JD-Core Version:    0.7.0.1
 */