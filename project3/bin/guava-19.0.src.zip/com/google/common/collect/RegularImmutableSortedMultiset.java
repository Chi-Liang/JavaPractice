/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.primitives.Ints;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ final class RegularImmutableSortedMultiset<E>
/*   9:    */   extends ImmutableSortedMultiset<E>
/*  10:    */ {
/*  11: 34 */   private static final long[] ZERO_CUMULATIVE_COUNTS = { 0L };
/*  12:    */   private final transient RegularImmutableSortedSet<E> elementSet;
/*  13:    */   private final transient long[] cumulativeCounts;
/*  14:    */   private final transient int offset;
/*  15:    */   private final transient int length;
/*  16:    */   
/*  17:    */   RegularImmutableSortedMultiset(Comparator<? super E> comparator)
/*  18:    */   {
/*  19: 42 */     this.elementSet = ImmutableSortedSet.emptySet(comparator);
/*  20: 43 */     this.cumulativeCounts = ZERO_CUMULATIVE_COUNTS;
/*  21: 44 */     this.offset = 0;
/*  22: 45 */     this.length = 0;
/*  23:    */   }
/*  24:    */   
/*  25:    */   RegularImmutableSortedMultiset(RegularImmutableSortedSet<E> elementSet, long[] cumulativeCounts, int offset, int length)
/*  26:    */   {
/*  27: 50 */     this.elementSet = elementSet;
/*  28: 51 */     this.cumulativeCounts = cumulativeCounts;
/*  29: 52 */     this.offset = offset;
/*  30: 53 */     this.length = length;
/*  31:    */   }
/*  32:    */   
/*  33:    */   private int getCount(int index)
/*  34:    */   {
/*  35: 57 */     return (int)(this.cumulativeCounts[(this.offset + index + 1)] - this.cumulativeCounts[(this.offset + index)]);
/*  36:    */   }
/*  37:    */   
/*  38:    */   Multiset.Entry<E> getEntry(int index)
/*  39:    */   {
/*  40: 62 */     return Multisets.immutableEntry(this.elementSet.asList().get(index), getCount(index));
/*  41:    */   }
/*  42:    */   
/*  43:    */   public Multiset.Entry<E> firstEntry()
/*  44:    */   {
/*  45: 67 */     return isEmpty() ? null : getEntry(0);
/*  46:    */   }
/*  47:    */   
/*  48:    */   public Multiset.Entry<E> lastEntry()
/*  49:    */   {
/*  50: 72 */     return isEmpty() ? null : getEntry(this.length - 1);
/*  51:    */   }
/*  52:    */   
/*  53:    */   public int count(@Nullable Object element)
/*  54:    */   {
/*  55: 77 */     int index = this.elementSet.indexOf(element);
/*  56: 78 */     return index >= 0 ? getCount(index) : 0;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public int size()
/*  60:    */   {
/*  61: 83 */     long size = this.cumulativeCounts[(this.offset + this.length)] - this.cumulativeCounts[this.offset];
/*  62: 84 */     return Ints.saturatedCast(size);
/*  63:    */   }
/*  64:    */   
/*  65:    */   public ImmutableSortedSet<E> elementSet()
/*  66:    */   {
/*  67: 89 */     return this.elementSet;
/*  68:    */   }
/*  69:    */   
/*  70:    */   public ImmutableSortedMultiset<E> headMultiset(E upperBound, BoundType boundType)
/*  71:    */   {
/*  72: 94 */     return getSubMultiset(0, this.elementSet.headIndex(upperBound, Preconditions.checkNotNull(boundType) == BoundType.CLOSED));
/*  73:    */   }
/*  74:    */   
/*  75:    */   public ImmutableSortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType)
/*  76:    */   {
/*  77: 99 */     return getSubMultiset(this.elementSet.tailIndex(lowerBound, Preconditions.checkNotNull(boundType) == BoundType.CLOSED), this.length);
/*  78:    */   }
/*  79:    */   
/*  80:    */   ImmutableSortedMultiset<E> getSubMultiset(int from, int to)
/*  81:    */   {
/*  82:104 */     Preconditions.checkPositionIndexes(from, to, this.length);
/*  83:105 */     if (from == to) {
/*  84:106 */       return emptyMultiset(comparator());
/*  85:    */     }
/*  86:107 */     if ((from == 0) && (to == this.length)) {
/*  87:108 */       return this;
/*  88:    */     }
/*  89:110 */     RegularImmutableSortedSet<E> subElementSet = this.elementSet.getSubSet(from, to);
/*  90:    */     
/*  91:112 */     return new RegularImmutableSortedMultiset(subElementSet, this.cumulativeCounts, this.offset + from, to - from);
/*  92:    */   }
/*  93:    */   
/*  94:    */   boolean isPartialView()
/*  95:    */   {
/*  96:119 */     return (this.offset > 0) || (this.length < this.cumulativeCounts.length - 1);
/*  97:    */   }
/*  98:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularImmutableSortedMultiset
 * JD-Core Version:    0.7.0.1
 */