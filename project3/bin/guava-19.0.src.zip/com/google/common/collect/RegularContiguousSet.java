/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Collection;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ final class RegularContiguousSet<C extends Comparable>
/*  12:    */   extends ContiguousSet<C>
/*  13:    */ {
/*  14:    */   private final Range<C> range;
/*  15:    */   private static final long serialVersionUID = 0L;
/*  16:    */   
/*  17:    */   RegularContiguousSet(Range<C> range, DiscreteDomain<C> domain)
/*  18:    */   {
/*  19: 40 */     super(domain);
/*  20: 41 */     this.range = range;
/*  21:    */   }
/*  22:    */   
/*  23:    */   private ContiguousSet<C> intersectionInCurrentDomain(Range<C> other)
/*  24:    */   {
/*  25: 45 */     return this.range.isConnected(other) ? ContiguousSet.create(this.range.intersection(other), this.domain) : new EmptyContiguousSet(this.domain);
/*  26:    */   }
/*  27:    */   
/*  28:    */   ContiguousSet<C> headSetImpl(C toElement, boolean inclusive)
/*  29:    */   {
/*  30: 52 */     return intersectionInCurrentDomain(Range.upTo(toElement, BoundType.forBoolean(inclusive)));
/*  31:    */   }
/*  32:    */   
/*  33:    */   ContiguousSet<C> subSetImpl(C fromElement, boolean fromInclusive, C toElement, boolean toInclusive)
/*  34:    */   {
/*  35: 58 */     if ((fromElement.compareTo(toElement) == 0) && (!fromInclusive) && (!toInclusive)) {
/*  36: 60 */       return new EmptyContiguousSet(this.domain);
/*  37:    */     }
/*  38: 62 */     return intersectionInCurrentDomain(Range.range(fromElement, BoundType.forBoolean(fromInclusive), toElement, BoundType.forBoolean(toInclusive)));
/*  39:    */   }
/*  40:    */   
/*  41:    */   ContiguousSet<C> tailSetImpl(C fromElement, boolean inclusive)
/*  42:    */   {
/*  43: 70 */     return intersectionInCurrentDomain(Range.downTo(fromElement, BoundType.forBoolean(inclusive)));
/*  44:    */   }
/*  45:    */   
/*  46:    */   @GwtIncompatible("not used by GWT emulation")
/*  47:    */   int indexOf(Object target)
/*  48:    */   {
/*  49: 76 */     return contains(target) ? (int)this.domain.distance(first(), (Comparable)target) : -1;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public UnmodifiableIterator<C> iterator()
/*  53:    */   {
/*  54: 81 */     new AbstractSequentialIterator(first())
/*  55:    */     {
/*  56: 82 */       final C last = RegularContiguousSet.this.last();
/*  57:    */       
/*  58:    */       protected C computeNext(C previous)
/*  59:    */       {
/*  60: 86 */         return RegularContiguousSet.equalsOrThrow(previous, this.last) ? null : RegularContiguousSet.this.domain.next(previous);
/*  61:    */       }
/*  62:    */     };
/*  63:    */   }
/*  64:    */   
/*  65:    */   @GwtIncompatible("NavigableSet")
/*  66:    */   public UnmodifiableIterator<C> descendingIterator()
/*  67:    */   {
/*  68: 94 */     new AbstractSequentialIterator(last())
/*  69:    */     {
/*  70: 95 */       final C first = RegularContiguousSet.this.first();
/*  71:    */       
/*  72:    */       protected C computeNext(C previous)
/*  73:    */       {
/*  74: 99 */         return RegularContiguousSet.equalsOrThrow(previous, this.first) ? null : RegularContiguousSet.this.domain.previous(previous);
/*  75:    */       }
/*  76:    */     };
/*  77:    */   }
/*  78:    */   
/*  79:    */   private static boolean equalsOrThrow(Comparable<?> left, @Nullable Comparable<?> right)
/*  80:    */   {
/*  81:105 */     return (right != null) && (Range.compareOrThrow(left, right) == 0);
/*  82:    */   }
/*  83:    */   
/*  84:    */   boolean isPartialView()
/*  85:    */   {
/*  86:110 */     return false;
/*  87:    */   }
/*  88:    */   
/*  89:    */   public C first()
/*  90:    */   {
/*  91:115 */     return this.range.lowerBound.leastValueAbove(this.domain);
/*  92:    */   }
/*  93:    */   
/*  94:    */   public C last()
/*  95:    */   {
/*  96:120 */     return this.range.upperBound.greatestValueBelow(this.domain);
/*  97:    */   }
/*  98:    */   
/*  99:    */   public int size()
/* 100:    */   {
/* 101:125 */     long distance = this.domain.distance(first(), last());
/* 102:126 */     return distance >= 2147483647L ? 2147483647 : (int)distance + 1;
/* 103:    */   }
/* 104:    */   
/* 105:    */   public boolean contains(@Nullable Object object)
/* 106:    */   {
/* 107:131 */     if (object == null) {
/* 108:132 */       return false;
/* 109:    */     }
/* 110:    */     try
/* 111:    */     {
/* 112:135 */       return this.range.contains((Comparable)object);
/* 113:    */     }
/* 114:    */     catch (ClassCastException e) {}
/* 115:137 */     return false;
/* 116:    */   }
/* 117:    */   
/* 118:    */   public boolean containsAll(Collection<?> targets)
/* 119:    */   {
/* 120:143 */     return Collections2.containsAllImpl(this, targets);
/* 121:    */   }
/* 122:    */   
/* 123:    */   public boolean isEmpty()
/* 124:    */   {
/* 125:148 */     return false;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public ContiguousSet<C> intersection(ContiguousSet<C> other)
/* 129:    */   {
/* 130:153 */     Preconditions.checkNotNull(other);
/* 131:154 */     Preconditions.checkArgument(this.domain.equals(other.domain));
/* 132:155 */     if (other.isEmpty()) {
/* 133:156 */       return other;
/* 134:    */     }
/* 135:158 */     C lowerEndpoint = (Comparable)Ordering.natural().max(first(), other.first());
/* 136:159 */     C upperEndpoint = (Comparable)Ordering.natural().min(last(), other.last());
/* 137:160 */     return lowerEndpoint.compareTo(upperEndpoint) < 0 ? ContiguousSet.create(Range.closed(lowerEndpoint, upperEndpoint), this.domain) : new EmptyContiguousSet(this.domain);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public Range<C> range()
/* 141:    */   {
/* 142:168 */     return range(BoundType.CLOSED, BoundType.CLOSED);
/* 143:    */   }
/* 144:    */   
/* 145:    */   public Range<C> range(BoundType lowerBoundType, BoundType upperBoundType)
/* 146:    */   {
/* 147:173 */     return Range.create(this.range.lowerBound.withLowerBoundType(lowerBoundType, this.domain), this.range.upperBound.withUpperBoundType(upperBoundType, this.domain));
/* 148:    */   }
/* 149:    */   
/* 150:    */   public boolean equals(@Nullable Object object)
/* 151:    */   {
/* 152:180 */     if (object == this) {
/* 153:181 */       return true;
/* 154:    */     }
/* 155:182 */     if ((object instanceof RegularContiguousSet))
/* 156:    */     {
/* 157:183 */       RegularContiguousSet<?> that = (RegularContiguousSet)object;
/* 158:184 */       if (this.domain.equals(that.domain)) {
/* 159:185 */         return (first().equals(that.first())) && (last().equals(that.last()));
/* 160:    */       }
/* 161:    */     }
/* 162:188 */     return super.equals(object);
/* 163:    */   }
/* 164:    */   
/* 165:    */   public int hashCode()
/* 166:    */   {
/* 167:194 */     return Sets.hashCodeImpl(this);
/* 168:    */   }
/* 169:    */   
/* 170:    */   @GwtIncompatible("serialization")
/* 171:    */   private static final class SerializedForm<C extends Comparable>
/* 172:    */     implements Serializable
/* 173:    */   {
/* 174:    */     final Range<C> range;
/* 175:    */     final DiscreteDomain<C> domain;
/* 176:    */     
/* 177:    */     private SerializedForm(Range<C> range, DiscreteDomain<C> domain)
/* 178:    */     {
/* 179:203 */       this.range = range;
/* 180:204 */       this.domain = domain;
/* 181:    */     }
/* 182:    */     
/* 183:    */     private Object readResolve()
/* 184:    */     {
/* 185:208 */       return new RegularContiguousSet(this.range, this.domain);
/* 186:    */     }
/* 187:    */   }
/* 188:    */   
/* 189:    */   @GwtIncompatible("serialization")
/* 190:    */   Object writeReplace()
/* 191:    */   {
/* 192:215 */     return new SerializedForm(this.range, this.domain, null);
/* 193:    */   }
/* 194:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.RegularContiguousSet
 * JD-Core Version:    0.7.0.1
 */