/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import java.util.Map.Entry;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @GwtCompatible
/*  10:    */ public abstract class ForwardingMapEntry<K, V>
/*  11:    */   extends ForwardingObject
/*  12:    */   implements Map.Entry<K, V>
/*  13:    */ {
/*  14:    */   protected abstract Map.Entry<K, V> delegate();
/*  15:    */   
/*  16:    */   public K getKey()
/*  17:    */   {
/*  18: 66 */     return delegate().getKey();
/*  19:    */   }
/*  20:    */   
/*  21:    */   public V getValue()
/*  22:    */   {
/*  23: 71 */     return delegate().getValue();
/*  24:    */   }
/*  25:    */   
/*  26:    */   public V setValue(V value)
/*  27:    */   {
/*  28: 76 */     return delegate().setValue(value);
/*  29:    */   }
/*  30:    */   
/*  31:    */   public boolean equals(@Nullable Object object)
/*  32:    */   {
/*  33: 81 */     return delegate().equals(object);
/*  34:    */   }
/*  35:    */   
/*  36:    */   public int hashCode()
/*  37:    */   {
/*  38: 86 */     return delegate().hashCode();
/*  39:    */   }
/*  40:    */   
/*  41:    */   protected boolean standardEquals(@Nullable Object object)
/*  42:    */   {
/*  43: 98 */     if ((object instanceof Map.Entry))
/*  44:    */     {
/*  45: 99 */       Map.Entry<?, ?> that = (Map.Entry)object;
/*  46:100 */       return (Objects.equal(getKey(), that.getKey())) && (Objects.equal(getValue(), that.getValue()));
/*  47:    */     }
/*  48:103 */     return false;
/*  49:    */   }
/*  50:    */   
/*  51:    */   protected int standardHashCode()
/*  52:    */   {
/*  53:114 */     K k = getKey();
/*  54:115 */     V v = getValue();
/*  55:116 */     return (k == null ? 0 : k.hashCode()) ^ (v == null ? 0 : v.hashCode());
/*  56:    */   }
/*  57:    */   
/*  58:    */   @Beta
/*  59:    */   protected String standardToString()
/*  60:    */   {
/*  61:129 */     return getKey() + "=" + getValue();
/*  62:    */   }
/*  63:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingMapEntry
 * JD-Core Version:    0.7.0.1
 */