/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.primitives.Ints;
/*   7:    */ import java.io.InvalidObjectException;
/*   8:    */ import java.io.ObjectStreamException;
/*   9:    */ import java.io.Serializable;
/*  10:    */ import java.util.ConcurrentModificationException;
/*  11:    */ import java.util.Iterator;
/*  12:    */ import java.util.Map;
/*  13:    */ import java.util.Map.Entry;
/*  14:    */ import java.util.Set;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ @GwtCompatible(emulated=true)
/*  18:    */ abstract class AbstractMapBasedMultiset<E>
/*  19:    */   extends AbstractMultiset<E>
/*  20:    */   implements Serializable
/*  21:    */ {
/*  22:    */   private transient Map<E, Count> backingMap;
/*  23:    */   private transient long size;
/*  24:    */   @GwtIncompatible("not needed in emulated source.")
/*  25:    */   private static final long serialVersionUID = -2250766705698539974L;
/*  26:    */   
/*  27:    */   protected AbstractMapBasedMultiset(Map<E, Count> backingMap)
/*  28:    */   {
/*  29: 61 */     this.backingMap = ((Map)Preconditions.checkNotNull(backingMap));
/*  30: 62 */     this.size = super.size();
/*  31:    */   }
/*  32:    */   
/*  33:    */   void setBackingMap(Map<E, Count> backingMap)
/*  34:    */   {
/*  35: 67 */     this.backingMap = backingMap;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public Set<Multiset.Entry<E>> entrySet()
/*  39:    */   {
/*  40: 81 */     return super.entrySet();
/*  41:    */   }
/*  42:    */   
/*  43:    */   Iterator<Multiset.Entry<E>> entryIterator()
/*  44:    */   {
/*  45: 86 */     final Iterator<Map.Entry<E, Count>> backingEntries = this.backingMap.entrySet().iterator();
/*  46: 87 */     new Iterator()
/*  47:    */     {
/*  48:    */       Map.Entry<E, Count> toRemove;
/*  49:    */       
/*  50:    */       public boolean hasNext()
/*  51:    */       {
/*  52: 92 */         return backingEntries.hasNext();
/*  53:    */       }
/*  54:    */       
/*  55:    */       public Multiset.Entry<E> next()
/*  56:    */       {
/*  57: 97 */         final Map.Entry<E, Count> mapEntry = (Map.Entry)backingEntries.next();
/*  58: 98 */         this.toRemove = mapEntry;
/*  59: 99 */         new Multisets.AbstractEntry()
/*  60:    */         {
/*  61:    */           public E getElement()
/*  62:    */           {
/*  63:102 */             return mapEntry.getKey();
/*  64:    */           }
/*  65:    */           
/*  66:    */           public int getCount()
/*  67:    */           {
/*  68:107 */             Count count = (Count)mapEntry.getValue();
/*  69:108 */             if ((count == null) || (count.get() == 0))
/*  70:    */             {
/*  71:109 */               Count frequency = (Count)AbstractMapBasedMultiset.this.backingMap.get(getElement());
/*  72:110 */               if (frequency != null) {
/*  73:111 */                 return frequency.get();
/*  74:    */               }
/*  75:    */             }
/*  76:114 */             return count == null ? 0 : count.get();
/*  77:    */           }
/*  78:    */         };
/*  79:    */       }
/*  80:    */       
/*  81:    */       public void remove()
/*  82:    */       {
/*  83:121 */         CollectPreconditions.checkRemove(this.toRemove != null);
/*  84:122 */         AbstractMapBasedMultiset.access$122(AbstractMapBasedMultiset.this, ((Count)this.toRemove.getValue()).getAndSet(0));
/*  85:123 */         backingEntries.remove();
/*  86:124 */         this.toRemove = null;
/*  87:    */       }
/*  88:    */     };
/*  89:    */   }
/*  90:    */   
/*  91:    */   public void clear()
/*  92:    */   {
/*  93:131 */     for (Count frequency : this.backingMap.values()) {
/*  94:132 */       frequency.set(0);
/*  95:    */     }
/*  96:134 */     this.backingMap.clear();
/*  97:135 */     this.size = 0L;
/*  98:    */   }
/*  99:    */   
/* 100:    */   int distinctElements()
/* 101:    */   {
/* 102:140 */     return this.backingMap.size();
/* 103:    */   }
/* 104:    */   
/* 105:    */   public int size()
/* 106:    */   {
/* 107:147 */     return Ints.saturatedCast(this.size);
/* 108:    */   }
/* 109:    */   
/* 110:    */   public Iterator<E> iterator()
/* 111:    */   {
/* 112:152 */     return new MapBasedMultisetIterator();
/* 113:    */   }
/* 114:    */   
/* 115:    */   private class MapBasedMultisetIterator
/* 116:    */     implements Iterator<E>
/* 117:    */   {
/* 118:    */     final Iterator<Map.Entry<E, Count>> entryIterator;
/* 119:    */     Map.Entry<E, Count> currentEntry;
/* 120:    */     int occurrencesLeft;
/* 121:    */     boolean canRemove;
/* 122:    */     
/* 123:    */     MapBasedMultisetIterator()
/* 124:    */     {
/* 125:167 */       this.entryIterator = AbstractMapBasedMultiset.this.backingMap.entrySet().iterator();
/* 126:    */     }
/* 127:    */     
/* 128:    */     public boolean hasNext()
/* 129:    */     {
/* 130:172 */       return (this.occurrencesLeft > 0) || (this.entryIterator.hasNext());
/* 131:    */     }
/* 132:    */     
/* 133:    */     public E next()
/* 134:    */     {
/* 135:177 */       if (this.occurrencesLeft == 0)
/* 136:    */       {
/* 137:178 */         this.currentEntry = ((Map.Entry)this.entryIterator.next());
/* 138:179 */         this.occurrencesLeft = ((Count)this.currentEntry.getValue()).get();
/* 139:    */       }
/* 140:181 */       this.occurrencesLeft -= 1;
/* 141:182 */       this.canRemove = true;
/* 142:183 */       return this.currentEntry.getKey();
/* 143:    */     }
/* 144:    */     
/* 145:    */     public void remove()
/* 146:    */     {
/* 147:188 */       CollectPreconditions.checkRemove(this.canRemove);
/* 148:189 */       int frequency = ((Count)this.currentEntry.getValue()).get();
/* 149:190 */       if (frequency <= 0) {
/* 150:191 */         throw new ConcurrentModificationException();
/* 151:    */       }
/* 152:193 */       if (((Count)this.currentEntry.getValue()).addAndGet(-1) == 0) {
/* 153:194 */         this.entryIterator.remove();
/* 154:    */       }
/* 155:196 */       AbstractMapBasedMultiset.access$110(AbstractMapBasedMultiset.this);
/* 156:197 */       this.canRemove = false;
/* 157:    */     }
/* 158:    */   }
/* 159:    */   
/* 160:    */   public int count(@Nullable Object element)
/* 161:    */   {
/* 162:203 */     Count frequency = (Count)Maps.safeGet(this.backingMap, element);
/* 163:204 */     return frequency == null ? 0 : frequency.get();
/* 164:    */   }
/* 165:    */   
/* 166:    */   public int add(@Nullable E element, int occurrences)
/* 167:    */   {
/* 168:218 */     if (occurrences == 0) {
/* 169:219 */       return count(element);
/* 170:    */     }
/* 171:221 */     Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s", new Object[] { Integer.valueOf(occurrences) });
/* 172:222 */     Count frequency = (Count)this.backingMap.get(element);
/* 173:    */     int oldCount;
/* 174:224 */     if (frequency == null)
/* 175:    */     {
/* 176:225 */       int oldCount = 0;
/* 177:226 */       this.backingMap.put(element, new Count(occurrences));
/* 178:    */     }
/* 179:    */     else
/* 180:    */     {
/* 181:228 */       oldCount = frequency.get();
/* 182:229 */       long newCount = oldCount + occurrences;
/* 183:230 */       Preconditions.checkArgument(newCount <= 2147483647L, "too many occurrences: %s", new Object[] { Long.valueOf(newCount) });
/* 184:231 */       frequency.getAndAdd(occurrences);
/* 185:    */     }
/* 186:233 */     this.size += occurrences;
/* 187:234 */     return oldCount;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public int remove(@Nullable Object element, int occurrences)
/* 191:    */   {
/* 192:239 */     if (occurrences == 0) {
/* 193:240 */       return count(element);
/* 194:    */     }
/* 195:242 */     Preconditions.checkArgument(occurrences > 0, "occurrences cannot be negative: %s", new Object[] { Integer.valueOf(occurrences) });
/* 196:243 */     Count frequency = (Count)this.backingMap.get(element);
/* 197:244 */     if (frequency == null) {
/* 198:245 */       return 0;
/* 199:    */     }
/* 200:248 */     int oldCount = frequency.get();
/* 201:    */     int numberRemoved;
/* 202:    */     int numberRemoved;
/* 203:251 */     if (oldCount > occurrences)
/* 204:    */     {
/* 205:252 */       numberRemoved = occurrences;
/* 206:    */     }
/* 207:    */     else
/* 208:    */     {
/* 209:254 */       numberRemoved = oldCount;
/* 210:255 */       this.backingMap.remove(element);
/* 211:    */     }
/* 212:258 */     frequency.addAndGet(-numberRemoved);
/* 213:259 */     this.size -= numberRemoved;
/* 214:260 */     return oldCount;
/* 215:    */   }
/* 216:    */   
/* 217:    */   public int setCount(@Nullable E element, int count)
/* 218:    */   {
/* 219:266 */     CollectPreconditions.checkNonnegative(count, "count");
/* 220:    */     int oldCount;
/* 221:    */     int oldCount;
/* 222:270 */     if (count == 0)
/* 223:    */     {
/* 224:271 */       Count existingCounter = (Count)this.backingMap.remove(element);
/* 225:272 */       oldCount = getAndSet(existingCounter, count);
/* 226:    */     }
/* 227:    */     else
/* 228:    */     {
/* 229:274 */       Count existingCounter = (Count)this.backingMap.get(element);
/* 230:275 */       oldCount = getAndSet(existingCounter, count);
/* 231:277 */       if (existingCounter == null) {
/* 232:278 */         this.backingMap.put(element, new Count(count));
/* 233:    */       }
/* 234:    */     }
/* 235:282 */     this.size += count - oldCount;
/* 236:283 */     return oldCount;
/* 237:    */   }
/* 238:    */   
/* 239:    */   private static int getAndSet(Count i, int count)
/* 240:    */   {
/* 241:287 */     if (i == null) {
/* 242:288 */       return 0;
/* 243:    */     }
/* 244:291 */     return i.getAndSet(count);
/* 245:    */   }
/* 246:    */   
/* 247:    */   @GwtIncompatible("java.io.ObjectStreamException")
/* 248:    */   private void readObjectNoData()
/* 249:    */     throws ObjectStreamException
/* 250:    */   {
/* 251:297 */     throw new InvalidObjectException("Stream data required");
/* 252:    */   }
/* 253:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractMapBasedMultiset
 * JD-Core Version:    0.7.0.1
 */