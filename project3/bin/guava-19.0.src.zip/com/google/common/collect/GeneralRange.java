/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Objects;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.Comparator;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true)
/*  11:    */ final class GeneralRange<T>
/*  12:    */   implements Serializable
/*  13:    */ {
/*  14:    */   private final Comparator<? super T> comparator;
/*  15:    */   private final boolean hasLowerBound;
/*  16:    */   @Nullable
/*  17:    */   private final T lowerEndpoint;
/*  18:    */   private final BoundType lowerBoundType;
/*  19:    */   private final boolean hasUpperBound;
/*  20:    */   @Nullable
/*  21:    */   private final T upperEndpoint;
/*  22:    */   private final BoundType upperBoundType;
/*  23:    */   private transient GeneralRange<T> reverse;
/*  24:    */   
/*  25:    */   static <T extends Comparable> GeneralRange<T> from(Range<T> range)
/*  26:    */   {
/*  27: 45 */     T lowerEndpoint = range.hasLowerBound() ? range.lowerEndpoint() : null;
/*  28: 46 */     BoundType lowerBoundType = range.hasLowerBound() ? range.lowerBoundType() : BoundType.OPEN;
/*  29:    */     
/*  30: 48 */     T upperEndpoint = range.hasUpperBound() ? range.upperEndpoint() : null;
/*  31: 49 */     BoundType upperBoundType = range.hasUpperBound() ? range.upperBoundType() : BoundType.OPEN;
/*  32: 50 */     return new GeneralRange(Ordering.natural(), range.hasLowerBound(), lowerEndpoint, lowerBoundType, range.hasUpperBound(), upperEndpoint, upperBoundType);
/*  33:    */   }
/*  34:    */   
/*  35:    */   static <T> GeneralRange<T> all(Comparator<? super T> comparator)
/*  36:    */   {
/*  37: 64 */     return new GeneralRange(comparator, false, null, BoundType.OPEN, false, null, BoundType.OPEN);
/*  38:    */   }
/*  39:    */   
/*  40:    */   static <T> GeneralRange<T> downTo(Comparator<? super T> comparator, @Nullable T endpoint, BoundType boundType)
/*  41:    */   {
/*  42: 73 */     return new GeneralRange(comparator, true, endpoint, boundType, false, null, BoundType.OPEN);
/*  43:    */   }
/*  44:    */   
/*  45:    */   static <T> GeneralRange<T> upTo(Comparator<? super T> comparator, @Nullable T endpoint, BoundType boundType)
/*  46:    */   {
/*  47: 82 */     return new GeneralRange(comparator, false, null, BoundType.OPEN, true, endpoint, boundType);
/*  48:    */   }
/*  49:    */   
/*  50:    */   static <T> GeneralRange<T> range(Comparator<? super T> comparator, @Nullable T lower, BoundType lowerType, @Nullable T upper, BoundType upperType)
/*  51:    */   {
/*  52: 95 */     return new GeneralRange(comparator, true, lower, lowerType, true, upper, upperType);
/*  53:    */   }
/*  54:    */   
/*  55:    */   private GeneralRange(Comparator<? super T> comparator, boolean hasLowerBound, @Nullable T lowerEndpoint, BoundType lowerBoundType, boolean hasUpperBound, @Nullable T upperEndpoint, BoundType upperBoundType)
/*  56:    */   {
/*  57:114 */     this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/*  58:115 */     this.hasLowerBound = hasLowerBound;
/*  59:116 */     this.hasUpperBound = hasUpperBound;
/*  60:117 */     this.lowerEndpoint = lowerEndpoint;
/*  61:118 */     this.lowerBoundType = ((BoundType)Preconditions.checkNotNull(lowerBoundType));
/*  62:119 */     this.upperEndpoint = upperEndpoint;
/*  63:120 */     this.upperBoundType = ((BoundType)Preconditions.checkNotNull(upperBoundType));
/*  64:122 */     if (hasLowerBound) {
/*  65:123 */       comparator.compare(lowerEndpoint, lowerEndpoint);
/*  66:    */     }
/*  67:125 */     if (hasUpperBound) {
/*  68:126 */       comparator.compare(upperEndpoint, upperEndpoint);
/*  69:    */     }
/*  70:128 */     if ((hasLowerBound) && (hasUpperBound))
/*  71:    */     {
/*  72:129 */       int cmp = comparator.compare(lowerEndpoint, upperEndpoint);
/*  73:    */       
/*  74:131 */       Preconditions.checkArgument(cmp <= 0, "lowerEndpoint (%s) > upperEndpoint (%s)", new Object[] { lowerEndpoint, upperEndpoint });
/*  75:133 */       if (cmp == 0) {
/*  76:134 */         Preconditions.checkArgument((lowerBoundType != BoundType.OPEN ? 1 : 0) | (upperBoundType != BoundType.OPEN ? 1 : 0));
/*  77:    */       }
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   Comparator<? super T> comparator()
/*  82:    */   {
/*  83:140 */     return this.comparator;
/*  84:    */   }
/*  85:    */   
/*  86:    */   boolean hasLowerBound()
/*  87:    */   {
/*  88:144 */     return this.hasLowerBound;
/*  89:    */   }
/*  90:    */   
/*  91:    */   boolean hasUpperBound()
/*  92:    */   {
/*  93:148 */     return this.hasUpperBound;
/*  94:    */   }
/*  95:    */   
/*  96:    */   boolean isEmpty()
/*  97:    */   {
/*  98:152 */     return ((hasUpperBound()) && (tooLow(getUpperEndpoint()))) || ((hasLowerBound()) && (tooHigh(getLowerEndpoint())));
/*  99:    */   }
/* 100:    */   
/* 101:    */   boolean tooLow(@Nullable T t)
/* 102:    */   {
/* 103:157 */     if (!hasLowerBound()) {
/* 104:158 */       return false;
/* 105:    */     }
/* 106:160 */     T lbound = getLowerEndpoint();
/* 107:161 */     int cmp = this.comparator.compare(t, lbound);
/* 108:162 */     return (cmp < 0 ? 1 : 0) | (cmp == 0 ? 1 : 0) & (getLowerBoundType() == BoundType.OPEN ? 1 : 0);
/* 109:    */   }
/* 110:    */   
/* 111:    */   boolean tooHigh(@Nullable T t)
/* 112:    */   {
/* 113:166 */     if (!hasUpperBound()) {
/* 114:167 */       return false;
/* 115:    */     }
/* 116:169 */     T ubound = getUpperEndpoint();
/* 117:170 */     int cmp = this.comparator.compare(t, ubound);
/* 118:171 */     return (cmp > 0 ? 1 : 0) | (cmp == 0 ? 1 : 0) & (getUpperBoundType() == BoundType.OPEN ? 1 : 0);
/* 119:    */   }
/* 120:    */   
/* 121:    */   boolean contains(@Nullable T t)
/* 122:    */   {
/* 123:175 */     return (!tooLow(t)) && (!tooHigh(t));
/* 124:    */   }
/* 125:    */   
/* 126:    */   GeneralRange<T> intersect(GeneralRange<T> other)
/* 127:    */   {
/* 128:182 */     Preconditions.checkNotNull(other);
/* 129:183 */     Preconditions.checkArgument(this.comparator.equals(other.comparator));
/* 130:    */     
/* 131:185 */     boolean hasLowBound = this.hasLowerBound;
/* 132:186 */     T lowEnd = getLowerEndpoint();
/* 133:187 */     BoundType lowType = getLowerBoundType();
/* 134:188 */     if (!hasLowerBound())
/* 135:    */     {
/* 136:189 */       hasLowBound = other.hasLowerBound;
/* 137:190 */       lowEnd = other.getLowerEndpoint();
/* 138:191 */       lowType = other.getLowerBoundType();
/* 139:    */     }
/* 140:192 */     else if (other.hasLowerBound())
/* 141:    */     {
/* 142:193 */       int cmp = this.comparator.compare(getLowerEndpoint(), other.getLowerEndpoint());
/* 143:194 */       if ((cmp < 0) || ((cmp == 0) && (other.getLowerBoundType() == BoundType.OPEN)))
/* 144:    */       {
/* 145:195 */         lowEnd = other.getLowerEndpoint();
/* 146:196 */         lowType = other.getLowerBoundType();
/* 147:    */       }
/* 148:    */     }
/* 149:200 */     boolean hasUpBound = this.hasUpperBound;
/* 150:201 */     T upEnd = getUpperEndpoint();
/* 151:202 */     BoundType upType = getUpperBoundType();
/* 152:203 */     if (!hasUpperBound())
/* 153:    */     {
/* 154:204 */       hasUpBound = other.hasUpperBound;
/* 155:205 */       upEnd = other.getUpperEndpoint();
/* 156:206 */       upType = other.getUpperBoundType();
/* 157:    */     }
/* 158:207 */     else if (other.hasUpperBound())
/* 159:    */     {
/* 160:208 */       int cmp = this.comparator.compare(getUpperEndpoint(), other.getUpperEndpoint());
/* 161:209 */       if ((cmp > 0) || ((cmp == 0) && (other.getUpperBoundType() == BoundType.OPEN)))
/* 162:    */       {
/* 163:210 */         upEnd = other.getUpperEndpoint();
/* 164:211 */         upType = other.getUpperBoundType();
/* 165:    */       }
/* 166:    */     }
/* 167:215 */     if ((hasLowBound) && (hasUpBound))
/* 168:    */     {
/* 169:216 */       int cmp = this.comparator.compare(lowEnd, upEnd);
/* 170:217 */       if ((cmp > 0) || ((cmp == 0) && (lowType == BoundType.OPEN) && (upType == BoundType.OPEN)))
/* 171:    */       {
/* 172:219 */         lowEnd = upEnd;
/* 173:220 */         lowType = BoundType.OPEN;
/* 174:221 */         upType = BoundType.CLOSED;
/* 175:    */       }
/* 176:    */     }
/* 177:225 */     return new GeneralRange(this.comparator, hasLowBound, lowEnd, lowType, hasUpBound, upEnd, upType);
/* 178:    */   }
/* 179:    */   
/* 180:    */   public boolean equals(@Nullable Object obj)
/* 181:    */   {
/* 182:230 */     if ((obj instanceof GeneralRange))
/* 183:    */     {
/* 184:231 */       GeneralRange<?> r = (GeneralRange)obj;
/* 185:232 */       return (this.comparator.equals(r.comparator)) && (this.hasLowerBound == r.hasLowerBound) && (this.hasUpperBound == r.hasUpperBound) && (getLowerBoundType().equals(r.getLowerBoundType())) && (getUpperBoundType().equals(r.getUpperBoundType())) && (Objects.equal(getLowerEndpoint(), r.getLowerEndpoint())) && (Objects.equal(getUpperEndpoint(), r.getUpperEndpoint()));
/* 186:    */     }
/* 187:240 */     return false;
/* 188:    */   }
/* 189:    */   
/* 190:    */   public int hashCode()
/* 191:    */   {
/* 192:245 */     return Objects.hashCode(new Object[] { this.comparator, getLowerEndpoint(), getLowerBoundType(), getUpperEndpoint(), getUpperBoundType() });
/* 193:    */   }
/* 194:    */   
/* 195:    */   GeneralRange<T> reverse()
/* 196:    */   {
/* 197:259 */     GeneralRange<T> result = this.reverse;
/* 198:260 */     if (result == null)
/* 199:    */     {
/* 200:261 */       result = new GeneralRange(Ordering.from(this.comparator).reverse(), this.hasUpperBound, getUpperEndpoint(), getUpperBoundType(), this.hasLowerBound, getLowerEndpoint(), getLowerBoundType());
/* 201:    */       
/* 202:    */ 
/* 203:    */ 
/* 204:    */ 
/* 205:    */ 
/* 206:    */ 
/* 207:    */ 
/* 208:269 */       result.reverse = this;
/* 209:270 */       return this.reverse = result;
/* 210:    */     }
/* 211:272 */     return result;
/* 212:    */   }
/* 213:    */   
/* 214:    */   public String toString()
/* 215:    */   {
/* 216:277 */     return this.comparator + ":" + (this.lowerBoundType == BoundType.CLOSED ? '[' : '(') + (this.hasLowerBound ? this.lowerEndpoint : "-∞") + ',' + (this.hasUpperBound ? this.upperEndpoint : "∞") + (this.upperBoundType == BoundType.CLOSED ? ']' : ')');
/* 217:    */   }
/* 218:    */   
/* 219:    */   T getLowerEndpoint()
/* 220:    */   {
/* 221:289 */     return this.lowerEndpoint;
/* 222:    */   }
/* 223:    */   
/* 224:    */   BoundType getLowerBoundType()
/* 225:    */   {
/* 226:293 */     return this.lowerBoundType;
/* 227:    */   }
/* 228:    */   
/* 229:    */   T getUpperEndpoint()
/* 230:    */   {
/* 231:297 */     return this.upperEndpoint;
/* 232:    */   }
/* 233:    */   
/* 234:    */   BoundType getUpperBoundType()
/* 235:    */   {
/* 236:301 */     return this.upperBoundType;
/* 237:    */   }
/* 238:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.GeneralRange
 * JD-Core Version:    0.7.0.1
 */