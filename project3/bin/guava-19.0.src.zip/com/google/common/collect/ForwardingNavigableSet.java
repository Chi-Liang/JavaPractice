/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import java.util.Iterator;
/*   5:    */ import java.util.NavigableSet;
/*   6:    */ import java.util.SortedSet;
/*   7:    */ 
/*   8:    */ public abstract class ForwardingNavigableSet<E>
/*   9:    */   extends ForwardingSortedSet<E>
/*  10:    */   implements NavigableSet<E>
/*  11:    */ {
/*  12:    */   protected abstract NavigableSet<E> delegate();
/*  13:    */   
/*  14:    */   public E lower(E e)
/*  15:    */   {
/*  16: 58 */     return delegate().lower(e);
/*  17:    */   }
/*  18:    */   
/*  19:    */   protected E standardLower(E e)
/*  20:    */   {
/*  21: 67 */     return Iterators.getNext(headSet(e, false).descendingIterator(), null);
/*  22:    */   }
/*  23:    */   
/*  24:    */   public E floor(E e)
/*  25:    */   {
/*  26: 72 */     return delegate().floor(e);
/*  27:    */   }
/*  28:    */   
/*  29:    */   protected E standardFloor(E e)
/*  30:    */   {
/*  31: 81 */     return Iterators.getNext(headSet(e, true).descendingIterator(), null);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public E ceiling(E e)
/*  35:    */   {
/*  36: 86 */     return delegate().ceiling(e);
/*  37:    */   }
/*  38:    */   
/*  39:    */   protected E standardCeiling(E e)
/*  40:    */   {
/*  41: 95 */     return Iterators.getNext(tailSet(e, true).iterator(), null);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public E higher(E e)
/*  45:    */   {
/*  46:100 */     return delegate().higher(e);
/*  47:    */   }
/*  48:    */   
/*  49:    */   protected E standardHigher(E e)
/*  50:    */   {
/*  51:109 */     return Iterators.getNext(tailSet(e, false).iterator(), null);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public E pollFirst()
/*  55:    */   {
/*  56:114 */     return delegate().pollFirst();
/*  57:    */   }
/*  58:    */   
/*  59:    */   protected E standardPollFirst()
/*  60:    */   {
/*  61:123 */     return Iterators.pollNext(iterator());
/*  62:    */   }
/*  63:    */   
/*  64:    */   public E pollLast()
/*  65:    */   {
/*  66:128 */     return delegate().pollLast();
/*  67:    */   }
/*  68:    */   
/*  69:    */   protected E standardPollLast()
/*  70:    */   {
/*  71:137 */     return Iterators.pollNext(descendingIterator());
/*  72:    */   }
/*  73:    */   
/*  74:    */   protected E standardFirst()
/*  75:    */   {
/*  76:141 */     return iterator().next();
/*  77:    */   }
/*  78:    */   
/*  79:    */   protected E standardLast()
/*  80:    */   {
/*  81:145 */     return descendingIterator().next();
/*  82:    */   }
/*  83:    */   
/*  84:    */   public NavigableSet<E> descendingSet()
/*  85:    */   {
/*  86:150 */     return delegate().descendingSet();
/*  87:    */   }
/*  88:    */   
/*  89:    */   @Beta
/*  90:    */   protected class StandardDescendingSet
/*  91:    */     extends Sets.DescendingSet<E>
/*  92:    */   {
/*  93:    */     public StandardDescendingSet()
/*  94:    */     {
/*  95:166 */       super();
/*  96:    */     }
/*  97:    */   }
/*  98:    */   
/*  99:    */   public Iterator<E> descendingIterator()
/* 100:    */   {
/* 101:172 */     return delegate().descendingIterator();
/* 102:    */   }
/* 103:    */   
/* 104:    */   public NavigableSet<E> subSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 105:    */   {
/* 106:178 */     return delegate().subSet(fromElement, fromInclusive, toElement, toInclusive);
/* 107:    */   }
/* 108:    */   
/* 109:    */   @Beta
/* 110:    */   protected NavigableSet<E> standardSubSet(E fromElement, boolean fromInclusive, E toElement, boolean toInclusive)
/* 111:    */   {
/* 112:189 */     return tailSet(fromElement, fromInclusive).headSet(toElement, toInclusive);
/* 113:    */   }
/* 114:    */   
/* 115:    */   protected SortedSet<E> standardSubSet(E fromElement, E toElement)
/* 116:    */   {
/* 117:200 */     return subSet(fromElement, true, toElement, false);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public NavigableSet<E> headSet(E toElement, boolean inclusive)
/* 121:    */   {
/* 122:205 */     return delegate().headSet(toElement, inclusive);
/* 123:    */   }
/* 124:    */   
/* 125:    */   protected SortedSet<E> standardHeadSet(E toElement)
/* 126:    */   {
/* 127:215 */     return headSet(toElement, false);
/* 128:    */   }
/* 129:    */   
/* 130:    */   public NavigableSet<E> tailSet(E fromElement, boolean inclusive)
/* 131:    */   {
/* 132:220 */     return delegate().tailSet(fromElement, inclusive);
/* 133:    */   }
/* 134:    */   
/* 135:    */   protected SortedSet<E> standardTailSet(E fromElement)
/* 136:    */   {
/* 137:230 */     return tailSet(fromElement, true);
/* 138:    */   }
/* 139:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingNavigableSet
 * JD-Core Version:    0.7.0.1
 */