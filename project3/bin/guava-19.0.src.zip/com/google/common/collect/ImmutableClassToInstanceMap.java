/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.primitives.Primitives;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Map;
/*   7:    */ import java.util.Map.Entry;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ public final class ImmutableClassToInstanceMap<B>
/*  11:    */   extends ForwardingMap<Class<? extends B>, B>
/*  12:    */   implements ClassToInstanceMap<B>, Serializable
/*  13:    */ {
/*  14: 38 */   private static final ImmutableClassToInstanceMap<Object> EMPTY = new ImmutableClassToInstanceMap(ImmutableMap.of());
/*  15:    */   private final ImmutableMap<Class<? extends B>, B> delegate;
/*  16:    */   
/*  17:    */   public static <B> ImmutableClassToInstanceMap<B> of()
/*  18:    */   {
/*  19: 48 */     return EMPTY;
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static <B, T extends B> ImmutableClassToInstanceMap<B> of(Class<T> type, T value)
/*  23:    */   {
/*  24: 57 */     ImmutableMap<Class<? extends B>, B> map = ImmutableMap.of(type, value);
/*  25: 58 */     return new ImmutableClassToInstanceMap(map);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <B> Builder<B> builder()
/*  29:    */   {
/*  30: 66 */     return new Builder();
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static final class Builder<B>
/*  34:    */   {
/*  35: 87 */     private final ImmutableMap.Builder<Class<? extends B>, B> mapBuilder = ImmutableMap.builder();
/*  36:    */     
/*  37:    */     public <T extends B> Builder<B> put(Class<T> key, T value)
/*  38:    */     {
/*  39: 94 */       this.mapBuilder.put(key, value);
/*  40: 95 */       return this;
/*  41:    */     }
/*  42:    */     
/*  43:    */     public <T extends B> Builder<B> putAll(Map<? extends Class<? extends T>, ? extends T> map)
/*  44:    */     {
/*  45:107 */       for (Map.Entry<? extends Class<? extends T>, ? extends T> entry : map.entrySet())
/*  46:    */       {
/*  47:108 */         Class<? extends T> type = (Class)entry.getKey();
/*  48:109 */         T value = entry.getValue();
/*  49:110 */         this.mapBuilder.put(type, cast(type, value));
/*  50:    */       }
/*  51:112 */       return this;
/*  52:    */     }
/*  53:    */     
/*  54:    */     private static <B, T extends B> T cast(Class<T> type, B value)
/*  55:    */     {
/*  56:116 */       return Primitives.wrap(type).cast(value);
/*  57:    */     }
/*  58:    */     
/*  59:    */     public ImmutableClassToInstanceMap<B> build()
/*  60:    */     {
/*  61:126 */       ImmutableMap<Class<? extends B>, B> map = this.mapBuilder.build();
/*  62:127 */       if (map.isEmpty()) {
/*  63:128 */         return ImmutableClassToInstanceMap.of();
/*  64:    */       }
/*  65:130 */       return new ImmutableClassToInstanceMap(map, null);
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static <B, S extends B> ImmutableClassToInstanceMap<B> copyOf(Map<? extends Class<? extends S>, ? extends S> map)
/*  70:    */   {
/*  71:150 */     if ((map instanceof ImmutableClassToInstanceMap))
/*  72:    */     {
/*  73:153 */       ImmutableClassToInstanceMap<B> cast = (ImmutableClassToInstanceMap)map;
/*  74:154 */       return cast;
/*  75:    */     }
/*  76:156 */     return new Builder().putAll(map).build();
/*  77:    */   }
/*  78:    */   
/*  79:    */   private ImmutableClassToInstanceMap(ImmutableMap<Class<? extends B>, B> delegate)
/*  80:    */   {
/*  81:162 */     this.delegate = delegate;
/*  82:    */   }
/*  83:    */   
/*  84:    */   protected Map<Class<? extends B>, B> delegate()
/*  85:    */   {
/*  86:167 */     return this.delegate;
/*  87:    */   }
/*  88:    */   
/*  89:    */   @Nullable
/*  90:    */   public <T extends B> T getInstance(Class<T> type)
/*  91:    */   {
/*  92:174 */     return this.delegate.get(Preconditions.checkNotNull(type));
/*  93:    */   }
/*  94:    */   
/*  95:    */   @Deprecated
/*  96:    */   public <T extends B> T putInstance(Class<T> type, T value)
/*  97:    */   {
/*  98:186 */     throw new UnsupportedOperationException();
/*  99:    */   }
/* 100:    */   
/* 101:    */   Object readResolve()
/* 102:    */   {
/* 103:190 */     return isEmpty() ? of() : this;
/* 104:    */   }
/* 105:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableClassToInstanceMap
 * JD-Core Version:    0.7.0.1
 */