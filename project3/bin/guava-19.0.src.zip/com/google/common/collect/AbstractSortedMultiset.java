/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.Comparator;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.NavigableSet;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ abstract class AbstractSortedMultiset<E>
/*  12:    */   extends AbstractMultiset<E>
/*  13:    */   implements SortedMultiset<E>
/*  14:    */ {
/*  15:    */   @GwtTransient
/*  16:    */   final Comparator<? super E> comparator;
/*  17:    */   private transient SortedMultiset<E> descendingMultiset;
/*  18:    */   
/*  19:    */   AbstractSortedMultiset()
/*  20:    */   {
/*  21: 44 */     this(Ordering.natural());
/*  22:    */   }
/*  23:    */   
/*  24:    */   AbstractSortedMultiset(Comparator<? super E> comparator)
/*  25:    */   {
/*  26: 48 */     this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/*  27:    */   }
/*  28:    */   
/*  29:    */   public NavigableSet<E> elementSet()
/*  30:    */   {
/*  31: 53 */     return (NavigableSet)super.elementSet();
/*  32:    */   }
/*  33:    */   
/*  34:    */   NavigableSet<E> createElementSet()
/*  35:    */   {
/*  36: 58 */     return new SortedMultisets.NavigableElementSet(this);
/*  37:    */   }
/*  38:    */   
/*  39:    */   public Comparator<? super E> comparator()
/*  40:    */   {
/*  41: 63 */     return this.comparator;
/*  42:    */   }
/*  43:    */   
/*  44:    */   public Multiset.Entry<E> firstEntry()
/*  45:    */   {
/*  46: 68 */     Iterator<Multiset.Entry<E>> entryIterator = entryIterator();
/*  47: 69 */     return entryIterator.hasNext() ? (Multiset.Entry)entryIterator.next() : null;
/*  48:    */   }
/*  49:    */   
/*  50:    */   public Multiset.Entry<E> lastEntry()
/*  51:    */   {
/*  52: 74 */     Iterator<Multiset.Entry<E>> entryIterator = descendingEntryIterator();
/*  53: 75 */     return entryIterator.hasNext() ? (Multiset.Entry)entryIterator.next() : null;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Multiset.Entry<E> pollFirstEntry()
/*  57:    */   {
/*  58: 80 */     Iterator<Multiset.Entry<E>> entryIterator = entryIterator();
/*  59: 81 */     if (entryIterator.hasNext())
/*  60:    */     {
/*  61: 82 */       Multiset.Entry<E> result = (Multiset.Entry)entryIterator.next();
/*  62: 83 */       result = Multisets.immutableEntry(result.getElement(), result.getCount());
/*  63: 84 */       entryIterator.remove();
/*  64: 85 */       return result;
/*  65:    */     }
/*  66: 87 */     return null;
/*  67:    */   }
/*  68:    */   
/*  69:    */   public Multiset.Entry<E> pollLastEntry()
/*  70:    */   {
/*  71: 92 */     Iterator<Multiset.Entry<E>> entryIterator = descendingEntryIterator();
/*  72: 93 */     if (entryIterator.hasNext())
/*  73:    */     {
/*  74: 94 */       Multiset.Entry<E> result = (Multiset.Entry)entryIterator.next();
/*  75: 95 */       result = Multisets.immutableEntry(result.getElement(), result.getCount());
/*  76: 96 */       entryIterator.remove();
/*  77: 97 */       return result;
/*  78:    */     }
/*  79: 99 */     return null;
/*  80:    */   }
/*  81:    */   
/*  82:    */   public SortedMultiset<E> subMultiset(@Nullable E fromElement, BoundType fromBoundType, @Nullable E toElement, BoundType toBoundType)
/*  83:    */   {
/*  84:109 */     Preconditions.checkNotNull(fromBoundType);
/*  85:110 */     Preconditions.checkNotNull(toBoundType);
/*  86:111 */     return tailMultiset(fromElement, fromBoundType).headMultiset(toElement, toBoundType);
/*  87:    */   }
/*  88:    */   
/*  89:    */   abstract Iterator<Multiset.Entry<E>> descendingEntryIterator();
/*  90:    */   
/*  91:    */   Iterator<E> descendingIterator()
/*  92:    */   {
/*  93:117 */     return Multisets.iteratorImpl(descendingMultiset());
/*  94:    */   }
/*  95:    */   
/*  96:    */   public SortedMultiset<E> descendingMultiset()
/*  97:    */   {
/*  98:124 */     SortedMultiset<E> result = this.descendingMultiset;
/*  99:125 */     return result == null ? (this.descendingMultiset = createDescendingMultiset()) : result;
/* 100:    */   }
/* 101:    */   
/* 102:    */   SortedMultiset<E> createDescendingMultiset()
/* 103:    */   {
/* 104:146 */     new DescendingMultiset()
/* 105:    */     {
/* 106:    */       SortedMultiset<E> forwardMultiset()
/* 107:    */       {
/* 108:133 */         return AbstractSortedMultiset.this;
/* 109:    */       }
/* 110:    */       
/* 111:    */       Iterator<Multiset.Entry<E>> entryIterator()
/* 112:    */       {
/* 113:138 */         return AbstractSortedMultiset.this.descendingEntryIterator();
/* 114:    */       }
/* 115:    */       
/* 116:    */       public Iterator<E> iterator()
/* 117:    */       {
/* 118:143 */         return AbstractSortedMultiset.this.descendingIterator();
/* 119:    */       }
/* 120:    */     };
/* 121:    */   }
/* 122:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.AbstractSortedMultiset
 * JD-Core Version:    0.7.0.1
 */