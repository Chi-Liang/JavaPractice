/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Supplier;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.HashMap;
/*   7:    */ import java.util.Map;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true)
/*  11:    */ public class HashBasedTable<R, C, V>
/*  12:    */   extends StandardTable<R, C, V>
/*  13:    */ {
/*  14:    */   private static final long serialVersionUID = 0L;
/*  15:    */   
/*  16:    */   private static class Factory<C, V>
/*  17:    */     implements Supplier<Map<C, V>>, Serializable
/*  18:    */   {
/*  19:    */     final int expectedSize;
/*  20:    */     private static final long serialVersionUID = 0L;
/*  21:    */     
/*  22:    */     Factory(int expectedSize)
/*  23:    */     {
/*  24: 61 */       this.expectedSize = expectedSize;
/*  25:    */     }
/*  26:    */     
/*  27:    */     public Map<C, V> get()
/*  28:    */     {
/*  29: 66 */       return Maps.newHashMapWithExpectedSize(this.expectedSize);
/*  30:    */     }
/*  31:    */   }
/*  32:    */   
/*  33:    */   public static <R, C, V> HashBasedTable<R, C, V> create()
/*  34:    */   {
/*  35: 76 */     return new HashBasedTable(new HashMap(), new Factory(0));
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <R, C, V> HashBasedTable<R, C, V> create(int expectedRows, int expectedCellsPerRow)
/*  39:    */   {
/*  40: 90 */     CollectPreconditions.checkNonnegative(expectedCellsPerRow, "expectedCellsPerRow");
/*  41: 91 */     Map<R, Map<C, V>> backingMap = Maps.newHashMapWithExpectedSize(expectedRows);
/*  42: 92 */     return new HashBasedTable(backingMap, new Factory(expectedCellsPerRow));
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static <R, C, V> HashBasedTable<R, C, V> create(Table<? extends R, ? extends C, ? extends V> table)
/*  46:    */   {
/*  47:105 */     HashBasedTable<R, C, V> result = create();
/*  48:106 */     result.putAll(table);
/*  49:107 */     return result;
/*  50:    */   }
/*  51:    */   
/*  52:    */   HashBasedTable(Map<R, Map<C, V>> backingMap, Factory<C, V> factory)
/*  53:    */   {
/*  54:111 */     super(backingMap, factory);
/*  55:    */   }
/*  56:    */   
/*  57:    */   public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/*  58:    */   {
/*  59:118 */     return super.contains(rowKey, columnKey);
/*  60:    */   }
/*  61:    */   
/*  62:    */   public boolean containsColumn(@Nullable Object columnKey)
/*  63:    */   {
/*  64:123 */     return super.containsColumn(columnKey);
/*  65:    */   }
/*  66:    */   
/*  67:    */   public boolean containsRow(@Nullable Object rowKey)
/*  68:    */   {
/*  69:128 */     return super.containsRow(rowKey);
/*  70:    */   }
/*  71:    */   
/*  72:    */   public boolean containsValue(@Nullable Object value)
/*  73:    */   {
/*  74:133 */     return super.containsValue(value);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/*  78:    */   {
/*  79:138 */     return super.get(rowKey, columnKey);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public boolean equals(@Nullable Object obj)
/*  83:    */   {
/*  84:143 */     return super.equals(obj);
/*  85:    */   }
/*  86:    */   
/*  87:    */   public V remove(@Nullable Object rowKey, @Nullable Object columnKey)
/*  88:    */   {
/*  89:148 */     return super.remove(rowKey, columnKey);
/*  90:    */   }
/*  91:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.HashBasedTable
 * JD-Core Version:    0.7.0.1
 */