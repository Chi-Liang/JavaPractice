/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.MoreObjects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import java.util.Collection;
/*   9:    */ import java.util.Comparator;
/*  10:    */ import java.util.Iterator;
/*  11:    */ import java.util.Map.Entry;
/*  12:    */ import java.util.NavigableMap;
/*  13:    */ import java.util.NoSuchElementException;
/*  14:    */ import java.util.Set;
/*  15:    */ import java.util.SortedMap;
/*  16:    */ import java.util.TreeMap;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @Beta
/*  20:    */ @GwtIncompatible("uses NavigableMap")
/*  21:    */ public class TreeRangeSet<C extends Comparable<?>>
/*  22:    */   extends AbstractRangeSet<C>
/*  23:    */ {
/*  24:    */   @VisibleForTesting
/*  25:    */   final NavigableMap<Cut<C>, Range<C>> rangesByLowerBound;
/*  26:    */   private transient Set<Range<C>> asRanges;
/*  27:    */   private transient Set<Range<C>> asDescendingSetOfRanges;
/*  28:    */   private transient RangeSet<C> complement;
/*  29:    */   
/*  30:    */   public static <C extends Comparable<?>> TreeRangeSet<C> create()
/*  31:    */   {
/*  32: 52 */     return new TreeRangeSet(new TreeMap());
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <C extends Comparable<?>> TreeRangeSet<C> create(RangeSet<C> rangeSet)
/*  36:    */   {
/*  37: 59 */     TreeRangeSet<C> result = create();
/*  38: 60 */     result.addAll(rangeSet);
/*  39: 61 */     return result;
/*  40:    */   }
/*  41:    */   
/*  42:    */   private TreeRangeSet(NavigableMap<Cut<C>, Range<C>> rangesByLowerCut)
/*  43:    */   {
/*  44: 65 */     this.rangesByLowerBound = rangesByLowerCut;
/*  45:    */   }
/*  46:    */   
/*  47:    */   public Set<Range<C>> asRanges()
/*  48:    */   {
/*  49: 73 */     Set<Range<C>> result = this.asRanges;
/*  50: 74 */     return result == null ? (this.asRanges = new AsRanges(this.rangesByLowerBound.values())) : result;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Set<Range<C>> asDescendingSetOfRanges()
/*  54:    */   {
/*  55: 79 */     Set<Range<C>> result = this.asDescendingSetOfRanges;
/*  56: 80 */     return result == null ? (this.asDescendingSetOfRanges = new AsRanges(this.rangesByLowerBound.descendingMap().values())) : result;
/*  57:    */   }
/*  58:    */   
/*  59:    */   final class AsRanges
/*  60:    */     extends ForwardingCollection<Range<C>>
/*  61:    */     implements Set<Range<C>>
/*  62:    */   {
/*  63:    */     final Collection<Range<C>> delegate;
/*  64:    */     
/*  65:    */     AsRanges()
/*  66:    */     {
/*  67: 90 */       this.delegate = delegate;
/*  68:    */     }
/*  69:    */     
/*  70:    */     protected Collection<Range<C>> delegate()
/*  71:    */     {
/*  72: 95 */       return this.delegate;
/*  73:    */     }
/*  74:    */     
/*  75:    */     public int hashCode()
/*  76:    */     {
/*  77:100 */       return Sets.hashCodeImpl(this);
/*  78:    */     }
/*  79:    */     
/*  80:    */     public boolean equals(@Nullable Object o)
/*  81:    */     {
/*  82:105 */       return Sets.equalsImpl(this, o);
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   @Nullable
/*  87:    */   public Range<C> rangeContaining(C value)
/*  88:    */   {
/*  89:112 */     Preconditions.checkNotNull(value);
/*  90:113 */     Map.Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(Cut.belowValue(value));
/*  91:114 */     if ((floorEntry != null) && (((Range)floorEntry.getValue()).contains(value))) {
/*  92:115 */       return (Range)floorEntry.getValue();
/*  93:    */     }
/*  94:118 */     return null;
/*  95:    */   }
/*  96:    */   
/*  97:    */   public boolean encloses(Range<C> range)
/*  98:    */   {
/*  99:124 */     Preconditions.checkNotNull(range);
/* 100:125 */     Map.Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(range.lowerBound);
/* 101:126 */     return (floorEntry != null) && (((Range)floorEntry.getValue()).encloses(range));
/* 102:    */   }
/* 103:    */   
/* 104:    */   @Nullable
/* 105:    */   private Range<C> rangeEnclosing(Range<C> range)
/* 106:    */   {
/* 107:131 */     Preconditions.checkNotNull(range);
/* 108:132 */     Map.Entry<Cut<C>, Range<C>> floorEntry = this.rangesByLowerBound.floorEntry(range.lowerBound);
/* 109:133 */     return (floorEntry != null) && (((Range)floorEntry.getValue()).encloses(range)) ? (Range)floorEntry.getValue() : null;
/* 110:    */   }
/* 111:    */   
/* 112:    */   public Range<C> span()
/* 113:    */   {
/* 114:140 */     Map.Entry<Cut<C>, Range<C>> firstEntry = this.rangesByLowerBound.firstEntry();
/* 115:141 */     Map.Entry<Cut<C>, Range<C>> lastEntry = this.rangesByLowerBound.lastEntry();
/* 116:142 */     if (firstEntry == null) {
/* 117:143 */       throw new NoSuchElementException();
/* 118:    */     }
/* 119:145 */     return Range.create(((Range)firstEntry.getValue()).lowerBound, ((Range)lastEntry.getValue()).upperBound);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public void add(Range<C> rangeToAdd)
/* 123:    */   {
/* 124:150 */     Preconditions.checkNotNull(rangeToAdd);
/* 125:152 */     if (rangeToAdd.isEmpty()) {
/* 126:153 */       return;
/* 127:    */     }
/* 128:158 */     Cut<C> lbToAdd = rangeToAdd.lowerBound;
/* 129:159 */     Cut<C> ubToAdd = rangeToAdd.upperBound;
/* 130:    */     
/* 131:161 */     Map.Entry<Cut<C>, Range<C>> entryBelowLB = this.rangesByLowerBound.lowerEntry(lbToAdd);
/* 132:162 */     if (entryBelowLB != null)
/* 133:    */     {
/* 134:164 */       Range<C> rangeBelowLB = (Range)entryBelowLB.getValue();
/* 135:165 */       if (rangeBelowLB.upperBound.compareTo(lbToAdd) >= 0)
/* 136:    */       {
/* 137:167 */         if (rangeBelowLB.upperBound.compareTo(ubToAdd) >= 0) {
/* 138:169 */           ubToAdd = rangeBelowLB.upperBound;
/* 139:    */         }
/* 140:175 */         lbToAdd = rangeBelowLB.lowerBound;
/* 141:    */       }
/* 142:    */     }
/* 143:179 */     Map.Entry<Cut<C>, Range<C>> entryBelowUB = this.rangesByLowerBound.floorEntry(ubToAdd);
/* 144:180 */     if (entryBelowUB != null)
/* 145:    */     {
/* 146:182 */       Range<C> rangeBelowUB = (Range)entryBelowUB.getValue();
/* 147:183 */       if (rangeBelowUB.upperBound.compareTo(ubToAdd) >= 0) {
/* 148:185 */         ubToAdd = rangeBelowUB.upperBound;
/* 149:    */       }
/* 150:    */     }
/* 151:190 */     this.rangesByLowerBound.subMap(lbToAdd, ubToAdd).clear();
/* 152:    */     
/* 153:192 */     replaceRangeWithSameLowerBound(Range.create(lbToAdd, ubToAdd));
/* 154:    */   }
/* 155:    */   
/* 156:    */   public void remove(Range<C> rangeToRemove)
/* 157:    */   {
/* 158:197 */     Preconditions.checkNotNull(rangeToRemove);
/* 159:199 */     if (rangeToRemove.isEmpty()) {
/* 160:200 */       return;
/* 161:    */     }
/* 162:206 */     Map.Entry<Cut<C>, Range<C>> entryBelowLB = this.rangesByLowerBound.lowerEntry(rangeToRemove.lowerBound);
/* 163:207 */     if (entryBelowLB != null)
/* 164:    */     {
/* 165:209 */       Range<C> rangeBelowLB = (Range)entryBelowLB.getValue();
/* 166:210 */       if (rangeBelowLB.upperBound.compareTo(rangeToRemove.lowerBound) >= 0)
/* 167:    */       {
/* 168:212 */         if ((rangeToRemove.hasUpperBound()) && (rangeBelowLB.upperBound.compareTo(rangeToRemove.upperBound) >= 0)) {
/* 169:215 */           replaceRangeWithSameLowerBound(Range.create(rangeToRemove.upperBound, rangeBelowLB.upperBound));
/* 170:    */         }
/* 171:218 */         replaceRangeWithSameLowerBound(Range.create(rangeBelowLB.lowerBound, rangeToRemove.lowerBound));
/* 172:    */       }
/* 173:    */     }
/* 174:223 */     Map.Entry<Cut<C>, Range<C>> entryBelowUB = this.rangesByLowerBound.floorEntry(rangeToRemove.upperBound);
/* 175:224 */     if (entryBelowUB != null)
/* 176:    */     {
/* 177:226 */       Range<C> rangeBelowUB = (Range)entryBelowUB.getValue();
/* 178:227 */       if ((rangeToRemove.hasUpperBound()) && (rangeBelowUB.upperBound.compareTo(rangeToRemove.upperBound) >= 0)) {
/* 179:230 */         replaceRangeWithSameLowerBound(Range.create(rangeToRemove.upperBound, rangeBelowUB.upperBound));
/* 180:    */       }
/* 181:    */     }
/* 182:235 */     this.rangesByLowerBound.subMap(rangeToRemove.lowerBound, rangeToRemove.upperBound).clear();
/* 183:    */   }
/* 184:    */   
/* 185:    */   private void replaceRangeWithSameLowerBound(Range<C> range)
/* 186:    */   {
/* 187:239 */     if (range.isEmpty()) {
/* 188:240 */       this.rangesByLowerBound.remove(range.lowerBound);
/* 189:    */     } else {
/* 190:242 */       this.rangesByLowerBound.put(range.lowerBound, range);
/* 191:    */     }
/* 192:    */   }
/* 193:    */   
/* 194:    */   public RangeSet<C> complement()
/* 195:    */   {
/* 196:250 */     RangeSet<C> result = this.complement;
/* 197:251 */     return result == null ? (this.complement = new Complement()) : result;
/* 198:    */   }
/* 199:    */   
/* 200:    */   @VisibleForTesting
/* 201:    */   static final class RangesByUpperBound<C extends Comparable<?>>
/* 202:    */     extends AbstractNavigableMap<Cut<C>, Range<C>>
/* 203:    */   {
/* 204:    */     private final NavigableMap<Cut<C>, Range<C>> rangesByLowerBound;
/* 205:    */     private final Range<Cut<C>> upperBoundWindow;
/* 206:    */     
/* 207:    */     RangesByUpperBound(NavigableMap<Cut<C>, Range<C>> rangesByLowerBound)
/* 208:    */     {
/* 209:266 */       this.rangesByLowerBound = rangesByLowerBound;
/* 210:267 */       this.upperBoundWindow = Range.all();
/* 211:    */     }
/* 212:    */     
/* 213:    */     private RangesByUpperBound(NavigableMap<Cut<C>, Range<C>> rangesByLowerBound, Range<Cut<C>> upperBoundWindow)
/* 214:    */     {
/* 215:272 */       this.rangesByLowerBound = rangesByLowerBound;
/* 216:273 */       this.upperBoundWindow = upperBoundWindow;
/* 217:    */     }
/* 218:    */     
/* 219:    */     private NavigableMap<Cut<C>, Range<C>> subMap(Range<Cut<C>> window)
/* 220:    */     {
/* 221:277 */       if (window.isConnected(this.upperBoundWindow)) {
/* 222:278 */         return new RangesByUpperBound(this.rangesByLowerBound, window.intersection(this.upperBoundWindow));
/* 223:    */       }
/* 224:280 */       return ImmutableSortedMap.of();
/* 225:    */     }
/* 226:    */     
/* 227:    */     public NavigableMap<Cut<C>, Range<C>> subMap(Cut<C> fromKey, boolean fromInclusive, Cut<C> toKey, boolean toInclusive)
/* 228:    */     {
/* 229:287 */       return subMap(Range.range(fromKey, BoundType.forBoolean(fromInclusive), toKey, BoundType.forBoolean(toInclusive)));
/* 230:    */     }
/* 231:    */     
/* 232:    */     public NavigableMap<Cut<C>, Range<C>> headMap(Cut<C> toKey, boolean inclusive)
/* 233:    */     {
/* 234:295 */       return subMap(Range.upTo(toKey, BoundType.forBoolean(inclusive)));
/* 235:    */     }
/* 236:    */     
/* 237:    */     public NavigableMap<Cut<C>, Range<C>> tailMap(Cut<C> fromKey, boolean inclusive)
/* 238:    */     {
/* 239:300 */       return subMap(Range.downTo(fromKey, BoundType.forBoolean(inclusive)));
/* 240:    */     }
/* 241:    */     
/* 242:    */     public Comparator<? super Cut<C>> comparator()
/* 243:    */     {
/* 244:305 */       return Ordering.natural();
/* 245:    */     }
/* 246:    */     
/* 247:    */     public boolean containsKey(@Nullable Object key)
/* 248:    */     {
/* 249:310 */       return get(key) != null;
/* 250:    */     }
/* 251:    */     
/* 252:    */     public Range<C> get(@Nullable Object key)
/* 253:    */     {
/* 254:315 */       if ((key instanceof Cut)) {
/* 255:    */         try
/* 256:    */         {
/* 257:318 */           Cut<C> cut = (Cut)key;
/* 258:319 */           if (!this.upperBoundWindow.contains(cut)) {
/* 259:320 */             return null;
/* 260:    */           }
/* 261:322 */           Map.Entry<Cut<C>, Range<C>> candidate = this.rangesByLowerBound.lowerEntry(cut);
/* 262:323 */           if ((candidate != null) && (((Range)candidate.getValue()).upperBound.equals(cut))) {
/* 263:324 */             return (Range)candidate.getValue();
/* 264:    */           }
/* 265:    */         }
/* 266:    */         catch (ClassCastException e)
/* 267:    */         {
/* 268:327 */           return null;
/* 269:    */         }
/* 270:    */       }
/* 271:330 */       return null;
/* 272:    */     }
/* 273:    */     
/* 274:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> entryIterator()
/* 275:    */     {
/* 276:    */       Iterator<Range<C>> backingItr;
/* 277:    */       final Iterator<Range<C>> backingItr;
/* 278:340 */       if (!this.upperBoundWindow.hasLowerBound())
/* 279:    */       {
/* 280:341 */         backingItr = this.rangesByLowerBound.values().iterator();
/* 281:    */       }
/* 282:    */       else
/* 283:    */       {
/* 284:343 */         Map.Entry<Cut<C>, Range<C>> lowerEntry = this.rangesByLowerBound.lowerEntry(this.upperBoundWindow.lowerEndpoint());
/* 285:    */         Iterator<Range<C>> backingItr;
/* 286:345 */         if (lowerEntry == null)
/* 287:    */         {
/* 288:346 */           backingItr = this.rangesByLowerBound.values().iterator();
/* 289:    */         }
/* 290:    */         else
/* 291:    */         {
/* 292:    */           Iterator<Range<C>> backingItr;
/* 293:347 */           if (this.upperBoundWindow.lowerBound.isLessThan(((Range)lowerEntry.getValue()).upperBound)) {
/* 294:348 */             backingItr = this.rangesByLowerBound.tailMap(lowerEntry.getKey(), true).values().iterator();
/* 295:    */           } else {
/* 296:350 */             backingItr = this.rangesByLowerBound.tailMap(this.upperBoundWindow.lowerEndpoint(), true).values().iterator();
/* 297:    */           }
/* 298:    */         }
/* 299:    */       }
/* 300:356 */       new AbstractIterator()
/* 301:    */       {
/* 302:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 303:    */         {
/* 304:359 */           if (!backingItr.hasNext()) {
/* 305:360 */             return (Map.Entry)endOfData();
/* 306:    */           }
/* 307:362 */           Range<C> range = (Range)backingItr.next();
/* 308:363 */           if (TreeRangeSet.RangesByUpperBound.this.upperBoundWindow.upperBound.isLessThan(range.upperBound)) {
/* 309:364 */             return (Map.Entry)endOfData();
/* 310:    */           }
/* 311:366 */           return Maps.immutableEntry(range.upperBound, range);
/* 312:    */         }
/* 313:    */       };
/* 314:    */     }
/* 315:    */     
/* 316:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> descendingEntryIterator()
/* 317:    */     {
/* 318:    */       Collection<Range<C>> candidates;
/* 319:    */       Collection<Range<C>> candidates;
/* 320:375 */       if (this.upperBoundWindow.hasUpperBound()) {
/* 321:376 */         candidates = this.rangesByLowerBound.headMap(this.upperBoundWindow.upperEndpoint(), false).descendingMap().values();
/* 322:    */       } else {
/* 323:382 */         candidates = this.rangesByLowerBound.descendingMap().values();
/* 324:    */       }
/* 325:384 */       final PeekingIterator<Range<C>> backingItr = Iterators.peekingIterator(candidates.iterator());
/* 326:385 */       if ((backingItr.hasNext()) && (this.upperBoundWindow.upperBound.isLessThan(((Range)backingItr.peek()).upperBound))) {
/* 327:387 */         backingItr.next();
/* 328:    */       }
/* 329:389 */       new AbstractIterator()
/* 330:    */       {
/* 331:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 332:    */         {
/* 333:392 */           if (!backingItr.hasNext()) {
/* 334:393 */             return (Map.Entry)endOfData();
/* 335:    */           }
/* 336:395 */           Range<C> range = (Range)backingItr.next();
/* 337:396 */           return TreeRangeSet.RangesByUpperBound.this.upperBoundWindow.lowerBound.isLessThan(range.upperBound) ? Maps.immutableEntry(range.upperBound, range) : (Map.Entry)endOfData();
/* 338:    */         }
/* 339:    */       };
/* 340:    */     }
/* 341:    */     
/* 342:    */     public int size()
/* 343:    */     {
/* 344:405 */       if (this.upperBoundWindow.equals(Range.all())) {
/* 345:406 */         return this.rangesByLowerBound.size();
/* 346:    */       }
/* 347:408 */       return Iterators.size(entryIterator());
/* 348:    */     }
/* 349:    */     
/* 350:    */     public boolean isEmpty()
/* 351:    */     {
/* 352:413 */       return !entryIterator().hasNext() ? true : this.upperBoundWindow.equals(Range.all()) ? this.rangesByLowerBound.isEmpty() : false;
/* 353:    */     }
/* 354:    */   }
/* 355:    */   
/* 356:    */   private static final class ComplementRangesByLowerBound<C extends Comparable<?>>
/* 357:    */     extends AbstractNavigableMap<Cut<C>, Range<C>>
/* 358:    */   {
/* 359:    */     private final NavigableMap<Cut<C>, Range<C>> positiveRangesByLowerBound;
/* 360:    */     private final NavigableMap<Cut<C>, Range<C>> positiveRangesByUpperBound;
/* 361:    */     private final Range<Cut<C>> complementLowerBoundWindow;
/* 362:    */     
/* 363:    */     ComplementRangesByLowerBound(NavigableMap<Cut<C>, Range<C>> positiveRangesByLowerBound)
/* 364:    */     {
/* 365:432 */       this(positiveRangesByLowerBound, Range.all());
/* 366:    */     }
/* 367:    */     
/* 368:    */     private ComplementRangesByLowerBound(NavigableMap<Cut<C>, Range<C>> positiveRangesByLowerBound, Range<Cut<C>> window)
/* 369:    */     {
/* 370:437 */       this.positiveRangesByLowerBound = positiveRangesByLowerBound;
/* 371:438 */       this.positiveRangesByUpperBound = new TreeRangeSet.RangesByUpperBound(positiveRangesByLowerBound);
/* 372:439 */       this.complementLowerBoundWindow = window;
/* 373:    */     }
/* 374:    */     
/* 375:    */     private NavigableMap<Cut<C>, Range<C>> subMap(Range<Cut<C>> subWindow)
/* 376:    */     {
/* 377:443 */       if (!this.complementLowerBoundWindow.isConnected(subWindow)) {
/* 378:444 */         return ImmutableSortedMap.of();
/* 379:    */       }
/* 380:446 */       subWindow = subWindow.intersection(this.complementLowerBoundWindow);
/* 381:447 */       return new ComplementRangesByLowerBound(this.positiveRangesByLowerBound, subWindow);
/* 382:    */     }
/* 383:    */     
/* 384:    */     public NavigableMap<Cut<C>, Range<C>> subMap(Cut<C> fromKey, boolean fromInclusive, Cut<C> toKey, boolean toInclusive)
/* 385:    */     {
/* 386:454 */       return subMap(Range.range(fromKey, BoundType.forBoolean(fromInclusive), toKey, BoundType.forBoolean(toInclusive)));
/* 387:    */     }
/* 388:    */     
/* 389:    */     public NavigableMap<Cut<C>, Range<C>> headMap(Cut<C> toKey, boolean inclusive)
/* 390:    */     {
/* 391:462 */       return subMap(Range.upTo(toKey, BoundType.forBoolean(inclusive)));
/* 392:    */     }
/* 393:    */     
/* 394:    */     public NavigableMap<Cut<C>, Range<C>> tailMap(Cut<C> fromKey, boolean inclusive)
/* 395:    */     {
/* 396:467 */       return subMap(Range.downTo(fromKey, BoundType.forBoolean(inclusive)));
/* 397:    */     }
/* 398:    */     
/* 399:    */     public Comparator<? super Cut<C>> comparator()
/* 400:    */     {
/* 401:472 */       return Ordering.natural();
/* 402:    */     }
/* 403:    */     
/* 404:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> entryIterator()
/* 405:    */     {
/* 406:    */       Collection<Range<C>> positiveRanges;
/* 407:    */       Collection<Range<C>> positiveRanges;
/* 408:487 */       if (this.complementLowerBoundWindow.hasLowerBound()) {
/* 409:488 */         positiveRanges = this.positiveRangesByUpperBound.tailMap(this.complementLowerBoundWindow.lowerEndpoint(), this.complementLowerBoundWindow.lowerBoundType() == BoundType.CLOSED).values();
/* 410:    */       } else {
/* 411:495 */         positiveRanges = this.positiveRangesByUpperBound.values();
/* 412:    */       }
/* 413:497 */       final PeekingIterator<Range<C>> positiveItr = Iterators.peekingIterator(positiveRanges.iterator());
/* 414:    */       Cut<C> firstComplementRangeLowerBound;
/* 415:500 */       if ((this.complementLowerBoundWindow.contains(Cut.belowAll())) && ((!positiveItr.hasNext()) || (((Range)positiveItr.peek()).lowerBound != Cut.belowAll())))
/* 416:    */       {
/* 417:502 */         firstComplementRangeLowerBound = Cut.belowAll();
/* 418:    */       }
/* 419:    */       else
/* 420:    */       {
/* 421:    */         Cut<C> firstComplementRangeLowerBound;
/* 422:503 */         if (positiveItr.hasNext()) {
/* 423:504 */           firstComplementRangeLowerBound = ((Range)positiveItr.next()).upperBound;
/* 424:    */         } else {
/* 425:506 */           return Iterators.emptyIterator();
/* 426:    */         }
/* 427:    */       }
/* 428:    */       final Cut<C> firstComplementRangeLowerBound;
/* 429:508 */       new AbstractIterator()
/* 430:    */       {
/* 431:509 */         Cut<C> nextComplementRangeLowerBound = firstComplementRangeLowerBound;
/* 432:    */         
/* 433:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 434:    */         {
/* 435:513 */           if ((TreeRangeSet.ComplementRangesByLowerBound.this.complementLowerBoundWindow.upperBound.isLessThan(this.nextComplementRangeLowerBound)) || (this.nextComplementRangeLowerBound == Cut.aboveAll())) {
/* 436:515 */             return (Map.Entry)endOfData();
/* 437:    */           }
/* 438:    */           Range<C> negativeRange;
/* 439:518 */           if (positiveItr.hasNext())
/* 440:    */           {
/* 441:519 */             Range<C> positiveRange = (Range)positiveItr.next();
/* 442:520 */             Range<C> negativeRange = Range.create(this.nextComplementRangeLowerBound, positiveRange.lowerBound);
/* 443:521 */             this.nextComplementRangeLowerBound = positiveRange.upperBound;
/* 444:    */           }
/* 445:    */           else
/* 446:    */           {
/* 447:523 */             negativeRange = Range.create(this.nextComplementRangeLowerBound, Cut.aboveAll());
/* 448:524 */             this.nextComplementRangeLowerBound = Cut.aboveAll();
/* 449:    */           }
/* 450:526 */           return Maps.immutableEntry(negativeRange.lowerBound, negativeRange);
/* 451:    */         }
/* 452:    */       };
/* 453:    */     }
/* 454:    */     
/* 455:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> descendingEntryIterator()
/* 456:    */     {
/* 457:541 */       Cut<C> startingPoint = this.complementLowerBoundWindow.hasUpperBound() ? (Cut)this.complementLowerBoundWindow.upperEndpoint() : Cut.aboveAll();
/* 458:    */       
/* 459:    */ 
/* 460:    */ 
/* 461:545 */       boolean inclusive = (this.complementLowerBoundWindow.hasUpperBound()) && (this.complementLowerBoundWindow.upperBoundType() == BoundType.CLOSED);
/* 462:    */       
/* 463:    */ 
/* 464:548 */       final PeekingIterator<Range<C>> positiveItr = Iterators.peekingIterator(this.positiveRangesByUpperBound.headMap(startingPoint, inclusive).descendingMap().values().iterator());
/* 465:    */       Cut<C> cut;
/* 466:    */       Cut<C> cut;
/* 467:556 */       if (positiveItr.hasNext())
/* 468:    */       {
/* 469:557 */         cut = ((Range)positiveItr.peek()).upperBound == Cut.aboveAll() ? ((Range)positiveItr.next()).lowerBound : (Cut)this.positiveRangesByLowerBound.higherKey(((Range)positiveItr.peek()).upperBound);
/* 470:    */       }
/* 471:    */       else
/* 472:    */       {
/* 473:560 */         if ((!this.complementLowerBoundWindow.contains(Cut.belowAll())) || (this.positiveRangesByLowerBound.containsKey(Cut.belowAll()))) {
/* 474:562 */           return Iterators.emptyIterator();
/* 475:    */         }
/* 476:564 */         cut = (Cut)this.positiveRangesByLowerBound.higherKey(Cut.belowAll());
/* 477:    */       }
/* 478:566 */       final Cut<C> firstComplementRangeUpperBound = (Cut)MoreObjects.firstNonNull(cut, Cut.aboveAll());
/* 479:    */       
/* 480:568 */       new AbstractIterator()
/* 481:    */       {
/* 482:569 */         Cut<C> nextComplementRangeUpperBound = firstComplementRangeUpperBound;
/* 483:    */         
/* 484:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 485:    */         {
/* 486:573 */           if (this.nextComplementRangeUpperBound == Cut.belowAll()) {
/* 487:574 */             return (Map.Entry)endOfData();
/* 488:    */           }
/* 489:575 */           if (positiveItr.hasNext())
/* 490:    */           {
/* 491:576 */             Range<C> positiveRange = (Range)positiveItr.next();
/* 492:577 */             Range<C> negativeRange = Range.create(positiveRange.upperBound, this.nextComplementRangeUpperBound);
/* 493:    */             
/* 494:579 */             this.nextComplementRangeUpperBound = positiveRange.lowerBound;
/* 495:580 */             if (TreeRangeSet.ComplementRangesByLowerBound.this.complementLowerBoundWindow.lowerBound.isLessThan(negativeRange.lowerBound)) {
/* 496:581 */               return Maps.immutableEntry(negativeRange.lowerBound, negativeRange);
/* 497:    */             }
/* 498:    */           }
/* 499:583 */           else if (TreeRangeSet.ComplementRangesByLowerBound.this.complementLowerBoundWindow.lowerBound.isLessThan(Cut.belowAll()))
/* 500:    */           {
/* 501:584 */             Range<C> negativeRange = Range.create(Cut.belowAll(), this.nextComplementRangeUpperBound);
/* 502:585 */             this.nextComplementRangeUpperBound = Cut.belowAll();
/* 503:586 */             return Maps.immutableEntry(Cut.belowAll(), negativeRange);
/* 504:    */           }
/* 505:588 */           return (Map.Entry)endOfData();
/* 506:    */         }
/* 507:    */       };
/* 508:    */     }
/* 509:    */     
/* 510:    */     public int size()
/* 511:    */     {
/* 512:595 */       return Iterators.size(entryIterator());
/* 513:    */     }
/* 514:    */     
/* 515:    */     @Nullable
/* 516:    */     public Range<C> get(Object key)
/* 517:    */     {
/* 518:601 */       if ((key instanceof Cut)) {
/* 519:    */         try
/* 520:    */         {
/* 521:604 */           Cut<C> cut = (Cut)key;
/* 522:    */           
/* 523:606 */           Map.Entry<Cut<C>, Range<C>> firstEntry = tailMap(cut, true).firstEntry();
/* 524:607 */           if ((firstEntry != null) && (((Cut)firstEntry.getKey()).equals(cut))) {
/* 525:608 */             return (Range)firstEntry.getValue();
/* 526:    */           }
/* 527:    */         }
/* 528:    */         catch (ClassCastException e)
/* 529:    */         {
/* 530:611 */           return null;
/* 531:    */         }
/* 532:    */       }
/* 533:614 */       return null;
/* 534:    */     }
/* 535:    */     
/* 536:    */     public boolean containsKey(Object key)
/* 537:    */     {
/* 538:619 */       return get(key) != null;
/* 539:    */     }
/* 540:    */   }
/* 541:    */   
/* 542:    */   private final class Complement
/* 543:    */     extends TreeRangeSet<C>
/* 544:    */   {
/* 545:    */     Complement()
/* 546:    */     {
/* 547:625 */       super(null);
/* 548:    */     }
/* 549:    */     
/* 550:    */     public void add(Range<C> rangeToAdd)
/* 551:    */     {
/* 552:630 */       TreeRangeSet.this.remove(rangeToAdd);
/* 553:    */     }
/* 554:    */     
/* 555:    */     public void remove(Range<C> rangeToRemove)
/* 556:    */     {
/* 557:635 */       TreeRangeSet.this.add(rangeToRemove);
/* 558:    */     }
/* 559:    */     
/* 560:    */     public boolean contains(C value)
/* 561:    */     {
/* 562:640 */       return !TreeRangeSet.this.contains(value);
/* 563:    */     }
/* 564:    */     
/* 565:    */     public RangeSet<C> complement()
/* 566:    */     {
/* 567:645 */       return TreeRangeSet.this;
/* 568:    */     }
/* 569:    */   }
/* 570:    */   
/* 571:    */   private static final class SubRangeSetRangesByLowerBound<C extends Comparable<?>>
/* 572:    */     extends AbstractNavigableMap<Cut<C>, Range<C>>
/* 573:    */   {
/* 574:    */     private final Range<Cut<C>> lowerBoundWindow;
/* 575:    */     private final Range<C> restriction;
/* 576:    */     private final NavigableMap<Cut<C>, Range<C>> rangesByLowerBound;
/* 577:    */     private final NavigableMap<Cut<C>, Range<C>> rangesByUpperBound;
/* 578:    */     
/* 579:    */     private SubRangeSetRangesByLowerBound(Range<Cut<C>> lowerBoundWindow, Range<C> restriction, NavigableMap<Cut<C>, Range<C>> rangesByLowerBound)
/* 580:    */     {
/* 581:670 */       this.lowerBoundWindow = ((Range)Preconditions.checkNotNull(lowerBoundWindow));
/* 582:671 */       this.restriction = ((Range)Preconditions.checkNotNull(restriction));
/* 583:672 */       this.rangesByLowerBound = ((NavigableMap)Preconditions.checkNotNull(rangesByLowerBound));
/* 584:673 */       this.rangesByUpperBound = new TreeRangeSet.RangesByUpperBound(rangesByLowerBound);
/* 585:    */     }
/* 586:    */     
/* 587:    */     private NavigableMap<Cut<C>, Range<C>> subMap(Range<Cut<C>> window)
/* 588:    */     {
/* 589:677 */       if (!window.isConnected(this.lowerBoundWindow)) {
/* 590:678 */         return ImmutableSortedMap.of();
/* 591:    */       }
/* 592:680 */       return new SubRangeSetRangesByLowerBound(this.lowerBoundWindow.intersection(window), this.restriction, this.rangesByLowerBound);
/* 593:    */     }
/* 594:    */     
/* 595:    */     public NavigableMap<Cut<C>, Range<C>> subMap(Cut<C> fromKey, boolean fromInclusive, Cut<C> toKey, boolean toInclusive)
/* 596:    */     {
/* 597:688 */       return subMap(Range.range(fromKey, BoundType.forBoolean(fromInclusive), toKey, BoundType.forBoolean(toInclusive)));
/* 598:    */     }
/* 599:    */     
/* 600:    */     public NavigableMap<Cut<C>, Range<C>> headMap(Cut<C> toKey, boolean inclusive)
/* 601:    */     {
/* 602:698 */       return subMap(Range.upTo(toKey, BoundType.forBoolean(inclusive)));
/* 603:    */     }
/* 604:    */     
/* 605:    */     public NavigableMap<Cut<C>, Range<C>> tailMap(Cut<C> fromKey, boolean inclusive)
/* 606:    */     {
/* 607:703 */       return subMap(Range.downTo(fromKey, BoundType.forBoolean(inclusive)));
/* 608:    */     }
/* 609:    */     
/* 610:    */     public Comparator<? super Cut<C>> comparator()
/* 611:    */     {
/* 612:708 */       return Ordering.natural();
/* 613:    */     }
/* 614:    */     
/* 615:    */     public boolean containsKey(@Nullable Object key)
/* 616:    */     {
/* 617:713 */       return get(key) != null;
/* 618:    */     }
/* 619:    */     
/* 620:    */     @Nullable
/* 621:    */     public Range<C> get(@Nullable Object key)
/* 622:    */     {
/* 623:719 */       if ((key instanceof Cut)) {
/* 624:    */         try
/* 625:    */         {
/* 626:722 */           Cut<C> cut = (Cut)key;
/* 627:723 */           if ((!this.lowerBoundWindow.contains(cut)) || (cut.compareTo(this.restriction.lowerBound) < 0) || (cut.compareTo(this.restriction.upperBound) >= 0)) {
/* 628:726 */             return null;
/* 629:    */           }
/* 630:727 */           if (cut.equals(this.restriction.lowerBound))
/* 631:    */           {
/* 632:729 */             Range<C> candidate = (Range)Maps.valueOrNull(this.rangesByLowerBound.floorEntry(cut));
/* 633:730 */             if ((candidate != null) && (candidate.upperBound.compareTo(this.restriction.lowerBound) > 0)) {
/* 634:731 */               return candidate.intersection(this.restriction);
/* 635:    */             }
/* 636:    */           }
/* 637:    */           else
/* 638:    */           {
/* 639:734 */             Range<C> result = (Range)this.rangesByLowerBound.get(cut);
/* 640:735 */             if (result != null) {
/* 641:736 */               return result.intersection(this.restriction);
/* 642:    */             }
/* 643:    */           }
/* 644:    */         }
/* 645:    */         catch (ClassCastException e)
/* 646:    */         {
/* 647:740 */           return null;
/* 648:    */         }
/* 649:    */       }
/* 650:743 */       return null;
/* 651:    */     }
/* 652:    */     
/* 653:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> entryIterator()
/* 654:    */     {
/* 655:748 */       if (this.restriction.isEmpty()) {
/* 656:749 */         return Iterators.emptyIterator();
/* 657:    */       }
/* 658:752 */       if (this.lowerBoundWindow.upperBound.isLessThan(this.restriction.lowerBound)) {
/* 659:753 */         return Iterators.emptyIterator();
/* 660:    */       }
/* 661:    */       Iterator<Range<C>> completeRangeItr;
/* 662:    */       final Iterator<Range<C>> completeRangeItr;
/* 663:754 */       if (this.lowerBoundWindow.lowerBound.isLessThan(this.restriction.lowerBound)) {
/* 664:756 */         completeRangeItr = this.rangesByUpperBound.tailMap(this.restriction.lowerBound, false).values().iterator();
/* 665:    */       } else {
/* 666:760 */         completeRangeItr = this.rangesByLowerBound.tailMap(this.lowerBoundWindow.lowerBound.endpoint(), this.lowerBoundWindow.lowerBoundType() == BoundType.CLOSED).values().iterator();
/* 667:    */       }
/* 668:768 */       final Cut<Cut<C>> upperBoundOnLowerBounds = (Cut)Ordering.natural().min(this.lowerBoundWindow.upperBound, Cut.belowValue(this.restriction.upperBound));
/* 669:    */       
/* 670:    */ 
/* 671:771 */       new AbstractIterator()
/* 672:    */       {
/* 673:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 674:    */         {
/* 675:774 */           if (!completeRangeItr.hasNext()) {
/* 676:775 */             return (Map.Entry)endOfData();
/* 677:    */           }
/* 678:777 */           Range<C> nextRange = (Range)completeRangeItr.next();
/* 679:778 */           if (upperBoundOnLowerBounds.isLessThan(nextRange.lowerBound)) {
/* 680:779 */             return (Map.Entry)endOfData();
/* 681:    */           }
/* 682:781 */           nextRange = nextRange.intersection(TreeRangeSet.SubRangeSetRangesByLowerBound.this.restriction);
/* 683:782 */           return Maps.immutableEntry(nextRange.lowerBound, nextRange);
/* 684:    */         }
/* 685:    */       };
/* 686:    */     }
/* 687:    */     
/* 688:    */     Iterator<Map.Entry<Cut<C>, Range<C>>> descendingEntryIterator()
/* 689:    */     {
/* 690:790 */       if (this.restriction.isEmpty()) {
/* 691:791 */         return Iterators.emptyIterator();
/* 692:    */       }
/* 693:793 */       Cut<Cut<C>> upperBoundOnLowerBounds = (Cut)Ordering.natural().min(this.lowerBoundWindow.upperBound, Cut.belowValue(this.restriction.upperBound));
/* 694:    */       
/* 695:    */ 
/* 696:796 */       final Iterator<Range<C>> completeRangeItr = this.rangesByLowerBound.headMap(upperBoundOnLowerBounds.endpoint(), upperBoundOnLowerBounds.typeAsUpperBound() == BoundType.CLOSED).descendingMap().values().iterator();
/* 697:    */       
/* 698:    */ 
/* 699:    */ 
/* 700:    */ 
/* 701:    */ 
/* 702:    */ 
/* 703:    */ 
/* 704:804 */       new AbstractIterator()
/* 705:    */       {
/* 706:    */         protected Map.Entry<Cut<C>, Range<C>> computeNext()
/* 707:    */         {
/* 708:807 */           if (!completeRangeItr.hasNext()) {
/* 709:808 */             return (Map.Entry)endOfData();
/* 710:    */           }
/* 711:810 */           Range<C> nextRange = (Range)completeRangeItr.next();
/* 712:811 */           if (TreeRangeSet.SubRangeSetRangesByLowerBound.this.restriction.lowerBound.compareTo(nextRange.upperBound) >= 0) {
/* 713:812 */             return (Map.Entry)endOfData();
/* 714:    */           }
/* 715:814 */           nextRange = nextRange.intersection(TreeRangeSet.SubRangeSetRangesByLowerBound.this.restriction);
/* 716:815 */           if (TreeRangeSet.SubRangeSetRangesByLowerBound.this.lowerBoundWindow.contains(nextRange.lowerBound)) {
/* 717:816 */             return Maps.immutableEntry(nextRange.lowerBound, nextRange);
/* 718:    */           }
/* 719:818 */           return (Map.Entry)endOfData();
/* 720:    */         }
/* 721:    */       };
/* 722:    */     }
/* 723:    */     
/* 724:    */     public int size()
/* 725:    */     {
/* 726:826 */       return Iterators.size(entryIterator());
/* 727:    */     }
/* 728:    */   }
/* 729:    */   
/* 730:    */   public RangeSet<C> subRangeSet(Range<C> view)
/* 731:    */   {
/* 732:832 */     return view.equals(Range.all()) ? this : new SubRangeSet(view);
/* 733:    */   }
/* 734:    */   
/* 735:    */   private final class SubRangeSet
/* 736:    */     extends TreeRangeSet<C>
/* 737:    */   {
/* 738:    */     private final Range<C> restriction;
/* 739:    */     
/* 740:    */     SubRangeSet()
/* 741:    */     {
/* 742:839 */       super(null);
/* 743:    */       
/* 744:841 */       this.restriction = restriction;
/* 745:    */     }
/* 746:    */     
/* 747:    */     public boolean encloses(Range<C> range)
/* 748:    */     {
/* 749:846 */       if ((!this.restriction.isEmpty()) && (this.restriction.encloses(range)))
/* 750:    */       {
/* 751:847 */         Range<C> enclosing = TreeRangeSet.this.rangeEnclosing(range);
/* 752:848 */         return (enclosing != null) && (!enclosing.intersection(this.restriction).isEmpty());
/* 753:    */       }
/* 754:850 */       return false;
/* 755:    */     }
/* 756:    */     
/* 757:    */     @Nullable
/* 758:    */     public Range<C> rangeContaining(C value)
/* 759:    */     {
/* 760:856 */       if (!this.restriction.contains(value)) {
/* 761:857 */         return null;
/* 762:    */       }
/* 763:859 */       Range<C> result = TreeRangeSet.this.rangeContaining(value);
/* 764:860 */       return result == null ? null : result.intersection(this.restriction);
/* 765:    */     }
/* 766:    */     
/* 767:    */     public void add(Range<C> rangeToAdd)
/* 768:    */     {
/* 769:865 */       Preconditions.checkArgument(this.restriction.encloses(rangeToAdd), "Cannot add range %s to subRangeSet(%s)", new Object[] { rangeToAdd, this.restriction });
/* 770:    */       
/* 771:    */ 
/* 772:    */ 
/* 773:    */ 
/* 774:870 */       super.add(rangeToAdd);
/* 775:    */     }
/* 776:    */     
/* 777:    */     public void remove(Range<C> rangeToRemove)
/* 778:    */     {
/* 779:875 */       if (rangeToRemove.isConnected(this.restriction)) {
/* 780:876 */         TreeRangeSet.this.remove(rangeToRemove.intersection(this.restriction));
/* 781:    */       }
/* 782:    */     }
/* 783:    */     
/* 784:    */     public boolean contains(C value)
/* 785:    */     {
/* 786:882 */       return (this.restriction.contains(value)) && (TreeRangeSet.this.contains(value));
/* 787:    */     }
/* 788:    */     
/* 789:    */     public void clear()
/* 790:    */     {
/* 791:887 */       TreeRangeSet.this.remove(this.restriction);
/* 792:    */     }
/* 793:    */     
/* 794:    */     public RangeSet<C> subRangeSet(Range<C> view)
/* 795:    */     {
/* 796:892 */       if (view.encloses(this.restriction)) {
/* 797:893 */         return this;
/* 798:    */       }
/* 799:894 */       if (view.isConnected(this.restriction)) {
/* 800:895 */         return new SubRangeSet(this, this.restriction.intersection(view));
/* 801:    */       }
/* 802:897 */       return ImmutableRangeSet.of();
/* 803:    */     }
/* 804:    */   }
/* 805:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.TreeRangeSet
 * JD-Core Version:    0.7.0.1
 */