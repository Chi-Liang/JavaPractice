/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.math.BigInteger;
/*   7:    */ import java.util.NoSuchElementException;
/*   8:    */ 
/*   9:    */ @GwtCompatible
/*  10:    */ @Beta
/*  11:    */ public abstract class DiscreteDomain<C extends Comparable>
/*  12:    */ {
/*  13:    */   public static DiscreteDomain<Integer> integers()
/*  14:    */   {
/*  15: 54 */     return IntegerDomain.INSTANCE;
/*  16:    */   }
/*  17:    */   
/*  18:    */   private static final class IntegerDomain
/*  19:    */     extends DiscreteDomain<Integer>
/*  20:    */     implements Serializable
/*  21:    */   {
/*  22: 58 */     private static final IntegerDomain INSTANCE = new IntegerDomain();
/*  23:    */     private static final long serialVersionUID = 0L;
/*  24:    */     
/*  25:    */     public Integer next(Integer value)
/*  26:    */     {
/*  27: 62 */       int i = value.intValue();
/*  28: 63 */       return i == 2147483647 ? null : Integer.valueOf(i + 1);
/*  29:    */     }
/*  30:    */     
/*  31:    */     public Integer previous(Integer value)
/*  32:    */     {
/*  33: 68 */       int i = value.intValue();
/*  34: 69 */       return i == -2147483648 ? null : Integer.valueOf(i - 1);
/*  35:    */     }
/*  36:    */     
/*  37:    */     public long distance(Integer start, Integer end)
/*  38:    */     {
/*  39: 74 */       return end.intValue() - start.intValue();
/*  40:    */     }
/*  41:    */     
/*  42:    */     public Integer minValue()
/*  43:    */     {
/*  44: 79 */       return Integer.valueOf(-2147483648);
/*  45:    */     }
/*  46:    */     
/*  47:    */     public Integer maxValue()
/*  48:    */     {
/*  49: 84 */       return Integer.valueOf(2147483647);
/*  50:    */     }
/*  51:    */     
/*  52:    */     private Object readResolve()
/*  53:    */     {
/*  54: 88 */       return INSTANCE;
/*  55:    */     }
/*  56:    */     
/*  57:    */     public String toString()
/*  58:    */     {
/*  59: 93 */       return "DiscreteDomain.integers()";
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static DiscreteDomain<Long> longs()
/*  64:    */   {
/*  65:105 */     return LongDomain.INSTANCE;
/*  66:    */   }
/*  67:    */   
/*  68:    */   private static final class LongDomain
/*  69:    */     extends DiscreteDomain<Long>
/*  70:    */     implements Serializable
/*  71:    */   {
/*  72:109 */     private static final LongDomain INSTANCE = new LongDomain();
/*  73:    */     private static final long serialVersionUID = 0L;
/*  74:    */     
/*  75:    */     public Long next(Long value)
/*  76:    */     {
/*  77:113 */       long l = value.longValue();
/*  78:114 */       return l == 9223372036854775807L ? null : Long.valueOf(l + 1L);
/*  79:    */     }
/*  80:    */     
/*  81:    */     public Long previous(Long value)
/*  82:    */     {
/*  83:119 */       long l = value.longValue();
/*  84:120 */       return l == -9223372036854775808L ? null : Long.valueOf(l - 1L);
/*  85:    */     }
/*  86:    */     
/*  87:    */     public long distance(Long start, Long end)
/*  88:    */     {
/*  89:125 */       long result = end.longValue() - start.longValue();
/*  90:126 */       if ((end.longValue() > start.longValue()) && (result < 0L)) {
/*  91:127 */         return 9223372036854775807L;
/*  92:    */       }
/*  93:129 */       if ((end.longValue() < start.longValue()) && (result > 0L)) {
/*  94:130 */         return -9223372036854775808L;
/*  95:    */       }
/*  96:132 */       return result;
/*  97:    */     }
/*  98:    */     
/*  99:    */     public Long minValue()
/* 100:    */     {
/* 101:137 */       return Long.valueOf(-9223372036854775808L);
/* 102:    */     }
/* 103:    */     
/* 104:    */     public Long maxValue()
/* 105:    */     {
/* 106:142 */       return Long.valueOf(9223372036854775807L);
/* 107:    */     }
/* 108:    */     
/* 109:    */     private Object readResolve()
/* 110:    */     {
/* 111:146 */       return INSTANCE;
/* 112:    */     }
/* 113:    */     
/* 114:    */     public String toString()
/* 115:    */     {
/* 116:151 */       return "DiscreteDomain.longs()";
/* 117:    */     }
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static DiscreteDomain<BigInteger> bigIntegers()
/* 121:    */   {
/* 122:163 */     return BigIntegerDomain.INSTANCE;
/* 123:    */   }
/* 124:    */   
/* 125:    */   public abstract C next(C paramC);
/* 126:    */   
/* 127:    */   public abstract C previous(C paramC);
/* 128:    */   
/* 129:    */   public abstract long distance(C paramC1, C paramC2);
/* 130:    */   
/* 131:    */   private static final class BigIntegerDomain
/* 132:    */     extends DiscreteDomain<BigInteger>
/* 133:    */     implements Serializable
/* 134:    */   {
/* 135:168 */     private static final BigIntegerDomain INSTANCE = new BigIntegerDomain();
/* 136:170 */     private static final BigInteger MIN_LONG = BigInteger.valueOf(-9223372036854775808L);
/* 137:171 */     private static final BigInteger MAX_LONG = BigInteger.valueOf(9223372036854775807L);
/* 138:    */     private static final long serialVersionUID = 0L;
/* 139:    */     
/* 140:    */     public BigInteger next(BigInteger value)
/* 141:    */     {
/* 142:175 */       return value.add(BigInteger.ONE);
/* 143:    */     }
/* 144:    */     
/* 145:    */     public BigInteger previous(BigInteger value)
/* 146:    */     {
/* 147:180 */       return value.subtract(BigInteger.ONE);
/* 148:    */     }
/* 149:    */     
/* 150:    */     public long distance(BigInteger start, BigInteger end)
/* 151:    */     {
/* 152:185 */       return end.subtract(start).max(MIN_LONG).min(MAX_LONG).longValue();
/* 153:    */     }
/* 154:    */     
/* 155:    */     private Object readResolve()
/* 156:    */     {
/* 157:193 */       return INSTANCE;
/* 158:    */     }
/* 159:    */     
/* 160:    */     public String toString()
/* 161:    */     {
/* 162:198 */       return "DiscreteDomain.bigIntegers()";
/* 163:    */     }
/* 164:    */   }
/* 165:    */   
/* 166:    */   public C minValue()
/* 167:    */   {
/* 168:258 */     throw new NoSuchElementException();
/* 169:    */   }
/* 170:    */   
/* 171:    */   public C maxValue()
/* 172:    */   {
/* 173:273 */     throw new NoSuchElementException();
/* 174:    */   }
/* 175:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.DiscreteDomain
 * JD-Core Version:    0.7.0.1
 */