/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.util.Arrays;
/*   6:    */ import java.util.Comparator;
/*   7:    */ import java.util.Map;
/*   8:    */ import java.util.Map.Entry;
/*   9:    */ 
/*  10:    */ @GwtCompatible(serializable=true, emulated=true)
/*  11:    */ public abstract class ImmutableBiMap<K, V>
/*  12:    */   extends ImmutableMap<K, V>
/*  13:    */   implements BiMap<K, V>
/*  14:    */ {
/*  15:    */   public static <K, V> ImmutableBiMap<K, V> of()
/*  16:    */   {
/*  17: 42 */     return RegularImmutableBiMap.EMPTY;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1)
/*  21:    */   {
/*  22: 49 */     return new SingletonImmutableBiMap(k1, v1);
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2)
/*  26:    */   {
/*  27: 58 */     return RegularImmutableBiMap.fromEntries(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2) });
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3)
/*  31:    */   {
/*  32: 67 */     return RegularImmutableBiMap.fromEntries(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3) });
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4)
/*  36:    */   {
/*  37: 76 */     return RegularImmutableBiMap.fromEntries(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4) });
/*  38:    */   }
/*  39:    */   
/*  40:    */   public static <K, V> ImmutableBiMap<K, V> of(K k1, V v1, K k2, V v2, K k3, V v3, K k4, V v4, K k5, V v5)
/*  41:    */   {
/*  42: 87 */     return RegularImmutableBiMap.fromEntries(new Map.Entry[] { entryOf(k1, v1), entryOf(k2, v2), entryOf(k3, v3), entryOf(k4, v4), entryOf(k5, v5) });
/*  43:    */   }
/*  44:    */   
/*  45:    */   public static <K, V> Builder<K, V> builder()
/*  46:    */   {
/*  47: 98 */     return new Builder();
/*  48:    */   }
/*  49:    */   
/*  50:    */   public static final class Builder<K, V>
/*  51:    */     extends ImmutableMap.Builder<K, V>
/*  52:    */   {
/*  53:    */     public Builder() {}
/*  54:    */     
/*  55:    */     Builder(int size)
/*  56:    */     {
/*  57:130 */       super();
/*  58:    */     }
/*  59:    */     
/*  60:    */     public Builder<K, V> put(K key, V value)
/*  61:    */     {
/*  62:139 */       super.put(key, value);
/*  63:140 */       return this;
/*  64:    */     }
/*  65:    */     
/*  66:    */     public Builder<K, V> put(Map.Entry<? extends K, ? extends V> entry)
/*  67:    */     {
/*  68:151 */       super.put(entry);
/*  69:152 */       return this;
/*  70:    */     }
/*  71:    */     
/*  72:    */     public Builder<K, V> putAll(Map<? extends K, ? extends V> map)
/*  73:    */     {
/*  74:164 */       super.putAll(map);
/*  75:165 */       return this;
/*  76:    */     }
/*  77:    */     
/*  78:    */     @Beta
/*  79:    */     public Builder<K, V> putAll(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/*  80:    */     {
/*  81:178 */       super.putAll(entries);
/*  82:179 */       return this;
/*  83:    */     }
/*  84:    */     
/*  85:    */     @Beta
/*  86:    */     public Builder<K, V> orderEntriesByValue(Comparator<? super V> valueComparator)
/*  87:    */     {
/*  88:196 */       super.orderEntriesByValue(valueComparator);
/*  89:197 */       return this;
/*  90:    */     }
/*  91:    */     
/*  92:    */     public ImmutableBiMap<K, V> build()
/*  93:    */     {
/*  94:207 */       switch (this.size)
/*  95:    */       {
/*  96:    */       case 0: 
/*  97:209 */         return ImmutableBiMap.of();
/*  98:    */       case 1: 
/*  99:211 */         return ImmutableBiMap.of(this.entries[0].getKey(), this.entries[0].getValue());
/* 100:    */       }
/* 101:220 */       if (this.valueComparator != null)
/* 102:    */       {
/* 103:221 */         if (this.entriesUsed) {
/* 104:222 */           this.entries = ((ImmutableMapEntry[])ObjectArrays.arraysCopyOf(this.entries, this.size));
/* 105:    */         }
/* 106:224 */         Arrays.sort(this.entries, 0, this.size, Ordering.from(this.valueComparator).onResultOf(Maps.valueFunction()));
/* 107:    */       }
/* 108:230 */       this.entriesUsed = (this.size == this.entries.length);
/* 109:231 */       return RegularImmutableBiMap.fromEntryArray(this.size, this.entries);
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:    */   public static <K, V> ImmutableBiMap<K, V> copyOf(Map<? extends K, ? extends V> map)
/* 114:    */   {
/* 115:250 */     if ((map instanceof ImmutableBiMap))
/* 116:    */     {
/* 117:252 */       ImmutableBiMap<K, V> bimap = (ImmutableBiMap)map;
/* 118:255 */       if (!bimap.isPartialView()) {
/* 119:256 */         return bimap;
/* 120:    */       }
/* 121:    */     }
/* 122:259 */     return copyOf(map.entrySet());
/* 123:    */   }
/* 124:    */   
/* 125:    */   @Beta
/* 126:    */   public static <K, V> ImmutableBiMap<K, V> copyOf(Iterable<? extends Map.Entry<? extends K, ? extends V>> entries)
/* 127:    */   {
/* 128:274 */     Map.Entry<K, V>[] entryArray = (Map.Entry[])Iterables.toArray(entries, EMPTY_ENTRY_ARRAY);
/* 129:275 */     switch (entryArray.length)
/* 130:    */     {
/* 131:    */     case 0: 
/* 132:277 */       return of();
/* 133:    */     case 1: 
/* 134:279 */       Map.Entry<K, V> entry = entryArray[0];
/* 135:280 */       return of(entry.getKey(), entry.getValue());
/* 136:    */     }
/* 137:286 */     return RegularImmutableBiMap.fromEntries(entryArray);
/* 138:    */   }
/* 139:    */   
/* 140:    */   public abstract ImmutableBiMap<V, K> inverse();
/* 141:    */   
/* 142:    */   public ImmutableSet<V> values()
/* 143:    */   {
/* 144:307 */     return inverse().keySet();
/* 145:    */   }
/* 146:    */   
/* 147:    */   @Deprecated
/* 148:    */   public V forcePut(K key, V value)
/* 149:    */   {
/* 150:319 */     throw new UnsupportedOperationException();
/* 151:    */   }
/* 152:    */   
/* 153:    */   private static class SerializedForm
/* 154:    */     extends ImmutableMap.SerializedForm
/* 155:    */   {
/* 156:    */     private static final long serialVersionUID = 0L;
/* 157:    */     
/* 158:    */     SerializedForm(ImmutableBiMap<?, ?> bimap)
/* 159:    */     {
/* 160:333 */       super();
/* 161:    */     }
/* 162:    */     
/* 163:    */     Object readResolve()
/* 164:    */     {
/* 165:338 */       ImmutableBiMap.Builder<Object, Object> builder = new ImmutableBiMap.Builder();
/* 166:339 */       return createMap(builder);
/* 167:    */     }
/* 168:    */   }
/* 169:    */   
/* 170:    */   Object writeReplace()
/* 171:    */   {
/* 172:347 */     return new SerializedForm(this);
/* 173:    */   }
/* 174:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ImmutableBiMap
 * JD-Core Version:    0.7.0.1
 */