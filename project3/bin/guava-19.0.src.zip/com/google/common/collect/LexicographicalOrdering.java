/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import java.util.Comparator;
/*  6:   */ import java.util.Iterator;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @GwtCompatible(serializable=true)
/* 10:   */ final class LexicographicalOrdering<T>
/* 11:   */   extends Ordering<Iterable<T>>
/* 12:   */   implements Serializable
/* 13:   */ {
/* 14:   */   final Comparator<? super T> elementOrder;
/* 15:   */   private static final long serialVersionUID = 0L;
/* 16:   */   
/* 17:   */   LexicographicalOrdering(Comparator<? super T> elementOrder)
/* 18:   */   {
/* 19:36 */     this.elementOrder = elementOrder;
/* 20:   */   }
/* 21:   */   
/* 22:   */   public int compare(Iterable<T> leftIterable, Iterable<T> rightIterable)
/* 23:   */   {
/* 24:41 */     Iterator<T> left = leftIterable.iterator();
/* 25:42 */     Iterator<T> right = rightIterable.iterator();
/* 26:43 */     while (left.hasNext())
/* 27:   */     {
/* 28:44 */       if (!right.hasNext()) {
/* 29:45 */         return 1;
/* 30:   */       }
/* 31:47 */       int result = this.elementOrder.compare(left.next(), right.next());
/* 32:48 */       if (result != 0) {
/* 33:49 */         return result;
/* 34:   */       }
/* 35:   */     }
/* 36:52 */     if (right.hasNext()) {
/* 37:53 */       return -1;
/* 38:   */     }
/* 39:55 */     return 0;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean equals(@Nullable Object object)
/* 43:   */   {
/* 44:60 */     if (object == this) {
/* 45:61 */       return true;
/* 46:   */     }
/* 47:63 */     if ((object instanceof LexicographicalOrdering))
/* 48:   */     {
/* 49:64 */       LexicographicalOrdering<?> that = (LexicographicalOrdering)object;
/* 50:65 */       return this.elementOrder.equals(that.elementOrder);
/* 51:   */     }
/* 52:67 */     return false;
/* 53:   */   }
/* 54:   */   
/* 55:   */   public int hashCode()
/* 56:   */   {
/* 57:72 */     return this.elementOrder.hashCode() ^ 0x7BB78CF5;
/* 58:   */   }
/* 59:   */   
/* 60:   */   public String toString()
/* 61:   */   {
/* 62:77 */     return this.elementOrder + ".lexicographical()";
/* 63:   */   }
/* 64:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.LexicographicalOrdering
 * JD-Core Version:    0.7.0.1
 */