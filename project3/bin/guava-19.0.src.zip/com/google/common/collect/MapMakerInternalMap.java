/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.VisibleForTesting;
/*    4:     */ import com.google.common.base.Equivalence;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.base.Ticker;
/*    7:     */ import com.google.common.primitives.Ints;
/*    8:     */ import com.google.j2objc.annotations.Weak;
/*    9:     */ import java.io.IOException;
/*   10:     */ import java.io.ObjectInputStream;
/*   11:     */ import java.io.ObjectOutputStream;
/*   12:     */ import java.io.Serializable;
/*   13:     */ import java.lang.ref.Reference;
/*   14:     */ import java.lang.ref.ReferenceQueue;
/*   15:     */ import java.lang.ref.SoftReference;
/*   16:     */ import java.lang.ref.WeakReference;
/*   17:     */ import java.util.AbstractCollection;
/*   18:     */ import java.util.AbstractMap;
/*   19:     */ import java.util.AbstractQueue;
/*   20:     */ import java.util.AbstractSet;
/*   21:     */ import java.util.ArrayList;
/*   22:     */ import java.util.Collection;
/*   23:     */ import java.util.Iterator;
/*   24:     */ import java.util.Map;
/*   25:     */ import java.util.Map.Entry;
/*   26:     */ import java.util.NoSuchElementException;
/*   27:     */ import java.util.Queue;
/*   28:     */ import java.util.Set;
/*   29:     */ import java.util.concurrent.CancellationException;
/*   30:     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*   31:     */ import java.util.concurrent.ConcurrentMap;
/*   32:     */ import java.util.concurrent.ExecutionException;
/*   33:     */ import java.util.concurrent.TimeUnit;
/*   34:     */ import java.util.concurrent.atomic.AtomicInteger;
/*   35:     */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*   36:     */ import java.util.concurrent.locks.ReentrantLock;
/*   37:     */ import java.util.logging.Level;
/*   38:     */ import java.util.logging.Logger;
/*   39:     */ import javax.annotation.Nullable;
/*   40:     */ import javax.annotation.concurrent.GuardedBy;
/*   41:     */ 
/*   42:     */ class MapMakerInternalMap<K, V>
/*   43:     */   extends AbstractMap<K, V>
/*   44:     */   implements ConcurrentMap<K, V>, Serializable
/*   45:     */ {
/*   46:     */   static final int MAXIMUM_CAPACITY = 1073741824;
/*   47:     */   static final int MAX_SEGMENTS = 65536;
/*   48:     */   static final int CONTAINS_VALUE_RETRIES = 3;
/*   49:     */   static final int DRAIN_THRESHOLD = 63;
/*   50:     */   static final int DRAIN_MAX = 16;
/*   51:     */   static final long CLEANUP_EXECUTOR_DELAY_SECS = 60L;
/*   52: 138 */   private static final Logger logger = Logger.getLogger(MapMakerInternalMap.class.getName());
/*   53:     */   final transient int segmentMask;
/*   54:     */   final transient int segmentShift;
/*   55:     */   final transient Segment<K, V>[] segments;
/*   56:     */   final int concurrencyLevel;
/*   57:     */   final Equivalence<Object> keyEquivalence;
/*   58:     */   final Equivalence<Object> valueEquivalence;
/*   59:     */   final Strength keyStrength;
/*   60:     */   final Strength valueStrength;
/*   61:     */   final int maximumSize;
/*   62:     */   final long expireAfterAccessNanos;
/*   63:     */   final long expireAfterWriteNanos;
/*   64:     */   final Queue<MapMaker.RemovalNotification<K, V>> removalNotificationQueue;
/*   65:     */   final MapMaker.RemovalListener<K, V> removalListener;
/*   66:     */   final transient EntryFactory entryFactory;
/*   67:     */   final Ticker ticker;
/*   68:     */   
/*   69:     */   MapMakerInternalMap(MapMaker builder)
/*   70:     */   {
/*   71: 199 */     this.concurrencyLevel = Math.min(builder.getConcurrencyLevel(), 65536);
/*   72:     */     
/*   73: 201 */     this.keyStrength = builder.getKeyStrength();
/*   74: 202 */     this.valueStrength = builder.getValueStrength();
/*   75:     */     
/*   76: 204 */     this.keyEquivalence = builder.getKeyEquivalence();
/*   77: 205 */     this.valueEquivalence = this.valueStrength.defaultEquivalence();
/*   78:     */     
/*   79: 207 */     this.maximumSize = builder.maximumSize;
/*   80: 208 */     this.expireAfterAccessNanos = builder.getExpireAfterAccessNanos();
/*   81: 209 */     this.expireAfterWriteNanos = builder.getExpireAfterWriteNanos();
/*   82:     */     
/*   83: 211 */     this.entryFactory = EntryFactory.getFactory(this.keyStrength, expires(), evictsBySize());
/*   84: 212 */     this.ticker = builder.getTicker();
/*   85:     */     
/*   86: 214 */     this.removalListener = builder.getRemovalListener();
/*   87: 215 */     this.removalNotificationQueue = (this.removalListener == GenericMapMaker.NullListener.INSTANCE ? discardingQueue() : new ConcurrentLinkedQueue());
/*   88:     */     
/*   89:     */ 
/*   90:     */ 
/*   91:     */ 
/*   92: 220 */     int initialCapacity = Math.min(builder.getInitialCapacity(), 1073741824);
/*   93: 221 */     if (evictsBySize()) {
/*   94: 222 */       initialCapacity = Math.min(initialCapacity, this.maximumSize);
/*   95:     */     }
/*   96: 228 */     int segmentShift = 0;
/*   97: 229 */     int segmentCount = 1;
/*   98: 231 */     while ((segmentCount < this.concurrencyLevel) && ((!evictsBySize()) || (segmentCount * 2 <= this.maximumSize)))
/*   99:     */     {
/*  100: 232 */       segmentShift++;
/*  101: 233 */       segmentCount <<= 1;
/*  102:     */     }
/*  103: 235 */     this.segmentShift = (32 - segmentShift);
/*  104: 236 */     this.segmentMask = (segmentCount - 1);
/*  105:     */     
/*  106: 238 */     this.segments = newSegmentArray(segmentCount);
/*  107:     */     
/*  108: 240 */     int segmentCapacity = initialCapacity / segmentCount;
/*  109: 241 */     if (segmentCapacity * segmentCount < initialCapacity) {
/*  110: 242 */       segmentCapacity++;
/*  111:     */     }
/*  112: 245 */     int segmentSize = 1;
/*  113: 246 */     while (segmentSize < segmentCapacity) {
/*  114: 247 */       segmentSize <<= 1;
/*  115:     */     }
/*  116: 250 */     if (evictsBySize())
/*  117:     */     {
/*  118: 252 */       int maximumSegmentSize = this.maximumSize / segmentCount + 1;
/*  119: 253 */       int remainder = this.maximumSize % segmentCount;
/*  120: 254 */       for (int i = 0; i < this.segments.length; i++)
/*  121:     */       {
/*  122: 255 */         if (i == remainder) {
/*  123: 256 */           maximumSegmentSize--;
/*  124:     */         }
/*  125: 258 */         this.segments[i] = createSegment(segmentSize, maximumSegmentSize);
/*  126:     */       }
/*  127:     */     }
/*  128:     */     else
/*  129:     */     {
/*  130: 261 */       for (int i = 0; i < this.segments.length; i++) {
/*  131: 262 */         this.segments[i] = createSegment(segmentSize, -1);
/*  132:     */       }
/*  133:     */     }
/*  134:     */   }
/*  135:     */   
/*  136:     */   boolean evictsBySize()
/*  137:     */   {
/*  138: 268 */     return this.maximumSize != -1;
/*  139:     */   }
/*  140:     */   
/*  141:     */   boolean expires()
/*  142:     */   {
/*  143: 272 */     return (expiresAfterWrite()) || (expiresAfterAccess());
/*  144:     */   }
/*  145:     */   
/*  146:     */   boolean expiresAfterWrite()
/*  147:     */   {
/*  148: 276 */     return this.expireAfterWriteNanos > 0L;
/*  149:     */   }
/*  150:     */   
/*  151:     */   boolean expiresAfterAccess()
/*  152:     */   {
/*  153: 280 */     return this.expireAfterAccessNanos > 0L;
/*  154:     */   }
/*  155:     */   
/*  156:     */   boolean usesKeyReferences()
/*  157:     */   {
/*  158: 284 */     return this.keyStrength != Strength.STRONG;
/*  159:     */   }
/*  160:     */   
/*  161:     */   boolean usesValueReferences()
/*  162:     */   {
/*  163: 288 */     return this.valueStrength != Strength.STRONG;
/*  164:     */   }
/*  165:     */   
/*  166:     */   static abstract enum Strength
/*  167:     */   {
/*  168: 297 */     STRONG,  SOFT,  WEAK;
/*  169:     */     
/*  170:     */     private Strength() {}
/*  171:     */     
/*  172:     */     abstract <K, V> MapMakerInternalMap.ValueReference<K, V> referenceValue(MapMakerInternalMap.Segment<K, V> paramSegment, MapMakerInternalMap.ReferenceEntry<K, V> paramReferenceEntry, V paramV);
/*  173:     */     
/*  174:     */     abstract Equivalence<Object> defaultEquivalence();
/*  175:     */   }
/*  176:     */   
/*  177:     */   static abstract enum EntryFactory
/*  178:     */   {
/*  179: 354 */     STRONG,  STRONG_EXPIRABLE,  STRONG_EVICTABLE,  STRONG_EXPIRABLE_EVICTABLE,  WEAK,  WEAK_EXPIRABLE,  WEAK_EVICTABLE,  WEAK_EXPIRABLE_EVICTABLE;
/*  180:     */     
/*  181:     */     static final int EXPIRABLE_MASK = 1;
/*  182:     */     static final int EVICTABLE_MASK = 2;
/*  183: 473 */     static final EntryFactory[][] factories = { { STRONG, STRONG_EXPIRABLE, STRONG_EVICTABLE, STRONG_EXPIRABLE_EVICTABLE }, new EntryFactory[0], { WEAK, WEAK_EXPIRABLE, WEAK_EVICTABLE, WEAK_EXPIRABLE_EVICTABLE } };
/*  184:     */     
/*  185:     */     private EntryFactory() {}
/*  186:     */     
/*  187:     */     static EntryFactory getFactory(MapMakerInternalMap.Strength keyStrength, boolean expireAfterWrite, boolean evictsBySize)
/*  188:     */     {
/*  189: 481 */       int flags = (expireAfterWrite ? 1 : 0) | (evictsBySize ? 2 : 0);
/*  190: 482 */       return factories[keyStrength.ordinal()][flags];
/*  191:     */     }
/*  192:     */     
/*  193:     */     abstract <K, V> MapMakerInternalMap.ReferenceEntry<K, V> newEntry(MapMakerInternalMap.Segment<K, V> paramSegment, K paramK, int paramInt, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> paramReferenceEntry);
/*  194:     */     
/*  195:     */     <K, V> MapMakerInternalMap.ReferenceEntry<K, V> copyEntry(MapMakerInternalMap.Segment<K, V> segment, MapMakerInternalMap.ReferenceEntry<K, V> original, MapMakerInternalMap.ReferenceEntry<K, V> newNext)
/*  196:     */     {
/*  197: 505 */       return newEntry(segment, original.getKey(), original.getHash(), newNext);
/*  198:     */     }
/*  199:     */     
/*  200:     */     <K, V> void copyExpirableEntry(MapMakerInternalMap.ReferenceEntry<K, V> original, MapMakerInternalMap.ReferenceEntry<K, V> newEntry)
/*  201:     */     {
/*  202: 512 */       newEntry.setExpirationTime(original.getExpirationTime());
/*  203:     */       
/*  204: 514 */       MapMakerInternalMap.connectExpirables(original.getPreviousExpirable(), newEntry);
/*  205: 515 */       MapMakerInternalMap.connectExpirables(newEntry, original.getNextExpirable());
/*  206:     */       
/*  207: 517 */       MapMakerInternalMap.nullifyExpirable(original);
/*  208:     */     }
/*  209:     */     
/*  210:     */     <K, V> void copyEvictableEntry(MapMakerInternalMap.ReferenceEntry<K, V> original, MapMakerInternalMap.ReferenceEntry<K, V> newEntry)
/*  211:     */     {
/*  212: 524 */       MapMakerInternalMap.connectEvictables(original.getPreviousEvictable(), newEntry);
/*  213: 525 */       MapMakerInternalMap.connectEvictables(newEntry, original.getNextEvictable());
/*  214:     */       
/*  215: 527 */       MapMakerInternalMap.nullifyEvictable(original);
/*  216:     */     }
/*  217:     */   }
/*  218:     */   
/*  219: 581 */   static final ValueReference<Object, Object> UNSET = new ValueReference()
/*  220:     */   {
/*  221:     */     public Object get()
/*  222:     */     {
/*  223: 585 */       return null;
/*  224:     */     }
/*  225:     */     
/*  226:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getEntry()
/*  227:     */     {
/*  228: 590 */       return null;
/*  229:     */     }
/*  230:     */     
/*  231:     */     public MapMakerInternalMap.ValueReference<Object, Object> copyFor(ReferenceQueue<Object> queue, @Nullable Object value, MapMakerInternalMap.ReferenceEntry<Object, Object> entry)
/*  232:     */     {
/*  233: 598 */       return this;
/*  234:     */     }
/*  235:     */     
/*  236:     */     public boolean isComputingReference()
/*  237:     */     {
/*  238: 603 */       return false;
/*  239:     */     }
/*  240:     */     
/*  241:     */     public Object waitForValue()
/*  242:     */     {
/*  243: 608 */       return null;
/*  244:     */     }
/*  245:     */     
/*  246:     */     public void clear(MapMakerInternalMap.ValueReference<Object, Object> newValue) {}
/*  247:     */   };
/*  248:     */   
/*  249:     */   static <K, V> ValueReference<K, V> unset()
/*  250:     */   {
/*  251: 620 */     return UNSET;
/*  252:     */   }
/*  253:     */   
/*  254:     */   static abstract interface ValueReference<K, V>
/*  255:     */   {
/*  256:     */     public abstract V get();
/*  257:     */     
/*  258:     */     public abstract V waitForValue()
/*  259:     */       throws ExecutionException;
/*  260:     */     
/*  261:     */     public abstract MapMakerInternalMap.ReferenceEntry<K, V> getEntry();
/*  262:     */     
/*  263:     */     public abstract ValueReference<K, V> copyFor(ReferenceQueue<V> paramReferenceQueue, @Nullable V paramV, MapMakerInternalMap.ReferenceEntry<K, V> paramReferenceEntry);
/*  264:     */     
/*  265:     */     public abstract void clear(@Nullable ValueReference<K, V> paramValueReference);
/*  266:     */     
/*  267:     */     public abstract boolean isComputingReference();
/*  268:     */   }
/*  269:     */   
/*  270:     */   static abstract interface ReferenceEntry<K, V>
/*  271:     */   {
/*  272:     */     public abstract MapMakerInternalMap.ValueReference<K, V> getValueReference();
/*  273:     */     
/*  274:     */     public abstract void setValueReference(MapMakerInternalMap.ValueReference<K, V> paramValueReference);
/*  275:     */     
/*  276:     */     public abstract ReferenceEntry<K, V> getNext();
/*  277:     */     
/*  278:     */     public abstract int getHash();
/*  279:     */     
/*  280:     */     public abstract K getKey();
/*  281:     */     
/*  282:     */     public abstract long getExpirationTime();
/*  283:     */     
/*  284:     */     public abstract void setExpirationTime(long paramLong);
/*  285:     */     
/*  286:     */     public abstract ReferenceEntry<K, V> getNextExpirable();
/*  287:     */     
/*  288:     */     public abstract void setNextExpirable(ReferenceEntry<K, V> paramReferenceEntry);
/*  289:     */     
/*  290:     */     public abstract ReferenceEntry<K, V> getPreviousExpirable();
/*  291:     */     
/*  292:     */     public abstract void setPreviousExpirable(ReferenceEntry<K, V> paramReferenceEntry);
/*  293:     */     
/*  294:     */     public abstract ReferenceEntry<K, V> getNextEvictable();
/*  295:     */     
/*  296:     */     public abstract void setNextEvictable(ReferenceEntry<K, V> paramReferenceEntry);
/*  297:     */     
/*  298:     */     public abstract ReferenceEntry<K, V> getPreviousEvictable();
/*  299:     */     
/*  300:     */     public abstract void setPreviousEvictable(ReferenceEntry<K, V> paramReferenceEntry);
/*  301:     */   }
/*  302:     */   
/*  303:     */   private static enum NullEntry
/*  304:     */     implements MapMakerInternalMap.ReferenceEntry<Object, Object>
/*  305:     */   {
/*  306: 726 */     INSTANCE;
/*  307:     */     
/*  308:     */     private NullEntry() {}
/*  309:     */     
/*  310:     */     public MapMakerInternalMap.ValueReference<Object, Object> getValueReference()
/*  311:     */     {
/*  312: 730 */       return null;
/*  313:     */     }
/*  314:     */     
/*  315:     */     public void setValueReference(MapMakerInternalMap.ValueReference<Object, Object> valueReference) {}
/*  316:     */     
/*  317:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getNext()
/*  318:     */     {
/*  319: 738 */       return null;
/*  320:     */     }
/*  321:     */     
/*  322:     */     public int getHash()
/*  323:     */     {
/*  324: 743 */       return 0;
/*  325:     */     }
/*  326:     */     
/*  327:     */     public Object getKey()
/*  328:     */     {
/*  329: 748 */       return null;
/*  330:     */     }
/*  331:     */     
/*  332:     */     public long getExpirationTime()
/*  333:     */     {
/*  334: 753 */       return 0L;
/*  335:     */     }
/*  336:     */     
/*  337:     */     public void setExpirationTime(long time) {}
/*  338:     */     
/*  339:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getNextExpirable()
/*  340:     */     {
/*  341: 761 */       return this;
/*  342:     */     }
/*  343:     */     
/*  344:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<Object, Object> next) {}
/*  345:     */     
/*  346:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getPreviousExpirable()
/*  347:     */     {
/*  348: 769 */       return this;
/*  349:     */     }
/*  350:     */     
/*  351:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<Object, Object> previous) {}
/*  352:     */     
/*  353:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getNextEvictable()
/*  354:     */     {
/*  355: 777 */       return this;
/*  356:     */     }
/*  357:     */     
/*  358:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<Object, Object> next) {}
/*  359:     */     
/*  360:     */     public MapMakerInternalMap.ReferenceEntry<Object, Object> getPreviousEvictable()
/*  361:     */     {
/*  362: 785 */       return this;
/*  363:     */     }
/*  364:     */     
/*  365:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<Object, Object> previous) {}
/*  366:     */   }
/*  367:     */   
/*  368:     */   static abstract class AbstractReferenceEntry<K, V>
/*  369:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  370:     */   {
/*  371:     */     public MapMakerInternalMap.ValueReference<K, V> getValueReference()
/*  372:     */     {
/*  373: 795 */       throw new UnsupportedOperationException();
/*  374:     */     }
/*  375:     */     
/*  376:     */     public void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/*  377:     */     {
/*  378: 800 */       throw new UnsupportedOperationException();
/*  379:     */     }
/*  380:     */     
/*  381:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNext()
/*  382:     */     {
/*  383: 805 */       throw new UnsupportedOperationException();
/*  384:     */     }
/*  385:     */     
/*  386:     */     public int getHash()
/*  387:     */     {
/*  388: 810 */       throw new UnsupportedOperationException();
/*  389:     */     }
/*  390:     */     
/*  391:     */     public K getKey()
/*  392:     */     {
/*  393: 815 */       throw new UnsupportedOperationException();
/*  394:     */     }
/*  395:     */     
/*  396:     */     public long getExpirationTime()
/*  397:     */     {
/*  398: 820 */       throw new UnsupportedOperationException();
/*  399:     */     }
/*  400:     */     
/*  401:     */     public void setExpirationTime(long time)
/*  402:     */     {
/*  403: 825 */       throw new UnsupportedOperationException();
/*  404:     */     }
/*  405:     */     
/*  406:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  407:     */     {
/*  408: 830 */       throw new UnsupportedOperationException();
/*  409:     */     }
/*  410:     */     
/*  411:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  412:     */     {
/*  413: 835 */       throw new UnsupportedOperationException();
/*  414:     */     }
/*  415:     */     
/*  416:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  417:     */     {
/*  418: 840 */       throw new UnsupportedOperationException();
/*  419:     */     }
/*  420:     */     
/*  421:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  422:     */     {
/*  423: 845 */       throw new UnsupportedOperationException();
/*  424:     */     }
/*  425:     */     
/*  426:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  427:     */     {
/*  428: 850 */       throw new UnsupportedOperationException();
/*  429:     */     }
/*  430:     */     
/*  431:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  432:     */     {
/*  433: 855 */       throw new UnsupportedOperationException();
/*  434:     */     }
/*  435:     */     
/*  436:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  437:     */     {
/*  438: 860 */       throw new UnsupportedOperationException();
/*  439:     */     }
/*  440:     */     
/*  441:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  442:     */     {
/*  443: 865 */       throw new UnsupportedOperationException();
/*  444:     */     }
/*  445:     */   }
/*  446:     */   
/*  447:     */   static <K, V> ReferenceEntry<K, V> nullEntry()
/*  448:     */   {
/*  449: 871 */     return NullEntry.INSTANCE;
/*  450:     */   }
/*  451:     */   
/*  452: 874 */   static final Queue<? extends Object> DISCARDING_QUEUE = new AbstractQueue()
/*  453:     */   {
/*  454:     */     public boolean offer(Object o)
/*  455:     */     {
/*  456: 878 */       return true;
/*  457:     */     }
/*  458:     */     
/*  459:     */     public Object peek()
/*  460:     */     {
/*  461: 883 */       return null;
/*  462:     */     }
/*  463:     */     
/*  464:     */     public Object poll()
/*  465:     */     {
/*  466: 888 */       return null;
/*  467:     */     }
/*  468:     */     
/*  469:     */     public int size()
/*  470:     */     {
/*  471: 893 */       return 0;
/*  472:     */     }
/*  473:     */     
/*  474:     */     public Iterator<Object> iterator()
/*  475:     */     {
/*  476: 898 */       return Iterators.emptyIterator();
/*  477:     */     }
/*  478:     */   };
/*  479:     */   transient Set<K> keySet;
/*  480:     */   transient Collection<V> values;
/*  481:     */   transient Set<Map.Entry<K, V>> entrySet;
/*  482:     */   private static final long serialVersionUID = 5L;
/*  483:     */   
/*  484:     */   static <E> Queue<E> discardingQueue()
/*  485:     */   {
/*  486: 907 */     return DISCARDING_QUEUE;
/*  487:     */   }
/*  488:     */   
/*  489:     */   static class StrongEntry<K, V>
/*  490:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  491:     */   {
/*  492:     */     final K key;
/*  493:     */     final int hash;
/*  494:     */     final MapMakerInternalMap.ReferenceEntry<K, V> next;
/*  495:     */     
/*  496:     */     StrongEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  497:     */     {
/*  498: 925 */       this.key = key;
/*  499: 926 */       this.hash = hash;
/*  500: 927 */       this.next = next;
/*  501:     */     }
/*  502:     */     
/*  503:     */     public K getKey()
/*  504:     */     {
/*  505: 932 */       return this.key;
/*  506:     */     }
/*  507:     */     
/*  508:     */     public long getExpirationTime()
/*  509:     */     {
/*  510: 939 */       throw new UnsupportedOperationException();
/*  511:     */     }
/*  512:     */     
/*  513:     */     public void setExpirationTime(long time)
/*  514:     */     {
/*  515: 944 */       throw new UnsupportedOperationException();
/*  516:     */     }
/*  517:     */     
/*  518:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  519:     */     {
/*  520: 949 */       throw new UnsupportedOperationException();
/*  521:     */     }
/*  522:     */     
/*  523:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  524:     */     {
/*  525: 954 */       throw new UnsupportedOperationException();
/*  526:     */     }
/*  527:     */     
/*  528:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  529:     */     {
/*  530: 959 */       throw new UnsupportedOperationException();
/*  531:     */     }
/*  532:     */     
/*  533:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  534:     */     {
/*  535: 964 */       throw new UnsupportedOperationException();
/*  536:     */     }
/*  537:     */     
/*  538:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  539:     */     {
/*  540: 971 */       throw new UnsupportedOperationException();
/*  541:     */     }
/*  542:     */     
/*  543:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  544:     */     {
/*  545: 976 */       throw new UnsupportedOperationException();
/*  546:     */     }
/*  547:     */     
/*  548:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  549:     */     {
/*  550: 981 */       throw new UnsupportedOperationException();
/*  551:     */     }
/*  552:     */     
/*  553:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  554:     */     {
/*  555: 986 */       throw new UnsupportedOperationException();
/*  556:     */     }
/*  557:     */     
/*  558: 993 */     volatile MapMakerInternalMap.ValueReference<K, V> valueReference = MapMakerInternalMap.unset();
/*  559:     */     
/*  560:     */     public MapMakerInternalMap.ValueReference<K, V> getValueReference()
/*  561:     */     {
/*  562: 997 */       return this.valueReference;
/*  563:     */     }
/*  564:     */     
/*  565:     */     public void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/*  566:     */     {
/*  567:1002 */       MapMakerInternalMap.ValueReference<K, V> previous = this.valueReference;
/*  568:1003 */       this.valueReference = valueReference;
/*  569:1004 */       previous.clear(valueReference);
/*  570:     */     }
/*  571:     */     
/*  572:     */     public int getHash()
/*  573:     */     {
/*  574:1009 */       return this.hash;
/*  575:     */     }
/*  576:     */     
/*  577:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNext()
/*  578:     */     {
/*  579:1014 */       return this.next;
/*  580:     */     }
/*  581:     */   }
/*  582:     */   
/*  583:     */   static final class StrongExpirableEntry<K, V>
/*  584:     */     extends MapMakerInternalMap.StrongEntry<K, V>
/*  585:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  586:     */   {
/*  587:     */     StrongExpirableEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  588:     */     {
/*  589:1021 */       super(hash, next);
/*  590:     */     }
/*  591:     */     
/*  592:1026 */     volatile long time = 9223372036854775807L;
/*  593:     */     
/*  594:     */     public long getExpirationTime()
/*  595:     */     {
/*  596:1030 */       return this.time;
/*  597:     */     }
/*  598:     */     
/*  599:     */     public void setExpirationTime(long time)
/*  600:     */     {
/*  601:1035 */       this.time = time;
/*  602:     */     }
/*  603:     */     
/*  604:1039 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/*  605:     */     
/*  606:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  607:     */     {
/*  608:1043 */       return this.nextExpirable;
/*  609:     */     }
/*  610:     */     
/*  611:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  612:     */     {
/*  613:1048 */       this.nextExpirable = next;
/*  614:     */     }
/*  615:     */     
/*  616:1052 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/*  617:     */     
/*  618:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  619:     */     {
/*  620:1056 */       return this.previousExpirable;
/*  621:     */     }
/*  622:     */     
/*  623:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  624:     */     {
/*  625:1061 */       this.previousExpirable = previous;
/*  626:     */     }
/*  627:     */   }
/*  628:     */   
/*  629:     */   static final class StrongEvictableEntry<K, V>
/*  630:     */     extends MapMakerInternalMap.StrongEntry<K, V>
/*  631:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  632:     */   {
/*  633:     */     StrongEvictableEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  634:     */     {
/*  635:1068 */       super(hash, next);
/*  636:     */     }
/*  637:     */     
/*  638:1074 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/*  639:     */     
/*  640:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  641:     */     {
/*  642:1078 */       return this.nextEvictable;
/*  643:     */     }
/*  644:     */     
/*  645:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  646:     */     {
/*  647:1083 */       this.nextEvictable = next;
/*  648:     */     }
/*  649:     */     
/*  650:1087 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/*  651:     */     
/*  652:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  653:     */     {
/*  654:1091 */       return this.previousEvictable;
/*  655:     */     }
/*  656:     */     
/*  657:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  658:     */     {
/*  659:1096 */       this.previousEvictable = previous;
/*  660:     */     }
/*  661:     */   }
/*  662:     */   
/*  663:     */   static final class StrongExpirableEvictableEntry<K, V>
/*  664:     */     extends MapMakerInternalMap.StrongEntry<K, V>
/*  665:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  666:     */   {
/*  667:     */     StrongExpirableEvictableEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  668:     */     {
/*  669:1103 */       super(hash, next);
/*  670:     */     }
/*  671:     */     
/*  672:1108 */     volatile long time = 9223372036854775807L;
/*  673:     */     
/*  674:     */     public long getExpirationTime()
/*  675:     */     {
/*  676:1112 */       return this.time;
/*  677:     */     }
/*  678:     */     
/*  679:     */     public void setExpirationTime(long time)
/*  680:     */     {
/*  681:1117 */       this.time = time;
/*  682:     */     }
/*  683:     */     
/*  684:1121 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/*  685:     */     
/*  686:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  687:     */     {
/*  688:1125 */       return this.nextExpirable;
/*  689:     */     }
/*  690:     */     
/*  691:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  692:     */     {
/*  693:1130 */       this.nextExpirable = next;
/*  694:     */     }
/*  695:     */     
/*  696:1134 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/*  697:     */     
/*  698:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  699:     */     {
/*  700:1138 */       return this.previousExpirable;
/*  701:     */     }
/*  702:     */     
/*  703:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  704:     */     {
/*  705:1143 */       this.previousExpirable = previous;
/*  706:     */     }
/*  707:     */     
/*  708:1149 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/*  709:     */     
/*  710:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  711:     */     {
/*  712:1153 */       return this.nextEvictable;
/*  713:     */     }
/*  714:     */     
/*  715:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  716:     */     {
/*  717:1158 */       this.nextEvictable = next;
/*  718:     */     }
/*  719:     */     
/*  720:1162 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/*  721:     */     
/*  722:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  723:     */     {
/*  724:1166 */       return this.previousEvictable;
/*  725:     */     }
/*  726:     */     
/*  727:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  728:     */     {
/*  729:1171 */       this.previousEvictable = previous;
/*  730:     */     }
/*  731:     */   }
/*  732:     */   
/*  733:     */   static class SoftEntry<K, V>
/*  734:     */     extends SoftReference<K>
/*  735:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  736:     */   {
/*  737:     */     final int hash;
/*  738:     */     final MapMakerInternalMap.ReferenceEntry<K, V> next;
/*  739:     */     
/*  740:     */     SoftEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  741:     */     {
/*  742:1180 */       super(queue);
/*  743:1181 */       this.hash = hash;
/*  744:1182 */       this.next = next;
/*  745:     */     }
/*  746:     */     
/*  747:     */     public K getKey()
/*  748:     */     {
/*  749:1187 */       return get();
/*  750:     */     }
/*  751:     */     
/*  752:     */     public long getExpirationTime()
/*  753:     */     {
/*  754:1193 */       throw new UnsupportedOperationException();
/*  755:     */     }
/*  756:     */     
/*  757:     */     public void setExpirationTime(long time)
/*  758:     */     {
/*  759:1198 */       throw new UnsupportedOperationException();
/*  760:     */     }
/*  761:     */     
/*  762:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  763:     */     {
/*  764:1203 */       throw new UnsupportedOperationException();
/*  765:     */     }
/*  766:     */     
/*  767:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  768:     */     {
/*  769:1208 */       throw new UnsupportedOperationException();
/*  770:     */     }
/*  771:     */     
/*  772:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  773:     */     {
/*  774:1213 */       throw new UnsupportedOperationException();
/*  775:     */     }
/*  776:     */     
/*  777:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  778:     */     {
/*  779:1218 */       throw new UnsupportedOperationException();
/*  780:     */     }
/*  781:     */     
/*  782:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  783:     */     {
/*  784:1225 */       throw new UnsupportedOperationException();
/*  785:     */     }
/*  786:     */     
/*  787:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  788:     */     {
/*  789:1230 */       throw new UnsupportedOperationException();
/*  790:     */     }
/*  791:     */     
/*  792:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  793:     */     {
/*  794:1235 */       throw new UnsupportedOperationException();
/*  795:     */     }
/*  796:     */     
/*  797:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  798:     */     {
/*  799:1240 */       throw new UnsupportedOperationException();
/*  800:     */     }
/*  801:     */     
/*  802:1247 */     volatile MapMakerInternalMap.ValueReference<K, V> valueReference = MapMakerInternalMap.unset();
/*  803:     */     
/*  804:     */     public MapMakerInternalMap.ValueReference<K, V> getValueReference()
/*  805:     */     {
/*  806:1251 */       return this.valueReference;
/*  807:     */     }
/*  808:     */     
/*  809:     */     public void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/*  810:     */     {
/*  811:1256 */       MapMakerInternalMap.ValueReference<K, V> previous = this.valueReference;
/*  812:1257 */       this.valueReference = valueReference;
/*  813:1258 */       previous.clear(valueReference);
/*  814:     */     }
/*  815:     */     
/*  816:     */     public int getHash()
/*  817:     */     {
/*  818:1263 */       return this.hash;
/*  819:     */     }
/*  820:     */     
/*  821:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNext()
/*  822:     */     {
/*  823:1268 */       return this.next;
/*  824:     */     }
/*  825:     */   }
/*  826:     */   
/*  827:     */   static final class SoftExpirableEntry<K, V>
/*  828:     */     extends MapMakerInternalMap.SoftEntry<K, V>
/*  829:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  830:     */   {
/*  831:     */     SoftExpirableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  832:     */     {
/*  833:1276 */       super(key, hash, next);
/*  834:     */     }
/*  835:     */     
/*  836:1281 */     volatile long time = 9223372036854775807L;
/*  837:     */     
/*  838:     */     public long getExpirationTime()
/*  839:     */     {
/*  840:1285 */       return this.time;
/*  841:     */     }
/*  842:     */     
/*  843:     */     public void setExpirationTime(long time)
/*  844:     */     {
/*  845:1290 */       this.time = time;
/*  846:     */     }
/*  847:     */     
/*  848:1294 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/*  849:     */     
/*  850:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  851:     */     {
/*  852:1298 */       return this.nextExpirable;
/*  853:     */     }
/*  854:     */     
/*  855:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  856:     */     {
/*  857:1303 */       this.nextExpirable = next;
/*  858:     */     }
/*  859:     */     
/*  860:1307 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/*  861:     */     
/*  862:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  863:     */     {
/*  864:1311 */       return this.previousExpirable;
/*  865:     */     }
/*  866:     */     
/*  867:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  868:     */     {
/*  869:1316 */       this.previousExpirable = previous;
/*  870:     */     }
/*  871:     */   }
/*  872:     */   
/*  873:     */   static final class SoftEvictableEntry<K, V>
/*  874:     */     extends MapMakerInternalMap.SoftEntry<K, V>
/*  875:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  876:     */   {
/*  877:     */     SoftEvictableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  878:     */     {
/*  879:1324 */       super(key, hash, next);
/*  880:     */     }
/*  881:     */     
/*  882:1330 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/*  883:     */     
/*  884:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  885:     */     {
/*  886:1334 */       return this.nextEvictable;
/*  887:     */     }
/*  888:     */     
/*  889:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  890:     */     {
/*  891:1339 */       this.nextEvictable = next;
/*  892:     */     }
/*  893:     */     
/*  894:1343 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/*  895:     */     
/*  896:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  897:     */     {
/*  898:1347 */       return this.previousEvictable;
/*  899:     */     }
/*  900:     */     
/*  901:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  902:     */     {
/*  903:1352 */       this.previousEvictable = previous;
/*  904:     */     }
/*  905:     */   }
/*  906:     */   
/*  907:     */   static final class SoftExpirableEvictableEntry<K, V>
/*  908:     */     extends MapMakerInternalMap.SoftEntry<K, V>
/*  909:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  910:     */   {
/*  911:     */     SoftExpirableEvictableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  912:     */     {
/*  913:1360 */       super(key, hash, next);
/*  914:     */     }
/*  915:     */     
/*  916:1365 */     volatile long time = 9223372036854775807L;
/*  917:     */     
/*  918:     */     public long getExpirationTime()
/*  919:     */     {
/*  920:1369 */       return this.time;
/*  921:     */     }
/*  922:     */     
/*  923:     */     public void setExpirationTime(long time)
/*  924:     */     {
/*  925:1374 */       this.time = time;
/*  926:     */     }
/*  927:     */     
/*  928:1378 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/*  929:     */     
/*  930:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/*  931:     */     {
/*  932:1382 */       return this.nextExpirable;
/*  933:     */     }
/*  934:     */     
/*  935:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  936:     */     {
/*  937:1387 */       this.nextExpirable = next;
/*  938:     */     }
/*  939:     */     
/*  940:1391 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/*  941:     */     
/*  942:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/*  943:     */     {
/*  944:1395 */       return this.previousExpirable;
/*  945:     */     }
/*  946:     */     
/*  947:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  948:     */     {
/*  949:1400 */       this.previousExpirable = previous;
/*  950:     */     }
/*  951:     */     
/*  952:1406 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/*  953:     */     
/*  954:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/*  955:     */     {
/*  956:1410 */       return this.nextEvictable;
/*  957:     */     }
/*  958:     */     
/*  959:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  960:     */     {
/*  961:1415 */       this.nextEvictable = next;
/*  962:     */     }
/*  963:     */     
/*  964:1419 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/*  965:     */     
/*  966:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/*  967:     */     {
/*  968:1423 */       return this.previousEvictable;
/*  969:     */     }
/*  970:     */     
/*  971:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/*  972:     */     {
/*  973:1428 */       this.previousEvictable = previous;
/*  974:     */     }
/*  975:     */   }
/*  976:     */   
/*  977:     */   static class WeakEntry<K, V>
/*  978:     */     extends WeakReference<K>
/*  979:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/*  980:     */   {
/*  981:     */     final int hash;
/*  982:     */     final MapMakerInternalMap.ReferenceEntry<K, V> next;
/*  983:     */     
/*  984:     */     WeakEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/*  985:     */     {
/*  986:1437 */       super(queue);
/*  987:1438 */       this.hash = hash;
/*  988:1439 */       this.next = next;
/*  989:     */     }
/*  990:     */     
/*  991:     */     public K getKey()
/*  992:     */     {
/*  993:1444 */       return get();
/*  994:     */     }
/*  995:     */     
/*  996:     */     public long getExpirationTime()
/*  997:     */     {
/*  998:1451 */       throw new UnsupportedOperationException();
/*  999:     */     }
/* 1000:     */     
/* 1001:     */     public void setExpirationTime(long time)
/* 1002:     */     {
/* 1003:1456 */       throw new UnsupportedOperationException();
/* 1004:     */     }
/* 1005:     */     
/* 1006:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/* 1007:     */     {
/* 1008:1461 */       throw new UnsupportedOperationException();
/* 1009:     */     }
/* 1010:     */     
/* 1011:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1012:     */     {
/* 1013:1466 */       throw new UnsupportedOperationException();
/* 1014:     */     }
/* 1015:     */     
/* 1016:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/* 1017:     */     {
/* 1018:1471 */       throw new UnsupportedOperationException();
/* 1019:     */     }
/* 1020:     */     
/* 1021:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1022:     */     {
/* 1023:1476 */       throw new UnsupportedOperationException();
/* 1024:     */     }
/* 1025:     */     
/* 1026:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/* 1027:     */     {
/* 1028:1483 */       throw new UnsupportedOperationException();
/* 1029:     */     }
/* 1030:     */     
/* 1031:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1032:     */     {
/* 1033:1488 */       throw new UnsupportedOperationException();
/* 1034:     */     }
/* 1035:     */     
/* 1036:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/* 1037:     */     {
/* 1038:1493 */       throw new UnsupportedOperationException();
/* 1039:     */     }
/* 1040:     */     
/* 1041:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1042:     */     {
/* 1043:1498 */       throw new UnsupportedOperationException();
/* 1044:     */     }
/* 1045:     */     
/* 1046:1505 */     volatile MapMakerInternalMap.ValueReference<K, V> valueReference = MapMakerInternalMap.unset();
/* 1047:     */     
/* 1048:     */     public MapMakerInternalMap.ValueReference<K, V> getValueReference()
/* 1049:     */     {
/* 1050:1509 */       return this.valueReference;
/* 1051:     */     }
/* 1052:     */     
/* 1053:     */     public void setValueReference(MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 1054:     */     {
/* 1055:1514 */       MapMakerInternalMap.ValueReference<K, V> previous = this.valueReference;
/* 1056:1515 */       this.valueReference = valueReference;
/* 1057:1516 */       previous.clear(valueReference);
/* 1058:     */     }
/* 1059:     */     
/* 1060:     */     public int getHash()
/* 1061:     */     {
/* 1062:1521 */       return this.hash;
/* 1063:     */     }
/* 1064:     */     
/* 1065:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNext()
/* 1066:     */     {
/* 1067:1526 */       return this.next;
/* 1068:     */     }
/* 1069:     */   }
/* 1070:     */   
/* 1071:     */   static final class WeakExpirableEntry<K, V>
/* 1072:     */     extends MapMakerInternalMap.WeakEntry<K, V>
/* 1073:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/* 1074:     */   {
/* 1075:     */     WeakExpirableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1076:     */     {
/* 1077:1534 */       super(key, hash, next);
/* 1078:     */     }
/* 1079:     */     
/* 1080:1539 */     volatile long time = 9223372036854775807L;
/* 1081:     */     
/* 1082:     */     public long getExpirationTime()
/* 1083:     */     {
/* 1084:1543 */       return this.time;
/* 1085:     */     }
/* 1086:     */     
/* 1087:     */     public void setExpirationTime(long time)
/* 1088:     */     {
/* 1089:1548 */       this.time = time;
/* 1090:     */     }
/* 1091:     */     
/* 1092:1552 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/* 1093:     */     
/* 1094:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/* 1095:     */     {
/* 1096:1556 */       return this.nextExpirable;
/* 1097:     */     }
/* 1098:     */     
/* 1099:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1100:     */     {
/* 1101:1561 */       this.nextExpirable = next;
/* 1102:     */     }
/* 1103:     */     
/* 1104:1565 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/* 1105:     */     
/* 1106:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/* 1107:     */     {
/* 1108:1569 */       return this.previousExpirable;
/* 1109:     */     }
/* 1110:     */     
/* 1111:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1112:     */     {
/* 1113:1574 */       this.previousExpirable = previous;
/* 1114:     */     }
/* 1115:     */   }
/* 1116:     */   
/* 1117:     */   static final class WeakEvictableEntry<K, V>
/* 1118:     */     extends MapMakerInternalMap.WeakEntry<K, V>
/* 1119:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/* 1120:     */   {
/* 1121:     */     WeakEvictableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1122:     */     {
/* 1123:1582 */       super(key, hash, next);
/* 1124:     */     }
/* 1125:     */     
/* 1126:1588 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/* 1127:     */     
/* 1128:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/* 1129:     */     {
/* 1130:1592 */       return this.nextEvictable;
/* 1131:     */     }
/* 1132:     */     
/* 1133:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1134:     */     {
/* 1135:1597 */       this.nextEvictable = next;
/* 1136:     */     }
/* 1137:     */     
/* 1138:1601 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/* 1139:     */     
/* 1140:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/* 1141:     */     {
/* 1142:1605 */       return this.previousEvictable;
/* 1143:     */     }
/* 1144:     */     
/* 1145:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1146:     */     {
/* 1147:1610 */       this.previousEvictable = previous;
/* 1148:     */     }
/* 1149:     */   }
/* 1150:     */   
/* 1151:     */   static final class WeakExpirableEvictableEntry<K, V>
/* 1152:     */     extends MapMakerInternalMap.WeakEntry<K, V>
/* 1153:     */     implements MapMakerInternalMap.ReferenceEntry<K, V>
/* 1154:     */   {
/* 1155:     */     WeakExpirableEvictableEntry(ReferenceQueue<K> queue, K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1156:     */     {
/* 1157:1618 */       super(key, hash, next);
/* 1158:     */     }
/* 1159:     */     
/* 1160:1623 */     volatile long time = 9223372036854775807L;
/* 1161:     */     
/* 1162:     */     public long getExpirationTime()
/* 1163:     */     {
/* 1164:1627 */       return this.time;
/* 1165:     */     }
/* 1166:     */     
/* 1167:     */     public void setExpirationTime(long time)
/* 1168:     */     {
/* 1169:1632 */       this.time = time;
/* 1170:     */     }
/* 1171:     */     
/* 1172:1636 */     MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = MapMakerInternalMap.nullEntry();
/* 1173:     */     
/* 1174:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/* 1175:     */     {
/* 1176:1640 */       return this.nextExpirable;
/* 1177:     */     }
/* 1178:     */     
/* 1179:     */     public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1180:     */     {
/* 1181:1645 */       this.nextExpirable = next;
/* 1182:     */     }
/* 1183:     */     
/* 1184:1649 */     MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = MapMakerInternalMap.nullEntry();
/* 1185:     */     
/* 1186:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/* 1187:     */     {
/* 1188:1653 */       return this.previousExpirable;
/* 1189:     */     }
/* 1190:     */     
/* 1191:     */     public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1192:     */     {
/* 1193:1658 */       this.previousExpirable = previous;
/* 1194:     */     }
/* 1195:     */     
/* 1196:1664 */     MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = MapMakerInternalMap.nullEntry();
/* 1197:     */     
/* 1198:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/* 1199:     */     {
/* 1200:1668 */       return this.nextEvictable;
/* 1201:     */     }
/* 1202:     */     
/* 1203:     */     public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1204:     */     {
/* 1205:1673 */       this.nextEvictable = next;
/* 1206:     */     }
/* 1207:     */     
/* 1208:1677 */     MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = MapMakerInternalMap.nullEntry();
/* 1209:     */     
/* 1210:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/* 1211:     */     {
/* 1212:1681 */       return this.previousEvictable;
/* 1213:     */     }
/* 1214:     */     
/* 1215:     */     public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 1216:     */     {
/* 1217:1686 */       this.previousEvictable = previous;
/* 1218:     */     }
/* 1219:     */   }
/* 1220:     */   
/* 1221:     */   static final class WeakValueReference<K, V>
/* 1222:     */     extends WeakReference<V>
/* 1223:     */     implements MapMakerInternalMap.ValueReference<K, V>
/* 1224:     */   {
/* 1225:     */     final MapMakerInternalMap.ReferenceEntry<K, V> entry;
/* 1226:     */     
/* 1227:     */     WeakValueReference(ReferenceQueue<V> queue, V referent, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1228:     */     {
/* 1229:1698 */       super(queue);
/* 1230:1699 */       this.entry = entry;
/* 1231:     */     }
/* 1232:     */     
/* 1233:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 1234:     */     {
/* 1235:1704 */       return this.entry;
/* 1236:     */     }
/* 1237:     */     
/* 1238:     */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue)
/* 1239:     */     {
/* 1240:1709 */       clear();
/* 1241:     */     }
/* 1242:     */     
/* 1243:     */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1244:     */     {
/* 1245:1715 */       return new WeakValueReference(queue, value, entry);
/* 1246:     */     }
/* 1247:     */     
/* 1248:     */     public boolean isComputingReference()
/* 1249:     */     {
/* 1250:1720 */       return false;
/* 1251:     */     }
/* 1252:     */     
/* 1253:     */     public V waitForValue()
/* 1254:     */     {
/* 1255:1725 */       return get();
/* 1256:     */     }
/* 1257:     */   }
/* 1258:     */   
/* 1259:     */   static final class SoftValueReference<K, V>
/* 1260:     */     extends SoftReference<V>
/* 1261:     */     implements MapMakerInternalMap.ValueReference<K, V>
/* 1262:     */   {
/* 1263:     */     final MapMakerInternalMap.ReferenceEntry<K, V> entry;
/* 1264:     */     
/* 1265:     */     SoftValueReference(ReferenceQueue<V> queue, V referent, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1266:     */     {
/* 1267:1737 */       super(queue);
/* 1268:1738 */       this.entry = entry;
/* 1269:     */     }
/* 1270:     */     
/* 1271:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 1272:     */     {
/* 1273:1743 */       return this.entry;
/* 1274:     */     }
/* 1275:     */     
/* 1276:     */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue)
/* 1277:     */     {
/* 1278:1748 */       clear();
/* 1279:     */     }
/* 1280:     */     
/* 1281:     */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1282:     */     {
/* 1283:1754 */       return new SoftValueReference(queue, value, entry);
/* 1284:     */     }
/* 1285:     */     
/* 1286:     */     public boolean isComputingReference()
/* 1287:     */     {
/* 1288:1759 */       return false;
/* 1289:     */     }
/* 1290:     */     
/* 1291:     */     public V waitForValue()
/* 1292:     */     {
/* 1293:1764 */       return get();
/* 1294:     */     }
/* 1295:     */   }
/* 1296:     */   
/* 1297:     */   static final class StrongValueReference<K, V>
/* 1298:     */     implements MapMakerInternalMap.ValueReference<K, V>
/* 1299:     */   {
/* 1300:     */     final V referent;
/* 1301:     */     
/* 1302:     */     StrongValueReference(V referent)
/* 1303:     */     {
/* 1304:1775 */       this.referent = referent;
/* 1305:     */     }
/* 1306:     */     
/* 1307:     */     public V get()
/* 1308:     */     {
/* 1309:1780 */       return this.referent;
/* 1310:     */     }
/* 1311:     */     
/* 1312:     */     public MapMakerInternalMap.ReferenceEntry<K, V> getEntry()
/* 1313:     */     {
/* 1314:1785 */       return null;
/* 1315:     */     }
/* 1316:     */     
/* 1317:     */     public MapMakerInternalMap.ValueReference<K, V> copyFor(ReferenceQueue<V> queue, V value, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1318:     */     {
/* 1319:1791 */       return this;
/* 1320:     */     }
/* 1321:     */     
/* 1322:     */     public boolean isComputingReference()
/* 1323:     */     {
/* 1324:1796 */       return false;
/* 1325:     */     }
/* 1326:     */     
/* 1327:     */     public V waitForValue()
/* 1328:     */     {
/* 1329:1801 */       return get();
/* 1330:     */     }
/* 1331:     */     
/* 1332:     */     public void clear(MapMakerInternalMap.ValueReference<K, V> newValue) {}
/* 1333:     */   }
/* 1334:     */   
/* 1335:     */   static int rehash(int h)
/* 1336:     */   {
/* 1337:1820 */     h += (h << 15 ^ 0xFFFFCD7D);
/* 1338:1821 */     h ^= h >>> 10;
/* 1339:1822 */     h += (h << 3);
/* 1340:1823 */     h ^= h >>> 6;
/* 1341:1824 */     h += (h << 2) + (h << 14);
/* 1342:1825 */     return h ^ h >>> 16;
/* 1343:     */   }
/* 1344:     */   
/* 1345:     */   @VisibleForTesting
/* 1346:     */   ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable ReferenceEntry<K, V> next)
/* 1347:     */   {
/* 1348:1834 */     return segmentFor(hash).newEntry(key, hash, next);
/* 1349:     */   }
/* 1350:     */   
/* 1351:     */   @VisibleForTesting
/* 1352:     */   ReferenceEntry<K, V> copyEntry(ReferenceEntry<K, V> original, ReferenceEntry<K, V> newNext)
/* 1353:     */   {
/* 1354:1843 */     int hash = original.getHash();
/* 1355:1844 */     return segmentFor(hash).copyEntry(original, newNext);
/* 1356:     */   }
/* 1357:     */   
/* 1358:     */   @VisibleForTesting
/* 1359:     */   ValueReference<K, V> newValueReference(ReferenceEntry<K, V> entry, V value)
/* 1360:     */   {
/* 1361:1853 */     int hash = entry.getHash();
/* 1362:1854 */     return this.valueStrength.referenceValue(segmentFor(hash), entry, value);
/* 1363:     */   }
/* 1364:     */   
/* 1365:     */   int hash(Object key)
/* 1366:     */   {
/* 1367:1858 */     int h = this.keyEquivalence.hash(key);
/* 1368:1859 */     return rehash(h);
/* 1369:     */   }
/* 1370:     */   
/* 1371:     */   void reclaimValue(ValueReference<K, V> valueReference)
/* 1372:     */   {
/* 1373:1863 */     ReferenceEntry<K, V> entry = valueReference.getEntry();
/* 1374:1864 */     int hash = entry.getHash();
/* 1375:1865 */     segmentFor(hash).reclaimValue(entry.getKey(), hash, valueReference);
/* 1376:     */   }
/* 1377:     */   
/* 1378:     */   void reclaimKey(ReferenceEntry<K, V> entry)
/* 1379:     */   {
/* 1380:1869 */     int hash = entry.getHash();
/* 1381:1870 */     segmentFor(hash).reclaimKey(entry, hash);
/* 1382:     */   }
/* 1383:     */   
/* 1384:     */   @VisibleForTesting
/* 1385:     */   boolean isLive(ReferenceEntry<K, V> entry)
/* 1386:     */   {
/* 1387:1879 */     return segmentFor(entry.getHash()).getLiveValue(entry) != null;
/* 1388:     */   }
/* 1389:     */   
/* 1390:     */   Segment<K, V> segmentFor(int hash)
/* 1391:     */   {
/* 1392:1890 */     return this.segments[(hash >>> this.segmentShift & this.segmentMask)];
/* 1393:     */   }
/* 1394:     */   
/* 1395:     */   Segment<K, V> createSegment(int initialCapacity, int maxSegmentSize)
/* 1396:     */   {
/* 1397:1894 */     return new Segment(this, initialCapacity, maxSegmentSize);
/* 1398:     */   }
/* 1399:     */   
/* 1400:     */   V getLiveValue(ReferenceEntry<K, V> entry)
/* 1401:     */   {
/* 1402:1903 */     if (entry.getKey() == null) {
/* 1403:1904 */       return null;
/* 1404:     */     }
/* 1405:1906 */     V value = entry.getValueReference().get();
/* 1406:1907 */     if (value == null) {
/* 1407:1908 */       return null;
/* 1408:     */     }
/* 1409:1911 */     if ((expires()) && (isExpired(entry))) {
/* 1410:1912 */       return null;
/* 1411:     */     }
/* 1412:1914 */     return value;
/* 1413:     */   }
/* 1414:     */   
/* 1415:     */   boolean isExpired(ReferenceEntry<K, V> entry)
/* 1416:     */   {
/* 1417:1923 */     return isExpired(entry, this.ticker.read());
/* 1418:     */   }
/* 1419:     */   
/* 1420:     */   boolean isExpired(ReferenceEntry<K, V> entry, long now)
/* 1421:     */   {
/* 1422:1931 */     return now - entry.getExpirationTime() > 0L;
/* 1423:     */   }
/* 1424:     */   
/* 1425:     */   static <K, V> void connectExpirables(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next)
/* 1426:     */   {
/* 1427:1936 */     previous.setNextExpirable(next);
/* 1428:1937 */     next.setPreviousExpirable(previous);
/* 1429:     */   }
/* 1430:     */   
/* 1431:     */   static <K, V> void nullifyExpirable(ReferenceEntry<K, V> nulled)
/* 1432:     */   {
/* 1433:1942 */     ReferenceEntry<K, V> nullEntry = nullEntry();
/* 1434:1943 */     nulled.setNextExpirable(nullEntry);
/* 1435:1944 */     nulled.setPreviousExpirable(nullEntry);
/* 1436:     */   }
/* 1437:     */   
/* 1438:     */   void processPendingNotifications()
/* 1439:     */   {
/* 1440:     */     MapMaker.RemovalNotification<K, V> notification;
/* 1441:1956 */     while ((notification = (MapMaker.RemovalNotification)this.removalNotificationQueue.poll()) != null) {
/* 1442:     */       try
/* 1443:     */       {
/* 1444:1958 */         this.removalListener.onRemoval(notification);
/* 1445:     */       }
/* 1446:     */       catch (Exception e)
/* 1447:     */       {
/* 1448:1960 */         logger.log(Level.WARNING, "Exception thrown by removal listener", e);
/* 1449:     */       }
/* 1450:     */     }
/* 1451:     */   }
/* 1452:     */   
/* 1453:     */   static <K, V> void connectEvictables(ReferenceEntry<K, V> previous, ReferenceEntry<K, V> next)
/* 1454:     */   {
/* 1455:1968 */     previous.setNextEvictable(next);
/* 1456:1969 */     next.setPreviousEvictable(previous);
/* 1457:     */   }
/* 1458:     */   
/* 1459:     */   static <K, V> void nullifyEvictable(ReferenceEntry<K, V> nulled)
/* 1460:     */   {
/* 1461:1974 */     ReferenceEntry<K, V> nullEntry = nullEntry();
/* 1462:1975 */     nulled.setNextEvictable(nullEntry);
/* 1463:1976 */     nulled.setPreviousEvictable(nullEntry);
/* 1464:     */   }
/* 1465:     */   
/* 1466:     */   final Segment<K, V>[] newSegmentArray(int ssize)
/* 1467:     */   {
/* 1468:1981 */     return new Segment[ssize];
/* 1469:     */   }
/* 1470:     */   
/* 1471:     */   static class Segment<K, V>
/* 1472:     */     extends ReentrantLock
/* 1473:     */   {
/* 1474:     */     @Weak
/* 1475:     */     final MapMakerInternalMap<K, V> map;
/* 1476:     */     volatile int count;
/* 1477:     */     int modCount;
/* 1478:     */     int threshold;
/* 1479:     */     volatile AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table;
/* 1480:     */     final int maxSegmentSize;
/* 1481:     */     final ReferenceQueue<K> keyReferenceQueue;
/* 1482:     */     final ReferenceQueue<V> valueReferenceQueue;
/* 1483:     */     final Queue<MapMakerInternalMap.ReferenceEntry<K, V>> recencyQueue;
/* 1484:2081 */     final AtomicInteger readCount = new AtomicInteger();
/* 1485:     */     @GuardedBy("this")
/* 1486:     */     final Queue<MapMakerInternalMap.ReferenceEntry<K, V>> evictionQueue;
/* 1487:     */     @GuardedBy("this")
/* 1488:     */     final Queue<MapMakerInternalMap.ReferenceEntry<K, V>> expirationQueue;
/* 1489:     */     
/* 1490:     */     Segment(MapMakerInternalMap<K, V> map, int initialCapacity, int maxSegmentSize)
/* 1491:     */     {
/* 1492:2098 */       this.map = map;
/* 1493:2099 */       this.maxSegmentSize = maxSegmentSize;
/* 1494:2100 */       initTable(newEntryArray(initialCapacity));
/* 1495:     */       
/* 1496:2102 */       this.keyReferenceQueue = (map.usesKeyReferences() ? new ReferenceQueue() : null);
/* 1497:     */       
/* 1498:2104 */       this.valueReferenceQueue = (map.usesValueReferences() ? new ReferenceQueue() : null);
/* 1499:     */       
/* 1500:2106 */       this.recencyQueue = ((map.evictsBySize()) || (map.expiresAfterAccess()) ? new ConcurrentLinkedQueue() : MapMakerInternalMap.discardingQueue());
/* 1501:     */       
/* 1502:     */ 
/* 1503:     */ 
/* 1504:     */ 
/* 1505:2111 */       this.evictionQueue = (map.evictsBySize() ? new MapMakerInternalMap.EvictionQueue() : MapMakerInternalMap.discardingQueue());
/* 1506:     */       
/* 1507:     */ 
/* 1508:     */ 
/* 1509:     */ 
/* 1510:2116 */       this.expirationQueue = (map.expires() ? new MapMakerInternalMap.ExpirationQueue() : MapMakerInternalMap.discardingQueue());
/* 1511:     */     }
/* 1512:     */     
/* 1513:     */     AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> newEntryArray(int size)
/* 1514:     */     {
/* 1515:2123 */       return new AtomicReferenceArray(size);
/* 1516:     */     }
/* 1517:     */     
/* 1518:     */     void initTable(AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> newTable)
/* 1519:     */     {
/* 1520:2127 */       this.threshold = (newTable.length() * 3 / 4);
/* 1521:2128 */       if (this.threshold == this.maxSegmentSize) {
/* 1522:2130 */         this.threshold += 1;
/* 1523:     */       }
/* 1524:2132 */       this.table = newTable;
/* 1525:     */     }
/* 1526:     */     
/* 1527:     */     @GuardedBy("this")
/* 1528:     */     MapMakerInternalMap.ReferenceEntry<K, V> newEntry(K key, int hash, @Nullable MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 1529:     */     {
/* 1530:2137 */       return this.map.entryFactory.newEntry(this, key, hash, next);
/* 1531:     */     }
/* 1532:     */     
/* 1533:     */     @GuardedBy("this")
/* 1534:     */     MapMakerInternalMap.ReferenceEntry<K, V> copyEntry(MapMakerInternalMap.ReferenceEntry<K, V> original, MapMakerInternalMap.ReferenceEntry<K, V> newNext)
/* 1535:     */     {
/* 1536:2146 */       if (original.getKey() == null) {
/* 1537:2148 */         return null;
/* 1538:     */       }
/* 1539:2151 */       MapMakerInternalMap.ValueReference<K, V> valueReference = original.getValueReference();
/* 1540:2152 */       V value = valueReference.get();
/* 1541:2153 */       if ((value == null) && (!valueReference.isComputingReference())) {
/* 1542:2155 */         return null;
/* 1543:     */       }
/* 1544:2158 */       MapMakerInternalMap.ReferenceEntry<K, V> newEntry = this.map.entryFactory.copyEntry(this, original, newNext);
/* 1545:2159 */       newEntry.setValueReference(valueReference.copyFor(this.valueReferenceQueue, value, newEntry));
/* 1546:2160 */       return newEntry;
/* 1547:     */     }
/* 1548:     */     
/* 1549:     */     @GuardedBy("this")
/* 1550:     */     void setValue(MapMakerInternalMap.ReferenceEntry<K, V> entry, V value)
/* 1551:     */     {
/* 1552:2168 */       MapMakerInternalMap.ValueReference<K, V> valueReference = this.map.valueStrength.referenceValue(this, entry, value);
/* 1553:2169 */       entry.setValueReference(valueReference);
/* 1554:2170 */       recordWrite(entry);
/* 1555:     */     }
/* 1556:     */     
/* 1557:     */     void tryDrainReferenceQueues()
/* 1558:     */     {
/* 1559:2179 */       if (tryLock()) {
/* 1560:     */         try
/* 1561:     */         {
/* 1562:2181 */           drainReferenceQueues();
/* 1563:     */         }
/* 1564:     */         finally
/* 1565:     */         {
/* 1566:2183 */           unlock();
/* 1567:     */         }
/* 1568:     */       }
/* 1569:     */     }
/* 1570:     */     
/* 1571:     */     @GuardedBy("this")
/* 1572:     */     void drainReferenceQueues()
/* 1573:     */     {
/* 1574:2194 */       if (this.map.usesKeyReferences()) {
/* 1575:2195 */         drainKeyReferenceQueue();
/* 1576:     */       }
/* 1577:2197 */       if (this.map.usesValueReferences()) {
/* 1578:2198 */         drainValueReferenceQueue();
/* 1579:     */       }
/* 1580:     */     }
/* 1581:     */     
/* 1582:     */     @GuardedBy("this")
/* 1583:     */     void drainKeyReferenceQueue()
/* 1584:     */     {
/* 1585:2205 */       int i = 0;
/* 1586:     */       Reference<? extends K> ref;
/* 1587:2206 */       for (; (ref = this.keyReferenceQueue.poll()) != null; i == 16)
/* 1588:     */       {
/* 1589:2208 */         MapMakerInternalMap.ReferenceEntry<K, V> entry = (MapMakerInternalMap.ReferenceEntry)ref;
/* 1590:2209 */         this.map.reclaimKey(entry);
/* 1591:2210 */         i++;
/* 1592:     */       }
/* 1593:     */     }
/* 1594:     */     
/* 1595:     */     @GuardedBy("this")
/* 1596:     */     void drainValueReferenceQueue()
/* 1597:     */     {
/* 1598:2219 */       int i = 0;
/* 1599:     */       Reference<? extends V> ref;
/* 1600:2220 */       for (; (ref = this.valueReferenceQueue.poll()) != null; i == 16)
/* 1601:     */       {
/* 1602:2222 */         MapMakerInternalMap.ValueReference<K, V> valueReference = (MapMakerInternalMap.ValueReference)ref;
/* 1603:2223 */         this.map.reclaimValue(valueReference);
/* 1604:2224 */         i++;
/* 1605:     */       }
/* 1606:     */     }
/* 1607:     */     
/* 1608:     */     void clearReferenceQueues()
/* 1609:     */     {
/* 1610:2234 */       if (this.map.usesKeyReferences()) {
/* 1611:2235 */         clearKeyReferenceQueue();
/* 1612:     */       }
/* 1613:2237 */       if (this.map.usesValueReferences()) {
/* 1614:2238 */         clearValueReferenceQueue();
/* 1615:     */       }
/* 1616:     */     }
/* 1617:     */     
/* 1618:     */     void clearKeyReferenceQueue()
/* 1619:     */     {
/* 1620:2243 */       while (this.keyReferenceQueue.poll() != null) {}
/* 1621:     */     }
/* 1622:     */     
/* 1623:     */     void clearValueReferenceQueue()
/* 1624:     */     {
/* 1625:2247 */       while (this.valueReferenceQueue.poll() != null) {}
/* 1626:     */     }
/* 1627:     */     
/* 1628:     */     void recordRead(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1629:     */     {
/* 1630:2260 */       if (this.map.expiresAfterAccess()) {
/* 1631:2261 */         recordExpirationTime(entry, this.map.expireAfterAccessNanos);
/* 1632:     */       }
/* 1633:2263 */       this.recencyQueue.add(entry);
/* 1634:     */     }
/* 1635:     */     
/* 1636:     */     @GuardedBy("this")
/* 1637:     */     void recordLockedRead(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1638:     */     {
/* 1639:2275 */       this.evictionQueue.add(entry);
/* 1640:2276 */       if (this.map.expiresAfterAccess())
/* 1641:     */       {
/* 1642:2277 */         recordExpirationTime(entry, this.map.expireAfterAccessNanos);
/* 1643:2278 */         this.expirationQueue.add(entry);
/* 1644:     */       }
/* 1645:     */     }
/* 1646:     */     
/* 1647:     */     @GuardedBy("this")
/* 1648:     */     void recordWrite(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 1649:     */     {
/* 1650:2289 */       drainRecencyQueue();
/* 1651:2290 */       this.evictionQueue.add(entry);
/* 1652:2291 */       if (this.map.expires())
/* 1653:     */       {
/* 1654:2294 */         long expiration = this.map.expiresAfterAccess() ? this.map.expireAfterAccessNanos : this.map.expireAfterWriteNanos;
/* 1655:     */         
/* 1656:2296 */         recordExpirationTime(entry, expiration);
/* 1657:2297 */         this.expirationQueue.add(entry);
/* 1658:     */       }
/* 1659:     */     }
/* 1660:     */     
/* 1661:     */     @GuardedBy("this")
/* 1662:     */     void drainRecencyQueue()
/* 1663:     */     {
/* 1664:     */       MapMakerInternalMap.ReferenceEntry<K, V> e;
/* 1665:2310 */       while ((e = (MapMakerInternalMap.ReferenceEntry)this.recencyQueue.poll()) != null)
/* 1666:     */       {
/* 1667:2315 */         if (this.evictionQueue.contains(e)) {
/* 1668:2316 */           this.evictionQueue.add(e);
/* 1669:     */         }
/* 1670:2318 */         if ((this.map.expiresAfterAccess()) && (this.expirationQueue.contains(e))) {
/* 1671:2319 */           this.expirationQueue.add(e);
/* 1672:     */         }
/* 1673:     */       }
/* 1674:     */     }
/* 1675:     */     
/* 1676:     */     void recordExpirationTime(MapMakerInternalMap.ReferenceEntry<K, V> entry, long expirationNanos)
/* 1677:     */     {
/* 1678:2328 */       entry.setExpirationTime(this.map.ticker.read() + expirationNanos);
/* 1679:     */     }
/* 1680:     */     
/* 1681:     */     void tryExpireEntries()
/* 1682:     */     {
/* 1683:2335 */       if (tryLock()) {
/* 1684:     */         try
/* 1685:     */         {
/* 1686:2337 */           expireEntries();
/* 1687:     */         }
/* 1688:     */         finally
/* 1689:     */         {
/* 1690:2339 */           unlock();
/* 1691:     */         }
/* 1692:     */       }
/* 1693:     */     }
/* 1694:     */     
/* 1695:     */     @GuardedBy("this")
/* 1696:     */     void expireEntries()
/* 1697:     */     {
/* 1698:2347 */       drainRecencyQueue();
/* 1699:2349 */       if (this.expirationQueue.isEmpty()) {
/* 1700:2352 */         return;
/* 1701:     */       }
/* 1702:2354 */       long now = this.map.ticker.read();
/* 1703:     */       MapMakerInternalMap.ReferenceEntry<K, V> e;
/* 1704:2356 */       while (((e = (MapMakerInternalMap.ReferenceEntry)this.expirationQueue.peek()) != null) && (this.map.isExpired(e, now))) {
/* 1705:2357 */         if (!removeEntry(e, e.getHash(), MapMaker.RemovalCause.EXPIRED)) {
/* 1706:2358 */           throw new AssertionError();
/* 1707:     */         }
/* 1708:     */       }
/* 1709:     */     }
/* 1710:     */     
/* 1711:     */     void enqueueNotification(MapMakerInternalMap.ReferenceEntry<K, V> entry, MapMaker.RemovalCause cause)
/* 1712:     */     {
/* 1713:2366 */       enqueueNotification(entry.getKey(), entry.getHash(), entry.getValueReference().get(), cause);
/* 1714:     */     }
/* 1715:     */     
/* 1716:     */     void enqueueNotification(@Nullable K key, int hash, @Nullable V value, MapMaker.RemovalCause cause)
/* 1717:     */     {
/* 1718:2370 */       if (this.map.removalNotificationQueue != MapMakerInternalMap.DISCARDING_QUEUE)
/* 1719:     */       {
/* 1720:2371 */         MapMaker.RemovalNotification<K, V> notification = new MapMaker.RemovalNotification(key, value, cause);
/* 1721:2372 */         this.map.removalNotificationQueue.offer(notification);
/* 1722:     */       }
/* 1723:     */     }
/* 1724:     */     
/* 1725:     */     @GuardedBy("this")
/* 1726:     */     boolean evictEntries()
/* 1727:     */     {
/* 1728:2384 */       if ((this.map.evictsBySize()) && (this.count >= this.maxSegmentSize))
/* 1729:     */       {
/* 1730:2385 */         drainRecencyQueue();
/* 1731:     */         
/* 1732:2387 */         MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)this.evictionQueue.remove();
/* 1733:2388 */         if (!removeEntry(e, e.getHash(), MapMaker.RemovalCause.SIZE)) {
/* 1734:2389 */           throw new AssertionError();
/* 1735:     */         }
/* 1736:2391 */         return true;
/* 1737:     */       }
/* 1738:2393 */       return false;
/* 1739:     */     }
/* 1740:     */     
/* 1741:     */     MapMakerInternalMap.ReferenceEntry<K, V> getFirst(int hash)
/* 1742:     */     {
/* 1743:2401 */       AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 1744:2402 */       return (MapMakerInternalMap.ReferenceEntry)table.get(hash & table.length() - 1);
/* 1745:     */     }
/* 1746:     */     
/* 1747:     */     MapMakerInternalMap.ReferenceEntry<K, V> getEntry(Object key, int hash)
/* 1748:     */     {
/* 1749:2408 */       if (this.count != 0) {
/* 1750:2409 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = getFirst(hash); e != null; e = e.getNext()) {
/* 1751:2410 */           if (e.getHash() == hash)
/* 1752:     */           {
/* 1753:2414 */             K entryKey = e.getKey();
/* 1754:2415 */             if (entryKey == null) {
/* 1755:2416 */               tryDrainReferenceQueues();
/* 1756:2420 */             } else if (this.map.keyEquivalence.equivalent(key, entryKey)) {
/* 1757:2421 */               return e;
/* 1758:     */             }
/* 1759:     */           }
/* 1760:     */         }
/* 1761:     */       }
/* 1762:2426 */       return null;
/* 1763:     */     }
/* 1764:     */     
/* 1765:     */     MapMakerInternalMap.ReferenceEntry<K, V> getLiveEntry(Object key, int hash)
/* 1766:     */     {
/* 1767:2430 */       MapMakerInternalMap.ReferenceEntry<K, V> e = getEntry(key, hash);
/* 1768:2431 */       if (e == null) {
/* 1769:2432 */         return null;
/* 1770:     */       }
/* 1771:2433 */       if ((this.map.expires()) && (this.map.isExpired(e)))
/* 1772:     */       {
/* 1773:2434 */         tryExpireEntries();
/* 1774:2435 */         return null;
/* 1775:     */       }
/* 1776:2437 */       return e;
/* 1777:     */     }
/* 1778:     */     
/* 1779:     */     V get(Object key, int hash)
/* 1780:     */     {
/* 1781:     */       try
/* 1782:     */       {
/* 1783:2442 */         MapMakerInternalMap.ReferenceEntry<K, V> e = getLiveEntry(key, hash);
/* 1784:2443 */         if (e == null) {
/* 1785:2444 */           return null;
/* 1786:     */         }
/* 1787:2447 */         Object value = e.getValueReference().get();
/* 1788:2448 */         if (value != null) {
/* 1789:2449 */           recordRead(e);
/* 1790:     */         } else {
/* 1791:2451 */           tryDrainReferenceQueues();
/* 1792:     */         }
/* 1793:2453 */         return value;
/* 1794:     */       }
/* 1795:     */       finally
/* 1796:     */       {
/* 1797:2455 */         postReadCleanup();
/* 1798:     */       }
/* 1799:     */     }
/* 1800:     */     
/* 1801:     */     boolean containsKey(Object key, int hash)
/* 1802:     */     {
/* 1803:     */       try
/* 1804:     */       {
/* 1805:     */         MapMakerInternalMap.ReferenceEntry<K, V> e;
/* 1806:2461 */         if (this.count != 0)
/* 1807:     */         {
/* 1808:2462 */           e = getLiveEntry(key, hash);
/* 1809:     */           boolean bool;
/* 1810:2463 */           if (e == null) {
/* 1811:2464 */             return false;
/* 1812:     */           }
/* 1813:2466 */           return e.getValueReference().get() != null;
/* 1814:     */         }
/* 1815:2469 */         return 0;
/* 1816:     */       }
/* 1817:     */       finally
/* 1818:     */       {
/* 1819:2471 */         postReadCleanup();
/* 1820:     */       }
/* 1821:     */     }
/* 1822:     */     
/* 1823:     */     @VisibleForTesting
/* 1824:     */     boolean containsValue(Object value)
/* 1825:     */     {
/* 1826:     */       try
/* 1827:     */       {
/* 1828:     */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table;
/* 1829:2482 */         if (this.count != 0)
/* 1830:     */         {
/* 1831:2483 */           table = this.table;
/* 1832:2484 */           int length = table.length();
/* 1833:2485 */           for (int i = 0; i < length; i++) {
/* 1834:2486 */             for (MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)table.get(i); e != null; e = e.getNext())
/* 1835:     */             {
/* 1836:2487 */               V entryValue = getLiveValue(e);
/* 1837:2488 */               if (entryValue != null) {
/* 1838:2491 */                 if (this.map.valueEquivalence.equivalent(value, entryValue)) {
/* 1839:2492 */                   return true;
/* 1840:     */                 }
/* 1841:     */               }
/* 1842:     */             }
/* 1843:     */           }
/* 1844:     */         }
/* 1845:2498 */         return 0;
/* 1846:     */       }
/* 1847:     */       finally
/* 1848:     */       {
/* 1849:2500 */         postReadCleanup();
/* 1850:     */       }
/* 1851:     */     }
/* 1852:     */     
/* 1853:     */     V put(K key, int hash, V value, boolean onlyIfAbsent)
/* 1854:     */     {
/* 1855:2505 */       lock();
/* 1856:     */       try
/* 1857:     */       {
/* 1858:2507 */         preWriteCleanup();
/* 1859:     */         
/* 1860:2509 */         int newCount = this.count + 1;
/* 1861:2510 */         if (newCount > this.threshold)
/* 1862:     */         {
/* 1863:2511 */           expand();
/* 1864:2512 */           newCount = this.count + 1;
/* 1865:     */         }
/* 1866:2515 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 1867:2516 */         int index = hash & table.length() - 1;
/* 1868:2517 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 1869:     */         K entryKey;
/* 1870:2520 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 1871:     */         {
/* 1872:2521 */           entryKey = e.getKey();
/* 1873:2522 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 1874:     */           {
/* 1875:2527 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 1876:2528 */             V entryValue = valueReference.get();
/* 1877:     */             V ?;
/* 1878:2530 */             if (entryValue == null)
/* 1879:     */             {
/* 1880:2531 */               this.modCount += 1;
/* 1881:2532 */               setValue(e, value);
/* 1882:2533 */               if (!valueReference.isComputingReference())
/* 1883:     */               {
/* 1884:2534 */                 enqueueNotification(key, hash, entryValue, MapMaker.RemovalCause.COLLECTED);
/* 1885:2535 */                 newCount = this.count;
/* 1886:     */               }
/* 1887:2536 */               else if (evictEntries())
/* 1888:     */               {
/* 1889:2537 */                 newCount = this.count + 1;
/* 1890:     */               }
/* 1891:2539 */               this.count = newCount;
/* 1892:2540 */               return null;
/* 1893:     */             }
/* 1894:2541 */             if (onlyIfAbsent)
/* 1895:     */             {
/* 1896:2545 */               recordLockedRead(e);
/* 1897:2546 */               return entryValue;
/* 1898:     */             }
/* 1899:2549 */             this.modCount += 1;
/* 1900:2550 */             enqueueNotification(key, hash, entryValue, MapMaker.RemovalCause.REPLACED);
/* 1901:2551 */             setValue(e, value);
/* 1902:2552 */             return entryValue;
/* 1903:     */           }
/* 1904:     */         }
/* 1905:2558 */         this.modCount += 1;
/* 1906:2559 */         MapMakerInternalMap.ReferenceEntry<K, V> newEntry = newEntry(key, hash, first);
/* 1907:2560 */         setValue(newEntry, value);
/* 1908:2561 */         table.set(index, newEntry);
/* 1909:2562 */         if (evictEntries()) {
/* 1910:2563 */           newCount = this.count + 1;
/* 1911:     */         }
/* 1912:2565 */         this.count = newCount;
/* 1913:2566 */         return null;
/* 1914:     */       }
/* 1915:     */       finally
/* 1916:     */       {
/* 1917:2568 */         unlock();
/* 1918:2569 */         postWriteCleanup();
/* 1919:     */       }
/* 1920:     */     }
/* 1921:     */     
/* 1922:     */     @GuardedBy("this")
/* 1923:     */     void expand()
/* 1924:     */     {
/* 1925:2578 */       AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> oldTable = this.table;
/* 1926:2579 */       int oldCapacity = oldTable.length();
/* 1927:2580 */       if (oldCapacity >= 1073741824) {
/* 1928:2581 */         return;
/* 1929:     */       }
/* 1930:2594 */       int newCount = this.count;
/* 1931:2595 */       AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> newTable = newEntryArray(oldCapacity << 1);
/* 1932:2596 */       this.threshold = (newTable.length() * 3 / 4);
/* 1933:2597 */       int newMask = newTable.length() - 1;
/* 1934:2598 */       for (int oldIndex = 0; oldIndex < oldCapacity; oldIndex++)
/* 1935:     */       {
/* 1936:2601 */         MapMakerInternalMap.ReferenceEntry<K, V> head = (MapMakerInternalMap.ReferenceEntry)oldTable.get(oldIndex);
/* 1937:2603 */         if (head != null)
/* 1938:     */         {
/* 1939:2604 */           MapMakerInternalMap.ReferenceEntry<K, V> next = head.getNext();
/* 1940:2605 */           int headIndex = head.getHash() & newMask;
/* 1941:2608 */           if (next == null)
/* 1942:     */           {
/* 1943:2609 */             newTable.set(headIndex, head);
/* 1944:     */           }
/* 1945:     */           else
/* 1946:     */           {
/* 1947:2614 */             MapMakerInternalMap.ReferenceEntry<K, V> tail = head;
/* 1948:2615 */             int tailIndex = headIndex;
/* 1949:2616 */             for (MapMakerInternalMap.ReferenceEntry<K, V> e = next; e != null; e = e.getNext())
/* 1950:     */             {
/* 1951:2617 */               int newIndex = e.getHash() & newMask;
/* 1952:2618 */               if (newIndex != tailIndex)
/* 1953:     */               {
/* 1954:2620 */                 tailIndex = newIndex;
/* 1955:2621 */                 tail = e;
/* 1956:     */               }
/* 1957:     */             }
/* 1958:2624 */             newTable.set(tailIndex, tail);
/* 1959:2627 */             for (MapMakerInternalMap.ReferenceEntry<K, V> e = head; e != tail; e = e.getNext())
/* 1960:     */             {
/* 1961:2628 */               int newIndex = e.getHash() & newMask;
/* 1962:2629 */               MapMakerInternalMap.ReferenceEntry<K, V> newNext = (MapMakerInternalMap.ReferenceEntry)newTable.get(newIndex);
/* 1963:2630 */               MapMakerInternalMap.ReferenceEntry<K, V> newFirst = copyEntry(e, newNext);
/* 1964:2631 */               if (newFirst != null)
/* 1965:     */               {
/* 1966:2632 */                 newTable.set(newIndex, newFirst);
/* 1967:     */               }
/* 1968:     */               else
/* 1969:     */               {
/* 1970:2634 */                 removeCollectedEntry(e);
/* 1971:2635 */                 newCount--;
/* 1972:     */               }
/* 1973:     */             }
/* 1974:     */           }
/* 1975:     */         }
/* 1976:     */       }
/* 1977:2641 */       this.table = newTable;
/* 1978:2642 */       this.count = newCount;
/* 1979:     */     }
/* 1980:     */     
/* 1981:     */     boolean replace(K key, int hash, V oldValue, V newValue)
/* 1982:     */     {
/* 1983:2646 */       lock();
/* 1984:     */       try
/* 1985:     */       {
/* 1986:2648 */         preWriteCleanup();
/* 1987:     */         
/* 1988:2650 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 1989:2651 */         int index = hash & table.length() - 1;
/* 1990:2652 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 1991:2654 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 1992:     */         {
/* 1993:2655 */           K entryKey = e.getKey();
/* 1994:2656 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 1995:     */           {
/* 1996:2661 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 1997:2662 */             V entryValue = valueReference.get();
/* 1998:     */             int newCount;
/* 1999:2663 */             if (entryValue == null)
/* 2000:     */             {
/* 2001:2664 */               if (isCollected(valueReference))
/* 2002:     */               {
/* 2003:2665 */                 newCount = this.count - 1;
/* 2004:2666 */                 this.modCount += 1;
/* 2005:2667 */                 enqueueNotification(entryKey, hash, entryValue, MapMaker.RemovalCause.COLLECTED);
/* 2006:2668 */                 MapMakerInternalMap.ReferenceEntry<K, V> newFirst = removeFromChain(first, e);
/* 2007:2669 */                 newCount = this.count - 1;
/* 2008:2670 */                 table.set(index, newFirst);
/* 2009:2671 */                 this.count = newCount;
/* 2010:     */               }
/* 2011:2673 */               return 0;
/* 2012:     */             }
/* 2013:2676 */             if (this.map.valueEquivalence.equivalent(oldValue, entryValue))
/* 2014:     */             {
/* 2015:2677 */               this.modCount += 1;
/* 2016:2678 */               enqueueNotification(key, hash, entryValue, MapMaker.RemovalCause.REPLACED);
/* 2017:2679 */               setValue(e, newValue);
/* 2018:2680 */               return 1;
/* 2019:     */             }
/* 2020:2684 */             recordLockedRead(e);
/* 2021:2685 */             return 0;
/* 2022:     */           }
/* 2023:     */         }
/* 2024:2690 */         return 0;
/* 2025:     */       }
/* 2026:     */       finally
/* 2027:     */       {
/* 2028:2692 */         unlock();
/* 2029:2693 */         postWriteCleanup();
/* 2030:     */       }
/* 2031:     */     }
/* 2032:     */     
/* 2033:     */     V replace(K key, int hash, V newValue)
/* 2034:     */     {
/* 2035:2698 */       lock();
/* 2036:     */       try
/* 2037:     */       {
/* 2038:2700 */         preWriteCleanup();
/* 2039:     */         
/* 2040:2702 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2041:2703 */         int index = hash & table.length() - 1;
/* 2042:2704 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2043:2706 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2044:     */         {
/* 2045:2707 */           K entryKey = e.getKey();
/* 2046:2708 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2047:     */           {
/* 2048:2713 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 2049:2714 */             V entryValue = valueReference.get();
/* 2050:     */             int newCount;
/* 2051:2715 */             if (entryValue == null)
/* 2052:     */             {
/* 2053:2716 */               if (isCollected(valueReference))
/* 2054:     */               {
/* 2055:2717 */                 newCount = this.count - 1;
/* 2056:2718 */                 this.modCount += 1;
/* 2057:2719 */                 enqueueNotification(entryKey, hash, entryValue, MapMaker.RemovalCause.COLLECTED);
/* 2058:2720 */                 MapMakerInternalMap.ReferenceEntry<K, V> newFirst = removeFromChain(first, e);
/* 2059:2721 */                 newCount = this.count - 1;
/* 2060:2722 */                 table.set(index, newFirst);
/* 2061:2723 */                 this.count = newCount;
/* 2062:     */               }
/* 2063:2725 */               return null;
/* 2064:     */             }
/* 2065:2728 */             this.modCount += 1;
/* 2066:2729 */             enqueueNotification(key, hash, entryValue, MapMaker.RemovalCause.REPLACED);
/* 2067:2730 */             setValue(e, newValue);
/* 2068:2731 */             return entryValue;
/* 2069:     */           }
/* 2070:     */         }
/* 2071:2735 */         return null;
/* 2072:     */       }
/* 2073:     */       finally
/* 2074:     */       {
/* 2075:2737 */         unlock();
/* 2076:2738 */         postWriteCleanup();
/* 2077:     */       }
/* 2078:     */     }
/* 2079:     */     
/* 2080:     */     V remove(Object key, int hash)
/* 2081:     */     {
/* 2082:2743 */       lock();
/* 2083:     */       try
/* 2084:     */       {
/* 2085:2745 */         preWriteCleanup();
/* 2086:     */         
/* 2087:2747 */         int newCount = this.count - 1;
/* 2088:2748 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2089:2749 */         int index = hash & table.length() - 1;
/* 2090:2750 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2091:2752 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2092:     */         {
/* 2093:2753 */           K entryKey = e.getKey();
/* 2094:2754 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2095:     */           {
/* 2096:2757 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 2097:2758 */             V entryValue = valueReference.get();
/* 2098:     */             MapMaker.RemovalCause cause;
/* 2099:2761 */             if (entryValue != null)
/* 2100:     */             {
/* 2101:2762 */               cause = MapMaker.RemovalCause.EXPLICIT;
/* 2102:     */             }
/* 2103:     */             else
/* 2104:     */             {
/* 2105:     */               MapMaker.RemovalCause cause;
/* 2106:2763 */               if (isCollected(valueReference)) {
/* 2107:2764 */                 cause = MapMaker.RemovalCause.COLLECTED;
/* 2108:     */               } else {
/* 2109:2766 */                 return null;
/* 2110:     */               }
/* 2111:     */             }
/* 2112:     */             MapMaker.RemovalCause cause;
/* 2113:2769 */             this.modCount += 1;
/* 2114:2770 */             enqueueNotification(entryKey, hash, entryValue, cause);
/* 2115:2771 */             Object newFirst = removeFromChain(first, e);
/* 2116:2772 */             newCount = this.count - 1;
/* 2117:2773 */             table.set(index, newFirst);
/* 2118:2774 */             this.count = newCount;
/* 2119:2775 */             return entryValue;
/* 2120:     */           }
/* 2121:     */         }
/* 2122:2779 */         return null;
/* 2123:     */       }
/* 2124:     */       finally
/* 2125:     */       {
/* 2126:2781 */         unlock();
/* 2127:2782 */         postWriteCleanup();
/* 2128:     */       }
/* 2129:     */     }
/* 2130:     */     
/* 2131:     */     boolean remove(Object key, int hash, Object value)
/* 2132:     */     {
/* 2133:2787 */       lock();
/* 2134:     */       try
/* 2135:     */       {
/* 2136:2789 */         preWriteCleanup();
/* 2137:     */         
/* 2138:2791 */         int newCount = this.count - 1;
/* 2139:2792 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2140:2793 */         int index = hash & table.length() - 1;
/* 2141:2794 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2142:2796 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2143:     */         {
/* 2144:2797 */           K entryKey = e.getKey();
/* 2145:2798 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2146:     */           {
/* 2147:2801 */             MapMakerInternalMap.ValueReference<K, V> valueReference = e.getValueReference();
/* 2148:2802 */             V entryValue = valueReference.get();
/* 2149:     */             MapMaker.RemovalCause cause;
/* 2150:2805 */             if (this.map.valueEquivalence.equivalent(value, entryValue))
/* 2151:     */             {
/* 2152:2806 */               cause = MapMaker.RemovalCause.EXPLICIT;
/* 2153:     */             }
/* 2154:     */             else
/* 2155:     */             {
/* 2156:     */               MapMaker.RemovalCause cause;
/* 2157:2807 */               if (isCollected(valueReference)) {
/* 2158:2808 */                 cause = MapMaker.RemovalCause.COLLECTED;
/* 2159:     */               } else {
/* 2160:2810 */                 return false;
/* 2161:     */               }
/* 2162:     */             }
/* 2163:     */             MapMaker.RemovalCause cause;
/* 2164:2813 */             this.modCount += 1;
/* 2165:2814 */             enqueueNotification(entryKey, hash, entryValue, cause);
/* 2166:2815 */             Object newFirst = removeFromChain(first, e);
/* 2167:2816 */             newCount = this.count - 1;
/* 2168:2817 */             table.set(index, newFirst);
/* 2169:2818 */             this.count = newCount;
/* 2170:2819 */             return cause == MapMaker.RemovalCause.EXPLICIT;
/* 2171:     */           }
/* 2172:     */         }
/* 2173:2823 */         return 0;
/* 2174:     */       }
/* 2175:     */       finally
/* 2176:     */       {
/* 2177:2825 */         unlock();
/* 2178:2826 */         postWriteCleanup();
/* 2179:     */       }
/* 2180:     */     }
/* 2181:     */     
/* 2182:     */     void clear()
/* 2183:     */     {
/* 2184:2831 */       if (this.count != 0)
/* 2185:     */       {
/* 2186:2832 */         lock();
/* 2187:     */         try
/* 2188:     */         {
/* 2189:2834 */           AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2190:2835 */           if (this.map.removalNotificationQueue != MapMakerInternalMap.DISCARDING_QUEUE) {
/* 2191:2836 */             for (int i = 0; i < table.length(); i++) {
/* 2192:2837 */               for (MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)table.get(i); e != null; e = e.getNext()) {
/* 2193:2839 */                 if (!e.getValueReference().isComputingReference()) {
/* 2194:2840 */                   enqueueNotification(e, MapMaker.RemovalCause.EXPLICIT);
/* 2195:     */                 }
/* 2196:     */               }
/* 2197:     */             }
/* 2198:     */           }
/* 2199:2845 */           for (int i = 0; i < table.length(); i++) {
/* 2200:2846 */             table.set(i, null);
/* 2201:     */           }
/* 2202:2848 */           clearReferenceQueues();
/* 2203:2849 */           this.evictionQueue.clear();
/* 2204:2850 */           this.expirationQueue.clear();
/* 2205:2851 */           this.readCount.set(0);
/* 2206:     */           
/* 2207:2853 */           this.modCount += 1;
/* 2208:2854 */           this.count = 0;
/* 2209:     */         }
/* 2210:     */         finally
/* 2211:     */         {
/* 2212:2856 */           unlock();
/* 2213:2857 */           postWriteCleanup();
/* 2214:     */         }
/* 2215:     */       }
/* 2216:     */     }
/* 2217:     */     
/* 2218:     */     @GuardedBy("this")
/* 2219:     */     MapMakerInternalMap.ReferenceEntry<K, V> removeFromChain(MapMakerInternalMap.ReferenceEntry<K, V> first, MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2220:     */     {
/* 2221:2876 */       this.evictionQueue.remove(entry);
/* 2222:2877 */       this.expirationQueue.remove(entry);
/* 2223:     */       
/* 2224:2879 */       int newCount = this.count;
/* 2225:2880 */       MapMakerInternalMap.ReferenceEntry<K, V> newFirst = entry.getNext();
/* 2226:2881 */       for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != entry; e = e.getNext())
/* 2227:     */       {
/* 2228:2882 */         MapMakerInternalMap.ReferenceEntry<K, V> next = copyEntry(e, newFirst);
/* 2229:2883 */         if (next != null)
/* 2230:     */         {
/* 2231:2884 */           newFirst = next;
/* 2232:     */         }
/* 2233:     */         else
/* 2234:     */         {
/* 2235:2886 */           removeCollectedEntry(e);
/* 2236:2887 */           newCount--;
/* 2237:     */         }
/* 2238:     */       }
/* 2239:2890 */       this.count = newCount;
/* 2240:2891 */       return newFirst;
/* 2241:     */     }
/* 2242:     */     
/* 2243:     */     void removeCollectedEntry(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2244:     */     {
/* 2245:2895 */       enqueueNotification(entry, MapMaker.RemovalCause.COLLECTED);
/* 2246:2896 */       this.evictionQueue.remove(entry);
/* 2247:2897 */       this.expirationQueue.remove(entry);
/* 2248:     */     }
/* 2249:     */     
/* 2250:     */     boolean reclaimKey(MapMakerInternalMap.ReferenceEntry<K, V> entry, int hash)
/* 2251:     */     {
/* 2252:2904 */       lock();
/* 2253:     */       try
/* 2254:     */       {
/* 2255:2906 */         int newCount = this.count - 1;
/* 2256:2907 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2257:2908 */         int index = hash & table.length() - 1;
/* 2258:2909 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2259:2911 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext()) {
/* 2260:2912 */           if (e == entry)
/* 2261:     */           {
/* 2262:2913 */             this.modCount += 1;
/* 2263:2914 */             enqueueNotification(e.getKey(), hash, e.getValueReference().get(), MapMaker.RemovalCause.COLLECTED);
/* 2264:     */             
/* 2265:2916 */             MapMakerInternalMap.ReferenceEntry<K, V> newFirst = removeFromChain(first, e);
/* 2266:2917 */             newCount = this.count - 1;
/* 2267:2918 */             table.set(index, newFirst);
/* 2268:2919 */             this.count = newCount;
/* 2269:2920 */             return true;
/* 2270:     */           }
/* 2271:     */         }
/* 2272:2924 */         return 0;
/* 2273:     */       }
/* 2274:     */       finally
/* 2275:     */       {
/* 2276:2926 */         unlock();
/* 2277:2927 */         postWriteCleanup();
/* 2278:     */       }
/* 2279:     */     }
/* 2280:     */     
/* 2281:     */     boolean reclaimValue(K key, int hash, MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 2282:     */     {
/* 2283:2935 */       lock();
/* 2284:     */       try
/* 2285:     */       {
/* 2286:2937 */         int newCount = this.count - 1;
/* 2287:2938 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2288:2939 */         int index = hash & table.length() - 1;
/* 2289:2940 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2290:2942 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2291:     */         {
/* 2292:2943 */           K entryKey = e.getKey();
/* 2293:2944 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2294:     */           {
/* 2295:2947 */             MapMakerInternalMap.ValueReference<K, V> v = e.getValueReference();
/* 2296:     */             MapMakerInternalMap.ReferenceEntry<K, V> newFirst;
/* 2297:2948 */             if (v == valueReference)
/* 2298:     */             {
/* 2299:2949 */               this.modCount += 1;
/* 2300:2950 */               enqueueNotification(key, hash, valueReference.get(), MapMaker.RemovalCause.COLLECTED);
/* 2301:2951 */               newFirst = removeFromChain(first, e);
/* 2302:2952 */               newCount = this.count - 1;
/* 2303:2953 */               table.set(index, newFirst);
/* 2304:2954 */               this.count = newCount;
/* 2305:2955 */               return true;
/* 2306:     */             }
/* 2307:2957 */             return 0;
/* 2308:     */           }
/* 2309:     */         }
/* 2310:2961 */         return 0;
/* 2311:     */       }
/* 2312:     */       finally
/* 2313:     */       {
/* 2314:2963 */         unlock();
/* 2315:2964 */         if (!isHeldByCurrentThread()) {
/* 2316:2965 */           postWriteCleanup();
/* 2317:     */         }
/* 2318:     */       }
/* 2319:     */     }
/* 2320:     */     
/* 2321:     */     boolean clearValue(K key, int hash, MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 2322:     */     {
/* 2323:2974 */       lock();
/* 2324:     */       try
/* 2325:     */       {
/* 2326:2976 */         AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2327:2977 */         int index = hash & table.length() - 1;
/* 2328:2978 */         MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2329:2980 */         for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext())
/* 2330:     */         {
/* 2331:2981 */           K entryKey = e.getKey();
/* 2332:2982 */           if ((e.getHash() == hash) && (entryKey != null) && (this.map.keyEquivalence.equivalent(key, entryKey)))
/* 2333:     */           {
/* 2334:2985 */             MapMakerInternalMap.ValueReference<K, V> v = e.getValueReference();
/* 2335:     */             MapMakerInternalMap.ReferenceEntry<K, V> newFirst;
/* 2336:2986 */             if (v == valueReference)
/* 2337:     */             {
/* 2338:2987 */               newFirst = removeFromChain(first, e);
/* 2339:2988 */               table.set(index, newFirst);
/* 2340:2989 */               return true;
/* 2341:     */             }
/* 2342:2991 */             return 0;
/* 2343:     */           }
/* 2344:     */         }
/* 2345:2995 */         return 0;
/* 2346:     */       }
/* 2347:     */       finally
/* 2348:     */       {
/* 2349:2997 */         unlock();
/* 2350:2998 */         postWriteCleanup();
/* 2351:     */       }
/* 2352:     */     }
/* 2353:     */     
/* 2354:     */     @GuardedBy("this")
/* 2355:     */     boolean removeEntry(MapMakerInternalMap.ReferenceEntry<K, V> entry, int hash, MapMaker.RemovalCause cause)
/* 2356:     */     {
/* 2357:3004 */       int newCount = this.count - 1;
/* 2358:3005 */       AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> table = this.table;
/* 2359:3006 */       int index = hash & table.length() - 1;
/* 2360:3007 */       MapMakerInternalMap.ReferenceEntry<K, V> first = (MapMakerInternalMap.ReferenceEntry)table.get(index);
/* 2361:3009 */       for (MapMakerInternalMap.ReferenceEntry<K, V> e = first; e != null; e = e.getNext()) {
/* 2362:3010 */         if (e == entry)
/* 2363:     */         {
/* 2364:3011 */           this.modCount += 1;
/* 2365:3012 */           enqueueNotification(e.getKey(), hash, e.getValueReference().get(), cause);
/* 2366:3013 */           MapMakerInternalMap.ReferenceEntry<K, V> newFirst = removeFromChain(first, e);
/* 2367:3014 */           newCount = this.count - 1;
/* 2368:3015 */           table.set(index, newFirst);
/* 2369:3016 */           this.count = newCount;
/* 2370:3017 */           return true;
/* 2371:     */         }
/* 2372:     */       }
/* 2373:3021 */       return false;
/* 2374:     */     }
/* 2375:     */     
/* 2376:     */     boolean isCollected(MapMakerInternalMap.ValueReference<K, V> valueReference)
/* 2377:     */     {
/* 2378:3029 */       if (valueReference.isComputingReference()) {
/* 2379:3030 */         return false;
/* 2380:     */       }
/* 2381:3032 */       return valueReference.get() == null;
/* 2382:     */     }
/* 2383:     */     
/* 2384:     */     V getLiveValue(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2385:     */     {
/* 2386:3040 */       if (entry.getKey() == null)
/* 2387:     */       {
/* 2388:3041 */         tryDrainReferenceQueues();
/* 2389:3042 */         return null;
/* 2390:     */       }
/* 2391:3044 */       V value = entry.getValueReference().get();
/* 2392:3045 */       if (value == null)
/* 2393:     */       {
/* 2394:3046 */         tryDrainReferenceQueues();
/* 2395:3047 */         return null;
/* 2396:     */       }
/* 2397:3050 */       if ((this.map.expires()) && (this.map.isExpired(entry)))
/* 2398:     */       {
/* 2399:3051 */         tryExpireEntries();
/* 2400:3052 */         return null;
/* 2401:     */       }
/* 2402:3054 */       return value;
/* 2403:     */     }
/* 2404:     */     
/* 2405:     */     void postReadCleanup()
/* 2406:     */     {
/* 2407:3063 */       if ((this.readCount.incrementAndGet() & 0x3F) == 0) {
/* 2408:3064 */         runCleanup();
/* 2409:     */       }
/* 2410:     */     }
/* 2411:     */     
/* 2412:     */     @GuardedBy("this")
/* 2413:     */     void preWriteCleanup()
/* 2414:     */     {
/* 2415:3076 */       runLockedCleanup();
/* 2416:     */     }
/* 2417:     */     
/* 2418:     */     void postWriteCleanup()
/* 2419:     */     {
/* 2420:3083 */       runUnlockedCleanup();
/* 2421:     */     }
/* 2422:     */     
/* 2423:     */     void runCleanup()
/* 2424:     */     {
/* 2425:3087 */       runLockedCleanup();
/* 2426:3088 */       runUnlockedCleanup();
/* 2427:     */     }
/* 2428:     */     
/* 2429:     */     void runLockedCleanup()
/* 2430:     */     {
/* 2431:3092 */       if (tryLock()) {
/* 2432:     */         try
/* 2433:     */         {
/* 2434:3094 */           drainReferenceQueues();
/* 2435:3095 */           expireEntries();
/* 2436:3096 */           this.readCount.set(0);
/* 2437:     */         }
/* 2438:     */         finally
/* 2439:     */         {
/* 2440:3098 */           unlock();
/* 2441:     */         }
/* 2442:     */       }
/* 2443:     */     }
/* 2444:     */     
/* 2445:     */     void runUnlockedCleanup()
/* 2446:     */     {
/* 2447:3105 */       if (!isHeldByCurrentThread()) {
/* 2448:3106 */         this.map.processPendingNotifications();
/* 2449:     */       }
/* 2450:     */     }
/* 2451:     */   }
/* 2452:     */   
/* 2453:     */   static final class EvictionQueue<K, V>
/* 2454:     */     extends AbstractQueue<MapMakerInternalMap.ReferenceEntry<K, V>>
/* 2455:     */   {
/* 2456:3125 */     final MapMakerInternalMap.ReferenceEntry<K, V> head = new MapMakerInternalMap.AbstractReferenceEntry()
/* 2457:     */     {
/* 2458:3128 */       MapMakerInternalMap.ReferenceEntry<K, V> nextEvictable = this;
/* 2459:     */       
/* 2460:     */       public MapMakerInternalMap.ReferenceEntry<K, V> getNextEvictable()
/* 2461:     */       {
/* 2462:3132 */         return this.nextEvictable;
/* 2463:     */       }
/* 2464:     */       
/* 2465:     */       public void setNextEvictable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 2466:     */       {
/* 2467:3137 */         this.nextEvictable = next;
/* 2468:     */       }
/* 2469:     */       
/* 2470:3140 */       MapMakerInternalMap.ReferenceEntry<K, V> previousEvictable = this;
/* 2471:     */       
/* 2472:     */       public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousEvictable()
/* 2473:     */       {
/* 2474:3144 */         return this.previousEvictable;
/* 2475:     */       }
/* 2476:     */       
/* 2477:     */       public void setPreviousEvictable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 2478:     */       {
/* 2479:3149 */         this.previousEvictable = previous;
/* 2480:     */       }
/* 2481:     */     };
/* 2482:     */     
/* 2483:     */     public boolean offer(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2484:     */     {
/* 2485:3158 */       MapMakerInternalMap.connectEvictables(entry.getPreviousEvictable(), entry.getNextEvictable());
/* 2486:     */       
/* 2487:     */ 
/* 2488:3161 */       MapMakerInternalMap.connectEvictables(this.head.getPreviousEvictable(), entry);
/* 2489:3162 */       MapMakerInternalMap.connectEvictables(entry, this.head);
/* 2490:     */       
/* 2491:3164 */       return true;
/* 2492:     */     }
/* 2493:     */     
/* 2494:     */     public MapMakerInternalMap.ReferenceEntry<K, V> peek()
/* 2495:     */     {
/* 2496:3169 */       MapMakerInternalMap.ReferenceEntry<K, V> next = this.head.getNextEvictable();
/* 2497:3170 */       return next == this.head ? null : next;
/* 2498:     */     }
/* 2499:     */     
/* 2500:     */     public MapMakerInternalMap.ReferenceEntry<K, V> poll()
/* 2501:     */     {
/* 2502:3175 */       MapMakerInternalMap.ReferenceEntry<K, V> next = this.head.getNextEvictable();
/* 2503:3176 */       if (next == this.head) {
/* 2504:3177 */         return null;
/* 2505:     */       }
/* 2506:3180 */       remove(next);
/* 2507:3181 */       return next;
/* 2508:     */     }
/* 2509:     */     
/* 2510:     */     public boolean remove(Object o)
/* 2511:     */     {
/* 2512:3187 */       MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)o;
/* 2513:3188 */       MapMakerInternalMap.ReferenceEntry<K, V> previous = e.getPreviousEvictable();
/* 2514:3189 */       MapMakerInternalMap.ReferenceEntry<K, V> next = e.getNextEvictable();
/* 2515:3190 */       MapMakerInternalMap.connectEvictables(previous, next);
/* 2516:3191 */       MapMakerInternalMap.nullifyEvictable(e);
/* 2517:     */       
/* 2518:3193 */       return next != MapMakerInternalMap.NullEntry.INSTANCE;
/* 2519:     */     }
/* 2520:     */     
/* 2521:     */     public boolean contains(Object o)
/* 2522:     */     {
/* 2523:3199 */       MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)o;
/* 2524:3200 */       return e.getNextEvictable() != MapMakerInternalMap.NullEntry.INSTANCE;
/* 2525:     */     }
/* 2526:     */     
/* 2527:     */     public boolean isEmpty()
/* 2528:     */     {
/* 2529:3205 */       return this.head.getNextEvictable() == this.head;
/* 2530:     */     }
/* 2531:     */     
/* 2532:     */     public int size()
/* 2533:     */     {
/* 2534:3210 */       int size = 0;
/* 2535:3211 */       for (MapMakerInternalMap.ReferenceEntry<K, V> e = this.head.getNextEvictable(); e != this.head; e = e.getNextEvictable()) {
/* 2536:3212 */         size++;
/* 2537:     */       }
/* 2538:3214 */       return size;
/* 2539:     */     }
/* 2540:     */     
/* 2541:     */     public void clear()
/* 2542:     */     {
/* 2543:3219 */       MapMakerInternalMap.ReferenceEntry<K, V> e = this.head.getNextEvictable();
/* 2544:3220 */       while (e != this.head)
/* 2545:     */       {
/* 2546:3221 */         MapMakerInternalMap.ReferenceEntry<K, V> next = e.getNextEvictable();
/* 2547:3222 */         MapMakerInternalMap.nullifyEvictable(e);
/* 2548:3223 */         e = next;
/* 2549:     */       }
/* 2550:3226 */       this.head.setNextEvictable(this.head);
/* 2551:3227 */       this.head.setPreviousEvictable(this.head);
/* 2552:     */     }
/* 2553:     */     
/* 2554:     */     public Iterator<MapMakerInternalMap.ReferenceEntry<K, V>> iterator()
/* 2555:     */     {
/* 2556:3232 */       new AbstractSequentialIterator(peek())
/* 2557:     */       {
/* 2558:     */         protected MapMakerInternalMap.ReferenceEntry<K, V> computeNext(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 2559:     */         {
/* 2560:3235 */           MapMakerInternalMap.ReferenceEntry<K, V> next = previous.getNextEvictable();
/* 2561:3236 */           return next == MapMakerInternalMap.EvictionQueue.this.head ? null : next;
/* 2562:     */         }
/* 2563:     */       };
/* 2564:     */     }
/* 2565:     */   }
/* 2566:     */   
/* 2567:     */   static final class ExpirationQueue<K, V>
/* 2568:     */     extends AbstractQueue<MapMakerInternalMap.ReferenceEntry<K, V>>
/* 2569:     */   {
/* 2570:3254 */     final MapMakerInternalMap.ReferenceEntry<K, V> head = new MapMakerInternalMap.AbstractReferenceEntry()
/* 2571:     */     {
/* 2572:     */       public long getExpirationTime()
/* 2573:     */       {
/* 2574:3259 */         return 9223372036854775807L;
/* 2575:     */       }
/* 2576:     */       
/* 2577:3265 */       MapMakerInternalMap.ReferenceEntry<K, V> nextExpirable = this;
/* 2578:     */       
/* 2579:     */       public void setExpirationTime(long time) {}
/* 2580:     */       
/* 2581:     */       public MapMakerInternalMap.ReferenceEntry<K, V> getNextExpirable()
/* 2582:     */       {
/* 2583:3269 */         return this.nextExpirable;
/* 2584:     */       }
/* 2585:     */       
/* 2586:     */       public void setNextExpirable(MapMakerInternalMap.ReferenceEntry<K, V> next)
/* 2587:     */       {
/* 2588:3274 */         this.nextExpirable = next;
/* 2589:     */       }
/* 2590:     */       
/* 2591:3277 */       MapMakerInternalMap.ReferenceEntry<K, V> previousExpirable = this;
/* 2592:     */       
/* 2593:     */       public MapMakerInternalMap.ReferenceEntry<K, V> getPreviousExpirable()
/* 2594:     */       {
/* 2595:3281 */         return this.previousExpirable;
/* 2596:     */       }
/* 2597:     */       
/* 2598:     */       public void setPreviousExpirable(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 2599:     */       {
/* 2600:3286 */         this.previousExpirable = previous;
/* 2601:     */       }
/* 2602:     */     };
/* 2603:     */     
/* 2604:     */     public boolean offer(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2605:     */     {
/* 2606:3295 */       MapMakerInternalMap.connectExpirables(entry.getPreviousExpirable(), entry.getNextExpirable());
/* 2607:     */       
/* 2608:     */ 
/* 2609:3298 */       MapMakerInternalMap.connectExpirables(this.head.getPreviousExpirable(), entry);
/* 2610:3299 */       MapMakerInternalMap.connectExpirables(entry, this.head);
/* 2611:     */       
/* 2612:3301 */       return true;
/* 2613:     */     }
/* 2614:     */     
/* 2615:     */     public MapMakerInternalMap.ReferenceEntry<K, V> peek()
/* 2616:     */     {
/* 2617:3306 */       MapMakerInternalMap.ReferenceEntry<K, V> next = this.head.getNextExpirable();
/* 2618:3307 */       return next == this.head ? null : next;
/* 2619:     */     }
/* 2620:     */     
/* 2621:     */     public MapMakerInternalMap.ReferenceEntry<K, V> poll()
/* 2622:     */     {
/* 2623:3312 */       MapMakerInternalMap.ReferenceEntry<K, V> next = this.head.getNextExpirable();
/* 2624:3313 */       if (next == this.head) {
/* 2625:3314 */         return null;
/* 2626:     */       }
/* 2627:3317 */       remove(next);
/* 2628:3318 */       return next;
/* 2629:     */     }
/* 2630:     */     
/* 2631:     */     public boolean remove(Object o)
/* 2632:     */     {
/* 2633:3324 */       MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)o;
/* 2634:3325 */       MapMakerInternalMap.ReferenceEntry<K, V> previous = e.getPreviousExpirable();
/* 2635:3326 */       MapMakerInternalMap.ReferenceEntry<K, V> next = e.getNextExpirable();
/* 2636:3327 */       MapMakerInternalMap.connectExpirables(previous, next);
/* 2637:3328 */       MapMakerInternalMap.nullifyExpirable(e);
/* 2638:     */       
/* 2639:3330 */       return next != MapMakerInternalMap.NullEntry.INSTANCE;
/* 2640:     */     }
/* 2641:     */     
/* 2642:     */     public boolean contains(Object o)
/* 2643:     */     {
/* 2644:3336 */       MapMakerInternalMap.ReferenceEntry<K, V> e = (MapMakerInternalMap.ReferenceEntry)o;
/* 2645:3337 */       return e.getNextExpirable() != MapMakerInternalMap.NullEntry.INSTANCE;
/* 2646:     */     }
/* 2647:     */     
/* 2648:     */     public boolean isEmpty()
/* 2649:     */     {
/* 2650:3342 */       return this.head.getNextExpirable() == this.head;
/* 2651:     */     }
/* 2652:     */     
/* 2653:     */     public int size()
/* 2654:     */     {
/* 2655:3347 */       int size = 0;
/* 2656:3348 */       for (MapMakerInternalMap.ReferenceEntry<K, V> e = this.head.getNextExpirable(); e != this.head; e = e.getNextExpirable()) {
/* 2657:3349 */         size++;
/* 2658:     */       }
/* 2659:3351 */       return size;
/* 2660:     */     }
/* 2661:     */     
/* 2662:     */     public void clear()
/* 2663:     */     {
/* 2664:3356 */       MapMakerInternalMap.ReferenceEntry<K, V> e = this.head.getNextExpirable();
/* 2665:3357 */       while (e != this.head)
/* 2666:     */       {
/* 2667:3358 */         MapMakerInternalMap.ReferenceEntry<K, V> next = e.getNextExpirable();
/* 2668:3359 */         MapMakerInternalMap.nullifyExpirable(e);
/* 2669:3360 */         e = next;
/* 2670:     */       }
/* 2671:3363 */       this.head.setNextExpirable(this.head);
/* 2672:3364 */       this.head.setPreviousExpirable(this.head);
/* 2673:     */     }
/* 2674:     */     
/* 2675:     */     public Iterator<MapMakerInternalMap.ReferenceEntry<K, V>> iterator()
/* 2676:     */     {
/* 2677:3369 */       new AbstractSequentialIterator(peek())
/* 2678:     */       {
/* 2679:     */         protected MapMakerInternalMap.ReferenceEntry<K, V> computeNext(MapMakerInternalMap.ReferenceEntry<K, V> previous)
/* 2680:     */         {
/* 2681:3372 */           MapMakerInternalMap.ReferenceEntry<K, V> next = previous.getNextExpirable();
/* 2682:3373 */           return next == MapMakerInternalMap.ExpirationQueue.this.head ? null : next;
/* 2683:     */         }
/* 2684:     */       };
/* 2685:     */     }
/* 2686:     */   }
/* 2687:     */   
/* 2688:     */   static final class CleanupMapTask
/* 2689:     */     implements Runnable
/* 2690:     */   {
/* 2691:     */     final WeakReference<MapMakerInternalMap<?, ?>> mapReference;
/* 2692:     */     
/* 2693:     */     public CleanupMapTask(MapMakerInternalMap<?, ?> map)
/* 2694:     */     {
/* 2695:3383 */       this.mapReference = new WeakReference(map);
/* 2696:     */     }
/* 2697:     */     
/* 2698:     */     public void run()
/* 2699:     */     {
/* 2700:3388 */       MapMakerInternalMap<?, ?> map = (MapMakerInternalMap)this.mapReference.get();
/* 2701:3389 */       if (map == null) {
/* 2702:3390 */         throw new CancellationException();
/* 2703:     */       }
/* 2704:3393 */       for (MapMakerInternalMap.Segment<?, ?> segment : map.segments) {
/* 2705:3394 */         segment.runCleanup();
/* 2706:     */       }
/* 2707:     */     }
/* 2708:     */   }
/* 2709:     */   
/* 2710:     */   public boolean isEmpty()
/* 2711:     */   {
/* 2712:3410 */     long sum = 0L;
/* 2713:3411 */     Segment<K, V>[] segments = this.segments;
/* 2714:3412 */     for (int i = 0; i < segments.length; i++)
/* 2715:     */     {
/* 2716:3413 */       if (segments[i].count != 0) {
/* 2717:3414 */         return false;
/* 2718:     */       }
/* 2719:3416 */       sum += segments[i].modCount;
/* 2720:     */     }
/* 2721:3419 */     if (sum != 0L)
/* 2722:     */     {
/* 2723:3420 */       for (int i = 0; i < segments.length; i++)
/* 2724:     */       {
/* 2725:3421 */         if (segments[i].count != 0) {
/* 2726:3422 */           return false;
/* 2727:     */         }
/* 2728:3424 */         sum -= segments[i].modCount;
/* 2729:     */       }
/* 2730:3426 */       if (sum != 0L) {
/* 2731:3427 */         return false;
/* 2732:     */       }
/* 2733:     */     }
/* 2734:3430 */     return true;
/* 2735:     */   }
/* 2736:     */   
/* 2737:     */   public int size()
/* 2738:     */   {
/* 2739:3435 */     Segment<K, V>[] segments = this.segments;
/* 2740:3436 */     long sum = 0L;
/* 2741:3437 */     for (int i = 0; i < segments.length; i++) {
/* 2742:3438 */       sum += segments[i].count;
/* 2743:     */     }
/* 2744:3440 */     return Ints.saturatedCast(sum);
/* 2745:     */   }
/* 2746:     */   
/* 2747:     */   public V get(@Nullable Object key)
/* 2748:     */   {
/* 2749:3445 */     if (key == null) {
/* 2750:3446 */       return null;
/* 2751:     */     }
/* 2752:3448 */     int hash = hash(key);
/* 2753:3449 */     return segmentFor(hash).get(key, hash);
/* 2754:     */   }
/* 2755:     */   
/* 2756:     */   ReferenceEntry<K, V> getEntry(@Nullable Object key)
/* 2757:     */   {
/* 2758:3457 */     if (key == null) {
/* 2759:3458 */       return null;
/* 2760:     */     }
/* 2761:3460 */     int hash = hash(key);
/* 2762:3461 */     return segmentFor(hash).getEntry(key, hash);
/* 2763:     */   }
/* 2764:     */   
/* 2765:     */   public boolean containsKey(@Nullable Object key)
/* 2766:     */   {
/* 2767:3466 */     if (key == null) {
/* 2768:3467 */       return false;
/* 2769:     */     }
/* 2770:3469 */     int hash = hash(key);
/* 2771:3470 */     return segmentFor(hash).containsKey(key, hash);
/* 2772:     */   }
/* 2773:     */   
/* 2774:     */   public boolean containsValue(@Nullable Object value)
/* 2775:     */   {
/* 2776:3475 */     if (value == null) {
/* 2777:3476 */       return false;
/* 2778:     */     }
/* 2779:3484 */     Segment<K, V>[] segments = this.segments;
/* 2780:3485 */     long last = -1L;
/* 2781:3486 */     for (int i = 0; i < 3; i++)
/* 2782:     */     {
/* 2783:3487 */       long sum = 0L;
/* 2784:3488 */       for (Segment<K, V> segment : segments)
/* 2785:     */       {
/* 2786:3490 */         int unused = segment.count;
/* 2787:     */         
/* 2788:3492 */         AtomicReferenceArray<ReferenceEntry<K, V>> table = segment.table;
/* 2789:3493 */         for (int j = 0; j < table.length(); j++) {
/* 2790:3494 */           for (ReferenceEntry<K, V> e = (ReferenceEntry)table.get(j); e != null; e = e.getNext())
/* 2791:     */           {
/* 2792:3495 */             V v = segment.getLiveValue(e);
/* 2793:3496 */             if ((v != null) && (this.valueEquivalence.equivalent(value, v))) {
/* 2794:3497 */               return true;
/* 2795:     */             }
/* 2796:     */           }
/* 2797:     */         }
/* 2798:3501 */         sum += segment.modCount;
/* 2799:     */       }
/* 2800:3503 */       if (sum == last) {
/* 2801:     */         break;
/* 2802:     */       }
/* 2803:3506 */       last = sum;
/* 2804:     */     }
/* 2805:3508 */     return false;
/* 2806:     */   }
/* 2807:     */   
/* 2808:     */   public V put(K key, V value)
/* 2809:     */   {
/* 2810:3513 */     Preconditions.checkNotNull(key);
/* 2811:3514 */     Preconditions.checkNotNull(value);
/* 2812:3515 */     int hash = hash(key);
/* 2813:3516 */     return segmentFor(hash).put(key, hash, value, false);
/* 2814:     */   }
/* 2815:     */   
/* 2816:     */   public V putIfAbsent(K key, V value)
/* 2817:     */   {
/* 2818:3521 */     Preconditions.checkNotNull(key);
/* 2819:3522 */     Preconditions.checkNotNull(value);
/* 2820:3523 */     int hash = hash(key);
/* 2821:3524 */     return segmentFor(hash).put(key, hash, value, true);
/* 2822:     */   }
/* 2823:     */   
/* 2824:     */   public void putAll(Map<? extends K, ? extends V> m)
/* 2825:     */   {
/* 2826:3529 */     for (Map.Entry<? extends K, ? extends V> e : m.entrySet()) {
/* 2827:3530 */       put(e.getKey(), e.getValue());
/* 2828:     */     }
/* 2829:     */   }
/* 2830:     */   
/* 2831:     */   public V remove(@Nullable Object key)
/* 2832:     */   {
/* 2833:3536 */     if (key == null) {
/* 2834:3537 */       return null;
/* 2835:     */     }
/* 2836:3539 */     int hash = hash(key);
/* 2837:3540 */     return segmentFor(hash).remove(key, hash);
/* 2838:     */   }
/* 2839:     */   
/* 2840:     */   public boolean remove(@Nullable Object key, @Nullable Object value)
/* 2841:     */   {
/* 2842:3545 */     if ((key == null) || (value == null)) {
/* 2843:3546 */       return false;
/* 2844:     */     }
/* 2845:3548 */     int hash = hash(key);
/* 2846:3549 */     return segmentFor(hash).remove(key, hash, value);
/* 2847:     */   }
/* 2848:     */   
/* 2849:     */   public boolean replace(K key, @Nullable V oldValue, V newValue)
/* 2850:     */   {
/* 2851:3554 */     Preconditions.checkNotNull(key);
/* 2852:3555 */     Preconditions.checkNotNull(newValue);
/* 2853:3556 */     if (oldValue == null) {
/* 2854:3557 */       return false;
/* 2855:     */     }
/* 2856:3559 */     int hash = hash(key);
/* 2857:3560 */     return segmentFor(hash).replace(key, hash, oldValue, newValue);
/* 2858:     */   }
/* 2859:     */   
/* 2860:     */   public V replace(K key, V value)
/* 2861:     */   {
/* 2862:3565 */     Preconditions.checkNotNull(key);
/* 2863:3566 */     Preconditions.checkNotNull(value);
/* 2864:3567 */     int hash = hash(key);
/* 2865:3568 */     return segmentFor(hash).replace(key, hash, value);
/* 2866:     */   }
/* 2867:     */   
/* 2868:     */   public void clear()
/* 2869:     */   {
/* 2870:3573 */     for (Segment<K, V> segment : this.segments) {
/* 2871:3574 */       segment.clear();
/* 2872:     */     }
/* 2873:     */   }
/* 2874:     */   
/* 2875:     */   public Set<K> keySet()
/* 2876:     */   {
/* 2877:3582 */     Set<K> ks = this.keySet;
/* 2878:3583 */     return this.keySet = new KeySet();
/* 2879:     */   }
/* 2880:     */   
/* 2881:     */   public Collection<V> values()
/* 2882:     */   {
/* 2883:3590 */     Collection<V> vs = this.values;
/* 2884:3591 */     return this.values = new Values();
/* 2885:     */   }
/* 2886:     */   
/* 2887:     */   public Set<Map.Entry<K, V>> entrySet()
/* 2888:     */   {
/* 2889:3598 */     Set<Map.Entry<K, V>> es = this.entrySet;
/* 2890:3599 */     return this.entrySet = new EntrySet();
/* 2891:     */   }
/* 2892:     */   
/* 2893:     */   abstract class HashIterator<E>
/* 2894:     */     implements Iterator<E>
/* 2895:     */   {
/* 2896:     */     int nextSegmentIndex;
/* 2897:     */     int nextTableIndex;
/* 2898:     */     MapMakerInternalMap.Segment<K, V> currentSegment;
/* 2899:     */     AtomicReferenceArray<MapMakerInternalMap.ReferenceEntry<K, V>> currentTable;
/* 2900:     */     MapMakerInternalMap.ReferenceEntry<K, V> nextEntry;
/* 2901:     */     MapMakerInternalMap<K, V>.WriteThroughEntry nextExternal;
/* 2902:     */     MapMakerInternalMap<K, V>.WriteThroughEntry lastReturned;
/* 2903:     */     
/* 2904:     */     HashIterator()
/* 2905:     */     {
/* 2906:3615 */       this.nextSegmentIndex = (MapMakerInternalMap.this.segments.length - 1);
/* 2907:3616 */       this.nextTableIndex = -1;
/* 2908:3617 */       advance();
/* 2909:     */     }
/* 2910:     */     
/* 2911:     */     public abstract E next();
/* 2912:     */     
/* 2913:     */     final void advance()
/* 2914:     */     {
/* 2915:3624 */       this.nextExternal = null;
/* 2916:3626 */       if (nextInChain()) {
/* 2917:3627 */         return;
/* 2918:     */       }
/* 2919:3630 */       if (nextInTable()) {
/* 2920:3631 */         return;
/* 2921:     */       }
/* 2922:3634 */       while (this.nextSegmentIndex >= 0)
/* 2923:     */       {
/* 2924:3635 */         this.currentSegment = MapMakerInternalMap.this.segments[(this.nextSegmentIndex--)];
/* 2925:3636 */         if (this.currentSegment.count != 0)
/* 2926:     */         {
/* 2927:3637 */           this.currentTable = this.currentSegment.table;
/* 2928:3638 */           this.nextTableIndex = (this.currentTable.length() - 1);
/* 2929:3639 */           if (nextInTable()) {}
/* 2930:     */         }
/* 2931:     */       }
/* 2932:     */     }
/* 2933:     */     
/* 2934:     */     boolean nextInChain()
/* 2935:     */     {
/* 2936:3650 */       if (this.nextEntry != null) {
/* 2937:3651 */         for (this.nextEntry = this.nextEntry.getNext(); this.nextEntry != null; this.nextEntry = this.nextEntry.getNext()) {
/* 2938:3652 */           if (advanceTo(this.nextEntry)) {
/* 2939:3653 */             return true;
/* 2940:     */           }
/* 2941:     */         }
/* 2942:     */       }
/* 2943:3657 */       return false;
/* 2944:     */     }
/* 2945:     */     
/* 2946:     */     boolean nextInTable()
/* 2947:     */     {
/* 2948:3664 */       while (this.nextTableIndex >= 0) {
/* 2949:3665 */         if (((this.nextEntry = (MapMakerInternalMap.ReferenceEntry)this.currentTable.get(this.nextTableIndex--)) != null) && (
/* 2950:3666 */           (advanceTo(this.nextEntry)) || (nextInChain()))) {
/* 2951:3667 */           return true;
/* 2952:     */         }
/* 2953:     */       }
/* 2954:3671 */       return false;
/* 2955:     */     }
/* 2956:     */     
/* 2957:     */     boolean advanceTo(MapMakerInternalMap.ReferenceEntry<K, V> entry)
/* 2958:     */     {
/* 2959:     */       try
/* 2960:     */       {
/* 2961:3680 */         K key = entry.getKey();
/* 2962:3681 */         V value = MapMakerInternalMap.this.getLiveValue(entry);
/* 2963:     */         boolean bool;
/* 2964:3682 */         if (value != null)
/* 2965:     */         {
/* 2966:3683 */           this.nextExternal = new MapMakerInternalMap.WriteThroughEntry(MapMakerInternalMap.this, key, value);
/* 2967:3684 */           return true;
/* 2968:     */         }
/* 2969:3687 */         return false;
/* 2970:     */       }
/* 2971:     */       finally
/* 2972:     */       {
/* 2973:3690 */         this.currentSegment.postReadCleanup();
/* 2974:     */       }
/* 2975:     */     }
/* 2976:     */     
/* 2977:     */     public boolean hasNext()
/* 2978:     */     {
/* 2979:3696 */       return this.nextExternal != null;
/* 2980:     */     }
/* 2981:     */     
/* 2982:     */     MapMakerInternalMap<K, V>.WriteThroughEntry nextEntry()
/* 2983:     */     {
/* 2984:3700 */       if (this.nextExternal == null) {
/* 2985:3701 */         throw new NoSuchElementException();
/* 2986:     */       }
/* 2987:3703 */       this.lastReturned = this.nextExternal;
/* 2988:3704 */       advance();
/* 2989:3705 */       return this.lastReturned;
/* 2990:     */     }
/* 2991:     */     
/* 2992:     */     public void remove()
/* 2993:     */     {
/* 2994:3710 */       CollectPreconditions.checkRemove(this.lastReturned != null);
/* 2995:3711 */       MapMakerInternalMap.this.remove(this.lastReturned.getKey());
/* 2996:3712 */       this.lastReturned = null;
/* 2997:     */     }
/* 2998:     */   }
/* 2999:     */   
/* 3000:     */   final class KeyIterator
/* 3001:     */     extends MapMakerInternalMap<K, V>.HashIterator<K>
/* 3002:     */   {
/* 3003:     */     KeyIterator()
/* 3004:     */     {
/* 3005:3716 */       super();
/* 3006:     */     }
/* 3007:     */     
/* 3008:     */     public K next()
/* 3009:     */     {
/* 3010:3720 */       return nextEntry().getKey();
/* 3011:     */     }
/* 3012:     */   }
/* 3013:     */   
/* 3014:     */   final class ValueIterator
/* 3015:     */     extends MapMakerInternalMap<K, V>.HashIterator<V>
/* 3016:     */   {
/* 3017:     */     ValueIterator()
/* 3018:     */     {
/* 3019:3724 */       super();
/* 3020:     */     }
/* 3021:     */     
/* 3022:     */     public V next()
/* 3023:     */     {
/* 3024:3728 */       return nextEntry().getValue();
/* 3025:     */     }
/* 3026:     */   }
/* 3027:     */   
/* 3028:     */   final class WriteThroughEntry
/* 3029:     */     extends AbstractMapEntry<K, V>
/* 3030:     */   {
/* 3031:     */     final K key;
/* 3032:     */     V value;
/* 3033:     */     
/* 3034:     */     WriteThroughEntry(V key)
/* 3035:     */     {
/* 3036:3741 */       this.key = key;
/* 3037:3742 */       this.value = value;
/* 3038:     */     }
/* 3039:     */     
/* 3040:     */     public K getKey()
/* 3041:     */     {
/* 3042:3747 */       return this.key;
/* 3043:     */     }
/* 3044:     */     
/* 3045:     */     public V getValue()
/* 3046:     */     {
/* 3047:3752 */       return this.value;
/* 3048:     */     }
/* 3049:     */     
/* 3050:     */     public boolean equals(@Nullable Object object)
/* 3051:     */     {
/* 3052:3758 */       if ((object instanceof Map.Entry))
/* 3053:     */       {
/* 3054:3759 */         Map.Entry<?, ?> that = (Map.Entry)object;
/* 3055:3760 */         return (this.key.equals(that.getKey())) && (this.value.equals(that.getValue()));
/* 3056:     */       }
/* 3057:3762 */       return false;
/* 3058:     */     }
/* 3059:     */     
/* 3060:     */     public int hashCode()
/* 3061:     */     {
/* 3062:3768 */       return this.key.hashCode() ^ this.value.hashCode();
/* 3063:     */     }
/* 3064:     */     
/* 3065:     */     public V setValue(V newValue)
/* 3066:     */     {
/* 3067:3773 */       V oldValue = MapMakerInternalMap.this.put(this.key, newValue);
/* 3068:3774 */       this.value = newValue;
/* 3069:3775 */       return oldValue;
/* 3070:     */     }
/* 3071:     */   }
/* 3072:     */   
/* 3073:     */   final class EntryIterator
/* 3074:     */     extends MapMakerInternalMap<K, V>.HashIterator<Map.Entry<K, V>>
/* 3075:     */   {
/* 3076:     */     EntryIterator()
/* 3077:     */     {
/* 3078:3779 */       super();
/* 3079:     */     }
/* 3080:     */     
/* 3081:     */     public Map.Entry<K, V> next()
/* 3082:     */     {
/* 3083:3783 */       return nextEntry();
/* 3084:     */     }
/* 3085:     */   }
/* 3086:     */   
/* 3087:     */   final class KeySet
/* 3088:     */     extends MapMakerInternalMap.SafeToArraySet<K>
/* 3089:     */   {
/* 3090:     */     KeySet()
/* 3091:     */     {
/* 3092:3788 */       super();
/* 3093:     */     }
/* 3094:     */     
/* 3095:     */     public Iterator<K> iterator()
/* 3096:     */     {
/* 3097:3792 */       return new MapMakerInternalMap.KeyIterator(MapMakerInternalMap.this);
/* 3098:     */     }
/* 3099:     */     
/* 3100:     */     public int size()
/* 3101:     */     {
/* 3102:3797 */       return MapMakerInternalMap.this.size();
/* 3103:     */     }
/* 3104:     */     
/* 3105:     */     public boolean isEmpty()
/* 3106:     */     {
/* 3107:3802 */       return MapMakerInternalMap.this.isEmpty();
/* 3108:     */     }
/* 3109:     */     
/* 3110:     */     public boolean contains(Object o)
/* 3111:     */     {
/* 3112:3807 */       return MapMakerInternalMap.this.containsKey(o);
/* 3113:     */     }
/* 3114:     */     
/* 3115:     */     public boolean remove(Object o)
/* 3116:     */     {
/* 3117:3812 */       return MapMakerInternalMap.this.remove(o) != null;
/* 3118:     */     }
/* 3119:     */     
/* 3120:     */     public void clear()
/* 3121:     */     {
/* 3122:3817 */       MapMakerInternalMap.this.clear();
/* 3123:     */     }
/* 3124:     */   }
/* 3125:     */   
/* 3126:     */   final class Values
/* 3127:     */     extends AbstractCollection<V>
/* 3128:     */   {
/* 3129:     */     Values() {}
/* 3130:     */     
/* 3131:     */     public Iterator<V> iterator()
/* 3132:     */     {
/* 3133:3826 */       return new MapMakerInternalMap.ValueIterator(MapMakerInternalMap.this);
/* 3134:     */     }
/* 3135:     */     
/* 3136:     */     public int size()
/* 3137:     */     {
/* 3138:3831 */       return MapMakerInternalMap.this.size();
/* 3139:     */     }
/* 3140:     */     
/* 3141:     */     public boolean isEmpty()
/* 3142:     */     {
/* 3143:3836 */       return MapMakerInternalMap.this.isEmpty();
/* 3144:     */     }
/* 3145:     */     
/* 3146:     */     public boolean contains(Object o)
/* 3147:     */     {
/* 3148:3841 */       return MapMakerInternalMap.this.containsValue(o);
/* 3149:     */     }
/* 3150:     */     
/* 3151:     */     public void clear()
/* 3152:     */     {
/* 3153:3846 */       MapMakerInternalMap.this.clear();
/* 3154:     */     }
/* 3155:     */     
/* 3156:     */     public Object[] toArray()
/* 3157:     */     {
/* 3158:3854 */       return MapMakerInternalMap.toArrayList(this).toArray();
/* 3159:     */     }
/* 3160:     */     
/* 3161:     */     public <E> E[] toArray(E[] a)
/* 3162:     */     {
/* 3163:3859 */       return MapMakerInternalMap.toArrayList(this).toArray(a);
/* 3164:     */     }
/* 3165:     */   }
/* 3166:     */   
/* 3167:     */   final class EntrySet
/* 3168:     */     extends MapMakerInternalMap.SafeToArraySet<Map.Entry<K, V>>
/* 3169:     */   {
/* 3170:     */     EntrySet()
/* 3171:     */     {
/* 3172:3864 */       super();
/* 3173:     */     }
/* 3174:     */     
/* 3175:     */     public Iterator<Map.Entry<K, V>> iterator()
/* 3176:     */     {
/* 3177:3868 */       return new MapMakerInternalMap.EntryIterator(MapMakerInternalMap.this);
/* 3178:     */     }
/* 3179:     */     
/* 3180:     */     public boolean contains(Object o)
/* 3181:     */     {
/* 3182:3873 */       if (!(o instanceof Map.Entry)) {
/* 3183:3874 */         return false;
/* 3184:     */       }
/* 3185:3876 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 3186:3877 */       Object key = e.getKey();
/* 3187:3878 */       if (key == null) {
/* 3188:3879 */         return false;
/* 3189:     */       }
/* 3190:3881 */       V v = MapMakerInternalMap.this.get(key);
/* 3191:     */       
/* 3192:3883 */       return (v != null) && (MapMakerInternalMap.this.valueEquivalence.equivalent(e.getValue(), v));
/* 3193:     */     }
/* 3194:     */     
/* 3195:     */     public boolean remove(Object o)
/* 3196:     */     {
/* 3197:3888 */       if (!(o instanceof Map.Entry)) {
/* 3198:3889 */         return false;
/* 3199:     */       }
/* 3200:3891 */       Map.Entry<?, ?> e = (Map.Entry)o;
/* 3201:3892 */       Object key = e.getKey();
/* 3202:3893 */       return (key != null) && (MapMakerInternalMap.this.remove(key, e.getValue()));
/* 3203:     */     }
/* 3204:     */     
/* 3205:     */     public int size()
/* 3206:     */     {
/* 3207:3898 */       return MapMakerInternalMap.this.size();
/* 3208:     */     }
/* 3209:     */     
/* 3210:     */     public boolean isEmpty()
/* 3211:     */     {
/* 3212:3903 */       return MapMakerInternalMap.this.isEmpty();
/* 3213:     */     }
/* 3214:     */     
/* 3215:     */     public void clear()
/* 3216:     */     {
/* 3217:3908 */       MapMakerInternalMap.this.clear();
/* 3218:     */     }
/* 3219:     */   }
/* 3220:     */   
/* 3221:     */   private static abstract class SafeToArraySet<E>
/* 3222:     */     extends AbstractSet<E>
/* 3223:     */   {
/* 3224:     */     public Object[] toArray()
/* 3225:     */     {
/* 3226:3918 */       return MapMakerInternalMap.toArrayList(this).toArray();
/* 3227:     */     }
/* 3228:     */     
/* 3229:     */     public <E> E[] toArray(E[] a)
/* 3230:     */     {
/* 3231:3923 */       return MapMakerInternalMap.toArrayList(this).toArray(a);
/* 3232:     */     }
/* 3233:     */   }
/* 3234:     */   
/* 3235:     */   private static <E> ArrayList<E> toArrayList(Collection<E> c)
/* 3236:     */   {
/* 3237:3929 */     ArrayList<E> result = new ArrayList(c.size());
/* 3238:3930 */     Iterators.addAll(result, c.iterator());
/* 3239:3931 */     return result;
/* 3240:     */   }
/* 3241:     */   
/* 3242:     */   Object writeReplace()
/* 3243:     */   {
/* 3244:3939 */     return new SerializationProxy(this.keyStrength, this.valueStrength, this.keyEquivalence, this.valueEquivalence, this.expireAfterWriteNanos, this.expireAfterAccessNanos, this.maximumSize, this.concurrencyLevel, this.removalListener, this);
/* 3245:     */   }
/* 3246:     */   
/* 3247:     */   static abstract class AbstractSerializationProxy<K, V>
/* 3248:     */     extends ForwardingConcurrentMap<K, V>
/* 3249:     */     implements Serializable
/* 3250:     */   {
/* 3251:     */     private static final long serialVersionUID = 3L;
/* 3252:     */     final MapMakerInternalMap.Strength keyStrength;
/* 3253:     */     final MapMakerInternalMap.Strength valueStrength;
/* 3254:     */     final Equivalence<Object> keyEquivalence;
/* 3255:     */     final Equivalence<Object> valueEquivalence;
/* 3256:     */     final long expireAfterWriteNanos;
/* 3257:     */     final long expireAfterAccessNanos;
/* 3258:     */     final int maximumSize;
/* 3259:     */     final int concurrencyLevel;
/* 3260:     */     final MapMaker.RemovalListener<? super K, ? super V> removalListener;
/* 3261:     */     transient ConcurrentMap<K, V> delegate;
/* 3262:     */     
/* 3263:     */     AbstractSerializationProxy(MapMakerInternalMap.Strength keyStrength, MapMakerInternalMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expireAfterWriteNanos, long expireAfterAccessNanos, int maximumSize, int concurrencyLevel, MapMaker.RemovalListener<? super K, ? super V> removalListener, ConcurrentMap<K, V> delegate)
/* 3264:     */     {
/* 3265:3983 */       this.keyStrength = keyStrength;
/* 3266:3984 */       this.valueStrength = valueStrength;
/* 3267:3985 */       this.keyEquivalence = keyEquivalence;
/* 3268:3986 */       this.valueEquivalence = valueEquivalence;
/* 3269:3987 */       this.expireAfterWriteNanos = expireAfterWriteNanos;
/* 3270:3988 */       this.expireAfterAccessNanos = expireAfterAccessNanos;
/* 3271:3989 */       this.maximumSize = maximumSize;
/* 3272:3990 */       this.concurrencyLevel = concurrencyLevel;
/* 3273:3991 */       this.removalListener = removalListener;
/* 3274:3992 */       this.delegate = delegate;
/* 3275:     */     }
/* 3276:     */     
/* 3277:     */     protected ConcurrentMap<K, V> delegate()
/* 3278:     */     {
/* 3279:3997 */       return this.delegate;
/* 3280:     */     }
/* 3281:     */     
/* 3282:     */     void writeMapTo(ObjectOutputStream out)
/* 3283:     */       throws IOException
/* 3284:     */     {
/* 3285:4001 */       out.writeInt(this.delegate.size());
/* 3286:4002 */       for (Map.Entry<K, V> entry : this.delegate.entrySet())
/* 3287:     */       {
/* 3288:4003 */         out.writeObject(entry.getKey());
/* 3289:4004 */         out.writeObject(entry.getValue());
/* 3290:     */       }
/* 3291:4006 */       out.writeObject(null);
/* 3292:     */     }
/* 3293:     */     
/* 3294:     */     MapMaker readMapMaker(ObjectInputStream in)
/* 3295:     */       throws IOException
/* 3296:     */     {
/* 3297:4011 */       int size = in.readInt();
/* 3298:4012 */       MapMaker mapMaker = new MapMaker().initialCapacity(size).setKeyStrength(this.keyStrength).setValueStrength(this.valueStrength).keyEquivalence(this.keyEquivalence).concurrencyLevel(this.concurrencyLevel);
/* 3299:     */       
/* 3300:     */ 
/* 3301:     */ 
/* 3302:     */ 
/* 3303:     */ 
/* 3304:     */ 
/* 3305:4019 */       mapMaker.removalListener(this.removalListener);
/* 3306:4020 */       if (this.expireAfterWriteNanos > 0L) {
/* 3307:4021 */         mapMaker.expireAfterWrite(this.expireAfterWriteNanos, TimeUnit.NANOSECONDS);
/* 3308:     */       }
/* 3309:4023 */       if (this.expireAfterAccessNanos > 0L) {
/* 3310:4024 */         mapMaker.expireAfterAccess(this.expireAfterAccessNanos, TimeUnit.NANOSECONDS);
/* 3311:     */       }
/* 3312:4026 */       if (this.maximumSize != -1) {
/* 3313:4027 */         mapMaker.maximumSize(this.maximumSize);
/* 3314:     */       }
/* 3315:4029 */       return mapMaker;
/* 3316:     */     }
/* 3317:     */     
/* 3318:     */     void readEntries(ObjectInputStream in)
/* 3319:     */       throws IOException, ClassNotFoundException
/* 3320:     */     {
/* 3321:     */       for (;;)
/* 3322:     */       {
/* 3323:4035 */         K key = in.readObject();
/* 3324:4036 */         if (key == null) {
/* 3325:     */           break;
/* 3326:     */         }
/* 3327:4039 */         V value = in.readObject();
/* 3328:4040 */         this.delegate.put(key, value);
/* 3329:     */       }
/* 3330:     */     }
/* 3331:     */   }
/* 3332:     */   
/* 3333:     */   private static final class SerializationProxy<K, V>
/* 3334:     */     extends MapMakerInternalMap.AbstractSerializationProxy<K, V>
/* 3335:     */   {
/* 3336:     */     private static final long serialVersionUID = 3L;
/* 3337:     */     
/* 3338:     */     SerializationProxy(MapMakerInternalMap.Strength keyStrength, MapMakerInternalMap.Strength valueStrength, Equivalence<Object> keyEquivalence, Equivalence<Object> valueEquivalence, long expireAfterWriteNanos, long expireAfterAccessNanos, int maximumSize, int concurrencyLevel, MapMaker.RemovalListener<? super K, ? super V> removalListener, ConcurrentMap<K, V> delegate)
/* 3339:     */     {
/* 3340:4063 */       super(valueStrength, keyEquivalence, valueEquivalence, expireAfterWriteNanos, expireAfterAccessNanos, maximumSize, concurrencyLevel, removalListener, delegate);
/* 3341:     */     }
/* 3342:     */     
/* 3343:     */     private void writeObject(ObjectOutputStream out)
/* 3344:     */       throws IOException
/* 3345:     */     {
/* 3346:4077 */       out.defaultWriteObject();
/* 3347:4078 */       writeMapTo(out);
/* 3348:     */     }
/* 3349:     */     
/* 3350:     */     private void readObject(ObjectInputStream in)
/* 3351:     */       throws IOException, ClassNotFoundException
/* 3352:     */     {
/* 3353:4082 */       in.defaultReadObject();
/* 3354:4083 */       MapMaker mapMaker = readMapMaker(in);
/* 3355:4084 */       this.delegate = mapMaker.makeMap();
/* 3356:4085 */       readEntries(in);
/* 3357:     */     }
/* 3358:     */     
/* 3359:     */     private Object readResolve()
/* 3360:     */     {
/* 3361:4089 */       return this.delegate;
/* 3362:     */     }
/* 3363:     */   }
/* 3364:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.MapMakerInternalMap
 * JD-Core Version:    0.7.0.1
 */