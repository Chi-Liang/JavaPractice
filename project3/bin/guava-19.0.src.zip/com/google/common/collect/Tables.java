/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Function;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Supplier;
/*   9:    */ import java.io.Serializable;
/*  10:    */ import java.util.Collection;
/*  11:    */ import java.util.Collections;
/*  12:    */ import java.util.Iterator;
/*  13:    */ import java.util.Map;
/*  14:    */ import java.util.Set;
/*  15:    */ import java.util.SortedMap;
/*  16:    */ import java.util.SortedSet;
/*  17:    */ import javax.annotation.Nullable;
/*  18:    */ 
/*  19:    */ @GwtCompatible
/*  20:    */ public final class Tables
/*  21:    */ {
/*  22:    */   public static <R, C, V> Table.Cell<R, C, V> immutableCell(@Nullable R rowKey, @Nullable C columnKey, @Nullable V value)
/*  23:    */   {
/*  24: 67 */     return new ImmutableCell(rowKey, columnKey, value);
/*  25:    */   }
/*  26:    */   
/*  27:    */   static final class ImmutableCell<R, C, V>
/*  28:    */     extends Tables.AbstractCell<R, C, V>
/*  29:    */     implements Serializable
/*  30:    */   {
/*  31:    */     private final R rowKey;
/*  32:    */     private final C columnKey;
/*  33:    */     private final V value;
/*  34:    */     private static final long serialVersionUID = 0L;
/*  35:    */     
/*  36:    */     ImmutableCell(@Nullable R rowKey, @Nullable C columnKey, @Nullable V value)
/*  37:    */     {
/*  38: 76 */       this.rowKey = rowKey;
/*  39: 77 */       this.columnKey = columnKey;
/*  40: 78 */       this.value = value;
/*  41:    */     }
/*  42:    */     
/*  43:    */     public R getRowKey()
/*  44:    */     {
/*  45: 83 */       return this.rowKey;
/*  46:    */     }
/*  47:    */     
/*  48:    */     public C getColumnKey()
/*  49:    */     {
/*  50: 88 */       return this.columnKey;
/*  51:    */     }
/*  52:    */     
/*  53:    */     public V getValue()
/*  54:    */     {
/*  55: 93 */       return this.value;
/*  56:    */     }
/*  57:    */   }
/*  58:    */   
/*  59:    */   static abstract class AbstractCell<R, C, V>
/*  60:    */     implements Table.Cell<R, C, V>
/*  61:    */   {
/*  62:    */     public boolean equals(Object obj)
/*  63:    */     {
/*  64:105 */       if (obj == this) {
/*  65:106 */         return true;
/*  66:    */       }
/*  67:108 */       if ((obj instanceof Table.Cell))
/*  68:    */       {
/*  69:109 */         Table.Cell<?, ?, ?> other = (Table.Cell)obj;
/*  70:110 */         return (Objects.equal(getRowKey(), other.getRowKey())) && (Objects.equal(getColumnKey(), other.getColumnKey())) && (Objects.equal(getValue(), other.getValue()));
/*  71:    */       }
/*  72:114 */       return false;
/*  73:    */     }
/*  74:    */     
/*  75:    */     public int hashCode()
/*  76:    */     {
/*  77:119 */       return Objects.hashCode(new Object[] { getRowKey(), getColumnKey(), getValue() });
/*  78:    */     }
/*  79:    */     
/*  80:    */     public String toString()
/*  81:    */     {
/*  82:124 */       return "(" + getRowKey() + "," + getColumnKey() + ")=" + getValue();
/*  83:    */     }
/*  84:    */   }
/*  85:    */   
/*  86:    */   public static <R, C, V> Table<C, R, V> transpose(Table<R, C, V> table)
/*  87:    */   {
/*  88:143 */     return (table instanceof TransposeTable) ? ((TransposeTable)table).original : new TransposeTable(table);
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static class TransposeTable<C, R, V>
/*  92:    */     extends AbstractTable<C, R, V>
/*  93:    */   {
/*  94:    */     final Table<R, C, V> original;
/*  95:    */     
/*  96:    */     TransposeTable(Table<R, C, V> original)
/*  97:    */     {
/*  98:152 */       this.original = ((Table)Preconditions.checkNotNull(original));
/*  99:    */     }
/* 100:    */     
/* 101:    */     public void clear()
/* 102:    */     {
/* 103:157 */       this.original.clear();
/* 104:    */     }
/* 105:    */     
/* 106:    */     public Map<C, V> column(R columnKey)
/* 107:    */     {
/* 108:162 */       return this.original.row(columnKey);
/* 109:    */     }
/* 110:    */     
/* 111:    */     public Set<R> columnKeySet()
/* 112:    */     {
/* 113:167 */       return this.original.rowKeySet();
/* 114:    */     }
/* 115:    */     
/* 116:    */     public Map<R, Map<C, V>> columnMap()
/* 117:    */     {
/* 118:172 */       return this.original.rowMap();
/* 119:    */     }
/* 120:    */     
/* 121:    */     public boolean contains(@Nullable Object rowKey, @Nullable Object columnKey)
/* 122:    */     {
/* 123:177 */       return this.original.contains(columnKey, rowKey);
/* 124:    */     }
/* 125:    */     
/* 126:    */     public boolean containsColumn(@Nullable Object columnKey)
/* 127:    */     {
/* 128:182 */       return this.original.containsRow(columnKey);
/* 129:    */     }
/* 130:    */     
/* 131:    */     public boolean containsRow(@Nullable Object rowKey)
/* 132:    */     {
/* 133:187 */       return this.original.containsColumn(rowKey);
/* 134:    */     }
/* 135:    */     
/* 136:    */     public boolean containsValue(@Nullable Object value)
/* 137:    */     {
/* 138:192 */       return this.original.containsValue(value);
/* 139:    */     }
/* 140:    */     
/* 141:    */     public V get(@Nullable Object rowKey, @Nullable Object columnKey)
/* 142:    */     {
/* 143:197 */       return this.original.get(columnKey, rowKey);
/* 144:    */     }
/* 145:    */     
/* 146:    */     public V put(C rowKey, R columnKey, V value)
/* 147:    */     {
/* 148:202 */       return this.original.put(columnKey, rowKey, value);
/* 149:    */     }
/* 150:    */     
/* 151:    */     public void putAll(Table<? extends C, ? extends R, ? extends V> table)
/* 152:    */     {
/* 153:207 */       this.original.putAll(Tables.transpose(table));
/* 154:    */     }
/* 155:    */     
/* 156:    */     public V remove(@Nullable Object rowKey, @Nullable Object columnKey)
/* 157:    */     {
/* 158:212 */       return this.original.remove(columnKey, rowKey);
/* 159:    */     }
/* 160:    */     
/* 161:    */     public Map<R, V> row(C rowKey)
/* 162:    */     {
/* 163:217 */       return this.original.column(rowKey);
/* 164:    */     }
/* 165:    */     
/* 166:    */     public Set<C> rowKeySet()
/* 167:    */     {
/* 168:222 */       return this.original.columnKeySet();
/* 169:    */     }
/* 170:    */     
/* 171:    */     public Map<C, Map<R, V>> rowMap()
/* 172:    */     {
/* 173:227 */       return this.original.columnMap();
/* 174:    */     }
/* 175:    */     
/* 176:    */     public int size()
/* 177:    */     {
/* 178:232 */       return this.original.size();
/* 179:    */     }
/* 180:    */     
/* 181:    */     public Collection<V> values()
/* 182:    */     {
/* 183:237 */       return this.original.values();
/* 184:    */     }
/* 185:    */     
/* 186:241 */     private static final Function<Table.Cell<?, ?, ?>, Table.Cell<?, ?, ?>> TRANSPOSE_CELL = new Function()
/* 187:    */     {
/* 188:    */       public Table.Cell<?, ?, ?> apply(Table.Cell<?, ?, ?> cell)
/* 189:    */       {
/* 190:245 */         return Tables.immutableCell(cell.getColumnKey(), cell.getRowKey(), cell.getValue());
/* 191:    */       }
/* 192:    */     };
/* 193:    */     
/* 194:    */     Iterator<Table.Cell<C, R, V>> cellIterator()
/* 195:    */     {
/* 196:252 */       return Iterators.transform(this.original.cellSet().iterator(), TRANSPOSE_CELL);
/* 197:    */     }
/* 198:    */   }
/* 199:    */   
/* 200:    */   @Beta
/* 201:    */   public static <R, C, V> Table<R, C, V> newCustomTable(Map<R, Map<C, V>> backingMap, Supplier<? extends Map<C, V>> factory)
/* 202:    */   {
/* 203:300 */     Preconditions.checkArgument(backingMap.isEmpty());
/* 204:301 */     Preconditions.checkNotNull(factory);
/* 205:    */     
/* 206:303 */     return new StandardTable(backingMap, factory);
/* 207:    */   }
/* 208:    */   
/* 209:    */   @Beta
/* 210:    */   public static <R, C, V1, V2> Table<R, C, V2> transformValues(Table<R, C, V1> fromTable, Function<? super V1, V2> function)
/* 211:    */   {
/* 212:335 */     return new TransformedTable(fromTable, function);
/* 213:    */   }
/* 214:    */   
/* 215:    */   private static class TransformedTable<R, C, V1, V2>
/* 216:    */     extends AbstractTable<R, C, V2>
/* 217:    */   {
/* 218:    */     final Table<R, C, V1> fromTable;
/* 219:    */     final Function<? super V1, V2> function;
/* 220:    */     
/* 221:    */     TransformedTable(Table<R, C, V1> fromTable, Function<? super V1, V2> function)
/* 222:    */     {
/* 223:343 */       this.fromTable = ((Table)Preconditions.checkNotNull(fromTable));
/* 224:344 */       this.function = ((Function)Preconditions.checkNotNull(function));
/* 225:    */     }
/* 226:    */     
/* 227:    */     public boolean contains(Object rowKey, Object columnKey)
/* 228:    */     {
/* 229:349 */       return this.fromTable.contains(rowKey, columnKey);
/* 230:    */     }
/* 231:    */     
/* 232:    */     public V2 get(Object rowKey, Object columnKey)
/* 233:    */     {
/* 234:356 */       return contains(rowKey, columnKey) ? this.function.apply(this.fromTable.get(rowKey, columnKey)) : null;
/* 235:    */     }
/* 236:    */     
/* 237:    */     public int size()
/* 238:    */     {
/* 239:361 */       return this.fromTable.size();
/* 240:    */     }
/* 241:    */     
/* 242:    */     public void clear()
/* 243:    */     {
/* 244:366 */       this.fromTable.clear();
/* 245:    */     }
/* 246:    */     
/* 247:    */     public V2 put(R rowKey, C columnKey, V2 value)
/* 248:    */     {
/* 249:371 */       throw new UnsupportedOperationException();
/* 250:    */     }
/* 251:    */     
/* 252:    */     public void putAll(Table<? extends R, ? extends C, ? extends V2> table)
/* 253:    */     {
/* 254:376 */       throw new UnsupportedOperationException();
/* 255:    */     }
/* 256:    */     
/* 257:    */     public V2 remove(Object rowKey, Object columnKey)
/* 258:    */     {
/* 259:381 */       return contains(rowKey, columnKey) ? this.function.apply(this.fromTable.remove(rowKey, columnKey)) : null;
/* 260:    */     }
/* 261:    */     
/* 262:    */     public Map<C, V2> row(R rowKey)
/* 263:    */     {
/* 264:388 */       return Maps.transformValues(this.fromTable.row(rowKey), this.function);
/* 265:    */     }
/* 266:    */     
/* 267:    */     public Map<R, V2> column(C columnKey)
/* 268:    */     {
/* 269:393 */       return Maps.transformValues(this.fromTable.column(columnKey), this.function);
/* 270:    */     }
/* 271:    */     
/* 272:    */     Function<Table.Cell<R, C, V1>, Table.Cell<R, C, V2>> cellFunction()
/* 273:    */     {
/* 274:397 */       new Function()
/* 275:    */       {
/* 276:    */         public Table.Cell<R, C, V2> apply(Table.Cell<R, C, V1> cell)
/* 277:    */         {
/* 278:400 */           return Tables.immutableCell(cell.getRowKey(), cell.getColumnKey(), Tables.TransformedTable.this.function.apply(cell.getValue()));
/* 279:    */         }
/* 280:    */       };
/* 281:    */     }
/* 282:    */     
/* 283:    */     Iterator<Table.Cell<R, C, V2>> cellIterator()
/* 284:    */     {
/* 285:408 */       return Iterators.transform(this.fromTable.cellSet().iterator(), cellFunction());
/* 286:    */     }
/* 287:    */     
/* 288:    */     public Set<R> rowKeySet()
/* 289:    */     {
/* 290:413 */       return this.fromTable.rowKeySet();
/* 291:    */     }
/* 292:    */     
/* 293:    */     public Set<C> columnKeySet()
/* 294:    */     {
/* 295:418 */       return this.fromTable.columnKeySet();
/* 296:    */     }
/* 297:    */     
/* 298:    */     Collection<V2> createValues()
/* 299:    */     {
/* 300:423 */       return Collections2.transform(this.fromTable.values(), this.function);
/* 301:    */     }
/* 302:    */     
/* 303:    */     public Map<R, Map<C, V2>> rowMap()
/* 304:    */     {
/* 305:428 */       Function<Map<C, V1>, Map<C, V2>> rowFunction = new Function()
/* 306:    */       {
/* 307:    */         public Map<C, V2> apply(Map<C, V1> row)
/* 308:    */         {
/* 309:432 */           return Maps.transformValues(row, Tables.TransformedTable.this.function);
/* 310:    */         }
/* 311:434 */       };
/* 312:435 */       return Maps.transformValues(this.fromTable.rowMap(), rowFunction);
/* 313:    */     }
/* 314:    */     
/* 315:    */     public Map<C, Map<R, V2>> columnMap()
/* 316:    */     {
/* 317:440 */       Function<Map<R, V1>, Map<R, V2>> columnFunction = new Function()
/* 318:    */       {
/* 319:    */         public Map<R, V2> apply(Map<R, V1> column)
/* 320:    */         {
/* 321:444 */           return Maps.transformValues(column, Tables.TransformedTable.this.function);
/* 322:    */         }
/* 323:446 */       };
/* 324:447 */       return Maps.transformValues(this.fromTable.columnMap(), columnFunction);
/* 325:    */     }
/* 326:    */   }
/* 327:    */   
/* 328:    */   public static <R, C, V> Table<R, C, V> unmodifiableTable(Table<? extends R, ? extends C, ? extends V> table)
/* 329:    */   {
/* 330:468 */     return new UnmodifiableTable(table);
/* 331:    */   }
/* 332:    */   
/* 333:    */   private static class UnmodifiableTable<R, C, V>
/* 334:    */     extends ForwardingTable<R, C, V>
/* 335:    */     implements Serializable
/* 336:    */   {
/* 337:    */     final Table<? extends R, ? extends C, ? extends V> delegate;
/* 338:    */     private static final long serialVersionUID = 0L;
/* 339:    */     
/* 340:    */     UnmodifiableTable(Table<? extends R, ? extends C, ? extends V> delegate)
/* 341:    */     {
/* 342:476 */       this.delegate = ((Table)Preconditions.checkNotNull(delegate));
/* 343:    */     }
/* 344:    */     
/* 345:    */     protected Table<R, C, V> delegate()
/* 346:    */     {
/* 347:482 */       return this.delegate;
/* 348:    */     }
/* 349:    */     
/* 350:    */     public Set<Table.Cell<R, C, V>> cellSet()
/* 351:    */     {
/* 352:487 */       return Collections.unmodifiableSet(super.cellSet());
/* 353:    */     }
/* 354:    */     
/* 355:    */     public void clear()
/* 356:    */     {
/* 357:492 */       throw new UnsupportedOperationException();
/* 358:    */     }
/* 359:    */     
/* 360:    */     public Map<R, V> column(@Nullable C columnKey)
/* 361:    */     {
/* 362:497 */       return Collections.unmodifiableMap(super.column(columnKey));
/* 363:    */     }
/* 364:    */     
/* 365:    */     public Set<C> columnKeySet()
/* 366:    */     {
/* 367:502 */       return Collections.unmodifiableSet(super.columnKeySet());
/* 368:    */     }
/* 369:    */     
/* 370:    */     public Map<C, Map<R, V>> columnMap()
/* 371:    */     {
/* 372:507 */       Function<Map<R, V>, Map<R, V>> wrapper = Tables.access$000();
/* 373:508 */       return Collections.unmodifiableMap(Maps.transformValues(super.columnMap(), wrapper));
/* 374:    */     }
/* 375:    */     
/* 376:    */     public V put(@Nullable R rowKey, @Nullable C columnKey, @Nullable V value)
/* 377:    */     {
/* 378:513 */       throw new UnsupportedOperationException();
/* 379:    */     }
/* 380:    */     
/* 381:    */     public void putAll(Table<? extends R, ? extends C, ? extends V> table)
/* 382:    */     {
/* 383:518 */       throw new UnsupportedOperationException();
/* 384:    */     }
/* 385:    */     
/* 386:    */     public V remove(@Nullable Object rowKey, @Nullable Object columnKey)
/* 387:    */     {
/* 388:523 */       throw new UnsupportedOperationException();
/* 389:    */     }
/* 390:    */     
/* 391:    */     public Map<C, V> row(@Nullable R rowKey)
/* 392:    */     {
/* 393:528 */       return Collections.unmodifiableMap(super.row(rowKey));
/* 394:    */     }
/* 395:    */     
/* 396:    */     public Set<R> rowKeySet()
/* 397:    */     {
/* 398:533 */       return Collections.unmodifiableSet(super.rowKeySet());
/* 399:    */     }
/* 400:    */     
/* 401:    */     public Map<R, Map<C, V>> rowMap()
/* 402:    */     {
/* 403:538 */       Function<Map<C, V>, Map<C, V>> wrapper = Tables.access$000();
/* 404:539 */       return Collections.unmodifiableMap(Maps.transformValues(super.rowMap(), wrapper));
/* 405:    */     }
/* 406:    */     
/* 407:    */     public Collection<V> values()
/* 408:    */     {
/* 409:544 */       return Collections.unmodifiableCollection(super.values());
/* 410:    */     }
/* 411:    */   }
/* 412:    */   
/* 413:    */   @Beta
/* 414:    */   public static <R, C, V> RowSortedTable<R, C, V> unmodifiableRowSortedTable(RowSortedTable<R, ? extends C, ? extends V> table)
/* 415:    */   {
/* 416:570 */     return new UnmodifiableRowSortedMap(table);
/* 417:    */   }
/* 418:    */   
/* 419:    */   static final class UnmodifiableRowSortedMap<R, C, V>
/* 420:    */     extends Tables.UnmodifiableTable<R, C, V>
/* 421:    */     implements RowSortedTable<R, C, V>
/* 422:    */   {
/* 423:    */     private static final long serialVersionUID = 0L;
/* 424:    */     
/* 425:    */     public UnmodifiableRowSortedMap(RowSortedTable<R, ? extends C, ? extends V> delegate)
/* 426:    */     {
/* 427:577 */       super();
/* 428:    */     }
/* 429:    */     
/* 430:    */     protected RowSortedTable<R, C, V> delegate()
/* 431:    */     {
/* 432:582 */       return (RowSortedTable)super.delegate();
/* 433:    */     }
/* 434:    */     
/* 435:    */     public SortedMap<R, Map<C, V>> rowMap()
/* 436:    */     {
/* 437:587 */       Function<Map<C, V>, Map<C, V>> wrapper = Tables.access$000();
/* 438:588 */       return Collections.unmodifiableSortedMap(Maps.transformValues(delegate().rowMap(), wrapper));
/* 439:    */     }
/* 440:    */     
/* 441:    */     public SortedSet<R> rowKeySet()
/* 442:    */     {
/* 443:593 */       return Collections.unmodifiableSortedSet(delegate().rowKeySet());
/* 444:    */     }
/* 445:    */   }
/* 446:    */   
/* 447:    */   private static <K, V> Function<Map<K, V>, Map<K, V>> unmodifiableWrapper()
/* 448:    */   {
/* 449:601 */     return UNMODIFIABLE_WRAPPER;
/* 450:    */   }
/* 451:    */   
/* 452:604 */   private static final Function<? extends Map<?, ?>, ? extends Map<?, ?>> UNMODIFIABLE_WRAPPER = new Function()
/* 453:    */   {
/* 454:    */     public Map<Object, Object> apply(Map<Object, Object> input)
/* 455:    */     {
/* 456:608 */       return Collections.unmodifiableMap(input);
/* 457:    */     }
/* 458:    */   };
/* 459:    */   
/* 460:    */   static boolean equalsImpl(Table<?, ?, ?> table, @Nullable Object obj)
/* 461:    */   {
/* 462:613 */     if (obj == table) {
/* 463:614 */       return true;
/* 464:    */     }
/* 465:615 */     if ((obj instanceof Table))
/* 466:    */     {
/* 467:616 */       Table<?, ?, ?> that = (Table)obj;
/* 468:617 */       return table.cellSet().equals(that.cellSet());
/* 469:    */     }
/* 470:619 */     return false;
/* 471:    */   }
/* 472:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Tables
 * JD-Core Version:    0.7.0.1
 */