/*  1:   */ package com.google.common.collect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.util.Iterator;
/*  6:   */ 
/*  7:   */ @GwtCompatible
/*  8:   */ abstract class TransformedIterator<F, T>
/*  9:   */   implements Iterator<T>
/* 10:   */ {
/* 11:   */   final Iterator<? extends F> backingIterator;
/* 12:   */   
/* 13:   */   TransformedIterator(Iterator<? extends F> backingIterator)
/* 14:   */   {
/* 15:36 */     this.backingIterator = ((Iterator)Preconditions.checkNotNull(backingIterator));
/* 16:   */   }
/* 17:   */   
/* 18:   */   abstract T transform(F paramF);
/* 19:   */   
/* 20:   */   public final boolean hasNext()
/* 21:   */   {
/* 22:43 */     return this.backingIterator.hasNext();
/* 23:   */   }
/* 24:   */   
/* 25:   */   public final T next()
/* 26:   */   {
/* 27:48 */     return transform(this.backingIterator.next());
/* 28:   */   }
/* 29:   */   
/* 30:   */   public final void remove()
/* 31:   */   {
/* 32:53 */     this.backingIterator.remove();
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.TransformedIterator
 * JD-Core Version:    0.7.0.1
 */