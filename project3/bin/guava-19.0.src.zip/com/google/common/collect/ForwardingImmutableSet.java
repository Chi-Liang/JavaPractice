package com.google.common.collect;

import com.google.common.annotations.GwtCompatible;

@GwtCompatible(emulated=true)
abstract class ForwardingImmutableSet<E> {}


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.ForwardingImmutableSet
 * JD-Core Version:    0.7.0.1
 */