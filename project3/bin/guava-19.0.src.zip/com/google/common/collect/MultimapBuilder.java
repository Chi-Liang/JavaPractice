/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Supplier;
/*   7:    */ import java.io.Serializable;
/*   8:    */ import java.util.ArrayList;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.Comparator;
/*  11:    */ import java.util.EnumMap;
/*  12:    */ import java.util.EnumSet;
/*  13:    */ import java.util.LinkedList;
/*  14:    */ import java.util.List;
/*  15:    */ import java.util.Map;
/*  16:    */ import java.util.Set;
/*  17:    */ import java.util.SortedSet;
/*  18:    */ import java.util.TreeMap;
/*  19:    */ import java.util.TreeSet;
/*  20:    */ import javax.annotation.CheckReturnValue;
/*  21:    */ 
/*  22:    */ @CheckReturnValue
/*  23:    */ @Beta
/*  24:    */ @GwtCompatible
/*  25:    */ public abstract class MultimapBuilder<K0, V0>
/*  26:    */ {
/*  27:    */   private static final int DEFAULT_EXPECTED_KEYS = 8;
/*  28:    */   
/*  29:    */   public static MultimapBuilderWithKeys<Object> hashKeys()
/*  30:    */   {
/*  31: 89 */     return hashKeys(8);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public static MultimapBuilderWithKeys<Object> hashKeys(int expectedKeys)
/*  35:    */   {
/*  36: 99 */     CollectPreconditions.checkNonnegative(expectedKeys, "expectedKeys");
/*  37:100 */     new MultimapBuilderWithKeys()
/*  38:    */     {
/*  39:    */       <K, V> Map<K, Collection<V>> createMap()
/*  40:    */       {
/*  41:103 */         return Maps.newHashMapWithExpectedSize(this.val$expectedKeys);
/*  42:    */       }
/*  43:    */     };
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static MultimapBuilderWithKeys<Object> linkedHashKeys()
/*  47:    */   {
/*  48:117 */     return linkedHashKeys(8);
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static MultimapBuilderWithKeys<Object> linkedHashKeys(int expectedKeys)
/*  52:    */   {
/*  53:130 */     CollectPreconditions.checkNonnegative(expectedKeys, "expectedKeys");
/*  54:131 */     new MultimapBuilderWithKeys()
/*  55:    */     {
/*  56:    */       <K, V> Map<K, Collection<V>> createMap()
/*  57:    */       {
/*  58:134 */         return Maps.newLinkedHashMapWithExpectedSize(this.val$expectedKeys);
/*  59:    */       }
/*  60:    */     };
/*  61:    */   }
/*  62:    */   
/*  63:    */   public static MultimapBuilderWithKeys<Comparable> treeKeys()
/*  64:    */   {
/*  65:151 */     return treeKeys(Ordering.natural());
/*  66:    */   }
/*  67:    */   
/*  68:    */   public static <K0> MultimapBuilderWithKeys<K0> treeKeys(Comparator<K0> comparator)
/*  69:    */   {
/*  70:168 */     Preconditions.checkNotNull(comparator);
/*  71:169 */     new MultimapBuilderWithKeys()
/*  72:    */     {
/*  73:    */       <K extends K0, V> Map<K, Collection<V>> createMap()
/*  74:    */       {
/*  75:172 */         return new TreeMap(this.val$comparator);
/*  76:    */       }
/*  77:    */     };
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static <K0 extends Enum<K0>> MultimapBuilderWithKeys<K0> enumKeys(Class<K0> keyClass)
/*  81:    */   {
/*  82:182 */     Preconditions.checkNotNull(keyClass);
/*  83:183 */     new MultimapBuilderWithKeys()
/*  84:    */     {
/*  85:    */       <K extends K0, V> Map<K, Collection<V>> createMap()
/*  86:    */       {
/*  87:189 */         return new EnumMap(this.val$keyClass);
/*  88:    */       }
/*  89:    */     };
/*  90:    */   }
/*  91:    */   
/*  92:    */   public abstract <K extends K0, V extends V0> Multimap<K, V> build();
/*  93:    */   
/*  94:    */   private static final class ArrayListSupplier<V>
/*  95:    */     implements Supplier<List<V>>, Serializable
/*  96:    */   {
/*  97:    */     private final int expectedValuesPerKey;
/*  98:    */     
/*  99:    */     ArrayListSupplier(int expectedValuesPerKey)
/* 100:    */     {
/* 101:198 */       this.expectedValuesPerKey = CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 102:    */     }
/* 103:    */     
/* 104:    */     public List<V> get()
/* 105:    */     {
/* 106:203 */       return new ArrayList(this.expectedValuesPerKey);
/* 107:    */     }
/* 108:    */   }
/* 109:    */   
/* 110:    */   private static enum LinkedListSupplier
/* 111:    */     implements Supplier<List<Object>>
/* 112:    */   {
/* 113:208 */     INSTANCE;
/* 114:    */     
/* 115:    */     private LinkedListSupplier() {}
/* 116:    */     
/* 117:    */     public static <V> Supplier<List<V>> instance()
/* 118:    */     {
/* 119:213 */       Supplier<List<V>> result = INSTANCE;
/* 120:214 */       return result;
/* 121:    */     }
/* 122:    */     
/* 123:    */     public List<Object> get()
/* 124:    */     {
/* 125:219 */       return new LinkedList();
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   private static final class HashSetSupplier<V>
/* 130:    */     implements Supplier<Set<V>>, Serializable
/* 131:    */   {
/* 132:    */     private final int expectedValuesPerKey;
/* 133:    */     
/* 134:    */     HashSetSupplier(int expectedValuesPerKey)
/* 135:    */     {
/* 136:227 */       this.expectedValuesPerKey = CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 137:    */     }
/* 138:    */     
/* 139:    */     public Set<V> get()
/* 140:    */     {
/* 141:232 */       return Sets.newHashSetWithExpectedSize(this.expectedValuesPerKey);
/* 142:    */     }
/* 143:    */   }
/* 144:    */   
/* 145:    */   private static final class LinkedHashSetSupplier<V>
/* 146:    */     implements Supplier<Set<V>>, Serializable
/* 147:    */   {
/* 148:    */     private final int expectedValuesPerKey;
/* 149:    */     
/* 150:    */     LinkedHashSetSupplier(int expectedValuesPerKey)
/* 151:    */     {
/* 152:240 */       this.expectedValuesPerKey = CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 153:    */     }
/* 154:    */     
/* 155:    */     public Set<V> get()
/* 156:    */     {
/* 157:245 */       return Sets.newLinkedHashSetWithExpectedSize(this.expectedValuesPerKey);
/* 158:    */     }
/* 159:    */   }
/* 160:    */   
/* 161:    */   private static final class TreeSetSupplier<V>
/* 162:    */     implements Supplier<SortedSet<V>>, Serializable
/* 163:    */   {
/* 164:    */     private final Comparator<? super V> comparator;
/* 165:    */     
/* 166:    */     TreeSetSupplier(Comparator<? super V> comparator)
/* 167:    */     {
/* 168:253 */       this.comparator = ((Comparator)Preconditions.checkNotNull(comparator));
/* 169:    */     }
/* 170:    */     
/* 171:    */     public SortedSet<V> get()
/* 172:    */     {
/* 173:258 */       return new TreeSet(this.comparator);
/* 174:    */     }
/* 175:    */   }
/* 176:    */   
/* 177:    */   private static final class EnumSetSupplier<V extends Enum<V>>
/* 178:    */     implements Supplier<Set<V>>, Serializable
/* 179:    */   {
/* 180:    */     private final Class<V> clazz;
/* 181:    */     
/* 182:    */     EnumSetSupplier(Class<V> clazz)
/* 183:    */     {
/* 184:267 */       this.clazz = ((Class)Preconditions.checkNotNull(clazz));
/* 185:    */     }
/* 186:    */     
/* 187:    */     public Set<V> get()
/* 188:    */     {
/* 189:272 */       return EnumSet.noneOf(this.clazz);
/* 190:    */     }
/* 191:    */   }
/* 192:    */   
/* 193:    */   public static abstract class MultimapBuilderWithKeys<K0>
/* 194:    */   {
/* 195:    */     private static final int DEFAULT_EXPECTED_VALUES_PER_KEY = 2;
/* 196:    */     
/* 197:    */     abstract <K extends K0, V> Map<K, Collection<V>> createMap();
/* 198:    */     
/* 199:    */     public MultimapBuilder.ListMultimapBuilder<K0, Object> arrayListValues()
/* 200:    */     {
/* 201:294 */       return arrayListValues(2);
/* 202:    */     }
/* 203:    */     
/* 204:    */     public MultimapBuilder.ListMultimapBuilder<K0, Object> arrayListValues(final int expectedValuesPerKey)
/* 205:    */     {
/* 206:304 */       CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 207:305 */       new MultimapBuilder.ListMultimapBuilder()
/* 208:    */       {
/* 209:    */         public <K extends K0, V> ListMultimap<K, V> build()
/* 210:    */         {
/* 211:308 */           return Multimaps.newListMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), new MultimapBuilder.ArrayListSupplier(expectedValuesPerKey));
/* 212:    */         }
/* 213:    */       };
/* 214:    */     }
/* 215:    */     
/* 216:    */     public MultimapBuilder.ListMultimapBuilder<K0, Object> linkedListValues()
/* 217:    */     {
/* 218:319 */       new MultimapBuilder.ListMultimapBuilder()
/* 219:    */       {
/* 220:    */         public <K extends K0, V> ListMultimap<K, V> build()
/* 221:    */         {
/* 222:322 */           return Multimaps.newListMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), MultimapBuilder.LinkedListSupplier.instance());
/* 223:    */         }
/* 224:    */       };
/* 225:    */     }
/* 226:    */     
/* 227:    */     public MultimapBuilder.SetMultimapBuilder<K0, Object> hashSetValues()
/* 228:    */     {
/* 229:332 */       return hashSetValues(2);
/* 230:    */     }
/* 231:    */     
/* 232:    */     public MultimapBuilder.SetMultimapBuilder<K0, Object> hashSetValues(final int expectedValuesPerKey)
/* 233:    */     {
/* 234:342 */       CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 235:343 */       new MultimapBuilder.SetMultimapBuilder()
/* 236:    */       {
/* 237:    */         public <K extends K0, V> SetMultimap<K, V> build()
/* 238:    */         {
/* 239:346 */           return Multimaps.newSetMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), new MultimapBuilder.HashSetSupplier(expectedValuesPerKey));
/* 240:    */         }
/* 241:    */       };
/* 242:    */     }
/* 243:    */     
/* 244:    */     public MultimapBuilder.SetMultimapBuilder<K0, Object> linkedHashSetValues()
/* 245:    */     {
/* 246:357 */       return linkedHashSetValues(2);
/* 247:    */     }
/* 248:    */     
/* 249:    */     public MultimapBuilder.SetMultimapBuilder<K0, Object> linkedHashSetValues(final int expectedValuesPerKey)
/* 250:    */     {
/* 251:367 */       CollectPreconditions.checkNonnegative(expectedValuesPerKey, "expectedValuesPerKey");
/* 252:368 */       new MultimapBuilder.SetMultimapBuilder()
/* 253:    */       {
/* 254:    */         public <K extends K0, V> SetMultimap<K, V> build()
/* 255:    */         {
/* 256:371 */           return Multimaps.newSetMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), new MultimapBuilder.LinkedHashSetSupplier(expectedValuesPerKey));
/* 257:    */         }
/* 258:    */       };
/* 259:    */     }
/* 260:    */     
/* 261:    */     public MultimapBuilder.SortedSetMultimapBuilder<K0, Comparable> treeSetValues()
/* 262:    */     {
/* 263:383 */       return treeSetValues(Ordering.natural());
/* 264:    */     }
/* 265:    */     
/* 266:    */     public <V0> MultimapBuilder.SortedSetMultimapBuilder<K0, V0> treeSetValues(final Comparator<V0> comparator)
/* 267:    */     {
/* 268:393 */       Preconditions.checkNotNull(comparator, "comparator");
/* 269:394 */       new MultimapBuilder.SortedSetMultimapBuilder()
/* 270:    */       {
/* 271:    */         public <K extends K0, V extends V0> SortedSetMultimap<K, V> build()
/* 272:    */         {
/* 273:397 */           return Multimaps.newSortedSetMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), new MultimapBuilder.TreeSetSupplier(comparator));
/* 274:    */         }
/* 275:    */       };
/* 276:    */     }
/* 277:    */     
/* 278:    */     public <V0 extends Enum<V0>> MultimapBuilder.SetMultimapBuilder<K0, V0> enumSetValues(final Class<V0> valueClass)
/* 279:    */     {
/* 280:408 */       Preconditions.checkNotNull(valueClass, "valueClass");
/* 281:409 */       new MultimapBuilder.SetMultimapBuilder()
/* 282:    */       {
/* 283:    */         public <K extends K0, V extends V0> SetMultimap<K, V> build()
/* 284:    */         {
/* 285:415 */           Supplier<Set<V>> factory = new MultimapBuilder.EnumSetSupplier(valueClass);
/* 286:416 */           return Multimaps.newSetMultimap(MultimapBuilder.MultimapBuilderWithKeys.this.createMap(), factory);
/* 287:    */         }
/* 288:    */       };
/* 289:    */     }
/* 290:    */   }
/* 291:    */   
/* 292:    */   public <K extends K0, V extends V0> Multimap<K, V> build(Multimap<? extends K, ? extends V> multimap)
/* 293:    */   {
/* 294:433 */     Multimap<K, V> result = build();
/* 295:434 */     result.putAll(multimap);
/* 296:435 */     return result;
/* 297:    */   }
/* 298:    */   
/* 299:    */   public static abstract class ListMultimapBuilder<K0, V0>
/* 300:    */     extends MultimapBuilder<K0, V0>
/* 301:    */   {
/* 302:    */     ListMultimapBuilder()
/* 303:    */     {
/* 304:442 */       super();
/* 305:    */     }
/* 306:    */     
/* 307:    */     public abstract <K extends K0, V extends V0> ListMultimap<K, V> build();
/* 308:    */     
/* 309:    */     public <K extends K0, V extends V0> ListMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap)
/* 310:    */     {
/* 311:450 */       return (ListMultimap)super.build(multimap);
/* 312:    */     }
/* 313:    */   }
/* 314:    */   
/* 315:    */   public static abstract class SetMultimapBuilder<K0, V0>
/* 316:    */     extends MultimapBuilder<K0, V0>
/* 317:    */   {
/* 318:    */     SetMultimapBuilder()
/* 319:    */     {
/* 320:458 */       super();
/* 321:    */     }
/* 322:    */     
/* 323:    */     public abstract <K extends K0, V extends V0> SetMultimap<K, V> build();
/* 324:    */     
/* 325:    */     public <K extends K0, V extends V0> SetMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap)
/* 326:    */     {
/* 327:466 */       return (SetMultimap)super.build(multimap);
/* 328:    */     }
/* 329:    */   }
/* 330:    */   
/* 331:    */   public static abstract class SortedSetMultimapBuilder<K0, V0>
/* 332:    */     extends MultimapBuilder.SetMultimapBuilder<K0, V0>
/* 333:    */   {
/* 334:    */     public abstract <K extends K0, V extends V0> SortedSetMultimap<K, V> build();
/* 335:    */     
/* 336:    */     public <K extends K0, V extends V0> SortedSetMultimap<K, V> build(Multimap<? extends K, ? extends V> multimap)
/* 337:    */     {
/* 338:482 */       return (SortedSetMultimap)super.build(multimap);
/* 339:    */     }
/* 340:    */   }
/* 341:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.MultimapBuilder
 * JD-Core Version:    0.7.0.1
 */