/*   1:    */ package com.google.common.collect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Comparator;
/*   5:    */ import java.util.NavigableSet;
/*   6:    */ 
/*   7:    */ @GwtCompatible(emulated=true)
/*   8:    */ final class UnmodifiableSortedMultiset<E>
/*   9:    */   extends Multisets.UnmodifiableMultiset<E>
/*  10:    */   implements SortedMultiset<E>
/*  11:    */ {
/*  12:    */   private transient UnmodifiableSortedMultiset<E> descendingMultiset;
/*  13:    */   private static final long serialVersionUID = 0L;
/*  14:    */   
/*  15:    */   UnmodifiableSortedMultiset(SortedMultiset<E> delegate)
/*  16:    */   {
/*  17: 36 */     super(delegate);
/*  18:    */   }
/*  19:    */   
/*  20:    */   protected SortedMultiset<E> delegate()
/*  21:    */   {
/*  22: 41 */     return (SortedMultiset)super.delegate();
/*  23:    */   }
/*  24:    */   
/*  25:    */   public Comparator<? super E> comparator()
/*  26:    */   {
/*  27: 46 */     return delegate().comparator();
/*  28:    */   }
/*  29:    */   
/*  30:    */   NavigableSet<E> createElementSet()
/*  31:    */   {
/*  32: 51 */     return Sets.unmodifiableNavigableSet(delegate().elementSet());
/*  33:    */   }
/*  34:    */   
/*  35:    */   public NavigableSet<E> elementSet()
/*  36:    */   {
/*  37: 56 */     return (NavigableSet)super.elementSet();
/*  38:    */   }
/*  39:    */   
/*  40:    */   public SortedMultiset<E> descendingMultiset()
/*  41:    */   {
/*  42: 63 */     UnmodifiableSortedMultiset<E> result = this.descendingMultiset;
/*  43: 64 */     if (result == null)
/*  44:    */     {
/*  45: 65 */       result = new UnmodifiableSortedMultiset(delegate().descendingMultiset());
/*  46: 66 */       result.descendingMultiset = this;
/*  47: 67 */       return this.descendingMultiset = result;
/*  48:    */     }
/*  49: 69 */     return result;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public Multiset.Entry<E> firstEntry()
/*  53:    */   {
/*  54: 74 */     return delegate().firstEntry();
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Multiset.Entry<E> lastEntry()
/*  58:    */   {
/*  59: 79 */     return delegate().lastEntry();
/*  60:    */   }
/*  61:    */   
/*  62:    */   public Multiset.Entry<E> pollFirstEntry()
/*  63:    */   {
/*  64: 84 */     throw new UnsupportedOperationException();
/*  65:    */   }
/*  66:    */   
/*  67:    */   public Multiset.Entry<E> pollLastEntry()
/*  68:    */   {
/*  69: 89 */     throw new UnsupportedOperationException();
/*  70:    */   }
/*  71:    */   
/*  72:    */   public SortedMultiset<E> headMultiset(E upperBound, BoundType boundType)
/*  73:    */   {
/*  74: 94 */     return Multisets.unmodifiableSortedMultiset(delegate().headMultiset(upperBound, boundType));
/*  75:    */   }
/*  76:    */   
/*  77:    */   public SortedMultiset<E> subMultiset(E lowerBound, BoundType lowerBoundType, E upperBound, BoundType upperBoundType)
/*  78:    */   {
/*  79:100 */     return Multisets.unmodifiableSortedMultiset(delegate().subMultiset(lowerBound, lowerBoundType, upperBound, upperBoundType));
/*  80:    */   }
/*  81:    */   
/*  82:    */   public SortedMultiset<E> tailMultiset(E lowerBound, BoundType boundType)
/*  83:    */   {
/*  84:106 */     return Multisets.unmodifiableSortedMultiset(delegate().tailMultiset(lowerBound, boundType));
/*  85:    */   }
/*  86:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.UnmodifiableSortedMultiset
 * JD-Core Version:    0.7.0.1
 */