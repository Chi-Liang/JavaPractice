/*    1:     */ package com.google.common.collect;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Function;
/*    7:     */ import com.google.common.base.Objects;
/*    8:     */ import com.google.common.base.Optional;
/*    9:     */ import com.google.common.base.Preconditions;
/*   10:     */ import com.google.common.base.Predicate;
/*   11:     */ import com.google.common.base.Predicates;
/*   12:     */ import java.util.Arrays;
/*   13:     */ import java.util.Collection;
/*   14:     */ import java.util.Collections;
/*   15:     */ import java.util.Comparator;
/*   16:     */ import java.util.Enumeration;
/*   17:     */ import java.util.Iterator;
/*   18:     */ import java.util.List;
/*   19:     */ import java.util.ListIterator;
/*   20:     */ import java.util.NoSuchElementException;
/*   21:     */ import java.util.PriorityQueue;
/*   22:     */ import java.util.Queue;
/*   23:     */ import javax.annotation.CheckReturnValue;
/*   24:     */ import javax.annotation.Nullable;
/*   25:     */ 
/*   26:     */ @GwtCompatible(emulated=true)
/*   27:     */ public final class Iterators
/*   28:     */ {
/*   29:  73 */   static final UnmodifiableListIterator<Object> EMPTY_LIST_ITERATOR = new UnmodifiableListIterator()
/*   30:     */   {
/*   31:     */     public boolean hasNext()
/*   32:     */     {
/*   33:  77 */       return false;
/*   34:     */     }
/*   35:     */     
/*   36:     */     public Object next()
/*   37:     */     {
/*   38:  82 */       throw new NoSuchElementException();
/*   39:     */     }
/*   40:     */     
/*   41:     */     public boolean hasPrevious()
/*   42:     */     {
/*   43:  87 */       return false;
/*   44:     */     }
/*   45:     */     
/*   46:     */     public Object previous()
/*   47:     */     {
/*   48:  92 */       throw new NoSuchElementException();
/*   49:     */     }
/*   50:     */     
/*   51:     */     public int nextIndex()
/*   52:     */     {
/*   53:  97 */       return 0;
/*   54:     */     }
/*   55:     */     
/*   56:     */     public int previousIndex()
/*   57:     */     {
/*   58: 102 */       return -1;
/*   59:     */     }
/*   60:     */   };
/*   61:     */   
/*   62:     */   @Deprecated
/*   63:     */   public static <T> UnmodifiableIterator<T> emptyIterator()
/*   64:     */   {
/*   65: 118 */     return emptyListIterator();
/*   66:     */   }
/*   67:     */   
/*   68:     */   static <T> UnmodifiableListIterator<T> emptyListIterator()
/*   69:     */   {
/*   70: 130 */     return EMPTY_LIST_ITERATOR;
/*   71:     */   }
/*   72:     */   
/*   73: 133 */   private static final Iterator<Object> EMPTY_MODIFIABLE_ITERATOR = new Iterator()
/*   74:     */   {
/*   75:     */     public boolean hasNext()
/*   76:     */     {
/*   77: 137 */       return false;
/*   78:     */     }
/*   79:     */     
/*   80:     */     public Object next()
/*   81:     */     {
/*   82: 142 */       throw new NoSuchElementException();
/*   83:     */     }
/*   84:     */     
/*   85:     */     public void remove()
/*   86:     */     {
/*   87: 147 */       CollectPreconditions.checkRemove(false);
/*   88:     */     }
/*   89:     */   };
/*   90:     */   
/*   91:     */   static <T> Iterator<T> emptyModifiableIterator()
/*   92:     */   {
/*   93: 160 */     return EMPTY_MODIFIABLE_ITERATOR;
/*   94:     */   }
/*   95:     */   
/*   96:     */   public static <T> UnmodifiableIterator<T> unmodifiableIterator(Iterator<T> iterator)
/*   97:     */   {
/*   98: 165 */     Preconditions.checkNotNull(iterator);
/*   99: 166 */     if ((iterator instanceof UnmodifiableIterator)) {
/*  100: 167 */       return (UnmodifiableIterator)iterator;
/*  101:     */     }
/*  102: 169 */     new UnmodifiableIterator()
/*  103:     */     {
/*  104:     */       public boolean hasNext()
/*  105:     */       {
/*  106: 172 */         return this.val$iterator.hasNext();
/*  107:     */       }
/*  108:     */       
/*  109:     */       public T next()
/*  110:     */       {
/*  111: 177 */         return this.val$iterator.next();
/*  112:     */       }
/*  113:     */     };
/*  114:     */   }
/*  115:     */   
/*  116:     */   @Deprecated
/*  117:     */   public static <T> UnmodifiableIterator<T> unmodifiableIterator(UnmodifiableIterator<T> iterator)
/*  118:     */   {
/*  119: 190 */     return (UnmodifiableIterator)Preconditions.checkNotNull(iterator);
/*  120:     */   }
/*  121:     */   
/*  122:     */   public static int size(Iterator<?> iterator)
/*  123:     */   {
/*  124: 199 */     int count = 0;
/*  125: 200 */     while (iterator.hasNext())
/*  126:     */     {
/*  127: 201 */       iterator.next();
/*  128: 202 */       count++;
/*  129:     */     }
/*  130: 204 */     return count;
/*  131:     */   }
/*  132:     */   
/*  133:     */   public static boolean contains(Iterator<?> iterator, @Nullable Object element)
/*  134:     */   {
/*  135: 211 */     return any(iterator, Predicates.equalTo(element));
/*  136:     */   }
/*  137:     */   
/*  138:     */   public static boolean removeAll(Iterator<?> removeFrom, Collection<?> elementsToRemove)
/*  139:     */   {
/*  140: 224 */     return removeIf(removeFrom, Predicates.in(elementsToRemove));
/*  141:     */   }
/*  142:     */   
/*  143:     */   public static <T> boolean removeIf(Iterator<T> removeFrom, Predicate<? super T> predicate)
/*  144:     */   {
/*  145: 239 */     Preconditions.checkNotNull(predicate);
/*  146: 240 */     boolean modified = false;
/*  147: 241 */     while (removeFrom.hasNext()) {
/*  148: 242 */       if (predicate.apply(removeFrom.next()))
/*  149:     */       {
/*  150: 243 */         removeFrom.remove();
/*  151: 244 */         modified = true;
/*  152:     */       }
/*  153:     */     }
/*  154: 247 */     return modified;
/*  155:     */   }
/*  156:     */   
/*  157:     */   public static boolean retainAll(Iterator<?> removeFrom, Collection<?> elementsToRetain)
/*  158:     */   {
/*  159: 260 */     return removeIf(removeFrom, Predicates.not(Predicates.in(elementsToRetain)));
/*  160:     */   }
/*  161:     */   
/*  162:     */   public static boolean elementsEqual(Iterator<?> iterator1, Iterator<?> iterator2)
/*  163:     */   {
/*  164: 274 */     while (iterator1.hasNext())
/*  165:     */     {
/*  166: 275 */       if (!iterator2.hasNext()) {
/*  167: 276 */         return false;
/*  168:     */       }
/*  169: 278 */       Object o1 = iterator1.next();
/*  170: 279 */       Object o2 = iterator2.next();
/*  171: 280 */       if (!Objects.equal(o1, o2)) {
/*  172: 281 */         return false;
/*  173:     */       }
/*  174:     */     }
/*  175: 284 */     return !iterator2.hasNext();
/*  176:     */   }
/*  177:     */   
/*  178:     */   public static String toString(Iterator<?> iterator)
/*  179:     */   {
/*  180: 293 */     return ']';
/*  181:     */   }
/*  182:     */   
/*  183:     */   public static <T> T getOnlyElement(Iterator<T> iterator)
/*  184:     */   {
/*  185: 307 */     T first = iterator.next();
/*  186: 308 */     if (!iterator.hasNext()) {
/*  187: 309 */       return first;
/*  188:     */     }
/*  189: 312 */     StringBuilder sb = new StringBuilder();
/*  190: 313 */     sb.append("expected one element but was: <" + first);
/*  191: 314 */     for (int i = 0; (i < 4) && (iterator.hasNext()); i++) {
/*  192: 315 */       sb.append(", " + iterator.next());
/*  193:     */     }
/*  194: 317 */     if (iterator.hasNext()) {
/*  195: 318 */       sb.append(", ...");
/*  196:     */     }
/*  197: 320 */     sb.append('>');
/*  198:     */     
/*  199: 322 */     throw new IllegalArgumentException(sb.toString());
/*  200:     */   }
/*  201:     */   
/*  202:     */   @Nullable
/*  203:     */   public static <T> T getOnlyElement(Iterator<? extends T> iterator, @Nullable T defaultValue)
/*  204:     */   {
/*  205: 334 */     return iterator.hasNext() ? getOnlyElement(iterator) : defaultValue;
/*  206:     */   }
/*  207:     */   
/*  208:     */   @GwtIncompatible("Array.newInstance(Class, int)")
/*  209:     */   public static <T> T[] toArray(Iterator<? extends T> iterator, Class<T> type)
/*  210:     */   {
/*  211: 348 */     List<T> list = Lists.newArrayList(iterator);
/*  212: 349 */     return Iterables.toArray(list, type);
/*  213:     */   }
/*  214:     */   
/*  215:     */   public static <T> boolean addAll(Collection<T> addTo, Iterator<? extends T> iterator)
/*  216:     */   {
/*  217: 361 */     Preconditions.checkNotNull(addTo);
/*  218: 362 */     Preconditions.checkNotNull(iterator);
/*  219: 363 */     boolean wasModified = false;
/*  220: 364 */     while (iterator.hasNext()) {
/*  221: 365 */       wasModified |= addTo.add(iterator.next());
/*  222:     */     }
/*  223: 367 */     return wasModified;
/*  224:     */   }
/*  225:     */   
/*  226:     */   public static int frequency(Iterator<?> iterator, @Nullable Object element)
/*  227:     */   {
/*  228: 378 */     return size(filter(iterator, Predicates.equalTo(element)));
/*  229:     */   }
/*  230:     */   
/*  231:     */   public static <T> Iterator<T> cycle(Iterable<T> iterable)
/*  232:     */   {
/*  233: 396 */     Preconditions.checkNotNull(iterable);
/*  234: 397 */     new Iterator()
/*  235:     */     {
/*  236: 398 */       Iterator<T> iterator = Iterators.emptyModifiableIterator();
/*  237:     */       
/*  238:     */       public boolean hasNext()
/*  239:     */       {
/*  240: 411 */         return (this.iterator.hasNext()) || (this.val$iterable.iterator().hasNext());
/*  241:     */       }
/*  242:     */       
/*  243:     */       public T next()
/*  244:     */       {
/*  245: 416 */         if (!this.iterator.hasNext())
/*  246:     */         {
/*  247: 417 */           this.iterator = this.val$iterable.iterator();
/*  248: 418 */           if (!this.iterator.hasNext()) {
/*  249: 419 */             throw new NoSuchElementException();
/*  250:     */           }
/*  251:     */         }
/*  252: 422 */         return this.iterator.next();
/*  253:     */       }
/*  254:     */       
/*  255:     */       public void remove()
/*  256:     */       {
/*  257: 427 */         this.iterator.remove();
/*  258:     */       }
/*  259:     */     };
/*  260:     */   }
/*  261:     */   
/*  262:     */   public static <T> Iterator<T> cycle(T... elements)
/*  263:     */   {
/*  264: 446 */     return cycle(Lists.newArrayList(elements));
/*  265:     */   }
/*  266:     */   
/*  267:     */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b)
/*  268:     */   {
/*  269: 463 */     Preconditions.checkNotNull(a);
/*  270: 464 */     Preconditions.checkNotNull(b);
/*  271: 465 */     return concat(new ConsumingQueueIterator(new Iterator[] { a, b }));
/*  272:     */   }
/*  273:     */   
/*  274:     */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b, Iterator<? extends T> c)
/*  275:     */   {
/*  276: 484 */     Preconditions.checkNotNull(a);
/*  277: 485 */     Preconditions.checkNotNull(b);
/*  278: 486 */     Preconditions.checkNotNull(c);
/*  279: 487 */     return concat(new ConsumingQueueIterator(new Iterator[] { a, b, c }));
/*  280:     */   }
/*  281:     */   
/*  282:     */   public static <T> Iterator<T> concat(Iterator<? extends T> a, Iterator<? extends T> b, Iterator<? extends T> c, Iterator<? extends T> d)
/*  283:     */   {
/*  284: 509 */     Preconditions.checkNotNull(a);
/*  285: 510 */     Preconditions.checkNotNull(b);
/*  286: 511 */     Preconditions.checkNotNull(c);
/*  287: 512 */     Preconditions.checkNotNull(d);
/*  288: 513 */     return concat(new ConsumingQueueIterator(new Iterator[] { a, b, c, d }));
/*  289:     */   }
/*  290:     */   
/*  291:     */   public static <T> Iterator<T> concat(Iterator<? extends T>... inputs)
/*  292:     */   {
/*  293: 532 */     for (Iterator<? extends T> input : (Iterator[])Preconditions.checkNotNull(inputs)) {
/*  294: 533 */       Preconditions.checkNotNull(input);
/*  295:     */     }
/*  296: 535 */     return concat(new ConsumingQueueIterator(inputs));
/*  297:     */   }
/*  298:     */   
/*  299:     */   public static <T> Iterator<T> concat(Iterator<? extends Iterator<? extends T>> inputs)
/*  300:     */   {
/*  301: 553 */     Preconditions.checkNotNull(inputs);
/*  302: 554 */     new Iterator()
/*  303:     */     {
/*  304: 555 */       Iterator<? extends T> current = Iterators.emptyIterator();
/*  305:     */       Iterator<? extends T> removeFrom;
/*  306:     */       
/*  307:     */       public boolean hasNext()
/*  308:     */       {
/*  309:     */         boolean currentHasNext;
/*  310: 568 */         while ((!(currentHasNext = ((Iterator)Preconditions.checkNotNull(this.current)).hasNext())) && (this.val$inputs.hasNext())) {
/*  311: 569 */           this.current = ((Iterator)this.val$inputs.next());
/*  312:     */         }
/*  313: 571 */         return currentHasNext;
/*  314:     */       }
/*  315:     */       
/*  316:     */       public T next()
/*  317:     */       {
/*  318: 576 */         if (!hasNext()) {
/*  319: 577 */           throw new NoSuchElementException();
/*  320:     */         }
/*  321: 579 */         this.removeFrom = this.current;
/*  322: 580 */         return this.current.next();
/*  323:     */       }
/*  324:     */       
/*  325:     */       public void remove()
/*  326:     */       {
/*  327: 585 */         CollectPreconditions.checkRemove(this.removeFrom != null);
/*  328: 586 */         this.removeFrom.remove();
/*  329: 587 */         this.removeFrom = null;
/*  330:     */       }
/*  331:     */     };
/*  332:     */   }
/*  333:     */   
/*  334:     */   public static <T> UnmodifiableIterator<List<T>> partition(Iterator<T> iterator, int size)
/*  335:     */   {
/*  336: 608 */     return partitionImpl(iterator, size, false);
/*  337:     */   }
/*  338:     */   
/*  339:     */   public static <T> UnmodifiableIterator<List<T>> paddedPartition(Iterator<T> iterator, int size)
/*  340:     */   {
/*  341: 628 */     return partitionImpl(iterator, size, true);
/*  342:     */   }
/*  343:     */   
/*  344:     */   private static <T> UnmodifiableIterator<List<T>> partitionImpl(Iterator<T> iterator, final int size, final boolean pad)
/*  345:     */   {
/*  346: 633 */     Preconditions.checkNotNull(iterator);
/*  347: 634 */     Preconditions.checkArgument(size > 0);
/*  348: 635 */     new UnmodifiableIterator()
/*  349:     */     {
/*  350:     */       public boolean hasNext()
/*  351:     */       {
/*  352: 638 */         return this.val$iterator.hasNext();
/*  353:     */       }
/*  354:     */       
/*  355:     */       public List<T> next()
/*  356:     */       {
/*  357: 643 */         if (!hasNext()) {
/*  358: 644 */           throw new NoSuchElementException();
/*  359:     */         }
/*  360: 646 */         Object[] array = new Object[size];
/*  361: 647 */         for (int count = 0; (count < size) && (this.val$iterator.hasNext()); count++) {
/*  362: 649 */           array[count] = this.val$iterator.next();
/*  363:     */         }
/*  364: 651 */         for (int i = count; i < size; i++) {
/*  365: 652 */           array[i] = null;
/*  366:     */         }
/*  367: 656 */         List<T> list = Collections.unmodifiableList(Arrays.asList(array));
/*  368: 657 */         return (pad) || (count == size) ? list : list.subList(0, count);
/*  369:     */       }
/*  370:     */     };
/*  371:     */   }
/*  372:     */   
/*  373:     */   @CheckReturnValue
/*  374:     */   public static <T> UnmodifiableIterator<T> filter(Iterator<T> unfiltered, final Predicate<? super T> predicate)
/*  375:     */   {
/*  376: 668 */     Preconditions.checkNotNull(unfiltered);
/*  377: 669 */     Preconditions.checkNotNull(predicate);
/*  378: 670 */     new AbstractIterator()
/*  379:     */     {
/*  380:     */       protected T computeNext()
/*  381:     */       {
/*  382: 673 */         while (this.val$unfiltered.hasNext())
/*  383:     */         {
/*  384: 674 */           T element = this.val$unfiltered.next();
/*  385: 675 */           if (predicate.apply(element)) {
/*  386: 676 */             return element;
/*  387:     */           }
/*  388:     */         }
/*  389: 679 */         return endOfData();
/*  390:     */       }
/*  391:     */     };
/*  392:     */   }
/*  393:     */   
/*  394:     */   @CheckReturnValue
/*  395:     */   @GwtIncompatible("Class.isInstance")
/*  396:     */   public static <T> UnmodifiableIterator<T> filter(Iterator<?> unfiltered, Class<T> type)
/*  397:     */   {
/*  398: 698 */     return filter(unfiltered, Predicates.instanceOf(type));
/*  399:     */   }
/*  400:     */   
/*  401:     */   public static <T> boolean any(Iterator<T> iterator, Predicate<? super T> predicate)
/*  402:     */   {
/*  403: 706 */     return indexOf(iterator, predicate) != -1;
/*  404:     */   }
/*  405:     */   
/*  406:     */   public static <T> boolean all(Iterator<T> iterator, Predicate<? super T> predicate)
/*  407:     */   {
/*  408: 715 */     Preconditions.checkNotNull(predicate);
/*  409: 716 */     while (iterator.hasNext())
/*  410:     */     {
/*  411: 717 */       T element = iterator.next();
/*  412: 718 */       if (!predicate.apply(element)) {
/*  413: 719 */         return false;
/*  414:     */       }
/*  415:     */     }
/*  416: 722 */     return true;
/*  417:     */   }
/*  418:     */   
/*  419:     */   public static <T> T find(Iterator<T> iterator, Predicate<? super T> predicate)
/*  420:     */   {
/*  421: 737 */     return filter(iterator, predicate).next();
/*  422:     */   }
/*  423:     */   
/*  424:     */   @Nullable
/*  425:     */   public static <T> T find(Iterator<? extends T> iterator, Predicate<? super T> predicate, @Nullable T defaultValue)
/*  426:     */   {
/*  427: 753 */     return getNext(filter(iterator, predicate), defaultValue);
/*  428:     */   }
/*  429:     */   
/*  430:     */   public static <T> Optional<T> tryFind(Iterator<T> iterator, Predicate<? super T> predicate)
/*  431:     */   {
/*  432: 770 */     UnmodifiableIterator<T> filteredIterator = filter(iterator, predicate);
/*  433: 771 */     return filteredIterator.hasNext() ? Optional.of(filteredIterator.next()) : Optional.absent();
/*  434:     */   }
/*  435:     */   
/*  436:     */   public static <T> int indexOf(Iterator<T> iterator, Predicate<? super T> predicate)
/*  437:     */   {
/*  438: 793 */     Preconditions.checkNotNull(predicate, "predicate");
/*  439: 794 */     for (int i = 0; iterator.hasNext(); i++)
/*  440:     */     {
/*  441: 795 */       T current = iterator.next();
/*  442: 796 */       if (predicate.apply(current)) {
/*  443: 797 */         return i;
/*  444:     */       }
/*  445:     */     }
/*  446: 800 */     return -1;
/*  447:     */   }
/*  448:     */   
/*  449:     */   public static <F, T> Iterator<T> transform(Iterator<F> fromIterator, final Function<? super F, ? extends T> function)
/*  450:     */   {
/*  451: 813 */     Preconditions.checkNotNull(function);
/*  452: 814 */     new TransformedIterator(fromIterator)
/*  453:     */     {
/*  454:     */       T transform(F from)
/*  455:     */       {
/*  456: 817 */         return function.apply(from);
/*  457:     */       }
/*  458:     */     };
/*  459:     */   }
/*  460:     */   
/*  461:     */   public static <T> T get(Iterator<T> iterator, int position)
/*  462:     */   {
/*  463: 833 */     checkNonnegative(position);
/*  464: 834 */     int skipped = advance(iterator, position);
/*  465: 835 */     if (!iterator.hasNext()) {
/*  466: 836 */       throw new IndexOutOfBoundsException("position (" + position + ") must be less than the number of elements that remained (" + skipped + ")");
/*  467:     */     }
/*  468: 843 */     return iterator.next();
/*  469:     */   }
/*  470:     */   
/*  471:     */   static void checkNonnegative(int position)
/*  472:     */   {
/*  473: 847 */     if (position < 0) {
/*  474: 848 */       throw new IndexOutOfBoundsException("position (" + position + ") must not be negative");
/*  475:     */     }
/*  476:     */   }
/*  477:     */   
/*  478:     */   @Nullable
/*  479:     */   public static <T> T get(Iterator<? extends T> iterator, int position, @Nullable T defaultValue)
/*  480:     */   {
/*  481: 869 */     checkNonnegative(position);
/*  482: 870 */     advance(iterator, position);
/*  483: 871 */     return getNext(iterator, defaultValue);
/*  484:     */   }
/*  485:     */   
/*  486:     */   @Nullable
/*  487:     */   public static <T> T getNext(Iterator<? extends T> iterator, @Nullable T defaultValue)
/*  488:     */   {
/*  489: 885 */     return iterator.hasNext() ? iterator.next() : defaultValue;
/*  490:     */   }
/*  491:     */   
/*  492:     */   public static <T> T getLast(Iterator<T> iterator)
/*  493:     */   {
/*  494:     */     for (;;)
/*  495:     */     {
/*  496: 896 */       T current = iterator.next();
/*  497: 897 */       if (!iterator.hasNext()) {
/*  498: 898 */         return current;
/*  499:     */       }
/*  500:     */     }
/*  501:     */   }
/*  502:     */   
/*  503:     */   @Nullable
/*  504:     */   public static <T> T getLast(Iterator<? extends T> iterator, @Nullable T defaultValue)
/*  505:     */   {
/*  506: 913 */     return iterator.hasNext() ? getLast(iterator) : defaultValue;
/*  507:     */   }
/*  508:     */   
/*  509:     */   public static int advance(Iterator<?> iterator, int numberToAdvance)
/*  510:     */   {
/*  511: 924 */     Preconditions.checkNotNull(iterator);
/*  512: 925 */     Preconditions.checkArgument(numberToAdvance >= 0, "numberToAdvance must be nonnegative");
/*  513: 928 */     for (int i = 0; (i < numberToAdvance) && (iterator.hasNext()); i++) {
/*  514: 929 */       iterator.next();
/*  515:     */     }
/*  516: 931 */     return i;
/*  517:     */   }
/*  518:     */   
/*  519:     */   public static <T> Iterator<T> limit(final Iterator<T> iterator, int limitSize)
/*  520:     */   {
/*  521: 947 */     Preconditions.checkNotNull(iterator);
/*  522: 948 */     Preconditions.checkArgument(limitSize >= 0, "limit is negative");
/*  523: 949 */     new Iterator()
/*  524:     */     {
/*  525:     */       private int count;
/*  526:     */       
/*  527:     */       public boolean hasNext()
/*  528:     */       {
/*  529: 954 */         return (this.count < this.val$limitSize) && (iterator.hasNext());
/*  530:     */       }
/*  531:     */       
/*  532:     */       public T next()
/*  533:     */       {
/*  534: 959 */         if (!hasNext()) {
/*  535: 960 */           throw new NoSuchElementException();
/*  536:     */         }
/*  537: 962 */         this.count += 1;
/*  538: 963 */         return iterator.next();
/*  539:     */       }
/*  540:     */       
/*  541:     */       public void remove()
/*  542:     */       {
/*  543: 968 */         iterator.remove();
/*  544:     */       }
/*  545:     */     };
/*  546:     */   }
/*  547:     */   
/*  548:     */   public static <T> Iterator<T> consumingIterator(Iterator<T> iterator)
/*  549:     */   {
/*  550: 987 */     Preconditions.checkNotNull(iterator);
/*  551: 988 */     new UnmodifiableIterator()
/*  552:     */     {
/*  553:     */       public boolean hasNext()
/*  554:     */       {
/*  555: 991 */         return this.val$iterator.hasNext();
/*  556:     */       }
/*  557:     */       
/*  558:     */       public T next()
/*  559:     */       {
/*  560: 996 */         T next = this.val$iterator.next();
/*  561: 997 */         this.val$iterator.remove();
/*  562: 998 */         return next;
/*  563:     */       }
/*  564:     */       
/*  565:     */       public String toString()
/*  566:     */       {
/*  567:1003 */         return "Iterators.consumingIterator(...)";
/*  568:     */       }
/*  569:     */     };
/*  570:     */   }
/*  571:     */   
/*  572:     */   @Nullable
/*  573:     */   static <T> T pollNext(Iterator<T> iterator)
/*  574:     */   {
/*  575:1014 */     if (iterator.hasNext())
/*  576:     */     {
/*  577:1015 */       T result = iterator.next();
/*  578:1016 */       iterator.remove();
/*  579:1017 */       return result;
/*  580:     */     }
/*  581:1019 */     return null;
/*  582:     */   }
/*  583:     */   
/*  584:     */   static void clear(Iterator<?> iterator)
/*  585:     */   {
/*  586:1029 */     Preconditions.checkNotNull(iterator);
/*  587:1030 */     while (iterator.hasNext())
/*  588:     */     {
/*  589:1031 */       iterator.next();
/*  590:1032 */       iterator.remove();
/*  591:     */     }
/*  592:     */   }
/*  593:     */   
/*  594:     */   public static <T> UnmodifiableIterator<T> forArray(T... array)
/*  595:     */   {
/*  596:1050 */     return forArray(array, 0, array.length, 0);
/*  597:     */   }
/*  598:     */   
/*  599:     */   static <T> UnmodifiableListIterator<T> forArray(final T[] array, final int offset, int length, int index)
/*  600:     */   {
/*  601:1062 */     Preconditions.checkArgument(length >= 0);
/*  602:1063 */     int end = offset + length;
/*  603:     */     
/*  604:     */ 
/*  605:1066 */     Preconditions.checkPositionIndexes(offset, end, array.length);
/*  606:1067 */     Preconditions.checkPositionIndex(index, length);
/*  607:1068 */     if (length == 0) {
/*  608:1069 */       return emptyListIterator();
/*  609:     */     }
/*  610:1077 */     new AbstractIndexedListIterator(length, index)
/*  611:     */     {
/*  612:     */       protected T get(int index)
/*  613:     */       {
/*  614:1080 */         return array[(offset + index)];
/*  615:     */       }
/*  616:     */     };
/*  617:     */   }
/*  618:     */   
/*  619:     */   public static <T> UnmodifiableIterator<T> singletonIterator(@Nullable T value)
/*  620:     */   {
/*  621:1092 */     new UnmodifiableIterator()
/*  622:     */     {
/*  623:     */       boolean done;
/*  624:     */       
/*  625:     */       public boolean hasNext()
/*  626:     */       {
/*  627:1097 */         return !this.done;
/*  628:     */       }
/*  629:     */       
/*  630:     */       public T next()
/*  631:     */       {
/*  632:1102 */         if (this.done) {
/*  633:1103 */           throw new NoSuchElementException();
/*  634:     */         }
/*  635:1105 */         this.done = true;
/*  636:1106 */         return this.val$value;
/*  637:     */       }
/*  638:     */     };
/*  639:     */   }
/*  640:     */   
/*  641:     */   public static <T> UnmodifiableIterator<T> forEnumeration(Enumeration<T> enumeration)
/*  642:     */   {
/*  643:1120 */     Preconditions.checkNotNull(enumeration);
/*  644:1121 */     new UnmodifiableIterator()
/*  645:     */     {
/*  646:     */       public boolean hasNext()
/*  647:     */       {
/*  648:1124 */         return this.val$enumeration.hasMoreElements();
/*  649:     */       }
/*  650:     */       
/*  651:     */       public T next()
/*  652:     */       {
/*  653:1129 */         return this.val$enumeration.nextElement();
/*  654:     */       }
/*  655:     */     };
/*  656:     */   }
/*  657:     */   
/*  658:     */   public static <T> Enumeration<T> asEnumeration(Iterator<T> iterator)
/*  659:     */   {
/*  660:1142 */     Preconditions.checkNotNull(iterator);
/*  661:1143 */     new Enumeration()
/*  662:     */     {
/*  663:     */       public boolean hasMoreElements()
/*  664:     */       {
/*  665:1146 */         return this.val$iterator.hasNext();
/*  666:     */       }
/*  667:     */       
/*  668:     */       public T nextElement()
/*  669:     */       {
/*  670:1151 */         return this.val$iterator.next();
/*  671:     */       }
/*  672:     */     };
/*  673:     */   }
/*  674:     */   
/*  675:     */   private static class PeekingImpl<E>
/*  676:     */     implements PeekingIterator<E>
/*  677:     */   {
/*  678:     */     private final Iterator<? extends E> iterator;
/*  679:     */     private boolean hasPeeked;
/*  680:     */     private E peekedElement;
/*  681:     */     
/*  682:     */     public PeekingImpl(Iterator<? extends E> iterator)
/*  683:     */     {
/*  684:1166 */       this.iterator = ((Iterator)Preconditions.checkNotNull(iterator));
/*  685:     */     }
/*  686:     */     
/*  687:     */     public boolean hasNext()
/*  688:     */     {
/*  689:1171 */       return (this.hasPeeked) || (this.iterator.hasNext());
/*  690:     */     }
/*  691:     */     
/*  692:     */     public E next()
/*  693:     */     {
/*  694:1176 */       if (!this.hasPeeked) {
/*  695:1177 */         return this.iterator.next();
/*  696:     */       }
/*  697:1179 */       E result = this.peekedElement;
/*  698:1180 */       this.hasPeeked = false;
/*  699:1181 */       this.peekedElement = null;
/*  700:1182 */       return result;
/*  701:     */     }
/*  702:     */     
/*  703:     */     public void remove()
/*  704:     */     {
/*  705:1187 */       Preconditions.checkState(!this.hasPeeked, "Can't remove after you've peeked at next");
/*  706:1188 */       this.iterator.remove();
/*  707:     */     }
/*  708:     */     
/*  709:     */     public E peek()
/*  710:     */     {
/*  711:1193 */       if (!this.hasPeeked)
/*  712:     */       {
/*  713:1194 */         this.peekedElement = this.iterator.next();
/*  714:1195 */         this.hasPeeked = true;
/*  715:     */       }
/*  716:1197 */       return this.peekedElement;
/*  717:     */     }
/*  718:     */   }
/*  719:     */   
/*  720:     */   public static <T> PeekingIterator<T> peekingIterator(Iterator<? extends T> iterator)
/*  721:     */   {
/*  722:1240 */     if ((iterator instanceof PeekingImpl))
/*  723:     */     {
/*  724:1244 */       PeekingImpl<T> peeking = (PeekingImpl)iterator;
/*  725:1245 */       return peeking;
/*  726:     */     }
/*  727:1247 */     return new PeekingImpl(iterator);
/*  728:     */   }
/*  729:     */   
/*  730:     */   @Deprecated
/*  731:     */   public static <T> PeekingIterator<T> peekingIterator(PeekingIterator<T> iterator)
/*  732:     */   {
/*  733:1258 */     return (PeekingIterator)Preconditions.checkNotNull(iterator);
/*  734:     */   }
/*  735:     */   
/*  736:     */   @Beta
/*  737:     */   public static <T> UnmodifiableIterator<T> mergeSorted(Iterable<? extends Iterator<? extends T>> iterators, Comparator<? super T> comparator)
/*  738:     */   {
/*  739:1277 */     Preconditions.checkNotNull(iterators, "iterators");
/*  740:1278 */     Preconditions.checkNotNull(comparator, "comparator");
/*  741:     */     
/*  742:1280 */     return new MergingIterator(iterators, comparator);
/*  743:     */   }
/*  744:     */   
/*  745:     */   private static class MergingIterator<T>
/*  746:     */     extends UnmodifiableIterator<T>
/*  747:     */   {
/*  748:     */     final Queue<PeekingIterator<T>> queue;
/*  749:     */     
/*  750:     */     public MergingIterator(Iterable<? extends Iterator<? extends T>> iterators, final Comparator<? super T> itemComparator)
/*  751:     */     {
/*  752:1300 */       Comparator<PeekingIterator<T>> heapComparator = new Comparator()
/*  753:     */       {
/*  754:     */         public int compare(PeekingIterator<T> o1, PeekingIterator<T> o2)
/*  755:     */         {
/*  756:1304 */           return itemComparator.compare(o1.peek(), o2.peek());
/*  757:     */         }
/*  758:1307 */       };
/*  759:1308 */       this.queue = new PriorityQueue(2, heapComparator);
/*  760:1310 */       for (Iterator<? extends T> iterator : iterators) {
/*  761:1311 */         if (iterator.hasNext()) {
/*  762:1312 */           this.queue.add(Iterators.peekingIterator(iterator));
/*  763:     */         }
/*  764:     */       }
/*  765:     */     }
/*  766:     */     
/*  767:     */     public boolean hasNext()
/*  768:     */     {
/*  769:1319 */       return !this.queue.isEmpty();
/*  770:     */     }
/*  771:     */     
/*  772:     */     public T next()
/*  773:     */     {
/*  774:1324 */       PeekingIterator<T> nextIter = (PeekingIterator)this.queue.remove();
/*  775:1325 */       T next = nextIter.next();
/*  776:1326 */       if (nextIter.hasNext()) {
/*  777:1327 */         this.queue.add(nextIter);
/*  778:     */       }
/*  779:1329 */       return next;
/*  780:     */     }
/*  781:     */   }
/*  782:     */   
/*  783:     */   static <T> ListIterator<T> cast(Iterator<T> iterator)
/*  784:     */   {
/*  785:1337 */     return (ListIterator)iterator;
/*  786:     */   }
/*  787:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.collect.Iterators
 * JD-Core Version:    0.7.0.1
 */