/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Map;
/*   7:    */ import javax.annotation.CheckReturnValue;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @CheckReturnValue
/*  11:    */ @GwtCompatible
/*  12:    */ public final class Functions
/*  13:    */ {
/*  14:    */   public static Function<Object, String> toStringFunction()
/*  15:    */   {
/*  16: 58 */     return ToStringFunction.INSTANCE;
/*  17:    */   }
/*  18:    */   
/*  19:    */   private static enum ToStringFunction
/*  20:    */     implements Function<Object, String>
/*  21:    */   {
/*  22: 63 */     INSTANCE;
/*  23:    */     
/*  24:    */     private ToStringFunction() {}
/*  25:    */     
/*  26:    */     public String apply(Object o)
/*  27:    */     {
/*  28: 67 */       Preconditions.checkNotNull(o);
/*  29: 68 */       return o.toString();
/*  30:    */     }
/*  31:    */     
/*  32:    */     public String toString()
/*  33:    */     {
/*  34: 73 */       return "Functions.toStringFunction()";
/*  35:    */     }
/*  36:    */   }
/*  37:    */   
/*  38:    */   public static <E> Function<E, E> identity()
/*  39:    */   {
/*  40: 83 */     return IdentityFunction.INSTANCE;
/*  41:    */   }
/*  42:    */   
/*  43:    */   private static enum IdentityFunction
/*  44:    */     implements Function<Object, Object>
/*  45:    */   {
/*  46: 88 */     INSTANCE;
/*  47:    */     
/*  48:    */     private IdentityFunction() {}
/*  49:    */     
/*  50:    */     @Nullable
/*  51:    */     public Object apply(@Nullable Object o)
/*  52:    */     {
/*  53: 93 */       return o;
/*  54:    */     }
/*  55:    */     
/*  56:    */     public String toString()
/*  57:    */     {
/*  58: 98 */       return "Functions.identity()";
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   public static <K, V> Function<K, V> forMap(Map<K, V> map)
/*  63:    */   {
/*  64:112 */     return new FunctionForMapNoDefault(map);
/*  65:    */   }
/*  66:    */   
/*  67:    */   private static class FunctionForMapNoDefault<K, V>
/*  68:    */     implements Function<K, V>, Serializable
/*  69:    */   {
/*  70:    */     final Map<K, V> map;
/*  71:    */     private static final long serialVersionUID = 0L;
/*  72:    */     
/*  73:    */     FunctionForMapNoDefault(Map<K, V> map)
/*  74:    */     {
/*  75:119 */       this.map = ((Map)Preconditions.checkNotNull(map));
/*  76:    */     }
/*  77:    */     
/*  78:    */     public V apply(@Nullable K key)
/*  79:    */     {
/*  80:124 */       V result = this.map.get(key);
/*  81:125 */       Preconditions.checkArgument((result != null) || (this.map.containsKey(key)), "Key '%s' not present in map", new Object[] { key });
/*  82:126 */       return result;
/*  83:    */     }
/*  84:    */     
/*  85:    */     public boolean equals(@Nullable Object o)
/*  86:    */     {
/*  87:131 */       if ((o instanceof FunctionForMapNoDefault))
/*  88:    */       {
/*  89:132 */         FunctionForMapNoDefault<?, ?> that = (FunctionForMapNoDefault)o;
/*  90:133 */         return this.map.equals(that.map);
/*  91:    */       }
/*  92:135 */       return false;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public int hashCode()
/*  96:    */     {
/*  97:140 */       return this.map.hashCode();
/*  98:    */     }
/*  99:    */     
/* 100:    */     public String toString()
/* 101:    */     {
/* 102:145 */       return "Functions.forMap(" + this.map + ")";
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   public static <K, V> Function<K, V> forMap(Map<K, ? extends V> map, @Nullable V defaultValue)
/* 107:    */   {
/* 108:162 */     return new ForMapWithDefault(map, defaultValue);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static class ForMapWithDefault<K, V>
/* 112:    */     implements Function<K, V>, Serializable
/* 113:    */   {
/* 114:    */     final Map<K, ? extends V> map;
/* 115:    */     final V defaultValue;
/* 116:    */     private static final long serialVersionUID = 0L;
/* 117:    */     
/* 118:    */     ForMapWithDefault(Map<K, ? extends V> map, @Nullable V defaultValue)
/* 119:    */     {
/* 120:170 */       this.map = ((Map)Preconditions.checkNotNull(map));
/* 121:171 */       this.defaultValue = defaultValue;
/* 122:    */     }
/* 123:    */     
/* 124:    */     public V apply(@Nullable K key)
/* 125:    */     {
/* 126:176 */       V result = this.map.get(key);
/* 127:177 */       return (result != null) || (this.map.containsKey(key)) ? result : this.defaultValue;
/* 128:    */     }
/* 129:    */     
/* 130:    */     public boolean equals(@Nullable Object o)
/* 131:    */     {
/* 132:182 */       if ((o instanceof ForMapWithDefault))
/* 133:    */       {
/* 134:183 */         ForMapWithDefault<?, ?> that = (ForMapWithDefault)o;
/* 135:184 */         return (this.map.equals(that.map)) && (Objects.equal(this.defaultValue, that.defaultValue));
/* 136:    */       }
/* 137:186 */       return false;
/* 138:    */     }
/* 139:    */     
/* 140:    */     public int hashCode()
/* 141:    */     {
/* 142:191 */       return Objects.hashCode(new Object[] { this.map, this.defaultValue });
/* 143:    */     }
/* 144:    */     
/* 145:    */     public String toString()
/* 146:    */     {
/* 147:197 */       return "Functions.forMap(" + this.map + ", defaultValue=" + this.defaultValue + ")";
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public static <A, B, C> Function<A, C> compose(Function<B, C> g, Function<A, ? extends B> f)
/* 152:    */   {
/* 153:213 */     return new FunctionComposition(g, f);
/* 154:    */   }
/* 155:    */   
/* 156:    */   private static class FunctionComposition<A, B, C>
/* 157:    */     implements Function<A, C>, Serializable
/* 158:    */   {
/* 159:    */     private final Function<B, C> g;
/* 160:    */     private final Function<A, ? extends B> f;
/* 161:    */     private static final long serialVersionUID = 0L;
/* 162:    */     
/* 163:    */     public FunctionComposition(Function<B, C> g, Function<A, ? extends B> f)
/* 164:    */     {
/* 165:221 */       this.g = ((Function)Preconditions.checkNotNull(g));
/* 166:222 */       this.f = ((Function)Preconditions.checkNotNull(f));
/* 167:    */     }
/* 168:    */     
/* 169:    */     public C apply(@Nullable A a)
/* 170:    */     {
/* 171:227 */       return this.g.apply(this.f.apply(a));
/* 172:    */     }
/* 173:    */     
/* 174:    */     public boolean equals(@Nullable Object obj)
/* 175:    */     {
/* 176:232 */       if ((obj instanceof FunctionComposition))
/* 177:    */       {
/* 178:233 */         FunctionComposition<?, ?, ?> that = (FunctionComposition)obj;
/* 179:234 */         return (this.f.equals(that.f)) && (this.g.equals(that.g));
/* 180:    */       }
/* 181:236 */       return false;
/* 182:    */     }
/* 183:    */     
/* 184:    */     public int hashCode()
/* 185:    */     {
/* 186:241 */       return this.f.hashCode() ^ this.g.hashCode();
/* 187:    */     }
/* 188:    */     
/* 189:    */     public String toString()
/* 190:    */     {
/* 191:247 */       return this.g + "(" + this.f + ")";
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static <T> Function<T, Boolean> forPredicate(Predicate<T> predicate)
/* 196:    */   {
/* 197:260 */     return new PredicateFunction(predicate, null);
/* 198:    */   }
/* 199:    */   
/* 200:    */   private static class PredicateFunction<T>
/* 201:    */     implements Function<T, Boolean>, Serializable
/* 202:    */   {
/* 203:    */     private final Predicate<T> predicate;
/* 204:    */     private static final long serialVersionUID = 0L;
/* 205:    */     
/* 206:    */     private PredicateFunction(Predicate<T> predicate)
/* 207:    */     {
/* 208:268 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/* 209:    */     }
/* 210:    */     
/* 211:    */     public Boolean apply(@Nullable T t)
/* 212:    */     {
/* 213:273 */       return Boolean.valueOf(this.predicate.apply(t));
/* 214:    */     }
/* 215:    */     
/* 216:    */     public boolean equals(@Nullable Object obj)
/* 217:    */     {
/* 218:278 */       if ((obj instanceof PredicateFunction))
/* 219:    */       {
/* 220:279 */         PredicateFunction<?> that = (PredicateFunction)obj;
/* 221:280 */         return this.predicate.equals(that.predicate);
/* 222:    */       }
/* 223:282 */       return false;
/* 224:    */     }
/* 225:    */     
/* 226:    */     public int hashCode()
/* 227:    */     {
/* 228:287 */       return this.predicate.hashCode();
/* 229:    */     }
/* 230:    */     
/* 231:    */     public String toString()
/* 232:    */     {
/* 233:292 */       return "Functions.forPredicate(" + this.predicate + ")";
/* 234:    */     }
/* 235:    */   }
/* 236:    */   
/* 237:    */   public static <E> Function<Object, E> constant(@Nullable E value)
/* 238:    */   {
/* 239:305 */     return new ConstantFunction(value);
/* 240:    */   }
/* 241:    */   
/* 242:    */   private static class ConstantFunction<E>
/* 243:    */     implements Function<Object, E>, Serializable
/* 244:    */   {
/* 245:    */     private final E value;
/* 246:    */     private static final long serialVersionUID = 0L;
/* 247:    */     
/* 248:    */     public ConstantFunction(@Nullable E value)
/* 249:    */     {
/* 250:312 */       this.value = value;
/* 251:    */     }
/* 252:    */     
/* 253:    */     public E apply(@Nullable Object from)
/* 254:    */     {
/* 255:317 */       return this.value;
/* 256:    */     }
/* 257:    */     
/* 258:    */     public boolean equals(@Nullable Object obj)
/* 259:    */     {
/* 260:322 */       if ((obj instanceof ConstantFunction))
/* 261:    */       {
/* 262:323 */         ConstantFunction<?> that = (ConstantFunction)obj;
/* 263:324 */         return Objects.equal(this.value, that.value);
/* 264:    */       }
/* 265:326 */       return false;
/* 266:    */     }
/* 267:    */     
/* 268:    */     public int hashCode()
/* 269:    */     {
/* 270:331 */       return this.value == null ? 0 : this.value.hashCode();
/* 271:    */     }
/* 272:    */     
/* 273:    */     public String toString()
/* 274:    */     {
/* 275:336 */       return "Functions.constant(" + this.value + ")";
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   @Beta
/* 280:    */   public static <T> Function<Object, T> forSupplier(Supplier<T> supplier)
/* 281:    */   {
/* 282:350 */     return new SupplierFunction(supplier, null);
/* 283:    */   }
/* 284:    */   
/* 285:    */   private static class SupplierFunction<T>
/* 286:    */     implements Function<Object, T>, Serializable
/* 287:    */   {
/* 288:    */     private final Supplier<T> supplier;
/* 289:    */     private static final long serialVersionUID = 0L;
/* 290:    */     
/* 291:    */     private SupplierFunction(Supplier<T> supplier)
/* 292:    */     {
/* 293:359 */       this.supplier = ((Supplier)Preconditions.checkNotNull(supplier));
/* 294:    */     }
/* 295:    */     
/* 296:    */     public T apply(@Nullable Object input)
/* 297:    */     {
/* 298:364 */       return this.supplier.get();
/* 299:    */     }
/* 300:    */     
/* 301:    */     public boolean equals(@Nullable Object obj)
/* 302:    */     {
/* 303:369 */       if ((obj instanceof SupplierFunction))
/* 304:    */       {
/* 305:370 */         SupplierFunction<?> that = (SupplierFunction)obj;
/* 306:371 */         return this.supplier.equals(that.supplier);
/* 307:    */       }
/* 308:373 */       return false;
/* 309:    */     }
/* 310:    */     
/* 311:    */     public int hashCode()
/* 312:    */     {
/* 313:378 */       return this.supplier.hashCode();
/* 314:    */     }
/* 315:    */     
/* 316:    */     public String toString()
/* 317:    */     {
/* 318:383 */       return "Functions.forSupplier(" + this.supplier + ")";
/* 319:    */     }
/* 320:    */   }
/* 321:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Functions
 * JD-Core Version:    0.7.0.1
 */