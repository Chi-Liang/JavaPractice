/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ import javax.annotation.CheckReturnValue;
/*  6:   */ 
/*  7:   */ @Beta
/*  8:   */ @GwtCompatible
/*  9:   */ public abstract class Ticker
/* 10:   */ {
/* 11:   */   public abstract long read();
/* 12:   */   
/* 13:   */   @CheckReturnValue
/* 14:   */   public static Ticker systemTicker()
/* 15:   */   {
/* 16:57 */     return SYSTEM_TICKER;
/* 17:   */   }
/* 18:   */   
/* 19:60 */   private static final Ticker SYSTEM_TICKER = new Ticker()
/* 20:   */   {
/* 21:   */     public long read()
/* 22:   */     {
/* 23:64 */       return Platform.systemNanoTime();
/* 24:   */     }
/* 25:   */   };
/* 26:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Ticker
 * JD-Core Version:    0.7.0.1
 */