/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @Beta
/*  8:   */ @GwtCompatible
/*  9:   */ public class VerifyException
/* 10:   */   extends RuntimeException
/* 11:   */ {
/* 12:   */   public VerifyException() {}
/* 13:   */   
/* 14:   */   public VerifyException(@Nullable String message)
/* 15:   */   {
/* 16:37 */     super(message);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public VerifyException(@Nullable Throwable cause)
/* 20:   */   {
/* 21:47 */     super(cause);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public VerifyException(@Nullable String message, @Nullable Throwable cause)
/* 25:   */   {
/* 26:57 */     super(message, cause);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.VerifyException
 * JD-Core Version:    0.7.0.1
 */