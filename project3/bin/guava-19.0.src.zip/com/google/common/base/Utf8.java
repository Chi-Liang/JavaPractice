/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import javax.annotation.CheckReturnValue;
/*   6:    */ 
/*   7:    */ @Beta
/*   8:    */ @GwtCompatible
/*   9:    */ public final class Utf8
/*  10:    */ {
/*  11:    */   @CheckReturnValue
/*  12:    */   public static int encodedLength(CharSequence sequence)
/*  13:    */   {
/*  14: 55 */     int utf16Length = sequence.length();
/*  15: 56 */     int utf8Length = utf16Length;
/*  16: 57 */     int i = 0;
/*  17: 60 */     while ((i < utf16Length) && (sequence.charAt(i) < '')) {
/*  18: 61 */       i++;
/*  19:    */     }
/*  20: 65 */     for (; i < utf16Length; i++)
/*  21:    */     {
/*  22: 66 */       char c = sequence.charAt(i);
/*  23: 67 */       if (c < 'ࠀ')
/*  24:    */       {
/*  25: 68 */         utf8Length += ('' - c >>> 31);
/*  26:    */       }
/*  27:    */       else
/*  28:    */       {
/*  29: 70 */         utf8Length += encodedLengthGeneral(sequence, i);
/*  30: 71 */         break;
/*  31:    */       }
/*  32:    */     }
/*  33: 75 */     if (utf8Length < utf16Length) {
/*  34: 77 */       throw new IllegalArgumentException("UTF-8 length does not fit in int: " + (utf8Length + 4294967296L));
/*  35:    */     }
/*  36: 80 */     return utf8Length;
/*  37:    */   }
/*  38:    */   
/*  39:    */   private static int encodedLengthGeneral(CharSequence sequence, int start)
/*  40:    */   {
/*  41: 84 */     int utf16Length = sequence.length();
/*  42: 85 */     int utf8Length = 0;
/*  43: 86 */     for (int i = start; i < utf16Length; i++)
/*  44:    */     {
/*  45: 87 */       char c = sequence.charAt(i);
/*  46: 88 */       if (c < 'ࠀ')
/*  47:    */       {
/*  48: 89 */         utf8Length += ('' - c >>> 31);
/*  49:    */       }
/*  50:    */       else
/*  51:    */       {
/*  52: 91 */         utf8Length += 2;
/*  53: 93 */         if ((55296 <= c) && (c <= 57343))
/*  54:    */         {
/*  55: 95 */           if (Character.codePointAt(sequence, i) == c) {
/*  56: 96 */             throw new IllegalArgumentException(unpairedSurrogateMsg(i));
/*  57:    */           }
/*  58: 98 */           i++;
/*  59:    */         }
/*  60:    */       }
/*  61:    */     }
/*  62:102 */     return utf8Length;
/*  63:    */   }
/*  64:    */   
/*  65:    */   @CheckReturnValue
/*  66:    */   public static boolean isWellFormed(byte[] bytes)
/*  67:    */   {
/*  68:117 */     return isWellFormed(bytes, 0, bytes.length);
/*  69:    */   }
/*  70:    */   
/*  71:    */   @CheckReturnValue
/*  72:    */   public static boolean isWellFormed(byte[] bytes, int off, int len)
/*  73:    */   {
/*  74:131 */     int end = off + len;
/*  75:132 */     Preconditions.checkPositionIndexes(off, end, bytes.length);
/*  76:134 */     for (int i = off; i < end; i++) {
/*  77:135 */       if (bytes[i] < 0) {
/*  78:136 */         return isWellFormedSlowPath(bytes, i, end);
/*  79:    */       }
/*  80:    */     }
/*  81:139 */     return true;
/*  82:    */   }
/*  83:    */   
/*  84:    */   private static boolean isWellFormedSlowPath(byte[] bytes, int off, int end)
/*  85:    */   {
/*  86:143 */     int index = off;
/*  87:    */     for (;;)
/*  88:    */     {
/*  89:149 */       if (index >= end) {
/*  90:150 */         return true;
/*  91:    */       }
/*  92:    */       int byte1;
/*  93:152 */       if ((byte1 = bytes[(index++)]) < 0) {
/*  94:154 */         if (byte1 < -32)
/*  95:    */         {
/*  96:156 */           if (index == end) {
/*  97:157 */             return false;
/*  98:    */           }
/*  99:161 */           if ((byte1 < -62) || (bytes[(index++)] > -65)) {
/* 100:162 */             return false;
/* 101:    */           }
/* 102:    */         }
/* 103:164 */         else if (byte1 < -16)
/* 104:    */         {
/* 105:166 */           if (index + 1 >= end) {
/* 106:167 */             return false;
/* 107:    */           }
/* 108:169 */           int byte2 = bytes[(index++)];
/* 109:170 */           if ((byte2 > -65) || ((byte1 == -32) && (byte2 < -96)) || ((byte1 == -19) && (-96 <= byte2)) || (bytes[(index++)] > -65)) {
/* 110:177 */             return false;
/* 111:    */           }
/* 112:    */         }
/* 113:    */         else
/* 114:    */         {
/* 115:181 */           if (index + 2 >= end) {
/* 116:182 */             return false;
/* 117:    */           }
/* 118:184 */           int byte2 = bytes[(index++)];
/* 119:185 */           if ((byte2 > -65) || ((byte1 << 28) + (byte2 - -112) >> 30 != 0) || (bytes[(index++)] > -65) || (bytes[(index++)] > -65)) {
/* 120:195 */             return false;
/* 121:    */           }
/* 122:    */         }
/* 123:    */       }
/* 124:    */     }
/* 125:    */   }
/* 126:    */   
/* 127:    */   private static String unpairedSurrogateMsg(int i)
/* 128:    */   {
/* 129:202 */     return "Unpaired surrogate at index " + i;
/* 130:    */   }
/* 131:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Utf8
 * JD-Core Version:    0.7.0.1
 */