/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import java.io.Closeable;
/*   5:    */ import java.io.FileNotFoundException;
/*   6:    */ import java.io.IOException;
/*   7:    */ import java.lang.ref.PhantomReference;
/*   8:    */ import java.lang.ref.Reference;
/*   9:    */ import java.lang.ref.ReferenceQueue;
/*  10:    */ import java.lang.reflect.Method;
/*  11:    */ import java.net.URL;
/*  12:    */ import java.net.URLClassLoader;
/*  13:    */ import java.util.logging.Level;
/*  14:    */ import java.util.logging.Logger;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ public class FinalizableReferenceQueue
/*  18:    */   implements Closeable
/*  19:    */ {
/*  20:131 */   private static final Logger logger = Logger.getLogger(FinalizableReferenceQueue.class.getName());
/*  21:    */   private static final String FINALIZER_CLASS_NAME = "com.google.common.base.internal.Finalizer";
/*  22:    */   private static final Method startFinalizer;
/*  23:    */   final ReferenceQueue<Object> queue;
/*  24:    */   final PhantomReference<Object> frqRef;
/*  25:    */   final boolean threadStarted;
/*  26:    */   
/*  27:    */   static
/*  28:    */   {
/*  29:139 */     Class<?> finalizer = loadFinalizer(new FinalizerLoader[] { new SystemLoader(), new DecoupledLoader(), new DirectLoader() });
/*  30:    */     
/*  31:141 */     startFinalizer = getStartFinalizer(finalizer);
/*  32:    */   }
/*  33:    */   
/*  34:    */   public FinalizableReferenceQueue()
/*  35:    */   {
/*  36:161 */     this.queue = new ReferenceQueue();
/*  37:162 */     this.frqRef = new PhantomReference(this, this.queue);
/*  38:163 */     boolean threadStarted = false;
/*  39:    */     try
/*  40:    */     {
/*  41:165 */       startFinalizer.invoke(null, new Object[] { FinalizableReference.class, this.queue, this.frqRef });
/*  42:166 */       threadStarted = true;
/*  43:    */     }
/*  44:    */     catch (IllegalAccessException impossible)
/*  45:    */     {
/*  46:168 */       throw new AssertionError(impossible);
/*  47:    */     }
/*  48:    */     catch (Throwable t)
/*  49:    */     {
/*  50:170 */       logger.log(Level.INFO, "Failed to start reference finalizer thread. Reference cleanup will only occur when new references are created.", t);
/*  51:    */     }
/*  52:177 */     this.threadStarted = threadStarted;
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void close()
/*  56:    */   {
/*  57:182 */     this.frqRef.enqueue();
/*  58:183 */     cleanUp();
/*  59:    */   }
/*  60:    */   
/*  61:    */   void cleanUp()
/*  62:    */   {
/*  63:192 */     if (this.threadStarted) {
/*  64:    */       return;
/*  65:    */     }
/*  66:    */     Reference<?> reference;
/*  67:197 */     while ((reference = this.queue.poll()) != null)
/*  68:    */     {
/*  69:202 */       reference.clear();
/*  70:    */       try
/*  71:    */       {
/*  72:204 */         ((FinalizableReference)reference).finalizeReferent();
/*  73:    */       }
/*  74:    */       catch (Throwable t)
/*  75:    */       {
/*  76:206 */         logger.log(Level.SEVERE, "Error cleaning up after reference.", t);
/*  77:    */       }
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   private static Class<?> loadFinalizer(FinalizerLoader... loaders)
/*  82:    */   {
/*  83:217 */     for (FinalizerLoader loader : loaders)
/*  84:    */     {
/*  85:218 */       Class<?> finalizer = loader.loadFinalizer();
/*  86:219 */       if (finalizer != null) {
/*  87:220 */         return finalizer;
/*  88:    */       }
/*  89:    */     }
/*  90:224 */     throw new AssertionError();
/*  91:    */   }
/*  92:    */   
/*  93:    */   static abstract interface FinalizerLoader
/*  94:    */   {
/*  95:    */     @Nullable
/*  96:    */     public abstract Class<?> loadFinalizer();
/*  97:    */   }
/*  98:    */   
/*  99:    */   static class SystemLoader
/* 100:    */     implements FinalizableReferenceQueue.FinalizerLoader
/* 101:    */   {
/* 102:    */     @VisibleForTesting
/* 103:    */     static boolean disabled;
/* 104:    */     
/* 105:    */     public Class<?> loadFinalizer()
/* 106:    */     {
/* 107:252 */       if (disabled) {
/* 108:253 */         return null;
/* 109:    */       }
/* 110:    */       ClassLoader systemLoader;
/* 111:    */       try
/* 112:    */       {
/* 113:257 */         systemLoader = ClassLoader.getSystemClassLoader();
/* 114:    */       }
/* 115:    */       catch (SecurityException e)
/* 116:    */       {
/* 117:259 */         FinalizableReferenceQueue.logger.info("Not allowed to access system class loader.");
/* 118:260 */         return null;
/* 119:    */       }
/* 120:262 */       if (systemLoader != null) {
/* 121:    */         try
/* 122:    */         {
/* 123:264 */           return systemLoader.loadClass("com.google.common.base.internal.Finalizer");
/* 124:    */         }
/* 125:    */         catch (ClassNotFoundException e)
/* 126:    */         {
/* 127:267 */           return null;
/* 128:    */         }
/* 129:    */       }
/* 130:270 */       return null;
/* 131:    */     }
/* 132:    */   }
/* 133:    */   
/* 134:    */   static class DecoupledLoader
/* 135:    */     implements FinalizableReferenceQueue.FinalizerLoader
/* 136:    */   {
/* 137:    */     private static final String LOADING_ERROR = "Could not load Finalizer in its own class loader. Loading Finalizer in the current class loader instead. As a result, you will not be able to garbage collect this class loader. To support reclaiming this class loader, either resolve the underlying issue, or move Guava to your system class path.";
/* 138:    */     
/* 139:    */     public Class<?> loadFinalizer()
/* 140:    */     {
/* 141:    */       try
/* 142:    */       {
/* 143:299 */         ClassLoader finalizerLoader = newLoader(getBaseUrl());
/* 144:300 */         return finalizerLoader.loadClass("com.google.common.base.internal.Finalizer");
/* 145:    */       }
/* 146:    */       catch (Exception e)
/* 147:    */       {
/* 148:302 */         FinalizableReferenceQueue.logger.log(Level.WARNING, "Could not load Finalizer in its own class loader. Loading Finalizer in the current class loader instead. As a result, you will not be able to garbage collect this class loader. To support reclaiming this class loader, either resolve the underlying issue, or move Guava to your system class path.", e);
/* 149:    */       }
/* 150:303 */       return null;
/* 151:    */     }
/* 152:    */     
/* 153:    */     URL getBaseUrl()
/* 154:    */       throws IOException
/* 155:    */     {
/* 156:312 */       String finalizerPath = "com.google.common.base.internal.Finalizer".replace('.', '/') + ".class";
/* 157:313 */       URL finalizerUrl = getClass().getClassLoader().getResource(finalizerPath);
/* 158:314 */       if (finalizerUrl == null) {
/* 159:315 */         throw new FileNotFoundException(finalizerPath);
/* 160:    */       }
/* 161:319 */       String urlString = finalizerUrl.toString();
/* 162:320 */       if (!urlString.endsWith(finalizerPath)) {
/* 163:321 */         throw new IOException("Unsupported path style: " + urlString);
/* 164:    */       }
/* 165:323 */       urlString = urlString.substring(0, urlString.length() - finalizerPath.length());
/* 166:324 */       return new URL(finalizerUrl, urlString);
/* 167:    */     }
/* 168:    */     
/* 169:    */     URLClassLoader newLoader(URL base)
/* 170:    */     {
/* 171:332 */       return new URLClassLoader(new URL[] { base }, null);
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   static class DirectLoader
/* 176:    */     implements FinalizableReferenceQueue.FinalizerLoader
/* 177:    */   {
/* 178:    */     public Class<?> loadFinalizer()
/* 179:    */     {
/* 180:    */       try
/* 181:    */       {
/* 182:344 */         return Class.forName("com.google.common.base.internal.Finalizer");
/* 183:    */       }
/* 184:    */       catch (ClassNotFoundException e)
/* 185:    */       {
/* 186:346 */         throw new AssertionError(e);
/* 187:    */       }
/* 188:    */     }
/* 189:    */   }
/* 190:    */   
/* 191:    */   static Method getStartFinalizer(Class<?> finalizer)
/* 192:    */   {
/* 193:    */     try
/* 194:    */     {
/* 195:356 */       return finalizer.getMethod("startFinalizer", new Class[] { Class.class, ReferenceQueue.class, PhantomReference.class });
/* 196:    */     }
/* 197:    */     catch (NoSuchMethodException e)
/* 198:    */     {
/* 199:359 */       throw new AssertionError(e);
/* 200:    */     }
/* 201:    */   }
/* 202:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.FinalizableReferenceQueue
 * JD-Core Version:    0.7.0.1
 */