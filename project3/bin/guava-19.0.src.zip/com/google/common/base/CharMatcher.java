/*    1:     */ package com.google.common.base;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.annotations.VisibleForTesting;
/*    7:     */ import java.util.Arrays;
/*    8:     */ import java.util.BitSet;
/*    9:     */ import javax.annotation.CheckReturnValue;
/*   10:     */ 
/*   11:     */ @Beta
/*   12:     */ @GwtCompatible(emulated=true)
/*   13:     */ public abstract class CharMatcher
/*   14:     */   implements Predicate<Character>
/*   15:     */ {
/*   16:     */   public static CharMatcher any()
/*   17:     */   {
/*   18:  69 */     return Any.INSTANCE;
/*   19:     */   }
/*   20:     */   
/*   21:     */   public static CharMatcher none()
/*   22:     */   {
/*   23:  78 */     return None.INSTANCE;
/*   24:     */   }
/*   25:     */   
/*   26:     */   public static CharMatcher whitespace()
/*   27:     */   {
/*   28:  94 */     return Whitespace.INSTANCE;
/*   29:     */   }
/*   30:     */   
/*   31:     */   public static CharMatcher breakingWhitespace()
/*   32:     */   {
/*   33: 105 */     return BreakingWhitespace.INSTANCE;
/*   34:     */   }
/*   35:     */   
/*   36:     */   public static CharMatcher ascii()
/*   37:     */   {
/*   38: 114 */     return Ascii.INSTANCE;
/*   39:     */   }
/*   40:     */   
/*   41:     */   public static CharMatcher digit()
/*   42:     */   {
/*   43: 125 */     return Digit.INSTANCE;
/*   44:     */   }
/*   45:     */   
/*   46:     */   public static CharMatcher javaDigit()
/*   47:     */   {
/*   48: 136 */     return JavaDigit.INSTANCE;
/*   49:     */   }
/*   50:     */   
/*   51:     */   public static CharMatcher javaLetter()
/*   52:     */   {
/*   53: 147 */     return JavaLetter.INSTANCE;
/*   54:     */   }
/*   55:     */   
/*   56:     */   public static CharMatcher javaLetterOrDigit()
/*   57:     */   {
/*   58: 157 */     return JavaLetterOrDigit.INSTANCE;
/*   59:     */   }
/*   60:     */   
/*   61:     */   public static CharMatcher javaUpperCase()
/*   62:     */   {
/*   63: 167 */     return JavaUpperCase.INSTANCE;
/*   64:     */   }
/*   65:     */   
/*   66:     */   public static CharMatcher javaLowerCase()
/*   67:     */   {
/*   68: 177 */     return JavaLowerCase.INSTANCE;
/*   69:     */   }
/*   70:     */   
/*   71:     */   public static CharMatcher javaIsoControl()
/*   72:     */   {
/*   73: 187 */     return JavaIsoControl.INSTANCE;
/*   74:     */   }
/*   75:     */   
/*   76:     */   public static CharMatcher invisible()
/*   77:     */   {
/*   78: 198 */     return Invisible.INSTANCE;
/*   79:     */   }
/*   80:     */   
/*   81:     */   public static CharMatcher singleWidth()
/*   82:     */   {
/*   83: 212 */     return SingleWidth.INSTANCE;
/*   84:     */   }
/*   85:     */   
/*   86: 228 */   public static final CharMatcher WHITESPACE = ;
/*   87: 237 */   public static final CharMatcher BREAKING_WHITESPACE = breakingWhitespace();
/*   88: 242 */   public static final CharMatcher ASCII = ascii();
/*   89: 249 */   public static final CharMatcher DIGIT = digit();
/*   90: 256 */   public static final CharMatcher JAVA_DIGIT = javaDigit();
/*   91: 263 */   public static final CharMatcher JAVA_LETTER = javaLetter();
/*   92: 269 */   public static final CharMatcher JAVA_LETTER_OR_DIGIT = javaLetterOrDigit();
/*   93: 275 */   public static final CharMatcher JAVA_UPPER_CASE = javaUpperCase();
/*   94: 281 */   public static final CharMatcher JAVA_LOWER_CASE = javaLowerCase();
/*   95: 287 */   public static final CharMatcher JAVA_ISO_CONTROL = javaIsoControl();
/*   96: 294 */   public static final CharMatcher INVISIBLE = invisible();
/*   97: 304 */   public static final CharMatcher SINGLE_WIDTH = singleWidth();
/*   98: 307 */   public static final CharMatcher ANY = any();
/*   99: 310 */   public static final CharMatcher NONE = none();
/*  100:     */   private static final int DISTINCT_CHARS = 65536;
/*  101:     */   
/*  102:     */   public static CharMatcher is(char match)
/*  103:     */   {
/*  104: 318 */     return new Is(match);
/*  105:     */   }
/*  106:     */   
/*  107:     */   public static CharMatcher isNot(char match)
/*  108:     */   {
/*  109: 327 */     return new IsNot(match);
/*  110:     */   }
/*  111:     */   
/*  112:     */   public static CharMatcher anyOf(CharSequence sequence)
/*  113:     */   {
/*  114: 335 */     switch (sequence.length())
/*  115:     */     {
/*  116:     */     case 0: 
/*  117: 337 */       return none();
/*  118:     */     case 1: 
/*  119: 339 */       return is(sequence.charAt(0));
/*  120:     */     case 2: 
/*  121: 341 */       return isEither(sequence.charAt(0), sequence.charAt(1));
/*  122:     */     }
/*  123: 345 */     return new AnyOf(sequence);
/*  124:     */   }
/*  125:     */   
/*  126:     */   public static CharMatcher noneOf(CharSequence sequence)
/*  127:     */   {
/*  128: 354 */     return anyOf(sequence).negate();
/*  129:     */   }
/*  130:     */   
/*  131:     */   public static CharMatcher inRange(char startInclusive, char endInclusive)
/*  132:     */   {
/*  133: 365 */     return new InRange(startInclusive, endInclusive);
/*  134:     */   }
/*  135:     */   
/*  136:     */   public static CharMatcher forPredicate(Predicate<? super Character> predicate)
/*  137:     */   {
/*  138: 373 */     return (predicate instanceof CharMatcher) ? (CharMatcher)predicate : new ForPredicate(predicate);
/*  139:     */   }
/*  140:     */   
/*  141:     */   public abstract boolean matches(char paramChar);
/*  142:     */   
/*  143:     */   public CharMatcher negate()
/*  144:     */   {
/*  145: 395 */     return new Negated(this);
/*  146:     */   }
/*  147:     */   
/*  148:     */   public CharMatcher and(CharMatcher other)
/*  149:     */   {
/*  150: 402 */     return new And(this, other);
/*  151:     */   }
/*  152:     */   
/*  153:     */   public CharMatcher or(CharMatcher other)
/*  154:     */   {
/*  155: 409 */     return new Or(this, other);
/*  156:     */   }
/*  157:     */   
/*  158:     */   public CharMatcher precomputed()
/*  159:     */   {
/*  160: 422 */     return Platform.precomputeCharMatcher(this);
/*  161:     */   }
/*  162:     */   
/*  163:     */   @GwtIncompatible("java.util.BitSet")
/*  164:     */   CharMatcher precomputedInternal()
/*  165:     */   {
/*  166: 439 */     BitSet table = new BitSet();
/*  167: 440 */     setBits(table);
/*  168: 441 */     int totalCharacters = table.cardinality();
/*  169: 442 */     if (totalCharacters * 2 <= 65536) {
/*  170: 443 */       return precomputedPositive(totalCharacters, table, toString());
/*  171:     */     }
/*  172: 446 */     table.flip(0, 65536);
/*  173: 447 */     int negatedCharacters = 65536 - totalCharacters;
/*  174: 448 */     String suffix = ".negate()";
/*  175: 449 */     final String description = toString();
/*  176: 450 */     String negatedDescription = description + suffix;
/*  177:     */     
/*  178:     */ 
/*  179:     */ 
/*  180: 454 */     new NegatedFastMatcher(precomputedPositive(negatedCharacters, table, negatedDescription))
/*  181:     */     {
/*  182:     */       public String toString()
/*  183:     */       {
/*  184: 458 */         return description;
/*  185:     */       }
/*  186:     */     };
/*  187:     */   }
/*  188:     */   
/*  189:     */   @GwtIncompatible("java.util.BitSet")
/*  190:     */   private static CharMatcher precomputedPositive(int totalCharacters, BitSet table, String description)
/*  191:     */   {
/*  192: 470 */     switch (totalCharacters)
/*  193:     */     {
/*  194:     */     case 0: 
/*  195: 472 */       return none();
/*  196:     */     case 1: 
/*  197: 474 */       return is((char)table.nextSetBit(0));
/*  198:     */     case 2: 
/*  199: 476 */       char c1 = (char)table.nextSetBit(0);
/*  200: 477 */       char c2 = (char)table.nextSetBit(c1 + '\001');
/*  201: 478 */       return isEither(c1, c2);
/*  202:     */     }
/*  203: 480 */     return isSmall(totalCharacters, table.length()) ? SmallCharMatcher.from(table, description) : new BitSetMatcher(table, description, null);
/*  204:     */   }
/*  205:     */   
/*  206:     */   @GwtIncompatible("SmallCharMatcher")
/*  207:     */   private static boolean isSmall(int totalCharacters, int tableLength)
/*  208:     */   {
/*  209: 488 */     return (totalCharacters <= 1023) && (tableLength > totalCharacters * 4 * 16);
/*  210:     */   }
/*  211:     */   
/*  212:     */   @GwtIncompatible("java.util.BitSet")
/*  213:     */   void setBits(BitSet table)
/*  214:     */   {
/*  215: 498 */     for (int c = 65535; c >= 0; c--) {
/*  216: 499 */       if (matches((char)c)) {
/*  217: 500 */         table.set(c);
/*  218:     */       }
/*  219:     */     }
/*  220:     */   }
/*  221:     */   
/*  222:     */   public boolean matchesAnyOf(CharSequence sequence)
/*  223:     */   {
/*  224: 519 */     return !matchesNoneOf(sequence);
/*  225:     */   }
/*  226:     */   
/*  227:     */   public boolean matchesAllOf(CharSequence sequence)
/*  228:     */   {
/*  229: 533 */     for (int i = sequence.length() - 1; i >= 0; i--) {
/*  230: 534 */       if (!matches(sequence.charAt(i))) {
/*  231: 535 */         return false;
/*  232:     */       }
/*  233:     */     }
/*  234: 538 */     return true;
/*  235:     */   }
/*  236:     */   
/*  237:     */   public boolean matchesNoneOf(CharSequence sequence)
/*  238:     */   {
/*  239: 553 */     return indexIn(sequence) == -1;
/*  240:     */   }
/*  241:     */   
/*  242:     */   public int indexIn(CharSequence sequence)
/*  243:     */   {
/*  244: 567 */     return indexIn(sequence, 0);
/*  245:     */   }
/*  246:     */   
/*  247:     */   public int indexIn(CharSequence sequence, int start)
/*  248:     */   {
/*  249: 586 */     int length = sequence.length();
/*  250: 587 */     Preconditions.checkPositionIndex(start, length);
/*  251: 588 */     for (int i = start; i < length; i++) {
/*  252: 589 */       if (matches(sequence.charAt(i))) {
/*  253: 590 */         return i;
/*  254:     */       }
/*  255:     */     }
/*  256: 593 */     return -1;
/*  257:     */   }
/*  258:     */   
/*  259:     */   public int lastIndexIn(CharSequence sequence)
/*  260:     */   {
/*  261: 607 */     for (int i = sequence.length() - 1; i >= 0; i--) {
/*  262: 608 */       if (matches(sequence.charAt(i))) {
/*  263: 609 */         return i;
/*  264:     */       }
/*  265:     */     }
/*  266: 612 */     return -1;
/*  267:     */   }
/*  268:     */   
/*  269:     */   public int countIn(CharSequence sequence)
/*  270:     */   {
/*  271: 619 */     int count = 0;
/*  272: 620 */     for (int i = 0; i < sequence.length(); i++) {
/*  273: 621 */       if (matches(sequence.charAt(i))) {
/*  274: 622 */         count++;
/*  275:     */       }
/*  276:     */     }
/*  277: 625 */     return count;
/*  278:     */   }
/*  279:     */   
/*  280:     */   @CheckReturnValue
/*  281:     */   public String removeFrom(CharSequence sequence)
/*  282:     */   {
/*  283: 638 */     String string = sequence.toString();
/*  284: 639 */     int pos = indexIn(string);
/*  285: 640 */     if (pos == -1) {
/*  286: 641 */       return string;
/*  287:     */     }
/*  288: 644 */     char[] chars = string.toCharArray();
/*  289: 645 */     int spread = 1;
/*  290:     */     for (;;)
/*  291:     */     {
/*  292: 650 */       pos++;
/*  293:     */       for (;;)
/*  294:     */       {
/*  295: 652 */         if (pos == chars.length) {
/*  296:     */           break label79;
/*  297:     */         }
/*  298: 655 */         if (matches(chars[pos])) {
/*  299:     */           break;
/*  300:     */         }
/*  301: 658 */         chars[(pos - spread)] = chars[pos];
/*  302: 659 */         pos++;
/*  303:     */       }
/*  304: 661 */       spread++;
/*  305:     */     }
/*  306:     */     label79:
/*  307: 663 */     return new String(chars, 0, pos - spread);
/*  308:     */   }
/*  309:     */   
/*  310:     */   @CheckReturnValue
/*  311:     */   public String retainFrom(CharSequence sequence)
/*  312:     */   {
/*  313: 676 */     return negate().removeFrom(sequence);
/*  314:     */   }
/*  315:     */   
/*  316:     */   @CheckReturnValue
/*  317:     */   public String replaceFrom(CharSequence sequence, char replacement)
/*  318:     */   {
/*  319: 698 */     String string = sequence.toString();
/*  320: 699 */     int pos = indexIn(string);
/*  321: 700 */     if (pos == -1) {
/*  322: 701 */       return string;
/*  323:     */     }
/*  324: 703 */     char[] chars = string.toCharArray();
/*  325: 704 */     chars[pos] = replacement;
/*  326: 705 */     for (int i = pos + 1; i < chars.length; i++) {
/*  327: 706 */       if (matches(chars[i])) {
/*  328: 707 */         chars[i] = replacement;
/*  329:     */       }
/*  330:     */     }
/*  331: 710 */     return new String(chars);
/*  332:     */   }
/*  333:     */   
/*  334:     */   @CheckReturnValue
/*  335:     */   public String replaceFrom(CharSequence sequence, CharSequence replacement)
/*  336:     */   {
/*  337: 731 */     int replacementLen = replacement.length();
/*  338: 732 */     if (replacementLen == 0) {
/*  339: 733 */       return removeFrom(sequence);
/*  340:     */     }
/*  341: 735 */     if (replacementLen == 1) {
/*  342: 736 */       return replaceFrom(sequence, replacement.charAt(0));
/*  343:     */     }
/*  344: 739 */     String string = sequence.toString();
/*  345: 740 */     int pos = indexIn(string);
/*  346: 741 */     if (pos == -1) {
/*  347: 742 */       return string;
/*  348:     */     }
/*  349: 745 */     int len = string.length();
/*  350: 746 */     StringBuilder buf = new StringBuilder(len * 3 / 2 + 16);
/*  351:     */     
/*  352: 748 */     int oldpos = 0;
/*  353:     */     do
/*  354:     */     {
/*  355: 750 */       buf.append(string, oldpos, pos);
/*  356: 751 */       buf.append(replacement);
/*  357: 752 */       oldpos = pos + 1;
/*  358: 753 */       pos = indexIn(string, oldpos);
/*  359: 754 */     } while (pos != -1);
/*  360: 756 */     buf.append(string, oldpos, len);
/*  361: 757 */     return buf.toString();
/*  362:     */   }
/*  363:     */   
/*  364:     */   @CheckReturnValue
/*  365:     */   public String trimFrom(CharSequence sequence)
/*  366:     */   {
/*  367: 776 */     int len = sequence.length();
/*  368: 780 */     for (int first = 0; first < len; first++) {
/*  369: 781 */       if (!matches(sequence.charAt(first))) {
/*  370:     */         break;
/*  371:     */       }
/*  372:     */     }
/*  373: 785 */     for (int last = len - 1; last > first; last--) {
/*  374: 786 */       if (!matches(sequence.charAt(last))) {
/*  375:     */         break;
/*  376:     */       }
/*  377:     */     }
/*  378: 791 */     return sequence.subSequence(first, last + 1).toString();
/*  379:     */   }
/*  380:     */   
/*  381:     */   @CheckReturnValue
/*  382:     */   public String trimLeadingFrom(CharSequence sequence)
/*  383:     */   {
/*  384: 804 */     int len = sequence.length();
/*  385: 805 */     for (int first = 0; first < len; first++) {
/*  386: 806 */       if (!matches(sequence.charAt(first))) {
/*  387: 807 */         return sequence.subSequence(first, len).toString();
/*  388:     */       }
/*  389:     */     }
/*  390: 810 */     return "";
/*  391:     */   }
/*  392:     */   
/*  393:     */   @CheckReturnValue
/*  394:     */   public String trimTrailingFrom(CharSequence sequence)
/*  395:     */   {
/*  396: 823 */     int len = sequence.length();
/*  397: 824 */     for (int last = len - 1; last >= 0; last--) {
/*  398: 825 */       if (!matches(sequence.charAt(last))) {
/*  399: 826 */         return sequence.subSequence(0, last + 1).toString();
/*  400:     */       }
/*  401:     */     }
/*  402: 829 */     return "";
/*  403:     */   }
/*  404:     */   
/*  405:     */   @CheckReturnValue
/*  406:     */   public String collapseFrom(CharSequence sequence, char replacement)
/*  407:     */   {
/*  408: 853 */     int len = sequence.length();
/*  409: 854 */     for (int i = 0; i < len; i++)
/*  410:     */     {
/*  411: 855 */       char c = sequence.charAt(i);
/*  412: 856 */       if (matches(c)) {
/*  413: 857 */         if ((c == replacement) && ((i == len - 1) || (!matches(sequence.charAt(i + 1)))))
/*  414:     */         {
/*  415: 859 */           i++;
/*  416:     */         }
/*  417:     */         else
/*  418:     */         {
/*  419: 861 */           StringBuilder builder = new StringBuilder(len).append(sequence.subSequence(0, i)).append(replacement);
/*  420:     */           
/*  421: 863 */           return finishCollapseFrom(sequence, i + 1, len, replacement, builder, true);
/*  422:     */         }
/*  423:     */       }
/*  424:     */     }
/*  425: 868 */     return sequence.toString();
/*  426:     */   }
/*  427:     */   
/*  428:     */   @CheckReturnValue
/*  429:     */   public String trimAndCollapseFrom(CharSequence sequence, char replacement)
/*  430:     */   {
/*  431: 879 */     int len = sequence.length();
/*  432: 880 */     int first = 0;
/*  433: 881 */     int last = len - 1;
/*  434: 883 */     while ((first < len) && (matches(sequence.charAt(first)))) {
/*  435: 884 */       first++;
/*  436:     */     }
/*  437: 887 */     while ((last > first) && (matches(sequence.charAt(last)))) {
/*  438: 888 */       last--;
/*  439:     */     }
/*  440: 891 */     return (first == 0) && (last == len - 1) ? collapseFrom(sequence, replacement) : finishCollapseFrom(sequence, first, last + 1, replacement, new StringBuilder(last + 1 - first), false);
/*  441:     */   }
/*  442:     */   
/*  443:     */   private String finishCollapseFrom(CharSequence sequence, int start, int end, char replacement, StringBuilder builder, boolean inMatchingGroup)
/*  444:     */   {
/*  445: 904 */     for (int i = start; i < end; i++)
/*  446:     */     {
/*  447: 905 */       char c = sequence.charAt(i);
/*  448: 906 */       if (matches(c))
/*  449:     */       {
/*  450: 907 */         if (!inMatchingGroup)
/*  451:     */         {
/*  452: 908 */           builder.append(replacement);
/*  453: 909 */           inMatchingGroup = true;
/*  454:     */         }
/*  455:     */       }
/*  456:     */       else
/*  457:     */       {
/*  458: 912 */         builder.append(c);
/*  459: 913 */         inMatchingGroup = false;
/*  460:     */       }
/*  461:     */     }
/*  462: 916 */     return builder.toString();
/*  463:     */   }
/*  464:     */   
/*  465:     */   @Deprecated
/*  466:     */   public boolean apply(Character character)
/*  467:     */   {
/*  468: 926 */     return matches(character.charValue());
/*  469:     */   }
/*  470:     */   
/*  471:     */   public String toString()
/*  472:     */   {
/*  473: 935 */     return super.toString();
/*  474:     */   }
/*  475:     */   
/*  476:     */   private static String showCharacter(char c)
/*  477:     */   {
/*  478: 943 */     String hex = "0123456789ABCDEF";
/*  479: 944 */     char[] tmp = { '\\', 'u', '\000', '\000', '\000', '\000' };
/*  480: 945 */     for (int i = 0; i < 4; i++)
/*  481:     */     {
/*  482: 946 */       tmp[(5 - i)] = hex.charAt(c & 0xF);
/*  483: 947 */       c = (char)(c >> '\004');
/*  484:     */     }
/*  485: 949 */     return String.copyValueOf(tmp);
/*  486:     */   }
/*  487:     */   
/*  488:     */   static abstract class FastMatcher
/*  489:     */     extends CharMatcher
/*  490:     */   {
/*  491:     */     public final CharMatcher precomputed()
/*  492:     */     {
/*  493: 959 */       return this;
/*  494:     */     }
/*  495:     */     
/*  496:     */     public CharMatcher negate()
/*  497:     */     {
/*  498: 964 */       return new CharMatcher.NegatedFastMatcher(this);
/*  499:     */     }
/*  500:     */   }
/*  501:     */   
/*  502:     */   static abstract class NamedFastMatcher
/*  503:     */     extends CharMatcher.FastMatcher
/*  504:     */   {
/*  505:     */     private final String description;
/*  506:     */     
/*  507:     */     NamedFastMatcher(String description)
/*  508:     */     {
/*  509: 974 */       this.description = ((String)Preconditions.checkNotNull(description));
/*  510:     */     }
/*  511:     */     
/*  512:     */     public final String toString()
/*  513:     */     {
/*  514: 979 */       return this.description;
/*  515:     */     }
/*  516:     */   }
/*  517:     */   
/*  518:     */   static class NegatedFastMatcher
/*  519:     */     extends CharMatcher.Negated
/*  520:     */   {
/*  521:     */     NegatedFastMatcher(CharMatcher original)
/*  522:     */     {
/*  523: 987 */       super();
/*  524:     */     }
/*  525:     */     
/*  526:     */     public final CharMatcher precomputed()
/*  527:     */     {
/*  528: 992 */       return this;
/*  529:     */     }
/*  530:     */   }
/*  531:     */   
/*  532:     */   @GwtIncompatible("java.util.BitSet")
/*  533:     */   private static final class BitSetMatcher
/*  534:     */     extends CharMatcher.NamedFastMatcher
/*  535:     */   {
/*  536:     */     private final BitSet table;
/*  537:     */     
/*  538:     */     private BitSetMatcher(BitSet table, String description)
/*  539:     */     {
/*  540:1003 */       super();
/*  541:1004 */       if (table.length() + 64 < table.size()) {
/*  542:1005 */         table = (BitSet)table.clone();
/*  543:     */       }
/*  544:1008 */       this.table = table;
/*  545:     */     }
/*  546:     */     
/*  547:     */     public boolean matches(char c)
/*  548:     */     {
/*  549:1013 */       return this.table.get(c);
/*  550:     */     }
/*  551:     */     
/*  552:     */     void setBits(BitSet bitSet)
/*  553:     */     {
/*  554:1018 */       bitSet.or(this.table);
/*  555:     */     }
/*  556:     */   }
/*  557:     */   
/*  558:     */   private static final class Any
/*  559:     */     extends CharMatcher.NamedFastMatcher
/*  560:     */   {
/*  561:1027 */     static final Any INSTANCE = new Any();
/*  562:     */     
/*  563:     */     private Any()
/*  564:     */     {
/*  565:1030 */       super();
/*  566:     */     }
/*  567:     */     
/*  568:     */     public boolean matches(char c)
/*  569:     */     {
/*  570:1035 */       return true;
/*  571:     */     }
/*  572:     */     
/*  573:     */     public int indexIn(CharSequence sequence)
/*  574:     */     {
/*  575:1040 */       return sequence.length() == 0 ? -1 : 0;
/*  576:     */     }
/*  577:     */     
/*  578:     */     public int indexIn(CharSequence sequence, int start)
/*  579:     */     {
/*  580:1045 */       int length = sequence.length();
/*  581:1046 */       Preconditions.checkPositionIndex(start, length);
/*  582:1047 */       return start == length ? -1 : start;
/*  583:     */     }
/*  584:     */     
/*  585:     */     public int lastIndexIn(CharSequence sequence)
/*  586:     */     {
/*  587:1052 */       return sequence.length() - 1;
/*  588:     */     }
/*  589:     */     
/*  590:     */     public boolean matchesAllOf(CharSequence sequence)
/*  591:     */     {
/*  592:1057 */       Preconditions.checkNotNull(sequence);
/*  593:1058 */       return true;
/*  594:     */     }
/*  595:     */     
/*  596:     */     public boolean matchesNoneOf(CharSequence sequence)
/*  597:     */     {
/*  598:1063 */       return sequence.length() == 0;
/*  599:     */     }
/*  600:     */     
/*  601:     */     public String removeFrom(CharSequence sequence)
/*  602:     */     {
/*  603:1068 */       Preconditions.checkNotNull(sequence);
/*  604:1069 */       return "";
/*  605:     */     }
/*  606:     */     
/*  607:     */     public String replaceFrom(CharSequence sequence, char replacement)
/*  608:     */     {
/*  609:1074 */       char[] array = new char[sequence.length()];
/*  610:1075 */       Arrays.fill(array, replacement);
/*  611:1076 */       return new String(array);
/*  612:     */     }
/*  613:     */     
/*  614:     */     public String replaceFrom(CharSequence sequence, CharSequence replacement)
/*  615:     */     {
/*  616:1081 */       StringBuilder result = new StringBuilder(sequence.length() * replacement.length());
/*  617:1082 */       for (int i = 0; i < sequence.length(); i++) {
/*  618:1083 */         result.append(replacement);
/*  619:     */       }
/*  620:1085 */       return result.toString();
/*  621:     */     }
/*  622:     */     
/*  623:     */     public String collapseFrom(CharSequence sequence, char replacement)
/*  624:     */     {
/*  625:1090 */       return sequence.length() == 0 ? "" : String.valueOf(replacement);
/*  626:     */     }
/*  627:     */     
/*  628:     */     public String trimFrom(CharSequence sequence)
/*  629:     */     {
/*  630:1095 */       Preconditions.checkNotNull(sequence);
/*  631:1096 */       return "";
/*  632:     */     }
/*  633:     */     
/*  634:     */     public int countIn(CharSequence sequence)
/*  635:     */     {
/*  636:1101 */       return sequence.length();
/*  637:     */     }
/*  638:     */     
/*  639:     */     public CharMatcher and(CharMatcher other)
/*  640:     */     {
/*  641:1106 */       return (CharMatcher)Preconditions.checkNotNull(other);
/*  642:     */     }
/*  643:     */     
/*  644:     */     public CharMatcher or(CharMatcher other)
/*  645:     */     {
/*  646:1111 */       Preconditions.checkNotNull(other);
/*  647:1112 */       return this;
/*  648:     */     }
/*  649:     */     
/*  650:     */     public CharMatcher negate()
/*  651:     */     {
/*  652:1117 */       return none();
/*  653:     */     }
/*  654:     */   }
/*  655:     */   
/*  656:     */   private static final class None
/*  657:     */     extends CharMatcher.NamedFastMatcher
/*  658:     */   {
/*  659:1124 */     static final None INSTANCE = new None();
/*  660:     */     
/*  661:     */     private None()
/*  662:     */     {
/*  663:1127 */       super();
/*  664:     */     }
/*  665:     */     
/*  666:     */     public boolean matches(char c)
/*  667:     */     {
/*  668:1132 */       return false;
/*  669:     */     }
/*  670:     */     
/*  671:     */     public int indexIn(CharSequence sequence)
/*  672:     */     {
/*  673:1137 */       Preconditions.checkNotNull(sequence);
/*  674:1138 */       return -1;
/*  675:     */     }
/*  676:     */     
/*  677:     */     public int indexIn(CharSequence sequence, int start)
/*  678:     */     {
/*  679:1143 */       int length = sequence.length();
/*  680:1144 */       Preconditions.checkPositionIndex(start, length);
/*  681:1145 */       return -1;
/*  682:     */     }
/*  683:     */     
/*  684:     */     public int lastIndexIn(CharSequence sequence)
/*  685:     */     {
/*  686:1150 */       Preconditions.checkNotNull(sequence);
/*  687:1151 */       return -1;
/*  688:     */     }
/*  689:     */     
/*  690:     */     public boolean matchesAllOf(CharSequence sequence)
/*  691:     */     {
/*  692:1156 */       return sequence.length() == 0;
/*  693:     */     }
/*  694:     */     
/*  695:     */     public boolean matchesNoneOf(CharSequence sequence)
/*  696:     */     {
/*  697:1161 */       Preconditions.checkNotNull(sequence);
/*  698:1162 */       return true;
/*  699:     */     }
/*  700:     */     
/*  701:     */     public String removeFrom(CharSequence sequence)
/*  702:     */     {
/*  703:1167 */       return sequence.toString();
/*  704:     */     }
/*  705:     */     
/*  706:     */     public String replaceFrom(CharSequence sequence, char replacement)
/*  707:     */     {
/*  708:1172 */       return sequence.toString();
/*  709:     */     }
/*  710:     */     
/*  711:     */     public String replaceFrom(CharSequence sequence, CharSequence replacement)
/*  712:     */     {
/*  713:1177 */       Preconditions.checkNotNull(replacement);
/*  714:1178 */       return sequence.toString();
/*  715:     */     }
/*  716:     */     
/*  717:     */     public String collapseFrom(CharSequence sequence, char replacement)
/*  718:     */     {
/*  719:1183 */       return sequence.toString();
/*  720:     */     }
/*  721:     */     
/*  722:     */     public String trimFrom(CharSequence sequence)
/*  723:     */     {
/*  724:1188 */       return sequence.toString();
/*  725:     */     }
/*  726:     */     
/*  727:     */     public String trimLeadingFrom(CharSequence sequence)
/*  728:     */     {
/*  729:1193 */       return sequence.toString();
/*  730:     */     }
/*  731:     */     
/*  732:     */     public String trimTrailingFrom(CharSequence sequence)
/*  733:     */     {
/*  734:1198 */       return sequence.toString();
/*  735:     */     }
/*  736:     */     
/*  737:     */     public int countIn(CharSequence sequence)
/*  738:     */     {
/*  739:1203 */       Preconditions.checkNotNull(sequence);
/*  740:1204 */       return 0;
/*  741:     */     }
/*  742:     */     
/*  743:     */     public CharMatcher and(CharMatcher other)
/*  744:     */     {
/*  745:1209 */       Preconditions.checkNotNull(other);
/*  746:1210 */       return this;
/*  747:     */     }
/*  748:     */     
/*  749:     */     public CharMatcher or(CharMatcher other)
/*  750:     */     {
/*  751:1215 */       return (CharMatcher)Preconditions.checkNotNull(other);
/*  752:     */     }
/*  753:     */     
/*  754:     */     public CharMatcher negate()
/*  755:     */     {
/*  756:1220 */       return any();
/*  757:     */     }
/*  758:     */   }
/*  759:     */   
/*  760:     */   @VisibleForTesting
/*  761:     */   static final class Whitespace
/*  762:     */     extends CharMatcher.NamedFastMatcher
/*  763:     */   {
/*  764:     */     static final String TABLE = " 　\r   　 \013　   　 \t     \f 　 　　 \n 　";
/*  765:     */     static final int MULTIPLIER = 1682554634;
/*  766:1234 */     static final int SHIFT = Integer.numberOfLeadingZeros(" 　\r   　 \013　   　 \t     \f 　 　　 \n 　".length() - 1);
/*  767:1236 */     static final Whitespace INSTANCE = new Whitespace();
/*  768:     */     
/*  769:     */     Whitespace()
/*  770:     */     {
/*  771:1239 */       super();
/*  772:     */     }
/*  773:     */     
/*  774:     */     public boolean matches(char c)
/*  775:     */     {
/*  776:1244 */       return " 　\r   　 \013　   　 \t     \f 　 　　 \n 　".charAt(1682554634 * c >>> SHIFT) == c;
/*  777:     */     }
/*  778:     */     
/*  779:     */     @GwtIncompatible("java.util.BitSet")
/*  780:     */     void setBits(BitSet table)
/*  781:     */     {
/*  782:1250 */       for (int i = 0; i < " 　\r   　 \013　   　 \t     \f 　 　　 \n 　".length(); i++) {
/*  783:1251 */         table.set(" 　\r   　 \013　   　 \t     \f 　 　　 \n 　".charAt(i));
/*  784:     */       }
/*  785:     */     }
/*  786:     */   }
/*  787:     */   
/*  788:     */   private static final class BreakingWhitespace
/*  789:     */     extends CharMatcher
/*  790:     */   {
/*  791:1259 */     static final CharMatcher INSTANCE = new BreakingWhitespace();
/*  792:     */     
/*  793:     */     public boolean matches(char c)
/*  794:     */     {
/*  795:1263 */       switch (c)
/*  796:     */       {
/*  797:     */       case '\t': 
/*  798:     */       case '\n': 
/*  799:     */       case '\013': 
/*  800:     */       case '\f': 
/*  801:     */       case '\r': 
/*  802:     */       case ' ': 
/*  803:     */       case '': 
/*  804:     */       case ' ': 
/*  805:     */       case ' ': 
/*  806:     */       case ' ': 
/*  807:     */       case ' ': 
/*  808:     */       case '　': 
/*  809:1276 */         return true;
/*  810:     */       case ' ': 
/*  811:1278 */         return false;
/*  812:     */       }
/*  813:1280 */       return (c >= ' ') && (c <= ' ');
/*  814:     */     }
/*  815:     */     
/*  816:     */     public String toString()
/*  817:     */     {
/*  818:1286 */       return "CharMatcher.breakingWhitespace()";
/*  819:     */     }
/*  820:     */   }
/*  821:     */   
/*  822:     */   private static final class Ascii
/*  823:     */     extends CharMatcher.NamedFastMatcher
/*  824:     */   {
/*  825:1293 */     static final Ascii INSTANCE = new Ascii();
/*  826:     */     
/*  827:     */     Ascii()
/*  828:     */     {
/*  829:1296 */       super();
/*  830:     */     }
/*  831:     */     
/*  832:     */     public boolean matches(char c)
/*  833:     */     {
/*  834:1301 */       return c <= '';
/*  835:     */     }
/*  836:     */   }
/*  837:     */   
/*  838:     */   private static class RangesMatcher
/*  839:     */     extends CharMatcher
/*  840:     */   {
/*  841:     */     private final String description;
/*  842:     */     private final char[] rangeStarts;
/*  843:     */     private final char[] rangeEnds;
/*  844:     */     
/*  845:     */     RangesMatcher(String description, char[] rangeStarts, char[] rangeEnds)
/*  846:     */     {
/*  847:1313 */       this.description = description;
/*  848:1314 */       this.rangeStarts = rangeStarts;
/*  849:1315 */       this.rangeEnds = rangeEnds;
/*  850:1316 */       Preconditions.checkArgument(rangeStarts.length == rangeEnds.length);
/*  851:1317 */       for (int i = 0; i < rangeStarts.length; i++)
/*  852:     */       {
/*  853:1318 */         Preconditions.checkArgument(rangeStarts[i] <= rangeEnds[i]);
/*  854:1319 */         if (i + 1 < rangeStarts.length) {
/*  855:1320 */           Preconditions.checkArgument(rangeEnds[i] < rangeStarts[(i + 1)]);
/*  856:     */         }
/*  857:     */       }
/*  858:     */     }
/*  859:     */     
/*  860:     */     public boolean matches(char c)
/*  861:     */     {
/*  862:1327 */       int index = Arrays.binarySearch(this.rangeStarts, c);
/*  863:1328 */       if (index >= 0) {
/*  864:1329 */         return true;
/*  865:     */       }
/*  866:1331 */       index = (index ^ 0xFFFFFFFF) - 1;
/*  867:1332 */       return (index >= 0) && (c <= this.rangeEnds[index]);
/*  868:     */     }
/*  869:     */     
/*  870:     */     public String toString()
/*  871:     */     {
/*  872:1338 */       return this.description;
/*  873:     */     }
/*  874:     */   }
/*  875:     */   
/*  876:     */   private static final class Digit
/*  877:     */     extends CharMatcher.RangesMatcher
/*  878:     */   {
/*  879:     */     private static final String ZEROES = "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０";
/*  880:     */     
/*  881:     */     private static char[] zeroes()
/*  882:     */     {
/*  883:1352 */       return "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".toCharArray();
/*  884:     */     }
/*  885:     */     
/*  886:     */     private static char[] nines()
/*  887:     */     {
/*  888:1356 */       char[] nines = new char["0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".length()];
/*  889:1357 */       for (int i = 0; i < "0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".length(); i++) {
/*  890:1358 */         nines[i] = ((char)("0٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".charAt(i) + '\t'));
/*  891:     */       }
/*  892:1360 */       return nines;
/*  893:     */     }
/*  894:     */     
/*  895:1363 */     static final Digit INSTANCE = new Digit();
/*  896:     */     
/*  897:     */     private Digit()
/*  898:     */     {
/*  899:1366 */       super(zeroes(), nines());
/*  900:     */     }
/*  901:     */   }
/*  902:     */   
/*  903:     */   private static final class JavaDigit
/*  904:     */     extends CharMatcher
/*  905:     */   {
/*  906:1373 */     static final JavaDigit INSTANCE = new JavaDigit();
/*  907:     */     
/*  908:     */     public boolean matches(char c)
/*  909:     */     {
/*  910:1377 */       return Character.isDigit(c);
/*  911:     */     }
/*  912:     */     
/*  913:     */     public String toString()
/*  914:     */     {
/*  915:1382 */       return "CharMatcher.javaDigit()";
/*  916:     */     }
/*  917:     */   }
/*  918:     */   
/*  919:     */   private static final class JavaLetter
/*  920:     */     extends CharMatcher
/*  921:     */   {
/*  922:1389 */     static final JavaLetter INSTANCE = new JavaLetter();
/*  923:     */     
/*  924:     */     public boolean matches(char c)
/*  925:     */     {
/*  926:1393 */       return Character.isLetter(c);
/*  927:     */     }
/*  928:     */     
/*  929:     */     public String toString()
/*  930:     */     {
/*  931:1398 */       return "CharMatcher.javaLetter()";
/*  932:     */     }
/*  933:     */   }
/*  934:     */   
/*  935:     */   private static final class JavaLetterOrDigit
/*  936:     */     extends CharMatcher
/*  937:     */   {
/*  938:1405 */     static final JavaLetterOrDigit INSTANCE = new JavaLetterOrDigit();
/*  939:     */     
/*  940:     */     public boolean matches(char c)
/*  941:     */     {
/*  942:1409 */       return Character.isLetterOrDigit(c);
/*  943:     */     }
/*  944:     */     
/*  945:     */     public String toString()
/*  946:     */     {
/*  947:1414 */       return "CharMatcher.javaLetterOrDigit()";
/*  948:     */     }
/*  949:     */   }
/*  950:     */   
/*  951:     */   private static final class JavaUpperCase
/*  952:     */     extends CharMatcher
/*  953:     */   {
/*  954:1421 */     static final JavaUpperCase INSTANCE = new JavaUpperCase();
/*  955:     */     
/*  956:     */     public boolean matches(char c)
/*  957:     */     {
/*  958:1425 */       return Character.isUpperCase(c);
/*  959:     */     }
/*  960:     */     
/*  961:     */     public String toString()
/*  962:     */     {
/*  963:1430 */       return "CharMatcher.javaUpperCase()";
/*  964:     */     }
/*  965:     */   }
/*  966:     */   
/*  967:     */   private static final class JavaLowerCase
/*  968:     */     extends CharMatcher
/*  969:     */   {
/*  970:1437 */     static final JavaLowerCase INSTANCE = new JavaLowerCase();
/*  971:     */     
/*  972:     */     public boolean matches(char c)
/*  973:     */     {
/*  974:1441 */       return Character.isLowerCase(c);
/*  975:     */     }
/*  976:     */     
/*  977:     */     public String toString()
/*  978:     */     {
/*  979:1446 */       return "CharMatcher.javaLowerCase()";
/*  980:     */     }
/*  981:     */   }
/*  982:     */   
/*  983:     */   private static final class JavaIsoControl
/*  984:     */     extends CharMatcher.NamedFastMatcher
/*  985:     */   {
/*  986:1453 */     static final JavaIsoControl INSTANCE = new JavaIsoControl();
/*  987:     */     
/*  988:     */     private JavaIsoControl()
/*  989:     */     {
/*  990:1456 */       super();
/*  991:     */     }
/*  992:     */     
/*  993:     */     public boolean matches(char c)
/*  994:     */     {
/*  995:1461 */       return (c <= '\037') || ((c >= '') && (c <= ''));
/*  996:     */     }
/*  997:     */   }
/*  998:     */   
/*  999:     */   private static final class Invisible
/* 1000:     */     extends CharMatcher.RangesMatcher
/* 1001:     */   {
/* 1002:     */     private static final String RANGE_STARTS = "";
/* 1003:     */     private static final String RANGE_ENDS = "  ­؄؜۝܏ ᠎‏ ⁤⁦⁧⁨⁩⁯　﻿￹￻";
/* 1004:1475 */     static final Invisible INSTANCE = new Invisible();
/* 1005:     */     
/* 1006:     */     private Invisible()
/* 1007:     */     {
/* 1008:1478 */       super("".toCharArray(), "  ­؄؜۝܏ ᠎‏ ⁤⁦⁧⁨⁩⁯　﻿￹￻".toCharArray());
/* 1009:     */     }
/* 1010:     */   }
/* 1011:     */   
/* 1012:     */   private static final class SingleWidth
/* 1013:     */     extends CharMatcher.RangesMatcher
/* 1014:     */   {
/* 1015:1488 */     static final SingleWidth INSTANCE = new SingleWidth();
/* 1016:     */     
/* 1017:     */     private SingleWidth()
/* 1018:     */     {
/* 1019:1491 */       super("".toCharArray(), "ӹ־ת״ۿݿ๿₯℺﷿﻿ￜ".toCharArray());
/* 1020:     */     }
/* 1021:     */   }
/* 1022:     */   
/* 1023:     */   private static class Negated
/* 1024:     */     extends CharMatcher
/* 1025:     */   {
/* 1026:     */     final CharMatcher original;
/* 1027:     */     
/* 1028:     */     Negated(CharMatcher original)
/* 1029:     */     {
/* 1030:1506 */       this.original = ((CharMatcher)Preconditions.checkNotNull(original));
/* 1031:     */     }
/* 1032:     */     
/* 1033:     */     public boolean matches(char c)
/* 1034:     */     {
/* 1035:1511 */       return !this.original.matches(c);
/* 1036:     */     }
/* 1037:     */     
/* 1038:     */     public boolean matchesAllOf(CharSequence sequence)
/* 1039:     */     {
/* 1040:1516 */       return this.original.matchesNoneOf(sequence);
/* 1041:     */     }
/* 1042:     */     
/* 1043:     */     public boolean matchesNoneOf(CharSequence sequence)
/* 1044:     */     {
/* 1045:1521 */       return this.original.matchesAllOf(sequence);
/* 1046:     */     }
/* 1047:     */     
/* 1048:     */     public int countIn(CharSequence sequence)
/* 1049:     */     {
/* 1050:1526 */       return sequence.length() - this.original.countIn(sequence);
/* 1051:     */     }
/* 1052:     */     
/* 1053:     */     @GwtIncompatible("java.util.BitSet")
/* 1054:     */     void setBits(BitSet table)
/* 1055:     */     {
/* 1056:1532 */       BitSet tmp = new BitSet();
/* 1057:1533 */       this.original.setBits(tmp);
/* 1058:1534 */       tmp.flip(0, 65536);
/* 1059:1535 */       table.or(tmp);
/* 1060:     */     }
/* 1061:     */     
/* 1062:     */     public CharMatcher negate()
/* 1063:     */     {
/* 1064:1540 */       return this.original;
/* 1065:     */     }
/* 1066:     */     
/* 1067:     */     public String toString()
/* 1068:     */     {
/* 1069:1545 */       return this.original + ".negate()";
/* 1070:     */     }
/* 1071:     */   }
/* 1072:     */   
/* 1073:     */   private static final class And
/* 1074:     */     extends CharMatcher
/* 1075:     */   {
/* 1076:     */     final CharMatcher first;
/* 1077:     */     final CharMatcher second;
/* 1078:     */     
/* 1079:     */     And(CharMatcher a, CharMatcher b)
/* 1080:     */     {
/* 1081:1556 */       this.first = ((CharMatcher)Preconditions.checkNotNull(a));
/* 1082:1557 */       this.second = ((CharMatcher)Preconditions.checkNotNull(b));
/* 1083:     */     }
/* 1084:     */     
/* 1085:     */     public boolean matches(char c)
/* 1086:     */     {
/* 1087:1562 */       return (this.first.matches(c)) && (this.second.matches(c));
/* 1088:     */     }
/* 1089:     */     
/* 1090:     */     @GwtIncompatible("java.util.BitSet")
/* 1091:     */     void setBits(BitSet table)
/* 1092:     */     {
/* 1093:1568 */       BitSet tmp1 = new BitSet();
/* 1094:1569 */       this.first.setBits(tmp1);
/* 1095:1570 */       BitSet tmp2 = new BitSet();
/* 1096:1571 */       this.second.setBits(tmp2);
/* 1097:1572 */       tmp1.and(tmp2);
/* 1098:1573 */       table.or(tmp1);
/* 1099:     */     }
/* 1100:     */     
/* 1101:     */     public String toString()
/* 1102:     */     {
/* 1103:1578 */       return "CharMatcher.and(" + this.first + ", " + this.second + ")";
/* 1104:     */     }
/* 1105:     */   }
/* 1106:     */   
/* 1107:     */   private static final class Or
/* 1108:     */     extends CharMatcher
/* 1109:     */   {
/* 1110:     */     final CharMatcher first;
/* 1111:     */     final CharMatcher second;
/* 1112:     */     
/* 1113:     */     Or(CharMatcher a, CharMatcher b)
/* 1114:     */     {
/* 1115:1589 */       this.first = ((CharMatcher)Preconditions.checkNotNull(a));
/* 1116:1590 */       this.second = ((CharMatcher)Preconditions.checkNotNull(b));
/* 1117:     */     }
/* 1118:     */     
/* 1119:     */     @GwtIncompatible("java.util.BitSet")
/* 1120:     */     void setBits(BitSet table)
/* 1121:     */     {
/* 1122:1596 */       this.first.setBits(table);
/* 1123:1597 */       this.second.setBits(table);
/* 1124:     */     }
/* 1125:     */     
/* 1126:     */     public boolean matches(char c)
/* 1127:     */     {
/* 1128:1602 */       return (this.first.matches(c)) || (this.second.matches(c));
/* 1129:     */     }
/* 1130:     */     
/* 1131:     */     public String toString()
/* 1132:     */     {
/* 1133:1607 */       return "CharMatcher.or(" + this.first + ", " + this.second + ")";
/* 1134:     */     }
/* 1135:     */   }
/* 1136:     */   
/* 1137:     */   private static final class Is
/* 1138:     */     extends CharMatcher.FastMatcher
/* 1139:     */   {
/* 1140:     */     private final char match;
/* 1141:     */     
/* 1142:     */     Is(char match)
/* 1143:     */     {
/* 1144:1619 */       this.match = match;
/* 1145:     */     }
/* 1146:     */     
/* 1147:     */     public boolean matches(char c)
/* 1148:     */     {
/* 1149:1624 */       return c == this.match;
/* 1150:     */     }
/* 1151:     */     
/* 1152:     */     public String replaceFrom(CharSequence sequence, char replacement)
/* 1153:     */     {
/* 1154:1629 */       return sequence.toString().replace(this.match, replacement);
/* 1155:     */     }
/* 1156:     */     
/* 1157:     */     public CharMatcher and(CharMatcher other)
/* 1158:     */     {
/* 1159:1634 */       return other.matches(this.match) ? this : none();
/* 1160:     */     }
/* 1161:     */     
/* 1162:     */     public CharMatcher or(CharMatcher other)
/* 1163:     */     {
/* 1164:1639 */       return other.matches(this.match) ? other : super.or(other);
/* 1165:     */     }
/* 1166:     */     
/* 1167:     */     public CharMatcher negate()
/* 1168:     */     {
/* 1169:1644 */       return isNot(this.match);
/* 1170:     */     }
/* 1171:     */     
/* 1172:     */     @GwtIncompatible("java.util.BitSet")
/* 1173:     */     void setBits(BitSet table)
/* 1174:     */     {
/* 1175:1650 */       table.set(this.match);
/* 1176:     */     }
/* 1177:     */     
/* 1178:     */     public String toString()
/* 1179:     */     {
/* 1180:1655 */       return "CharMatcher.is('" + CharMatcher.showCharacter(this.match) + "')";
/* 1181:     */     }
/* 1182:     */   }
/* 1183:     */   
/* 1184:     */   private static final class IsNot
/* 1185:     */     extends CharMatcher.FastMatcher
/* 1186:     */   {
/* 1187:     */     private final char match;
/* 1188:     */     
/* 1189:     */     IsNot(char match)
/* 1190:     */     {
/* 1191:1665 */       this.match = match;
/* 1192:     */     }
/* 1193:     */     
/* 1194:     */     public boolean matches(char c)
/* 1195:     */     {
/* 1196:1670 */       return c != this.match;
/* 1197:     */     }
/* 1198:     */     
/* 1199:     */     public CharMatcher and(CharMatcher other)
/* 1200:     */     {
/* 1201:1675 */       return other.matches(this.match) ? super.and(other) : other;
/* 1202:     */     }
/* 1203:     */     
/* 1204:     */     public CharMatcher or(CharMatcher other)
/* 1205:     */     {
/* 1206:1680 */       return other.matches(this.match) ? any() : this;
/* 1207:     */     }
/* 1208:     */     
/* 1209:     */     @GwtIncompatible("java.util.BitSet")
/* 1210:     */     void setBits(BitSet table)
/* 1211:     */     {
/* 1212:1686 */       table.set(0, this.match);
/* 1213:1687 */       table.set(this.match + '\001', 65536);
/* 1214:     */     }
/* 1215:     */     
/* 1216:     */     public CharMatcher negate()
/* 1217:     */     {
/* 1218:1692 */       return is(this.match);
/* 1219:     */     }
/* 1220:     */     
/* 1221:     */     public String toString()
/* 1222:     */     {
/* 1223:1697 */       return "CharMatcher.isNot('" + CharMatcher.showCharacter(this.match) + "')";
/* 1224:     */     }
/* 1225:     */   }
/* 1226:     */   
/* 1227:     */   private static IsEither isEither(char c1, char c2)
/* 1228:     */   {
/* 1229:1702 */     return new IsEither(c1, c2);
/* 1230:     */   }
/* 1231:     */   
/* 1232:     */   private static final class IsEither
/* 1233:     */     extends CharMatcher.FastMatcher
/* 1234:     */   {
/* 1235:     */     private final char match1;
/* 1236:     */     private final char match2;
/* 1237:     */     
/* 1238:     */     IsEither(char match1, char match2)
/* 1239:     */     {
/* 1240:1712 */       this.match1 = match1;
/* 1241:1713 */       this.match2 = match2;
/* 1242:     */     }
/* 1243:     */     
/* 1244:     */     public boolean matches(char c)
/* 1245:     */     {
/* 1246:1718 */       return (c == this.match1) || (c == this.match2);
/* 1247:     */     }
/* 1248:     */     
/* 1249:     */     @GwtIncompatible("java.util.BitSet")
/* 1250:     */     void setBits(BitSet table)
/* 1251:     */     {
/* 1252:1724 */       table.set(this.match1);
/* 1253:1725 */       table.set(this.match2);
/* 1254:     */     }
/* 1255:     */     
/* 1256:     */     public String toString()
/* 1257:     */     {
/* 1258:1730 */       return "CharMatcher.anyOf(\"" + CharMatcher.showCharacter(this.match1) + CharMatcher.showCharacter(this.match2) + "\")";
/* 1259:     */     }
/* 1260:     */   }
/* 1261:     */   
/* 1262:     */   private static final class AnyOf
/* 1263:     */     extends CharMatcher
/* 1264:     */   {
/* 1265:     */     private final char[] chars;
/* 1266:     */     
/* 1267:     */     public AnyOf(CharSequence chars)
/* 1268:     */     {
/* 1269:1740 */       this.chars = chars.toString().toCharArray();
/* 1270:1741 */       Arrays.sort(this.chars);
/* 1271:     */     }
/* 1272:     */     
/* 1273:     */     public boolean matches(char c)
/* 1274:     */     {
/* 1275:1746 */       return Arrays.binarySearch(this.chars, c) >= 0;
/* 1276:     */     }
/* 1277:     */     
/* 1278:     */     @GwtIncompatible("java.util.BitSet")
/* 1279:     */     void setBits(BitSet table)
/* 1280:     */     {
/* 1281:1752 */       for (char c : this.chars) {
/* 1282:1753 */         table.set(c);
/* 1283:     */       }
/* 1284:     */     }
/* 1285:     */     
/* 1286:     */     public String toString()
/* 1287:     */     {
/* 1288:1759 */       StringBuilder description = new StringBuilder("CharMatcher.anyOf(\"");
/* 1289:1760 */       for (char c : this.chars) {
/* 1290:1761 */         description.append(CharMatcher.showCharacter(c));
/* 1291:     */       }
/* 1292:1763 */       description.append("\")");
/* 1293:1764 */       return description.toString();
/* 1294:     */     }
/* 1295:     */   }
/* 1296:     */   
/* 1297:     */   private static final class InRange
/* 1298:     */     extends CharMatcher.FastMatcher
/* 1299:     */   {
/* 1300:     */     private final char startInclusive;
/* 1301:     */     private final char endInclusive;
/* 1302:     */     
/* 1303:     */     InRange(char startInclusive, char endInclusive)
/* 1304:     */     {
/* 1305:1775 */       Preconditions.checkArgument(endInclusive >= startInclusive);
/* 1306:1776 */       this.startInclusive = startInclusive;
/* 1307:1777 */       this.endInclusive = endInclusive;
/* 1308:     */     }
/* 1309:     */     
/* 1310:     */     public boolean matches(char c)
/* 1311:     */     {
/* 1312:1782 */       return (this.startInclusive <= c) && (c <= this.endInclusive);
/* 1313:     */     }
/* 1314:     */     
/* 1315:     */     @GwtIncompatible("java.util.BitSet")
/* 1316:     */     void setBits(BitSet table)
/* 1317:     */     {
/* 1318:1788 */       table.set(this.startInclusive, this.endInclusive + '\001');
/* 1319:     */     }
/* 1320:     */     
/* 1321:     */     public String toString()
/* 1322:     */     {
/* 1323:1793 */       return "CharMatcher.inRange('" + CharMatcher.showCharacter(this.startInclusive) + "', '" + CharMatcher.showCharacter(this.endInclusive) + "')";
/* 1324:     */     }
/* 1325:     */   }
/* 1326:     */   
/* 1327:     */   private static final class ForPredicate
/* 1328:     */     extends CharMatcher
/* 1329:     */   {
/* 1330:     */     private final Predicate<? super Character> predicate;
/* 1331:     */     
/* 1332:     */     ForPredicate(Predicate<? super Character> predicate)
/* 1333:     */     {
/* 1334:1807 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/* 1335:     */     }
/* 1336:     */     
/* 1337:     */     public boolean matches(char c)
/* 1338:     */     {
/* 1339:1812 */       return this.predicate.apply(Character.valueOf(c));
/* 1340:     */     }
/* 1341:     */     
/* 1342:     */     public boolean apply(Character character)
/* 1343:     */     {
/* 1344:1818 */       return this.predicate.apply(Preconditions.checkNotNull(character));
/* 1345:     */     }
/* 1346:     */     
/* 1347:     */     public String toString()
/* 1348:     */     {
/* 1349:1823 */       return "CharMatcher.forPredicate(" + this.predicate + ")";
/* 1350:     */     }
/* 1351:     */   }
/* 1352:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.CharMatcher
 * JD-Core Version:    0.7.0.1
 */