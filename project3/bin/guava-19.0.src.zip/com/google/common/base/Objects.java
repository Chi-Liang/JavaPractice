/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import javax.annotation.CheckReturnValue;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible
/*   9:    */ public final class Objects
/*  10:    */ {
/*  11:    */   @CheckReturnValue
/*  12:    */   public static boolean equal(@Nullable Object a, @Nullable Object b)
/*  13:    */   {
/*  14: 60 */     return (a == b) || ((a != null) && (a.equals(b)));
/*  15:    */   }
/*  16:    */   
/*  17:    */   @CheckReturnValue
/*  18:    */   public static int hashCode(@Nullable Object... objects)
/*  19:    */   {
/*  20: 85 */     return Arrays.hashCode(objects);
/*  21:    */   }
/*  22:    */   
/*  23:    */   @CheckReturnValue
/*  24:    */   @Deprecated
/*  25:    */   public static ToStringHelper toStringHelper(Object self)
/*  26:    */   {
/*  27:132 */     return new ToStringHelper(self.getClass().getSimpleName(), null);
/*  28:    */   }
/*  29:    */   
/*  30:    */   @CheckReturnValue
/*  31:    */   @Deprecated
/*  32:    */   public static ToStringHelper toStringHelper(Class<?> clazz)
/*  33:    */   {
/*  34:150 */     return new ToStringHelper(clazz.getSimpleName(), null);
/*  35:    */   }
/*  36:    */   
/*  37:    */   @CheckReturnValue
/*  38:    */   @Deprecated
/*  39:    */   public static ToStringHelper toStringHelper(String className)
/*  40:    */   {
/*  41:166 */     return new ToStringHelper(className, null);
/*  42:    */   }
/*  43:    */   
/*  44:    */   @CheckReturnValue
/*  45:    */   @Deprecated
/*  46:    */   public static <T> T firstNonNull(@Nullable T first, @Nullable T second)
/*  47:    */   {
/*  48:191 */     return MoreObjects.firstNonNull(first, second);
/*  49:    */   }
/*  50:    */   
/*  51:    */   @Deprecated
/*  52:    */   public static final class ToStringHelper
/*  53:    */   {
/*  54:    */     private final String className;
/*  55:205 */     private ValueHolder holderHead = new ValueHolder(null);
/*  56:206 */     private ValueHolder holderTail = this.holderHead;
/*  57:207 */     private boolean omitNullValues = false;
/*  58:    */     
/*  59:    */     private ToStringHelper(String className)
/*  60:    */     {
/*  61:213 */       this.className = ((String)Preconditions.checkNotNull(className));
/*  62:    */     }
/*  63:    */     
/*  64:    */     public ToStringHelper omitNullValues()
/*  65:    */     {
/*  66:224 */       this.omitNullValues = true;
/*  67:225 */       return this;
/*  68:    */     }
/*  69:    */     
/*  70:    */     public ToStringHelper add(String name, @Nullable Object value)
/*  71:    */     {
/*  72:235 */       return addHolder(name, value);
/*  73:    */     }
/*  74:    */     
/*  75:    */     public ToStringHelper add(String name, boolean value)
/*  76:    */     {
/*  77:245 */       return addHolder(name, String.valueOf(value));
/*  78:    */     }
/*  79:    */     
/*  80:    */     public ToStringHelper add(String name, char value)
/*  81:    */     {
/*  82:255 */       return addHolder(name, String.valueOf(value));
/*  83:    */     }
/*  84:    */     
/*  85:    */     public ToStringHelper add(String name, double value)
/*  86:    */     {
/*  87:265 */       return addHolder(name, String.valueOf(value));
/*  88:    */     }
/*  89:    */     
/*  90:    */     public ToStringHelper add(String name, float value)
/*  91:    */     {
/*  92:275 */       return addHolder(name, String.valueOf(value));
/*  93:    */     }
/*  94:    */     
/*  95:    */     public ToStringHelper add(String name, int value)
/*  96:    */     {
/*  97:285 */       return addHolder(name, String.valueOf(value));
/*  98:    */     }
/*  99:    */     
/* 100:    */     public ToStringHelper add(String name, long value)
/* 101:    */     {
/* 102:295 */       return addHolder(name, String.valueOf(value));
/* 103:    */     }
/* 104:    */     
/* 105:    */     public ToStringHelper addValue(@Nullable Object value)
/* 106:    */     {
/* 107:305 */       return addHolder(value);
/* 108:    */     }
/* 109:    */     
/* 110:    */     public ToStringHelper addValue(boolean value)
/* 111:    */     {
/* 112:317 */       return addHolder(String.valueOf(value));
/* 113:    */     }
/* 114:    */     
/* 115:    */     public ToStringHelper addValue(char value)
/* 116:    */     {
/* 117:329 */       return addHolder(String.valueOf(value));
/* 118:    */     }
/* 119:    */     
/* 120:    */     public ToStringHelper addValue(double value)
/* 121:    */     {
/* 122:341 */       return addHolder(String.valueOf(value));
/* 123:    */     }
/* 124:    */     
/* 125:    */     public ToStringHelper addValue(float value)
/* 126:    */     {
/* 127:353 */       return addHolder(String.valueOf(value));
/* 128:    */     }
/* 129:    */     
/* 130:    */     public ToStringHelper addValue(int value)
/* 131:    */     {
/* 132:365 */       return addHolder(String.valueOf(value));
/* 133:    */     }
/* 134:    */     
/* 135:    */     public ToStringHelper addValue(long value)
/* 136:    */     {
/* 137:377 */       return addHolder(String.valueOf(value));
/* 138:    */     }
/* 139:    */     
/* 140:    */     public String toString()
/* 141:    */     {
/* 142:393 */       boolean omitNullValuesSnapshot = this.omitNullValues;
/* 143:394 */       String nextSeparator = "";
/* 144:395 */       StringBuilder builder = new StringBuilder(32).append(this.className).append('{');
/* 145:396 */       for (ValueHolder valueHolder = this.holderHead.next; valueHolder != null; valueHolder = valueHolder.next) {
/* 146:399 */         if ((!omitNullValuesSnapshot) || (valueHolder.value != null))
/* 147:    */         {
/* 148:400 */           builder.append(nextSeparator);
/* 149:401 */           nextSeparator = ", ";
/* 150:403 */           if (valueHolder.name != null) {
/* 151:404 */             builder.append(valueHolder.name).append('=');
/* 152:    */           }
/* 153:406 */           builder.append(valueHolder.value);
/* 154:    */         }
/* 155:    */       }
/* 156:409 */       return '}';
/* 157:    */     }
/* 158:    */     
/* 159:    */     private ValueHolder addHolder()
/* 160:    */     {
/* 161:413 */       ValueHolder valueHolder = new ValueHolder(null);
/* 162:414 */       this.holderTail = (this.holderTail.next = valueHolder);
/* 163:415 */       return valueHolder;
/* 164:    */     }
/* 165:    */     
/* 166:    */     private ToStringHelper addHolder(@Nullable Object value)
/* 167:    */     {
/* 168:419 */       ValueHolder valueHolder = addHolder();
/* 169:420 */       valueHolder.value = value;
/* 170:421 */       return this;
/* 171:    */     }
/* 172:    */     
/* 173:    */     private ToStringHelper addHolder(String name, @Nullable Object value)
/* 174:    */     {
/* 175:425 */       ValueHolder valueHolder = addHolder();
/* 176:426 */       valueHolder.value = value;
/* 177:427 */       valueHolder.name = ((String)Preconditions.checkNotNull(name));
/* 178:428 */       return this;
/* 179:    */     }
/* 180:    */     
/* 181:    */     private static final class ValueHolder
/* 182:    */     {
/* 183:    */       String name;
/* 184:    */       Object value;
/* 185:    */       ValueHolder next;
/* 186:    */     }
/* 187:    */   }
/* 188:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Objects
 * JD-Core Version:    0.7.0.1
 */