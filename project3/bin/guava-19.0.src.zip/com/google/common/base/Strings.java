/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import javax.annotation.CheckReturnValue;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @CheckReturnValue
/*   9:    */ @GwtCompatible
/*  10:    */ public final class Strings
/*  11:    */ {
/*  12:    */   public static String nullToEmpty(@Nullable String string)
/*  13:    */   {
/*  14: 49 */     return string == null ? "" : string;
/*  15:    */   }
/*  16:    */   
/*  17:    */   @Nullable
/*  18:    */   public static String emptyToNull(@Nullable String string)
/*  19:    */   {
/*  20: 61 */     return isNullOrEmpty(string) ? null : string;
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static boolean isNullOrEmpty(@Nullable String string)
/*  24:    */   {
/*  25: 78 */     return (string == null) || (string.length() == 0);
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static String padStart(String string, int minLength, char padChar)
/*  29:    */   {
/*  30:101 */     Preconditions.checkNotNull(string);
/*  31:102 */     if (string.length() >= minLength) {
/*  32:103 */       return string;
/*  33:    */     }
/*  34:105 */     StringBuilder sb = new StringBuilder(minLength);
/*  35:106 */     for (int i = string.length(); i < minLength; i++) {
/*  36:107 */       sb.append(padChar);
/*  37:    */     }
/*  38:109 */     sb.append(string);
/*  39:110 */     return sb.toString();
/*  40:    */   }
/*  41:    */   
/*  42:    */   public static String padEnd(String string, int minLength, char padChar)
/*  43:    */   {
/*  44:133 */     Preconditions.checkNotNull(string);
/*  45:134 */     if (string.length() >= minLength) {
/*  46:135 */       return string;
/*  47:    */     }
/*  48:137 */     StringBuilder sb = new StringBuilder(minLength);
/*  49:138 */     sb.append(string);
/*  50:139 */     for (int i = string.length(); i < minLength; i++) {
/*  51:140 */       sb.append(padChar);
/*  52:    */     }
/*  53:142 */     return sb.toString();
/*  54:    */   }
/*  55:    */   
/*  56:    */   public static String repeat(String string, int count)
/*  57:    */   {
/*  58:157 */     Preconditions.checkNotNull(string);
/*  59:159 */     if (count <= 1)
/*  60:    */     {
/*  61:160 */       Preconditions.checkArgument(count >= 0, "invalid count: %s", new Object[] { Integer.valueOf(count) });
/*  62:161 */       return count == 0 ? "" : string;
/*  63:    */     }
/*  64:165 */     int len = string.length();
/*  65:166 */     long longSize = len * count;
/*  66:167 */     int size = (int)longSize;
/*  67:168 */     if (size != longSize) {
/*  68:169 */       throw new ArrayIndexOutOfBoundsException("Required array size too large: " + longSize);
/*  69:    */     }
/*  70:172 */     char[] array = new char[size];
/*  71:173 */     string.getChars(0, len, array, 0);
/*  72:175 */     for (int n = len; n < size - n; n <<= 1) {
/*  73:176 */       System.arraycopy(array, 0, array, n, n);
/*  74:    */     }
/*  75:178 */     System.arraycopy(array, 0, array, n, size - n);
/*  76:179 */     return new String(array);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static String commonPrefix(CharSequence a, CharSequence b)
/*  80:    */   {
/*  81:191 */     Preconditions.checkNotNull(a);
/*  82:192 */     Preconditions.checkNotNull(b);
/*  83:    */     
/*  84:194 */     int maxPrefixLength = Math.min(a.length(), b.length());
/*  85:195 */     int p = 0;
/*  86:196 */     while ((p < maxPrefixLength) && (a.charAt(p) == b.charAt(p))) {
/*  87:197 */       p++;
/*  88:    */     }
/*  89:199 */     if ((validSurrogatePairAt(a, p - 1)) || (validSurrogatePairAt(b, p - 1))) {
/*  90:200 */       p--;
/*  91:    */     }
/*  92:202 */     return a.subSequence(0, p).toString();
/*  93:    */   }
/*  94:    */   
/*  95:    */   public static String commonSuffix(CharSequence a, CharSequence b)
/*  96:    */   {
/*  97:214 */     Preconditions.checkNotNull(a);
/*  98:215 */     Preconditions.checkNotNull(b);
/*  99:    */     
/* 100:217 */     int maxSuffixLength = Math.min(a.length(), b.length());
/* 101:218 */     int s = 0;
/* 102:219 */     while ((s < maxSuffixLength) && (a.charAt(a.length() - s - 1) == b.charAt(b.length() - s - 1))) {
/* 103:220 */       s++;
/* 104:    */     }
/* 105:222 */     if ((validSurrogatePairAt(a, a.length() - s - 1)) || (validSurrogatePairAt(b, b.length() - s - 1))) {
/* 106:224 */       s--;
/* 107:    */     }
/* 108:226 */     return a.subSequence(a.length() - s, a.length()).toString();
/* 109:    */   }
/* 110:    */   
/* 111:    */   @VisibleForTesting
/* 112:    */   static boolean validSurrogatePairAt(CharSequence string, int index)
/* 113:    */   {
/* 114:235 */     return (index >= 0) && (index <= string.length() - 2) && (Character.isHighSurrogate(string.charAt(index))) && (Character.isLowSurrogate(string.charAt(index + 1)));
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Strings
 * JD-Core Version:    0.7.0.1
 */