/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.io.Serializable;
/*  5:   */ import java.util.Iterator;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @GwtCompatible(serializable=true)
/*  9:   */ final class PairwiseEquivalence<T>
/* 10:   */   extends Equivalence<Iterable<T>>
/* 11:   */   implements Serializable
/* 12:   */ {
/* 13:   */   final Equivalence<? super T> elementEquivalence;
/* 14:   */   private static final long serialVersionUID = 1L;
/* 15:   */   
/* 16:   */   PairwiseEquivalence(Equivalence<? super T> elementEquivalence)
/* 17:   */   {
/* 18:32 */     this.elementEquivalence = ((Equivalence)Preconditions.checkNotNull(elementEquivalence));
/* 19:   */   }
/* 20:   */   
/* 21:   */   protected boolean doEquivalent(Iterable<T> iterableA, Iterable<T> iterableB)
/* 22:   */   {
/* 23:37 */     Iterator<T> iteratorA = iterableA.iterator();
/* 24:38 */     Iterator<T> iteratorB = iterableB.iterator();
/* 25:40 */     while ((iteratorA.hasNext()) && (iteratorB.hasNext())) {
/* 26:41 */       if (!this.elementEquivalence.equivalent(iteratorA.next(), iteratorB.next())) {
/* 27:42 */         return false;
/* 28:   */       }
/* 29:   */     }
/* 30:46 */     return (!iteratorA.hasNext()) && (!iteratorB.hasNext());
/* 31:   */   }
/* 32:   */   
/* 33:   */   protected int doHash(Iterable<T> iterable)
/* 34:   */   {
/* 35:51 */     int hash = 78721;
/* 36:52 */     for (T element : iterable) {
/* 37:53 */       hash = hash * 24943 + this.elementEquivalence.hash(element);
/* 38:   */     }
/* 39:55 */     return hash;
/* 40:   */   }
/* 41:   */   
/* 42:   */   public boolean equals(@Nullable Object object)
/* 43:   */   {
/* 44:60 */     if ((object instanceof PairwiseEquivalence))
/* 45:   */     {
/* 46:61 */       PairwiseEquivalence<?> that = (PairwiseEquivalence)object;
/* 47:62 */       return this.elementEquivalence.equals(that.elementEquivalence);
/* 48:   */     }
/* 49:65 */     return false;
/* 50:   */   }
/* 51:   */   
/* 52:   */   public int hashCode()
/* 53:   */   {
/* 54:70 */     return this.elementEquivalence.hashCode() ^ 0x46A3EB07;
/* 55:   */   }
/* 56:   */   
/* 57:   */   public String toString()
/* 58:   */   {
/* 59:75 */     return this.elementEquivalence + ".pairwise()";
/* 60:   */   }
/* 61:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.PairwiseEquivalence
 * JD-Core Version:    0.7.0.1
 */