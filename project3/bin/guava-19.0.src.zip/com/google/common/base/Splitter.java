/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.util.ArrayList;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.LinkedHashMap;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.regex.Matcher;
/*  13:    */ import java.util.regex.Pattern;
/*  14:    */ import javax.annotation.CheckReturnValue;
/*  15:    */ 
/*  16:    */ @GwtCompatible(emulated=true)
/*  17:    */ public final class Splitter
/*  18:    */ {
/*  19:    */   private final CharMatcher trimmer;
/*  20:    */   private final boolean omitEmptyStrings;
/*  21:    */   private final Strategy strategy;
/*  22:    */   private final int limit;
/*  23:    */   
/*  24:    */   private Splitter(Strategy strategy)
/*  25:    */   {
/*  26:110 */     this(strategy, false, CharMatcher.NONE, 2147483647);
/*  27:    */   }
/*  28:    */   
/*  29:    */   private Splitter(Strategy strategy, boolean omitEmptyStrings, CharMatcher trimmer, int limit)
/*  30:    */   {
/*  31:114 */     this.strategy = strategy;
/*  32:115 */     this.omitEmptyStrings = omitEmptyStrings;
/*  33:116 */     this.trimmer = trimmer;
/*  34:117 */     this.limit = limit;
/*  35:    */   }
/*  36:    */   
/*  37:    */   @CheckReturnValue
/*  38:    */   public static Splitter on(char separator)
/*  39:    */   {
/*  40:130 */     return on(CharMatcher.is(separator));
/*  41:    */   }
/*  42:    */   
/*  43:    */   @CheckReturnValue
/*  44:    */   public static Splitter on(CharMatcher separatorMatcher)
/*  45:    */   {
/*  46:145 */     Preconditions.checkNotNull(separatorMatcher);
/*  47:    */     
/*  48:147 */     new Splitter(new Strategy()
/*  49:    */     {
/*  50:    */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit)
/*  51:    */       {
/*  52:151 */         new Splitter.SplittingIterator(splitter, toSplit)
/*  53:    */         {
/*  54:    */           int separatorStart(int start)
/*  55:    */           {
/*  56:154 */             return Splitter.1.this.val$separatorMatcher.indexIn(this.toSplit, start);
/*  57:    */           }
/*  58:    */           
/*  59:    */           int separatorEnd(int separatorPosition)
/*  60:    */           {
/*  61:159 */             return separatorPosition + 1;
/*  62:    */           }
/*  63:    */         };
/*  64:    */       }
/*  65:    */     });
/*  66:    */   }
/*  67:    */   
/*  68:    */   @CheckReturnValue
/*  69:    */   public static Splitter on(String separator)
/*  70:    */   {
/*  71:176 */     Preconditions.checkArgument(separator.length() != 0, "The separator may not be the empty string.");
/*  72:177 */     if (separator.length() == 1) {
/*  73:178 */       return on(separator.charAt(0));
/*  74:    */     }
/*  75:180 */     new Splitter(new Strategy()
/*  76:    */     {
/*  77:    */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit)
/*  78:    */       {
/*  79:184 */         new Splitter.SplittingIterator(splitter, toSplit)
/*  80:    */         {
/*  81:    */           public int separatorStart(int start)
/*  82:    */           {
/*  83:187 */             int separatorLength = Splitter.2.this.val$separator.length();
/*  84:    */             
/*  85:    */ 
/*  86:190 */             int p = start;
/*  87:    */             label80:
/*  88:190 */             for (int last = this.toSplit.length() - separatorLength; p <= last; p++)
/*  89:    */             {
/*  90:191 */               for (int i = 0; i < separatorLength; i++) {
/*  91:192 */                 if (this.toSplit.charAt(i + p) != Splitter.2.this.val$separator.charAt(i)) {
/*  92:    */                   break label80;
/*  93:    */                 }
/*  94:    */               }
/*  95:196 */               return p;
/*  96:    */             }
/*  97:198 */             return -1;
/*  98:    */           }
/*  99:    */           
/* 100:    */           public int separatorEnd(int separatorPosition)
/* 101:    */           {
/* 102:203 */             return separatorPosition + Splitter.2.this.val$separator.length();
/* 103:    */           }
/* 104:    */         };
/* 105:    */       }
/* 106:    */     });
/* 107:    */   }
/* 108:    */   
/* 109:    */   @CheckReturnValue
/* 110:    */   @GwtIncompatible("java.util.regex")
/* 111:    */   public static Splitter on(Pattern separatorPattern)
/* 112:    */   {
/* 113:225 */     Preconditions.checkNotNull(separatorPattern);
/* 114:226 */     Preconditions.checkArgument(!separatorPattern.matcher("").matches(), "The pattern may not match the empty string: %s", new Object[] { separatorPattern });
/* 115:    */     
/* 116:    */ 
/* 117:    */ 
/* 118:    */ 
/* 119:231 */     new Splitter(new Strategy()
/* 120:    */     {
/* 121:    */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit)
/* 122:    */       {
/* 123:235 */         final Matcher matcher = this.val$separatorPattern.matcher(toSplit);
/* 124:236 */         new Splitter.SplittingIterator(splitter, toSplit)
/* 125:    */         {
/* 126:    */           public int separatorStart(int start)
/* 127:    */           {
/* 128:239 */             return matcher.find(start) ? matcher.start() : -1;
/* 129:    */           }
/* 130:    */           
/* 131:    */           public int separatorEnd(int separatorPosition)
/* 132:    */           {
/* 133:244 */             return matcher.end();
/* 134:    */           }
/* 135:    */         };
/* 136:    */       }
/* 137:    */     });
/* 138:    */   }
/* 139:    */   
/* 140:    */   @CheckReturnValue
/* 141:    */   @GwtIncompatible("java.util.regex")
/* 142:    */   public static Splitter onPattern(String separatorPattern)
/* 143:    */   {
/* 144:269 */     return on(Pattern.compile(separatorPattern));
/* 145:    */   }
/* 146:    */   
/* 147:    */   @CheckReturnValue
/* 148:    */   public static Splitter fixedLength(int length)
/* 149:    */   {
/* 150:293 */     Preconditions.checkArgument(length > 0, "The length may not be less than 1");
/* 151:    */     
/* 152:295 */     new Splitter(new Strategy()
/* 153:    */     {
/* 154:    */       public Splitter.SplittingIterator iterator(Splitter splitter, CharSequence toSplit)
/* 155:    */       {
/* 156:299 */         new Splitter.SplittingIterator(splitter, toSplit)
/* 157:    */         {
/* 158:    */           public int separatorStart(int start)
/* 159:    */           {
/* 160:302 */             int nextChunkStart = start + Splitter.4.this.val$length;
/* 161:303 */             return nextChunkStart < this.toSplit.length() ? nextChunkStart : -1;
/* 162:    */           }
/* 163:    */           
/* 164:    */           public int separatorEnd(int separatorPosition)
/* 165:    */           {
/* 166:308 */             return separatorPosition;
/* 167:    */           }
/* 168:    */         };
/* 169:    */       }
/* 170:    */     });
/* 171:    */   }
/* 172:    */   
/* 173:    */   @CheckReturnValue
/* 174:    */   public Splitter omitEmptyStrings()
/* 175:    */   {
/* 176:335 */     return new Splitter(this.strategy, true, this.trimmer, this.limit);
/* 177:    */   }
/* 178:    */   
/* 179:    */   @CheckReturnValue
/* 180:    */   public Splitter limit(int limit)
/* 181:    */   {
/* 182:360 */     Preconditions.checkArgument(limit > 0, "must be greater than zero: %s", new Object[] { Integer.valueOf(limit) });
/* 183:361 */     return new Splitter(this.strategy, this.omitEmptyStrings, this.trimmer, limit);
/* 184:    */   }
/* 185:    */   
/* 186:    */   @CheckReturnValue
/* 187:    */   public Splitter trimResults()
/* 188:    */   {
/* 189:376 */     return trimResults(CharMatcher.WHITESPACE);
/* 190:    */   }
/* 191:    */   
/* 192:    */   @CheckReturnValue
/* 193:    */   public Splitter trimResults(CharMatcher trimmer)
/* 194:    */   {
/* 195:393 */     Preconditions.checkNotNull(trimmer);
/* 196:394 */     return new Splitter(this.strategy, this.omitEmptyStrings, trimmer, this.limit);
/* 197:    */   }
/* 198:    */   
/* 199:    */   @CheckReturnValue
/* 200:    */   public Iterable<String> split(final CharSequence sequence)
/* 201:    */   {
/* 202:407 */     Preconditions.checkNotNull(sequence);
/* 203:    */     
/* 204:409 */     new Iterable()
/* 205:    */     {
/* 206:    */       public Iterator<String> iterator()
/* 207:    */       {
/* 208:412 */         return Splitter.this.splittingIterator(sequence);
/* 209:    */       }
/* 210:    */       
/* 211:    */       public String toString()
/* 212:    */       {
/* 213:417 */         return ']';
/* 214:    */       }
/* 215:    */     };
/* 216:    */   }
/* 217:    */   
/* 218:    */   private Iterator<String> splittingIterator(CharSequence sequence)
/* 219:    */   {
/* 220:426 */     return this.strategy.iterator(this, sequence);
/* 221:    */   }
/* 222:    */   
/* 223:    */   @CheckReturnValue
/* 224:    */   @Beta
/* 225:    */   public List<String> splitToList(CharSequence sequence)
/* 226:    */   {
/* 227:441 */     Preconditions.checkNotNull(sequence);
/* 228:    */     
/* 229:443 */     Iterator<String> iterator = splittingIterator(sequence);
/* 230:444 */     List<String> result = new ArrayList();
/* 231:446 */     while (iterator.hasNext()) {
/* 232:447 */       result.add(iterator.next());
/* 233:    */     }
/* 234:450 */     return Collections.unmodifiableList(result);
/* 235:    */   }
/* 236:    */   
/* 237:    */   @CheckReturnValue
/* 238:    */   @Beta
/* 239:    */   public MapSplitter withKeyValueSeparator(String separator)
/* 240:    */   {
/* 241:462 */     return withKeyValueSeparator(on(separator));
/* 242:    */   }
/* 243:    */   
/* 244:    */   @CheckReturnValue
/* 245:    */   @Beta
/* 246:    */   public MapSplitter withKeyValueSeparator(char separator)
/* 247:    */   {
/* 248:474 */     return withKeyValueSeparator(on(separator));
/* 249:    */   }
/* 250:    */   
/* 251:    */   @CheckReturnValue
/* 252:    */   @Beta
/* 253:    */   public MapSplitter withKeyValueSeparator(Splitter keyValueSplitter)
/* 254:    */   {
/* 255:487 */     return new MapSplitter(this, keyValueSplitter, null);
/* 256:    */   }
/* 257:    */   
/* 258:    */   @Beta
/* 259:    */   public static final class MapSplitter
/* 260:    */   {
/* 261:    */     private static final String INVALID_ENTRY_MESSAGE = "Chunk [%s] is not a valid entry";
/* 262:    */     private final Splitter outerSplitter;
/* 263:    */     private final Splitter entrySplitter;
/* 264:    */     
/* 265:    */     private MapSplitter(Splitter outerSplitter, Splitter entrySplitter)
/* 266:    */     {
/* 267:504 */       this.outerSplitter = outerSplitter;
/* 268:505 */       this.entrySplitter = ((Splitter)Preconditions.checkNotNull(entrySplitter));
/* 269:    */     }
/* 270:    */     
/* 271:    */     @CheckReturnValue
/* 272:    */     public Map<String, String> split(CharSequence sequence)
/* 273:    */     {
/* 274:525 */       Map<String, String> map = new LinkedHashMap();
/* 275:526 */       for (String entry : this.outerSplitter.split(sequence))
/* 276:    */       {
/* 277:527 */         Iterator<String> entryFields = this.entrySplitter.splittingIterator(entry);
/* 278:    */         
/* 279:529 */         Preconditions.checkArgument(entryFields.hasNext(), "Chunk [%s] is not a valid entry", new Object[] { entry });
/* 280:530 */         String key = (String)entryFields.next();
/* 281:531 */         Preconditions.checkArgument(!map.containsKey(key), "Duplicate key [%s] found.", new Object[] { key });
/* 282:    */         
/* 283:533 */         Preconditions.checkArgument(entryFields.hasNext(), "Chunk [%s] is not a valid entry", new Object[] { entry });
/* 284:534 */         String value = (String)entryFields.next();
/* 285:535 */         map.put(key, value);
/* 286:    */         
/* 287:537 */         Preconditions.checkArgument(!entryFields.hasNext(), "Chunk [%s] is not a valid entry", new Object[] { entry });
/* 288:    */       }
/* 289:539 */       return Collections.unmodifiableMap(map);
/* 290:    */     }
/* 291:    */   }
/* 292:    */   
/* 293:    */   private static abstract interface Strategy
/* 294:    */   {
/* 295:    */     public abstract Iterator<String> iterator(Splitter paramSplitter, CharSequence paramCharSequence);
/* 296:    */   }
/* 297:    */   
/* 298:    */   private static abstract class SplittingIterator
/* 299:    */     extends AbstractIterator<String>
/* 300:    */   {
/* 301:    */     final CharSequence toSplit;
/* 302:    */     final CharMatcher trimmer;
/* 303:    */     final boolean omitEmptyStrings;
/* 304:565 */     int offset = 0;
/* 305:    */     int limit;
/* 306:    */     
/* 307:    */     abstract int separatorStart(int paramInt);
/* 308:    */     
/* 309:    */     abstract int separatorEnd(int paramInt);
/* 310:    */     
/* 311:    */     protected SplittingIterator(Splitter splitter, CharSequence toSplit)
/* 312:    */     {
/* 313:569 */       this.trimmer = splitter.trimmer;
/* 314:570 */       this.omitEmptyStrings = splitter.omitEmptyStrings;
/* 315:571 */       this.limit = splitter.limit;
/* 316:572 */       this.toSplit = toSplit;
/* 317:    */     }
/* 318:    */     
/* 319:    */     protected String computeNext()
/* 320:    */     {
/* 321:583 */       int nextStart = this.offset;
/* 322:584 */       while (this.offset != -1)
/* 323:    */       {
/* 324:585 */         int start = nextStart;
/* 325:    */         
/* 326:    */ 
/* 327:588 */         int separatorPosition = separatorStart(this.offset);
/* 328:    */         int end;
/* 329:589 */         if (separatorPosition == -1)
/* 330:    */         {
/* 331:590 */           int end = this.toSplit.length();
/* 332:591 */           this.offset = -1;
/* 333:    */         }
/* 334:    */         else
/* 335:    */         {
/* 336:593 */           end = separatorPosition;
/* 337:594 */           this.offset = separatorEnd(separatorPosition);
/* 338:    */         }
/* 339:596 */         if (this.offset == nextStart)
/* 340:    */         {
/* 341:604 */           this.offset += 1;
/* 342:605 */           if (this.offset >= this.toSplit.length()) {
/* 343:606 */             this.offset = -1;
/* 344:    */           }
/* 345:    */         }
/* 346:    */         else
/* 347:    */         {
/* 348:611 */           while ((start < end) && (this.trimmer.matches(this.toSplit.charAt(start)))) {
/* 349:612 */             start++;
/* 350:    */           }
/* 351:614 */           while ((end > start) && (this.trimmer.matches(this.toSplit.charAt(end - 1)))) {
/* 352:615 */             end--;
/* 353:    */           }
/* 354:618 */           if ((this.omitEmptyStrings) && (start == end))
/* 355:    */           {
/* 356:620 */             nextStart = this.offset;
/* 357:    */           }
/* 358:    */           else
/* 359:    */           {
/* 360:624 */             if (this.limit == 1)
/* 361:    */             {
/* 362:628 */               end = this.toSplit.length();
/* 363:629 */               this.offset = -1;
/* 364:631 */               while ((end > start) && (this.trimmer.matches(this.toSplit.charAt(end - 1)))) {
/* 365:632 */                 end--;
/* 366:    */               }
/* 367:    */             }
/* 368:635 */             this.limit -= 1;
/* 369:    */             
/* 370:    */ 
/* 371:638 */             return this.toSplit.subSequence(start, end).toString();
/* 372:    */           }
/* 373:    */         }
/* 374:    */       }
/* 375:640 */       return (String)endOfData();
/* 376:    */     }
/* 377:    */   }
/* 378:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Splitter
 * JD-Core Version:    0.7.0.1
 */