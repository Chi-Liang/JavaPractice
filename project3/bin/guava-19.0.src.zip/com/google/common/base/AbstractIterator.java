/*  1:   */ 
/*  2:   */ 
/*  3:   */ com.google.common.annotations.GwtCompatible
/*  4:   */ java.util.Iterator
/*  5:   */ java.util.NoSuchElementException
/*  6:   */ 
/*  7:   */ 
/*  8:   */ AbstractIterator
/*  9:   */   
/* 10:   */ 
/* 11:32 */   state = NOT_READY
/* 12:   */   next
/* 13:   */   computeNext
/* 14:   */   
/* 15:   */   State
/* 16:   */   
/* 17:37 */     READY, NOT_READY, DONE, FAILED
/* 18:   */     
/* 19:   */     State {}
/* 20:   */   
/* 21:   */   
/* 22:   */   endOfData
/* 23:   */   
/* 24:48 */     state = State.DONE;
/* 25:49 */     return null;
/* 26:   */   }
/* 27:   */   
/* 28:   */   public final boolean hasNext()
/* 29:   */   {
/* 30:54 */     Preconditions.checkState(this.state != State.FAILED);
/* 31:55 */     switch (1.$SwitchMap$com$google$common$base$AbstractIterator$State[this.state.ordinal()])
/* 32:   */     {
/* 33:   */     case 1: 
/* 34:57 */       return true;
/* 35:   */     case 2: 
/* 36:59 */       return false;
/* 37:   */     }
/* 38:62 */     return tryToComputeNext();
/* 39:   */   }
/* 40:   */   
/* 41:   */   private boolean tryToComputeNext()
/* 42:   */   {
/* 43:66 */     this.state = State.FAILED;
/* 44:67 */     this.next = computeNext();
/* 45:68 */     if (this.state != State.DONE)
/* 46:   */     {
/* 47:69 */       this.state = State.READY;
/* 48:70 */       return true;
/* 49:   */     }
/* 50:72 */     return false;
/* 51:   */   }
/* 52:   */   
/* 53:   */   public final T next()
/* 54:   */   {
/* 55:77 */     if (!hasNext()) {
/* 56:78 */       throw new NoSuchElementException();
/* 57:   */     }
/* 58:80 */     this.state = State.NOT_READY;
/* 59:81 */     T result = this.next;
/* 60:82 */     this.next = null;
/* 61:83 */     return result;
/* 62:   */   }
/* 63:   */   
/* 64:   */   public final void remove()
/* 65:   */   {
/* 66:88 */     throw new UnsupportedOperationException();
/* 67:   */   }
/* 68:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.AbstractIterator
 * JD-Core Version:    0.7.0.1
 */