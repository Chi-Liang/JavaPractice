/*   1:    */ package com.google.common.base.internal;
/*   2:    */ 
/*   3:    */ import java.lang.ref.PhantomReference;
/*   4:    */ import java.lang.ref.Reference;
/*   5:    */ import java.lang.ref.ReferenceQueue;
/*   6:    */ import java.lang.ref.WeakReference;
/*   7:    */ import java.lang.reflect.Field;
/*   8:    */ import java.lang.reflect.Method;
/*   9:    */ import java.util.logging.Level;
/*  10:    */ import java.util.logging.Logger;
/*  11:    */ 
/*  12:    */ public class Finalizer
/*  13:    */   implements Runnable
/*  14:    */ {
/*  15: 51 */   private static final Logger logger = Logger.getLogger(Finalizer.class.getName());
/*  16:    */   private static final String FINALIZABLE_REFERENCE = "com.google.common.base.FinalizableReference";
/*  17:    */   private final WeakReference<Class<?>> finalizableReferenceClassReference;
/*  18:    */   private final PhantomReference<Object> frqReference;
/*  19:    */   private final ReferenceQueue<Object> queue;
/*  20:    */   
/*  21:    */   public static void startFinalizer(Class<?> finalizableReferenceClass, ReferenceQueue<Object> queue, PhantomReference<Object> frqReference)
/*  22:    */   {
/*  23: 78 */     if (!finalizableReferenceClass.getName().equals("com.google.common.base.FinalizableReference")) {
/*  24: 79 */       throw new IllegalArgumentException("Expected com.google.common.base.FinalizableReference.");
/*  25:    */     }
/*  26: 82 */     Finalizer finalizer = new Finalizer(finalizableReferenceClass, queue, frqReference);
/*  27: 83 */     Thread thread = new Thread(finalizer);
/*  28: 84 */     thread.setName(Finalizer.class.getName());
/*  29: 85 */     thread.setDaemon(true);
/*  30:    */     try
/*  31:    */     {
/*  32: 88 */       if (inheritableThreadLocals != null) {
/*  33: 89 */         inheritableThreadLocals.set(thread, null);
/*  34:    */       }
/*  35:    */     }
/*  36:    */     catch (Throwable t)
/*  37:    */     {
/*  38: 92 */       logger.log(Level.INFO, "Failed to clear thread local values inherited by reference finalizer thread.", t);
/*  39:    */     }
/*  40: 98 */     thread.start();
/*  41:    */   }
/*  42:    */   
/*  43:105 */   private static final Field inheritableThreadLocals = getInheritableThreadLocalsField();
/*  44:    */   
/*  45:    */   private Finalizer(Class<?> finalizableReferenceClass, ReferenceQueue<Object> queue, PhantomReference<Object> frqReference)
/*  46:    */   {
/*  47:112 */     this.queue = queue;
/*  48:    */     
/*  49:114 */     this.finalizableReferenceClassReference = new WeakReference(finalizableReferenceClass);
/*  50:    */     
/*  51:    */ 
/*  52:    */ 
/*  53:118 */     this.frqReference = frqReference;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public void run()
/*  57:    */   {
/*  58:    */     try
/*  59:    */     {
/*  60:129 */       while (cleanUp(this.queue.remove())) {}
/*  61:    */     }
/*  62:    */     catch (InterruptedException e) {}
/*  63:    */   }
/*  64:    */   
/*  65:    */   private boolean cleanUp(Reference<?> reference)
/*  66:    */   {
/*  67:144 */     Method finalizeReferentMethod = getFinalizeReferentMethod();
/*  68:145 */     if (finalizeReferentMethod == null) {
/*  69:146 */       return false;
/*  70:    */     }
/*  71:    */     do
/*  72:    */     {
/*  73:153 */       reference.clear();
/*  74:155 */       if (reference == this.frqReference) {
/*  75:160 */         return false;
/*  76:    */       }
/*  77:    */       try
/*  78:    */       {
/*  79:164 */         finalizeReferentMethod.invoke(reference, new Object[0]);
/*  80:    */       }
/*  81:    */       catch (Throwable t)
/*  82:    */       {
/*  83:166 */         logger.log(Level.SEVERE, "Error cleaning up after reference.", t);
/*  84:    */       }
/*  85:173 */     } while ((reference = this.queue.poll()) != null);
/*  86:174 */     return true;
/*  87:    */   }
/*  88:    */   
/*  89:    */   private Method getFinalizeReferentMethod()
/*  90:    */   {
/*  91:181 */     Class<?> finalizableReferenceClass = (Class)this.finalizableReferenceClassReference.get();
/*  92:182 */     if (finalizableReferenceClass == null) {
/*  93:191 */       return null;
/*  94:    */     }
/*  95:    */     try
/*  96:    */     {
/*  97:194 */       return finalizableReferenceClass.getMethod("finalizeReferent", new Class[0]);
/*  98:    */     }
/*  99:    */     catch (NoSuchMethodException e)
/* 100:    */     {
/* 101:196 */       throw new AssertionError(e);
/* 102:    */     }
/* 103:    */   }
/* 104:    */   
/* 105:    */   public static Field getInheritableThreadLocalsField()
/* 106:    */   {
/* 107:    */     try
/* 108:    */     {
/* 109:202 */       Field inheritableThreadLocals = Thread.class.getDeclaredField("inheritableThreadLocals");
/* 110:203 */       inheritableThreadLocals.setAccessible(true);
/* 111:204 */       return inheritableThreadLocals;
/* 112:    */     }
/* 113:    */     catch (Throwable t)
/* 114:    */     {
/* 115:206 */       logger.log(Level.INFO, "Couldn't access Thread.inheritableThreadLocals. Reference finalizer threads will inherit thread local values.");
/* 116:    */     }
/* 117:210 */     return null;
/* 118:    */   }
/* 119:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.internal.Finalizer
 * JD-Core Version:    0.7.0.1
 */