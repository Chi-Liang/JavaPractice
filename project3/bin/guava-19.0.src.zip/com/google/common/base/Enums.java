/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.lang.ref.WeakReference;
/*   8:    */ import java.lang.reflect.Field;
/*   9:    */ import java.util.EnumSet;
/*  10:    */ import java.util.HashMap;
/*  11:    */ import java.util.Map;
/*  12:    */ import java.util.WeakHashMap;
/*  13:    */ import javax.annotation.CheckReturnValue;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @CheckReturnValue
/*  17:    */ @GwtCompatible(emulated=true)
/*  18:    */ @Beta
/*  19:    */ public final class Enums
/*  20:    */ {
/*  21:    */   @GwtIncompatible("reflection")
/*  22:    */   public static Field getField(Enum<?> enumValue)
/*  23:    */   {
/*  24: 59 */     Class<?> clazz = enumValue.getDeclaringClass();
/*  25:    */     try
/*  26:    */     {
/*  27: 61 */       return clazz.getDeclaredField(enumValue.name());
/*  28:    */     }
/*  29:    */     catch (NoSuchFieldException impossible)
/*  30:    */     {
/*  31: 63 */       throw new AssertionError(impossible);
/*  32:    */     }
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static <T extends Enum<T>> Optional<T> getIfPresent(Class<T> enumClass, String value)
/*  36:    */   {
/*  37: 76 */     Preconditions.checkNotNull(enumClass);
/*  38: 77 */     Preconditions.checkNotNull(value);
/*  39: 78 */     return Platform.getEnumIfPresent(enumClass, value);
/*  40:    */   }
/*  41:    */   
/*  42:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  43: 83 */   private static final Map<Class<? extends Enum<?>>, Map<String, WeakReference<? extends Enum<?>>>> enumConstantCache = new WeakHashMap();
/*  44:    */   
/*  45:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  46:    */   private static <T extends Enum<T>> Map<String, WeakReference<? extends Enum<?>>> populateCache(Class<T> enumClass)
/*  47:    */   {
/*  48: 90 */     Map<String, WeakReference<? extends Enum<?>>> result = new HashMap();
/*  49: 92 */     for (T enumInstance : EnumSet.allOf(enumClass)) {
/*  50: 93 */       result.put(enumInstance.name(), new WeakReference(enumInstance));
/*  51:    */     }
/*  52: 95 */     enumConstantCache.put(enumClass, result);
/*  53: 96 */     return result;
/*  54:    */   }
/*  55:    */   
/*  56:    */   @GwtIncompatible("java.lang.ref.WeakReference")
/*  57:    */   static <T extends Enum<T>> Map<String, WeakReference<? extends Enum<?>>> getEnumConstants(Class<T> enumClass)
/*  58:    */   {
/*  59:102 */     synchronized (enumConstantCache)
/*  60:    */     {
/*  61:103 */       Map<String, WeakReference<? extends Enum<?>>> constants = (Map)enumConstantCache.get(enumClass);
/*  62:104 */       if (constants == null) {
/*  63:105 */         constants = populateCache(enumClass);
/*  64:    */       }
/*  65:107 */       return constants;
/*  66:    */     }
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static <T extends Enum<T>> Converter<String, T> stringConverter(Class<T> enumClass)
/*  70:    */   {
/*  71:120 */     return new StringConverter(enumClass);
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static final class StringConverter<T extends Enum<T>>
/*  75:    */     extends Converter<String, T>
/*  76:    */     implements Serializable
/*  77:    */   {
/*  78:    */     private final Class<T> enumClass;
/*  79:    */     private static final long serialVersionUID = 0L;
/*  80:    */     
/*  81:    */     StringConverter(Class<T> enumClass)
/*  82:    */     {
/*  83:129 */       this.enumClass = ((Class)Preconditions.checkNotNull(enumClass));
/*  84:    */     }
/*  85:    */     
/*  86:    */     protected T doForward(String value)
/*  87:    */     {
/*  88:134 */       return Enum.valueOf(this.enumClass, value);
/*  89:    */     }
/*  90:    */     
/*  91:    */     protected String doBackward(T enumValue)
/*  92:    */     {
/*  93:139 */       return enumValue.name();
/*  94:    */     }
/*  95:    */     
/*  96:    */     public boolean equals(@Nullable Object object)
/*  97:    */     {
/*  98:144 */       if ((object instanceof StringConverter))
/*  99:    */       {
/* 100:145 */         StringConverter<?> that = (StringConverter)object;
/* 101:146 */         return this.enumClass.equals(that.enumClass);
/* 102:    */       }
/* 103:148 */       return false;
/* 104:    */     }
/* 105:    */     
/* 106:    */     public int hashCode()
/* 107:    */     {
/* 108:153 */       return this.enumClass.hashCode();
/* 109:    */     }
/* 110:    */     
/* 111:    */     public String toString()
/* 112:    */     {
/* 113:158 */       return "Enums.stringConverter(" + this.enumClass.getName() + ".class)";
/* 114:    */     }
/* 115:    */   }
/* 116:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Enums
 * JD-Core Version:    0.7.0.1
 */