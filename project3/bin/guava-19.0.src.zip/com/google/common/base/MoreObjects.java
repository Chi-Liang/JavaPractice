/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Arrays;
/*   5:    */ import javax.annotation.CheckReturnValue;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible
/*   9:    */ public final class MoreObjects
/*  10:    */ {
/*  11:    */   @CheckReturnValue
/*  12:    */   public static <T> T firstNonNull(@Nullable T first, @Nullable T second)
/*  13:    */   {
/*  14: 56 */     return first != null ? first : Preconditions.checkNotNull(second);
/*  15:    */   }
/*  16:    */   
/*  17:    */   @CheckReturnValue
/*  18:    */   public static ToStringHelper toStringHelper(Object self)
/*  19:    */   {
/*  20:100 */     return new ToStringHelper(self.getClass().getSimpleName(), null);
/*  21:    */   }
/*  22:    */   
/*  23:    */   @CheckReturnValue
/*  24:    */   public static ToStringHelper toStringHelper(Class<?> clazz)
/*  25:    */   {
/*  26:115 */     return new ToStringHelper(clazz.getSimpleName(), null);
/*  27:    */   }
/*  28:    */   
/*  29:    */   @CheckReturnValue
/*  30:    */   public static ToStringHelper toStringHelper(String className)
/*  31:    */   {
/*  32:128 */     return new ToStringHelper(className, null);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public static final class ToStringHelper
/*  36:    */   {
/*  37:    */     private final String className;
/*  38:139 */     private ValueHolder holderHead = new ValueHolder(null);
/*  39:140 */     private ValueHolder holderTail = this.holderHead;
/*  40:141 */     private boolean omitNullValues = false;
/*  41:    */     
/*  42:    */     private ToStringHelper(String className)
/*  43:    */     {
/*  44:147 */       this.className = ((String)Preconditions.checkNotNull(className));
/*  45:    */     }
/*  46:    */     
/*  47:    */     public ToStringHelper omitNullValues()
/*  48:    */     {
/*  49:158 */       this.omitNullValues = true;
/*  50:159 */       return this;
/*  51:    */     }
/*  52:    */     
/*  53:    */     public ToStringHelper add(String name, @Nullable Object value)
/*  54:    */     {
/*  55:169 */       return addHolder(name, value);
/*  56:    */     }
/*  57:    */     
/*  58:    */     public ToStringHelper add(String name, boolean value)
/*  59:    */     {
/*  60:179 */       return addHolder(name, String.valueOf(value));
/*  61:    */     }
/*  62:    */     
/*  63:    */     public ToStringHelper add(String name, char value)
/*  64:    */     {
/*  65:189 */       return addHolder(name, String.valueOf(value));
/*  66:    */     }
/*  67:    */     
/*  68:    */     public ToStringHelper add(String name, double value)
/*  69:    */     {
/*  70:199 */       return addHolder(name, String.valueOf(value));
/*  71:    */     }
/*  72:    */     
/*  73:    */     public ToStringHelper add(String name, float value)
/*  74:    */     {
/*  75:209 */       return addHolder(name, String.valueOf(value));
/*  76:    */     }
/*  77:    */     
/*  78:    */     public ToStringHelper add(String name, int value)
/*  79:    */     {
/*  80:219 */       return addHolder(name, String.valueOf(value));
/*  81:    */     }
/*  82:    */     
/*  83:    */     public ToStringHelper add(String name, long value)
/*  84:    */     {
/*  85:229 */       return addHolder(name, String.valueOf(value));
/*  86:    */     }
/*  87:    */     
/*  88:    */     public ToStringHelper addValue(@Nullable Object value)
/*  89:    */     {
/*  90:239 */       return addHolder(value);
/*  91:    */     }
/*  92:    */     
/*  93:    */     public ToStringHelper addValue(boolean value)
/*  94:    */     {
/*  95:251 */       return addHolder(String.valueOf(value));
/*  96:    */     }
/*  97:    */     
/*  98:    */     public ToStringHelper addValue(char value)
/*  99:    */     {
/* 100:263 */       return addHolder(String.valueOf(value));
/* 101:    */     }
/* 102:    */     
/* 103:    */     public ToStringHelper addValue(double value)
/* 104:    */     {
/* 105:275 */       return addHolder(String.valueOf(value));
/* 106:    */     }
/* 107:    */     
/* 108:    */     public ToStringHelper addValue(float value)
/* 109:    */     {
/* 110:287 */       return addHolder(String.valueOf(value));
/* 111:    */     }
/* 112:    */     
/* 113:    */     public ToStringHelper addValue(int value)
/* 114:    */     {
/* 115:299 */       return addHolder(String.valueOf(value));
/* 116:    */     }
/* 117:    */     
/* 118:    */     public ToStringHelper addValue(long value)
/* 119:    */     {
/* 120:311 */       return addHolder(String.valueOf(value));
/* 121:    */     }
/* 122:    */     
/* 123:    */     @CheckReturnValue
/* 124:    */     public String toString()
/* 125:    */     {
/* 126:328 */       boolean omitNullValuesSnapshot = this.omitNullValues;
/* 127:329 */       String nextSeparator = "";
/* 128:330 */       StringBuilder builder = new StringBuilder(32).append(this.className).append('{');
/* 129:331 */       for (ValueHolder valueHolder = this.holderHead.next; valueHolder != null; valueHolder = valueHolder.next)
/* 130:    */       {
/* 131:334 */         Object value = valueHolder.value;
/* 132:335 */         if ((!omitNullValuesSnapshot) || (value != null))
/* 133:    */         {
/* 134:336 */           builder.append(nextSeparator);
/* 135:337 */           nextSeparator = ", ";
/* 136:339 */           if (valueHolder.name != null) {
/* 137:340 */             builder.append(valueHolder.name).append('=');
/* 138:    */           }
/* 139:342 */           if ((value != null) && (value.getClass().isArray()))
/* 140:    */           {
/* 141:343 */             Object[] objectArray = { value };
/* 142:344 */             String arrayString = Arrays.deepToString(objectArray);
/* 143:345 */             builder.append(arrayString.substring(1, arrayString.length() - 1));
/* 144:    */           }
/* 145:    */           else
/* 146:    */           {
/* 147:347 */             builder.append(value);
/* 148:    */           }
/* 149:    */         }
/* 150:    */       }
/* 151:351 */       return '}';
/* 152:    */     }
/* 153:    */     
/* 154:    */     private ValueHolder addHolder()
/* 155:    */     {
/* 156:355 */       ValueHolder valueHolder = new ValueHolder(null);
/* 157:356 */       this.holderTail = (this.holderTail.next = valueHolder);
/* 158:357 */       return valueHolder;
/* 159:    */     }
/* 160:    */     
/* 161:    */     private ToStringHelper addHolder(@Nullable Object value)
/* 162:    */     {
/* 163:361 */       ValueHolder valueHolder = addHolder();
/* 164:362 */       valueHolder.value = value;
/* 165:363 */       return this;
/* 166:    */     }
/* 167:    */     
/* 168:    */     private ToStringHelper addHolder(String name, @Nullable Object value)
/* 169:    */     {
/* 170:367 */       ValueHolder valueHolder = addHolder();
/* 171:368 */       valueHolder.value = value;
/* 172:369 */       valueHolder.name = ((String)Preconditions.checkNotNull(name));
/* 173:370 */       return this;
/* 174:    */     }
/* 175:    */     
/* 176:    */     private static final class ValueHolder
/* 177:    */     {
/* 178:    */       String name;
/* 179:    */       Object value;
/* 180:    */       ValueHolder next;
/* 181:    */     }
/* 182:    */   }
/* 183:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.MoreObjects
 * JD-Core Version:    0.7.0.1
 */