/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import java.util.Set;
/*   8:    */ import javax.annotation.CheckReturnValue;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @CheckReturnValue
/*  12:    */ @GwtCompatible(serializable=true)
/*  13:    */ public abstract class Optional<T>
/*  14:    */   implements Serializable
/*  15:    */ {
/*  16:    */   private static final long serialVersionUID = 0L;
/*  17:    */   
/*  18:    */   public static <T> Optional<T> absent()
/*  19:    */   {
/*  20:100 */     return Absent.withType();
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static <T> Optional<T> of(T reference)
/*  24:    */   {
/*  25:112 */     return new Present(Preconditions.checkNotNull(reference));
/*  26:    */   }
/*  27:    */   
/*  28:    */   public static <T> Optional<T> fromNullable(@Nullable T nullableReference)
/*  29:    */   {
/*  30:123 */     return nullableReference == null ? absent() : new Present(nullableReference);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public abstract boolean isPresent();
/*  34:    */   
/*  35:    */   public abstract T get();
/*  36:    */   
/*  37:    */   public abstract T or(T paramT);
/*  38:    */   
/*  39:    */   public abstract Optional<T> or(Optional<? extends T> paramOptional);
/*  40:    */   
/*  41:    */   @Beta
/*  42:    */   public abstract T or(Supplier<? extends T> paramSupplier);
/*  43:    */   
/*  44:    */   @Nullable
/*  45:    */   public abstract T orNull();
/*  46:    */   
/*  47:    */   public abstract Set<T> asSet();
/*  48:    */   
/*  49:    */   public abstract <V> Optional<V> transform(Function<? super T, V> paramFunction);
/*  50:    */   
/*  51:    */   public abstract boolean equals(@Nullable Object paramObject);
/*  52:    */   
/*  53:    */   public abstract int hashCode();
/*  54:    */   
/*  55:    */   public abstract String toString();
/*  56:    */   
/*  57:    */   @Beta
/*  58:    */   public static <T> Iterable<T> presentInstances(Iterable<? extends Optional<? extends T>> optionals)
/*  59:    */   {
/*  60:296 */     Preconditions.checkNotNull(optionals);
/*  61:297 */     new Iterable()
/*  62:    */     {
/*  63:    */       public Iterator<T> iterator()
/*  64:    */       {
/*  65:300 */         new AbstractIterator()
/*  66:    */         {
/*  67:301 */           private final Iterator<? extends Optional<? extends T>> iterator = (Iterator)Preconditions.checkNotNull(Optional.1.this.val$optionals.iterator());
/*  68:    */           
/*  69:    */           protected T computeNext()
/*  70:    */           {
/*  71:306 */             while (this.iterator.hasNext())
/*  72:    */             {
/*  73:307 */               Optional<? extends T> optional = (Optional)this.iterator.next();
/*  74:308 */               if (optional.isPresent()) {
/*  75:309 */                 return optional.get();
/*  76:    */               }
/*  77:    */             }
/*  78:312 */             return endOfData();
/*  79:    */           }
/*  80:    */         };
/*  81:    */       }
/*  82:    */     };
/*  83:    */   }
/*  84:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Optional
 * JD-Core Version:    0.7.0.1
 */