/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.concurrent.TimeUnit;
/*   8:    */ import javax.annotation.CheckReturnValue;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @CheckReturnValue
/*  12:    */ @GwtCompatible
/*  13:    */ public final class Suppliers
/*  14:    */ {
/*  15:    */   public static <F, T> Supplier<T> compose(Function<? super F, T> function, Supplier<F> supplier)
/*  16:    */   {
/*  17: 52 */     Preconditions.checkNotNull(function);
/*  18: 53 */     Preconditions.checkNotNull(supplier);
/*  19: 54 */     return new SupplierComposition(function, supplier);
/*  20:    */   }
/*  21:    */   
/*  22:    */   private static class SupplierComposition<F, T>
/*  23:    */     implements Supplier<T>, Serializable
/*  24:    */   {
/*  25:    */     final Function<? super F, T> function;
/*  26:    */     final Supplier<F> supplier;
/*  27:    */     private static final long serialVersionUID = 0L;
/*  28:    */     
/*  29:    */     SupplierComposition(Function<? super F, T> function, Supplier<F> supplier)
/*  30:    */     {
/*  31: 62 */       this.function = function;
/*  32: 63 */       this.supplier = supplier;
/*  33:    */     }
/*  34:    */     
/*  35:    */     public T get()
/*  36:    */     {
/*  37: 68 */       return this.function.apply(this.supplier.get());
/*  38:    */     }
/*  39:    */     
/*  40:    */     public boolean equals(@Nullable Object obj)
/*  41:    */     {
/*  42: 73 */       if ((obj instanceof SupplierComposition))
/*  43:    */       {
/*  44: 74 */         SupplierComposition<?, ?> that = (SupplierComposition)obj;
/*  45: 75 */         return (this.function.equals(that.function)) && (this.supplier.equals(that.supplier));
/*  46:    */       }
/*  47: 77 */       return false;
/*  48:    */     }
/*  49:    */     
/*  50:    */     public int hashCode()
/*  51:    */     {
/*  52: 82 */       return Objects.hashCode(new Object[] { this.function, this.supplier });
/*  53:    */     }
/*  54:    */     
/*  55:    */     public String toString()
/*  56:    */     {
/*  57: 87 */       return "Suppliers.compose(" + this.function + ", " + this.supplier + ")";
/*  58:    */     }
/*  59:    */   }
/*  60:    */   
/*  61:    */   public static <T> Supplier<T> memoize(Supplier<T> delegate)
/*  62:    */   {
/*  63:108 */     return (delegate instanceof MemoizingSupplier) ? delegate : new MemoizingSupplier((Supplier)Preconditions.checkNotNull(delegate));
/*  64:    */   }
/*  65:    */   
/*  66:    */   @VisibleForTesting
/*  67:    */   static class MemoizingSupplier<T>
/*  68:    */     implements Supplier<T>, Serializable
/*  69:    */   {
/*  70:    */     final Supplier<T> delegate;
/*  71:    */     volatile transient boolean initialized;
/*  72:    */     transient T value;
/*  73:    */     private static final long serialVersionUID = 0L;
/*  74:    */     
/*  75:    */     MemoizingSupplier(Supplier<T> delegate)
/*  76:    */     {
/*  77:122 */       this.delegate = delegate;
/*  78:    */     }
/*  79:    */     
/*  80:    */     public T get()
/*  81:    */     {
/*  82:128 */       if (!this.initialized) {
/*  83:129 */         synchronized (this)
/*  84:    */         {
/*  85:130 */           if (!this.initialized)
/*  86:    */           {
/*  87:131 */             T t = this.delegate.get();
/*  88:132 */             this.value = t;
/*  89:133 */             this.initialized = true;
/*  90:134 */             return t;
/*  91:    */           }
/*  92:    */         }
/*  93:    */       }
/*  94:138 */       return this.value;
/*  95:    */     }
/*  96:    */     
/*  97:    */     public String toString()
/*  98:    */     {
/*  99:143 */       return "Suppliers.memoize(" + this.delegate + ")";
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:    */   public static <T> Supplier<T> memoizeWithExpiration(Supplier<T> delegate, long duration, TimeUnit unit)
/* 104:    */   {
/* 105:169 */     return new ExpiringMemoizingSupplier(delegate, duration, unit);
/* 106:    */   }
/* 107:    */   
/* 108:    */   @VisibleForTesting
/* 109:    */   static class ExpiringMemoizingSupplier<T>
/* 110:    */     implements Supplier<T>, Serializable
/* 111:    */   {
/* 112:    */     final Supplier<T> delegate;
/* 113:    */     final long durationNanos;
/* 114:    */     volatile transient T value;
/* 115:    */     volatile transient long expirationNanos;
/* 116:    */     private static final long serialVersionUID = 0L;
/* 117:    */     
/* 118:    */     ExpiringMemoizingSupplier(Supplier<T> delegate, long duration, TimeUnit unit)
/* 119:    */     {
/* 120:181 */       this.delegate = ((Supplier)Preconditions.checkNotNull(delegate));
/* 121:182 */       this.durationNanos = unit.toNanos(duration);
/* 122:183 */       Preconditions.checkArgument(duration > 0L);
/* 123:    */     }
/* 124:    */     
/* 125:    */     public T get()
/* 126:    */     {
/* 127:194 */       long nanos = this.expirationNanos;
/* 128:195 */       long now = Platform.systemNanoTime();
/* 129:196 */       if ((nanos == 0L) || (now - nanos >= 0L)) {
/* 130:197 */         synchronized (this)
/* 131:    */         {
/* 132:198 */           if (nanos == this.expirationNanos)
/* 133:    */           {
/* 134:199 */             T t = this.delegate.get();
/* 135:200 */             this.value = t;
/* 136:201 */             nanos = now + this.durationNanos;
/* 137:    */             
/* 138:    */ 
/* 139:204 */             this.expirationNanos = (nanos == 0L ? 1L : nanos);
/* 140:205 */             return t;
/* 141:    */           }
/* 142:    */         }
/* 143:    */       }
/* 144:209 */       return this.value;
/* 145:    */     }
/* 146:    */     
/* 147:    */     public String toString()
/* 148:    */     {
/* 149:216 */       return "Suppliers.memoizeWithExpiration(" + this.delegate + ", " + this.durationNanos + ", NANOS)";
/* 150:    */     }
/* 151:    */   }
/* 152:    */   
/* 153:    */   public static <T> Supplier<T> ofInstance(@Nullable T instance)
/* 154:    */   {
/* 155:226 */     return new SupplierOfInstance(instance);
/* 156:    */   }
/* 157:    */   
/* 158:    */   private static class SupplierOfInstance<T>
/* 159:    */     implements Supplier<T>, Serializable
/* 160:    */   {
/* 161:    */     final T instance;
/* 162:    */     private static final long serialVersionUID = 0L;
/* 163:    */     
/* 164:    */     SupplierOfInstance(@Nullable T instance)
/* 165:    */     {
/* 166:233 */       this.instance = instance;
/* 167:    */     }
/* 168:    */     
/* 169:    */     public T get()
/* 170:    */     {
/* 171:238 */       return this.instance;
/* 172:    */     }
/* 173:    */     
/* 174:    */     public boolean equals(@Nullable Object obj)
/* 175:    */     {
/* 176:243 */       if ((obj instanceof SupplierOfInstance))
/* 177:    */       {
/* 178:244 */         SupplierOfInstance<?> that = (SupplierOfInstance)obj;
/* 179:245 */         return Objects.equal(this.instance, that.instance);
/* 180:    */       }
/* 181:247 */       return false;
/* 182:    */     }
/* 183:    */     
/* 184:    */     public int hashCode()
/* 185:    */     {
/* 186:252 */       return Objects.hashCode(new Object[] { this.instance });
/* 187:    */     }
/* 188:    */     
/* 189:    */     public String toString()
/* 190:    */     {
/* 191:257 */       return "Suppliers.ofInstance(" + this.instance + ")";
/* 192:    */     }
/* 193:    */   }
/* 194:    */   
/* 195:    */   public static <T> Supplier<T> synchronizedSupplier(Supplier<T> delegate)
/* 196:    */   {
/* 197:268 */     return new ThreadSafeSupplier((Supplier)Preconditions.checkNotNull(delegate));
/* 198:    */   }
/* 199:    */   
/* 200:    */   private static class ThreadSafeSupplier<T>
/* 201:    */     implements Supplier<T>, Serializable
/* 202:    */   {
/* 203:    */     final Supplier<T> delegate;
/* 204:    */     private static final long serialVersionUID = 0L;
/* 205:    */     
/* 206:    */     ThreadSafeSupplier(Supplier<T> delegate)
/* 207:    */     {
/* 208:275 */       this.delegate = delegate;
/* 209:    */     }
/* 210:    */     
/* 211:    */     public T get()
/* 212:    */     {
/* 213:280 */       synchronized (this.delegate)
/* 214:    */       {
/* 215:281 */         return this.delegate.get();
/* 216:    */       }
/* 217:    */     }
/* 218:    */     
/* 219:    */     public String toString()
/* 220:    */     {
/* 221:287 */       return "Suppliers.synchronizedSupplier(" + this.delegate + ")";
/* 222:    */     }
/* 223:    */   }
/* 224:    */   
/* 225:    */   @Beta
/* 226:    */   public static <T> Function<Supplier<T>, T> supplierFunction()
/* 227:    */   {
/* 228:302 */     SupplierFunction<T> sf = SupplierFunctionImpl.INSTANCE;
/* 229:303 */     return sf;
/* 230:    */   }
/* 231:    */   
/* 232:    */   private static abstract interface SupplierFunction<T>
/* 233:    */     extends Function<Supplier<T>, T>
/* 234:    */   {}
/* 235:    */   
/* 236:    */   private static enum SupplierFunctionImpl
/* 237:    */     implements Suppliers.SupplierFunction<Object>
/* 238:    */   {
/* 239:309 */     INSTANCE;
/* 240:    */     
/* 241:    */     private SupplierFunctionImpl() {}
/* 242:    */     
/* 243:    */     public Object apply(Supplier<Object> input)
/* 244:    */     {
/* 245:314 */       return input.get();
/* 246:    */     }
/* 247:    */     
/* 248:    */     public String toString()
/* 249:    */     {
/* 250:319 */       return "Suppliers.supplierFunction()";
/* 251:    */     }
/* 252:    */   }
/* 253:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Suppliers
 * JD-Core Version:    0.7.0.1
 */