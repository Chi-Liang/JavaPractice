/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import java.io.PrintWriter;
/*   6:    */ import java.io.StringWriter;
/*   7:    */ import java.lang.reflect.InvocationTargetException;
/*   8:    */ import java.lang.reflect.Method;
/*   9:    */ import java.util.AbstractList;
/*  10:    */ import java.util.ArrayList;
/*  11:    */ import java.util.Arrays;
/*  12:    */ import java.util.Collections;
/*  13:    */ import java.util.List;
/*  14:    */ import javax.annotation.CheckReturnValue;
/*  15:    */ import javax.annotation.Nullable;
/*  16:    */ 
/*  17:    */ public final class Throwables
/*  18:    */ {
/*  19:    */   private static final String JAVA_LANG_ACCESS_CLASSNAME = "sun.misc.JavaLangAccess";
/*  20:    */   @VisibleForTesting
/*  21:    */   static final String SHARED_SECRETS_CLASSNAME = "sun.misc.SharedSecrets";
/*  22:    */   
/*  23:    */   public static <X extends Throwable> void propagateIfInstanceOf(@Nullable Throwable throwable, Class<X> declaredType)
/*  24:    */     throws Throwable
/*  25:    */   {
/*  26: 69 */     if ((throwable != null) && (declaredType.isInstance(throwable))) {
/*  27: 70 */       throw ((Throwable)declaredType.cast(throwable));
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static void propagateIfPossible(@Nullable Throwable throwable)
/*  32:    */   {
/*  33: 89 */     propagateIfInstanceOf(throwable, Error.class);
/*  34: 90 */     propagateIfInstanceOf(throwable, RuntimeException.class);
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static <X extends Throwable> void propagateIfPossible(@Nullable Throwable throwable, Class<X> declaredType)
/*  38:    */     throws Throwable
/*  39:    */   {
/*  40:112 */     propagateIfInstanceOf(throwable, declaredType);
/*  41:113 */     propagateIfPossible(throwable);
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <X1 extends Throwable, X2 extends Throwable> void propagateIfPossible(@Nullable Throwable throwable, Class<X1> declaredType1, Class<X2> declaredType2)
/*  45:    */     throws Throwable, Throwable
/*  46:    */   {
/*  47:130 */     Preconditions.checkNotNull(declaredType2);
/*  48:131 */     propagateIfInstanceOf(throwable, declaredType1);
/*  49:132 */     propagateIfPossible(throwable, declaredType2);
/*  50:    */   }
/*  51:    */   
/*  52:    */   public static RuntimeException propagate(Throwable throwable)
/*  53:    */   {
/*  54:159 */     propagateIfPossible((Throwable)Preconditions.checkNotNull(throwable));
/*  55:160 */     throw new RuntimeException(throwable);
/*  56:    */   }
/*  57:    */   
/*  58:    */   @CheckReturnValue
/*  59:    */   public static Throwable getRootCause(Throwable throwable)
/*  60:    */   {
/*  61:    */     Throwable cause;
/*  62:174 */     while ((cause = throwable.getCause()) != null) {
/*  63:175 */       throwable = cause;
/*  64:    */     }
/*  65:177 */     return throwable;
/*  66:    */   }
/*  67:    */   
/*  68:    */   @CheckReturnValue
/*  69:    */   @Beta
/*  70:    */   public static List<Throwable> getCausalChain(Throwable throwable)
/*  71:    */   {
/*  72:198 */     Preconditions.checkNotNull(throwable);
/*  73:199 */     List<Throwable> causes = new ArrayList(4);
/*  74:200 */     while (throwable != null)
/*  75:    */     {
/*  76:201 */       causes.add(throwable);
/*  77:202 */       throwable = throwable.getCause();
/*  78:    */     }
/*  79:204 */     return Collections.unmodifiableList(causes);
/*  80:    */   }
/*  81:    */   
/*  82:    */   @CheckReturnValue
/*  83:    */   public static String getStackTraceAsString(Throwable throwable)
/*  84:    */   {
/*  85:215 */     StringWriter stringWriter = new StringWriter();
/*  86:216 */     throwable.printStackTrace(new PrintWriter(stringWriter));
/*  87:217 */     return stringWriter.toString();
/*  88:    */   }
/*  89:    */   
/*  90:    */   @CheckReturnValue
/*  91:    */   @Beta
/*  92:    */   public static List<StackTraceElement> lazyStackTrace(Throwable throwable)
/*  93:    */   {
/*  94:250 */     return lazyStackTraceIsLazy() ? jlaStackTrace(throwable) : Collections.unmodifiableList(Arrays.asList(throwable.getStackTrace()));
/*  95:    */   }
/*  96:    */   
/*  97:    */   @CheckReturnValue
/*  98:    */   @Beta
/*  99:    */   public static boolean lazyStackTraceIsLazy()
/* 100:    */   {
/* 101:264 */     return (getStackTraceElementMethod != null ? 1 : 0) & (getStackTraceDepthMethod != null ? 1 : 0);
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static List<StackTraceElement> jlaStackTrace(Throwable t)
/* 105:    */   {
/* 106:268 */     Preconditions.checkNotNull(t);
/* 107:    */     
/* 108:    */ 
/* 109:    */ 
/* 110:    */ 
/* 111:    */ 
/* 112:    */ 
/* 113:275 */     new AbstractList()
/* 114:    */     {
/* 115:    */       public StackTraceElement get(int n)
/* 116:    */       {
/* 117:278 */         return (StackTraceElement)Throwables.invokeAccessibleNonThrowingMethod(Throwables.getStackTraceElementMethod, Throwables.jla, new Object[] { this.val$t, Integer.valueOf(n) });
/* 118:    */       }
/* 119:    */       
/* 120:    */       public int size()
/* 121:    */       {
/* 122:284 */         return ((Integer)Throwables.invokeAccessibleNonThrowingMethod(Throwables.getStackTraceDepthMethod, Throwables.jla, new Object[] { this.val$t })).intValue();
/* 123:    */       }
/* 124:    */     };
/* 125:    */   }
/* 126:    */   
/* 127:    */   private static Object invokeAccessibleNonThrowingMethod(Method method, Object receiver, Object... params)
/* 128:    */   {
/* 129:    */     try
/* 130:    */     {
/* 131:292 */       return method.invoke(receiver, params);
/* 132:    */     }
/* 133:    */     catch (IllegalAccessException e)
/* 134:    */     {
/* 135:294 */       throw new RuntimeException(e);
/* 136:    */     }
/* 137:    */     catch (InvocationTargetException e)
/* 138:    */     {
/* 139:296 */       throw propagate(e.getCause());
/* 140:    */     }
/* 141:    */   }
/* 142:    */   
/* 143:    */   @Nullable
/* 144:307 */   private static final Object jla = ;
/* 145:    */   @Nullable
/* 146:314 */   private static final Method getStackTraceElementMethod = jla == null ? null : getGetMethod();
/* 147:    */   @Nullable
/* 148:321 */   private static final Method getStackTraceDepthMethod = jla == null ? null : getSizeMethod();
/* 149:    */   
/* 150:    */   @Nullable
/* 151:    */   private static Object getJLA()
/* 152:    */   {
/* 153:    */     try
/* 154:    */     {
/* 155:334 */       Class<?> sharedSecrets = Class.forName("sun.misc.SharedSecrets", false, null);
/* 156:335 */       Method langAccess = sharedSecrets.getMethod("getJavaLangAccess", new Class[0]);
/* 157:336 */       return langAccess.invoke(null, new Object[0]);
/* 158:    */     }
/* 159:    */     catch (ThreadDeath death)
/* 160:    */     {
/* 161:338 */       throw death;
/* 162:    */     }
/* 163:    */     catch (Throwable t) {}
/* 164:344 */     return null;
/* 165:    */   }
/* 166:    */   
/* 167:    */   @Nullable
/* 168:    */   private static Method getGetMethod()
/* 169:    */   {
/* 170:354 */     return getJlaMethod("getStackTraceElement", new Class[] { Throwable.class, Integer.TYPE });
/* 171:    */   }
/* 172:    */   
/* 173:    */   @Nullable
/* 174:    */   private static Method getSizeMethod()
/* 175:    */   {
/* 176:363 */     return getJlaMethod("getStackTraceDepth", new Class[] { Throwable.class });
/* 177:    */   }
/* 178:    */   
/* 179:    */   @Nullable
/* 180:    */   private static Method getJlaMethod(String name, Class<?>... parameterTypes)
/* 181:    */     throws ThreadDeath
/* 182:    */   {
/* 183:    */     try
/* 184:    */     {
/* 185:369 */       return Class.forName("sun.misc.JavaLangAccess", false, null).getMethod(name, parameterTypes);
/* 186:    */     }
/* 187:    */     catch (ThreadDeath death)
/* 188:    */     {
/* 189:371 */       throw death;
/* 190:    */     }
/* 191:    */     catch (Throwable t) {}
/* 192:377 */     return null;
/* 193:    */   }
/* 194:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Throwables
 * JD-Core Version:    0.7.0.1
 */