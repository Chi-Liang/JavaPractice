/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import java.util.Collections;
/*  4:   */ import java.util.HashMap;
/*  5:   */ import java.util.Map;
/*  6:   */ import javax.annotation.CheckReturnValue;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @CheckReturnValue
/* 10:   */ public final class Defaults
/* 11:   */ {
/* 12:   */   private static final Map<Class<?>, Object> DEFAULTS;
/* 13:   */   
/* 14:   */   static
/* 15:   */   {
/* 16:42 */     Map<Class<?>, Object> map = new HashMap();
/* 17:43 */     put(map, Boolean.TYPE, Boolean.valueOf(false));
/* 18:44 */     put(map, Character.TYPE, Character.valueOf('\000'));
/* 19:45 */     put(map, Byte.TYPE, Byte.valueOf((byte)0));
/* 20:46 */     put(map, Short.TYPE, Short.valueOf((short)0));
/* 21:47 */     put(map, Integer.TYPE, Integer.valueOf(0));
/* 22:48 */     put(map, Long.TYPE, Long.valueOf(0L));
/* 23:49 */     put(map, Float.TYPE, Float.valueOf(0.0F));
/* 24:50 */     put(map, Double.TYPE, Double.valueOf(0.0D));
/* 25:51 */     DEFAULTS = Collections.unmodifiableMap(map);
/* 26:   */   }
/* 27:   */   
/* 28:   */   private static <T> void put(Map<Class<?>, Object> map, Class<T> type, T value)
/* 29:   */   {
/* 30:55 */     map.put(type, value);
/* 31:   */   }
/* 32:   */   
/* 33:   */   @Nullable
/* 34:   */   public static <T> T defaultValue(Class<T> type)
/* 35:   */   {
/* 36:67 */     T t = DEFAULTS.get(Preconditions.checkNotNull(type));
/* 37:68 */     return t;
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Defaults
 * JD-Core Version:    0.7.0.1
 */