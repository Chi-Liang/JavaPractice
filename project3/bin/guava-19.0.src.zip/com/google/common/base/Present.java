/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import java.util.Collections;
/*   5:    */ import java.util.Set;
/*   6:    */ import javax.annotation.Nullable;
/*   7:    */ 
/*   8:    */ @GwtCompatible
/*   9:    */ final class Present<T>
/*  10:    */   extends Optional<T>
/*  11:    */ {
/*  12:    */   private final T reference;
/*  13:    */   private static final long serialVersionUID = 0L;
/*  14:    */   
/*  15:    */   Present(T reference)
/*  16:    */   {
/*  17: 36 */     this.reference = reference;
/*  18:    */   }
/*  19:    */   
/*  20:    */   public boolean isPresent()
/*  21:    */   {
/*  22: 41 */     return true;
/*  23:    */   }
/*  24:    */   
/*  25:    */   public T get()
/*  26:    */   {
/*  27: 46 */     return this.reference;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public T or(T defaultValue)
/*  31:    */   {
/*  32: 51 */     Preconditions.checkNotNull(defaultValue, "use Optional.orNull() instead of Optional.or(null)");
/*  33: 52 */     return this.reference;
/*  34:    */   }
/*  35:    */   
/*  36:    */   public Optional<T> or(Optional<? extends T> secondChoice)
/*  37:    */   {
/*  38: 57 */     Preconditions.checkNotNull(secondChoice);
/*  39: 58 */     return this;
/*  40:    */   }
/*  41:    */   
/*  42:    */   public T or(Supplier<? extends T> supplier)
/*  43:    */   {
/*  44: 63 */     Preconditions.checkNotNull(supplier);
/*  45: 64 */     return this.reference;
/*  46:    */   }
/*  47:    */   
/*  48:    */   public T orNull()
/*  49:    */   {
/*  50: 69 */     return this.reference;
/*  51:    */   }
/*  52:    */   
/*  53:    */   public Set<T> asSet()
/*  54:    */   {
/*  55: 74 */     return Collections.singleton(this.reference);
/*  56:    */   }
/*  57:    */   
/*  58:    */   public <V> Optional<V> transform(Function<? super T, V> function)
/*  59:    */   {
/*  60: 79 */     return new Present(Preconditions.checkNotNull(function.apply(this.reference), "the Function passed to Optional.transform() must not return null."));
/*  61:    */   }
/*  62:    */   
/*  63:    */   public boolean equals(@Nullable Object object)
/*  64:    */   {
/*  65: 87 */     if ((object instanceof Present))
/*  66:    */     {
/*  67: 88 */       Present<?> other = (Present)object;
/*  68: 89 */       return this.reference.equals(other.reference);
/*  69:    */     }
/*  70: 91 */     return false;
/*  71:    */   }
/*  72:    */   
/*  73:    */   public int hashCode()
/*  74:    */   {
/*  75: 96 */     return 1502476572 + this.reference.hashCode();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public String toString()
/*  79:    */   {
/*  80:101 */     return "Optional.of(" + this.reference + ")";
/*  81:    */   }
/*  82:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Present
 * JD-Core Version:    0.7.0.1
 */