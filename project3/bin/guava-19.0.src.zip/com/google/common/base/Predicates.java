/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.io.Serializable;
/*   7:    */ import java.util.ArrayList;
/*   8:    */ import java.util.Arrays;
/*   9:    */ import java.util.Collection;
/*  10:    */ import java.util.List;
/*  11:    */ import java.util.regex.Matcher;
/*  12:    */ import java.util.regex.Pattern;
/*  13:    */ import javax.annotation.CheckReturnValue;
/*  14:    */ import javax.annotation.Nullable;
/*  15:    */ 
/*  16:    */ @CheckReturnValue
/*  17:    */ @GwtCompatible(emulated=true)
/*  18:    */ public final class Predicates
/*  19:    */ {
/*  20:    */   @GwtCompatible(serializable=true)
/*  21:    */   public static <T> Predicate<T> alwaysTrue()
/*  22:    */   {
/*  23: 61 */     return ObjectPredicate.ALWAYS_TRUE.withNarrowedType();
/*  24:    */   }
/*  25:    */   
/*  26:    */   @GwtCompatible(serializable=true)
/*  27:    */   public static <T> Predicate<T> alwaysFalse()
/*  28:    */   {
/*  29: 69 */     return ObjectPredicate.ALWAYS_FALSE.withNarrowedType();
/*  30:    */   }
/*  31:    */   
/*  32:    */   @GwtCompatible(serializable=true)
/*  33:    */   public static <T> Predicate<T> isNull()
/*  34:    */   {
/*  35: 78 */     return ObjectPredicate.IS_NULL.withNarrowedType();
/*  36:    */   }
/*  37:    */   
/*  38:    */   @GwtCompatible(serializable=true)
/*  39:    */   public static <T> Predicate<T> notNull()
/*  40:    */   {
/*  41: 87 */     return ObjectPredicate.NOT_NULL.withNarrowedType();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static <T> Predicate<T> not(Predicate<T> predicate)
/*  45:    */   {
/*  46: 95 */     return new NotPredicate(predicate);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public static <T> Predicate<T> and(Iterable<? extends Predicate<? super T>> components)
/*  50:    */   {
/*  51:108 */     return new AndPredicate(defensiveCopy(components), null);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public static <T> Predicate<T> and(Predicate<? super T>... components)
/*  55:    */   {
/*  56:121 */     return new AndPredicate(defensiveCopy(components), null);
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static <T> Predicate<T> and(Predicate<? super T> first, Predicate<? super T> second)
/*  60:    */   {
/*  61:131 */     return new AndPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), null);
/*  62:    */   }
/*  63:    */   
/*  64:    */   public static <T> Predicate<T> or(Iterable<? extends Predicate<? super T>> components)
/*  65:    */   {
/*  66:144 */     return new OrPredicate(defensiveCopy(components), null);
/*  67:    */   }
/*  68:    */   
/*  69:    */   public static <T> Predicate<T> or(Predicate<? super T>... components)
/*  70:    */   {
/*  71:157 */     return new OrPredicate(defensiveCopy(components), null);
/*  72:    */   }
/*  73:    */   
/*  74:    */   public static <T> Predicate<T> or(Predicate<? super T> first, Predicate<? super T> second)
/*  75:    */   {
/*  76:167 */     return new OrPredicate(asList((Predicate)Preconditions.checkNotNull(first), (Predicate)Preconditions.checkNotNull(second)), null);
/*  77:    */   }
/*  78:    */   
/*  79:    */   public static <T> Predicate<T> equalTo(@Nullable T target)
/*  80:    */   {
/*  81:175 */     return target == null ? isNull() : new IsEqualToPredicate(target, null);
/*  82:    */   }
/*  83:    */   
/*  84:    */   @GwtIncompatible("Class.isInstance")
/*  85:    */   public static Predicate<Object> instanceOf(Class<?> clazz)
/*  86:    */   {
/*  87:195 */     return new InstanceOfPredicate(clazz, null);
/*  88:    */   }
/*  89:    */   
/*  90:    */   @GwtIncompatible("Class.isAssignableFrom")
/*  91:    */   @Beta
/*  92:    */   public static Predicate<Class<?>> assignableFrom(Class<?> clazz)
/*  93:    */   {
/*  94:208 */     return new AssignableFromPredicate(clazz, null);
/*  95:    */   }
/*  96:    */   
/*  97:    */   public static <T> Predicate<T> in(Collection<? extends T> target)
/*  98:    */   {
/*  99:225 */     return new InPredicate(target, null);
/* 100:    */   }
/* 101:    */   
/* 102:    */   public static <A, B> Predicate<A> compose(Predicate<B> predicate, Function<A, ? extends B> function)
/* 103:    */   {
/* 104:236 */     return new CompositionPredicate(predicate, function, null);
/* 105:    */   }
/* 106:    */   
/* 107:    */   @GwtIncompatible("java.util.regex.Pattern")
/* 108:    */   public static Predicate<CharSequence> containsPattern(String pattern)
/* 109:    */   {
/* 110:250 */     return new ContainsPatternFromStringPredicate(pattern);
/* 111:    */   }
/* 112:    */   
/* 113:    */   @GwtIncompatible("java.util.regex.Pattern")
/* 114:    */   public static Predicate<CharSequence> contains(Pattern pattern)
/* 115:    */   {
/* 116:263 */     return new ContainsPatternPredicate(pattern);
/* 117:    */   }
/* 118:    */   
/* 119:    */   static abstract enum ObjectPredicate
/* 120:    */     implements Predicate<Object>
/* 121:    */   {
/* 122:271 */     ALWAYS_TRUE,  ALWAYS_FALSE,  IS_NULL,  NOT_NULL;
/* 123:    */     
/* 124:    */     private ObjectPredicate() {}
/* 125:    */     
/* 126:    */     <T> Predicate<T> withNarrowedType()
/* 127:    */     {
/* 128:321 */       return this;
/* 129:    */     }
/* 130:    */   }
/* 131:    */   
/* 132:    */   private static class NotPredicate<T>
/* 133:    */     implements Predicate<T>, Serializable
/* 134:    */   {
/* 135:    */     final Predicate<T> predicate;
/* 136:    */     private static final long serialVersionUID = 0L;
/* 137:    */     
/* 138:    */     NotPredicate(Predicate<T> predicate)
/* 139:    */     {
/* 140:330 */       this.predicate = ((Predicate)Preconditions.checkNotNull(predicate));
/* 141:    */     }
/* 142:    */     
/* 143:    */     public boolean apply(@Nullable T t)
/* 144:    */     {
/* 145:335 */       return !this.predicate.apply(t);
/* 146:    */     }
/* 147:    */     
/* 148:    */     public int hashCode()
/* 149:    */     {
/* 150:340 */       return this.predicate.hashCode() ^ 0xFFFFFFFF;
/* 151:    */     }
/* 152:    */     
/* 153:    */     public boolean equals(@Nullable Object obj)
/* 154:    */     {
/* 155:345 */       if ((obj instanceof NotPredicate))
/* 156:    */       {
/* 157:346 */         NotPredicate<?> that = (NotPredicate)obj;
/* 158:347 */         return this.predicate.equals(that.predicate);
/* 159:    */       }
/* 160:349 */       return false;
/* 161:    */     }
/* 162:    */     
/* 163:    */     public String toString()
/* 164:    */     {
/* 165:354 */       return "Predicates.not(" + this.predicate + ")";
/* 166:    */     }
/* 167:    */   }
/* 168:    */   
/* 169:360 */   private static final Joiner COMMA_JOINER = Joiner.on(',');
/* 170:    */   
/* 171:    */   private static class AndPredicate<T>
/* 172:    */     implements Predicate<T>, Serializable
/* 173:    */   {
/* 174:    */     private final List<? extends Predicate<? super T>> components;
/* 175:    */     private static final long serialVersionUID = 0L;
/* 176:    */     
/* 177:    */     private AndPredicate(List<? extends Predicate<? super T>> components)
/* 178:    */     {
/* 179:367 */       this.components = components;
/* 180:    */     }
/* 181:    */     
/* 182:    */     public boolean apply(@Nullable T t)
/* 183:    */     {
/* 184:373 */       for (int i = 0; i < this.components.size(); i++) {
/* 185:374 */         if (!((Predicate)this.components.get(i)).apply(t)) {
/* 186:375 */           return false;
/* 187:    */         }
/* 188:    */       }
/* 189:378 */       return true;
/* 190:    */     }
/* 191:    */     
/* 192:    */     public int hashCode()
/* 193:    */     {
/* 194:384 */       return this.components.hashCode() + 306654252;
/* 195:    */     }
/* 196:    */     
/* 197:    */     public boolean equals(@Nullable Object obj)
/* 198:    */     {
/* 199:389 */       if ((obj instanceof AndPredicate))
/* 200:    */       {
/* 201:390 */         AndPredicate<?> that = (AndPredicate)obj;
/* 202:391 */         return this.components.equals(that.components);
/* 203:    */       }
/* 204:393 */       return false;
/* 205:    */     }
/* 206:    */     
/* 207:    */     public String toString()
/* 208:    */     {
/* 209:398 */       return "Predicates.and(" + Predicates.COMMA_JOINER.join(this.components) + ")";
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   private static class OrPredicate<T>
/* 214:    */     implements Predicate<T>, Serializable
/* 215:    */   {
/* 216:    */     private final List<? extends Predicate<? super T>> components;
/* 217:    */     private static final long serialVersionUID = 0L;
/* 218:    */     
/* 219:    */     private OrPredicate(List<? extends Predicate<? super T>> components)
/* 220:    */     {
/* 221:409 */       this.components = components;
/* 222:    */     }
/* 223:    */     
/* 224:    */     public boolean apply(@Nullable T t)
/* 225:    */     {
/* 226:415 */       for (int i = 0; i < this.components.size(); i++) {
/* 227:416 */         if (((Predicate)this.components.get(i)).apply(t)) {
/* 228:417 */           return true;
/* 229:    */         }
/* 230:    */       }
/* 231:420 */       return false;
/* 232:    */     }
/* 233:    */     
/* 234:    */     public int hashCode()
/* 235:    */     {
/* 236:426 */       return this.components.hashCode() + 87855567;
/* 237:    */     }
/* 238:    */     
/* 239:    */     public boolean equals(@Nullable Object obj)
/* 240:    */     {
/* 241:431 */       if ((obj instanceof OrPredicate))
/* 242:    */       {
/* 243:432 */         OrPredicate<?> that = (OrPredicate)obj;
/* 244:433 */         return this.components.equals(that.components);
/* 245:    */       }
/* 246:435 */       return false;
/* 247:    */     }
/* 248:    */     
/* 249:    */     public String toString()
/* 250:    */     {
/* 251:440 */       return "Predicates.or(" + Predicates.COMMA_JOINER.join(this.components) + ")";
/* 252:    */     }
/* 253:    */   }
/* 254:    */   
/* 255:    */   private static class IsEqualToPredicate<T>
/* 256:    */     implements Predicate<T>, Serializable
/* 257:    */   {
/* 258:    */     private final T target;
/* 259:    */     private static final long serialVersionUID = 0L;
/* 260:    */     
/* 261:    */     private IsEqualToPredicate(T target)
/* 262:    */     {
/* 263:451 */       this.target = target;
/* 264:    */     }
/* 265:    */     
/* 266:    */     public boolean apply(T t)
/* 267:    */     {
/* 268:456 */       return this.target.equals(t);
/* 269:    */     }
/* 270:    */     
/* 271:    */     public int hashCode()
/* 272:    */     {
/* 273:461 */       return this.target.hashCode();
/* 274:    */     }
/* 275:    */     
/* 276:    */     public boolean equals(@Nullable Object obj)
/* 277:    */     {
/* 278:466 */       if ((obj instanceof IsEqualToPredicate))
/* 279:    */       {
/* 280:467 */         IsEqualToPredicate<?> that = (IsEqualToPredicate)obj;
/* 281:468 */         return this.target.equals(that.target);
/* 282:    */       }
/* 283:470 */       return false;
/* 284:    */     }
/* 285:    */     
/* 286:    */     public String toString()
/* 287:    */     {
/* 288:475 */       return "Predicates.equalTo(" + this.target + ")";
/* 289:    */     }
/* 290:    */   }
/* 291:    */   
/* 292:    */   @GwtIncompatible("Class.isInstance")
/* 293:    */   private static class InstanceOfPredicate
/* 294:    */     implements Predicate<Object>, Serializable
/* 295:    */   {
/* 296:    */     private final Class<?> clazz;
/* 297:    */     private static final long serialVersionUID = 0L;
/* 298:    */     
/* 299:    */     private InstanceOfPredicate(Class<?> clazz)
/* 300:    */     {
/* 301:487 */       this.clazz = ((Class)Preconditions.checkNotNull(clazz));
/* 302:    */     }
/* 303:    */     
/* 304:    */     public boolean apply(@Nullable Object o)
/* 305:    */     {
/* 306:492 */       return this.clazz.isInstance(o);
/* 307:    */     }
/* 308:    */     
/* 309:    */     public int hashCode()
/* 310:    */     {
/* 311:497 */       return this.clazz.hashCode();
/* 312:    */     }
/* 313:    */     
/* 314:    */     public boolean equals(@Nullable Object obj)
/* 315:    */     {
/* 316:502 */       if ((obj instanceof InstanceOfPredicate))
/* 317:    */       {
/* 318:503 */         InstanceOfPredicate that = (InstanceOfPredicate)obj;
/* 319:504 */         return this.clazz == that.clazz;
/* 320:    */       }
/* 321:506 */       return false;
/* 322:    */     }
/* 323:    */     
/* 324:    */     public String toString()
/* 325:    */     {
/* 326:511 */       return "Predicates.instanceOf(" + this.clazz.getName() + ")";
/* 327:    */     }
/* 328:    */   }
/* 329:    */   
/* 330:    */   @GwtIncompatible("Class.isAssignableFrom")
/* 331:    */   private static class AssignableFromPredicate
/* 332:    */     implements Predicate<Class<?>>, Serializable
/* 333:    */   {
/* 334:    */     private final Class<?> clazz;
/* 335:    */     private static final long serialVersionUID = 0L;
/* 336:    */     
/* 337:    */     private AssignableFromPredicate(Class<?> clazz)
/* 338:    */     {
/* 339:523 */       this.clazz = ((Class)Preconditions.checkNotNull(clazz));
/* 340:    */     }
/* 341:    */     
/* 342:    */     public boolean apply(Class<?> input)
/* 343:    */     {
/* 344:528 */       return this.clazz.isAssignableFrom(input);
/* 345:    */     }
/* 346:    */     
/* 347:    */     public int hashCode()
/* 348:    */     {
/* 349:533 */       return this.clazz.hashCode();
/* 350:    */     }
/* 351:    */     
/* 352:    */     public boolean equals(@Nullable Object obj)
/* 353:    */     {
/* 354:538 */       if ((obj instanceof AssignableFromPredicate))
/* 355:    */       {
/* 356:539 */         AssignableFromPredicate that = (AssignableFromPredicate)obj;
/* 357:540 */         return this.clazz == that.clazz;
/* 358:    */       }
/* 359:542 */       return false;
/* 360:    */     }
/* 361:    */     
/* 362:    */     public String toString()
/* 363:    */     {
/* 364:547 */       return "Predicates.assignableFrom(" + this.clazz.getName() + ")";
/* 365:    */     }
/* 366:    */   }
/* 367:    */   
/* 368:    */   private static class InPredicate<T>
/* 369:    */     implements Predicate<T>, Serializable
/* 370:    */   {
/* 371:    */     private final Collection<?> target;
/* 372:    */     private static final long serialVersionUID = 0L;
/* 373:    */     
/* 374:    */     private InPredicate(Collection<?> target)
/* 375:    */     {
/* 376:558 */       this.target = ((Collection)Preconditions.checkNotNull(target));
/* 377:    */     }
/* 378:    */     
/* 379:    */     public boolean apply(@Nullable T t)
/* 380:    */     {
/* 381:    */       try
/* 382:    */       {
/* 383:564 */         return this.target.contains(t);
/* 384:    */       }
/* 385:    */       catch (NullPointerException e)
/* 386:    */       {
/* 387:566 */         return false;
/* 388:    */       }
/* 389:    */       catch (ClassCastException e) {}
/* 390:568 */       return false;
/* 391:    */     }
/* 392:    */     
/* 393:    */     public boolean equals(@Nullable Object obj)
/* 394:    */     {
/* 395:574 */       if ((obj instanceof InPredicate))
/* 396:    */       {
/* 397:575 */         InPredicate<?> that = (InPredicate)obj;
/* 398:576 */         return this.target.equals(that.target);
/* 399:    */       }
/* 400:578 */       return false;
/* 401:    */     }
/* 402:    */     
/* 403:    */     public int hashCode()
/* 404:    */     {
/* 405:583 */       return this.target.hashCode();
/* 406:    */     }
/* 407:    */     
/* 408:    */     public String toString()
/* 409:    */     {
/* 410:588 */       return "Predicates.in(" + this.target + ")";
/* 411:    */     }
/* 412:    */   }
/* 413:    */   
/* 414:    */   private static class CompositionPredicate<A, B>
/* 415:    */     implements Predicate<A>, Serializable
/* 416:    */   {
/* 417:    */     final Predicate<B> p;
/* 418:    */     final Function<A, ? extends B> f;
/* 419:    */     private static final long serialVersionUID = 0L;
/* 420:    */     
/* 421:    */     private CompositionPredicate(Predicate<B> p, Function<A, ? extends B> f)
/* 422:    */     {
/* 423:600 */       this.p = ((Predicate)Preconditions.checkNotNull(p));
/* 424:601 */       this.f = ((Function)Preconditions.checkNotNull(f));
/* 425:    */     }
/* 426:    */     
/* 427:    */     public boolean apply(@Nullable A a)
/* 428:    */     {
/* 429:606 */       return this.p.apply(this.f.apply(a));
/* 430:    */     }
/* 431:    */     
/* 432:    */     public boolean equals(@Nullable Object obj)
/* 433:    */     {
/* 434:611 */       if ((obj instanceof CompositionPredicate))
/* 435:    */       {
/* 436:612 */         CompositionPredicate<?, ?> that = (CompositionPredicate)obj;
/* 437:613 */         return (this.f.equals(that.f)) && (this.p.equals(that.p));
/* 438:    */       }
/* 439:615 */       return false;
/* 440:    */     }
/* 441:    */     
/* 442:    */     public int hashCode()
/* 443:    */     {
/* 444:620 */       return this.f.hashCode() ^ this.p.hashCode();
/* 445:    */     }
/* 446:    */     
/* 447:    */     public String toString()
/* 448:    */     {
/* 449:626 */       return this.p + "(" + this.f + ")";
/* 450:    */     }
/* 451:    */   }
/* 452:    */   
/* 453:    */   @GwtIncompatible("Only used by other GWT-incompatible code.")
/* 454:    */   private static class ContainsPatternPredicate
/* 455:    */     implements Predicate<CharSequence>, Serializable
/* 456:    */   {
/* 457:    */     final Pattern pattern;
/* 458:    */     private static final long serialVersionUID = 0L;
/* 459:    */     
/* 460:    */     ContainsPatternPredicate(Pattern pattern)
/* 461:    */     {
/* 462:638 */       this.pattern = ((Pattern)Preconditions.checkNotNull(pattern));
/* 463:    */     }
/* 464:    */     
/* 465:    */     public boolean apply(CharSequence t)
/* 466:    */     {
/* 467:643 */       return this.pattern.matcher(t).find();
/* 468:    */     }
/* 469:    */     
/* 470:    */     public int hashCode()
/* 471:    */     {
/* 472:651 */       return Objects.hashCode(new Object[] { this.pattern.pattern(), Integer.valueOf(this.pattern.flags()) });
/* 473:    */     }
/* 474:    */     
/* 475:    */     public boolean equals(@Nullable Object obj)
/* 476:    */     {
/* 477:656 */       if ((obj instanceof ContainsPatternPredicate))
/* 478:    */       {
/* 479:657 */         ContainsPatternPredicate that = (ContainsPatternPredicate)obj;
/* 480:    */         
/* 481:    */ 
/* 482:    */ 
/* 483:661 */         return (Objects.equal(this.pattern.pattern(), that.pattern.pattern())) && (Objects.equal(Integer.valueOf(this.pattern.flags()), Integer.valueOf(that.pattern.flags())));
/* 484:    */       }
/* 485:664 */       return false;
/* 486:    */     }
/* 487:    */     
/* 488:    */     public String toString()
/* 489:    */     {
/* 490:669 */       String patternString = Objects.toStringHelper(this.pattern).add("pattern", this.pattern.pattern()).add("pattern.flags", this.pattern.flags()).toString();
/* 491:    */       
/* 492:    */ 
/* 493:    */ 
/* 494:673 */       return "Predicates.contains(" + patternString + ")";
/* 495:    */     }
/* 496:    */   }
/* 497:    */   
/* 498:    */   @GwtIncompatible("Only used by other GWT-incompatible code.")
/* 499:    */   private static class ContainsPatternFromStringPredicate
/* 500:    */     extends Predicates.ContainsPatternPredicate
/* 501:    */   {
/* 502:    */     private static final long serialVersionUID = 0L;
/* 503:    */     
/* 504:    */     ContainsPatternFromStringPredicate(String string)
/* 505:    */     {
/* 506:684 */       super();
/* 507:    */     }
/* 508:    */     
/* 509:    */     public String toString()
/* 510:    */     {
/* 511:689 */       return "Predicates.containsPattern(" + this.pattern.pattern() + ")";
/* 512:    */     }
/* 513:    */   }
/* 514:    */   
/* 515:    */   private static <T> List<Predicate<? super T>> asList(Predicate<? super T> first, Predicate<? super T> second)
/* 516:    */   {
/* 517:698 */     return Arrays.asList(new Predicate[] { first, second });
/* 518:    */   }
/* 519:    */   
/* 520:    */   private static <T> List<T> defensiveCopy(T... array)
/* 521:    */   {
/* 522:702 */     return defensiveCopy(Arrays.asList(array));
/* 523:    */   }
/* 524:    */   
/* 525:    */   static <T> List<T> defensiveCopy(Iterable<T> iterable)
/* 526:    */   {
/* 527:706 */     ArrayList<T> list = new ArrayList();
/* 528:707 */     for (T element : iterable) {
/* 529:708 */       list.add(Preconditions.checkNotNull(element));
/* 530:    */     }
/* 531:710 */     return list;
/* 532:    */   }
/* 533:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Predicates
 * JD-Core Version:    0.7.0.1
 */