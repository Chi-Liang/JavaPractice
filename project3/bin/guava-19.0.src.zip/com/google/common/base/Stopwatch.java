/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import java.util.Locale;
/*   6:    */ import java.util.concurrent.TimeUnit;
/*   7:    */ import javax.annotation.CheckReturnValue;
/*   8:    */ 
/*   9:    */ @GwtCompatible(emulated=true)
/*  10:    */ public final class Stopwatch
/*  11:    */ {
/*  12:    */   private final Ticker ticker;
/*  13:    */   private boolean isRunning;
/*  14:    */   private long elapsedNanos;
/*  15:    */   private long startTick;
/*  16:    */   
/*  17:    */   @CheckReturnValue
/*  18:    */   public static Stopwatch createUnstarted()
/*  19:    */   {
/*  20: 91 */     return new Stopwatch();
/*  21:    */   }
/*  22:    */   
/*  23:    */   @CheckReturnValue
/*  24:    */   public static Stopwatch createUnstarted(Ticker ticker)
/*  25:    */   {
/*  26:102 */     return new Stopwatch(ticker);
/*  27:    */   }
/*  28:    */   
/*  29:    */   @CheckReturnValue
/*  30:    */   public static Stopwatch createStarted()
/*  31:    */   {
/*  32:113 */     return new Stopwatch().start();
/*  33:    */   }
/*  34:    */   
/*  35:    */   @CheckReturnValue
/*  36:    */   public static Stopwatch createStarted(Ticker ticker)
/*  37:    */   {
/*  38:124 */     return new Stopwatch(ticker).start();
/*  39:    */   }
/*  40:    */   
/*  41:    */   Stopwatch()
/*  42:    */   {
/*  43:128 */     this.ticker = Ticker.systemTicker();
/*  44:    */   }
/*  45:    */   
/*  46:    */   Stopwatch(Ticker ticker)
/*  47:    */   {
/*  48:132 */     this.ticker = ((Ticker)Preconditions.checkNotNull(ticker, "ticker"));
/*  49:    */   }
/*  50:    */   
/*  51:    */   @CheckReturnValue
/*  52:    */   public boolean isRunning()
/*  53:    */   {
/*  54:142 */     return this.isRunning;
/*  55:    */   }
/*  56:    */   
/*  57:    */   public Stopwatch start()
/*  58:    */   {
/*  59:152 */     Preconditions.checkState(!this.isRunning, "This stopwatch is already running.");
/*  60:153 */     this.isRunning = true;
/*  61:154 */     this.startTick = this.ticker.read();
/*  62:155 */     return this;
/*  63:    */   }
/*  64:    */   
/*  65:    */   public Stopwatch stop()
/*  66:    */   {
/*  67:166 */     long tick = this.ticker.read();
/*  68:167 */     Preconditions.checkState(this.isRunning, "This stopwatch is already stopped.");
/*  69:168 */     this.isRunning = false;
/*  70:169 */     this.elapsedNanos += tick - this.startTick;
/*  71:170 */     return this;
/*  72:    */   }
/*  73:    */   
/*  74:    */   public Stopwatch reset()
/*  75:    */   {
/*  76:180 */     this.elapsedNanos = 0L;
/*  77:181 */     this.isRunning = false;
/*  78:182 */     return this;
/*  79:    */   }
/*  80:    */   
/*  81:    */   private long elapsedNanos()
/*  82:    */   {
/*  83:186 */     return this.isRunning ? this.ticker.read() - this.startTick + this.elapsedNanos : this.elapsedNanos;
/*  84:    */   }
/*  85:    */   
/*  86:    */   @CheckReturnValue
/*  87:    */   public long elapsed(TimeUnit desiredUnit)
/*  88:    */   {
/*  89:201 */     return desiredUnit.convert(elapsedNanos(), TimeUnit.NANOSECONDS);
/*  90:    */   }
/*  91:    */   
/*  92:    */   @GwtIncompatible("String.format()")
/*  93:    */   public String toString()
/*  94:    */   {
/*  95:210 */     long nanos = elapsedNanos();
/*  96:    */     
/*  97:212 */     TimeUnit unit = chooseUnit(nanos);
/*  98:213 */     double value = nanos / TimeUnit.NANOSECONDS.convert(1L, unit);
/*  99:    */     
/* 100:    */ 
/* 101:216 */     return String.format(Locale.ROOT, "%.4g %s", new Object[] { Double.valueOf(value), abbreviate(unit) });
/* 102:    */   }
/* 103:    */   
/* 104:    */   private static TimeUnit chooseUnit(long nanos)
/* 105:    */   {
/* 106:220 */     if (TimeUnit.DAYS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 107:221 */       return TimeUnit.DAYS;
/* 108:    */     }
/* 109:223 */     if (TimeUnit.HOURS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 110:224 */       return TimeUnit.HOURS;
/* 111:    */     }
/* 112:226 */     if (TimeUnit.MINUTES.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 113:227 */       return TimeUnit.MINUTES;
/* 114:    */     }
/* 115:229 */     if (TimeUnit.SECONDS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 116:230 */       return TimeUnit.SECONDS;
/* 117:    */     }
/* 118:232 */     if (TimeUnit.MILLISECONDS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 119:233 */       return TimeUnit.MILLISECONDS;
/* 120:    */     }
/* 121:235 */     if (TimeUnit.MICROSECONDS.convert(nanos, TimeUnit.NANOSECONDS) > 0L) {
/* 122:236 */       return TimeUnit.MICROSECONDS;
/* 123:    */     }
/* 124:238 */     return TimeUnit.NANOSECONDS;
/* 125:    */   }
/* 126:    */   
/* 127:    */   private static String abbreviate(TimeUnit unit)
/* 128:    */   {
/* 129:242 */     switch (1.$SwitchMap$java$util$concurrent$TimeUnit[unit.ordinal()])
/* 130:    */     {
/* 131:    */     case 1: 
/* 132:244 */       return "ns";
/* 133:    */     case 2: 
/* 134:246 */       return "μs";
/* 135:    */     case 3: 
/* 136:248 */       return "ms";
/* 137:    */     case 4: 
/* 138:250 */       return "s";
/* 139:    */     case 5: 
/* 140:252 */       return "min";
/* 141:    */     case 6: 
/* 142:254 */       return "h";
/* 143:    */     case 7: 
/* 144:256 */       return "d";
/* 145:    */     }
/* 146:258 */     throw new AssertionError();
/* 147:    */   }
/* 148:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Stopwatch
 * JD-Core Version:    0.7.0.1
 */