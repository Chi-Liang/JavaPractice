/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ import java.io.Serializable;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ @Beta
/*  9:   */ @GwtCompatible
/* 10:   */ final class FunctionalEquivalence<F, T>
/* 11:   */   extends Equivalence<F>
/* 12:   */   implements Serializable
/* 13:   */ {
/* 14:   */   private static final long serialVersionUID = 0L;
/* 15:   */   private final Function<F, ? extends T> function;
/* 16:   */   private final Equivalence<T> resultEquivalence;
/* 17:   */   
/* 18:   */   FunctionalEquivalence(Function<F, ? extends T> function, Equivalence<T> resultEquivalence)
/* 19:   */   {
/* 20:44 */     this.function = ((Function)Preconditions.checkNotNull(function));
/* 21:45 */     this.resultEquivalence = ((Equivalence)Preconditions.checkNotNull(resultEquivalence));
/* 22:   */   }
/* 23:   */   
/* 24:   */   protected boolean doEquivalent(F a, F b)
/* 25:   */   {
/* 26:50 */     return this.resultEquivalence.equivalent(this.function.apply(a), this.function.apply(b));
/* 27:   */   }
/* 28:   */   
/* 29:   */   protected int doHash(F a)
/* 30:   */   {
/* 31:55 */     return this.resultEquivalence.hash(this.function.apply(a));
/* 32:   */   }
/* 33:   */   
/* 34:   */   public boolean equals(@Nullable Object obj)
/* 35:   */   {
/* 36:60 */     if (obj == this) {
/* 37:61 */       return true;
/* 38:   */     }
/* 39:63 */     if ((obj instanceof FunctionalEquivalence))
/* 40:   */     {
/* 41:64 */       FunctionalEquivalence<?, ?> that = (FunctionalEquivalence)obj;
/* 42:65 */       return (this.function.equals(that.function)) && (this.resultEquivalence.equals(that.resultEquivalence));
/* 43:   */     }
/* 44:67 */     return false;
/* 45:   */   }
/* 46:   */   
/* 47:   */   public int hashCode()
/* 48:   */   {
/* 49:72 */     return Objects.hashCode(new Object[] { this.function, this.resultEquivalence });
/* 50:   */   }
/* 51:   */   
/* 52:   */   public String toString()
/* 53:   */   {
/* 54:77 */     return this.resultEquivalence + ".onResultOf(" + this.function + ")";
/* 55:   */   }
/* 56:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.FunctionalEquivalence
 * JD-Core Version:    0.7.0.1
 */