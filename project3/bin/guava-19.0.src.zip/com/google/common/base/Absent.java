/*   1:    */ 
/*   2:    */ 
/*   3:    */ com.google.common.annotations.GwtCompatible
/*   4:    */ java.util.Collections
/*   5:    */ java.util.Set
/*   6:    */ javax.annotation.Nullable
/*   7:    */ 
/*   8:    */ 
/*   9:    */ Absent
/*  10:    */   
/*  11:    */ 
/*  12: 33 */   INSTANCE = ()
/*  13:    */   serialVersionUID = 0L
/*  14:    */   
/*  15:    */   withType
/*  16:    */   
/*  17: 37 */     INSTANCE
/*  18:    */   
/*  19:    */   
/*  20:    */   isPresent
/*  21:    */   
/*  22: 44 */     
/*  23:    */   
/*  24:    */   
/*  25:    */   get
/*  26:    */   
/*  27: 49 */     "Optional.get() cannot be called on an absent value"
/*  28:    */   
/*  29:    */   
/*  30:    */   or
/*  31:    */   
/*  32: 54 */     checkNotNull, "use Optional.orNull() instead of Optional.or(null)"
/*  33:    */   
/*  34:    */   
/*  35:    */   or? 
/*  36:    */   
/*  37: 60 */     checkNotNull
/*  38:    */   
/*  39:    */   
/*  40:    */   or? 
/*  41:    */   
/*  42: 65 */     checkNotNullget(), "use Optional.orNull() instead of a Supplier that returns null"
/*  43:    */   
/*  44:    */   
/*  45:    */   
/*  46:    */   orNull
/*  47:    */   
/*  48: 72 */     
/*  49:    */   
/*  50:    */   
/*  51:    */   asSet
/*  52:    */   
/*  53: 77 */     emptySet()
/*  54:    */   
/*  55:    */   
/*  56:    */   transform? , 
/*  57:    */   
/*  58: 82 */     checkNotNull
/*  59: 83 */     absent()
/*  60:    */   
/*  61:    */   
/*  62:    */   equals
/*  63:    */   
/*  64: 88 */     ==
/*  65:    */   
/*  66:    */   
/*  67:    */   hashCode
/*  68:    */   
/*  69: 93 */     2040732332
/*  70:    */   
/*  71:    */   
/*  72:    */   toString
/*  73:    */   
/*  74: 98 */     "Optional.absent()"
/*  75:    */   
/*  76:    */   
/*  77:    */   readResolve
/*  78:    */   
/*  79:102 */     INSTANCE
/*  80:    */   
/*  81:    */ 


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Absent
 * JD-Core Version:    0.7.0.1
 */