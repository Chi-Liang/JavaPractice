/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import javax.annotation.Nullable;
/*   5:    */ 
/*   6:    */ @GwtCompatible
/*   7:    */ public final class Preconditions
/*   8:    */ {
/*   9:    */   public static void checkArgument(boolean expression)
/*  10:    */   {
/*  11:107 */     if (!expression) {
/*  12:108 */       throw new IllegalArgumentException();
/*  13:    */     }
/*  14:    */   }
/*  15:    */   
/*  16:    */   public static void checkArgument(boolean expression, @Nullable Object errorMessage)
/*  17:    */   {
/*  18:121 */     if (!expression) {
/*  19:122 */       throw new IllegalArgumentException(String.valueOf(errorMessage));
/*  20:    */     }
/*  21:    */   }
/*  22:    */   
/*  23:    */   public static void checkArgument(boolean expression, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs)
/*  24:    */   {
/*  25:145 */     if (!expression) {
/*  26:146 */       throw new IllegalArgumentException(format(errorMessageTemplate, errorMessageArgs));
/*  27:    */     }
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static void checkState(boolean expression)
/*  31:    */   {
/*  32:158 */     if (!expression) {
/*  33:159 */       throw new IllegalStateException();
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   public static void checkState(boolean expression, @Nullable Object errorMessage)
/*  38:    */   {
/*  39:173 */     if (!expression) {
/*  40:174 */       throw new IllegalStateException(String.valueOf(errorMessage));
/*  41:    */     }
/*  42:    */   }
/*  43:    */   
/*  44:    */   public static void checkState(boolean expression, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs)
/*  45:    */   {
/*  46:198 */     if (!expression) {
/*  47:199 */       throw new IllegalStateException(format(errorMessageTemplate, errorMessageArgs));
/*  48:    */     }
/*  49:    */   }
/*  50:    */   
/*  51:    */   public static <T> T checkNotNull(T reference)
/*  52:    */   {
/*  53:211 */     if (reference == null) {
/*  54:212 */       throw new NullPointerException();
/*  55:    */     }
/*  56:214 */     return reference;
/*  57:    */   }
/*  58:    */   
/*  59:    */   public static <T> T checkNotNull(T reference, @Nullable Object errorMessage)
/*  60:    */   {
/*  61:227 */     if (reference == null) {
/*  62:228 */       throw new NullPointerException(String.valueOf(errorMessage));
/*  63:    */     }
/*  64:230 */     return reference;
/*  65:    */   }
/*  66:    */   
/*  67:    */   public static <T> T checkNotNull(T reference, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs)
/*  68:    */   {
/*  69:249 */     if (reference == null) {
/*  70:251 */       throw new NullPointerException(format(errorMessageTemplate, errorMessageArgs));
/*  71:    */     }
/*  72:253 */     return reference;
/*  73:    */   }
/*  74:    */   
/*  75:    */   public static int checkElementIndex(int index, int size)
/*  76:    */   {
/*  77:293 */     return checkElementIndex(index, size, "index");
/*  78:    */   }
/*  79:    */   
/*  80:    */   public static int checkElementIndex(int index, int size, @Nullable String desc)
/*  81:    */   {
/*  82:309 */     if ((index < 0) || (index >= size)) {
/*  83:310 */       throw new IndexOutOfBoundsException(badElementIndex(index, size, desc));
/*  84:    */     }
/*  85:312 */     return index;
/*  86:    */   }
/*  87:    */   
/*  88:    */   private static String badElementIndex(int index, int size, String desc)
/*  89:    */   {
/*  90:316 */     if (index < 0) {
/*  91:317 */       return format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) });
/*  92:    */     }
/*  93:318 */     if (size < 0) {
/*  94:319 */       throw new IllegalArgumentException("negative size: " + size);
/*  95:    */     }
/*  96:321 */     return format("%s (%s) must be less than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) });
/*  97:    */   }
/*  98:    */   
/*  99:    */   public static int checkPositionIndex(int index, int size)
/* 100:    */   {
/* 101:336 */     return checkPositionIndex(index, size, "index");
/* 102:    */   }
/* 103:    */   
/* 104:    */   public static int checkPositionIndex(int index, int size, @Nullable String desc)
/* 105:    */   {
/* 106:352 */     if ((index < 0) || (index > size)) {
/* 107:353 */       throw new IndexOutOfBoundsException(badPositionIndex(index, size, desc));
/* 108:    */     }
/* 109:355 */     return index;
/* 110:    */   }
/* 111:    */   
/* 112:    */   private static String badPositionIndex(int index, int size, String desc)
/* 113:    */   {
/* 114:359 */     if (index < 0) {
/* 115:360 */       return format("%s (%s) must not be negative", new Object[] { desc, Integer.valueOf(index) });
/* 116:    */     }
/* 117:361 */     if (size < 0) {
/* 118:362 */       throw new IllegalArgumentException("negative size: " + size);
/* 119:    */     }
/* 120:364 */     return format("%s (%s) must not be greater than size (%s)", new Object[] { desc, Integer.valueOf(index), Integer.valueOf(size) });
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static void checkPositionIndexes(int start, int end, int size)
/* 124:    */   {
/* 125:382 */     if ((start < 0) || (end < start) || (end > size)) {
/* 126:383 */       throw new IndexOutOfBoundsException(badPositionIndexes(start, end, size));
/* 127:    */     }
/* 128:    */   }
/* 129:    */   
/* 130:    */   private static String badPositionIndexes(int start, int end, int size)
/* 131:    */   {
/* 132:388 */     if ((start < 0) || (start > size)) {
/* 133:389 */       return badPositionIndex(start, size, "start index");
/* 134:    */     }
/* 135:391 */     if ((end < 0) || (end > size)) {
/* 136:392 */       return badPositionIndex(end, size, "end index");
/* 137:    */     }
/* 138:395 */     return format("end index (%s) must not be less than start index (%s)", new Object[] { Integer.valueOf(end), Integer.valueOf(start) });
/* 139:    */   }
/* 140:    */   
/* 141:    */   static String format(String template, @Nullable Object... args)
/* 142:    */   {
/* 143:410 */     template = String.valueOf(template);
/* 144:    */     
/* 145:    */ 
/* 146:413 */     StringBuilder builder = new StringBuilder(template.length() + 16 * args.length);
/* 147:414 */     int templateStart = 0;
/* 148:415 */     int i = 0;
/* 149:416 */     while (i < args.length)
/* 150:    */     {
/* 151:417 */       int placeholderStart = template.indexOf("%s", templateStart);
/* 152:418 */       if (placeholderStart == -1) {
/* 153:    */         break;
/* 154:    */       }
/* 155:421 */       builder.append(template.substring(templateStart, placeholderStart));
/* 156:422 */       builder.append(args[(i++)]);
/* 157:423 */       templateStart = placeholderStart + 2;
/* 158:    */     }
/* 159:425 */     builder.append(template.substring(templateStart));
/* 160:428 */     if (i < args.length)
/* 161:    */     {
/* 162:429 */       builder.append(" [");
/* 163:430 */       builder.append(args[(i++)]);
/* 164:431 */       while (i < args.length)
/* 165:    */       {
/* 166:432 */         builder.append(", ");
/* 167:433 */         builder.append(args[(i++)]);
/* 168:    */       }
/* 169:435 */       builder.append(']');
/* 170:    */     }
/* 171:438 */     return builder.toString();
/* 172:    */   }
/* 173:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Preconditions
 * JD-Core Version:    0.7.0.1
 */