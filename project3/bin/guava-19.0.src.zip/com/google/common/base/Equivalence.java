/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import javax.annotation.CheckReturnValue;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @CheckReturnValue
/*  10:    */ @GwtCompatible
/*  11:    */ public abstract class Equivalence<T>
/*  12:    */ {
/*  13:    */   public final boolean equivalent(@Nullable T a, @Nullable T b)
/*  14:    */   {
/*  15: 67 */     if (a == b) {
/*  16: 68 */       return true;
/*  17:    */     }
/*  18: 70 */     if ((a == null) || (b == null)) {
/*  19: 71 */       return false;
/*  20:    */     }
/*  21: 73 */     return doEquivalent(a, b);
/*  22:    */   }
/*  23:    */   
/*  24:    */   protected abstract boolean doEquivalent(T paramT1, T paramT2);
/*  25:    */   
/*  26:    */   public final int hash(@Nullable T t)
/*  27:    */   {
/*  28:103 */     if (t == null) {
/*  29:104 */       return 0;
/*  30:    */     }
/*  31:106 */     return doHash(t);
/*  32:    */   }
/*  33:    */   
/*  34:    */   protected abstract int doHash(T paramT);
/*  35:    */   
/*  36:    */   public final <F> Equivalence<F> onResultOf(Function<F, ? extends T> function)
/*  37:    */   {
/*  38:142 */     return new FunctionalEquivalence(function, this);
/*  39:    */   }
/*  40:    */   
/*  41:    */   public final <S extends T> Wrapper<S> wrap(@Nullable S reference)
/*  42:    */   {
/*  43:153 */     return new Wrapper(this, reference, null);
/*  44:    */   }
/*  45:    */   
/*  46:    */   public static final class Wrapper<T>
/*  47:    */     implements Serializable
/*  48:    */   {
/*  49:    */     private final Equivalence<? super T> equivalence;
/*  50:    */     @Nullable
/*  51:    */     private final T reference;
/*  52:    */     private static final long serialVersionUID = 0L;
/*  53:    */     
/*  54:    */     private Wrapper(Equivalence<? super T> equivalence, @Nullable T reference)
/*  55:    */     {
/*  56:179 */       this.equivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/*  57:180 */       this.reference = reference;
/*  58:    */     }
/*  59:    */     
/*  60:    */     @Nullable
/*  61:    */     public T get()
/*  62:    */     {
/*  63:186 */       return this.reference;
/*  64:    */     }
/*  65:    */     
/*  66:    */     public boolean equals(@Nullable Object obj)
/*  67:    */     {
/*  68:196 */       if (obj == this) {
/*  69:197 */         return true;
/*  70:    */       }
/*  71:199 */       if ((obj instanceof Wrapper))
/*  72:    */       {
/*  73:200 */         Wrapper<?> that = (Wrapper)obj;
/*  74:202 */         if (this.equivalence.equals(that.equivalence))
/*  75:    */         {
/*  76:208 */           Equivalence<Object> equivalence = this.equivalence;
/*  77:209 */           return equivalence.equivalent(this.reference, that.reference);
/*  78:    */         }
/*  79:    */       }
/*  80:212 */       return false;
/*  81:    */     }
/*  82:    */     
/*  83:    */     public int hashCode()
/*  84:    */     {
/*  85:220 */       return this.equivalence.hash(this.reference);
/*  86:    */     }
/*  87:    */     
/*  88:    */     public String toString()
/*  89:    */     {
/*  90:229 */       return this.equivalence + ".wrap(" + this.reference + ")";
/*  91:    */     }
/*  92:    */   }
/*  93:    */   
/*  94:    */   @GwtCompatible(serializable=true)
/*  95:    */   public final <S extends T> Equivalence<Iterable<S>> pairwise()
/*  96:    */   {
/*  97:250 */     return new PairwiseEquivalence(this);
/*  98:    */   }
/*  99:    */   
/* 100:    */   @Beta
/* 101:    */   public final Predicate<T> equivalentTo(@Nullable T target)
/* 102:    */   {
/* 103:261 */     return new EquivalentToPredicate(this, target);
/* 104:    */   }
/* 105:    */   
/* 106:    */   private static final class EquivalentToPredicate<T>
/* 107:    */     implements Predicate<T>, Serializable
/* 108:    */   {
/* 109:    */     private final Equivalence<T> equivalence;
/* 110:    */     @Nullable
/* 111:    */     private final T target;
/* 112:    */     private static final long serialVersionUID = 0L;
/* 113:    */     
/* 114:    */     EquivalentToPredicate(Equivalence<T> equivalence, @Nullable T target)
/* 115:    */     {
/* 116:270 */       this.equivalence = ((Equivalence)Preconditions.checkNotNull(equivalence));
/* 117:271 */       this.target = target;
/* 118:    */     }
/* 119:    */     
/* 120:    */     public boolean apply(@Nullable T input)
/* 121:    */     {
/* 122:276 */       return this.equivalence.equivalent(input, this.target);
/* 123:    */     }
/* 124:    */     
/* 125:    */     public boolean equals(@Nullable Object obj)
/* 126:    */     {
/* 127:281 */       if (this == obj) {
/* 128:282 */         return true;
/* 129:    */       }
/* 130:284 */       if ((obj instanceof EquivalentToPredicate))
/* 131:    */       {
/* 132:285 */         EquivalentToPredicate<?> that = (EquivalentToPredicate)obj;
/* 133:286 */         return (this.equivalence.equals(that.equivalence)) && (Objects.equal(this.target, that.target));
/* 134:    */       }
/* 135:288 */       return false;
/* 136:    */     }
/* 137:    */     
/* 138:    */     public int hashCode()
/* 139:    */     {
/* 140:293 */       return Objects.hashCode(new Object[] { this.equivalence, this.target });
/* 141:    */     }
/* 142:    */     
/* 143:    */     public String toString()
/* 144:    */     {
/* 145:298 */       return this.equivalence + ".equivalentTo(" + this.target + ")";
/* 146:    */     }
/* 147:    */   }
/* 148:    */   
/* 149:    */   public static Equivalence<Object> equals()
/* 150:    */   {
/* 151:315 */     return Equals.INSTANCE;
/* 152:    */   }
/* 153:    */   
/* 154:    */   public static Equivalence<Object> identity()
/* 155:    */   {
/* 156:327 */     return Identity.INSTANCE;
/* 157:    */   }
/* 158:    */   
/* 159:    */   static final class Equals
/* 160:    */     extends Equivalence<Object>
/* 161:    */     implements Serializable
/* 162:    */   {
/* 163:332 */     static final Equals INSTANCE = new Equals();
/* 164:    */     private static final long serialVersionUID = 1L;
/* 165:    */     
/* 166:    */     protected boolean doEquivalent(Object a, Object b)
/* 167:    */     {
/* 168:336 */       return a.equals(b);
/* 169:    */     }
/* 170:    */     
/* 171:    */     protected int doHash(Object o)
/* 172:    */     {
/* 173:341 */       return o.hashCode();
/* 174:    */     }
/* 175:    */     
/* 176:    */     private Object readResolve()
/* 177:    */     {
/* 178:345 */       return INSTANCE;
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */   static final class Identity
/* 183:    */     extends Equivalence<Object>
/* 184:    */     implements Serializable
/* 185:    */   {
/* 186:353 */     static final Identity INSTANCE = new Identity();
/* 187:    */     private static final long serialVersionUID = 1L;
/* 188:    */     
/* 189:    */     protected boolean doEquivalent(Object a, Object b)
/* 190:    */     {
/* 191:357 */       return false;
/* 192:    */     }
/* 193:    */     
/* 194:    */     protected int doHash(Object o)
/* 195:    */     {
/* 196:362 */       return System.identityHashCode(o);
/* 197:    */     }
/* 198:    */     
/* 199:    */     private Object readResolve()
/* 200:    */     {
/* 201:366 */       return INSTANCE;
/* 202:    */     }
/* 203:    */   }
/* 204:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Equivalence
 * JD-Core Version:    0.7.0.1
 */