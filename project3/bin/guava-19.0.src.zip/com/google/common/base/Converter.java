/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import java.util.Iterator;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ @GwtCompatible
/*  11:    */ public abstract class Converter<A, B>
/*  12:    */   implements Function<A, B>
/*  13:    */ {
/*  14:    */   private final boolean handleNullAutomatically;
/*  15:    */   private transient Converter<B, A> reverse;
/*  16:    */   
/*  17:    */   protected Converter()
/*  18:    */   {
/*  19:124 */     this(true);
/*  20:    */   }
/*  21:    */   
/*  22:    */   Converter(boolean handleNullAutomatically)
/*  23:    */   {
/*  24:131 */     this.handleNullAutomatically = handleNullAutomatically;
/*  25:    */   }
/*  26:    */   
/*  27:    */   protected abstract B doForward(A paramA);
/*  28:    */   
/*  29:    */   protected abstract A doBackward(B paramB);
/*  30:    */   
/*  31:    */   @Nullable
/*  32:    */   public final B convert(@Nullable A a)
/*  33:    */   {
/*  34:168 */     return correctedDoForward(a);
/*  35:    */   }
/*  36:    */   
/*  37:    */   @Nullable
/*  38:    */   B correctedDoForward(@Nullable A a)
/*  39:    */   {
/*  40:173 */     if (this.handleNullAutomatically) {
/*  41:175 */       return a == null ? null : Preconditions.checkNotNull(doForward(a));
/*  42:    */     }
/*  43:177 */     return doForward(a);
/*  44:    */   }
/*  45:    */   
/*  46:    */   @Nullable
/*  47:    */   A correctedDoBackward(@Nullable B b)
/*  48:    */   {
/*  49:183 */     if (this.handleNullAutomatically) {
/*  50:185 */       return b == null ? null : Preconditions.checkNotNull(doBackward(b));
/*  51:    */     }
/*  52:187 */     return doBackward(b);
/*  53:    */   }
/*  54:    */   
/*  55:    */   public Iterable<B> convertAll(final Iterable<? extends A> fromIterable)
/*  56:    */   {
/*  57:200 */     Preconditions.checkNotNull(fromIterable, "fromIterable");
/*  58:201 */     new Iterable()
/*  59:    */     {
/*  60:    */       public Iterator<B> iterator()
/*  61:    */       {
/*  62:204 */         new Iterator()
/*  63:    */         {
/*  64:205 */           private final Iterator<? extends A> fromIterator = Converter.1.this.val$fromIterable.iterator();
/*  65:    */           
/*  66:    */           public boolean hasNext()
/*  67:    */           {
/*  68:209 */             return this.fromIterator.hasNext();
/*  69:    */           }
/*  70:    */           
/*  71:    */           public B next()
/*  72:    */           {
/*  73:214 */             return Converter.this.convert(this.fromIterator.next());
/*  74:    */           }
/*  75:    */           
/*  76:    */           public void remove()
/*  77:    */           {
/*  78:219 */             this.fromIterator.remove();
/*  79:    */           }
/*  80:    */         };
/*  81:    */       }
/*  82:    */     };
/*  83:    */   }
/*  84:    */   
/*  85:    */   public Converter<B, A> reverse()
/*  86:    */   {
/*  87:234 */     Converter<B, A> result = this.reverse;
/*  88:235 */     return result == null ? (this.reverse = new ReverseConverter(this)) : result;
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static final class ReverseConverter<A, B>
/*  92:    */     extends Converter<B, A>
/*  93:    */     implements Serializable
/*  94:    */   {
/*  95:    */     final Converter<A, B> original;
/*  96:    */     private static final long serialVersionUID = 0L;
/*  97:    */     
/*  98:    */     ReverseConverter(Converter<A, B> original)
/*  99:    */     {
/* 100:243 */       this.original = original;
/* 101:    */     }
/* 102:    */     
/* 103:    */     protected A doForward(B b)
/* 104:    */     {
/* 105:255 */       throw new AssertionError();
/* 106:    */     }
/* 107:    */     
/* 108:    */     protected B doBackward(A a)
/* 109:    */     {
/* 110:260 */       throw new AssertionError();
/* 111:    */     }
/* 112:    */     
/* 113:    */     @Nullable
/* 114:    */     A correctedDoForward(@Nullable B b)
/* 115:    */     {
/* 116:266 */       return this.original.correctedDoBackward(b);
/* 117:    */     }
/* 118:    */     
/* 119:    */     @Nullable
/* 120:    */     B correctedDoBackward(@Nullable A a)
/* 121:    */     {
/* 122:272 */       return this.original.correctedDoForward(a);
/* 123:    */     }
/* 124:    */     
/* 125:    */     public Converter<A, B> reverse()
/* 126:    */     {
/* 127:277 */       return this.original;
/* 128:    */     }
/* 129:    */     
/* 130:    */     public boolean equals(@Nullable Object object)
/* 131:    */     {
/* 132:282 */       if ((object instanceof ReverseConverter))
/* 133:    */       {
/* 134:283 */         ReverseConverter<?, ?> that = (ReverseConverter)object;
/* 135:284 */         return this.original.equals(that.original);
/* 136:    */       }
/* 137:286 */       return false;
/* 138:    */     }
/* 139:    */     
/* 140:    */     public int hashCode()
/* 141:    */     {
/* 142:291 */       return this.original.hashCode() ^ 0xFFFFFFFF;
/* 143:    */     }
/* 144:    */     
/* 145:    */     public String toString()
/* 146:    */     {
/* 147:296 */       return this.original + ".reverse()";
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public final <C> Converter<A, C> andThen(Converter<B, C> secondConverter)
/* 152:    */   {
/* 153:310 */     return doAndThen(secondConverter);
/* 154:    */   }
/* 155:    */   
/* 156:    */   <C> Converter<A, C> doAndThen(Converter<B, C> secondConverter)
/* 157:    */   {
/* 158:317 */     return new ConverterComposition(this, (Converter)Preconditions.checkNotNull(secondConverter));
/* 159:    */   }
/* 160:    */   
/* 161:    */   private static final class ConverterComposition<A, B, C>
/* 162:    */     extends Converter<A, C>
/* 163:    */     implements Serializable
/* 164:    */   {
/* 165:    */     final Converter<A, B> first;
/* 166:    */     final Converter<B, C> second;
/* 167:    */     private static final long serialVersionUID = 0L;
/* 168:    */     
/* 169:    */     ConverterComposition(Converter<A, B> first, Converter<B, C> second)
/* 170:    */     {
/* 171:326 */       this.first = first;
/* 172:327 */       this.second = second;
/* 173:    */     }
/* 174:    */     
/* 175:    */     protected C doForward(A a)
/* 176:    */     {
/* 177:339 */       throw new AssertionError();
/* 178:    */     }
/* 179:    */     
/* 180:    */     protected A doBackward(C c)
/* 181:    */     {
/* 182:344 */       throw new AssertionError();
/* 183:    */     }
/* 184:    */     
/* 185:    */     @Nullable
/* 186:    */     C correctedDoForward(@Nullable A a)
/* 187:    */     {
/* 188:350 */       return this.second.correctedDoForward(this.first.correctedDoForward(a));
/* 189:    */     }
/* 190:    */     
/* 191:    */     @Nullable
/* 192:    */     A correctedDoBackward(@Nullable C c)
/* 193:    */     {
/* 194:356 */       return this.first.correctedDoBackward(this.second.correctedDoBackward(c));
/* 195:    */     }
/* 196:    */     
/* 197:    */     public boolean equals(@Nullable Object object)
/* 198:    */     {
/* 199:361 */       if ((object instanceof ConverterComposition))
/* 200:    */       {
/* 201:362 */         ConverterComposition<?, ?, ?> that = (ConverterComposition)object;
/* 202:363 */         return (this.first.equals(that.first)) && (this.second.equals(that.second));
/* 203:    */       }
/* 204:365 */       return false;
/* 205:    */     }
/* 206:    */     
/* 207:    */     public int hashCode()
/* 208:    */     {
/* 209:370 */       return 31 * this.first.hashCode() + this.second.hashCode();
/* 210:    */     }
/* 211:    */     
/* 212:    */     public String toString()
/* 213:    */     {
/* 214:375 */       return this.first + ".andThen(" + this.second + ")";
/* 215:    */     }
/* 216:    */   }
/* 217:    */   
/* 218:    */   @Deprecated
/* 219:    */   @Nullable
/* 220:    */   public final B apply(@Nullable A a)
/* 221:    */   {
/* 222:388 */     return convert(a);
/* 223:    */   }
/* 224:    */   
/* 225:    */   public boolean equals(@Nullable Object object)
/* 226:    */   {
/* 227:404 */     return super.equals(object);
/* 228:    */   }
/* 229:    */   
/* 230:    */   public static <A, B> Converter<A, B> from(Function<? super A, ? extends B> forwardFunction, Function<? super B, ? extends A> backwardFunction)
/* 231:    */   {
/* 232:426 */     return new FunctionBasedConverter(forwardFunction, backwardFunction, null);
/* 233:    */   }
/* 234:    */   
/* 235:    */   private static final class FunctionBasedConverter<A, B>
/* 236:    */     extends Converter<A, B>
/* 237:    */     implements Serializable
/* 238:    */   {
/* 239:    */     private final Function<? super A, ? extends B> forwardFunction;
/* 240:    */     private final Function<? super B, ? extends A> backwardFunction;
/* 241:    */     
/* 242:    */     private FunctionBasedConverter(Function<? super A, ? extends B> forwardFunction, Function<? super B, ? extends A> backwardFunction)
/* 243:    */     {
/* 244:437 */       this.forwardFunction = ((Function)Preconditions.checkNotNull(forwardFunction));
/* 245:438 */       this.backwardFunction = ((Function)Preconditions.checkNotNull(backwardFunction));
/* 246:    */     }
/* 247:    */     
/* 248:    */     protected B doForward(A a)
/* 249:    */     {
/* 250:443 */       return this.forwardFunction.apply(a);
/* 251:    */     }
/* 252:    */     
/* 253:    */     protected A doBackward(B b)
/* 254:    */     {
/* 255:448 */       return this.backwardFunction.apply(b);
/* 256:    */     }
/* 257:    */     
/* 258:    */     public boolean equals(@Nullable Object object)
/* 259:    */     {
/* 260:453 */       if ((object instanceof FunctionBasedConverter))
/* 261:    */       {
/* 262:454 */         FunctionBasedConverter<?, ?> that = (FunctionBasedConverter)object;
/* 263:455 */         return (this.forwardFunction.equals(that.forwardFunction)) && (this.backwardFunction.equals(that.backwardFunction));
/* 264:    */       }
/* 265:458 */       return false;
/* 266:    */     }
/* 267:    */     
/* 268:    */     public int hashCode()
/* 269:    */     {
/* 270:463 */       return this.forwardFunction.hashCode() * 31 + this.backwardFunction.hashCode();
/* 271:    */     }
/* 272:    */     
/* 273:    */     public String toString()
/* 274:    */     {
/* 275:468 */       return "Converter.from(" + this.forwardFunction + ", " + this.backwardFunction + ")";
/* 276:    */     }
/* 277:    */   }
/* 278:    */   
/* 279:    */   public static <T> Converter<T, T> identity()
/* 280:    */   {
/* 281:477 */     return IdentityConverter.INSTANCE;
/* 282:    */   }
/* 283:    */   
/* 284:    */   private static final class IdentityConverter<T>
/* 285:    */     extends Converter<T, T>
/* 286:    */     implements Serializable
/* 287:    */   {
/* 288:485 */     static final IdentityConverter INSTANCE = new IdentityConverter();
/* 289:    */     private static final long serialVersionUID = 0L;
/* 290:    */     
/* 291:    */     protected T doForward(T t)
/* 292:    */     {
/* 293:489 */       return t;
/* 294:    */     }
/* 295:    */     
/* 296:    */     protected T doBackward(T t)
/* 297:    */     {
/* 298:494 */       return t;
/* 299:    */     }
/* 300:    */     
/* 301:    */     public IdentityConverter<T> reverse()
/* 302:    */     {
/* 303:499 */       return this;
/* 304:    */     }
/* 305:    */     
/* 306:    */     <S> Converter<T, S> doAndThen(Converter<T, S> otherConverter)
/* 307:    */     {
/* 308:504 */       return (Converter)Preconditions.checkNotNull(otherConverter, "otherConverter");
/* 309:    */     }
/* 310:    */     
/* 311:    */     public String toString()
/* 312:    */     {
/* 313:514 */       return "Converter.identity()";
/* 314:    */     }
/* 315:    */     
/* 316:    */     private Object readResolve()
/* 317:    */     {
/* 318:518 */       return INSTANCE;
/* 319:    */     }
/* 320:    */   }
/* 321:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Converter
 * JD-Core Version:    0.7.0.1
 */