/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import javax.annotation.Nullable;
/*   6:    */ 
/*   7:    */ @Beta
/*   8:    */ @GwtCompatible
/*   9:    */ public final class Verify
/*  10:    */ {
/*  11:    */   public static void verify(boolean expression)
/*  12:    */   {
/*  13: 99 */     if (!expression) {
/*  14:100 */       throw new VerifyException();
/*  15:    */     }
/*  16:    */   }
/*  17:    */   
/*  18:    */   public static void verify(boolean expression, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs)
/*  19:    */   {
/*  20:124 */     if (!expression) {
/*  21:125 */       throw new VerifyException(Preconditions.format(errorMessageTemplate, errorMessageArgs));
/*  22:    */     }
/*  23:    */   }
/*  24:    */   
/*  25:    */   public static <T> T verifyNotNull(@Nullable T reference)
/*  26:    */   {
/*  27:137 */     return verifyNotNull(reference, "expected a non-null reference", new Object[0]);
/*  28:    */   }
/*  29:    */   
/*  30:    */   public static <T> T verifyNotNull(@Nullable T reference, @Nullable String errorMessageTemplate, @Nullable Object... errorMessageArgs)
/*  31:    */   {
/*  32:160 */     verify(reference != null, errorMessageTemplate, errorMessageArgs);
/*  33:161 */     return reference;
/*  34:    */   }
/*  35:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Verify
 * JD-Core Version:    0.7.0.1
 */