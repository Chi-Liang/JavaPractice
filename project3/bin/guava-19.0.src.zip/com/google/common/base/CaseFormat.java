/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import java.io.Serializable;
/*   6:    */ import javax.annotation.CheckReturnValue;
/*   7:    */ import javax.annotation.Nullable;
/*   8:    */ 
/*   9:    */ @CheckReturnValue
/*  10:    */ @GwtCompatible
/*  11:    */ public enum CaseFormat
/*  12:    */ {
/*  13: 42 */   LOWER_HYPHEN(CharMatcher.is('-'), "-"),  LOWER_UNDERSCORE(CharMatcher.is('_'), "_"),  LOWER_CAMEL(CharMatcher.inRange('A', 'Z'), ""),  UPPER_CAMEL(CharMatcher.inRange('A', 'Z'), ""),  UPPER_UNDERSCORE(CharMatcher.is('_'), "_");
/*  14:    */   
/*  15:    */   private final CharMatcher wordBoundary;
/*  16:    */   private final String wordSeparator;
/*  17:    */   
/*  18:    */   private CaseFormat(CharMatcher wordBoundary, String wordSeparator)
/*  19:    */   {
/*  20:126 */     this.wordBoundary = wordBoundary;
/*  21:127 */     this.wordSeparator = wordSeparator;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public final String to(CaseFormat format, String str)
/*  25:    */   {
/*  26:136 */     Preconditions.checkNotNull(format);
/*  27:137 */     Preconditions.checkNotNull(str);
/*  28:138 */     return format == this ? str : convert(format, str);
/*  29:    */   }
/*  30:    */   
/*  31:    */   String convert(CaseFormat format, String s)
/*  32:    */   {
/*  33:146 */     StringBuilder out = null;
/*  34:147 */     int i = 0;
/*  35:148 */     int j = -1;
/*  36:149 */     while ((j = this.wordBoundary.indexIn(s, ++j)) != -1)
/*  37:    */     {
/*  38:150 */       if (i == 0)
/*  39:    */       {
/*  40:152 */         out = new StringBuilder(s.length() + 4 * this.wordSeparator.length());
/*  41:153 */         out.append(format.normalizeFirstWord(s.substring(i, j)));
/*  42:    */       }
/*  43:    */       else
/*  44:    */       {
/*  45:155 */         out.append(format.normalizeWord(s.substring(i, j)));
/*  46:    */       }
/*  47:157 */       out.append(format.wordSeparator);
/*  48:158 */       i = j + this.wordSeparator.length();
/*  49:    */     }
/*  50:160 */     return format.normalizeWord(s.substring(i));
/*  51:    */   }
/*  52:    */   
/*  53:    */   @Beta
/*  54:    */   public Converter<String, String> converterTo(CaseFormat targetFormat)
/*  55:    */   {
/*  56:172 */     return new StringConverter(this, targetFormat);
/*  57:    */   }
/*  58:    */   
/*  59:    */   abstract String normalizeWord(String paramString);
/*  60:    */   
/*  61:    */   private static final class StringConverter
/*  62:    */     extends Converter<String, String>
/*  63:    */     implements Serializable
/*  64:    */   {
/*  65:    */     private final CaseFormat sourceFormat;
/*  66:    */     private final CaseFormat targetFormat;
/*  67:    */     private static final long serialVersionUID = 0L;
/*  68:    */     
/*  69:    */     StringConverter(CaseFormat sourceFormat, CaseFormat targetFormat)
/*  70:    */     {
/*  71:182 */       this.sourceFormat = ((CaseFormat)Preconditions.checkNotNull(sourceFormat));
/*  72:183 */       this.targetFormat = ((CaseFormat)Preconditions.checkNotNull(targetFormat));
/*  73:    */     }
/*  74:    */     
/*  75:    */     protected String doForward(String s)
/*  76:    */     {
/*  77:188 */       return this.sourceFormat.to(this.targetFormat, s);
/*  78:    */     }
/*  79:    */     
/*  80:    */     protected String doBackward(String s)
/*  81:    */     {
/*  82:193 */       return this.targetFormat.to(this.sourceFormat, s);
/*  83:    */     }
/*  84:    */     
/*  85:    */     public boolean equals(@Nullable Object object)
/*  86:    */     {
/*  87:198 */       if ((object instanceof StringConverter))
/*  88:    */       {
/*  89:199 */         StringConverter that = (StringConverter)object;
/*  90:200 */         return (this.sourceFormat.equals(that.sourceFormat)) && (this.targetFormat.equals(that.targetFormat));
/*  91:    */       }
/*  92:202 */       return false;
/*  93:    */     }
/*  94:    */     
/*  95:    */     public int hashCode()
/*  96:    */     {
/*  97:207 */       return this.sourceFormat.hashCode() ^ this.targetFormat.hashCode();
/*  98:    */     }
/*  99:    */     
/* 100:    */     public String toString()
/* 101:    */     {
/* 102:212 */       return this.sourceFormat + ".converterTo(" + this.targetFormat + ")";
/* 103:    */     }
/* 104:    */   }
/* 105:    */   
/* 106:    */   private String normalizeFirstWord(String word)
/* 107:    */   {
/* 108:221 */     return this == LOWER_CAMEL ? Ascii.toLowerCase(word) : normalizeWord(word);
/* 109:    */   }
/* 110:    */   
/* 111:    */   private static String firstCharOnlyToUpper(String word)
/* 112:    */   {
/* 113:225 */     return word.length() + Ascii.toUpperCase(word.charAt(0)) + Ascii.toLowerCase(word.substring(1));
/* 114:    */   }
/* 115:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.CaseFormat
 * JD-Core Version:    0.7.0.1
 */