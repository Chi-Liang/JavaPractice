/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import javax.annotation.CheckReturnValue;
/*   6:    */ 
/*   7:    */ @CheckReturnValue
/*   8:    */ @GwtCompatible
/*   9:    */ public final class Ascii
/*  10:    */ {
/*  11:    */   public static final byte NUL = 0;
/*  12:    */   public static final byte SOH = 1;
/*  13:    */   public static final byte STX = 2;
/*  14:    */   public static final byte ETX = 3;
/*  15:    */   public static final byte EOT = 4;
/*  16:    */   public static final byte ENQ = 5;
/*  17:    */   public static final byte ACK = 6;
/*  18:    */   public static final byte BEL = 7;
/*  19:    */   public static final byte BS = 8;
/*  20:    */   public static final byte HT = 9;
/*  21:    */   public static final byte LF = 10;
/*  22:    */   public static final byte NL = 10;
/*  23:    */   public static final byte VT = 11;
/*  24:    */   public static final byte FF = 12;
/*  25:    */   public static final byte CR = 13;
/*  26:    */   public static final byte SO = 14;
/*  27:    */   public static final byte SI = 15;
/*  28:    */   public static final byte DLE = 16;
/*  29:    */   public static final byte DC1 = 17;
/*  30:    */   public static final byte XON = 17;
/*  31:    */   public static final byte DC2 = 18;
/*  32:    */   public static final byte DC3 = 19;
/*  33:    */   public static final byte XOFF = 19;
/*  34:    */   public static final byte DC4 = 20;
/*  35:    */   public static final byte NAK = 21;
/*  36:    */   public static final byte SYN = 22;
/*  37:    */   public static final byte ETB = 23;
/*  38:    */   public static final byte CAN = 24;
/*  39:    */   public static final byte EM = 25;
/*  40:    */   public static final byte SUB = 26;
/*  41:    */   public static final byte ESC = 27;
/*  42:    */   public static final byte FS = 28;
/*  43:    */   public static final byte GS = 29;
/*  44:    */   public static final byte RS = 30;
/*  45:    */   public static final byte US = 31;
/*  46:    */   public static final byte SP = 32;
/*  47:    */   public static final byte SPACE = 32;
/*  48:    */   public static final byte DEL = 127;
/*  49:    */   public static final char MIN = '\000';
/*  50:    */   public static final char MAX = '';
/*  51:    */   
/*  52:    */   public static String toLowerCase(String string)
/*  53:    */   {
/*  54:439 */     int length = string.length();
/*  55:440 */     for (int i = 0; i < length; i++) {
/*  56:441 */       if (isUpperCase(string.charAt(i)))
/*  57:    */       {
/*  58:442 */         char[] chars = string.toCharArray();
/*  59:443 */         for (; i < length; i++)
/*  60:    */         {
/*  61:444 */           char c = chars[i];
/*  62:445 */           if (isUpperCase(c)) {
/*  63:446 */             chars[i] = ((char)(c ^ 0x20));
/*  64:    */           }
/*  65:    */         }
/*  66:449 */         return String.valueOf(chars);
/*  67:    */       }
/*  68:    */     }
/*  69:452 */     return string;
/*  70:    */   }
/*  71:    */   
/*  72:    */   public static String toLowerCase(CharSequence chars)
/*  73:    */   {
/*  74:463 */     if ((chars instanceof String)) {
/*  75:464 */       return toLowerCase((String)chars);
/*  76:    */     }
/*  77:466 */     int length = chars.length();
/*  78:467 */     StringBuilder builder = new StringBuilder(length);
/*  79:468 */     for (int i = 0; i < length; i++) {
/*  80:469 */       builder.append(toLowerCase(chars.charAt(i)));
/*  81:    */     }
/*  82:471 */     return builder.toString();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public static char toLowerCase(char c)
/*  86:    */   {
/*  87:479 */     return isUpperCase(c) ? (char)(c ^ 0x20) : c;
/*  88:    */   }
/*  89:    */   
/*  90:    */   public static String toUpperCase(String string)
/*  91:    */   {
/*  92:488 */     int length = string.length();
/*  93:489 */     for (int i = 0; i < length; i++) {
/*  94:490 */       if (isLowerCase(string.charAt(i)))
/*  95:    */       {
/*  96:491 */         char[] chars = string.toCharArray();
/*  97:492 */         for (; i < length; i++)
/*  98:    */         {
/*  99:493 */           char c = chars[i];
/* 100:494 */           if (isLowerCase(c)) {
/* 101:495 */             chars[i] = ((char)(c & 0x5F));
/* 102:    */           }
/* 103:    */         }
/* 104:498 */         return String.valueOf(chars);
/* 105:    */       }
/* 106:    */     }
/* 107:501 */     return string;
/* 108:    */   }
/* 109:    */   
/* 110:    */   public static String toUpperCase(CharSequence chars)
/* 111:    */   {
/* 112:512 */     if ((chars instanceof String)) {
/* 113:513 */       return toUpperCase((String)chars);
/* 114:    */     }
/* 115:515 */     int length = chars.length();
/* 116:516 */     StringBuilder builder = new StringBuilder(length);
/* 117:517 */     for (int i = 0; i < length; i++) {
/* 118:518 */       builder.append(toUpperCase(chars.charAt(i)));
/* 119:    */     }
/* 120:520 */     return builder.toString();
/* 121:    */   }
/* 122:    */   
/* 123:    */   public static char toUpperCase(char c)
/* 124:    */   {
/* 125:528 */     return isLowerCase(c) ? (char)(c & 0x5F) : c;
/* 126:    */   }
/* 127:    */   
/* 128:    */   public static boolean isLowerCase(char c)
/* 129:    */   {
/* 130:539 */     return (c >= 'a') && (c <= 'z');
/* 131:    */   }
/* 132:    */   
/* 133:    */   public static boolean isUpperCase(char c)
/* 134:    */   {
/* 135:548 */     return (c >= 'A') && (c <= 'Z');
/* 136:    */   }
/* 137:    */   
/* 138:    */   @Beta
/* 139:    */   public static String truncate(CharSequence seq, int maxLength, String truncationIndicator)
/* 140:    */   {
/* 141:585 */     Preconditions.checkNotNull(seq);
/* 142:    */     
/* 143:    */ 
/* 144:588 */     int truncationLength = maxLength - truncationIndicator.length();
/* 145:    */     
/* 146:    */ 
/* 147:    */ 
/* 148:592 */     Preconditions.checkArgument(truncationLength >= 0, "maxLength (%s) must be >= length of the truncation indicator (%s)", new Object[] { Integer.valueOf(maxLength), Integer.valueOf(truncationIndicator.length()) });
/* 149:598 */     if (seq.length() <= maxLength)
/* 150:    */     {
/* 151:599 */       String string = seq.toString();
/* 152:600 */       if (string.length() <= maxLength) {
/* 153:601 */         return string;
/* 154:    */       }
/* 155:604 */       seq = string;
/* 156:    */     }
/* 157:607 */     return truncationIndicator;
/* 158:    */   }
/* 159:    */   
/* 160:    */   @Beta
/* 161:    */   public static boolean equalsIgnoreCase(CharSequence s1, CharSequence s2)
/* 162:    */   {
/* 163:636 */     int length = s1.length();
/* 164:637 */     if (s1 == s2) {
/* 165:638 */       return true;
/* 166:    */     }
/* 167:640 */     if (length != s2.length()) {
/* 168:641 */       return false;
/* 169:    */     }
/* 170:643 */     for (int i = 0; i < length; i++)
/* 171:    */     {
/* 172:644 */       char c1 = s1.charAt(i);
/* 173:645 */       char c2 = s2.charAt(i);
/* 174:646 */       if (c1 != c2)
/* 175:    */       {
/* 176:649 */         int alphaIndex = getAlphaIndex(c1);
/* 177:652 */         if ((alphaIndex >= 26) || (alphaIndex != getAlphaIndex(c2))) {
/* 178:655 */           return false;
/* 179:    */         }
/* 180:    */       }
/* 181:    */     }
/* 182:657 */     return true;
/* 183:    */   }
/* 184:    */   
/* 185:    */   private static int getAlphaIndex(char c)
/* 186:    */   {
/* 187:667 */     return (char)((c | 0x20) - 'a');
/* 188:    */   }
/* 189:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.Ascii
 * JD-Core Version:    0.7.0.1
 */