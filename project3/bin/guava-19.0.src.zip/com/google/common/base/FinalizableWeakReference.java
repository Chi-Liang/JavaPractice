/*  1:   */ package com.google.common.base;
/*  2:   */ 
/*  3:   */ import java.lang.ref.WeakReference;
/*  4:   */ 
/*  5:   */ public abstract class FinalizableWeakReference<T>
/*  6:   */   extends WeakReference<T>
/*  7:   */   implements FinalizableReference
/*  8:   */ {
/*  9:   */   protected FinalizableWeakReference(T referent, FinalizableReferenceQueue queue)
/* 10:   */   {
/* 11:39 */     super(referent, queue.queue);
/* 12:40 */     queue.cleanUp();
/* 13:   */   }
/* 14:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.FinalizableWeakReference
 * JD-Core Version:    0.7.0.1
 */