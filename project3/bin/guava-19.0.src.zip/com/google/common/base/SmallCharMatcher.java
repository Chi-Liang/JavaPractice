/*   1:    */ package com.google.common.base;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtIncompatible;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import java.util.BitSet;
/*   6:    */ 
/*   7:    */ @GwtIncompatible("no precomputation is done in GWT")
/*   8:    */ final class SmallCharMatcher
/*   9:    */   extends CharMatcher.NamedFastMatcher
/*  10:    */ {
/*  11:    */   static final int MAX_SIZE = 1023;
/*  12:    */   private final char[] table;
/*  13:    */   private final boolean containsZero;
/*  14:    */   private final long filter;
/*  15:    */   private static final int C1 = -862048943;
/*  16:    */   private static final int C2 = 461845907;
/*  17:    */   private static final double DESIRED_LOAD_FACTOR = 0.5D;
/*  18:    */   
/*  19:    */   private SmallCharMatcher(char[] table, long filter, boolean containsZero, String description)
/*  20:    */   {
/*  21: 39 */     super(description);
/*  22: 40 */     this.table = table;
/*  23: 41 */     this.filter = filter;
/*  24: 42 */     this.containsZero = containsZero;
/*  25:    */   }
/*  26:    */   
/*  27:    */   static int smear(int hashCode)
/*  28:    */   {
/*  29: 57 */     return 461845907 * Integer.rotateLeft(hashCode * -862048943, 15);
/*  30:    */   }
/*  31:    */   
/*  32:    */   private boolean checkFilter(int c)
/*  33:    */   {
/*  34: 61 */     return 1L == (1L & this.filter >> c);
/*  35:    */   }
/*  36:    */   
/*  37:    */   @VisibleForTesting
/*  38:    */   static int chooseTableSize(int setSize)
/*  39:    */   {
/*  40: 78 */     if (setSize == 1) {
/*  41: 79 */       return 2;
/*  42:    */     }
/*  43: 83 */     int tableSize = Integer.highestOneBit(setSize - 1) << 1;
/*  44: 84 */     while (tableSize * 0.5D < setSize) {
/*  45: 85 */       tableSize <<= 1;
/*  46:    */     }
/*  47: 87 */     return tableSize;
/*  48:    */   }
/*  49:    */   
/*  50:    */   static CharMatcher from(BitSet chars, String description)
/*  51:    */   {
/*  52: 92 */     long filter = 0L;
/*  53: 93 */     int size = chars.cardinality();
/*  54: 94 */     boolean containsZero = chars.get(0);
/*  55:    */     
/*  56: 96 */     char[] table = new char[chooseTableSize(size)];
/*  57: 97 */     int mask = table.length - 1;
/*  58: 98 */     for (int c = chars.nextSetBit(0); c != -1; c = chars.nextSetBit(c + 1))
/*  59:    */     {
/*  60:100 */       filter |= 1L << c;
/*  61:101 */       int index = smear(c) & mask;
/*  62:    */       for (;;)
/*  63:    */       {
/*  64:104 */         if (table[index] == 0)
/*  65:    */         {
/*  66:105 */           table[index] = ((char)c);
/*  67:106 */           break;
/*  68:    */         }
/*  69:109 */         index = index + 1 & mask;
/*  70:    */       }
/*  71:    */     }
/*  72:112 */     return new SmallCharMatcher(table, filter, containsZero, description);
/*  73:    */   }
/*  74:    */   
/*  75:    */   public boolean matches(char c)
/*  76:    */   {
/*  77:117 */     if (c == 0) {
/*  78:118 */       return this.containsZero;
/*  79:    */     }
/*  80:120 */     if (!checkFilter(c)) {
/*  81:121 */       return false;
/*  82:    */     }
/*  83:123 */     int mask = this.table.length - 1;
/*  84:124 */     int startingIndex = smear(c) & mask;
/*  85:125 */     int index = startingIndex;
/*  86:    */     do
/*  87:    */     {
/*  88:128 */       if (this.table[index] == 0) {
/*  89:129 */         return false;
/*  90:    */       }
/*  91:131 */       if (this.table[index] == c) {
/*  92:132 */         return true;
/*  93:    */       }
/*  94:135 */       index = index + 1 & mask;
/*  95:138 */     } while (index != startingIndex);
/*  96:139 */     return false;
/*  97:    */   }
/*  98:    */   
/*  99:    */   void setBits(BitSet table)
/* 100:    */   {
/* 101:144 */     if (this.containsZero) {
/* 102:145 */       table.set(0);
/* 103:    */     }
/* 104:147 */     for (char c : this.table) {
/* 105:148 */       if (c != 0) {
/* 106:149 */         table.set(c);
/* 107:    */       }
/* 108:    */     }
/* 109:    */   }
/* 110:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.base.SmallCharMatcher
 * JD-Core Version:    0.7.0.1
 */