/*  1:   */ package com.google.common.reflect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.lang.reflect.InvocationHandler;
/*  6:   */ import java.lang.reflect.Proxy;
/*  7:   */ 
/*  8:   */ @Beta
/*  9:   */ public final class Reflection
/* 10:   */ {
/* 11:   */   public static String getPackageName(Class<?> clazz)
/* 12:   */   {
/* 13:41 */     return getPackageName(clazz.getName());
/* 14:   */   }
/* 15:   */   
/* 16:   */   public static String getPackageName(String classFullName)
/* 17:   */   {
/* 18:50 */     int lastDot = classFullName.lastIndexOf('.');
/* 19:51 */     return lastDot < 0 ? "" : classFullName.substring(0, lastDot);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public static void initialize(Class<?>... classes)
/* 23:   */   {
/* 24:67 */     for (Class<?> clazz : classes) {
/* 25:   */       try
/* 26:   */       {
/* 27:69 */         Class.forName(clazz.getName(), true, clazz.getClassLoader());
/* 28:   */       }
/* 29:   */       catch (ClassNotFoundException e)
/* 30:   */       {
/* 31:71 */         throw new AssertionError(e);
/* 32:   */       }
/* 33:   */     }
/* 34:   */   }
/* 35:   */   
/* 36:   */   public static <T> T newProxy(Class<T> interfaceType, InvocationHandler handler)
/* 37:   */   {
/* 38:88 */     Preconditions.checkNotNull(handler);
/* 39:89 */     Preconditions.checkArgument(interfaceType.isInterface(), "%s is not an interface", new Object[] { interfaceType });
/* 40:90 */     Object object = Proxy.newProxyInstance(interfaceType.getClassLoader(), new Class[] { interfaceType }, handler);
/* 41:   */     
/* 42:   */ 
/* 43:   */ 
/* 44:94 */     return interfaceType.cast(object);
/* 45:   */   }
/* 46:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.Reflection
 * JD-Core Version:    0.7.0.1
 */