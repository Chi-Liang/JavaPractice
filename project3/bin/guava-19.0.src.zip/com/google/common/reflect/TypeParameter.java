/*  1:   */ package com.google.common.reflect;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.lang.reflect.Type;
/*  6:   */ import java.lang.reflect.TypeVariable;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @Beta
/* 10:   */ public abstract class TypeParameter<T>
/* 11:   */   extends TypeCapture<T>
/* 12:   */ {
/* 13:   */   final TypeVariable<?> typeVariable;
/* 14:   */   
/* 15:   */   protected TypeParameter()
/* 16:   */   {
/* 17:47 */     Type type = capture();
/* 18:48 */     Preconditions.checkArgument(type instanceof TypeVariable, "%s should be a type variable.", new Object[] { type });
/* 19:49 */     this.typeVariable = ((TypeVariable)type);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public final int hashCode()
/* 23:   */   {
/* 24:53 */     return this.typeVariable.hashCode();
/* 25:   */   }
/* 26:   */   
/* 27:   */   public final boolean equals(@Nullable Object o)
/* 28:   */   {
/* 29:57 */     if ((o instanceof TypeParameter))
/* 30:   */     {
/* 31:58 */       TypeParameter<?> that = (TypeParameter)o;
/* 32:59 */       return this.typeVariable.equals(that.typeVariable);
/* 33:   */     }
/* 34:61 */     return false;
/* 35:   */   }
/* 36:   */   
/* 37:   */   public String toString()
/* 38:   */   {
/* 39:65 */     return this.typeVariable.toString();
/* 40:   */   }
/* 41:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.TypeParameter
 * JD-Core Version:    0.7.0.1
 */