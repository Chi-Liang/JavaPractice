/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Joiner;
/*   6:    */ import com.google.common.base.Objects;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Predicates;
/*   9:    */ import com.google.common.collect.ImmutableList;
/*  10:    */ import com.google.common.collect.ImmutableList.Builder;
/*  11:    */ import com.google.common.collect.ImmutableMap;
/*  12:    */ import com.google.common.collect.ImmutableMap.Builder;
/*  13:    */ import com.google.common.collect.Iterables;
/*  14:    */ import java.io.Serializable;
/*  15:    */ import java.lang.reflect.AnnotatedElement;
/*  16:    */ import java.lang.reflect.Array;
/*  17:    */ import java.lang.reflect.GenericArrayType;
/*  18:    */ import java.lang.reflect.GenericDeclaration;
/*  19:    */ import java.lang.reflect.InvocationHandler;
/*  20:    */ import java.lang.reflect.InvocationTargetException;
/*  21:    */ import java.lang.reflect.Method;
/*  22:    */ import java.lang.reflect.ParameterizedType;
/*  23:    */ import java.lang.reflect.Proxy;
/*  24:    */ import java.lang.reflect.Type;
/*  25:    */ import java.lang.reflect.TypeVariable;
/*  26:    */ import java.lang.reflect.WildcardType;
/*  27:    */ import java.security.AccessControlException;
/*  28:    */ import java.util.Arrays;
/*  29:    */ import java.util.Collection;
/*  30:    */ import java.util.concurrent.atomic.AtomicReference;
/*  31:    */ import javax.annotation.Nullable;
/*  32:    */ 
/*  33:    */ final class Types
/*  34:    */ {
/*  35: 60 */   private static final Function<Type, String> TYPE_NAME = new Function()
/*  36:    */   {
/*  37:    */     public String apply(Type from)
/*  38:    */     {
/*  39: 63 */       return Types.JavaVersion.CURRENT.typeName(from);
/*  40:    */     }
/*  41:    */   };
/*  42: 67 */   private static final Joiner COMMA_JOINER = Joiner.on(", ").useForNull("null");
/*  43:    */   
/*  44:    */   static Type newArrayType(Type componentType)
/*  45:    */   {
/*  46: 71 */     if ((componentType instanceof WildcardType))
/*  47:    */     {
/*  48: 72 */       WildcardType wildcard = (WildcardType)componentType;
/*  49: 73 */       Type[] lowerBounds = wildcard.getLowerBounds();
/*  50: 74 */       Preconditions.checkArgument(lowerBounds.length <= 1, "Wildcard cannot have more than one lower bounds.");
/*  51: 75 */       if (lowerBounds.length == 1) {
/*  52: 76 */         return supertypeOf(newArrayType(lowerBounds[0]));
/*  53:    */       }
/*  54: 78 */       Type[] upperBounds = wildcard.getUpperBounds();
/*  55: 79 */       Preconditions.checkArgument(upperBounds.length == 1, "Wildcard should have only one upper bound.");
/*  56: 80 */       return subtypeOf(newArrayType(upperBounds[0]));
/*  57:    */     }
/*  58: 83 */     return JavaVersion.CURRENT.newArrayType(componentType);
/*  59:    */   }
/*  60:    */   
/*  61:    */   static ParameterizedType newParameterizedTypeWithOwner(@Nullable Type ownerType, Class<?> rawType, Type... arguments)
/*  62:    */   {
/*  63: 92 */     if (ownerType == null) {
/*  64: 93 */       return newParameterizedType(rawType, arguments);
/*  65:    */     }
/*  66: 96 */     Preconditions.checkNotNull(arguments);
/*  67: 97 */     Preconditions.checkArgument(rawType.getEnclosingClass() != null, "Owner type for unenclosed %s", new Object[] { rawType });
/*  68: 98 */     return new ParameterizedTypeImpl(ownerType, rawType, arguments);
/*  69:    */   }
/*  70:    */   
/*  71:    */   static ParameterizedType newParameterizedType(Class<?> rawType, Type... arguments)
/*  72:    */   {
/*  73:106 */     return new ParameterizedTypeImpl(ClassOwnership.JVM_BEHAVIOR.getOwnerType(rawType), rawType, arguments);
/*  74:    */   }
/*  75:    */   
/*  76:    */   private static abstract enum ClassOwnership
/*  77:    */   {
/*  78:113 */     OWNED_BY_ENCLOSING_CLASS,  LOCAL_CLASS_HAS_NO_OWNER;
/*  79:    */     
/*  80:134 */     static final ClassOwnership JVM_BEHAVIOR = detectJvmBehavior();
/*  81:    */     
/*  82:    */     private ClassOwnership() {}
/*  83:    */     
/*  84:    */     @Nullable
/*  85:    */     abstract Class<?> getOwnerType(Class<?> paramClass);
/*  86:    */     
/*  87:    */     private static ClassOwnership detectJvmBehavior()
/*  88:    */     {
/*  89:138 */       Class<?> subclass = new 1LocalClass() {}.getClass();
/*  90:139 */       ParameterizedType parameterizedType = (ParameterizedType)subclass.getGenericSuperclass();
/*  91:141 */       for (ClassOwnership behavior : values()) {
/*  92:142 */         if (behavior.getOwnerType(1LocalClass.class) == parameterizedType.getOwnerType()) {
/*  93:143 */           return behavior;
/*  94:    */         }
/*  95:    */       }
/*  96:146 */       throw new AssertionError();
/*  97:    */     }
/*  98:    */   }
/*  99:    */   
/* 100:    */   static <D extends GenericDeclaration> TypeVariable<D> newArtificialTypeVariable(D declaration, String name, Type... bounds)
/* 101:    */   {
/* 102:156 */     return newTypeVariableImpl(declaration, name, bounds.length == 0 ? new Type[] { Object.class } : bounds);
/* 103:    */   }
/* 104:    */   
/* 105:    */   @VisibleForTesting
/* 106:    */   static WildcardType subtypeOf(Type upperBound)
/* 107:    */   {
/* 108:166 */     return new WildcardTypeImpl(new Type[0], new Type[] { upperBound });
/* 109:    */   }
/* 110:    */   
/* 111:    */   @VisibleForTesting
/* 112:    */   static WildcardType supertypeOf(Type lowerBound)
/* 113:    */   {
/* 114:171 */     return new WildcardTypeImpl(new Type[] { lowerBound }, new Type[] { Object.class });
/* 115:    */   }
/* 116:    */   
/* 117:    */   static String toString(Type type)
/* 118:    */   {
/* 119:184 */     return (type instanceof Class) ? ((Class)type).getName() : type.toString();
/* 120:    */   }
/* 121:    */   
/* 122:    */   @Nullable
/* 123:    */   static Type getComponentType(Type type)
/* 124:    */   {
/* 125:190 */     Preconditions.checkNotNull(type);
/* 126:191 */     AtomicReference<Type> result = new AtomicReference();
/* 127:192 */     new TypeVisitor()
/* 128:    */     {
/* 129:    */       void visitTypeVariable(TypeVariable<?> t)
/* 130:    */       {
/* 131:194 */         this.val$result.set(Types.subtypeOfComponentType(t.getBounds()));
/* 132:    */       }
/* 133:    */       
/* 134:    */       void visitWildcardType(WildcardType t)
/* 135:    */       {
/* 136:197 */         this.val$result.set(Types.subtypeOfComponentType(t.getUpperBounds()));
/* 137:    */       }
/* 138:    */       
/* 139:    */       void visitGenericArrayType(GenericArrayType t)
/* 140:    */       {
/* 141:200 */         this.val$result.set(t.getGenericComponentType());
/* 142:    */       }
/* 143:    */       
/* 144:    */       void visitClass(Class<?> t)
/* 145:    */       {
/* 146:203 */         this.val$result.set(t.getComponentType());
/* 147:    */       }
/* 148:203 */     }.visit(new Type[] { type });
/* 149:    */     
/* 150:    */ 
/* 151:206 */     return (Type)result.get();
/* 152:    */   }
/* 153:    */   
/* 154:    */   @Nullable
/* 155:    */   private static Type subtypeOfComponentType(Type[] bounds)
/* 156:    */   {
/* 157:214 */     for (Type bound : bounds)
/* 158:    */     {
/* 159:215 */       Type componentType = getComponentType(bound);
/* 160:216 */       if (componentType != null)
/* 161:    */       {
/* 162:219 */         if ((componentType instanceof Class))
/* 163:    */         {
/* 164:220 */           Class<?> componentClass = (Class)componentType;
/* 165:221 */           if (componentClass.isPrimitive()) {
/* 166:222 */             return componentClass;
/* 167:    */           }
/* 168:    */         }
/* 169:225 */         return subtypeOf(componentType);
/* 170:    */       }
/* 171:    */     }
/* 172:228 */     return null;
/* 173:    */   }
/* 174:    */   
/* 175:    */   private static final class GenericArrayTypeImpl
/* 176:    */     implements GenericArrayType, Serializable
/* 177:    */   {
/* 178:    */     private final Type componentType;
/* 179:    */     private static final long serialVersionUID = 0L;
/* 180:    */     
/* 181:    */     GenericArrayTypeImpl(Type componentType)
/* 182:    */     {
/* 183:237 */       this.componentType = Types.JavaVersion.CURRENT.usedInGenericType(componentType);
/* 184:    */     }
/* 185:    */     
/* 186:    */     public Type getGenericComponentType()
/* 187:    */     {
/* 188:241 */       return this.componentType;
/* 189:    */     }
/* 190:    */     
/* 191:    */     public String toString()
/* 192:    */     {
/* 193:245 */       return Types.toString(this.componentType) + "[]";
/* 194:    */     }
/* 195:    */     
/* 196:    */     public int hashCode()
/* 197:    */     {
/* 198:249 */       return this.componentType.hashCode();
/* 199:    */     }
/* 200:    */     
/* 201:    */     public boolean equals(Object obj)
/* 202:    */     {
/* 203:253 */       if ((obj instanceof GenericArrayType))
/* 204:    */       {
/* 205:254 */         GenericArrayType that = (GenericArrayType)obj;
/* 206:255 */         return Objects.equal(getGenericComponentType(), that.getGenericComponentType());
/* 207:    */       }
/* 208:258 */       return false;
/* 209:    */     }
/* 210:    */   }
/* 211:    */   
/* 212:    */   private static final class ParameterizedTypeImpl
/* 213:    */     implements ParameterizedType, Serializable
/* 214:    */   {
/* 215:    */     private final Type ownerType;
/* 216:    */     private final ImmutableList<Type> argumentsList;
/* 217:    */     private final Class<?> rawType;
/* 218:    */     private static final long serialVersionUID = 0L;
/* 219:    */     
/* 220:    */     ParameterizedTypeImpl(@Nullable Type ownerType, Class<?> rawType, Type[] typeArguments)
/* 221:    */     {
/* 222:273 */       Preconditions.checkNotNull(rawType);
/* 223:274 */       Preconditions.checkArgument(typeArguments.length == rawType.getTypeParameters().length);
/* 224:275 */       Types.disallowPrimitiveType(typeArguments, "type parameter");
/* 225:276 */       this.ownerType = ownerType;
/* 226:277 */       this.rawType = rawType;
/* 227:278 */       this.argumentsList = Types.JavaVersion.CURRENT.usedInGenericType(typeArguments);
/* 228:    */     }
/* 229:    */     
/* 230:    */     public Type[] getActualTypeArguments()
/* 231:    */     {
/* 232:282 */       return Types.toArray(this.argumentsList);
/* 233:    */     }
/* 234:    */     
/* 235:    */     public Type getRawType()
/* 236:    */     {
/* 237:286 */       return this.rawType;
/* 238:    */     }
/* 239:    */     
/* 240:    */     public Type getOwnerType()
/* 241:    */     {
/* 242:290 */       return this.ownerType;
/* 243:    */     }
/* 244:    */     
/* 245:    */     public String toString()
/* 246:    */     {
/* 247:294 */       StringBuilder builder = new StringBuilder();
/* 248:295 */       if (this.ownerType != null) {
/* 249:296 */         builder.append(Types.JavaVersion.CURRENT.typeName(this.ownerType)).append('.');
/* 250:    */       }
/* 251:298 */       builder.append(this.rawType.getName()).append('<').append(Types.COMMA_JOINER.join(Iterables.transform(this.argumentsList, Types.TYPE_NAME))).append('>');
/* 252:    */       
/* 253:    */ 
/* 254:    */ 
/* 255:302 */       return builder.toString();
/* 256:    */     }
/* 257:    */     
/* 258:    */     public int hashCode()
/* 259:    */     {
/* 260:306 */       return (this.ownerType == null ? 0 : this.ownerType.hashCode()) ^ this.argumentsList.hashCode() ^ this.rawType.hashCode();
/* 261:    */     }
/* 262:    */     
/* 263:    */     public boolean equals(Object other)
/* 264:    */     {
/* 265:311 */       if (!(other instanceof ParameterizedType)) {
/* 266:312 */         return false;
/* 267:    */       }
/* 268:314 */       ParameterizedType that = (ParameterizedType)other;
/* 269:315 */       return (getRawType().equals(that.getRawType())) && (Objects.equal(getOwnerType(), that.getOwnerType())) && (Arrays.equals(getActualTypeArguments(), that.getActualTypeArguments()));
/* 270:    */     }
/* 271:    */   }
/* 272:    */   
/* 273:    */   private static <D extends GenericDeclaration> TypeVariable<D> newTypeVariableImpl(D genericDeclaration, String name, Type[] bounds)
/* 274:    */   {
/* 275:326 */     TypeVariableImpl<D> typeVariableImpl = new TypeVariableImpl(genericDeclaration, name, bounds);
/* 276:    */     
/* 277:    */ 
/* 278:329 */     TypeVariable<D> typeVariable = (TypeVariable)Reflection.newProxy(TypeVariable.class, new TypeVariableInvocationHandler(typeVariableImpl));
/* 279:    */     
/* 280:331 */     return typeVariable;
/* 281:    */   }
/* 282:    */   
/* 283:    */   private static final class TypeVariableInvocationHandler
/* 284:    */     implements InvocationHandler
/* 285:    */   {
/* 286:    */     private static final ImmutableMap<String, Method> typeVariableMethods;
/* 287:    */     private final Types.TypeVariableImpl<?> typeVariableImpl;
/* 288:    */     
/* 289:    */     static
/* 290:    */     {
/* 291:357 */       ImmutableMap.Builder<String, Method> builder = ImmutableMap.builder();
/* 292:358 */       for (Method method : Types.TypeVariableImpl.class.getMethods()) {
/* 293:359 */         if (method.getDeclaringClass().equals(Types.TypeVariableImpl.class))
/* 294:    */         {
/* 295:    */           try
/* 296:    */           {
/* 297:361 */             method.setAccessible(true);
/* 298:    */           }
/* 299:    */           catch (AccessControlException e) {}
/* 300:366 */           builder.put(method.getName(), method);
/* 301:    */         }
/* 302:    */       }
/* 303:369 */       typeVariableMethods = builder.build();
/* 304:    */     }
/* 305:    */     
/* 306:    */     TypeVariableInvocationHandler(Types.TypeVariableImpl<?> typeVariableImpl)
/* 307:    */     {
/* 308:375 */       this.typeVariableImpl = typeVariableImpl;
/* 309:    */     }
/* 310:    */     
/* 311:    */     public Object invoke(Object proxy, Method method, Object[] args)
/* 312:    */       throws Throwable
/* 313:    */     {
/* 314:379 */       String methodName = method.getName();
/* 315:380 */       Method typeVariableMethod = (Method)typeVariableMethods.get(methodName);
/* 316:381 */       if (typeVariableMethod == null) {
/* 317:382 */         throw new UnsupportedOperationException(methodName);
/* 318:    */       }
/* 319:    */       try
/* 320:    */       {
/* 321:385 */         return typeVariableMethod.invoke(this.typeVariableImpl, args);
/* 322:    */       }
/* 323:    */       catch (InvocationTargetException e)
/* 324:    */       {
/* 325:387 */         throw e.getCause();
/* 326:    */       }
/* 327:    */     }
/* 328:    */   }
/* 329:    */   
/* 330:    */   private static final class TypeVariableImpl<D extends GenericDeclaration>
/* 331:    */   {
/* 332:    */     private final D genericDeclaration;
/* 333:    */     private final String name;
/* 334:    */     private final ImmutableList<Type> bounds;
/* 335:    */     
/* 336:    */     TypeVariableImpl(D genericDeclaration, String name, Type[] bounds)
/* 337:    */     {
/* 338:400 */       Types.disallowPrimitiveType(bounds, "bound for type variable");
/* 339:401 */       this.genericDeclaration = ((GenericDeclaration)Preconditions.checkNotNull(genericDeclaration));
/* 340:402 */       this.name = ((String)Preconditions.checkNotNull(name));
/* 341:403 */       this.bounds = ImmutableList.copyOf(bounds);
/* 342:    */     }
/* 343:    */     
/* 344:    */     public Type[] getBounds()
/* 345:    */     {
/* 346:407 */       return Types.toArray(this.bounds);
/* 347:    */     }
/* 348:    */     
/* 349:    */     public D getGenericDeclaration()
/* 350:    */     {
/* 351:411 */       return this.genericDeclaration;
/* 352:    */     }
/* 353:    */     
/* 354:    */     public String getName()
/* 355:    */     {
/* 356:415 */       return this.name;
/* 357:    */     }
/* 358:    */     
/* 359:    */     public String getTypeName()
/* 360:    */     {
/* 361:419 */       return this.name;
/* 362:    */     }
/* 363:    */     
/* 364:    */     public String toString()
/* 365:    */     {
/* 366:423 */       return this.name;
/* 367:    */     }
/* 368:    */     
/* 369:    */     public int hashCode()
/* 370:    */     {
/* 371:427 */       return this.genericDeclaration.hashCode() ^ this.name.hashCode();
/* 372:    */     }
/* 373:    */     
/* 374:    */     public boolean equals(Object obj)
/* 375:    */     {
/* 376:431 */       if (Types.NativeTypeVariableEquals.NATIVE_TYPE_VARIABLE_ONLY)
/* 377:    */       {
/* 378:433 */         if ((obj != null) && (Proxy.isProxyClass(obj.getClass())) && ((Proxy.getInvocationHandler(obj) instanceof Types.TypeVariableInvocationHandler)))
/* 379:    */         {
/* 380:436 */           Types.TypeVariableInvocationHandler typeVariableInvocationHandler = (Types.TypeVariableInvocationHandler)Proxy.getInvocationHandler(obj);
/* 381:    */           
/* 382:438 */           TypeVariableImpl<?> that = Types.TypeVariableInvocationHandler.access$600(typeVariableInvocationHandler);
/* 383:439 */           return (this.name.equals(that.getName())) && (this.genericDeclaration.equals(that.getGenericDeclaration())) && (this.bounds.equals(that.bounds));
/* 384:    */         }
/* 385:443 */         return false;
/* 386:    */       }
/* 387:446 */       if ((obj instanceof TypeVariable))
/* 388:    */       {
/* 389:447 */         TypeVariable<?> that = (TypeVariable)obj;
/* 390:448 */         return (this.name.equals(that.getName())) && (this.genericDeclaration.equals(that.getGenericDeclaration()));
/* 391:    */       }
/* 392:451 */       return false;
/* 393:    */     }
/* 394:    */   }
/* 395:    */   
/* 396:    */   static final class WildcardTypeImpl
/* 397:    */     implements WildcardType, Serializable
/* 398:    */   {
/* 399:    */     private final ImmutableList<Type> lowerBounds;
/* 400:    */     private final ImmutableList<Type> upperBounds;
/* 401:    */     private static final long serialVersionUID = 0L;
/* 402:    */     
/* 403:    */     WildcardTypeImpl(Type[] lowerBounds, Type[] upperBounds)
/* 404:    */     {
/* 405:462 */       Types.disallowPrimitiveType(lowerBounds, "lower bound for wildcard");
/* 406:463 */       Types.disallowPrimitiveType(upperBounds, "upper bound for wildcard");
/* 407:464 */       this.lowerBounds = Types.JavaVersion.CURRENT.usedInGenericType(lowerBounds);
/* 408:465 */       this.upperBounds = Types.JavaVersion.CURRENT.usedInGenericType(upperBounds);
/* 409:    */     }
/* 410:    */     
/* 411:    */     public Type[] getLowerBounds()
/* 412:    */     {
/* 413:469 */       return Types.toArray(this.lowerBounds);
/* 414:    */     }
/* 415:    */     
/* 416:    */     public Type[] getUpperBounds()
/* 417:    */     {
/* 418:473 */       return Types.toArray(this.upperBounds);
/* 419:    */     }
/* 420:    */     
/* 421:    */     public boolean equals(Object obj)
/* 422:    */     {
/* 423:477 */       if ((obj instanceof WildcardType))
/* 424:    */       {
/* 425:478 */         WildcardType that = (WildcardType)obj;
/* 426:479 */         return (this.lowerBounds.equals(Arrays.asList(that.getLowerBounds()))) && (this.upperBounds.equals(Arrays.asList(that.getUpperBounds())));
/* 427:    */       }
/* 428:482 */       return false;
/* 429:    */     }
/* 430:    */     
/* 431:    */     public int hashCode()
/* 432:    */     {
/* 433:486 */       return this.lowerBounds.hashCode() ^ this.upperBounds.hashCode();
/* 434:    */     }
/* 435:    */     
/* 436:    */     public String toString()
/* 437:    */     {
/* 438:490 */       StringBuilder builder = new StringBuilder("?");
/* 439:491 */       for (Type lowerBound : this.lowerBounds) {
/* 440:492 */         builder.append(" super ").append(Types.JavaVersion.CURRENT.typeName(lowerBound));
/* 441:    */       }
/* 442:494 */       for (Type upperBound : Types.filterUpperBounds(this.upperBounds)) {
/* 443:495 */         builder.append(" extends ").append(Types.JavaVersion.CURRENT.typeName(upperBound));
/* 444:    */       }
/* 445:497 */       return builder.toString();
/* 446:    */     }
/* 447:    */   }
/* 448:    */   
/* 449:    */   private static Type[] toArray(Collection<Type> types)
/* 450:    */   {
/* 451:504 */     return (Type[])types.toArray(new Type[types.size()]);
/* 452:    */   }
/* 453:    */   
/* 454:    */   private static Iterable<Type> filterUpperBounds(Iterable<Type> bounds)
/* 455:    */   {
/* 456:508 */     return Iterables.filter(bounds, Predicates.not(Predicates.equalTo(Object.class)));
/* 457:    */   }
/* 458:    */   
/* 459:    */   private static void disallowPrimitiveType(Type[] types, String usedAs)
/* 460:    */   {
/* 461:513 */     for (Type type : types) {
/* 462:514 */       if ((type instanceof Class))
/* 463:    */       {
/* 464:515 */         Class<?> cls = (Class)type;
/* 465:516 */         Preconditions.checkArgument(!cls.isPrimitive(), "Primitive type '%s' used as %s", new Object[] { cls, usedAs });
/* 466:    */       }
/* 467:    */     }
/* 468:    */   }
/* 469:    */   
/* 470:    */   static Class<?> getArrayClass(Class<?> componentType)
/* 471:    */   {
/* 472:527 */     return Array.newInstance(componentType, 0).getClass();
/* 473:    */   }
/* 474:    */   
/* 475:    */   static abstract enum JavaVersion
/* 476:    */   {
/* 477:533 */     JAVA6,  JAVA7,  JAVA8;
/* 478:    */     
/* 479:    */     static final JavaVersion CURRENT;
/* 480:    */     
/* 481:    */     static
/* 482:    */     {
/* 483:584 */       if (AnnotatedElement.class.isAssignableFrom(TypeVariable.class)) {
/* 484:585 */         CURRENT = JAVA8;
/* 485:586 */       } else if ((new TypeCapture() {}.capture() instanceof Class)) {
/* 486:587 */         CURRENT = JAVA7;
/* 487:    */       } else {
/* 488:589 */         CURRENT = JAVA6;
/* 489:    */       }
/* 490:    */     }
/* 491:    */     
/* 492:    */     String typeName(Type type)
/* 493:    */     {
/* 494:596 */       return Types.toString(type);
/* 495:    */     }
/* 496:    */     
/* 497:    */     final ImmutableList<Type> usedInGenericType(Type[] types)
/* 498:    */     {
/* 499:600 */       ImmutableList.Builder<Type> builder = ImmutableList.builder();
/* 500:601 */       for (Type type : types) {
/* 501:602 */         builder.add(usedInGenericType(type));
/* 502:    */       }
/* 503:604 */       return builder.build();
/* 504:    */     }
/* 505:    */     
/* 506:    */     private JavaVersion() {}
/* 507:    */     
/* 508:    */     abstract Type newArrayType(Type paramType);
/* 509:    */     
/* 510:    */     abstract Type usedInGenericType(Type paramType);
/* 511:    */   }
/* 512:    */   
/* 513:    */   static final class NativeTypeVariableEquals<X>
/* 514:    */   {
/* 515:619 */     static final boolean NATIVE_TYPE_VARIABLE_ONLY = !NativeTypeVariableEquals.class.getTypeParameters()[0].equals(Types.newArtificialTypeVariable(NativeTypeVariableEquals.class, "X", new Type[0]));
/* 516:    */   }
/* 517:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.Types
 * JD-Core Version:    0.7.0.1
 */