/*  1:   */ package com.google.common.reflect;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import java.lang.reflect.ParameterizedType;
/*  5:   */ import java.lang.reflect.Type;
/*  6:   */ 
/*  7:   */ abstract class TypeCapture<T>
/*  8:   */ {
/*  9:   */   final Type capture()
/* 10:   */   {
/* 11:33 */     Type superclass = getClass().getGenericSuperclass();
/* 12:34 */     Preconditions.checkArgument(superclass instanceof ParameterizedType, "%s isn't parameterized", new Object[] { superclass });
/* 13:   */     
/* 14:36 */     return ((ParameterizedType)superclass).getActualTypeArguments()[0];
/* 15:   */   }
/* 16:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.TypeCapture
 * JD-Core Version:    0.7.0.1
 */