/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Joiner;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.collect.ImmutableMap;
/*   8:    */ import com.google.common.collect.ImmutableMap.Builder;
/*   9:    */ import com.google.common.collect.Maps;
/*  10:    */ import java.lang.reflect.GenericArrayType;
/*  11:    */ import java.lang.reflect.ParameterizedType;
/*  12:    */ import java.lang.reflect.Type;
/*  13:    */ import java.lang.reflect.TypeVariable;
/*  14:    */ import java.lang.reflect.WildcardType;
/*  15:    */ import java.util.Arrays;
/*  16:    */ import java.util.Map;
/*  17:    */ import java.util.Map.Entry;
/*  18:    */ import java.util.concurrent.atomic.AtomicInteger;
/*  19:    */ import javax.annotation.Nullable;
/*  20:    */ 
/*  21:    */ @Beta
/*  22:    */ public final class TypeResolver
/*  23:    */ {
/*  24:    */   private final TypeTable typeTable;
/*  25:    */   
/*  26:    */   public TypeResolver()
/*  27:    */   {
/*  28: 60 */     this.typeTable = new TypeTable();
/*  29:    */   }
/*  30:    */   
/*  31:    */   private TypeResolver(TypeTable typeTable)
/*  32:    */   {
/*  33: 64 */     this.typeTable = typeTable;
/*  34:    */   }
/*  35:    */   
/*  36:    */   static TypeResolver accordingTo(Type type)
/*  37:    */   {
/*  38: 68 */     return new TypeResolver().where(TypeMappingIntrospector.getTypeMappings(type));
/*  39:    */   }
/*  40:    */   
/*  41:    */   public TypeResolver where(Type formal, Type actual)
/*  42:    */   {
/*  43: 91 */     Map<TypeVariableKey, Type> mappings = Maps.newHashMap();
/*  44: 92 */     populateTypeMappings(mappings, (Type)Preconditions.checkNotNull(formal), (Type)Preconditions.checkNotNull(actual));
/*  45: 93 */     return where(mappings);
/*  46:    */   }
/*  47:    */   
/*  48:    */   TypeResolver where(Map<TypeVariableKey, ? extends Type> mappings)
/*  49:    */   {
/*  50: 98 */     return new TypeResolver(this.typeTable.where(mappings));
/*  51:    */   }
/*  52:    */   
/*  53:    */   private static void populateTypeMappings(Map<TypeVariableKey, Type> mappings, Type from, final Type to)
/*  54:    */   {
/*  55:103 */     if (from.equals(to)) {
/*  56:104 */       return;
/*  57:    */     }
/*  58:106 */     if (to instanceof WildcardType != from instanceof WildcardType) {
/*  59:109 */       return;
/*  60:    */     }
/*  61:111 */     new TypeVisitor()
/*  62:    */     {
/*  63:    */       void visitTypeVariable(TypeVariable<?> typeVariable)
/*  64:    */       {
/*  65:113 */         this.val$mappings.put(new TypeResolver.TypeVariableKey(typeVariable), to);
/*  66:    */       }
/*  67:    */       
/*  68:    */       void visitWildcardType(WildcardType fromWildcardType)
/*  69:    */       {
/*  70:116 */         WildcardType toWildcardType = (WildcardType)TypeResolver.expectArgument(WildcardType.class, to);
/*  71:117 */         Type[] fromUpperBounds = fromWildcardType.getUpperBounds();
/*  72:118 */         Type[] toUpperBounds = toWildcardType.getUpperBounds();
/*  73:119 */         Type[] fromLowerBounds = fromWildcardType.getLowerBounds();
/*  74:120 */         Type[] toLowerBounds = toWildcardType.getLowerBounds();
/*  75:121 */         Preconditions.checkArgument((fromUpperBounds.length == toUpperBounds.length) && (fromLowerBounds.length == toLowerBounds.length), "Incompatible type: %s vs. %s", new Object[] { fromWildcardType, to });
/*  76:125 */         for (int i = 0; i < fromUpperBounds.length; i++) {
/*  77:126 */           TypeResolver.populateTypeMappings(this.val$mappings, fromUpperBounds[i], toUpperBounds[i]);
/*  78:    */         }
/*  79:128 */         for (int i = 0; i < fromLowerBounds.length; i++) {
/*  80:129 */           TypeResolver.populateTypeMappings(this.val$mappings, fromLowerBounds[i], toLowerBounds[i]);
/*  81:    */         }
/*  82:    */       }
/*  83:    */       
/*  84:    */       void visitParameterizedType(ParameterizedType fromParameterizedType)
/*  85:    */       {
/*  86:133 */         ParameterizedType toParameterizedType = (ParameterizedType)TypeResolver.expectArgument(ParameterizedType.class, to);
/*  87:134 */         Preconditions.checkArgument(fromParameterizedType.getRawType().equals(toParameterizedType.getRawType()), "Inconsistent raw type: %s vs. %s", new Object[] { fromParameterizedType, to });
/*  88:    */         
/*  89:136 */         Type[] fromArgs = fromParameterizedType.getActualTypeArguments();
/*  90:137 */         Type[] toArgs = toParameterizedType.getActualTypeArguments();
/*  91:138 */         Preconditions.checkArgument(fromArgs.length == toArgs.length, "%s not compatible with %s", new Object[] { fromParameterizedType, toParameterizedType });
/*  92:140 */         for (int i = 0; i < fromArgs.length; i++) {
/*  93:141 */           TypeResolver.populateTypeMappings(this.val$mappings, fromArgs[i], toArgs[i]);
/*  94:    */         }
/*  95:    */       }
/*  96:    */       
/*  97:    */       void visitGenericArrayType(GenericArrayType fromArrayType)
/*  98:    */       {
/*  99:145 */         Type componentType = Types.getComponentType(to);
/* 100:146 */         Preconditions.checkArgument(componentType != null, "%s is not an array type.", new Object[] { to });
/* 101:147 */         TypeResolver.populateTypeMappings(this.val$mappings, fromArrayType.getGenericComponentType(), componentType);
/* 102:    */       }
/* 103:    */       
/* 104:    */       void visitClass(Class<?> fromClass)
/* 105:    */       {
/* 106:153 */         throw new IllegalArgumentException("No type mapping from " + fromClass);
/* 107:    */       }
/* 108:153 */     }.visit(new Type[] { from });
/* 109:    */   }
/* 110:    */   
/* 111:    */   public Type resolveType(Type type)
/* 112:    */   {
/* 113:163 */     Preconditions.checkNotNull(type);
/* 114:164 */     if ((type instanceof TypeVariable)) {
/* 115:165 */       return this.typeTable.resolve((TypeVariable)type);
/* 116:    */     }
/* 117:166 */     if ((type instanceof ParameterizedType)) {
/* 118:167 */       return resolveParameterizedType((ParameterizedType)type);
/* 119:    */     }
/* 120:168 */     if ((type instanceof GenericArrayType)) {
/* 121:169 */       return resolveGenericArrayType((GenericArrayType)type);
/* 122:    */     }
/* 123:170 */     if ((type instanceof WildcardType)) {
/* 124:171 */       return resolveWildcardType((WildcardType)type);
/* 125:    */     }
/* 126:174 */     return type;
/* 127:    */   }
/* 128:    */   
/* 129:    */   private Type[] resolveTypes(Type[] types)
/* 130:    */   {
/* 131:179 */     Type[] result = new Type[types.length];
/* 132:180 */     for (int i = 0; i < types.length; i++) {
/* 133:181 */       result[i] = resolveType(types[i]);
/* 134:    */     }
/* 135:183 */     return result;
/* 136:    */   }
/* 137:    */   
/* 138:    */   private WildcardType resolveWildcardType(WildcardType type)
/* 139:    */   {
/* 140:187 */     Type[] lowerBounds = type.getLowerBounds();
/* 141:188 */     Type[] upperBounds = type.getUpperBounds();
/* 142:189 */     return new Types.WildcardTypeImpl(resolveTypes(lowerBounds), resolveTypes(upperBounds));
/* 143:    */   }
/* 144:    */   
/* 145:    */   private Type resolveGenericArrayType(GenericArrayType type)
/* 146:    */   {
/* 147:194 */     Type componentType = type.getGenericComponentType();
/* 148:195 */     Type resolvedComponentType = resolveType(componentType);
/* 149:196 */     return Types.newArrayType(resolvedComponentType);
/* 150:    */   }
/* 151:    */   
/* 152:    */   private ParameterizedType resolveParameterizedType(ParameterizedType type)
/* 153:    */   {
/* 154:200 */     Type owner = type.getOwnerType();
/* 155:201 */     Type resolvedOwner = owner == null ? null : resolveType(owner);
/* 156:202 */     Type resolvedRawType = resolveType(type.getRawType());
/* 157:    */     
/* 158:204 */     Type[] args = type.getActualTypeArguments();
/* 159:205 */     Type[] resolvedArgs = resolveTypes(args);
/* 160:206 */     return Types.newParameterizedTypeWithOwner(resolvedOwner, (Class)resolvedRawType, resolvedArgs);
/* 161:    */   }
/* 162:    */   
/* 163:    */   private static <T> T expectArgument(Class<T> type, Object arg)
/* 164:    */   {
/* 165:    */     try
/* 166:    */     {
/* 167:212 */       return type.cast(arg);
/* 168:    */     }
/* 169:    */     catch (ClassCastException e)
/* 170:    */     {
/* 171:214 */       throw new IllegalArgumentException(arg + " is not a " + type.getSimpleName());
/* 172:    */     }
/* 173:    */   }
/* 174:    */   
/* 175:    */   private static class TypeTable
/* 176:    */   {
/* 177:    */     private final ImmutableMap<TypeResolver.TypeVariableKey, Type> map;
/* 178:    */     
/* 179:    */     TypeTable()
/* 180:    */     {
/* 181:223 */       this.map = ImmutableMap.of();
/* 182:    */     }
/* 183:    */     
/* 184:    */     private TypeTable(ImmutableMap<TypeResolver.TypeVariableKey, Type> map)
/* 185:    */     {
/* 186:227 */       this.map = map;
/* 187:    */     }
/* 188:    */     
/* 189:    */     final TypeTable where(Map<TypeResolver.TypeVariableKey, ? extends Type> mappings)
/* 190:    */     {
/* 191:232 */       ImmutableMap.Builder<TypeResolver.TypeVariableKey, Type> builder = ImmutableMap.builder();
/* 192:233 */       builder.putAll(this.map);
/* 193:234 */       for (Map.Entry<TypeResolver.TypeVariableKey, ? extends Type> mapping : mappings.entrySet())
/* 194:    */       {
/* 195:235 */         TypeResolver.TypeVariableKey variable = (TypeResolver.TypeVariableKey)mapping.getKey();
/* 196:236 */         Type type = (Type)mapping.getValue();
/* 197:237 */         Preconditions.checkArgument(!variable.equalsType(type), "Type variable %s bound to itself", new Object[] { variable });
/* 198:238 */         builder.put(variable, type);
/* 199:    */       }
/* 200:240 */       return new TypeTable(builder.build());
/* 201:    */     }
/* 202:    */     
/* 203:    */     final Type resolve(final TypeVariable<?> var)
/* 204:    */     {
/* 205:244 */       final TypeTable unguarded = this;
/* 206:245 */       TypeTable guarded = new TypeTable()
/* 207:    */       {
/* 208:    */         public Type resolveInternal(TypeVariable<?> intermediateVar, TypeResolver.TypeTable forDependent)
/* 209:    */         {
/* 210:248 */           if (intermediateVar.getGenericDeclaration().equals(var.getGenericDeclaration())) {
/* 211:249 */             return intermediateVar;
/* 212:    */           }
/* 213:251 */           return unguarded.resolveInternal(intermediateVar, forDependent);
/* 214:    */         }
/* 215:253 */       };
/* 216:254 */       return resolveInternal(var, guarded);
/* 217:    */     }
/* 218:    */     
/* 219:    */     Type resolveInternal(TypeVariable<?> var, TypeTable forDependants)
/* 220:    */     {
/* 221:266 */       Type type = (Type)this.map.get(new TypeResolver.TypeVariableKey(var));
/* 222:267 */       if (type == null)
/* 223:    */       {
/* 224:268 */         Type[] bounds = var.getBounds();
/* 225:269 */         if (bounds.length == 0) {
/* 226:270 */           return var;
/* 227:    */         }
/* 228:272 */         Type[] resolvedBounds = new TypeResolver(forDependants, null).resolveTypes(bounds);
/* 229:301 */         if ((Types.NativeTypeVariableEquals.NATIVE_TYPE_VARIABLE_ONLY) && (Arrays.equals(bounds, resolvedBounds))) {
/* 230:303 */           return var;
/* 231:    */         }
/* 232:305 */         return Types.newArtificialTypeVariable(var.getGenericDeclaration(), var.getName(), resolvedBounds);
/* 233:    */       }
/* 234:309 */       return new TypeResolver(forDependants, null).resolveType(type);
/* 235:    */     }
/* 236:    */   }
/* 237:    */   
/* 238:    */   private static final class TypeMappingIntrospector
/* 239:    */     extends TypeVisitor
/* 240:    */   {
/* 241:315 */     private static final TypeResolver.WildcardCapturer wildcardCapturer = new TypeResolver.WildcardCapturer(null);
/* 242:317 */     private final Map<TypeResolver.TypeVariableKey, Type> mappings = Maps.newHashMap();
/* 243:    */     
/* 244:    */     static ImmutableMap<TypeResolver.TypeVariableKey, Type> getTypeMappings(Type contextType)
/* 245:    */     {
/* 246:325 */       TypeMappingIntrospector introspector = new TypeMappingIntrospector();
/* 247:326 */       introspector.visit(new Type[] { wildcardCapturer.capture(contextType) });
/* 248:327 */       return ImmutableMap.copyOf(introspector.mappings);
/* 249:    */     }
/* 250:    */     
/* 251:    */     void visitClass(Class<?> clazz)
/* 252:    */     {
/* 253:331 */       visit(new Type[] { clazz.getGenericSuperclass() });
/* 254:332 */       visit(clazz.getGenericInterfaces());
/* 255:    */     }
/* 256:    */     
/* 257:    */     void visitParameterizedType(ParameterizedType parameterizedType)
/* 258:    */     {
/* 259:336 */       Class<?> rawClass = (Class)parameterizedType.getRawType();
/* 260:337 */       TypeVariable<?>[] vars = rawClass.getTypeParameters();
/* 261:338 */       Type[] typeArgs = parameterizedType.getActualTypeArguments();
/* 262:339 */       Preconditions.checkState(vars.length == typeArgs.length);
/* 263:340 */       for (int i = 0; i < vars.length; i++) {
/* 264:341 */         map(new TypeResolver.TypeVariableKey(vars[i]), typeArgs[i]);
/* 265:    */       }
/* 266:343 */       visit(new Type[] { rawClass });
/* 267:344 */       visit(new Type[] { parameterizedType.getOwnerType() });
/* 268:    */     }
/* 269:    */     
/* 270:    */     void visitTypeVariable(TypeVariable<?> t)
/* 271:    */     {
/* 272:348 */       visit(t.getBounds());
/* 273:    */     }
/* 274:    */     
/* 275:    */     void visitWildcardType(WildcardType t)
/* 276:    */     {
/* 277:352 */       visit(t.getUpperBounds());
/* 278:    */     }
/* 279:    */     
/* 280:    */     private void map(TypeResolver.TypeVariableKey var, Type arg)
/* 281:    */     {
/* 282:356 */       if (this.mappings.containsKey(var)) {
/* 283:362 */         return;
/* 284:    */       }
/* 285:365 */       for (Type t = arg; t != null; t = (Type)this.mappings.get(TypeResolver.TypeVariableKey.forLookup(t))) {
/* 286:366 */         if (var.equalsType(t))
/* 287:    */         {
/* 288:371 */           for (Type x = arg; x != null; x = (Type)this.mappings.remove(TypeResolver.TypeVariableKey.forLookup(x))) {}
/* 289:372 */           return;
/* 290:    */         }
/* 291:    */       }
/* 292:375 */       this.mappings.put(var, arg);
/* 293:    */     }
/* 294:    */   }
/* 295:    */   
/* 296:    */   private static final class WildcardCapturer
/* 297:    */   {
/* 298:388 */     private final AtomicInteger id = new AtomicInteger();
/* 299:    */     
/* 300:    */     Type capture(Type type)
/* 301:    */     {
/* 302:391 */       Preconditions.checkNotNull(type);
/* 303:392 */       if ((type instanceof Class)) {
/* 304:393 */         return type;
/* 305:    */       }
/* 306:395 */       if ((type instanceof TypeVariable)) {
/* 307:396 */         return type;
/* 308:    */       }
/* 309:398 */       if ((type instanceof GenericArrayType))
/* 310:    */       {
/* 311:399 */         GenericArrayType arrayType = (GenericArrayType)type;
/* 312:400 */         return Types.newArrayType(capture(arrayType.getGenericComponentType()));
/* 313:    */       }
/* 314:402 */       if ((type instanceof ParameterizedType))
/* 315:    */       {
/* 316:403 */         ParameterizedType parameterizedType = (ParameterizedType)type;
/* 317:404 */         return Types.newParameterizedTypeWithOwner(captureNullable(parameterizedType.getOwnerType()), (Class)parameterizedType.getRawType(), capture(parameterizedType.getActualTypeArguments()));
/* 318:    */       }
/* 319:409 */       if ((type instanceof WildcardType))
/* 320:    */       {
/* 321:410 */         WildcardType wildcardType = (WildcardType)type;
/* 322:411 */         Type[] lowerBounds = wildcardType.getLowerBounds();
/* 323:412 */         if (lowerBounds.length == 0)
/* 324:    */         {
/* 325:413 */           Type[] upperBounds = wildcardType.getUpperBounds();
/* 326:414 */           String name = "capture#" + this.id.incrementAndGet() + "-of ? extends " + Joiner.on('&').join(upperBounds);
/* 327:    */           
/* 328:416 */           return Types.newArtificialTypeVariable(WildcardCapturer.class, name, wildcardType.getUpperBounds());
/* 329:    */         }
/* 330:420 */         return type;
/* 331:    */       }
/* 332:423 */       throw new AssertionError("must have been one of the known types");
/* 333:    */     }
/* 334:    */     
/* 335:    */     private Type captureNullable(@Nullable Type type)
/* 336:    */     {
/* 337:427 */       if (type == null) {
/* 338:428 */         return null;
/* 339:    */       }
/* 340:430 */       return capture(type);
/* 341:    */     }
/* 342:    */     
/* 343:    */     private Type[] capture(Type[] types)
/* 344:    */     {
/* 345:434 */       Type[] result = new Type[types.length];
/* 346:435 */       for (int i = 0; i < types.length; i++) {
/* 347:436 */         result[i] = capture(types[i]);
/* 348:    */       }
/* 349:438 */       return result;
/* 350:    */     }
/* 351:    */   }
/* 352:    */   
/* 353:    */   static final class TypeVariableKey
/* 354:    */   {
/* 355:    */     private final TypeVariable<?> var;
/* 356:    */     
/* 357:    */     TypeVariableKey(TypeVariable<?> var)
/* 358:    */     {
/* 359:460 */       this.var = ((TypeVariable)Preconditions.checkNotNull(var));
/* 360:    */     }
/* 361:    */     
/* 362:    */     public int hashCode()
/* 363:    */     {
/* 364:464 */       return Objects.hashCode(new Object[] { this.var.getGenericDeclaration(), this.var.getName() });
/* 365:    */     }
/* 366:    */     
/* 367:    */     public boolean equals(Object obj)
/* 368:    */     {
/* 369:468 */       if ((obj instanceof TypeVariableKey))
/* 370:    */       {
/* 371:469 */         TypeVariableKey that = (TypeVariableKey)obj;
/* 372:470 */         return equalsTypeVariable(that.var);
/* 373:    */       }
/* 374:472 */       return false;
/* 375:    */     }
/* 376:    */     
/* 377:    */     public String toString()
/* 378:    */     {
/* 379:477 */       return this.var.toString();
/* 380:    */     }
/* 381:    */     
/* 382:    */     static Object forLookup(Type t)
/* 383:    */     {
/* 384:482 */       if ((t instanceof TypeVariable)) {
/* 385:483 */         return new TypeVariableKey((TypeVariable)t);
/* 386:    */       }
/* 387:485 */       return null;
/* 388:    */     }
/* 389:    */     
/* 390:    */     boolean equalsType(Type type)
/* 391:    */     {
/* 392:494 */       if ((type instanceof TypeVariable)) {
/* 393:495 */         return equalsTypeVariable((TypeVariable)type);
/* 394:    */       }
/* 395:497 */       return false;
/* 396:    */     }
/* 397:    */     
/* 398:    */     private boolean equalsTypeVariable(TypeVariable<?> that)
/* 399:    */     {
/* 400:502 */       return (this.var.getGenericDeclaration().equals(that.getGenericDeclaration())) && (this.var.getName().equals(that.getName()));
/* 401:    */     }
/* 402:    */   }
/* 403:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.TypeResolver
 * JD-Core Version:    0.7.0.1
 */