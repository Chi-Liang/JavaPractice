/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import java.lang.reflect.InvocationHandler;
/*   5:    */ import java.lang.reflect.Method;
/*   6:    */ import java.lang.reflect.Proxy;
/*   7:    */ import java.util.Arrays;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @Beta
/*  11:    */ public abstract class AbstractInvocationHandler
/*  12:    */   implements InvocationHandler
/*  13:    */ {
/*  14: 47 */   private static final Object[] NO_ARGS = new Object[0];
/*  15:    */   
/*  16:    */   public final Object invoke(Object proxy, Method method, @Nullable Object[] args)
/*  17:    */     throws Throwable
/*  18:    */   {
/*  19: 65 */     if (args == null) {
/*  20: 66 */       args = NO_ARGS;
/*  21:    */     }
/*  22: 68 */     if ((args.length == 0) && (method.getName().equals("hashCode"))) {
/*  23: 69 */       return Integer.valueOf(hashCode());
/*  24:    */     }
/*  25: 71 */     if ((args.length == 1) && (method.getName().equals("equals")) && (method.getParameterTypes()[0] == Object.class))
/*  26:    */     {
/*  27: 74 */       Object arg = args[0];
/*  28: 75 */       if (arg == null) {
/*  29: 76 */         return Boolean.valueOf(false);
/*  30:    */       }
/*  31: 78 */       if (proxy == arg) {
/*  32: 79 */         return Boolean.valueOf(true);
/*  33:    */       }
/*  34: 81 */       return Boolean.valueOf((isProxyOfSameInterfaces(arg, proxy.getClass())) && (equals(Proxy.getInvocationHandler(arg))));
/*  35:    */     }
/*  36: 84 */     if ((args.length == 0) && (method.getName().equals("toString"))) {
/*  37: 85 */       return toString();
/*  38:    */     }
/*  39: 87 */     return handleInvocation(proxy, method, args);
/*  40:    */   }
/*  41:    */   
/*  42:    */   protected abstract Object handleInvocation(Object paramObject, Method paramMethod, Object[] paramArrayOfObject)
/*  43:    */     throws Throwable;
/*  44:    */   
/*  45:    */   public boolean equals(Object obj)
/*  46:    */   {
/*  47:110 */     return super.equals(obj);
/*  48:    */   }
/*  49:    */   
/*  50:    */   public int hashCode()
/*  51:    */   {
/*  52:118 */     return super.hashCode();
/*  53:    */   }
/*  54:    */   
/*  55:    */   public String toString()
/*  56:    */   {
/*  57:127 */     return super.toString();
/*  58:    */   }
/*  59:    */   
/*  60:    */   private static boolean isProxyOfSameInterfaces(Object arg, Class<?> proxyClass)
/*  61:    */   {
/*  62:131 */     return (proxyClass.isInstance(arg)) || ((Proxy.isProxyClass(arg.getClass())) && (Arrays.equals(arg.getClass().getInterfaces(), proxyClass.getInterfaces())));
/*  63:    */   }
/*  64:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.AbstractInvocationHandler
 * JD-Core Version:    0.7.0.1
 */