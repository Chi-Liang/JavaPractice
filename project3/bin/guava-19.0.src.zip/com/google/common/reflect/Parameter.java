/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Optional;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.FluentIterable;
/*   7:    */ import com.google.common.collect.ImmutableList;
/*   8:    */ import java.lang.annotation.Annotation;
/*   9:    */ import java.lang.reflect.AnnotatedElement;
/*  10:    */ import javax.annotation.Nullable;
/*  11:    */ 
/*  12:    */ @Beta
/*  13:    */ public final class Parameter
/*  14:    */   implements AnnotatedElement
/*  15:    */ {
/*  16:    */   private final Invokable<?, ?> declaration;
/*  17:    */   private final int position;
/*  18:    */   private final TypeToken<?> type;
/*  19:    */   private final ImmutableList<Annotation> annotations;
/*  20:    */   
/*  21:    */   Parameter(Invokable<?, ?> declaration, int position, TypeToken<?> type, Annotation[] annotations)
/*  22:    */   {
/*  23: 49 */     this.declaration = declaration;
/*  24: 50 */     this.position = position;
/*  25: 51 */     this.type = type;
/*  26: 52 */     this.annotations = ImmutableList.copyOf(annotations);
/*  27:    */   }
/*  28:    */   
/*  29:    */   public TypeToken<?> getType()
/*  30:    */   {
/*  31: 57 */     return this.type;
/*  32:    */   }
/*  33:    */   
/*  34:    */   public Invokable<?, ?> getDeclaringInvokable()
/*  35:    */   {
/*  36: 62 */     return this.declaration;
/*  37:    */   }
/*  38:    */   
/*  39:    */   public boolean isAnnotationPresent(Class<? extends Annotation> annotationType)
/*  40:    */   {
/*  41: 66 */     return getAnnotation(annotationType) != null;
/*  42:    */   }
/*  43:    */   
/*  44:    */   @Nullable
/*  45:    */   public <A extends Annotation> A getAnnotation(Class<A> annotationType)
/*  46:    */   {
/*  47: 72 */     Preconditions.checkNotNull(annotationType);
/*  48: 73 */     for (Annotation annotation : this.annotations) {
/*  49: 74 */       if (annotationType.isInstance(annotation)) {
/*  50: 75 */         return (Annotation)annotationType.cast(annotation);
/*  51:    */       }
/*  52:    */     }
/*  53: 78 */     return null;
/*  54:    */   }
/*  55:    */   
/*  56:    */   public Annotation[] getAnnotations()
/*  57:    */   {
/*  58: 82 */     return getDeclaredAnnotations();
/*  59:    */   }
/*  60:    */   
/*  61:    */   public <A extends Annotation> A[] getAnnotationsByType(Class<A> annotationType)
/*  62:    */   {
/*  63: 90 */     return getDeclaredAnnotationsByType(annotationType);
/*  64:    */   }
/*  65:    */   
/*  66:    */   public Annotation[] getDeclaredAnnotations()
/*  67:    */   {
/*  68: 98 */     return (Annotation[])this.annotations.toArray(new Annotation[this.annotations.size()]);
/*  69:    */   }
/*  70:    */   
/*  71:    */   @Nullable
/*  72:    */   public <A extends Annotation> A getDeclaredAnnotation(Class<A> annotationType)
/*  73:    */   {
/*  74:107 */     Preconditions.checkNotNull(annotationType);
/*  75:108 */     return (Annotation)FluentIterable.from(this.annotations).filter(annotationType).first().orNull();
/*  76:    */   }
/*  77:    */   
/*  78:    */   public <A extends Annotation> A[] getDeclaredAnnotationsByType(Class<A> annotationType)
/*  79:    */   {
/*  80:120 */     return (Annotation[])FluentIterable.from(this.annotations).filter(annotationType).toArray(annotationType);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public boolean equals(@Nullable Object obj)
/*  84:    */   {
/*  85:126 */     if ((obj instanceof Parameter))
/*  86:    */     {
/*  87:127 */       Parameter that = (Parameter)obj;
/*  88:128 */       return (this.position == that.position) && (this.declaration.equals(that.declaration));
/*  89:    */     }
/*  90:130 */     return false;
/*  91:    */   }
/*  92:    */   
/*  93:    */   public int hashCode()
/*  94:    */   {
/*  95:134 */     return this.position;
/*  96:    */   }
/*  97:    */   
/*  98:    */   public String toString()
/*  99:    */   {
/* 100:138 */     return this.type + " arg" + this.position;
/* 101:    */   }
/* 102:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.Parameter
 * JD-Core Version:    0.7.0.1
 */