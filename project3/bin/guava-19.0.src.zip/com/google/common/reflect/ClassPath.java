/*   1:    */ package com.google.common.reflect;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.CharMatcher;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Predicate;
/*   8:    */ import com.google.common.base.Splitter;
/*   9:    */ import com.google.common.collect.FluentIterable;
/*  10:    */ import com.google.common.collect.ImmutableMap;
/*  11:    */ import com.google.common.collect.ImmutableSet;
/*  12:    */ import com.google.common.collect.ImmutableSet.Builder;
/*  13:    */ import com.google.common.collect.Maps;
/*  14:    */ import com.google.common.collect.MultimapBuilder;
/*  15:    */ import com.google.common.collect.MultimapBuilder.MultimapBuilderWithKeys;
/*  16:    */ import com.google.common.collect.MultimapBuilder.SetMultimapBuilder;
/*  17:    */ import com.google.common.collect.SetMultimap;
/*  18:    */ import com.google.common.collect.Sets;
/*  19:    */ import java.io.File;
/*  20:    */ import java.io.IOException;
/*  21:    */ import java.net.MalformedURLException;
/*  22:    */ import java.net.URI;
/*  23:    */ import java.net.URL;
/*  24:    */ import java.net.URLClassLoader;
/*  25:    */ import java.util.Enumeration;
/*  26:    */ import java.util.LinkedHashMap;
/*  27:    */ import java.util.Map.Entry;
/*  28:    */ import java.util.NoSuchElementException;
/*  29:    */ import java.util.Set;
/*  30:    */ import java.util.jar.Attributes;
/*  31:    */ import java.util.jar.Attributes.Name;
/*  32:    */ import java.util.jar.JarEntry;
/*  33:    */ import java.util.jar.JarFile;
/*  34:    */ import java.util.jar.Manifest;
/*  35:    */ import java.util.logging.Logger;
/*  36:    */ import javax.annotation.Nullable;
/*  37:    */ 
/*  38:    */ @Beta
/*  39:    */ public final class ClassPath
/*  40:    */ {
/*  41: 60 */   private static final Logger logger = Logger.getLogger(ClassPath.class.getName());
/*  42: 62 */   private static final Predicate<ClassInfo> IS_TOP_LEVEL = new Predicate()
/*  43:    */   {
/*  44:    */     public boolean apply(ClassPath.ClassInfo info)
/*  45:    */     {
/*  46: 64 */       return info.className.indexOf('$') == -1;
/*  47:    */     }
/*  48:    */   };
/*  49: 69 */   private static final Splitter CLASS_PATH_ATTRIBUTE_SEPARATOR = Splitter.on(" ").omitEmptyStrings();
/*  50:    */   private static final String CLASS_FILE_NAME_EXTENSION = ".class";
/*  51:    */   private final ImmutableSet<ResourceInfo> resources;
/*  52:    */   
/*  53:    */   private ClassPath(ImmutableSet<ResourceInfo> resources)
/*  54:    */   {
/*  55: 77 */     this.resources = resources;
/*  56:    */   }
/*  57:    */   
/*  58:    */   public static ClassPath from(ClassLoader classloader)
/*  59:    */     throws IOException
/*  60:    */   {
/*  61: 90 */     DefaultScanner scanner = new DefaultScanner();
/*  62: 91 */     scanner.scan(classloader);
/*  63: 92 */     return new ClassPath(scanner.getResources());
/*  64:    */   }
/*  65:    */   
/*  66:    */   public ImmutableSet<ResourceInfo> getResources()
/*  67:    */   {
/*  68:100 */     return this.resources;
/*  69:    */   }
/*  70:    */   
/*  71:    */   public ImmutableSet<ClassInfo> getAllClasses()
/*  72:    */   {
/*  73:109 */     return FluentIterable.from(this.resources).filter(ClassInfo.class).toSet();
/*  74:    */   }
/*  75:    */   
/*  76:    */   public ImmutableSet<ClassInfo> getTopLevelClasses()
/*  77:    */   {
/*  78:114 */     return FluentIterable.from(this.resources).filter(ClassInfo.class).filter(IS_TOP_LEVEL).toSet();
/*  79:    */   }
/*  80:    */   
/*  81:    */   public ImmutableSet<ClassInfo> getTopLevelClasses(String packageName)
/*  82:    */   {
/*  83:119 */     Preconditions.checkNotNull(packageName);
/*  84:120 */     ImmutableSet.Builder<ClassInfo> builder = ImmutableSet.builder();
/*  85:121 */     for (ClassInfo classInfo : getTopLevelClasses()) {
/*  86:122 */       if (classInfo.getPackageName().equals(packageName)) {
/*  87:123 */         builder.add(classInfo);
/*  88:    */       }
/*  89:    */     }
/*  90:126 */     return builder.build();
/*  91:    */   }
/*  92:    */   
/*  93:    */   public ImmutableSet<ClassInfo> getTopLevelClassesRecursive(String packageName)
/*  94:    */   {
/*  95:134 */     Preconditions.checkNotNull(packageName);
/*  96:135 */     String packagePrefix = packageName + '.';
/*  97:136 */     ImmutableSet.Builder<ClassInfo> builder = ImmutableSet.builder();
/*  98:137 */     for (ClassInfo classInfo : getTopLevelClasses()) {
/*  99:138 */       if (classInfo.getName().startsWith(packagePrefix)) {
/* 100:139 */         builder.add(classInfo);
/* 101:    */       }
/* 102:    */     }
/* 103:142 */     return builder.build();
/* 104:    */   }
/* 105:    */   
/* 106:    */   @Beta
/* 107:    */   public static class ResourceInfo
/* 108:    */   {
/* 109:    */     private final String resourceName;
/* 110:    */     final ClassLoader loader;
/* 111:    */     
/* 112:    */     static ResourceInfo of(String resourceName, ClassLoader loader)
/* 113:    */     {
/* 114:158 */       if (resourceName.endsWith(".class")) {
/* 115:159 */         return new ClassPath.ClassInfo(resourceName, loader);
/* 116:    */       }
/* 117:161 */       return new ResourceInfo(resourceName, loader);
/* 118:    */     }
/* 119:    */     
/* 120:    */     ResourceInfo(String resourceName, ClassLoader loader)
/* 121:    */     {
/* 122:166 */       this.resourceName = ((String)Preconditions.checkNotNull(resourceName));
/* 123:167 */       this.loader = ((ClassLoader)Preconditions.checkNotNull(loader));
/* 124:    */     }
/* 125:    */     
/* 126:    */     public final URL url()
/* 127:    */       throws NoSuchElementException
/* 128:    */     {
/* 129:178 */       URL url = this.loader.getResource(this.resourceName);
/* 130:179 */       if (url == null) {
/* 131:180 */         throw new NoSuchElementException(this.resourceName);
/* 132:    */       }
/* 133:182 */       return url;
/* 134:    */     }
/* 135:    */     
/* 136:    */     public final String getResourceName()
/* 137:    */     {
/* 138:187 */       return this.resourceName;
/* 139:    */     }
/* 140:    */     
/* 141:    */     public int hashCode()
/* 142:    */     {
/* 143:191 */       return this.resourceName.hashCode();
/* 144:    */     }
/* 145:    */     
/* 146:    */     public boolean equals(Object obj)
/* 147:    */     {
/* 148:195 */       if ((obj instanceof ResourceInfo))
/* 149:    */       {
/* 150:196 */         ResourceInfo that = (ResourceInfo)obj;
/* 151:197 */         return (this.resourceName.equals(that.resourceName)) && (this.loader == that.loader);
/* 152:    */       }
/* 153:200 */       return false;
/* 154:    */     }
/* 155:    */     
/* 156:    */     public String toString()
/* 157:    */     {
/* 158:205 */       return this.resourceName;
/* 159:    */     }
/* 160:    */   }
/* 161:    */   
/* 162:    */   @Beta
/* 163:    */   public static final class ClassInfo
/* 164:    */     extends ClassPath.ResourceInfo
/* 165:    */   {
/* 166:    */     private final String className;
/* 167:    */     
/* 168:    */     ClassInfo(String resourceName, ClassLoader loader)
/* 169:    */     {
/* 170:219 */       super(loader);
/* 171:220 */       this.className = ClassPath.getClassName(resourceName);
/* 172:    */     }
/* 173:    */     
/* 174:    */     public String getPackageName()
/* 175:    */     {
/* 176:230 */       return Reflection.getPackageName(this.className);
/* 177:    */     }
/* 178:    */     
/* 179:    */     public String getSimpleName()
/* 180:    */     {
/* 181:240 */       int lastDollarSign = this.className.lastIndexOf('$');
/* 182:241 */       if (lastDollarSign != -1)
/* 183:    */       {
/* 184:242 */         String innerClassName = this.className.substring(lastDollarSign + 1);
/* 185:    */         
/* 186:    */ 
/* 187:245 */         return CharMatcher.DIGIT.trimLeadingFrom(innerClassName);
/* 188:    */       }
/* 189:247 */       String packageName = getPackageName();
/* 190:248 */       if (packageName.isEmpty()) {
/* 191:249 */         return this.className;
/* 192:    */       }
/* 193:253 */       return this.className.substring(packageName.length() + 1);
/* 194:    */     }
/* 195:    */     
/* 196:    */     public String getName()
/* 197:    */     {
/* 198:263 */       return this.className;
/* 199:    */     }
/* 200:    */     
/* 201:    */     public Class<?> load()
/* 202:    */     {
/* 203:    */       try
/* 204:    */       {
/* 205:274 */         return this.loader.loadClass(this.className);
/* 206:    */       }
/* 207:    */       catch (ClassNotFoundException e)
/* 208:    */       {
/* 209:277 */         throw new IllegalStateException(e);
/* 210:    */       }
/* 211:    */     }
/* 212:    */     
/* 213:    */     public String toString()
/* 214:    */     {
/* 215:282 */       return this.className;
/* 216:    */     }
/* 217:    */   }
/* 218:    */   
/* 219:    */   static abstract class Scanner
/* 220:    */   {
/* 221:295 */     private final Set<File> scannedUris = Sets.newHashSet();
/* 222:    */     
/* 223:    */     public final void scan(ClassLoader classloader)
/* 224:    */       throws IOException
/* 225:    */     {
/* 226:298 */       for (Map.Entry<File, ClassLoader> entry : getClassPathEntries(classloader).entrySet()) {
/* 227:299 */         scan((File)entry.getKey(), (ClassLoader)entry.getValue());
/* 228:    */       }
/* 229:    */     }
/* 230:    */     
/* 231:    */     protected abstract void scanDirectory(ClassLoader paramClassLoader, File paramFile)
/* 232:    */       throws IOException;
/* 233:    */     
/* 234:    */     protected abstract void scanJarFile(ClassLoader paramClassLoader, JarFile paramJarFile)
/* 235:    */       throws IOException;
/* 236:    */     
/* 237:    */     @VisibleForTesting
/* 238:    */     final void scan(File file, ClassLoader classloader)
/* 239:    */       throws IOException
/* 240:    */     {
/* 241:311 */       if (this.scannedUris.add(file.getCanonicalFile())) {
/* 242:312 */         scanFrom(file, classloader);
/* 243:    */       }
/* 244:    */     }
/* 245:    */     
/* 246:    */     private void scanFrom(File file, ClassLoader classloader)
/* 247:    */       throws IOException
/* 248:    */     {
/* 249:317 */       if (!file.exists()) {
/* 250:318 */         return;
/* 251:    */       }
/* 252:320 */       if (file.isDirectory()) {
/* 253:321 */         scanDirectory(classloader, file);
/* 254:    */       } else {
/* 255:323 */         scanJar(file, classloader);
/* 256:    */       }
/* 257:    */     }
/* 258:    */     
/* 259:    */     private void scanJar(File file, ClassLoader classloader)
/* 260:    */       throws IOException
/* 261:    */     {
/* 262:    */       JarFile jarFile;
/* 263:    */       try
/* 264:    */       {
/* 265:330 */         jarFile = new JarFile(file);
/* 266:    */       }
/* 267:    */       catch (IOException e)
/* 268:    */       {
/* 269:333 */         return;
/* 270:    */       }
/* 271:    */       try
/* 272:    */       {
/* 273:336 */         for (File path : getClassPathFromManifest(file, jarFile.getManifest())) {
/* 274:337 */           scan(path, classloader);
/* 275:    */         }
/* 276:339 */         scanJarFile(classloader, jarFile); return;
/* 277:    */       }
/* 278:    */       finally
/* 279:    */       {
/* 280:    */         try
/* 281:    */         {
/* 282:342 */           jarFile.close();
/* 283:    */         }
/* 284:    */         catch (IOException ignored) {}
/* 285:    */       }
/* 286:    */     }
/* 287:    */     
/* 288:    */     @VisibleForTesting
/* 289:    */     static ImmutableSet<File> getClassPathFromManifest(File jarFile, @Nullable Manifest manifest)
/* 290:    */     {
/* 291:356 */       if (manifest == null) {
/* 292:357 */         return ImmutableSet.of();
/* 293:    */       }
/* 294:359 */       ImmutableSet.Builder<File> builder = ImmutableSet.builder();
/* 295:360 */       String classpathAttribute = manifest.getMainAttributes().getValue(Attributes.Name.CLASS_PATH.toString());
/* 296:362 */       if (classpathAttribute != null) {
/* 297:363 */         for (String path : ClassPath.CLASS_PATH_ATTRIBUTE_SEPARATOR.split(classpathAttribute))
/* 298:    */         {
/* 299:    */           URL url;
/* 300:    */           try
/* 301:    */           {
/* 302:366 */             url = getClassPathEntry(jarFile, path);
/* 303:    */           }
/* 304:    */           catch (MalformedURLException e)
/* 305:    */           {
/* 306:369 */             ClassPath.logger.warning("Invalid Class-Path entry: " + path);
/* 307:    */           }
/* 308:370 */           continue;
/* 309:372 */           if (url.getProtocol().equals("file")) {
/* 310:373 */             builder.add(new File(url.getFile()));
/* 311:    */           }
/* 312:    */         }
/* 313:    */       }
/* 314:377 */       return builder.build();
/* 315:    */     }
/* 316:    */     
/* 317:    */     @VisibleForTesting
/* 318:    */     static ImmutableMap<File, ClassLoader> getClassPathEntries(ClassLoader classloader)
/* 319:    */     {
/* 320:382 */       LinkedHashMap<File, ClassLoader> entries = Maps.newLinkedHashMap();
/* 321:    */       
/* 322:384 */       ClassLoader parent = classloader.getParent();
/* 323:385 */       if (parent != null) {
/* 324:386 */         entries.putAll(getClassPathEntries(parent));
/* 325:    */       }
/* 326:388 */       if ((classloader instanceof URLClassLoader))
/* 327:    */       {
/* 328:389 */         URLClassLoader urlClassLoader = (URLClassLoader)classloader;
/* 329:390 */         for (URL entry : urlClassLoader.getURLs()) {
/* 330:391 */           if (entry.getProtocol().equals("file"))
/* 331:    */           {
/* 332:392 */             File file = new File(entry.getFile());
/* 333:393 */             if (!entries.containsKey(file)) {
/* 334:394 */               entries.put(file, classloader);
/* 335:    */             }
/* 336:    */           }
/* 337:    */         }
/* 338:    */       }
/* 339:399 */       return ImmutableMap.copyOf(entries);
/* 340:    */     }
/* 341:    */     
/* 342:    */     @VisibleForTesting
/* 343:    */     static URL getClassPathEntry(File jarFile, String path)
/* 344:    */       throws MalformedURLException
/* 345:    */     {
/* 346:410 */       return new URL(jarFile.toURI().toURL(), path);
/* 347:    */     }
/* 348:    */   }
/* 349:    */   
/* 350:    */   @VisibleForTesting
/* 351:    */   static final class DefaultScanner
/* 352:    */     extends ClassPath.Scanner
/* 353:    */   {
/* 354:415 */     private final SetMultimap<ClassLoader, String> resources = MultimapBuilder.hashKeys().linkedHashSetValues().build();
/* 355:    */     
/* 356:    */     ImmutableSet<ClassPath.ResourceInfo> getResources()
/* 357:    */     {
/* 358:419 */       ImmutableSet.Builder<ClassPath.ResourceInfo> builder = ImmutableSet.builder();
/* 359:420 */       for (Map.Entry<ClassLoader, String> entry : this.resources.entries()) {
/* 360:421 */         builder.add(ClassPath.ResourceInfo.of((String)entry.getValue(), (ClassLoader)entry.getKey()));
/* 361:    */       }
/* 362:423 */       return builder.build();
/* 363:    */     }
/* 364:    */     
/* 365:    */     protected void scanJarFile(ClassLoader classloader, JarFile file)
/* 366:    */     {
/* 367:427 */       Enumeration<JarEntry> entries = file.entries();
/* 368:428 */       while (entries.hasMoreElements())
/* 369:    */       {
/* 370:429 */         JarEntry entry = (JarEntry)entries.nextElement();
/* 371:430 */         if ((!entry.isDirectory()) && (!entry.getName().equals("META-INF/MANIFEST.MF"))) {
/* 372:433 */           this.resources.get(classloader).add(entry.getName());
/* 373:    */         }
/* 374:    */       }
/* 375:    */     }
/* 376:    */     
/* 377:    */     protected void scanDirectory(ClassLoader classloader, File directory)
/* 378:    */       throws IOException
/* 379:    */     {
/* 380:439 */       scanDirectory(directory, classloader, "");
/* 381:    */     }
/* 382:    */     
/* 383:    */     private void scanDirectory(File directory, ClassLoader classloader, String packagePrefix)
/* 384:    */       throws IOException
/* 385:    */     {
/* 386:444 */       File[] files = directory.listFiles();
/* 387:445 */       if (files == null)
/* 388:    */       {
/* 389:446 */         ClassPath.logger.warning("Cannot read directory " + directory);
/* 390:    */         
/* 391:448 */         return;
/* 392:    */       }
/* 393:450 */       for (File f : files)
/* 394:    */       {
/* 395:451 */         String name = f.getName();
/* 396:452 */         if (f.isDirectory())
/* 397:    */         {
/* 398:453 */           scanDirectory(f, classloader, packagePrefix + name + "/");
/* 399:    */         }
/* 400:    */         else
/* 401:    */         {
/* 402:455 */           String resourceName = packagePrefix + name;
/* 403:456 */           if (!resourceName.equals("META-INF/MANIFEST.MF")) {
/* 404:457 */             this.resources.get(classloader).add(resourceName);
/* 405:    */           }
/* 406:    */         }
/* 407:    */       }
/* 408:    */     }
/* 409:    */   }
/* 410:    */   
/* 411:    */   @VisibleForTesting
/* 412:    */   static String getClassName(String filename)
/* 413:    */   {
/* 414:465 */     int classNameEnd = filename.length() - ".class".length();
/* 415:466 */     return filename.substring(0, classNameEnd).replace('/', '.');
/* 416:    */   }
/* 417:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.ClassPath
 * JD-Core Version:    0.7.0.1
 */