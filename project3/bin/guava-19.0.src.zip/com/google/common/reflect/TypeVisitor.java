/*  1:   */ package com.google.common.reflect;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.Sets;
/*  4:   */ import java.lang.reflect.GenericArrayType;
/*  5:   */ import java.lang.reflect.ParameterizedType;
/*  6:   */ import java.lang.reflect.Type;
/*  7:   */ import java.lang.reflect.TypeVariable;
/*  8:   */ import java.lang.reflect.WildcardType;
/*  9:   */ import java.util.Set;
/* 10:   */ import javax.annotation.concurrent.NotThreadSafe;
/* 11:   */ 
/* 12:   */ @NotThreadSafe
/* 13:   */ abstract class TypeVisitor
/* 14:   */ {
/* 15:63 */   private final Set<Type> visited = Sets.newHashSet();
/* 16:   */   
/* 17:   */   public final void visit(Type... types)
/* 18:   */   {
/* 19:70 */     for (Type type : types) {
/* 20:71 */       if ((type != null) && (this.visited.add(type)))
/* 21:   */       {
/* 22:75 */         boolean succeeded = false;
/* 23:   */         try
/* 24:   */         {
/* 25:77 */           if ((type instanceof TypeVariable)) {
/* 26:78 */             visitTypeVariable((TypeVariable)type);
/* 27:79 */           } else if ((type instanceof WildcardType)) {
/* 28:80 */             visitWildcardType((WildcardType)type);
/* 29:81 */           } else if ((type instanceof ParameterizedType)) {
/* 30:82 */             visitParameterizedType((ParameterizedType)type);
/* 31:83 */           } else if ((type instanceof Class)) {
/* 32:84 */             visitClass((Class)type);
/* 33:85 */           } else if ((type instanceof GenericArrayType)) {
/* 34:86 */             visitGenericArrayType((GenericArrayType)type);
/* 35:   */           } else {
/* 36:88 */             throw new AssertionError("Unknown type: " + type);
/* 37:   */           }
/* 38:90 */           succeeded = true;
/* 39:   */         }
/* 40:   */         finally
/* 41:   */         {
/* 42:92 */           if (!succeeded) {
/* 43:93 */             this.visited.remove(type);
/* 44:   */           }
/* 45:   */         }
/* 46:   */       }
/* 47:   */     }
/* 48:   */   }
/* 49:   */   
/* 50:   */   void visitClass(Class<?> t) {}
/* 51:   */   
/* 52:   */   void visitGenericArrayType(GenericArrayType t) {}
/* 53:   */   
/* 54:   */   void visitParameterizedType(ParameterizedType t) {}
/* 55:   */   
/* 56:   */   void visitTypeVariable(TypeVariable<?> t) {}
/* 57:   */   
/* 58:   */   void visitWildcardType(WildcardType t) {}
/* 59:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.reflect.TypeVisitor
 * JD-Core Version:    0.7.0.1
 */