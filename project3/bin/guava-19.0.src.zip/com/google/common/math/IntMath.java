/*   1:    */ package com.google.common.math;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import java.math.RoundingMode;
/*   8:    */ 
/*   9:    */ @GwtCompatible(emulated=true)
/*  10:    */ public final class IntMath
/*  11:    */ {
/*  12:    */   @VisibleForTesting
/*  13:    */   static final int MAX_POWER_OF_SQRT2_UNSIGNED = -1257966797;
/*  14:    */   
/*  15:    */   public static boolean isPowerOfTwo(int x)
/*  16:    */   {
/*  17: 63 */     return (x > 0 ? 1 : 0) & ((x & x - 1) == 0 ? 1 : 0);
/*  18:    */   }
/*  19:    */   
/*  20:    */   @VisibleForTesting
/*  21:    */   static int lessThanBranchFree(int x, int y)
/*  22:    */   {
/*  23: 75 */     return (x - y ^ 0xFFFFFFFF ^ 0xFFFFFFFF) >>> 31;
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static int log2(int x, RoundingMode mode)
/*  27:    */   {
/*  28: 88 */     MathPreconditions.checkPositive("x", x);
/*  29: 89 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  30:    */     {
/*  31:    */     case 1: 
/*  32: 91 */       MathPreconditions.checkRoundingUnnecessary(isPowerOfTwo(x));
/*  33:    */     case 2: 
/*  34:    */     case 3: 
/*  35: 95 */       return 31 - Integer.numberOfLeadingZeros(x);
/*  36:    */     case 4: 
/*  37:    */     case 5: 
/*  38: 99 */       return 32 - Integer.numberOfLeadingZeros(x - 1);
/*  39:    */     case 6: 
/*  40:    */     case 7: 
/*  41:    */     case 8: 
/*  42:105 */       int leadingZeros = Integer.numberOfLeadingZeros(x);
/*  43:106 */       int cmp = -1257966797 >>> leadingZeros;
/*  44:    */       
/*  45:108 */       int logFloor = 31 - leadingZeros;
/*  46:109 */       return logFloor + lessThanBranchFree(cmp, x);
/*  47:    */     }
/*  48:112 */     throw new AssertionError();
/*  49:    */   }
/*  50:    */   
/*  51:    */   @GwtIncompatible("need BigIntegerMath to adequately test")
/*  52:    */   public static int log10(int x, RoundingMode mode)
/*  53:    */   {
/*  54:129 */     MathPreconditions.checkPositive("x", x);
/*  55:130 */     int logFloor = log10Floor(x);
/*  56:131 */     int floorPow = powersOf10[logFloor];
/*  57:132 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  58:    */     {
/*  59:    */     case 1: 
/*  60:134 */       MathPreconditions.checkRoundingUnnecessary(x == floorPow);
/*  61:    */     case 2: 
/*  62:    */     case 3: 
/*  63:138 */       return logFloor;
/*  64:    */     case 4: 
/*  65:    */     case 5: 
/*  66:141 */       return logFloor + lessThanBranchFree(floorPow, x);
/*  67:    */     case 6: 
/*  68:    */     case 7: 
/*  69:    */     case 8: 
/*  70:146 */       return logFloor + lessThanBranchFree(halfPowersOf10[logFloor], x);
/*  71:    */     }
/*  72:148 */     throw new AssertionError();
/*  73:    */   }
/*  74:    */   
/*  75:    */   private static int log10Floor(int x)
/*  76:    */   {
/*  77:160 */     int y = maxLog10ForLeadingZeros[Integer.numberOfLeadingZeros(x)];
/*  78:    */     
/*  79:    */ 
/*  80:    */ 
/*  81:    */ 
/*  82:165 */     return y - lessThanBranchFree(x, powersOf10[y]);
/*  83:    */   }
/*  84:    */   
/*  85:    */   @VisibleForTesting
/*  86:169 */   static final byte[] maxLog10ForLeadingZeros = { 9, 9, 9, 8, 8, 8, 7, 7, 7, 6, 6, 6, 6, 5, 5, 5, 4, 4, 4, 3, 3, 3, 3, 2, 2, 2, 1, 1, 1, 0, 0, 0, 0 };
/*  87:    */   @VisibleForTesting
/*  88:172 */   static final int[] powersOf10 = { 1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000 };
/*  89:    */   @VisibleForTesting
/*  90:176 */   static final int[] halfPowersOf10 = { 3, 31, 316, 3162, 31622, 316227, 3162277, 31622776, 316227766, 2147483647 };
/*  91:    */   @VisibleForTesting
/*  92:    */   static final int FLOOR_SQRT_MAX_INT = 46340;
/*  93:    */   
/*  94:    */   @GwtIncompatible("failing tests")
/*  95:    */   public static int pow(int b, int k)
/*  96:    */   {
/*  97:190 */     MathPreconditions.checkNonNegative("exponent", k);
/*  98:191 */     switch (b)
/*  99:    */     {
/* 100:    */     case 0: 
/* 101:193 */       return k == 0 ? 1 : 0;
/* 102:    */     case 1: 
/* 103:195 */       return 1;
/* 104:    */     case -1: 
/* 105:197 */       return (k & 0x1) == 0 ? 1 : -1;
/* 106:    */     case 2: 
/* 107:199 */       return k < 32 ? 1 << k : 0;
/* 108:    */     case -2: 
/* 109:201 */       if (k < 32) {
/* 110:202 */         return (k & 0x1) == 0 ? 1 << k : -(1 << k);
/* 111:    */       }
/* 112:204 */       return 0;
/* 113:    */     }
/* 114:209 */     for (int accum = 1;; k >>= 1)
/* 115:    */     {
/* 116:210 */       switch (k)
/* 117:    */       {
/* 118:    */       case 0: 
/* 119:212 */         return accum;
/* 120:    */       case 1: 
/* 121:214 */         return b * accum;
/* 122:    */       }
/* 123:216 */       accum *= ((k & 0x1) == 0 ? 1 : b);
/* 124:217 */       b *= b;
/* 125:    */     }
/* 126:    */   }
/* 127:    */   
/* 128:    */   @GwtIncompatible("need BigIntegerMath to adequately test")
/* 129:    */   public static int sqrt(int x, RoundingMode mode)
/* 130:    */   {
/* 131:232 */     MathPreconditions.checkNonNegative("x", x);
/* 132:233 */     int sqrtFloor = sqrtFloor(x);
/* 133:234 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/* 134:    */     {
/* 135:    */     case 1: 
/* 136:236 */       MathPreconditions.checkRoundingUnnecessary(sqrtFloor * sqrtFloor == x);
/* 137:    */     case 2: 
/* 138:    */     case 3: 
/* 139:239 */       return sqrtFloor;
/* 140:    */     case 4: 
/* 141:    */     case 5: 
/* 142:242 */       return sqrtFloor + lessThanBranchFree(sqrtFloor * sqrtFloor, x);
/* 143:    */     case 6: 
/* 144:    */     case 7: 
/* 145:    */     case 8: 
/* 146:246 */       int halfSquare = sqrtFloor * sqrtFloor + sqrtFloor;
/* 147:    */       
/* 148:    */ 
/* 149:    */ 
/* 150:    */ 
/* 151:    */ 
/* 152:    */ 
/* 153:    */ 
/* 154:    */ 
/* 155:    */ 
/* 156:    */ 
/* 157:    */ 
/* 158:258 */       return sqrtFloor + lessThanBranchFree(halfSquare, x);
/* 159:    */     }
/* 160:260 */     throw new AssertionError();
/* 161:    */   }
/* 162:    */   
/* 163:    */   private static int sqrtFloor(int x)
/* 164:    */   {
/* 165:267 */     return (int)Math.sqrt(x);
/* 166:    */   }
/* 167:    */   
/* 168:    */   public static int divide(int p, int q, RoundingMode mode)
/* 169:    */   {
/* 170:279 */     Preconditions.checkNotNull(mode);
/* 171:280 */     if (q == 0) {
/* 172:281 */       throw new ArithmeticException("/ by zero");
/* 173:    */     }
/* 174:283 */     int div = p / q;
/* 175:284 */     int rem = p - q * div;
/* 176:286 */     if (rem == 0) {
/* 177:287 */       return div;
/* 178:    */     }
/* 179:297 */     int signum = 0x1 | (p ^ q) >> 31;
/* 180:    */     boolean increment;
/* 181:    */     boolean increment;
/* 182:299 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/* 183:    */     {
/* 184:    */     case 1: 
/* 185:301 */       MathPreconditions.checkRoundingUnnecessary(rem == 0);
/* 186:    */     case 2: 
/* 187:304 */       increment = false;
/* 188:305 */       break;
/* 189:    */     case 4: 
/* 190:307 */       increment = true;
/* 191:308 */       break;
/* 192:    */     case 5: 
/* 193:310 */       increment = signum > 0;
/* 194:311 */       break;
/* 195:    */     case 3: 
/* 196:313 */       increment = signum < 0;
/* 197:314 */       break;
/* 198:    */     case 6: 
/* 199:    */     case 7: 
/* 200:    */     case 8: 
/* 201:318 */       int absRem = Math.abs(rem);
/* 202:319 */       int cmpRemToHalfDivisor = absRem - (Math.abs(q) - absRem);
/* 203:322 */       if (cmpRemToHalfDivisor == 0)
/* 204:    */       {
/* 205:323 */         if (mode != RoundingMode.HALF_UP) {}
/* 206:323 */         increment = ((mode == RoundingMode.HALF_EVEN ? 1 : 0) & ((div & 0x1) != 0 ? 1 : 0)) != 0;
/* 207:    */       }
/* 208:    */       else
/* 209:    */       {
/* 210:325 */         increment = cmpRemToHalfDivisor > 0;
/* 211:    */       }
/* 212:327 */       break;
/* 213:    */     default: 
/* 214:329 */       throw new AssertionError();
/* 215:    */     }
/* 216:331 */     return increment ? div + signum : div;
/* 217:    */   }
/* 218:    */   
/* 219:    */   public static int mod(int x, int m)
/* 220:    */   {
/* 221:351 */     if (m <= 0) {
/* 222:352 */       throw new ArithmeticException("Modulus " + m + " must be > 0");
/* 223:    */     }
/* 224:354 */     int result = x % m;
/* 225:355 */     return result >= 0 ? result : result + m;
/* 226:    */   }
/* 227:    */   
/* 228:    */   public static int gcd(int a, int b)
/* 229:    */   {
/* 230:370 */     MathPreconditions.checkNonNegative("a", a);
/* 231:371 */     MathPreconditions.checkNonNegative("b", b);
/* 232:372 */     if (a == 0) {
/* 233:375 */       return b;
/* 234:    */     }
/* 235:376 */     if (b == 0) {
/* 236:377 */       return a;
/* 237:    */     }
/* 238:383 */     int aTwos = Integer.numberOfTrailingZeros(a);
/* 239:384 */     a >>= aTwos;
/* 240:385 */     int bTwos = Integer.numberOfTrailingZeros(b);
/* 241:386 */     b >>= bTwos;
/* 242:387 */     while (a != b)
/* 243:    */     {
/* 244:395 */       int delta = a - b;
/* 245:    */       
/* 246:397 */       int minDeltaOrZero = delta & delta >> 31;
/* 247:    */       
/* 248:    */ 
/* 249:400 */       a = delta - minDeltaOrZero - minDeltaOrZero;
/* 250:    */       
/* 251:    */ 
/* 252:403 */       b += minDeltaOrZero;
/* 253:404 */       a >>= Integer.numberOfTrailingZeros(a);
/* 254:    */     }
/* 255:406 */     return a << Math.min(aTwos, bTwos);
/* 256:    */   }
/* 257:    */   
/* 258:    */   public static int checkedAdd(int a, int b)
/* 259:    */   {
/* 260:415 */     long result = a + b;
/* 261:416 */     MathPreconditions.checkNoOverflow(result == (int)result);
/* 262:417 */     return (int)result;
/* 263:    */   }
/* 264:    */   
/* 265:    */   public static int checkedSubtract(int a, int b)
/* 266:    */   {
/* 267:426 */     long result = a - b;
/* 268:427 */     MathPreconditions.checkNoOverflow(result == (int)result);
/* 269:428 */     return (int)result;
/* 270:    */   }
/* 271:    */   
/* 272:    */   public static int checkedMultiply(int a, int b)
/* 273:    */   {
/* 274:437 */     long result = a * b;
/* 275:438 */     MathPreconditions.checkNoOverflow(result == (int)result);
/* 276:439 */     return (int)result;
/* 277:    */   }
/* 278:    */   
/* 279:    */   public static int checkedPow(int b, int k)
/* 280:    */   {
/* 281:451 */     MathPreconditions.checkNonNegative("exponent", k);
/* 282:452 */     switch (b)
/* 283:    */     {
/* 284:    */     case 0: 
/* 285:454 */       return k == 0 ? 1 : 0;
/* 286:    */     case 1: 
/* 287:456 */       return 1;
/* 288:    */     case -1: 
/* 289:458 */       return (k & 0x1) == 0 ? 1 : -1;
/* 290:    */     case 2: 
/* 291:460 */       MathPreconditions.checkNoOverflow(k < 31);
/* 292:461 */       return 1 << k;
/* 293:    */     case -2: 
/* 294:463 */       MathPreconditions.checkNoOverflow(k < 32);
/* 295:464 */       return (k & 0x1) == 0 ? 1 << k : -1 << k;
/* 296:    */     }
/* 297:468 */     int accum = 1;
/* 298:    */     for (;;)
/* 299:    */     {
/* 300:470 */       switch (k)
/* 301:    */       {
/* 302:    */       case 0: 
/* 303:472 */         return accum;
/* 304:    */       case 1: 
/* 305:474 */         return checkedMultiply(accum, b);
/* 306:    */       }
/* 307:476 */       if ((k & 0x1) != 0) {
/* 308:477 */         accum = checkedMultiply(accum, b);
/* 309:    */       }
/* 310:479 */       k >>= 1;
/* 311:480 */       if (k > 0)
/* 312:    */       {
/* 313:481 */         MathPreconditions.checkNoOverflow((-46340 <= b ? 1 : 0) & (b <= 46340 ? 1 : 0));
/* 314:482 */         b *= b;
/* 315:    */       }
/* 316:    */     }
/* 317:    */   }
/* 318:    */   
/* 319:    */   public static int factorial(int n)
/* 320:    */   {
/* 321:498 */     MathPreconditions.checkNonNegative("n", n);
/* 322:499 */     return n < factorials.length ? factorials[n] : 2147483647;
/* 323:    */   }
/* 324:    */   
/* 325:502 */   private static final int[] factorials = { 1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880, 3628800, 39916800, 479001600 };
/* 326:    */   
/* 327:    */   @GwtIncompatible("need BigIntegerMath to adequately test")
/* 328:    */   public static int binomial(int n, int k)
/* 329:    */   {
/* 330:525 */     MathPreconditions.checkNonNegative("n", n);
/* 331:526 */     MathPreconditions.checkNonNegative("k", k);
/* 332:527 */     Preconditions.checkArgument(k <= n, "k (%s) > n (%s)", new Object[] { Integer.valueOf(k), Integer.valueOf(n) });
/* 333:528 */     if (k > n >> 1) {
/* 334:529 */       k = n - k;
/* 335:    */     }
/* 336:531 */     if ((k >= biggestBinomials.length) || (n > biggestBinomials[k])) {
/* 337:532 */       return 2147483647;
/* 338:    */     }
/* 339:534 */     switch (k)
/* 340:    */     {
/* 341:    */     case 0: 
/* 342:536 */       return 1;
/* 343:    */     case 1: 
/* 344:538 */       return n;
/* 345:    */     }
/* 346:540 */     long result = 1L;
/* 347:541 */     for (int i = 0; i < k; i++)
/* 348:    */     {
/* 349:542 */       result *= (n - i);
/* 350:543 */       result /= (i + 1);
/* 351:    */     }
/* 352:545 */     return (int)result;
/* 353:    */   }
/* 354:    */   
/* 355:    */   @VisibleForTesting
/* 356:550 */   static int[] biggestBinomials = { 2147483647, 2147483647, 65536, 2345, 477, 193, 110, 75, 58, 49, 43, 39, 37, 35, 34, 34, 33 };
/* 357:    */   
/* 358:    */   public static int mean(int x, int y)
/* 359:    */   {
/* 360:580 */     return (x & y) + ((x ^ y) >> 1);
/* 361:    */   }
/* 362:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.math.IntMath
 * JD-Core Version:    0.7.0.1
 */