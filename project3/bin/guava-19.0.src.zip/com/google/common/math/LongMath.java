/*   1:    */ package com.google.common.math;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.annotations.VisibleForTesting;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.primitives.UnsignedLongs;
/*   8:    */ import java.math.RoundingMode;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ public final class LongMath
/*  12:    */ {
/*  13:    */   @VisibleForTesting
/*  14:    */   static final long MAX_POWER_OF_SQRT2_UNSIGNED = -5402926248376769404L;
/*  15:    */   
/*  16:    */   public static boolean isPowerOfTwo(long x)
/*  17:    */   {
/*  18: 63 */     return (x > 0L ? 1 : 0) & ((x & x - 1L) == 0L ? 1 : 0);
/*  19:    */   }
/*  20:    */   
/*  21:    */   @VisibleForTesting
/*  22:    */   static int lessThanBranchFree(long x, long y)
/*  23:    */   {
/*  24: 74 */     return (int)((x - y ^ 0xFFFFFFFF ^ 0xFFFFFFFF) >>> 63);
/*  25:    */   }
/*  26:    */   
/*  27:    */   public static int log2(long x, RoundingMode mode)
/*  28:    */   {
/*  29: 87 */     MathPreconditions.checkPositive("x", x);
/*  30: 88 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  31:    */     {
/*  32:    */     case 1: 
/*  33: 90 */       MathPreconditions.checkRoundingUnnecessary(isPowerOfTwo(x));
/*  34:    */     case 2: 
/*  35:    */     case 3: 
/*  36: 94 */       return 63 - Long.numberOfLeadingZeros(x);
/*  37:    */     case 4: 
/*  38:    */     case 5: 
/*  39: 98 */       return 64 - Long.numberOfLeadingZeros(x - 1L);
/*  40:    */     case 6: 
/*  41:    */     case 7: 
/*  42:    */     case 8: 
/*  43:104 */       int leadingZeros = Long.numberOfLeadingZeros(x);
/*  44:105 */       long cmp = -5402926248376769404L >>> leadingZeros;
/*  45:    */       
/*  46:107 */       int logFloor = 63 - leadingZeros;
/*  47:108 */       return logFloor + lessThanBranchFree(cmp, x);
/*  48:    */     }
/*  49:111 */     throw new AssertionError("impossible");
/*  50:    */   }
/*  51:    */   
/*  52:    */   @GwtIncompatible("TODO")
/*  53:    */   public static int log10(long x, RoundingMode mode)
/*  54:    */   {
/*  55:129 */     MathPreconditions.checkPositive("x", x);
/*  56:130 */     int logFloor = log10Floor(x);
/*  57:131 */     long floorPow = powersOf10[logFloor];
/*  58:132 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/*  59:    */     {
/*  60:    */     case 1: 
/*  61:134 */       MathPreconditions.checkRoundingUnnecessary(x == floorPow);
/*  62:    */     case 2: 
/*  63:    */     case 3: 
/*  64:138 */       return logFloor;
/*  65:    */     case 4: 
/*  66:    */     case 5: 
/*  67:141 */       return logFloor + lessThanBranchFree(floorPow, x);
/*  68:    */     case 6: 
/*  69:    */     case 7: 
/*  70:    */     case 8: 
/*  71:146 */       return logFloor + lessThanBranchFree(halfPowersOf10[logFloor], x);
/*  72:    */     }
/*  73:148 */     throw new AssertionError();
/*  74:    */   }
/*  75:    */   
/*  76:    */   @GwtIncompatible("TODO")
/*  77:    */   static int log10Floor(long x)
/*  78:    */   {
/*  79:161 */     int y = maxLog10ForLeadingZeros[Long.numberOfLeadingZeros(x)];
/*  80:    */     
/*  81:    */ 
/*  82:    */ 
/*  83:    */ 
/*  84:166 */     return y - lessThanBranchFree(x, powersOf10[y]);
/*  85:    */   }
/*  86:    */   
/*  87:    */   @VisibleForTesting
/*  88:170 */   static final byte[] maxLog10ForLeadingZeros = { 19, 18, 18, 18, 18, 17, 17, 17, 16, 16, 16, 15, 15, 15, 15, 14, 14, 14, 13, 13, 13, 12, 12, 12, 12, 11, 11, 11, 10, 10, 10, 9, 9, 9, 9, 8, 8, 8, 7, 7, 7, 6, 6, 6, 6, 5, 5, 5, 4, 4, 4, 3, 3, 3, 3, 2, 2, 2, 1, 1, 1, 0, 0, 0 };
/*  89:    */   @GwtIncompatible("TODO")
/*  90:    */   @VisibleForTesting
/*  91:177 */   static final long[] powersOf10 = { 1L, 10L, 100L, 1000L, 10000L, 100000L, 1000000L, 10000000L, 100000000L, 1000000000L, 10000000000L, 100000000000L, 1000000000000L, 10000000000000L, 100000000000000L, 1000000000000000L, 10000000000000000L, 100000000000000000L, 1000000000000000000L };
/*  92:    */   @GwtIncompatible("TODO")
/*  93:    */   @VisibleForTesting
/*  94:202 */   static final long[] halfPowersOf10 = { 3L, 31L, 316L, 3162L, 31622L, 316227L, 3162277L, 31622776L, 316227766L, 3162277660L, 31622776601L, 316227766016L, 3162277660168L, 31622776601683L, 316227766016837L, 3162277660168379L, 31622776601683793L, 316227766016837933L, 3162277660168379331L };
/*  95:    */   @VisibleForTesting
/*  96:    */   static final long FLOOR_SQRT_MAX_LONG = 3037000499L;
/*  97:    */   
/*  98:    */   @GwtIncompatible("TODO")
/*  99:    */   public static long pow(long b, int k)
/* 100:    */   {
/* 101:233 */     MathPreconditions.checkNonNegative("exponent", k);
/* 102:234 */     if ((-2L <= b) && (b <= 2L))
/* 103:    */     {
/* 104:235 */       switch ((int)b)
/* 105:    */       {
/* 106:    */       case 0: 
/* 107:237 */         return k == 0 ? 1L : 0L;
/* 108:    */       case 1: 
/* 109:239 */         return 1L;
/* 110:    */       case -1: 
/* 111:241 */         return (k & 0x1) == 0 ? 1L : -1L;
/* 112:    */       case 2: 
/* 113:243 */         return k < 64 ? 1L << k : 0L;
/* 114:    */       case -2: 
/* 115:245 */         if (k < 64) {
/* 116:246 */           return (k & 0x1) == 0 ? 1L << k : -(1L << k);
/* 117:    */         }
/* 118:248 */         return 0L;
/* 119:    */       }
/* 120:251 */       throw new AssertionError();
/* 121:    */     }
/* 122:254 */     for (long accum = 1L;; k >>= 1)
/* 123:    */     {
/* 124:255 */       switch (k)
/* 125:    */       {
/* 126:    */       case 0: 
/* 127:257 */         return accum;
/* 128:    */       case 1: 
/* 129:259 */         return accum * b;
/* 130:    */       }
/* 131:261 */       accum *= ((k & 0x1) == 0 ? 1L : b);
/* 132:262 */       b *= b;
/* 133:    */     }
/* 134:    */   }
/* 135:    */   
/* 136:    */   @GwtIncompatible("TODO")
/* 137:    */   public static long sqrt(long x, RoundingMode mode)
/* 138:    */   {
/* 139:277 */     MathPreconditions.checkNonNegative("x", x);
/* 140:278 */     if (fitsInInt(x)) {
/* 141:279 */       return IntMath.sqrt((int)x, mode);
/* 142:    */     }
/* 143:296 */     long guess = Math.sqrt(x);
/* 144:    */     
/* 145:298 */     long guessSquared = guess * guess;
/* 146:301 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/* 147:    */     {
/* 148:    */     case 1: 
/* 149:303 */       MathPreconditions.checkRoundingUnnecessary(guessSquared == x);
/* 150:304 */       return guess;
/* 151:    */     case 2: 
/* 152:    */     case 3: 
/* 153:307 */       if (x < guessSquared) {
/* 154:308 */         return guess - 1L;
/* 155:    */       }
/* 156:310 */       return guess;
/* 157:    */     case 4: 
/* 158:    */     case 5: 
/* 159:313 */       if (x > guessSquared) {
/* 160:314 */         return guess + 1L;
/* 161:    */       }
/* 162:316 */       return guess;
/* 163:    */     case 6: 
/* 164:    */     case 7: 
/* 165:    */     case 8: 
/* 166:320 */       long sqrtFloor = guess - (x < guessSquared ? 1 : 0);
/* 167:321 */       long halfSquare = sqrtFloor * sqrtFloor + sqrtFloor;
/* 168:    */       
/* 169:    */ 
/* 170:    */ 
/* 171:    */ 
/* 172:    */ 
/* 173:    */ 
/* 174:    */ 
/* 175:    */ 
/* 176:    */ 
/* 177:    */ 
/* 178:    */ 
/* 179:333 */       return sqrtFloor + lessThanBranchFree(halfSquare, x);
/* 180:    */     }
/* 181:335 */     throw new AssertionError();
/* 182:    */   }
/* 183:    */   
/* 184:    */   @GwtIncompatible("TODO")
/* 185:    */   public static long divide(long p, long q, RoundingMode mode)
/* 186:    */   {
/* 187:349 */     Preconditions.checkNotNull(mode);
/* 188:350 */     long div = p / q;
/* 189:351 */     long rem = p - q * div;
/* 190:353 */     if (rem == 0L) {
/* 191:354 */       return div;
/* 192:    */     }
/* 193:364 */     int signum = 0x1 | (int)((p ^ q) >> 63);
/* 194:    */     boolean increment;
/* 195:    */     boolean increment;
/* 196:366 */     switch (1.$SwitchMap$java$math$RoundingMode[mode.ordinal()])
/* 197:    */     {
/* 198:    */     case 1: 
/* 199:368 */       MathPreconditions.checkRoundingUnnecessary(rem == 0L);
/* 200:    */     case 2: 
/* 201:371 */       increment = false;
/* 202:372 */       break;
/* 203:    */     case 4: 
/* 204:374 */       increment = true;
/* 205:375 */       break;
/* 206:    */     case 5: 
/* 207:377 */       increment = signum > 0;
/* 208:378 */       break;
/* 209:    */     case 3: 
/* 210:380 */       increment = signum < 0;
/* 211:381 */       break;
/* 212:    */     case 6: 
/* 213:    */     case 7: 
/* 214:    */     case 8: 
/* 215:385 */       long absRem = Math.abs(rem);
/* 216:386 */       long cmpRemToHalfDivisor = absRem - (Math.abs(q) - absRem);
/* 217:389 */       if (cmpRemToHalfDivisor == 0L) {
/* 218:390 */         increment = (mode == RoundingMode.HALF_UP ? 1 : 0) | (mode == RoundingMode.HALF_EVEN ? 1 : 0) & ((div & 1L) != 0L ? 1 : 0);
/* 219:    */       } else {
/* 220:392 */         increment = cmpRemToHalfDivisor > 0L;
/* 221:    */       }
/* 222:394 */       break;
/* 223:    */     default: 
/* 224:396 */       throw new AssertionError();
/* 225:    */     }
/* 226:398 */     return increment ? div + signum : div;
/* 227:    */   }
/* 228:    */   
/* 229:    */   @GwtIncompatible("TODO")
/* 230:    */   public static int mod(long x, int m)
/* 231:    */   {
/* 232:422 */     return (int)mod(x, m);
/* 233:    */   }
/* 234:    */   
/* 235:    */   @GwtIncompatible("TODO")
/* 236:    */   public static long mod(long x, long m)
/* 237:    */   {
/* 238:445 */     if (m <= 0L) {
/* 239:446 */       throw new ArithmeticException("Modulus must be positive");
/* 240:    */     }
/* 241:448 */     long result = x % m;
/* 242:449 */     return result >= 0L ? result : result + m;
/* 243:    */   }
/* 244:    */   
/* 245:    */   public static long gcd(long a, long b)
/* 246:    */   {
/* 247:464 */     MathPreconditions.checkNonNegative("a", a);
/* 248:465 */     MathPreconditions.checkNonNegative("b", b);
/* 249:466 */     if (a == 0L) {
/* 250:469 */       return b;
/* 251:    */     }
/* 252:470 */     if (b == 0L) {
/* 253:471 */       return a;
/* 254:    */     }
/* 255:477 */     int aTwos = Long.numberOfTrailingZeros(a);
/* 256:478 */     a >>= aTwos;
/* 257:479 */     int bTwos = Long.numberOfTrailingZeros(b);
/* 258:480 */     b >>= bTwos;
/* 259:481 */     while (a != b)
/* 260:    */     {
/* 261:489 */       long delta = a - b;
/* 262:    */       
/* 263:491 */       long minDeltaOrZero = delta & delta >> 63;
/* 264:    */       
/* 265:    */ 
/* 266:494 */       a = delta - minDeltaOrZero - minDeltaOrZero;
/* 267:    */       
/* 268:    */ 
/* 269:497 */       b += minDeltaOrZero;
/* 270:498 */       a >>= Long.numberOfTrailingZeros(a);
/* 271:    */     }
/* 272:500 */     return a << Math.min(aTwos, bTwos);
/* 273:    */   }
/* 274:    */   
/* 275:    */   @GwtIncompatible("TODO")
/* 276:    */   public static long checkedAdd(long a, long b)
/* 277:    */   {
/* 278:510 */     long result = a + b;
/* 279:511 */     MathPreconditions.checkNoOverflow(((a ^ b) < 0L ? 1 : 0) | ((a ^ result) >= 0L ? 1 : 0));
/* 280:512 */     return result;
/* 281:    */   }
/* 282:    */   
/* 283:    */   @GwtIncompatible("TODO")
/* 284:    */   public static long checkedSubtract(long a, long b)
/* 285:    */   {
/* 286:522 */     long result = a - b;
/* 287:523 */     MathPreconditions.checkNoOverflow(((a ^ b) >= 0L ? 1 : 0) | ((a ^ result) >= 0L ? 1 : 0));
/* 288:524 */     return result;
/* 289:    */   }
/* 290:    */   
/* 291:    */   @GwtIncompatible("TODO")
/* 292:    */   public static long checkedMultiply(long a, long b)
/* 293:    */   {
/* 294:535 */     int leadingZeros = Long.numberOfLeadingZeros(a) + Long.numberOfLeadingZeros(a ^ 0xFFFFFFFF) + Long.numberOfLeadingZeros(b) + Long.numberOfLeadingZeros(b ^ 0xFFFFFFFF);
/* 295:547 */     if (leadingZeros > 65) {
/* 296:548 */       return a * b;
/* 297:    */     }
/* 298:550 */     MathPreconditions.checkNoOverflow(leadingZeros >= 64);
/* 299:551 */     MathPreconditions.checkNoOverflow((a >= 0L ? 1 : 0) | (b != -9223372036854775808L ? 1 : 0));
/* 300:552 */     long result = a * b;
/* 301:553 */     MathPreconditions.checkNoOverflow((a == 0L) || (result / a == b));
/* 302:554 */     return result;
/* 303:    */   }
/* 304:    */   
/* 305:    */   @GwtIncompatible("TODO")
/* 306:    */   public static long checkedPow(long b, int k)
/* 307:    */   {
/* 308:565 */     MathPreconditions.checkNonNegative("exponent", k);
/* 309:566 */     if (((b >= -2L ? 1 : 0) & (b <= 2L ? 1 : 0)) != 0)
/* 310:    */     {
/* 311:567 */       switch ((int)b)
/* 312:    */       {
/* 313:    */       case 0: 
/* 314:569 */         return k == 0 ? 1L : 0L;
/* 315:    */       case 1: 
/* 316:571 */         return 1L;
/* 317:    */       case -1: 
/* 318:573 */         return (k & 0x1) == 0 ? 1L : -1L;
/* 319:    */       case 2: 
/* 320:575 */         MathPreconditions.checkNoOverflow(k < 63);
/* 321:576 */         return 1L << k;
/* 322:    */       case -2: 
/* 323:578 */         MathPreconditions.checkNoOverflow(k < 64);
/* 324:579 */         return (k & 0x1) == 0 ? 1L << k : -1L << k;
/* 325:    */       }
/* 326:581 */       throw new AssertionError();
/* 327:    */     }
/* 328:584 */     long accum = 1L;
/* 329:    */     for (;;)
/* 330:    */     {
/* 331:586 */       switch (k)
/* 332:    */       {
/* 333:    */       case 0: 
/* 334:588 */         return accum;
/* 335:    */       case 1: 
/* 336:590 */         return checkedMultiply(accum, b);
/* 337:    */       }
/* 338:592 */       if ((k & 0x1) != 0) {
/* 339:593 */         accum = checkedMultiply(accum, b);
/* 340:    */       }
/* 341:595 */       k >>= 1;
/* 342:596 */       if (k > 0)
/* 343:    */       {
/* 344:597 */         MathPreconditions.checkNoOverflow((-3037000499L <= b) && (b <= 3037000499L));
/* 345:598 */         b *= b;
/* 346:    */       }
/* 347:    */     }
/* 348:    */   }
/* 349:    */   
/* 350:    */   @GwtIncompatible("TODO")
/* 351:    */   public static long factorial(int n)
/* 352:    */   {
/* 353:615 */     MathPreconditions.checkNonNegative("n", n);
/* 354:616 */     return n < factorials.length ? factorials[n] : 9223372036854775807L;
/* 355:    */   }
/* 356:    */   
/* 357:619 */   static final long[] factorials = { 1L, 1L, 2L, 6L, 24L, 120L, 720L, 5040L, 40320L, 362880L, 3628800L, 39916800L, 479001600L, 6227020800L, 87178291200L, 1307674368000L, 20922789888000L, 355687428096000L, 6402373705728000L, 121645100408832000L, 2432902008176640000L };
/* 358:    */   
/* 359:    */   public static long binomial(int n, int k)
/* 360:    */   {
/* 361:650 */     MathPreconditions.checkNonNegative("n", n);
/* 362:651 */     MathPreconditions.checkNonNegative("k", k);
/* 363:652 */     Preconditions.checkArgument(k <= n, "k (%s) > n (%s)", new Object[] { Integer.valueOf(k), Integer.valueOf(n) });
/* 364:653 */     if (k > n >> 1) {
/* 365:654 */       k = n - k;
/* 366:    */     }
/* 367:656 */     switch (k)
/* 368:    */     {
/* 369:    */     case 0: 
/* 370:658 */       return 1L;
/* 371:    */     case 1: 
/* 372:660 */       return n;
/* 373:    */     }
/* 374:662 */     if (n < factorials.length) {
/* 375:663 */       return factorials[n] / (factorials[k] * factorials[(n - k)]);
/* 376:    */     }
/* 377:664 */     if ((k >= biggestBinomials.length) || (n > biggestBinomials[k])) {
/* 378:665 */       return 9223372036854775807L;
/* 379:    */     }
/* 380:666 */     if ((k < biggestSimpleBinomials.length) && (n <= biggestSimpleBinomials[k]))
/* 381:    */     {
/* 382:668 */       long result = n--;
/* 383:669 */       for (int i = 2; i <= k; i++)
/* 384:    */       {
/* 385:670 */         result *= n;
/* 386:671 */         result /= i;n--;
/* 387:    */       }
/* 388:673 */       return result;
/* 389:    */     }
/* 390:675 */     int nBits = log2(n, RoundingMode.CEILING);
/* 391:    */     
/* 392:677 */     long result = 1L;
/* 393:678 */     long numerator = n--;
/* 394:679 */     long denominator = 1L;
/* 395:    */     
/* 396:681 */     int numeratorBits = nBits;
/* 397:689 */     for (int i = 2; i <= k; n--)
/* 398:    */     {
/* 399:690 */       if (numeratorBits + nBits < 63)
/* 400:    */       {
/* 401:692 */         numerator *= n;
/* 402:693 */         denominator *= i;
/* 403:694 */         numeratorBits += nBits;
/* 404:    */       }
/* 405:    */       else
/* 406:    */       {
/* 407:698 */         result = multiplyFraction(result, numerator, denominator);
/* 408:699 */         numerator = n;
/* 409:700 */         denominator = i;
/* 410:701 */         numeratorBits = nBits;
/* 411:    */       }
/* 412:689 */       i++;
/* 413:    */     }
/* 414:704 */     return multiplyFraction(result, numerator, denominator);
/* 415:    */   }
/* 416:    */   
/* 417:    */   static long multiplyFraction(long x, long numerator, long denominator)
/* 418:    */   {
/* 419:713 */     if (x == 1L) {
/* 420:714 */       return numerator / denominator;
/* 421:    */     }
/* 422:716 */     long commonDivisor = gcd(x, denominator);
/* 423:717 */     x /= commonDivisor;
/* 424:718 */     denominator /= commonDivisor;
/* 425:    */     
/* 426:    */ 
/* 427:721 */     return x * (numerator / denominator);
/* 428:    */   }
/* 429:    */   
/* 430:728 */   static final int[] biggestBinomials = { 2147483647, 2147483647, 2147483647, 3810779, 121977, 16175, 4337, 1733, 887, 534, 361, 265, 206, 169, 143, 125, 111, 101, 94, 88, 83, 79, 76, 74, 72, 70, 69, 68, 67, 67, 66, 66, 66, 66 };
/* 431:    */   @VisibleForTesting
/* 432:737 */   static final int[] biggestSimpleBinomials = { 2147483647, 2147483647, 2147483647, 2642246, 86251, 11724, 3218, 1313, 684, 419, 287, 214, 169, 139, 119, 105, 95, 87, 81, 76, 73, 70, 68, 66, 64, 63, 62, 62, 61, 61, 61 };
/* 433:    */   
/* 434:    */   static boolean fitsInInt(long x)
/* 435:    */   {
/* 436:745 */     return (int)x == x;
/* 437:    */   }
/* 438:    */   
/* 439:    */   public static long mean(long x, long y)
/* 440:    */   {
/* 441:758 */     return (x & y) + ((x ^ y) >> 1);
/* 442:    */   }
/* 443:    */   
/* 444:768 */   private static final long[][] millerRabinBaseSets = { { 291830L, 126401071349994536L }, { 885594168L, 725270293939359937L, 3569819667048198375L }, { 273919523040L, 15L, 7363882082L, 992620450144556L }, { 47636622961200L, 2L, 2570940L, 211991001L, 3749873356L }, { 7999252175582850L, 2L, 4130806001517L, 149795463772692060L, 186635894390467037L, 3967304179347715805L }, { 585226005592931976L, 2L, 123635709730000L, 9233062284813009L, 43835965440333360L, 761179012939631437L, 1263739024124850375L }, { 9223372036854775807L, 2L, 325L, 9375L, 28178L, 450775L, 9780504L, 1795265022L } };
/* 445:    */   
/* 446:    */   private static abstract enum MillerRabinTester
/* 447:    */   {
/* 448:786 */     SMALL,  LARGE;
/* 449:    */     
/* 450:    */     private MillerRabinTester() {}
/* 451:    */     
/* 452:    */     static boolean test(long base, long n)
/* 453:    */     {
/* 454:888 */       return (n <= 3037000499L ? SMALL : LARGE).testWitness(base, n);
/* 455:    */     }
/* 456:    */     
/* 457:    */     abstract long mulMod(long paramLong1, long paramLong2, long paramLong3);
/* 458:    */     
/* 459:    */     abstract long squareMod(long paramLong1, long paramLong2);
/* 460:    */     
/* 461:    */     private long powMod(long a, long p, long m)
/* 462:    */     {
/* 463:905 */       long res = 1L;
/* 464:906 */       for (; p != 0L; p >>= 1)
/* 465:    */       {
/* 466:907 */         if ((p & 1L) != 0L) {
/* 467:908 */           res = mulMod(res, a, m);
/* 468:    */         }
/* 469:910 */         a = squareMod(a, m);
/* 470:    */       }
/* 471:912 */       return res;
/* 472:    */     }
/* 473:    */     
/* 474:    */     private boolean testWitness(long base, long n)
/* 475:    */     {
/* 476:919 */       int r = Long.numberOfTrailingZeros(n - 1L);
/* 477:920 */       long d = n - 1L >> r;
/* 478:921 */       base %= n;
/* 479:922 */       if (base == 0L) {
/* 480:923 */         return true;
/* 481:    */       }
/* 482:926 */       long a = powMod(base, d, n);
/* 483:930 */       if (a == 1L) {
/* 484:931 */         return true;
/* 485:    */       }
/* 486:933 */       int j = 0;
/* 487:934 */       while (a != n - 1L)
/* 488:    */       {
/* 489:935 */         j++;
/* 490:935 */         if (j == r) {
/* 491:936 */           return false;
/* 492:    */         }
/* 493:938 */         a = squareMod(a, n);
/* 494:    */       }
/* 495:940 */       return true;
/* 496:    */     }
/* 497:    */   }
/* 498:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.math.LongMath
 * JD-Core Version:    0.7.0.1
 */