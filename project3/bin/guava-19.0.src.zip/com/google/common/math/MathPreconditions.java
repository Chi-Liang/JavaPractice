/*  1:   */ package com.google.common.math;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.math.BigInteger;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible
/*  8:   */ final class MathPreconditions
/*  9:   */ {
/* 10:   */   static int checkPositive(@Nullable String role, int x)
/* 11:   */   {
/* 12:31 */     if (x <= 0) {
/* 13:32 */       throw new IllegalArgumentException(role + " (" + x + ") must be > 0");
/* 14:   */     }
/* 15:34 */     return x;
/* 16:   */   }
/* 17:   */   
/* 18:   */   static long checkPositive(@Nullable String role, long x)
/* 19:   */   {
/* 20:38 */     if (x <= 0L) {
/* 21:39 */       throw new IllegalArgumentException(role + " (" + x + ") must be > 0");
/* 22:   */     }
/* 23:41 */     return x;
/* 24:   */   }
/* 25:   */   
/* 26:   */   static BigInteger checkPositive(@Nullable String role, BigInteger x)
/* 27:   */   {
/* 28:45 */     if (x.signum() <= 0) {
/* 29:46 */       throw new IllegalArgumentException(role + " (" + x + ") must be > 0");
/* 30:   */     }
/* 31:48 */     return x;
/* 32:   */   }
/* 33:   */   
/* 34:   */   static int checkNonNegative(@Nullable String role, int x)
/* 35:   */   {
/* 36:52 */     if (x < 0) {
/* 37:53 */       throw new IllegalArgumentException(role + " (" + x + ") must be >= 0");
/* 38:   */     }
/* 39:55 */     return x;
/* 40:   */   }
/* 41:   */   
/* 42:   */   static long checkNonNegative(@Nullable String role, long x)
/* 43:   */   {
/* 44:59 */     if (x < 0L) {
/* 45:60 */       throw new IllegalArgumentException(role + " (" + x + ") must be >= 0");
/* 46:   */     }
/* 47:62 */     return x;
/* 48:   */   }
/* 49:   */   
/* 50:   */   static BigInteger checkNonNegative(@Nullable String role, BigInteger x)
/* 51:   */   {
/* 52:66 */     if (x.signum() < 0) {
/* 53:67 */       throw new IllegalArgumentException(role + " (" + x + ") must be >= 0");
/* 54:   */     }
/* 55:69 */     return x;
/* 56:   */   }
/* 57:   */   
/* 58:   */   static double checkNonNegative(@Nullable String role, double x)
/* 59:   */   {
/* 60:73 */     if (x < 0.0D) {
/* 61:74 */       throw new IllegalArgumentException(role + " (" + x + ") must be >= 0");
/* 62:   */     }
/* 63:76 */     return x;
/* 64:   */   }
/* 65:   */   
/* 66:   */   static void checkRoundingUnnecessary(boolean condition)
/* 67:   */   {
/* 68:80 */     if (!condition) {
/* 69:81 */       throw new ArithmeticException("mode was UNNECESSARY, but rounding was necessary");
/* 70:   */     }
/* 71:   */   }
/* 72:   */   
/* 73:   */   static void checkInRange(boolean condition)
/* 74:   */   {
/* 75:86 */     if (!condition) {
/* 76:87 */       throw new ArithmeticException("not in range");
/* 77:   */     }
/* 78:   */   }
/* 79:   */   
/* 80:   */   static void checkNoOverflow(boolean condition)
/* 81:   */   {
/* 82:92 */     if (!condition) {
/* 83:93 */       throw new ArithmeticException("overflow");
/* 84:   */     }
/* 85:   */   }
/* 86:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.math.MathPreconditions
 * JD-Core Version:    0.7.0.1
 */