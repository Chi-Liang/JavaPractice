/*  1:   */ package com.google.common.eventbus;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import java.util.concurrent.Executor;
/*  5:   */ 
/*  6:   */ @Beta
/*  7:   */ public class AsyncEventBus
/*  8:   */   extends EventBus
/*  9:   */ {
/* 10:   */   public AsyncEventBus(String identifier, Executor executor)
/* 11:   */   {
/* 12:43 */     super(identifier, executor, Dispatcher.legacyAsync(), EventBus.LoggingHandler.INSTANCE);
/* 13:   */   }
/* 14:   */   
/* 15:   */   public AsyncEventBus(Executor executor, SubscriberExceptionHandler subscriberExceptionHandler)
/* 16:   */   {
/* 17:58 */     super("default", executor, Dispatcher.legacyAsync(), subscriberExceptionHandler);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public AsyncEventBus(Executor executor)
/* 21:   */   {
/* 22:70 */     super("default", executor, Dispatcher.legacyAsync(), EventBus.LoggingHandler.INSTANCE);
/* 23:   */   }
/* 24:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.eventbus.AsyncEventBus
 * JD-Core Version:    0.7.0.1
 */