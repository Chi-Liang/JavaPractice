/*   1:    */ package com.google.common.eventbus;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.MoreObjects;
/*   5:    */ import com.google.common.base.Objects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Throwables;
/*   8:    */ import com.google.common.cache.CacheBuilder;
/*   9:    */ import com.google.common.cache.CacheLoader;
/*  10:    */ import com.google.common.cache.LoadingCache;
/*  11:    */ import com.google.common.collect.HashMultimap;
/*  12:    */ import com.google.common.collect.ImmutableList;
/*  13:    */ import com.google.common.collect.ImmutableSet;
/*  14:    */ import com.google.common.collect.Iterators;
/*  15:    */ import com.google.common.collect.Lists;
/*  16:    */ import com.google.common.collect.Maps;
/*  17:    */ import com.google.common.collect.Multimap;
/*  18:    */ import com.google.common.reflect.TypeToken;
/*  19:    */ import com.google.common.reflect.TypeToken.TypeSet;
/*  20:    */ import com.google.common.util.concurrent.UncheckedExecutionException;
/*  21:    */ import com.google.j2objc.annotations.Weak;
/*  22:    */ import java.lang.reflect.Method;
/*  23:    */ import java.util.Arrays;
/*  24:    */ import java.util.Collection;
/*  25:    */ import java.util.Iterator;
/*  26:    */ import java.util.List;
/*  27:    */ import java.util.Map;
/*  28:    */ import java.util.Map.Entry;
/*  29:    */ import java.util.Set;
/*  30:    */ import java.util.concurrent.ConcurrentMap;
/*  31:    */ import java.util.concurrent.CopyOnWriteArraySet;
/*  32:    */ import javax.annotation.Nullable;
/*  33:    */ 
/*  34:    */ final class SubscriberRegistry
/*  35:    */ {
/*  36: 65 */   private final ConcurrentMap<Class<?>, CopyOnWriteArraySet<Subscriber>> subscribers = Maps.newConcurrentMap();
/*  37:    */   @Weak
/*  38:    */   private final EventBus bus;
/*  39:    */   
/*  40:    */   SubscriberRegistry(EventBus bus)
/*  41:    */   {
/*  42: 74 */     this.bus = ((EventBus)Preconditions.checkNotNull(bus));
/*  43:    */   }
/*  44:    */   
/*  45:    */   void register(Object listener)
/*  46:    */   {
/*  47: 81 */     Multimap<Class<?>, Subscriber> listenerMethods = findAllSubscribers(listener);
/*  48: 83 */     for (Map.Entry<Class<?>, Collection<Subscriber>> entry : listenerMethods.asMap().entrySet())
/*  49:    */     {
/*  50: 84 */       Class<?> eventType = (Class)entry.getKey();
/*  51: 85 */       Collection<Subscriber> eventMethodsInListener = (Collection)entry.getValue();
/*  52:    */       
/*  53: 87 */       CopyOnWriteArraySet<Subscriber> eventSubscribers = (CopyOnWriteArraySet)this.subscribers.get(eventType);
/*  54: 89 */       if (eventSubscribers == null)
/*  55:    */       {
/*  56: 90 */         CopyOnWriteArraySet<Subscriber> newSet = new CopyOnWriteArraySet();
/*  57: 91 */         eventSubscribers = (CopyOnWriteArraySet)MoreObjects.firstNonNull(this.subscribers.putIfAbsent(eventType, newSet), newSet);
/*  58:    */       }
/*  59: 95 */       eventSubscribers.addAll(eventMethodsInListener);
/*  60:    */     }
/*  61:    */   }
/*  62:    */   
/*  63:    */   void unregister(Object listener)
/*  64:    */   {
/*  65:103 */     Multimap<Class<?>, Subscriber> listenerMethods = findAllSubscribers(listener);
/*  66:105 */     for (Map.Entry<Class<?>, Collection<Subscriber>> entry : listenerMethods.asMap().entrySet())
/*  67:    */     {
/*  68:106 */       Class<?> eventType = (Class)entry.getKey();
/*  69:107 */       Collection<Subscriber> listenerMethodsForType = (Collection)entry.getValue();
/*  70:    */       
/*  71:109 */       CopyOnWriteArraySet<Subscriber> currentSubscribers = (CopyOnWriteArraySet)this.subscribers.get(eventType);
/*  72:110 */       if ((currentSubscribers == null) || (!currentSubscribers.removeAll(listenerMethodsForType))) {
/*  73:115 */         throw new IllegalArgumentException("missing event subscriber for an annotated method. Is " + listener + " registered?");
/*  74:    */       }
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   @VisibleForTesting
/*  79:    */   Set<Subscriber> getSubscribersForTesting(Class<?> eventType)
/*  80:    */   {
/*  81:126 */     return (Set)MoreObjects.firstNonNull(this.subscribers.get(eventType), ImmutableSet.of());
/*  82:    */   }
/*  83:    */   
/*  84:    */   Iterator<Subscriber> getSubscribers(Object event)
/*  85:    */   {
/*  86:134 */     ImmutableSet<Class<?>> eventTypes = flattenHierarchy(event.getClass());
/*  87:    */     
/*  88:136 */     List<Iterator<Subscriber>> subscriberIterators = Lists.newArrayListWithCapacity(eventTypes.size());
/*  89:139 */     for (Class<?> eventType : eventTypes)
/*  90:    */     {
/*  91:140 */       CopyOnWriteArraySet<Subscriber> eventSubscribers = (CopyOnWriteArraySet)this.subscribers.get(eventType);
/*  92:141 */       if (eventSubscribers != null) {
/*  93:143 */         subscriberIterators.add(eventSubscribers.iterator());
/*  94:    */       }
/*  95:    */     }
/*  96:147 */     return Iterators.concat(subscriberIterators.iterator());
/*  97:    */   }
/*  98:    */   
/*  99:156 */   private static final LoadingCache<Class<?>, ImmutableList<Method>> subscriberMethodsCache = CacheBuilder.newBuilder().weakKeys().build(new CacheLoader()
/* 100:    */   {
/* 101:    */     public ImmutableList<Method> load(Class<?> concreteClass)
/* 102:    */       throws Exception
/* 103:    */     {
/* 104:162 */       return SubscriberRegistry.getAnnotatedMethodsNotCached(concreteClass);
/* 105:    */     }
/* 106:156 */   });
/* 107:    */   
/* 108:    */   private Multimap<Class<?>, Subscriber> findAllSubscribers(Object listener)
/* 109:    */   {
/* 110:170 */     Multimap<Class<?>, Subscriber> methodsInListener = HashMultimap.create();
/* 111:171 */     Class<?> clazz = listener.getClass();
/* 112:172 */     for (Method method : getAnnotatedMethods(clazz))
/* 113:    */     {
/* 114:173 */       Class<?>[] parameterTypes = method.getParameterTypes();
/* 115:174 */       Class<?> eventType = parameterTypes[0];
/* 116:175 */       methodsInListener.put(eventType, Subscriber.create(this.bus, listener, method));
/* 117:    */     }
/* 118:177 */     return methodsInListener;
/* 119:    */   }
/* 120:    */   
/* 121:    */   private static ImmutableList<Method> getAnnotatedMethods(Class<?> clazz)
/* 122:    */   {
/* 123:181 */     return (ImmutableList)subscriberMethodsCache.getUnchecked(clazz);
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static ImmutableList<Method> getAnnotatedMethodsNotCached(Class<?> clazz)
/* 127:    */   {
/* 128:185 */     Set<? extends Class<?>> supertypes = TypeToken.of(clazz).getTypes().rawTypes();
/* 129:186 */     Map<MethodIdentifier, Method> identifiers = Maps.newHashMap();
/* 130:187 */     for (Class<?> supertype : supertypes) {
/* 131:188 */       for (Method method : supertype.getDeclaredMethods()) {
/* 132:189 */         if ((method.isAnnotationPresent(Subscribe.class)) && (!method.isSynthetic()))
/* 133:    */         {
/* 134:191 */           Class<?>[] parameterTypes = method.getParameterTypes();
/* 135:192 */           Preconditions.checkArgument(parameterTypes.length == 1, "Method %s has @Subscribe annotation but has %s parameters.Subscriber methods must have exactly 1 parameter.", new Object[] { method, Integer.valueOf(parameterTypes.length) });
/* 136:    */           
/* 137:    */ 
/* 138:    */ 
/* 139:    */ 
/* 140:197 */           MethodIdentifier ident = new MethodIdentifier(method);
/* 141:198 */           if (!identifiers.containsKey(ident)) {
/* 142:199 */             identifiers.put(ident, method);
/* 143:    */           }
/* 144:    */         }
/* 145:    */       }
/* 146:    */     }
/* 147:204 */     return ImmutableList.copyOf(identifiers.values());
/* 148:    */   }
/* 149:    */   
/* 150:210 */   private static final LoadingCache<Class<?>, ImmutableSet<Class<?>>> flattenHierarchyCache = CacheBuilder.newBuilder().weakKeys().build(new CacheLoader()
/* 151:    */   {
/* 152:    */     public ImmutableSet<Class<?>> load(Class<?> concreteClass)
/* 153:    */     {
/* 154:217 */       return ImmutableSet.copyOf(TypeToken.of(concreteClass).getTypes().rawTypes());
/* 155:    */     }
/* 156:210 */   });
/* 157:    */   
/* 158:    */   @VisibleForTesting
/* 159:    */   static ImmutableSet<Class<?>> flattenHierarchy(Class<?> concreteClass)
/* 160:    */   {
/* 161:    */     try
/* 162:    */     {
/* 163:229 */       return (ImmutableSet)flattenHierarchyCache.getUnchecked(concreteClass);
/* 164:    */     }
/* 165:    */     catch (UncheckedExecutionException e)
/* 166:    */     {
/* 167:231 */       throw Throwables.propagate(e.getCause());
/* 168:    */     }
/* 169:    */   }
/* 170:    */   
/* 171:    */   private static final class MethodIdentifier
/* 172:    */   {
/* 173:    */     private final String name;
/* 174:    */     private final List<Class<?>> parameterTypes;
/* 175:    */     
/* 176:    */     MethodIdentifier(Method method)
/* 177:    */     {
/* 178:241 */       this.name = method.getName();
/* 179:242 */       this.parameterTypes = Arrays.asList(method.getParameterTypes());
/* 180:    */     }
/* 181:    */     
/* 182:    */     public int hashCode()
/* 183:    */     {
/* 184:247 */       return Objects.hashCode(new Object[] { this.name, this.parameterTypes });
/* 185:    */     }
/* 186:    */     
/* 187:    */     public boolean equals(@Nullable Object o)
/* 188:    */     {
/* 189:252 */       if ((o instanceof MethodIdentifier))
/* 190:    */       {
/* 191:253 */         MethodIdentifier ident = (MethodIdentifier)o;
/* 192:254 */         return (this.name.equals(ident.name)) && (this.parameterTypes.equals(ident.parameterTypes));
/* 193:    */       }
/* 194:256 */       return false;
/* 195:    */     }
/* 196:    */   }
/* 197:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.eventbus.SubscriberRegistry
 * JD-Core Version:    0.7.0.1
 */