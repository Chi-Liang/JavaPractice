/*   1:    */ package com.google.common.eventbus;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.MoreObjects;
/*   5:    */ import com.google.common.base.MoreObjects.ToStringHelper;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.util.concurrent.MoreExecutors;
/*   8:    */ import java.lang.reflect.Method;
/*   9:    */ import java.util.Iterator;
/*  10:    */ import java.util.Locale;
/*  11:    */ import java.util.concurrent.Executor;
/*  12:    */ import java.util.logging.Level;
/*  13:    */ import java.util.logging.Logger;
/*  14:    */ 
/*  15:    */ @Beta
/*  16:    */ public class EventBus
/*  17:    */ {
/*  18:104 */   private static final Logger logger = Logger.getLogger(EventBus.class.getName());
/*  19:    */   private final String identifier;
/*  20:    */   private final Executor executor;
/*  21:    */   private final SubscriberExceptionHandler exceptionHandler;
/*  22:110 */   private final SubscriberRegistry subscribers = new SubscriberRegistry(this);
/*  23:    */   private final Dispatcher dispatcher;
/*  24:    */   
/*  25:    */   public EventBus()
/*  26:    */   {
/*  27:117 */     this("default");
/*  28:    */   }
/*  29:    */   
/*  30:    */   public EventBus(String identifier)
/*  31:    */   {
/*  32:127 */     this(identifier, MoreExecutors.directExecutor(), Dispatcher.perThreadDispatchQueue(), LoggingHandler.INSTANCE);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public EventBus(SubscriberExceptionHandler exceptionHandler)
/*  36:    */   {
/*  37:138 */     this("default", MoreExecutors.directExecutor(), Dispatcher.perThreadDispatchQueue(), exceptionHandler);
/*  38:    */   }
/*  39:    */   
/*  40:    */   EventBus(String identifier, Executor executor, Dispatcher dispatcher, SubscriberExceptionHandler exceptionHandler)
/*  41:    */   {
/*  42:144 */     this.identifier = ((String)Preconditions.checkNotNull(identifier));
/*  43:145 */     this.executor = ((Executor)Preconditions.checkNotNull(executor));
/*  44:146 */     this.dispatcher = ((Dispatcher)Preconditions.checkNotNull(dispatcher));
/*  45:147 */     this.exceptionHandler = ((SubscriberExceptionHandler)Preconditions.checkNotNull(exceptionHandler));
/*  46:    */   }
/*  47:    */   
/*  48:    */   public final String identifier()
/*  49:    */   {
/*  50:156 */     return this.identifier;
/*  51:    */   }
/*  52:    */   
/*  53:    */   final Executor executor()
/*  54:    */   {
/*  55:163 */     return this.executor;
/*  56:    */   }
/*  57:    */   
/*  58:    */   void handleSubscriberException(Throwable e, SubscriberExceptionContext context)
/*  59:    */   {
/*  60:170 */     Preconditions.checkNotNull(e);
/*  61:171 */     Preconditions.checkNotNull(context);
/*  62:    */     try
/*  63:    */     {
/*  64:173 */       this.exceptionHandler.handleException(e, context);
/*  65:    */     }
/*  66:    */     catch (Throwable e2)
/*  67:    */     {
/*  68:176 */       logger.log(Level.SEVERE, String.format(Locale.ROOT, "Exception %s thrown while handling exception: %s", new Object[] { e2, e }), e2);
/*  69:    */     }
/*  70:    */   }
/*  71:    */   
/*  72:    */   public void register(Object object)
/*  73:    */   {
/*  74:188 */     this.subscribers.register(object);
/*  75:    */   }
/*  76:    */   
/*  77:    */   public void unregister(Object object)
/*  78:    */   {
/*  79:198 */     this.subscribers.unregister(object);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public void post(Object event)
/*  83:    */   {
/*  84:213 */     Iterator<Subscriber> eventSubscribers = this.subscribers.getSubscribers(event);
/*  85:214 */     if (eventSubscribers.hasNext()) {
/*  86:215 */       this.dispatcher.dispatch(event, eventSubscribers);
/*  87:216 */     } else if (!(event instanceof DeadEvent)) {
/*  88:218 */       post(new DeadEvent(this, event));
/*  89:    */     }
/*  90:    */   }
/*  91:    */   
/*  92:    */   public String toString()
/*  93:    */   {
/*  94:224 */     return MoreObjects.toStringHelper(this).addValue(this.identifier).toString();
/*  95:    */   }
/*  96:    */   
/*  97:    */   static final class LoggingHandler
/*  98:    */     implements SubscriberExceptionHandler
/*  99:    */   {
/* 100:233 */     static final LoggingHandler INSTANCE = new LoggingHandler();
/* 101:    */     
/* 102:    */     public void handleException(Throwable exception, SubscriberExceptionContext context)
/* 103:    */     {
/* 104:237 */       Logger logger = logger(context);
/* 105:238 */       if (logger.isLoggable(Level.SEVERE)) {
/* 106:239 */         logger.log(Level.SEVERE, message(context), exception);
/* 107:    */       }
/* 108:    */     }
/* 109:    */     
/* 110:    */     private static Logger logger(SubscriberExceptionContext context)
/* 111:    */     {
/* 112:244 */       return Logger.getLogger(EventBus.class.getName() + "." + context.getEventBus().identifier());
/* 113:    */     }
/* 114:    */     
/* 115:    */     private static String message(SubscriberExceptionContext context)
/* 116:    */     {
/* 117:248 */       Method method = context.getSubscriberMethod();
/* 118:249 */       return "Exception thrown by subscriber method " + method.getName() + '(' + method.getParameterTypes()[0].getName() + ')' + " on subscriber " + context.getSubscriber() + " when dispatching event: " + context.getEvent();
/* 119:    */     }
/* 120:    */   }
/* 121:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.eventbus.EventBus
 * JD-Core Version:    0.7.0.1
 */