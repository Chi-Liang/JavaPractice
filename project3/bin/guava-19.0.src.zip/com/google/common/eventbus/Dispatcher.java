/*   1:    */ package com.google.common.eventbus;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.collect.Queues;
/*   5:    */ import java.util.Iterator;
/*   6:    */ import java.util.Queue;
/*   7:    */ import java.util.concurrent.ConcurrentLinkedQueue;
/*   8:    */ 
/*   9:    */ abstract class Dispatcher
/*  10:    */ {
/*  11:    */   static Dispatcher perThreadDispatchQueue()
/*  12:    */   {
/*  13: 50 */     return new PerThreadQueuedDispatcher(null);
/*  14:    */   }
/*  15:    */   
/*  16:    */   static Dispatcher legacyAsync()
/*  17:    */   {
/*  18: 60 */     return new LegacyAsyncDispatcher(null);
/*  19:    */   }
/*  20:    */   
/*  21:    */   static Dispatcher immediate()
/*  22:    */   {
/*  23: 69 */     return ImmediateDispatcher.INSTANCE;
/*  24:    */   }
/*  25:    */   
/*  26:    */   abstract void dispatch(Object paramObject, Iterator<Subscriber> paramIterator);
/*  27:    */   
/*  28:    */   private static final class PerThreadQueuedDispatcher
/*  29:    */     extends Dispatcher
/*  30:    */   {
/*  31:    */     private final ThreadLocal<Queue<Event>> queue;
/*  32:    */     private final ThreadLocal<Boolean> dispatching;
/*  33:    */     
/*  34:    */     private PerThreadQueuedDispatcher()
/*  35:    */     {
/*  36: 87 */       this.queue = new ThreadLocal()
/*  37:    */       {
/*  38:    */         protected Queue<Dispatcher.PerThreadQueuedDispatcher.Event> initialValue()
/*  39:    */         {
/*  40: 91 */           return Queues.newArrayDeque();
/*  41:    */         }
/*  42: 97 */       };
/*  43: 98 */       this.dispatching = new ThreadLocal()
/*  44:    */       {
/*  45:    */         protected Boolean initialValue()
/*  46:    */         {
/*  47:102 */           return Boolean.valueOf(false);
/*  48:    */         }
/*  49:    */       };
/*  50:    */     }
/*  51:    */     
/*  52:    */     void dispatch(Object event, Iterator<Subscriber> subscribers)
/*  53:    */     {
/*  54:108 */       Preconditions.checkNotNull(event);
/*  55:109 */       Preconditions.checkNotNull(subscribers);
/*  56:110 */       Queue<Event> queueForThread = (Queue)this.queue.get();
/*  57:111 */       queueForThread.offer(new Event(event, subscribers, null));
/*  58:113 */       if (!((Boolean)this.dispatching.get()).booleanValue())
/*  59:    */       {
/*  60:114 */         this.dispatching.set(Boolean.valueOf(true));
/*  61:    */         try
/*  62:    */         {
/*  63:    */           Event nextEvent;
/*  64:117 */           if ((nextEvent = (Event)queueForThread.poll()) != null) {
/*  65:118 */             while (nextEvent.subscribers.hasNext()) {
/*  66:119 */               ((Subscriber)nextEvent.subscribers.next()).dispatchEvent(nextEvent.event);
/*  67:    */             }
/*  68:    */           }
/*  69:    */         }
/*  70:    */         finally
/*  71:    */         {
/*  72:123 */           this.dispatching.remove();
/*  73:124 */           this.queue.remove();
/*  74:    */         }
/*  75:    */       }
/*  76:    */     }
/*  77:    */     
/*  78:    */     private static final class Event
/*  79:    */     {
/*  80:    */       private final Object event;
/*  81:    */       private final Iterator<Subscriber> subscribers;
/*  82:    */       
/*  83:    */       private Event(Object event, Iterator<Subscriber> subscribers)
/*  84:    */       {
/*  85:134 */         this.event = event;
/*  86:135 */         this.subscribers = subscribers;
/*  87:    */       }
/*  88:    */     }
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static final class LegacyAsyncDispatcher
/*  92:    */     extends Dispatcher
/*  93:    */   {
/*  94:    */     private final ConcurrentLinkedQueue<EventWithSubscriber> queue;
/*  95:    */     
/*  96:    */     private LegacyAsyncDispatcher()
/*  97:    */     {
/*  98:166 */       this.queue = Queues.newConcurrentLinkedQueue();
/*  99:    */     }
/* 100:    */     
/* 101:    */     void dispatch(Object event, Iterator<Subscriber> subscribers)
/* 102:    */     {
/* 103:171 */       Preconditions.checkNotNull(event);
/* 104:172 */       while (subscribers.hasNext()) {
/* 105:173 */         this.queue.add(new EventWithSubscriber(event, (Subscriber)subscribers.next(), null));
/* 106:    */       }
/* 107:    */       EventWithSubscriber e;
/* 108:177 */       while ((e = (EventWithSubscriber)this.queue.poll()) != null) {
/* 109:178 */         e.subscriber.dispatchEvent(e.event);
/* 110:    */       }
/* 111:    */     }
/* 112:    */     
/* 113:    */     private static final class EventWithSubscriber
/* 114:    */     {
/* 115:    */       private final Object event;
/* 116:    */       private final Subscriber subscriber;
/* 117:    */       
/* 118:    */       private EventWithSubscriber(Object event, Subscriber subscriber)
/* 119:    */       {
/* 120:187 */         this.event = event;
/* 121:188 */         this.subscriber = subscriber;
/* 122:    */       }
/* 123:    */     }
/* 124:    */   }
/* 125:    */   
/* 126:    */   private static final class ImmediateDispatcher
/* 127:    */     extends Dispatcher
/* 128:    */   {
/* 129:197 */     private static final ImmediateDispatcher INSTANCE = new ImmediateDispatcher();
/* 130:    */     
/* 131:    */     void dispatch(Object event, Iterator<Subscriber> subscribers)
/* 132:    */     {
/* 133:201 */       Preconditions.checkNotNull(event);
/* 134:202 */       while (subscribers.hasNext()) {
/* 135:203 */         ((Subscriber)subscribers.next()).dispatchEvent(event);
/* 136:    */       }
/* 137:    */     }
/* 138:    */   }
/* 139:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.eventbus.Dispatcher
 * JD-Core Version:    0.7.0.1
 */