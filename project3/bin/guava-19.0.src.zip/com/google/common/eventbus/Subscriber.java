/*   1:    */ package com.google.common.eventbus;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.j2objc.annotations.Weak;
/*   6:    */ import java.lang.reflect.InvocationTargetException;
/*   7:    */ import java.lang.reflect.Method;
/*   8:    */ import java.util.concurrent.Executor;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ class Subscriber
/*  12:    */ {
/*  13:    */   @Weak
/*  14:    */   private EventBus bus;
/*  15:    */   @VisibleForTesting
/*  16:    */   final Object target;
/*  17:    */   private final Method method;
/*  18:    */   private final Executor executor;
/*  19:    */   
/*  20:    */   static Subscriber create(EventBus bus, Object listener, Method method)
/*  21:    */   {
/*  22: 45 */     return isDeclaredThreadSafe(method) ? new Subscriber(bus, listener, method) : new SynchronizedSubscriber(bus, listener, method, null);
/*  23:    */   }
/*  24:    */   
/*  25:    */   private Subscriber(EventBus bus, Object target, Method method)
/*  26:    */   {
/*  27: 64 */     this.bus = bus;
/*  28: 65 */     this.target = Preconditions.checkNotNull(target);
/*  29: 66 */     this.method = method;
/*  30: 67 */     method.setAccessible(true);
/*  31:    */     
/*  32: 69 */     this.executor = bus.executor();
/*  33:    */   }
/*  34:    */   
/*  35:    */   final void dispatchEvent(final Object event)
/*  36:    */   {
/*  37: 76 */     this.executor.execute(new Runnable()
/*  38:    */     {
/*  39:    */       public void run()
/*  40:    */       {
/*  41:    */         try
/*  42:    */         {
/*  43: 80 */           Subscriber.this.invokeSubscriberMethod(event);
/*  44:    */         }
/*  45:    */         catch (InvocationTargetException e)
/*  46:    */         {
/*  47: 82 */           Subscriber.this.bus.handleSubscriberException(e.getCause(), Subscriber.this.context(event));
/*  48:    */         }
/*  49:    */       }
/*  50:    */     });
/*  51:    */   }
/*  52:    */   
/*  53:    */   @VisibleForTesting
/*  54:    */   void invokeSubscriberMethod(Object event)
/*  55:    */     throws InvocationTargetException
/*  56:    */   {
/*  57:    */     try
/*  58:    */     {
/*  59: 95 */       this.method.invoke(this.target, new Object[] { Preconditions.checkNotNull(event) });
/*  60:    */     }
/*  61:    */     catch (IllegalArgumentException e)
/*  62:    */     {
/*  63: 97 */       throw new Error("Method rejected target/argument: " + event, e);
/*  64:    */     }
/*  65:    */     catch (IllegalAccessException e)
/*  66:    */     {
/*  67: 99 */       throw new Error("Method became inaccessible: " + event, e);
/*  68:    */     }
/*  69:    */     catch (InvocationTargetException e)
/*  70:    */     {
/*  71:101 */       if ((e.getCause() instanceof Error)) {
/*  72:102 */         throw ((Error)e.getCause());
/*  73:    */       }
/*  74:104 */       throw e;
/*  75:    */     }
/*  76:    */   }
/*  77:    */   
/*  78:    */   private SubscriberExceptionContext context(Object event)
/*  79:    */   {
/*  80:112 */     return new SubscriberExceptionContext(this.bus, event, this.target, this.method);
/*  81:    */   }
/*  82:    */   
/*  83:    */   public final int hashCode()
/*  84:    */   {
/*  85:117 */     return (31 + this.method.hashCode()) * 31 + System.identityHashCode(this.target);
/*  86:    */   }
/*  87:    */   
/*  88:    */   public final boolean equals(@Nullable Object obj)
/*  89:    */   {
/*  90:122 */     if ((obj instanceof Subscriber))
/*  91:    */     {
/*  92:123 */       Subscriber that = (Subscriber)obj;
/*  93:    */       
/*  94:    */ 
/*  95:    */ 
/*  96:127 */       return (this.target == that.target) && (this.method.equals(that.method));
/*  97:    */     }
/*  98:129 */     return false;
/*  99:    */   }
/* 100:    */   
/* 101:    */   private static boolean isDeclaredThreadSafe(Method method)
/* 102:    */   {
/* 103:137 */     return method.getAnnotation(AllowConcurrentEvents.class) != null;
/* 104:    */   }
/* 105:    */   
/* 106:    */   @VisibleForTesting
/* 107:    */   static final class SynchronizedSubscriber
/* 108:    */     extends Subscriber
/* 109:    */   {
/* 110:    */     private SynchronizedSubscriber(EventBus bus, Object target, Method method)
/* 111:    */     {
/* 112:148 */       super(target, method, null);
/* 113:    */     }
/* 114:    */     
/* 115:    */     void invokeSubscriberMethod(Object event)
/* 116:    */       throws InvocationTargetException
/* 117:    */     {
/* 118:153 */       synchronized (this)
/* 119:    */       {
/* 120:154 */         super.invokeSubscriberMethod(event);
/* 121:    */       }
/* 122:    */     }
/* 123:    */   }
/* 124:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.eventbus.Subscriber
 * JD-Core Version:    0.7.0.1
 */