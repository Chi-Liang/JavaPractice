package com.google.common.eventbus;

public abstract interface SubscriberExceptionHandler
{
  public abstract void handleException(Throwable paramThrowable, SubscriberExceptionContext paramSubscriberExceptionContext);
}


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.eventbus.SubscriberExceptionHandler
 * JD-Core Version:    0.7.0.1
 */