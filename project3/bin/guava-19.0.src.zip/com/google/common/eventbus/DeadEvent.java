/*  1:   */ package com.google.common.eventbus;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.MoreObjects;
/*  5:   */ import com.google.common.base.MoreObjects.ToStringHelper;
/*  6:   */ import com.google.common.base.Preconditions;
/*  7:   */ 
/*  8:   */ @Beta
/*  9:   */ public class DeadEvent
/* 10:   */ {
/* 11:   */   private final Object source;
/* 12:   */   private final Object event;
/* 13:   */   
/* 14:   */   public DeadEvent(Object source, Object event)
/* 15:   */   {
/* 16:48 */     this.source = Preconditions.checkNotNull(source);
/* 17:49 */     this.event = Preconditions.checkNotNull(event);
/* 18:   */   }
/* 19:   */   
/* 20:   */   public Object getSource()
/* 21:   */   {
/* 22:59 */     return this.source;
/* 23:   */   }
/* 24:   */   
/* 25:   */   public Object getEvent()
/* 26:   */   {
/* 27:69 */     return this.event;
/* 28:   */   }
/* 29:   */   
/* 30:   */   public String toString()
/* 31:   */   {
/* 32:74 */     return MoreObjects.toStringHelper(this).add("source", this.source).add("event", this.event).toString();
/* 33:   */   }
/* 34:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.eventbus.DeadEvent
 * JD-Core Version:    0.7.0.1
 */