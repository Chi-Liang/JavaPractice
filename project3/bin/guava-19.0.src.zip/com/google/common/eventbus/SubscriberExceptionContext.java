/*  1:   */ package com.google.common.eventbus;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import java.lang.reflect.Method;
/*  5:   */ 
/*  6:   */ public class SubscriberExceptionContext
/*  7:   */ {
/*  8:   */   private final EventBus eventBus;
/*  9:   */   private final Object event;
/* 10:   */   private final Object subscriber;
/* 11:   */   private final Method subscriberMethod;
/* 12:   */   
/* 13:   */   SubscriberExceptionContext(EventBus eventBus, Object event, Object subscriber, Method subscriberMethod)
/* 14:   */   {
/* 15:42 */     this.eventBus = ((EventBus)Preconditions.checkNotNull(eventBus));
/* 16:43 */     this.event = Preconditions.checkNotNull(event);
/* 17:44 */     this.subscriber = Preconditions.checkNotNull(subscriber);
/* 18:45 */     this.subscriberMethod = ((Method)Preconditions.checkNotNull(subscriberMethod));
/* 19:   */   }
/* 20:   */   
/* 21:   */   public EventBus getEventBus()
/* 22:   */   {
/* 23:53 */     return this.eventBus;
/* 24:   */   }
/* 25:   */   
/* 26:   */   public Object getEvent()
/* 27:   */   {
/* 28:60 */     return this.event;
/* 29:   */   }
/* 30:   */   
/* 31:   */   public Object getSubscriber()
/* 32:   */   {
/* 33:67 */     return this.subscriber;
/* 34:   */   }
/* 35:   */   
/* 36:   */   public Method getSubscriberMethod()
/* 37:   */   {
/* 38:74 */     return this.subscriberMethod;
/* 39:   */   }
/* 40:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.eventbus.SubscriberExceptionContext
 * JD-Core Version:    0.7.0.1
 */