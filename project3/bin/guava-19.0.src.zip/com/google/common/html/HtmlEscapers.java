/*  1:   */ package com.google.common.html;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ import com.google.common.escape.Escaper;
/*  6:   */ import com.google.common.escape.Escapers;
/*  7:   */ import com.google.common.escape.Escapers.Builder;
/*  8:   */ 
/*  9:   */ @Beta
/* 10:   */ @GwtCompatible
/* 11:   */ public final class HtmlEscapers
/* 12:   */ {
/* 13:   */   public static Escaper htmlEscaper()
/* 14:   */   {
/* 15:62 */     return HTML_ESCAPER;
/* 16:   */   }
/* 17:   */   
/* 18:68 */   private static final Escaper HTML_ESCAPER = Escapers.builder().addEscape('"', "&quot;").addEscape('\'', "&#39;").addEscape('&', "&amp;").addEscape('<', "&lt;").addEscape('>', "&gt;").build();
/* 19:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.html.HtmlEscapers
 * JD-Core Version:    0.7.0.1
 */