/*    1:     */ package com.google.common.util.concurrent;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.VisibleForTesting;
/*    5:     */ import com.google.common.base.MoreObjects;
/*    6:     */ import com.google.common.base.Preconditions;
/*    7:     */ import com.google.common.collect.ImmutableSet;
/*    8:     */ import com.google.common.collect.Lists;
/*    9:     */ import com.google.common.collect.MapMaker;
/*   10:     */ import com.google.common.collect.Maps;
/*   11:     */ import com.google.common.collect.Sets;
/*   12:     */ import com.google.j2objc.annotations.Weak;
/*   13:     */ import java.util.ArrayList;
/*   14:     */ import java.util.Arrays;
/*   15:     */ import java.util.Collections;
/*   16:     */ import java.util.EnumMap;
/*   17:     */ import java.util.List;
/*   18:     */ import java.util.Map;
/*   19:     */ import java.util.Map.Entry;
/*   20:     */ import java.util.Set;
/*   21:     */ import java.util.concurrent.ConcurrentMap;
/*   22:     */ import java.util.concurrent.TimeUnit;
/*   23:     */ import java.util.concurrent.locks.ReentrantLock;
/*   24:     */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*   25:     */ import java.util.concurrent.locks.ReentrantReadWriteLock.ReadLock;
/*   26:     */ import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;
/*   27:     */ import java.util.logging.Level;
/*   28:     */ import java.util.logging.Logger;
/*   29:     */ import javax.annotation.Nullable;
/*   30:     */ import javax.annotation.concurrent.ThreadSafe;
/*   31:     */ 
/*   32:     */ @Beta
/*   33:     */ @ThreadSafe
/*   34:     */ public class CycleDetectingLockFactory
/*   35:     */ {
/*   36:     */   @Beta
/*   37:     */   @ThreadSafe
/*   38:     */   public static abstract interface Policy
/*   39:     */   {
/*   40:     */     public abstract void handlePotentialDeadlock(CycleDetectingLockFactory.PotentialDeadlockException paramPotentialDeadlockException);
/*   41:     */   }
/*   42:     */   
/*   43:     */   @Beta
/*   44:     */   public static abstract enum Policies
/*   45:     */     implements CycleDetectingLockFactory.Policy
/*   46:     */   {
/*   47: 206 */     THROW,  WARN,  DISABLED;
/*   48:     */     
/*   49:     */     private Policies() {}
/*   50:     */   }
/*   51:     */   
/*   52:     */   public static CycleDetectingLockFactory newInstance(Policy policy)
/*   53:     */   {
/*   54: 247 */     return new CycleDetectingLockFactory(policy);
/*   55:     */   }
/*   56:     */   
/*   57:     */   public ReentrantLock newReentrantLock(String lockName)
/*   58:     */   {
/*   59: 254 */     return newReentrantLock(lockName, false);
/*   60:     */   }
/*   61:     */   
/*   62:     */   public ReentrantLock newReentrantLock(String lockName, boolean fair)
/*   63:     */   {
/*   64: 263 */     return this.policy == Policies.DISABLED ? new ReentrantLock(fair) : new CycleDetectingReentrantLock(new LockGraphNode(lockName), fair, null);
/*   65:     */   }
/*   66:     */   
/*   67:     */   public ReentrantReadWriteLock newReentrantReadWriteLock(String lockName)
/*   68:     */   {
/*   69: 272 */     return newReentrantReadWriteLock(lockName, false);
/*   70:     */   }
/*   71:     */   
/*   72:     */   public ReentrantReadWriteLock newReentrantReadWriteLock(String lockName, boolean fair)
/*   73:     */   {
/*   74: 282 */     return this.policy == Policies.DISABLED ? new ReentrantReadWriteLock(fair) : new CycleDetectingReentrantReadWriteLock(new LockGraphNode(lockName), fair, null);
/*   75:     */   }
/*   76:     */   
/*   77: 289 */   private static final ConcurrentMap<Class<? extends Enum>, Map<? extends Enum, LockGraphNode>> lockGraphNodesPerType = new MapMaker().weakKeys().makeMap();
/*   78:     */   
/*   79:     */   public static <E extends Enum<E>> WithExplicitOrdering<E> newInstanceWithExplicitOrdering(Class<E> enumClass, Policy policy)
/*   80:     */   {
/*   81: 299 */     Preconditions.checkNotNull(enumClass);
/*   82: 300 */     Preconditions.checkNotNull(policy);
/*   83:     */     
/*   84: 302 */     Map<E, LockGraphNode> lockGraphNodes = getOrCreateNodes(enumClass);
/*   85:     */     
/*   86: 304 */     return new WithExplicitOrdering(policy, lockGraphNodes);
/*   87:     */   }
/*   88:     */   
/*   89:     */   private static Map<? extends Enum, LockGraphNode> getOrCreateNodes(Class<? extends Enum> clazz)
/*   90:     */   {
/*   91: 309 */     Map<? extends Enum, LockGraphNode> existing = (Map)lockGraphNodesPerType.get(clazz);
/*   92: 311 */     if (existing != null) {
/*   93: 312 */       return existing;
/*   94:     */     }
/*   95: 314 */     Map<? extends Enum, LockGraphNode> created = createNodes(clazz);
/*   96: 315 */     existing = (Map)lockGraphNodesPerType.putIfAbsent(clazz, created);
/*   97: 316 */     return (Map)MoreObjects.firstNonNull(existing, created);
/*   98:     */   }
/*   99:     */   
/*  100:     */   @VisibleForTesting
/*  101:     */   static <E extends Enum<E>> Map<E, LockGraphNode> createNodes(Class<E> clazz)
/*  102:     */   {
/*  103: 327 */     EnumMap<E, LockGraphNode> map = Maps.newEnumMap(clazz);
/*  104: 328 */     E[] keys = (Enum[])clazz.getEnumConstants();
/*  105: 329 */     int numKeys = keys.length;
/*  106: 330 */     ArrayList<LockGraphNode> nodes = Lists.newArrayListWithCapacity(numKeys);
/*  107: 333 */     for (E key : keys)
/*  108:     */     {
/*  109: 334 */       LockGraphNode node = new LockGraphNode(getLockName(key));
/*  110: 335 */       nodes.add(node);
/*  111: 336 */       map.put(key, node);
/*  112:     */     }
/*  113: 339 */     for (int i = 1; i < numKeys; i++) {
/*  114: 340 */       ((LockGraphNode)nodes.get(i)).checkAcquiredLocks(Policies.THROW, nodes.subList(0, i));
/*  115:     */     }
/*  116: 343 */     for (int i = 0; i < numKeys - 1; i++) {
/*  117: 344 */       ((LockGraphNode)nodes.get(i)).checkAcquiredLocks(Policies.DISABLED, nodes.subList(i + 1, numKeys));
/*  118:     */     }
/*  119: 347 */     return Collections.unmodifiableMap(map);
/*  120:     */   }
/*  121:     */   
/*  122:     */   private static String getLockName(Enum<?> rank)
/*  123:     */   {
/*  124: 356 */     return rank.getDeclaringClass().getSimpleName() + "." + rank.name();
/*  125:     */   }
/*  126:     */   
/*  127:     */   @Beta
/*  128:     */   public static final class WithExplicitOrdering<E extends Enum<E>>
/*  129:     */     extends CycleDetectingLockFactory
/*  130:     */   {
/*  131:     */     private final Map<E, CycleDetectingLockFactory.LockGraphNode> lockGraphNodes;
/*  132:     */     
/*  133:     */     @VisibleForTesting
/*  134:     */     WithExplicitOrdering(CycleDetectingLockFactory.Policy policy, Map<E, CycleDetectingLockFactory.LockGraphNode> lockGraphNodes)
/*  135:     */     {
/*  136: 429 */       super(null);
/*  137: 430 */       this.lockGraphNodes = lockGraphNodes;
/*  138:     */     }
/*  139:     */     
/*  140:     */     public ReentrantLock newReentrantLock(E rank)
/*  141:     */     {
/*  142: 437 */       return newReentrantLock(rank, false);
/*  143:     */     }
/*  144:     */     
/*  145:     */     public ReentrantLock newReentrantLock(E rank, boolean fair)
/*  146:     */     {
/*  147: 450 */       return this.policy == CycleDetectingLockFactory.Policies.DISABLED ? new ReentrantLock(fair) : new CycleDetectingLockFactory.CycleDetectingReentrantLock(this, (CycleDetectingLockFactory.LockGraphNode)this.lockGraphNodes.get(rank), fair, null);
/*  148:     */     }
/*  149:     */     
/*  150:     */     public ReentrantReadWriteLock newReentrantReadWriteLock(E rank)
/*  151:     */     {
/*  152: 458 */       return newReentrantReadWriteLock(rank, false);
/*  153:     */     }
/*  154:     */     
/*  155:     */     public ReentrantReadWriteLock newReentrantReadWriteLock(E rank, boolean fair)
/*  156:     */     {
/*  157: 472 */       return this.policy == CycleDetectingLockFactory.Policies.DISABLED ? new ReentrantReadWriteLock(fair) : new CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock(this, (CycleDetectingLockFactory.LockGraphNode)this.lockGraphNodes.get(rank), fair, null);
/*  158:     */     }
/*  159:     */   }
/*  160:     */   
/*  161: 480 */   private static final Logger logger = Logger.getLogger(CycleDetectingLockFactory.class.getName());
/*  162:     */   final Policy policy;
/*  163:     */   
/*  164:     */   private CycleDetectingLockFactory(Policy policy)
/*  165:     */   {
/*  166: 486 */     this.policy = ((Policy)Preconditions.checkNotNull(policy));
/*  167:     */   }
/*  168:     */   
/*  169: 497 */   private static final ThreadLocal<ArrayList<LockGraphNode>> acquiredLocks = new ThreadLocal()
/*  170:     */   {
/*  171:     */     protected ArrayList<CycleDetectingLockFactory.LockGraphNode> initialValue()
/*  172:     */     {
/*  173: 500 */       return Lists.newArrayListWithCapacity(3);
/*  174:     */     }
/*  175:     */   };
/*  176:     */   
/*  177:     */   private static class ExampleStackTrace
/*  178:     */     extends IllegalStateException
/*  179:     */   {
/*  180: 520 */     static final StackTraceElement[] EMPTY_STACK_TRACE = new StackTraceElement[0];
/*  181: 523 */     static final Set<String> EXCLUDED_CLASS_NAMES = ImmutableSet.of(CycleDetectingLockFactory.class.getName(), ExampleStackTrace.class.getName(), CycleDetectingLockFactory.LockGraphNode.class.getName());
/*  182:     */     
/*  183:     */     ExampleStackTrace(CycleDetectingLockFactory.LockGraphNode node1, CycleDetectingLockFactory.LockGraphNode node2)
/*  184:     */     {
/*  185: 529 */       super();
/*  186: 530 */       StackTraceElement[] origStackTrace = getStackTrace();
/*  187: 531 */       int i = 0;
/*  188: 531 */       for (int n = origStackTrace.length; i < n; i++)
/*  189:     */       {
/*  190: 532 */         if (CycleDetectingLockFactory.WithExplicitOrdering.class.getName().equals(origStackTrace[i].getClassName()))
/*  191:     */         {
/*  192: 535 */           setStackTrace(EMPTY_STACK_TRACE);
/*  193: 536 */           break;
/*  194:     */         }
/*  195: 538 */         if (!EXCLUDED_CLASS_NAMES.contains(origStackTrace[i].getClassName()))
/*  196:     */         {
/*  197: 539 */           setStackTrace((StackTraceElement[])Arrays.copyOfRange(origStackTrace, i, n));
/*  198: 540 */           break;
/*  199:     */         }
/*  200:     */       }
/*  201:     */     }
/*  202:     */   }
/*  203:     */   
/*  204:     */   @Beta
/*  205:     */   public static final class PotentialDeadlockException
/*  206:     */     extends CycleDetectingLockFactory.ExampleStackTrace
/*  207:     */   {
/*  208:     */     private final CycleDetectingLockFactory.ExampleStackTrace conflictingStackTrace;
/*  209:     */     
/*  210:     */     private PotentialDeadlockException(CycleDetectingLockFactory.LockGraphNode node1, CycleDetectingLockFactory.LockGraphNode node2, CycleDetectingLockFactory.ExampleStackTrace conflictingStackTrace)
/*  211:     */     {
/*  212: 578 */       super(node2);
/*  213: 579 */       this.conflictingStackTrace = conflictingStackTrace;
/*  214: 580 */       initCause(conflictingStackTrace);
/*  215:     */     }
/*  216:     */     
/*  217:     */     public CycleDetectingLockFactory.ExampleStackTrace getConflictingStackTrace()
/*  218:     */     {
/*  219: 584 */       return this.conflictingStackTrace;
/*  220:     */     }
/*  221:     */     
/*  222:     */     public String getMessage()
/*  223:     */     {
/*  224: 593 */       StringBuilder message = new StringBuilder(super.getMessage());
/*  225: 594 */       for (Throwable t = this.conflictingStackTrace; t != null; t = t.getCause()) {
/*  226: 595 */         message.append(", ").append(t.getMessage());
/*  227:     */       }
/*  228: 597 */       return message.toString();
/*  229:     */     }
/*  230:     */   }
/*  231:     */   
/*  232:     */   private static abstract interface CycleDetectingLock
/*  233:     */   {
/*  234:     */     public abstract CycleDetectingLockFactory.LockGraphNode getLockGraphNode();
/*  235:     */     
/*  236:     */     public abstract boolean isAcquiredByCurrentThread();
/*  237:     */   }
/*  238:     */   
/*  239:     */   private static class LockGraphNode
/*  240:     */   {
/*  241: 626 */     final Map<LockGraphNode, CycleDetectingLockFactory.ExampleStackTrace> allowedPriorLocks = new MapMaker().weakKeys().makeMap();
/*  242: 633 */     final Map<LockGraphNode, CycleDetectingLockFactory.PotentialDeadlockException> disallowedPriorLocks = new MapMaker().weakKeys().makeMap();
/*  243:     */     final String lockName;
/*  244:     */     
/*  245:     */     LockGraphNode(String lockName)
/*  246:     */     {
/*  247: 639 */       this.lockName = ((String)Preconditions.checkNotNull(lockName));
/*  248:     */     }
/*  249:     */     
/*  250:     */     String getLockName()
/*  251:     */     {
/*  252: 643 */       return this.lockName;
/*  253:     */     }
/*  254:     */     
/*  255:     */     void checkAcquiredLocks(CycleDetectingLockFactory.Policy policy, List<LockGraphNode> acquiredLocks)
/*  256:     */     {
/*  257: 648 */       int i = 0;
/*  258: 648 */       for (int size = acquiredLocks.size(); i < size; i++) {
/*  259: 649 */         checkAcquiredLock(policy, (LockGraphNode)acquiredLocks.get(i));
/*  260:     */       }
/*  261:     */     }
/*  262:     */     
/*  263:     */     void checkAcquiredLock(CycleDetectingLockFactory.Policy policy, LockGraphNode acquiredLock)
/*  264:     */     {
/*  265: 669 */       Preconditions.checkState(this != acquiredLock, "Attempted to acquire multiple locks with the same rank %s", new Object[] { acquiredLock.getLockName() });
/*  266: 672 */       if (this.allowedPriorLocks.containsKey(acquiredLock)) {
/*  267: 676 */         return;
/*  268:     */       }
/*  269: 678 */       CycleDetectingLockFactory.PotentialDeadlockException previousDeadlockException = (CycleDetectingLockFactory.PotentialDeadlockException)this.disallowedPriorLocks.get(acquiredLock);
/*  270: 680 */       if (previousDeadlockException != null)
/*  271:     */       {
/*  272: 684 */         CycleDetectingLockFactory.PotentialDeadlockException exception = new CycleDetectingLockFactory.PotentialDeadlockException(acquiredLock, this, previousDeadlockException.getConflictingStackTrace(), null);
/*  273:     */         
/*  274:     */ 
/*  275: 687 */         policy.handlePotentialDeadlock(exception);
/*  276: 688 */         return;
/*  277:     */       }
/*  278: 692 */       Set<LockGraphNode> seen = Sets.newIdentityHashSet();
/*  279: 693 */       CycleDetectingLockFactory.ExampleStackTrace path = acquiredLock.findPathTo(this, seen);
/*  280: 695 */       if (path == null)
/*  281:     */       {
/*  282: 704 */         this.allowedPriorLocks.put(acquiredLock, new CycleDetectingLockFactory.ExampleStackTrace(acquiredLock, this));
/*  283:     */       }
/*  284:     */       else
/*  285:     */       {
/*  286: 709 */         CycleDetectingLockFactory.PotentialDeadlockException exception = new CycleDetectingLockFactory.PotentialDeadlockException(acquiredLock, this, path, null);
/*  287:     */         
/*  288: 711 */         this.disallowedPriorLocks.put(acquiredLock, exception);
/*  289: 712 */         policy.handlePotentialDeadlock(exception);
/*  290:     */       }
/*  291:     */     }
/*  292:     */     
/*  293:     */     @Nullable
/*  294:     */     private CycleDetectingLockFactory.ExampleStackTrace findPathTo(LockGraphNode node, Set<LockGraphNode> seen)
/*  295:     */     {
/*  296: 728 */       if (!seen.add(this)) {
/*  297: 729 */         return null;
/*  298:     */       }
/*  299: 731 */       CycleDetectingLockFactory.ExampleStackTrace found = (CycleDetectingLockFactory.ExampleStackTrace)this.allowedPriorLocks.get(node);
/*  300: 732 */       if (found != null) {
/*  301: 733 */         return found;
/*  302:     */       }
/*  303: 737 */       for (Map.Entry<LockGraphNode, CycleDetectingLockFactory.ExampleStackTrace> entry : this.allowedPriorLocks.entrySet())
/*  304:     */       {
/*  305: 738 */         LockGraphNode preAcquiredLock = (LockGraphNode)entry.getKey();
/*  306: 739 */         found = preAcquiredLock.findPathTo(node, seen);
/*  307: 740 */         if (found != null)
/*  308:     */         {
/*  309: 744 */           CycleDetectingLockFactory.ExampleStackTrace path = new CycleDetectingLockFactory.ExampleStackTrace(preAcquiredLock, this);
/*  310:     */           
/*  311: 746 */           path.setStackTrace(((CycleDetectingLockFactory.ExampleStackTrace)entry.getValue()).getStackTrace());
/*  312: 747 */           path.initCause(found);
/*  313: 748 */           return path;
/*  314:     */         }
/*  315:     */       }
/*  316: 751 */       return null;
/*  317:     */     }
/*  318:     */   }
/*  319:     */   
/*  320:     */   private void aboutToAcquire(CycleDetectingLock lock)
/*  321:     */   {
/*  322: 760 */     if (!lock.isAcquiredByCurrentThread())
/*  323:     */     {
/*  324: 761 */       ArrayList<LockGraphNode> acquiredLockList = (ArrayList)acquiredLocks.get();
/*  325: 762 */       LockGraphNode node = lock.getLockGraphNode();
/*  326: 763 */       node.checkAcquiredLocks(this.policy, acquiredLockList);
/*  327: 764 */       acquiredLockList.add(node);
/*  328:     */     }
/*  329:     */   }
/*  330:     */   
/*  331:     */   private void lockStateChanged(CycleDetectingLock lock)
/*  332:     */   {
/*  333: 775 */     if (!lock.isAcquiredByCurrentThread())
/*  334:     */     {
/*  335: 776 */       ArrayList<LockGraphNode> acquiredLockList = (ArrayList)acquiredLocks.get();
/*  336: 777 */       LockGraphNode node = lock.getLockGraphNode();
/*  337: 780 */       for (int i = acquiredLockList.size() - 1; i >= 0; i--) {
/*  338: 781 */         if (acquiredLockList.get(i) == node)
/*  339:     */         {
/*  340: 782 */           acquiredLockList.remove(i);
/*  341: 783 */           break;
/*  342:     */         }
/*  343:     */       }
/*  344:     */     }
/*  345:     */   }
/*  346:     */   
/*  347:     */   final class CycleDetectingReentrantLock
/*  348:     */     extends ReentrantLock
/*  349:     */     implements CycleDetectingLockFactory.CycleDetectingLock
/*  350:     */   {
/*  351:     */     private final CycleDetectingLockFactory.LockGraphNode lockGraphNode;
/*  352:     */     
/*  353:     */     private CycleDetectingReentrantLock(CycleDetectingLockFactory.LockGraphNode lockGraphNode, boolean fair)
/*  354:     */     {
/*  355: 796 */       super();
/*  356: 797 */       this.lockGraphNode = ((CycleDetectingLockFactory.LockGraphNode)Preconditions.checkNotNull(lockGraphNode));
/*  357:     */     }
/*  358:     */     
/*  359:     */     public CycleDetectingLockFactory.LockGraphNode getLockGraphNode()
/*  360:     */     {
/*  361: 804 */       return this.lockGraphNode;
/*  362:     */     }
/*  363:     */     
/*  364:     */     public boolean isAcquiredByCurrentThread()
/*  365:     */     {
/*  366: 809 */       return isHeldByCurrentThread();
/*  367:     */     }
/*  368:     */     
/*  369:     */     public void lock()
/*  370:     */     {
/*  371: 816 */       CycleDetectingLockFactory.this.aboutToAcquire(this);
/*  372:     */       try
/*  373:     */       {
/*  374: 818 */         super.lock();
/*  375:     */       }
/*  376:     */       finally
/*  377:     */       {
/*  378: 820 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  379:     */       }
/*  380:     */     }
/*  381:     */     
/*  382:     */     public void lockInterruptibly()
/*  383:     */       throws InterruptedException
/*  384:     */     {
/*  385: 826 */       CycleDetectingLockFactory.this.aboutToAcquire(this);
/*  386:     */       try
/*  387:     */       {
/*  388: 828 */         super.lockInterruptibly();
/*  389:     */       }
/*  390:     */       finally
/*  391:     */       {
/*  392: 830 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  393:     */       }
/*  394:     */     }
/*  395:     */     
/*  396:     */     public boolean tryLock()
/*  397:     */     {
/*  398: 836 */       CycleDetectingLockFactory.this.aboutToAcquire(this);
/*  399:     */       try
/*  400:     */       {
/*  401: 838 */         return super.tryLock();
/*  402:     */       }
/*  403:     */       finally
/*  404:     */       {
/*  405: 840 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  406:     */       }
/*  407:     */     }
/*  408:     */     
/*  409:     */     public boolean tryLock(long timeout, TimeUnit unit)
/*  410:     */       throws InterruptedException
/*  411:     */     {
/*  412: 847 */       CycleDetectingLockFactory.this.aboutToAcquire(this);
/*  413:     */       try
/*  414:     */       {
/*  415: 849 */         return super.tryLock(timeout, unit);
/*  416:     */       }
/*  417:     */       finally
/*  418:     */       {
/*  419: 851 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  420:     */       }
/*  421:     */     }
/*  422:     */     
/*  423:     */     public void unlock()
/*  424:     */     {
/*  425:     */       try
/*  426:     */       {
/*  427: 858 */         super.unlock();
/*  428:     */       }
/*  429:     */       finally
/*  430:     */       {
/*  431: 860 */         CycleDetectingLockFactory.this.lockStateChanged(this);
/*  432:     */       }
/*  433:     */     }
/*  434:     */   }
/*  435:     */   
/*  436:     */   final class CycleDetectingReentrantReadWriteLock
/*  437:     */     extends ReentrantReadWriteLock
/*  438:     */     implements CycleDetectingLockFactory.CycleDetectingLock
/*  439:     */   {
/*  440:     */     private final CycleDetectingLockFactory.CycleDetectingReentrantReadLock readLock;
/*  441:     */     private final CycleDetectingLockFactory.CycleDetectingReentrantWriteLock writeLock;
/*  442:     */     private final CycleDetectingLockFactory.LockGraphNode lockGraphNode;
/*  443:     */     
/*  444:     */     private CycleDetectingReentrantReadWriteLock(CycleDetectingLockFactory.LockGraphNode lockGraphNode, boolean fair)
/*  445:     */     {
/*  446: 879 */       super();
/*  447: 880 */       this.readLock = new CycleDetectingLockFactory.CycleDetectingReentrantReadLock(CycleDetectingLockFactory.this, this);
/*  448: 881 */       this.writeLock = new CycleDetectingLockFactory.CycleDetectingReentrantWriteLock(CycleDetectingLockFactory.this, this);
/*  449: 882 */       this.lockGraphNode = ((CycleDetectingLockFactory.LockGraphNode)Preconditions.checkNotNull(lockGraphNode));
/*  450:     */     }
/*  451:     */     
/*  452:     */     public ReentrantReadWriteLock.ReadLock readLock()
/*  453:     */     {
/*  454: 889 */       return this.readLock;
/*  455:     */     }
/*  456:     */     
/*  457:     */     public ReentrantReadWriteLock.WriteLock writeLock()
/*  458:     */     {
/*  459: 894 */       return this.writeLock;
/*  460:     */     }
/*  461:     */     
/*  462:     */     public CycleDetectingLockFactory.LockGraphNode getLockGraphNode()
/*  463:     */     {
/*  464: 901 */       return this.lockGraphNode;
/*  465:     */     }
/*  466:     */     
/*  467:     */     public boolean isAcquiredByCurrentThread()
/*  468:     */     {
/*  469: 906 */       return (isWriteLockedByCurrentThread()) || (getReadHoldCount() > 0);
/*  470:     */     }
/*  471:     */   }
/*  472:     */   
/*  473:     */   private class CycleDetectingReentrantReadLock
/*  474:     */     extends ReentrantReadWriteLock.ReadLock
/*  475:     */   {
/*  476:     */     @Weak
/*  477:     */     final CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock readWriteLock;
/*  478:     */     
/*  479:     */     CycleDetectingReentrantReadLock(CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock readWriteLock)
/*  480:     */     {
/*  481: 917 */       super();
/*  482: 918 */       this.readWriteLock = readWriteLock;
/*  483:     */     }
/*  484:     */     
/*  485:     */     public void lock()
/*  486:     */     {
/*  487: 923 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  488:     */       try
/*  489:     */       {
/*  490: 925 */         super.lock();
/*  491:     */       }
/*  492:     */       finally
/*  493:     */       {
/*  494: 927 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  495:     */       }
/*  496:     */     }
/*  497:     */     
/*  498:     */     public void lockInterruptibly()
/*  499:     */       throws InterruptedException
/*  500:     */     {
/*  501: 933 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  502:     */       try
/*  503:     */       {
/*  504: 935 */         super.lockInterruptibly();
/*  505:     */       }
/*  506:     */       finally
/*  507:     */       {
/*  508: 937 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  509:     */       }
/*  510:     */     }
/*  511:     */     
/*  512:     */     public boolean tryLock()
/*  513:     */     {
/*  514: 943 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  515:     */       try
/*  516:     */       {
/*  517: 945 */         return super.tryLock();
/*  518:     */       }
/*  519:     */       finally
/*  520:     */       {
/*  521: 947 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  522:     */       }
/*  523:     */     }
/*  524:     */     
/*  525:     */     public boolean tryLock(long timeout, TimeUnit unit)
/*  526:     */       throws InterruptedException
/*  527:     */     {
/*  528: 954 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  529:     */       try
/*  530:     */       {
/*  531: 956 */         return super.tryLock(timeout, unit);
/*  532:     */       }
/*  533:     */       finally
/*  534:     */       {
/*  535: 958 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  536:     */       }
/*  537:     */     }
/*  538:     */     
/*  539:     */     public void unlock()
/*  540:     */     {
/*  541:     */       try
/*  542:     */       {
/*  543: 965 */         super.unlock();
/*  544:     */       }
/*  545:     */       finally
/*  546:     */       {
/*  547: 967 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  548:     */       }
/*  549:     */     }
/*  550:     */   }
/*  551:     */   
/*  552:     */   private class CycleDetectingReentrantWriteLock
/*  553:     */     extends ReentrantReadWriteLock.WriteLock
/*  554:     */   {
/*  555:     */     @Weak
/*  556:     */     final CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock readWriteLock;
/*  557:     */     
/*  558:     */     CycleDetectingReentrantWriteLock(CycleDetectingLockFactory.CycleDetectingReentrantReadWriteLock readWriteLock)
/*  559:     */     {
/*  560: 979 */       super();
/*  561: 980 */       this.readWriteLock = readWriteLock;
/*  562:     */     }
/*  563:     */     
/*  564:     */     public void lock()
/*  565:     */     {
/*  566: 985 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  567:     */       try
/*  568:     */       {
/*  569: 987 */         super.lock();
/*  570:     */       }
/*  571:     */       finally
/*  572:     */       {
/*  573: 989 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  574:     */       }
/*  575:     */     }
/*  576:     */     
/*  577:     */     public void lockInterruptibly()
/*  578:     */       throws InterruptedException
/*  579:     */     {
/*  580: 995 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  581:     */       try
/*  582:     */       {
/*  583: 997 */         super.lockInterruptibly();
/*  584:     */       }
/*  585:     */       finally
/*  586:     */       {
/*  587: 999 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  588:     */       }
/*  589:     */     }
/*  590:     */     
/*  591:     */     public boolean tryLock()
/*  592:     */     {
/*  593:1005 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  594:     */       try
/*  595:     */       {
/*  596:1007 */         return super.tryLock();
/*  597:     */       }
/*  598:     */       finally
/*  599:     */       {
/*  600:1009 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  601:     */       }
/*  602:     */     }
/*  603:     */     
/*  604:     */     public boolean tryLock(long timeout, TimeUnit unit)
/*  605:     */       throws InterruptedException
/*  606:     */     {
/*  607:1016 */       CycleDetectingLockFactory.this.aboutToAcquire(this.readWriteLock);
/*  608:     */       try
/*  609:     */       {
/*  610:1018 */         return super.tryLock(timeout, unit);
/*  611:     */       }
/*  612:     */       finally
/*  613:     */       {
/*  614:1020 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  615:     */       }
/*  616:     */     }
/*  617:     */     
/*  618:     */     public void unlock()
/*  619:     */     {
/*  620:     */       try
/*  621:     */       {
/*  622:1027 */         super.unlock();
/*  623:     */       }
/*  624:     */       finally
/*  625:     */       {
/*  626:1029 */         CycleDetectingLockFactory.this.lockStateChanged(this.readWriteLock);
/*  627:     */       }
/*  628:     */     }
/*  629:     */   }
/*  630:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.CycleDetectingLockFactory
 * JD-Core Version:    0.7.0.1
 */