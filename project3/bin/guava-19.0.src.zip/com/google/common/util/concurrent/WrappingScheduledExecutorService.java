/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import java.util.concurrent.Callable;
/*  4:   */ import java.util.concurrent.ScheduledExecutorService;
/*  5:   */ import java.util.concurrent.ScheduledFuture;
/*  6:   */ import java.util.concurrent.TimeUnit;
/*  7:   */ 
/*  8:   */ abstract class WrappingScheduledExecutorService
/*  9:   */   extends WrappingExecutorService
/* 10:   */   implements ScheduledExecutorService
/* 11:   */ {
/* 12:   */   final ScheduledExecutorService delegate;
/* 13:   */   
/* 14:   */   protected WrappingScheduledExecutorService(ScheduledExecutorService delegate)
/* 15:   */   {
/* 16:36 */     super(delegate);
/* 17:37 */     this.delegate = delegate;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public final ScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit)
/* 21:   */   {
/* 22:42 */     return this.delegate.schedule(wrapTask(command), delay, unit);
/* 23:   */   }
/* 24:   */   
/* 25:   */   public final <V> ScheduledFuture<V> schedule(Callable<V> task, long delay, TimeUnit unit)
/* 26:   */   {
/* 27:47 */     return this.delegate.schedule(wrapTask(task), delay, unit);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public final ScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit)
/* 31:   */   {
/* 32:53 */     return this.delegate.scheduleAtFixedRate(wrapTask(command), initialDelay, period, unit);
/* 33:   */   }
/* 34:   */   
/* 35:   */   public final ScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit)
/* 36:   */   {
/* 37:59 */     return this.delegate.scheduleWithFixedDelay(wrapTask(command), initialDelay, delay, unit);
/* 38:   */   }
/* 39:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.WrappingScheduledExecutorService
 * JD-Core Version:    0.7.0.1
 */