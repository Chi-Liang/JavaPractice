/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import java.util.concurrent.AbstractExecutorService;
/*  5:   */ import java.util.concurrent.Callable;
/*  6:   */ import java.util.concurrent.RunnableFuture;
/*  7:   */ import javax.annotation.Nullable;
/*  8:   */ 
/*  9:   */ @Beta
/* 10:   */ public abstract class AbstractListeningExecutorService
/* 11:   */   extends AbstractExecutorService
/* 12:   */   implements ListeningExecutorService
/* 13:   */ {
/* 14:   */   protected final <T> RunnableFuture<T> newTaskFor(Runnable runnable, T value)
/* 15:   */   {
/* 16:44 */     return TrustedListenableFutureTask.create(runnable, value);
/* 17:   */   }
/* 18:   */   
/* 19:   */   protected final <T> RunnableFuture<T> newTaskFor(Callable<T> callable)
/* 20:   */   {
/* 21:49 */     return TrustedListenableFutureTask.create(callable);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public ListenableFuture<?> submit(Runnable task)
/* 25:   */   {
/* 26:53 */     return (ListenableFuture)super.submit(task);
/* 27:   */   }
/* 28:   */   
/* 29:   */   public <T> ListenableFuture<T> submit(Runnable task, @Nullable T result)
/* 30:   */   {
/* 31:57 */     return (ListenableFuture)super.submit(task, result);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public <T> ListenableFuture<T> submit(Callable<T> task)
/* 35:   */   {
/* 36:61 */     return (ListenableFuture)super.submit(task);
/* 37:   */   }
/* 38:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractListeningExecutorService
 * JD-Core Version:    0.7.0.1
 */