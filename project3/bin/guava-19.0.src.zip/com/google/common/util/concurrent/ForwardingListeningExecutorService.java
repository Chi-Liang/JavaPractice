/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import java.util.concurrent.Callable;
/*  4:   */ 
/*  5:   */ public abstract class ForwardingListeningExecutorService
/*  6:   */   extends ForwardingExecutorService
/*  7:   */   implements ListeningExecutorService
/*  8:   */ {
/*  9:   */   protected abstract ListeningExecutorService delegate();
/* 10:   */   
/* 11:   */   public <T> ListenableFuture<T> submit(Callable<T> task)
/* 12:   */   {
/* 13:40 */     return delegate().submit(task);
/* 14:   */   }
/* 15:   */   
/* 16:   */   public ListenableFuture<?> submit(Runnable task)
/* 17:   */   {
/* 18:45 */     return delegate().submit(task);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public <T> ListenableFuture<T> submit(Runnable task, T result)
/* 22:   */   {
/* 23:50 */     return delegate().submit(task, result);
/* 24:   */   }
/* 25:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ForwardingListeningExecutorService
 * JD-Core Version:    0.7.0.1
 */