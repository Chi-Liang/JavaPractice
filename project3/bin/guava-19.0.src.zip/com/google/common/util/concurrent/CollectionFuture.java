/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.base.Optional;
/*  5:   */ import com.google.common.base.Preconditions;
/*  6:   */ import com.google.common.collect.ImmutableCollection;
/*  7:   */ import com.google.common.collect.ImmutableList;
/*  8:   */ import com.google.common.collect.Lists;
/*  9:   */ import java.util.List;
/* 10:   */ import javax.annotation.Nullable;
/* 11:   */ 
/* 12:   */ @GwtCompatible
/* 13:   */ abstract class CollectionFuture<V, C>
/* 14:   */   extends AggregateFuture<V, C>
/* 15:   */ {
/* 16:   */   abstract class CollectionFutureRunningState
/* 17:   */     extends AggregateFuture<V, C>.RunningState
/* 18:   */   {
/* 19:   */     private List<Optional<V>> values;
/* 20:   */     
/* 21:   */     CollectionFutureRunningState(boolean futures)
/* 22:   */     {
/* 23:45 */       super(futures, allMustSucceed, true);
/* 24:   */       
/* 25:47 */       this.values = ((List)(futures.isEmpty() ? ImmutableList.of() : Lists.newArrayListWithCapacity(futures.size())));
/* 26:51 */       for (int i = 0; i < futures.size(); i++) {
/* 27:52 */         this.values.add(null);
/* 28:   */       }
/* 29:   */     }
/* 30:   */     
/* 31:   */     final void collectOneValue(boolean allMustSucceed, int index, @Nullable V returnValue)
/* 32:   */     {
/* 33:58 */       List<Optional<V>> localValues = this.values;
/* 34:60 */       if (localValues != null) {
/* 35:61 */         localValues.set(index, Optional.fromNullable(returnValue));
/* 36:   */       } else {
/* 37:67 */         Preconditions.checkState((allMustSucceed) || (CollectionFuture.this.isCancelled()), "Future was done before all dependencies completed");
/* 38:   */       }
/* 39:   */     }
/* 40:   */     
/* 41:   */     final void handleAllCompleted()
/* 42:   */     {
/* 43:74 */       List<Optional<V>> localValues = this.values;
/* 44:75 */       if (localValues != null) {
/* 45:76 */         CollectionFuture.this.set(combine(localValues));
/* 46:   */       } else {
/* 47:78 */         Preconditions.checkState(CollectionFuture.this.isDone());
/* 48:   */       }
/* 49:   */     }
/* 50:   */     
/* 51:   */     void releaseResourcesAfterFailure()
/* 52:   */     {
/* 53:84 */       super.releaseResourcesAfterFailure();
/* 54:85 */       this.values = null;
/* 55:   */     }
/* 56:   */     
/* 57:   */     abstract C combine(List<Optional<V>> paramList);
/* 58:   */   }
/* 59:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.CollectionFuture
 * JD-Core Version:    0.7.0.1
 */