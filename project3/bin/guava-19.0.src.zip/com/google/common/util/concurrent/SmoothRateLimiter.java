/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.math.LongMath;
/*   4:    */ import java.util.concurrent.TimeUnit;
/*   5:    */ 
/*   6:    */ abstract class SmoothRateLimiter
/*   7:    */   extends RateLimiter
/*   8:    */ {
/*   9:    */   double storedPermits;
/*  10:    */   double maxPermits;
/*  11:    */   double stableIntervalMicros;
/*  12:    */   
/*  13:    */   static final class SmoothWarmingUp
/*  14:    */     extends SmoothRateLimiter
/*  15:    */   {
/*  16:    */     private final long warmupPeriodMicros;
/*  17:    */     private double slope;
/*  18:    */     private double thresholdPermits;
/*  19:    */     private double coldFactor;
/*  20:    */     
/*  21:    */     SmoothWarmingUp(RateLimiter.SleepingStopwatch stopwatch, long warmupPeriod, TimeUnit timeUnit, double coldFactor)
/*  22:    */     {
/*  23:214 */       super(null);
/*  24:215 */       this.warmupPeriodMicros = timeUnit.toMicros(warmupPeriod);
/*  25:216 */       this.coldFactor = coldFactor;
/*  26:    */     }
/*  27:    */     
/*  28:    */     void doSetRate(double permitsPerSecond, double stableIntervalMicros)
/*  29:    */     {
/*  30:221 */       double oldMaxPermits = this.maxPermits;
/*  31:222 */       double coldIntervalMicros = stableIntervalMicros * this.coldFactor;
/*  32:223 */       this.thresholdPermits = (0.5D * this.warmupPeriodMicros / stableIntervalMicros);
/*  33:224 */       this.maxPermits = (this.thresholdPermits + 2.0D * this.warmupPeriodMicros / (stableIntervalMicros + coldIntervalMicros));
/*  34:    */       
/*  35:226 */       this.slope = ((coldIntervalMicros - stableIntervalMicros) / (this.maxPermits - this.thresholdPermits));
/*  36:227 */       if (oldMaxPermits == (1.0D / 0.0D)) {
/*  37:229 */         this.storedPermits = 0.0D;
/*  38:    */       } else {
/*  39:231 */         this.storedPermits = (oldMaxPermits == 0.0D ? this.maxPermits : this.storedPermits * this.maxPermits / oldMaxPermits);
/*  40:    */       }
/*  41:    */     }
/*  42:    */     
/*  43:    */     long storedPermitsToWaitTime(double storedPermits, double permitsToTake)
/*  44:    */     {
/*  45:239 */       double availablePermitsAboveThreshold = storedPermits - this.thresholdPermits;
/*  46:240 */       long micros = 0L;
/*  47:242 */       if (availablePermitsAboveThreshold > 0.0D)
/*  48:    */       {
/*  49:243 */         double permitsAboveThresholdToTake = Math.min(availablePermitsAboveThreshold, permitsToTake);
/*  50:244 */         micros = (permitsAboveThresholdToTake * (permitsToTime(availablePermitsAboveThreshold) + permitsToTime(availablePermitsAboveThreshold - permitsAboveThresholdToTake)) / 2.0D);
/*  51:    */         
/*  52:    */ 
/*  53:247 */         permitsToTake -= permitsAboveThresholdToTake;
/*  54:    */       }
/*  55:250 */       micros = (micros + this.stableIntervalMicros * permitsToTake);
/*  56:251 */       return micros;
/*  57:    */     }
/*  58:    */     
/*  59:    */     private double permitsToTime(double permits)
/*  60:    */     {
/*  61:255 */       return this.stableIntervalMicros + permits * this.slope;
/*  62:    */     }
/*  63:    */     
/*  64:    */     double coolDownIntervalMicros()
/*  65:    */     {
/*  66:260 */       return this.warmupPeriodMicros / this.maxPermits;
/*  67:    */     }
/*  68:    */   }
/*  69:    */   
/*  70:    */   static final class SmoothBursty
/*  71:    */     extends SmoothRateLimiter
/*  72:    */   {
/*  73:    */     final double maxBurstSeconds;
/*  74:    */     
/*  75:    */     SmoothBursty(RateLimiter.SleepingStopwatch stopwatch, double maxBurstSeconds)
/*  76:    */     {
/*  77:275 */       super(null);
/*  78:276 */       this.maxBurstSeconds = maxBurstSeconds;
/*  79:    */     }
/*  80:    */     
/*  81:    */     void doSetRate(double permitsPerSecond, double stableIntervalMicros)
/*  82:    */     {
/*  83:281 */       double oldMaxPermits = this.maxPermits;
/*  84:282 */       this.maxPermits = (this.maxBurstSeconds * permitsPerSecond);
/*  85:283 */       if (oldMaxPermits == (1.0D / 0.0D)) {
/*  86:285 */         this.storedPermits = this.maxPermits;
/*  87:    */       } else {
/*  88:287 */         this.storedPermits = (oldMaxPermits == 0.0D ? 0.0D : this.storedPermits * this.maxPermits / oldMaxPermits);
/*  89:    */       }
/*  90:    */     }
/*  91:    */     
/*  92:    */     long storedPermitsToWaitTime(double storedPermits, double permitsToTake)
/*  93:    */     {
/*  94:295 */       return 0L;
/*  95:    */     }
/*  96:    */     
/*  97:    */     double coolDownIntervalMicros()
/*  98:    */     {
/*  99:300 */       return this.stableIntervalMicros;
/* 100:    */     }
/* 101:    */   }
/* 102:    */   
/* 103:325 */   private long nextFreeTicketMicros = 0L;
/* 104:    */   
/* 105:    */   private SmoothRateLimiter(RateLimiter.SleepingStopwatch stopwatch)
/* 106:    */   {
/* 107:328 */     super(stopwatch);
/* 108:    */   }
/* 109:    */   
/* 110:    */   final void doSetRate(double permitsPerSecond, long nowMicros)
/* 111:    */   {
/* 112:333 */     resync(nowMicros);
/* 113:334 */     double stableIntervalMicros = TimeUnit.SECONDS.toMicros(1L) / permitsPerSecond;
/* 114:335 */     this.stableIntervalMicros = stableIntervalMicros;
/* 115:336 */     doSetRate(permitsPerSecond, stableIntervalMicros);
/* 116:    */   }
/* 117:    */   
/* 118:    */   abstract void doSetRate(double paramDouble1, double paramDouble2);
/* 119:    */   
/* 120:    */   final double doGetRate()
/* 121:    */   {
/* 122:343 */     return TimeUnit.SECONDS.toMicros(1L) / this.stableIntervalMicros;
/* 123:    */   }
/* 124:    */   
/* 125:    */   final long queryEarliestAvailable(long nowMicros)
/* 126:    */   {
/* 127:348 */     return this.nextFreeTicketMicros;
/* 128:    */   }
/* 129:    */   
/* 130:    */   final long reserveEarliestAvailable(int requiredPermits, long nowMicros)
/* 131:    */   {
/* 132:353 */     resync(nowMicros);
/* 133:354 */     long returnValue = this.nextFreeTicketMicros;
/* 134:355 */     double storedPermitsToSpend = Math.min(requiredPermits, this.storedPermits);
/* 135:356 */     double freshPermits = requiredPermits - storedPermitsToSpend;
/* 136:357 */     long waitMicros = storedPermitsToWaitTime(this.storedPermits, storedPermitsToSpend) + (freshPermits * this.stableIntervalMicros);
/* 137:    */     try
/* 138:    */     {
/* 139:361 */       this.nextFreeTicketMicros = LongMath.checkedAdd(this.nextFreeTicketMicros, waitMicros);
/* 140:    */     }
/* 141:    */     catch (ArithmeticException e)
/* 142:    */     {
/* 143:363 */       this.nextFreeTicketMicros = 9223372036854775807L;
/* 144:    */     }
/* 145:365 */     this.storedPermits -= storedPermitsToSpend;
/* 146:366 */     return returnValue;
/* 147:    */   }
/* 148:    */   
/* 149:    */   abstract long storedPermitsToWaitTime(double paramDouble1, double paramDouble2);
/* 150:    */   
/* 151:    */   abstract double coolDownIntervalMicros();
/* 152:    */   
/* 153:    */   void resync(long nowMicros)
/* 154:    */   {
/* 155:389 */     if (nowMicros > this.nextFreeTicketMicros)
/* 156:    */     {
/* 157:390 */       this.storedPermits = Math.min(this.maxPermits, this.storedPermits + (nowMicros - this.nextFreeTicketMicros) / coolDownIntervalMicros());
/* 158:    */       
/* 159:    */ 
/* 160:393 */       this.nextFreeTicketMicros = nowMicros;
/* 161:    */     }
/* 162:    */   }
/* 163:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.SmoothRateLimiter
 * JD-Core Version:    0.7.0.1
 */