/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.VisibleForTesting;
/*  4:   */ import java.io.PrintStream;
/*  5:   */ import java.util.Locale;
/*  6:   */ import java.util.logging.Level;
/*  7:   */ import java.util.logging.Logger;
/*  8:   */ 
/*  9:   */ public final class UncaughtExceptionHandlers
/* 10:   */ {
/* 11:   */   public static Thread.UncaughtExceptionHandler systemExit()
/* 12:   */   {
/* 13:51 */     return new Exiter(Runtime.getRuntime());
/* 14:   */   }
/* 15:   */   
/* 16:   */   @VisibleForTesting
/* 17:   */   static final class Exiter
/* 18:   */     implements Thread.UncaughtExceptionHandler
/* 19:   */   {
/* 20:55 */     private static final Logger logger = Logger.getLogger(Exiter.class.getName());
/* 21:   */     private final Runtime runtime;
/* 22:   */     
/* 23:   */     Exiter(Runtime runtime)
/* 24:   */     {
/* 25:60 */       this.runtime = runtime;
/* 26:   */     }
/* 27:   */     
/* 28:   */     public void uncaughtException(Thread t, Throwable e)
/* 29:   */     {
/* 30:   */       try
/* 31:   */       {
/* 32:66 */         logger.log(Level.SEVERE, String.format(Locale.ROOT, "Caught an exception in %s.  Shutting down.", new Object[] { t }), e);
/* 33:   */       }
/* 34:   */       catch (Throwable errorInLogging)
/* 35:   */       {
/* 36:71 */         System.err.println(e.getMessage());
/* 37:72 */         System.err.println(errorInLogging.getMessage());
/* 38:   */       }
/* 39:   */       finally
/* 40:   */       {
/* 41:74 */         this.runtime.exit(1);
/* 42:   */       }
/* 43:   */     }
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.UncaughtExceptionHandlers
 * JD-Core Version:    0.7.0.1
 */