/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.MoreObjects;
/*   6:    */ import com.google.common.base.Preconditions;
/*   7:    */ import com.google.common.base.Supplier;
/*   8:    */ import com.google.common.collect.ImmutableList;
/*   9:    */ import com.google.common.collect.Iterables;
/*  10:    */ import com.google.common.collect.MapMaker;
/*  11:    */ import com.google.common.math.IntMath;
/*  12:    */ import java.lang.ref.Reference;
/*  13:    */ import java.lang.ref.ReferenceQueue;
/*  14:    */ import java.lang.ref.WeakReference;
/*  15:    */ import java.math.RoundingMode;
/*  16:    */ import java.util.Arrays;
/*  17:    */ import java.util.Collections;
/*  18:    */ import java.util.List;
/*  19:    */ import java.util.concurrent.ConcurrentMap;
/*  20:    */ import java.util.concurrent.Semaphore;
/*  21:    */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*  22:    */ import java.util.concurrent.locks.Lock;
/*  23:    */ import java.util.concurrent.locks.ReadWriteLock;
/*  24:    */ import java.util.concurrent.locks.ReentrantLock;
/*  25:    */ import java.util.concurrent.locks.ReentrantReadWriteLock;
/*  26:    */ 
/*  27:    */ @Beta
/*  28:    */ public abstract class Striped<L>
/*  29:    */ {
/*  30:    */   private static final int LARGE_LAZY_CUTOFF = 1024;
/*  31:    */   
/*  32:    */   public abstract L get(Object paramObject);
/*  33:    */   
/*  34:    */   public abstract L getAt(int paramInt);
/*  35:    */   
/*  36:    */   abstract int indexFor(Object paramObject);
/*  37:    */   
/*  38:    */   public abstract int size();
/*  39:    */   
/*  40:    */   public Iterable<L> bulkGet(Iterable<?> keys)
/*  41:    */   {
/*  42:146 */     Object[] array = Iterables.toArray(keys, Object.class);
/*  43:147 */     if (array.length == 0) {
/*  44:148 */       return ImmutableList.of();
/*  45:    */     }
/*  46:150 */     int[] stripes = new int[array.length];
/*  47:151 */     for (int i = 0; i < array.length; i++) {
/*  48:152 */       stripes[i] = indexFor(array[i]);
/*  49:    */     }
/*  50:154 */     Arrays.sort(stripes);
/*  51:    */     
/*  52:156 */     int previousStripe = stripes[0];
/*  53:157 */     array[0] = getAt(previousStripe);
/*  54:158 */     for (int i = 1; i < array.length; i++)
/*  55:    */     {
/*  56:159 */       int currentStripe = stripes[i];
/*  57:160 */       if (currentStripe == previousStripe)
/*  58:    */       {
/*  59:161 */         array[i] = array[(i - 1)];
/*  60:    */       }
/*  61:    */       else
/*  62:    */       {
/*  63:163 */         array[i] = getAt(currentStripe);
/*  64:164 */         previousStripe = currentStripe;
/*  65:    */       }
/*  66:    */     }
/*  67:185 */     List<L> asList = Arrays.asList(array);
/*  68:186 */     return Collections.unmodifiableList(asList);
/*  69:    */   }
/*  70:    */   
/*  71:    */   public static Striped<Lock> lock(int stripes)
/*  72:    */   {
/*  73:199 */     new CompactStriped(stripes, new Supplier()
/*  74:    */     {
/*  75:    */       public Lock get()
/*  76:    */       {
/*  77:201 */         return new Striped.PaddedLock();
/*  78:    */       }
/*  79:201 */     }, null);
/*  80:    */   }
/*  81:    */   
/*  82:    */   public static Striped<Lock> lazyWeakLock(int stripes)
/*  83:    */   {
/*  84:214 */     lazy(stripes, new Supplier()
/*  85:    */     {
/*  86:    */       public Lock get()
/*  87:    */       {
/*  88:216 */         return new ReentrantLock(false);
/*  89:    */       }
/*  90:    */     });
/*  91:    */   }
/*  92:    */   
/*  93:    */   private static <L> Striped<L> lazy(int stripes, Supplier<L> supplier)
/*  94:    */   {
/*  95:222 */     return stripes < 1024 ? new SmallLazyStriped(stripes, supplier) : new LargeLazyStriped(stripes, supplier);
/*  96:    */   }
/*  97:    */   
/*  98:    */   public static Striped<Semaphore> semaphore(int stripes, int permits)
/*  99:    */   {
/* 100:236 */     new CompactStriped(stripes, new Supplier()
/* 101:    */     {
/* 102:    */       public Semaphore get()
/* 103:    */       {
/* 104:238 */         return new Striped.PaddedSemaphore(this.val$permits);
/* 105:    */       }
/* 106:238 */     }, null);
/* 107:    */   }
/* 108:    */   
/* 109:    */   public static Striped<Semaphore> lazyWeakSemaphore(int stripes, int permits)
/* 110:    */   {
/* 111:252 */     lazy(stripes, new Supplier()
/* 112:    */     {
/* 113:    */       public Semaphore get()
/* 114:    */       {
/* 115:254 */         return new Semaphore(this.val$permits, false);
/* 116:    */       }
/* 117:    */     });
/* 118:    */   }
/* 119:    */   
/* 120:    */   public static Striped<ReadWriteLock> readWriteLock(int stripes)
/* 121:    */   {
/* 122:267 */     return new CompactStriped(stripes, READ_WRITE_LOCK_SUPPLIER, null);
/* 123:    */   }
/* 124:    */   
/* 125:    */   public static Striped<ReadWriteLock> lazyWeakReadWriteLock(int stripes)
/* 126:    */   {
/* 127:278 */     return lazy(stripes, READ_WRITE_LOCK_SUPPLIER);
/* 128:    */   }
/* 129:    */   
/* 130:282 */   private static final Supplier<ReadWriteLock> READ_WRITE_LOCK_SUPPLIER = new Supplier()
/* 131:    */   {
/* 132:    */     public ReadWriteLock get()
/* 133:    */     {
/* 134:285 */       return new ReentrantReadWriteLock();
/* 135:    */     }
/* 136:    */   };
/* 137:    */   private static final int ALL_SET = -1;
/* 138:    */   
/* 139:    */   private static abstract class PowerOfTwoStriped<L>
/* 140:    */     extends Striped<L>
/* 141:    */   {
/* 142:    */     final int mask;
/* 143:    */     
/* 144:    */     PowerOfTwoStriped(int stripes)
/* 145:    */     {
/* 146:293 */       super();
/* 147:294 */       Preconditions.checkArgument(stripes > 0, "Stripes must be positive");
/* 148:295 */       this.mask = (stripes > 1073741824 ? -1 : Striped.ceilToPowerOfTwo(stripes) - 1);
/* 149:    */     }
/* 150:    */     
/* 151:    */     final int indexFor(Object key)
/* 152:    */     {
/* 153:299 */       int hash = Striped.smear(key.hashCode());
/* 154:300 */       return hash & this.mask;
/* 155:    */     }
/* 156:    */     
/* 157:    */     public final L get(Object key)
/* 158:    */     {
/* 159:304 */       return getAt(indexFor(key));
/* 160:    */     }
/* 161:    */   }
/* 162:    */   
/* 163:    */   private static class CompactStriped<L>
/* 164:    */     extends Striped.PowerOfTwoStriped<L>
/* 165:    */   {
/* 166:    */     private final Object[] array;
/* 167:    */     
/* 168:    */     private CompactStriped(int stripes, Supplier<L> supplier)
/* 169:    */     {
/* 170:317 */       super();
/* 171:318 */       Preconditions.checkArgument(stripes <= 1073741824, "Stripes must be <= 2^30)");
/* 172:    */       
/* 173:320 */       this.array = new Object[this.mask + 1];
/* 174:321 */       for (int i = 0; i < this.array.length; i++) {
/* 175:322 */         this.array[i] = supplier.get();
/* 176:    */       }
/* 177:    */     }
/* 178:    */     
/* 179:    */     public L getAt(int index)
/* 180:    */     {
/* 181:328 */       return this.array[index];
/* 182:    */     }
/* 183:    */     
/* 184:    */     public int size()
/* 185:    */     {
/* 186:332 */       return this.array.length;
/* 187:    */     }
/* 188:    */   }
/* 189:    */   
/* 190:    */   @VisibleForTesting
/* 191:    */   static class SmallLazyStriped<L>
/* 192:    */     extends Striped.PowerOfTwoStriped<L>
/* 193:    */   {
/* 194:    */     final AtomicReferenceArray<ArrayReference<? extends L>> locks;
/* 195:    */     final Supplier<L> supplier;
/* 196:    */     final int size;
/* 197:345 */     final ReferenceQueue<L> queue = new ReferenceQueue();
/* 198:    */     
/* 199:    */     SmallLazyStriped(int stripes, Supplier<L> supplier)
/* 200:    */     {
/* 201:348 */       super();
/* 202:349 */       this.size = (this.mask == -1 ? 2147483647 : this.mask + 1);
/* 203:350 */       this.locks = new AtomicReferenceArray(this.size);
/* 204:351 */       this.supplier = supplier;
/* 205:    */     }
/* 206:    */     
/* 207:    */     public L getAt(int index)
/* 208:    */     {
/* 209:355 */       if (this.size != 2147483647) {
/* 210:356 */         Preconditions.checkElementIndex(index, size());
/* 211:    */       }
/* 212:358 */       ArrayReference<? extends L> existingRef = (ArrayReference)this.locks.get(index);
/* 213:359 */       L existing = existingRef == null ? null : existingRef.get();
/* 214:360 */       if (existing != null) {
/* 215:361 */         return existing;
/* 216:    */       }
/* 217:363 */       L created = this.supplier.get();
/* 218:364 */       ArrayReference<L> newRef = new ArrayReference(created, index, this.queue);
/* 219:365 */       while (!this.locks.compareAndSet(index, existingRef, newRef))
/* 220:    */       {
/* 221:367 */         existingRef = (ArrayReference)this.locks.get(index);
/* 222:368 */         existing = existingRef == null ? null : existingRef.get();
/* 223:369 */         if (existing != null) {
/* 224:370 */           return existing;
/* 225:    */         }
/* 226:    */       }
/* 227:373 */       drainQueue();
/* 228:374 */       return created;
/* 229:    */     }
/* 230:    */     
/* 231:    */     private void drainQueue()
/* 232:    */     {
/* 233:    */       Reference<? extends L> ref;
/* 234:382 */       while ((ref = this.queue.poll()) != null)
/* 235:    */       {
/* 236:384 */         ArrayReference<? extends L> arrayRef = (ArrayReference)ref;
/* 237:    */         
/* 238:    */ 
/* 239:387 */         this.locks.compareAndSet(arrayRef.index, arrayRef, null);
/* 240:    */       }
/* 241:    */     }
/* 242:    */     
/* 243:    */     public int size()
/* 244:    */     {
/* 245:392 */       return this.size;
/* 246:    */     }
/* 247:    */     
/* 248:    */     private static final class ArrayReference<L>
/* 249:    */       extends WeakReference<L>
/* 250:    */     {
/* 251:    */       final int index;
/* 252:    */       
/* 253:    */       ArrayReference(L referent, int index, ReferenceQueue<L> queue)
/* 254:    */       {
/* 255:399 */         super(queue);
/* 256:400 */         this.index = index;
/* 257:    */       }
/* 258:    */     }
/* 259:    */   }
/* 260:    */   
/* 261:    */   @VisibleForTesting
/* 262:    */   static class LargeLazyStriped<L>
/* 263:    */     extends Striped.PowerOfTwoStriped<L>
/* 264:    */   {
/* 265:    */     final ConcurrentMap<Integer, L> locks;
/* 266:    */     final Supplier<L> supplier;
/* 267:    */     final int size;
/* 268:    */     
/* 269:    */     LargeLazyStriped(int stripes, Supplier<L> supplier)
/* 270:    */     {
/* 271:416 */       super();
/* 272:417 */       this.size = (this.mask == -1 ? 2147483647 : this.mask + 1);
/* 273:418 */       this.supplier = supplier;
/* 274:419 */       this.locks = new MapMaker().weakValues().makeMap();
/* 275:    */     }
/* 276:    */     
/* 277:    */     public L getAt(int index)
/* 278:    */     {
/* 279:423 */       if (this.size != 2147483647) {
/* 280:424 */         Preconditions.checkElementIndex(index, size());
/* 281:    */       }
/* 282:426 */       L existing = this.locks.get(Integer.valueOf(index));
/* 283:427 */       if (existing != null) {
/* 284:428 */         return existing;
/* 285:    */       }
/* 286:430 */       L created = this.supplier.get();
/* 287:431 */       existing = this.locks.putIfAbsent(Integer.valueOf(index), created);
/* 288:432 */       return MoreObjects.firstNonNull(existing, created);
/* 289:    */     }
/* 290:    */     
/* 291:    */     public int size()
/* 292:    */     {
/* 293:436 */       return this.size;
/* 294:    */     }
/* 295:    */   }
/* 296:    */   
/* 297:    */   private static int ceilToPowerOfTwo(int x)
/* 298:    */   {
/* 299:446 */     return 1 << IntMath.log2(x, RoundingMode.CEILING);
/* 300:    */   }
/* 301:    */   
/* 302:    */   private static int smear(int hashCode)
/* 303:    */   {
/* 304:459 */     hashCode ^= hashCode >>> 20 ^ hashCode >>> 12;
/* 305:460 */     return hashCode ^ hashCode >>> 7 ^ hashCode >>> 4;
/* 306:    */   }
/* 307:    */   
/* 308:    */   private static class PaddedLock
/* 309:    */     extends ReentrantLock
/* 310:    */   {
/* 311:    */     long unused1;
/* 312:    */     long unused2;
/* 313:    */     long unused3;
/* 314:    */     
/* 315:    */     PaddedLock()
/* 316:    */     {
/* 317:474 */       super();
/* 318:    */     }
/* 319:    */   }
/* 320:    */   
/* 321:    */   private static class PaddedSemaphore
/* 322:    */     extends Semaphore
/* 323:    */   {
/* 324:    */     long unused1;
/* 325:    */     long unused2;
/* 326:    */     long unused3;
/* 327:    */     
/* 328:    */     PaddedSemaphore(int permits)
/* 329:    */     {
/* 330:485 */       super(false);
/* 331:    */     }
/* 332:    */   }
/* 333:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.Striped
 * JD-Core Version:    0.7.0.1
 */