/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.VisibleForTesting;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Stopwatch;
/*   7:    */ import java.util.Locale;
/*   8:    */ import java.util.concurrent.TimeUnit;
/*   9:    */ import javax.annotation.concurrent.ThreadSafe;
/*  10:    */ 
/*  11:    */ @ThreadSafe
/*  12:    */ @Beta
/*  13:    */ public abstract class RateLimiter
/*  14:    */ {
/*  15:    */   private final SleepingStopwatch stopwatch;
/*  16:    */   private volatile Object mutexDoNotUseDirectly;
/*  17:    */   
/*  18:    */   public static RateLimiter create(double permitsPerSecond)
/*  19:    */   {
/*  20:130 */     return create(SleepingStopwatch.createFromSystemTimer(), permitsPerSecond);
/*  21:    */   }
/*  22:    */   
/*  23:    */   @VisibleForTesting
/*  24:    */   static RateLimiter create(SleepingStopwatch stopwatch, double permitsPerSecond)
/*  25:    */   {
/*  26:139 */     RateLimiter rateLimiter = new SmoothRateLimiter.SmoothBursty(stopwatch, 1.0D);
/*  27:140 */     rateLimiter.setRate(permitsPerSecond);
/*  28:141 */     return rateLimiter;
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static RateLimiter create(double permitsPerSecond, long warmupPeriod, TimeUnit unit)
/*  32:    */   {
/*  33:169 */     Preconditions.checkArgument(warmupPeriod >= 0L, "warmupPeriod must not be negative: %s", new Object[] { Long.valueOf(warmupPeriod) });
/*  34:170 */     return create(SleepingStopwatch.createFromSystemTimer(), permitsPerSecond, warmupPeriod, unit, 3.0D);
/*  35:    */   }
/*  36:    */   
/*  37:    */   @VisibleForTesting
/*  38:    */   static RateLimiter create(SleepingStopwatch stopwatch, double permitsPerSecond, long warmupPeriod, TimeUnit unit, double coldFactor)
/*  39:    */   {
/*  40:178 */     RateLimiter rateLimiter = new SmoothRateLimiter.SmoothWarmingUp(stopwatch, warmupPeriod, unit, coldFactor);
/*  41:179 */     rateLimiter.setRate(permitsPerSecond);
/*  42:180 */     return rateLimiter;
/*  43:    */   }
/*  44:    */   
/*  45:    */   private Object mutex()
/*  46:    */   {
/*  47:193 */     Object mutex = this.mutexDoNotUseDirectly;
/*  48:194 */     if (mutex == null) {
/*  49:195 */       synchronized (this)
/*  50:    */       {
/*  51:196 */         mutex = this.mutexDoNotUseDirectly;
/*  52:197 */         if (mutex == null) {
/*  53:198 */           this.mutexDoNotUseDirectly = (mutex = new Object());
/*  54:    */         }
/*  55:    */       }
/*  56:    */     }
/*  57:202 */     return mutex;
/*  58:    */   }
/*  59:    */   
/*  60:    */   RateLimiter(SleepingStopwatch stopwatch)
/*  61:    */   {
/*  62:206 */     this.stopwatch = ((SleepingStopwatch)Preconditions.checkNotNull(stopwatch));
/*  63:    */   }
/*  64:    */   
/*  65:    */   public final void setRate(double permitsPerSecond)
/*  66:    */   {
/*  67:229 */     Preconditions.checkArgument((permitsPerSecond > 0.0D) && (!Double.isNaN(permitsPerSecond)), "rate must be positive");
/*  68:231 */     synchronized (mutex())
/*  69:    */     {
/*  70:232 */       doSetRate(permitsPerSecond, this.stopwatch.readMicros());
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   abstract void doSetRate(double paramDouble, long paramLong);
/*  75:    */   
/*  76:    */   public final double getRate()
/*  77:    */   {
/*  78:246 */     synchronized (mutex())
/*  79:    */     {
/*  80:247 */       return doGetRate();
/*  81:    */     }
/*  82:    */   }
/*  83:    */   
/*  84:    */   abstract double doGetRate();
/*  85:    */   
/*  86:    */   public double acquire()
/*  87:    */   {
/*  88:263 */     return acquire(1);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public double acquire(int permits)
/*  92:    */   {
/*  93:276 */     long microsToWait = reserve(permits);
/*  94:277 */     this.stopwatch.sleepMicrosUninterruptibly(microsToWait);
/*  95:278 */     return 1.0D * microsToWait / TimeUnit.SECONDS.toMicros(1L);
/*  96:    */   }
/*  97:    */   
/*  98:    */   final long reserve(int permits)
/*  99:    */   {
/* 100:288 */     checkPermits(permits);
/* 101:289 */     synchronized (mutex())
/* 102:    */     {
/* 103:290 */       return reserveAndGetWaitLength(permits, this.stopwatch.readMicros());
/* 104:    */     }
/* 105:    */   }
/* 106:    */   
/* 107:    */   public boolean tryAcquire(long timeout, TimeUnit unit)
/* 108:    */   {
/* 109:308 */     return tryAcquire(1, timeout, unit);
/* 110:    */   }
/* 111:    */   
/* 112:    */   public boolean tryAcquire(int permits)
/* 113:    */   {
/* 114:323 */     return tryAcquire(permits, 0L, TimeUnit.MICROSECONDS);
/* 115:    */   }
/* 116:    */   
/* 117:    */   public boolean tryAcquire()
/* 118:    */   {
/* 119:337 */     return tryAcquire(1, 0L, TimeUnit.MICROSECONDS);
/* 120:    */   }
/* 121:    */   
/* 122:    */   public boolean tryAcquire(int permits, long timeout, TimeUnit unit)
/* 123:    */   {
/* 124:353 */     long timeoutMicros = Math.max(unit.toMicros(timeout), 0L);
/* 125:354 */     checkPermits(permits);
/* 126:    */     long microsToWait;
/* 127:356 */     synchronized (mutex())
/* 128:    */     {
/* 129:357 */       long nowMicros = this.stopwatch.readMicros();
/* 130:358 */       if (!canAcquire(nowMicros, timeoutMicros)) {
/* 131:359 */         return false;
/* 132:    */       }
/* 133:361 */       microsToWait = reserveAndGetWaitLength(permits, nowMicros);
/* 134:    */     }
/* 135:364 */     this.stopwatch.sleepMicrosUninterruptibly(microsToWait);
/* 136:365 */     return true;
/* 137:    */   }
/* 138:    */   
/* 139:    */   private boolean canAcquire(long nowMicros, long timeoutMicros)
/* 140:    */   {
/* 141:369 */     return queryEarliestAvailable(nowMicros) - timeoutMicros <= nowMicros;
/* 142:    */   }
/* 143:    */   
/* 144:    */   final long reserveAndGetWaitLength(int permits, long nowMicros)
/* 145:    */   {
/* 146:378 */     long momentAvailable = reserveEarliestAvailable(permits, nowMicros);
/* 147:379 */     return Math.max(momentAvailable - nowMicros, 0L);
/* 148:    */   }
/* 149:    */   
/* 150:    */   abstract long queryEarliestAvailable(long paramLong);
/* 151:    */   
/* 152:    */   abstract long reserveEarliestAvailable(int paramInt, long paramLong);
/* 153:    */   
/* 154:    */   public String toString()
/* 155:    */   {
/* 156:401 */     return String.format(Locale.ROOT, "RateLimiter[stableRate=%3.1fqps]", new Object[] { Double.valueOf(getRate()) });
/* 157:    */   }
/* 158:    */   
/* 159:    */   @VisibleForTesting
/* 160:    */   static abstract class SleepingStopwatch
/* 161:    */   {
/* 162:    */     abstract long readMicros();
/* 163:    */     
/* 164:    */     abstract void sleepMicrosUninterruptibly(long paramLong);
/* 165:    */     
/* 166:    */     static final SleepingStopwatch createFromSystemTimer()
/* 167:    */     {
/* 168:416 */       new SleepingStopwatch()
/* 169:    */       {
/* 170:417 */         final Stopwatch stopwatch = Stopwatch.createStarted();
/* 171:    */         
/* 172:    */         long readMicros()
/* 173:    */         {
/* 174:421 */           return this.stopwatch.elapsed(TimeUnit.MICROSECONDS);
/* 175:    */         }
/* 176:    */         
/* 177:    */         void sleepMicrosUninterruptibly(long micros)
/* 178:    */         {
/* 179:426 */           if (micros > 0L) {
/* 180:427 */             Uninterruptibles.sleepUninterruptibly(micros, TimeUnit.MICROSECONDS);
/* 181:    */           }
/* 182:    */         }
/* 183:    */       };
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   private static int checkPermits(int permits)
/* 188:    */   {
/* 189:435 */     Preconditions.checkArgument(permits > 0, "Requested permits (%s) must be positive", new Object[] { Integer.valueOf(permits) });
/* 190:436 */     return permits;
/* 191:    */   }
/* 192:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.RateLimiter
 * JD-Core Version:    0.7.0.1
 */