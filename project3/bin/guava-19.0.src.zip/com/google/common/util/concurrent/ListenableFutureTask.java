/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import java.util.concurrent.Callable;
/*  4:   */ import java.util.concurrent.Executor;
/*  5:   */ import java.util.concurrent.FutureTask;
/*  6:   */ import javax.annotation.Nullable;
/*  7:   */ 
/*  8:   */ public class ListenableFutureTask<V>
/*  9:   */   extends FutureTask<V>
/* 10:   */   implements ListenableFuture<V>
/* 11:   */ {
/* 12:43 */   private final ExecutionList executionList = new ExecutionList();
/* 13:   */   
/* 14:   */   public static <V> ListenableFutureTask<V> create(Callable<V> callable)
/* 15:   */   {
/* 16:53 */     return new ListenableFutureTask(callable);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static <V> ListenableFutureTask<V> create(Runnable runnable, @Nullable V result)
/* 20:   */   {
/* 21:70 */     return new ListenableFutureTask(runnable, result);
/* 22:   */   }
/* 23:   */   
/* 24:   */   ListenableFutureTask(Callable<V> callable)
/* 25:   */   {
/* 26:74 */     super(callable);
/* 27:   */   }
/* 28:   */   
/* 29:   */   ListenableFutureTask(Runnable runnable, @Nullable V result)
/* 30:   */   {
/* 31:78 */     super(runnable, result);
/* 32:   */   }
/* 33:   */   
/* 34:   */   public void addListener(Runnable listener, Executor exec)
/* 35:   */   {
/* 36:83 */     this.executionList.add(listener, exec);
/* 37:   */   }
/* 38:   */   
/* 39:   */   protected void done()
/* 40:   */   {
/* 41:91 */     this.executionList.execute();
/* 42:   */   }
/* 43:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ListenableFutureTask
 * JD-Core Version:    0.7.0.1
 */