/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.base.Supplier;
/*   7:    */ import java.util.concurrent.Callable;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ 
/*  10:    */ @GwtCompatible(emulated=true)
/*  11:    */ public final class Callables
/*  12:    */ {
/*  13:    */   public static <T> Callable<T> returning(@Nullable T value)
/*  14:    */   {
/*  15: 44 */     new Callable()
/*  16:    */     {
/*  17:    */       public T call()
/*  18:    */       {
/*  19: 46 */         return this.val$value;
/*  20:    */       }
/*  21:    */     };
/*  22:    */   }
/*  23:    */   
/*  24:    */   @GwtIncompatible("threads")
/*  25:    */   static <T> Callable<T> threadRenaming(final Callable<T> callable, Supplier<String> nameSupplier)
/*  26:    */   {
/*  27: 63 */     Preconditions.checkNotNull(nameSupplier);
/*  28: 64 */     Preconditions.checkNotNull(callable);
/*  29: 65 */     new Callable()
/*  30:    */     {
/*  31:    */       public T call()
/*  32:    */         throws Exception
/*  33:    */       {
/*  34: 67 */         Thread currentThread = Thread.currentThread();
/*  35: 68 */         String oldName = currentThread.getName();
/*  36: 69 */         boolean restoreName = Callables.trySetName((String)this.val$nameSupplier.get(), currentThread);
/*  37:    */         try
/*  38:    */         {
/*  39: 71 */           return callable.call();
/*  40:    */         }
/*  41:    */         finally
/*  42:    */         {
/*  43: 73 */           if (restoreName) {
/*  44: 74 */             Callables.trySetName(oldName, currentThread);
/*  45:    */           }
/*  46:    */         }
/*  47:    */       }
/*  48:    */     };
/*  49:    */   }
/*  50:    */   
/*  51:    */   @GwtIncompatible("threads")
/*  52:    */   static Runnable threadRenaming(final Runnable task, Supplier<String> nameSupplier)
/*  53:    */   {
/*  54: 92 */     Preconditions.checkNotNull(nameSupplier);
/*  55: 93 */     Preconditions.checkNotNull(task);
/*  56: 94 */     new Runnable()
/*  57:    */     {
/*  58:    */       public void run()
/*  59:    */       {
/*  60: 96 */         Thread currentThread = Thread.currentThread();
/*  61: 97 */         String oldName = currentThread.getName();
/*  62: 98 */         boolean restoreName = Callables.trySetName((String)this.val$nameSupplier.get(), currentThread);
/*  63:    */         try
/*  64:    */         {
/*  65:100 */           task.run();
/*  66:    */         }
/*  67:    */         finally
/*  68:    */         {
/*  69:102 */           if (restoreName) {
/*  70:103 */             Callables.trySetName(oldName, currentThread);
/*  71:    */           }
/*  72:    */         }
/*  73:    */       }
/*  74:    */     };
/*  75:    */   }
/*  76:    */   
/*  77:    */   @GwtIncompatible("threads")
/*  78:    */   private static boolean trySetName(String threadName, Thread currentThread)
/*  79:    */   {
/*  80:    */     try
/*  81:    */     {
/*  82:117 */       currentThread.setName(threadName);
/*  83:118 */       return true;
/*  84:    */     }
/*  85:    */     catch (SecurityException e) {}
/*  86:120 */     return false;
/*  87:    */   }
/*  88:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.Callables
 * JD-Core Version:    0.7.0.1
 */