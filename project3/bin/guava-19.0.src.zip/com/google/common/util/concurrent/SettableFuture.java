/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.annotations.GwtCompatible;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ @GwtCompatible
/*  8:   */ public final class SettableFuture<V>
/*  9:   */   extends AbstractFuture.TrustedFuture<V>
/* 10:   */ {
/* 11:   */   public static <V> SettableFuture<V> create()
/* 12:   */   {
/* 13:39 */     return new SettableFuture();
/* 14:   */   }
/* 15:   */   
/* 16:   */   public boolean set(@Nullable V value)
/* 17:   */   {
/* 18:49 */     return super.set(value);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean setException(Throwable throwable)
/* 22:   */   {
/* 23:53 */     return super.setException(throwable);
/* 24:   */   }
/* 25:   */   
/* 26:   */   @Beta
/* 27:   */   public boolean setFuture(ListenableFuture<? extends V> future)
/* 28:   */   {
/* 29:59 */     return super.setFuture(future);
/* 30:   */   }
/* 31:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.SettableFuture
 * JD-Core Version:    0.7.0.1
 */