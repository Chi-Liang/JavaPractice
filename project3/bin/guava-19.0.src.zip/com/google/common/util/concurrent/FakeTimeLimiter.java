/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.Beta;
/*  4:   */ import com.google.common.base.Preconditions;
/*  5:   */ import java.util.concurrent.Callable;
/*  6:   */ import java.util.concurrent.TimeUnit;
/*  7:   */ 
/*  8:   */ @Beta
/*  9:   */ public final class FakeTimeLimiter
/* 10:   */   implements TimeLimiter
/* 11:   */ {
/* 12:   */   public <T> T newProxy(T target, Class<T> interfaceType, long timeoutDuration, TimeUnit timeoutUnit)
/* 13:   */   {
/* 14:41 */     Preconditions.checkNotNull(target);
/* 15:42 */     Preconditions.checkNotNull(interfaceType);
/* 16:43 */     Preconditions.checkNotNull(timeoutUnit);
/* 17:44 */     return target;
/* 18:   */   }
/* 19:   */   
/* 20:   */   public <T> T callWithTimeout(Callable<T> callable, long timeoutDuration, TimeUnit timeoutUnit, boolean amInterruptible)
/* 21:   */     throws Exception
/* 22:   */   {
/* 23:50 */     Preconditions.checkNotNull(timeoutUnit);
/* 24:51 */     return callable.call();
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.FakeTimeLimiter
 * JD-Core Version:    0.7.0.1
 */