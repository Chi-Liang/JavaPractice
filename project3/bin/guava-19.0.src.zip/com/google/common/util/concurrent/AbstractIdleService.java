/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Supplier;
/*   5:    */ import java.util.concurrent.Executor;
/*   6:    */ import java.util.concurrent.TimeUnit;
/*   7:    */ import java.util.concurrent.TimeoutException;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ public abstract class AbstractIdleService
/*  11:    */   implements Service
/*  12:    */ {
/*  13: 41 */   private final Supplier<String> threadNameSupplier = new ThreadNameSupplier(null);
/*  14:    */   protected abstract void startUp()
/*  15:    */     throws Exception;
/*  16:    */   
/*  17:    */   protected abstract void shutDown()
/*  18:    */     throws Exception;
/*  19:    */   
/*  20:    */   private final class ThreadNameSupplier
/*  21:    */     implements Supplier<String>
/*  22:    */   {
/*  23:    */     private ThreadNameSupplier() {}
/*  24:    */     
/*  25:    */     public String get()
/*  26:    */     {
/*  27: 46 */       return AbstractIdleService.this.serviceName() + " " + AbstractIdleService.this.state();
/*  28:    */     }
/*  29:    */   }
/*  30:    */   
/*  31: 51 */   private final Service delegate = new DelegateService(null);
/*  32:    */   
/*  33:    */   private final class DelegateService
/*  34:    */     extends AbstractService
/*  35:    */   {
/*  36:    */     private DelegateService() {}
/*  37:    */     
/*  38:    */     protected final void doStart()
/*  39:    */     {
/*  40: 56 */       MoreExecutors.renamingDecorator(AbstractIdleService.this.executor(), AbstractIdleService.this.threadNameSupplier).execute(new Runnable()
/*  41:    */       {
/*  42:    */         public void run()
/*  43:    */         {
/*  44:    */           try
/*  45:    */           {
/*  46: 60 */             AbstractIdleService.this.startUp();
/*  47: 61 */             AbstractIdleService.DelegateService.this.notifyStarted();
/*  48:    */           }
/*  49:    */           catch (Throwable t)
/*  50:    */           {
/*  51: 63 */             AbstractIdleService.DelegateService.this.notifyFailed(t);
/*  52:    */           }
/*  53:    */         }
/*  54:    */       });
/*  55:    */     }
/*  56:    */     
/*  57:    */     protected final void doStop()
/*  58:    */     {
/*  59: 70 */       MoreExecutors.renamingDecorator(AbstractIdleService.this.executor(), AbstractIdleService.this.threadNameSupplier).execute(new Runnable()
/*  60:    */       {
/*  61:    */         public void run()
/*  62:    */         {
/*  63:    */           try
/*  64:    */           {
/*  65: 74 */             AbstractIdleService.this.shutDown();
/*  66: 75 */             AbstractIdleService.DelegateService.this.notifyStopped();
/*  67:    */           }
/*  68:    */           catch (Throwable t)
/*  69:    */           {
/*  70: 77 */             AbstractIdleService.DelegateService.this.notifyFailed(t);
/*  71:    */           }
/*  72:    */         }
/*  73:    */       });
/*  74:    */     }
/*  75:    */     
/*  76:    */     public String toString()
/*  77:    */     {
/*  78: 84 */       return AbstractIdleService.this.toString();
/*  79:    */     }
/*  80:    */   }
/*  81:    */   
/*  82:    */   protected Executor executor()
/*  83:    */   {
/*  84:106 */     new Executor()
/*  85:    */     {
/*  86:    */       public void execute(Runnable command)
/*  87:    */       {
/*  88:108 */         MoreExecutors.newThread((String)AbstractIdleService.this.threadNameSupplier.get(), command).start();
/*  89:    */       }
/*  90:    */     };
/*  91:    */   }
/*  92:    */   
/*  93:    */   public String toString()
/*  94:    */   {
/*  95:114 */     return serviceName() + " [" + state() + "]";
/*  96:    */   }
/*  97:    */   
/*  98:    */   public final boolean isRunning()
/*  99:    */   {
/* 100:118 */     return this.delegate.isRunning();
/* 101:    */   }
/* 102:    */   
/* 103:    */   public final Service.State state()
/* 104:    */   {
/* 105:122 */     return this.delegate.state();
/* 106:    */   }
/* 107:    */   
/* 108:    */   public final void addListener(Service.Listener listener, Executor executor)
/* 109:    */   {
/* 110:129 */     this.delegate.addListener(listener, executor);
/* 111:    */   }
/* 112:    */   
/* 113:    */   public final Throwable failureCause()
/* 114:    */   {
/* 115:136 */     return this.delegate.failureCause();
/* 116:    */   }
/* 117:    */   
/* 118:    */   public final Service startAsync()
/* 119:    */   {
/* 120:143 */     this.delegate.startAsync();
/* 121:144 */     return this;
/* 122:    */   }
/* 123:    */   
/* 124:    */   public final Service stopAsync()
/* 125:    */   {
/* 126:151 */     this.delegate.stopAsync();
/* 127:152 */     return this;
/* 128:    */   }
/* 129:    */   
/* 130:    */   public final void awaitRunning()
/* 131:    */   {
/* 132:159 */     this.delegate.awaitRunning();
/* 133:    */   }
/* 134:    */   
/* 135:    */   public final void awaitRunning(long timeout, TimeUnit unit)
/* 136:    */     throws TimeoutException
/* 137:    */   {
/* 138:166 */     this.delegate.awaitRunning(timeout, unit);
/* 139:    */   }
/* 140:    */   
/* 141:    */   public final void awaitTerminated()
/* 142:    */   {
/* 143:173 */     this.delegate.awaitTerminated();
/* 144:    */   }
/* 145:    */   
/* 146:    */   public final void awaitTerminated(long timeout, TimeUnit unit)
/* 147:    */     throws TimeoutException
/* 148:    */   {
/* 149:180 */     this.delegate.awaitTerminated(timeout, unit);
/* 150:    */   }
/* 151:    */   
/* 152:    */   protected String serviceName()
/* 153:    */   {
/* 154:190 */     return getClass().getSimpleName();
/* 155:    */   }
/* 156:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractIdleService
 * JD-Core Version:    0.7.0.1
 */