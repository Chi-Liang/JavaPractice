/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import javax.annotation.Nullable;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public class UncheckedExecutionException
/*  8:   */   extends RuntimeException
/*  9:   */ {
/* 10:   */   private static final long serialVersionUID = 0L;
/* 11:   */   
/* 12:   */   protected UncheckedExecutionException() {}
/* 13:   */   
/* 14:   */   protected UncheckedExecutionException(@Nullable String message)
/* 15:   */   {
/* 16:51 */     super(message);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public UncheckedExecutionException(@Nullable String message, @Nullable Throwable cause)
/* 20:   */   {
/* 21:58 */     super(message, cause);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public UncheckedExecutionException(@Nullable Throwable cause)
/* 25:   */   {
/* 26:65 */     super(cause);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.UncheckedExecutionException
 * JD-Core Version:    0.7.0.1
 */