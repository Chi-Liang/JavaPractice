/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.Ordering;
/*   7:    */ import java.lang.ref.WeakReference;
/*   8:    */ import java.lang.reflect.Constructor;
/*   9:    */ import java.lang.reflect.InvocationTargetException;
/*  10:    */ import java.util.Arrays;
/*  11:    */ import java.util.List;
/*  12:    */ import java.util.Set;
/*  13:    */ import java.util.concurrent.CopyOnWriteArraySet;
/*  14:    */ import java.util.concurrent.ExecutionException;
/*  15:    */ import java.util.concurrent.Future;
/*  16:    */ import java.util.concurrent.TimeUnit;
/*  17:    */ import java.util.concurrent.TimeoutException;
/*  18:    */ import javax.annotation.Nullable;
/*  19:    */ import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;
/*  20:    */ 
/*  21:    */ final class FuturesGetChecked
/*  22:    */ {
/*  23:    */   static <V, X extends Exception> V getChecked(Future<V> future, Class<X> exceptionClass)
/*  24:    */     throws Exception
/*  25:    */   {
/*  26: 47 */     return getChecked(bestGetCheckedTypeValidator(), future, exceptionClass);
/*  27:    */   }
/*  28:    */   
/*  29:    */   @VisibleForTesting
/*  30:    */   static <V, X extends Exception> V getChecked(GetCheckedTypeValidator validator, Future<V> future, Class<X> exceptionClass)
/*  31:    */     throws Exception
/*  32:    */   {
/*  33: 56 */     validator.validateClass(exceptionClass);
/*  34:    */     try
/*  35:    */     {
/*  36: 58 */       return future.get();
/*  37:    */     }
/*  38:    */     catch (InterruptedException e)
/*  39:    */     {
/*  40: 60 */       Thread.currentThread().interrupt();
/*  41: 61 */       throw newWithCause(exceptionClass, e);
/*  42:    */     }
/*  43:    */     catch (ExecutionException e)
/*  44:    */     {
/*  45: 63 */       wrapAndThrowExceptionOrError(e.getCause(), exceptionClass);
/*  46: 64 */       throw new AssertionError();
/*  47:    */     }
/*  48:    */   }
/*  49:    */   
/*  50:    */   static <V, X extends Exception> V getChecked(Future<V> future, Class<X> exceptionClass, long timeout, TimeUnit unit)
/*  51:    */     throws Exception
/*  52:    */   {
/*  53: 74 */     bestGetCheckedTypeValidator().validateClass(exceptionClass);
/*  54:    */     try
/*  55:    */     {
/*  56: 76 */       return future.get(timeout, unit);
/*  57:    */     }
/*  58:    */     catch (InterruptedException e)
/*  59:    */     {
/*  60: 78 */       Thread.currentThread().interrupt();
/*  61: 79 */       throw newWithCause(exceptionClass, e);
/*  62:    */     }
/*  63:    */     catch (TimeoutException e)
/*  64:    */     {
/*  65: 81 */       throw newWithCause(exceptionClass, e);
/*  66:    */     }
/*  67:    */     catch (ExecutionException e)
/*  68:    */     {
/*  69: 83 */       wrapAndThrowExceptionOrError(e.getCause(), exceptionClass);
/*  70: 84 */       throw new AssertionError();
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static GetCheckedTypeValidator bestGetCheckedTypeValidator()
/*  75:    */   {
/*  76: 94 */     return GetCheckedTypeValidatorHolder.BEST_VALIDATOR;
/*  77:    */   }
/*  78:    */   
/*  79:    */   @VisibleForTesting
/*  80:    */   static GetCheckedTypeValidator weakSetValidator()
/*  81:    */   {
/*  82: 99 */     return FuturesGetChecked.GetCheckedTypeValidatorHolder.WeakSetValidator.INSTANCE;
/*  83:    */   }
/*  84:    */   
/*  85:    */   @VisibleForTesting
/*  86:    */   static GetCheckedTypeValidator classValueValidator()
/*  87:    */   {
/*  88:105 */     return FuturesGetChecked.GetCheckedTypeValidatorHolder.ClassValueValidator.INSTANCE;
/*  89:    */   }
/*  90:    */   
/*  91:    */   @VisibleForTesting
/*  92:    */   static class GetCheckedTypeValidatorHolder
/*  93:    */   {
/*  94:116 */     static final String CLASS_VALUE_VALIDATOR_NAME = GetCheckedTypeValidatorHolder.class.getName() + "$ClassValueValidator";
/*  95:119 */     static final FuturesGetChecked.GetCheckedTypeValidator BEST_VALIDATOR = getBestValidator();
/*  96:    */     
/*  97:    */     @IgnoreJRERequirement
/*  98:    */     static enum ClassValueValidator
/*  99:    */       implements FuturesGetChecked.GetCheckedTypeValidator
/* 100:    */     {
/* 101:124 */       INSTANCE;
/* 102:    */       
/* 103:130 */       private static final ClassValue<Boolean> isValidClass = new ClassValue()
/* 104:    */       {
/* 105:    */         protected Boolean computeValue(Class<?> type)
/* 106:    */         {
/* 107:134 */           FuturesGetChecked.checkExceptionClassValidity(type.asSubclass(Exception.class));
/* 108:135 */           return Boolean.valueOf(true);
/* 109:    */         }
/* 110:    */       };
/* 111:    */       
/* 112:    */       private ClassValueValidator() {}
/* 113:    */       
/* 114:    */       public void validateClass(Class<? extends Exception> exceptionClass)
/* 115:    */       {
/* 116:141 */         isValidClass.get(exceptionClass);
/* 117:    */       }
/* 118:    */     }
/* 119:    */     
/* 120:    */     static enum WeakSetValidator
/* 121:    */       implements FuturesGetChecked.GetCheckedTypeValidator
/* 122:    */     {
/* 123:146 */       INSTANCE;
/* 124:    */       
/* 125:156 */       private static final Set<WeakReference<Class<? extends Exception>>> validClasses = new CopyOnWriteArraySet();
/* 126:    */       
/* 127:    */       private WeakSetValidator() {}
/* 128:    */       
/* 129:    */       public void validateClass(Class<? extends Exception> exceptionClass)
/* 130:    */       {
/* 131:161 */         for (WeakReference<Class<? extends Exception>> knownGood : validClasses) {
/* 132:162 */           if (exceptionClass.equals(knownGood.get())) {
/* 133:163 */             return;
/* 134:    */           }
/* 135:    */         }
/* 136:167 */         FuturesGetChecked.checkExceptionClassValidity(exceptionClass);
/* 137:178 */         if (validClasses.size() > 1000) {
/* 138:179 */           validClasses.clear();
/* 139:    */         }
/* 140:182 */         validClasses.add(new WeakReference(exceptionClass));
/* 141:    */       }
/* 142:    */     }
/* 143:    */     
/* 144:    */     static FuturesGetChecked.GetCheckedTypeValidator getBestValidator()
/* 145:    */     {
/* 146:    */       try
/* 147:    */       {
/* 148:192 */         Class<?> theClass = Class.forName(CLASS_VALUE_VALIDATOR_NAME);
/* 149:193 */         return (FuturesGetChecked.GetCheckedTypeValidator)theClass.getEnumConstants()[0];
/* 150:    */       }
/* 151:    */       catch (Throwable t) {}
/* 152:195 */       return FuturesGetChecked.weakSetValidator();
/* 153:    */     }
/* 154:    */   }
/* 155:    */   
/* 156:    */   private static <X extends Exception> void wrapAndThrowExceptionOrError(Throwable cause, Class<X> exceptionClass)
/* 157:    */     throws Exception
/* 158:    */   {
/* 159:203 */     if ((cause instanceof Error)) {
/* 160:204 */       throw new ExecutionError((Error)cause);
/* 161:    */     }
/* 162:206 */     if ((cause instanceof RuntimeException)) {
/* 163:207 */       throw new UncheckedExecutionException(cause);
/* 164:    */     }
/* 165:209 */     throw newWithCause(exceptionClass, cause);
/* 166:    */   }
/* 167:    */   
/* 168:    */   private static boolean hasConstructorUsableByGetChecked(Class<? extends Exception> exceptionClass)
/* 169:    */   {
/* 170:    */     try
/* 171:    */     {
/* 172:220 */       newWithCause(exceptionClass, new Exception());
/* 173:221 */       return true;
/* 174:    */     }
/* 175:    */     catch (Exception e) {}
/* 176:223 */     return false;
/* 177:    */   }
/* 178:    */   
/* 179:    */   private static <X extends Exception> X newWithCause(Class<X> exceptionClass, Throwable cause)
/* 180:    */   {
/* 181:230 */     List<Constructor<X>> constructors = Arrays.asList(exceptionClass.getConstructors());
/* 182:231 */     for (Constructor<X> constructor : preferringStrings(constructors))
/* 183:    */     {
/* 184:232 */       X instance = (Exception)newFromConstructor(constructor, cause);
/* 185:233 */       if (instance != null)
/* 186:    */       {
/* 187:234 */         if (instance.getCause() == null) {
/* 188:235 */           instance.initCause(cause);
/* 189:    */         }
/* 190:237 */         return instance;
/* 191:    */       }
/* 192:    */     }
/* 193:240 */     throw new IllegalArgumentException("No appropriate constructor for exception of type " + exceptionClass + " in response to chained exception", cause);
/* 194:    */   }
/* 195:    */   
/* 196:    */   private static <X extends Exception> List<Constructor<X>> preferringStrings(List<Constructor<X>> constructors)
/* 197:    */   {
/* 198:249 */     return WITH_STRING_PARAM_FIRST.sortedCopy(constructors);
/* 199:    */   }
/* 200:    */   
/* 201:252 */   private static final Ordering<Constructor<?>> WITH_STRING_PARAM_FIRST = Ordering.natural().onResultOf(new Function()
/* 202:    */   {
/* 203:    */     public Boolean apply(Constructor<?> input)
/* 204:    */     {
/* 205:258 */       return Boolean.valueOf(Arrays.asList(input.getParameterTypes()).contains(String.class));
/* 206:    */     }
/* 207:252 */   }).reverse();
/* 208:    */   
/* 209:    */   @Nullable
/* 210:    */   private static <X> X newFromConstructor(Constructor<X> constructor, Throwable cause)
/* 211:    */   {
/* 212:265 */     Class<?>[] paramTypes = constructor.getParameterTypes();
/* 213:266 */     Object[] params = new Object[paramTypes.length];
/* 214:267 */     for (int i = 0; i < paramTypes.length; i++)
/* 215:    */     {
/* 216:268 */       Class<?> paramType = paramTypes[i];
/* 217:269 */       if (paramType.equals(String.class)) {
/* 218:270 */         params[i] = cause.toString();
/* 219:271 */       } else if (paramType.equals(Throwable.class)) {
/* 220:272 */         params[i] = cause;
/* 221:    */       } else {
/* 222:274 */         return null;
/* 223:    */       }
/* 224:    */     }
/* 225:    */     try
/* 226:    */     {
/* 227:278 */       return constructor.newInstance(params);
/* 228:    */     }
/* 229:    */     catch (IllegalArgumentException e)
/* 230:    */     {
/* 231:280 */       return null;
/* 232:    */     }
/* 233:    */     catch (InstantiationException e)
/* 234:    */     {
/* 235:282 */       return null;
/* 236:    */     }
/* 237:    */     catch (IllegalAccessException e)
/* 238:    */     {
/* 239:284 */       return null;
/* 240:    */     }
/* 241:    */     catch (InvocationTargetException e) {}
/* 242:286 */     return null;
/* 243:    */   }
/* 244:    */   
/* 245:    */   @VisibleForTesting
/* 246:    */   static boolean isCheckedException(Class<? extends Exception> type)
/* 247:    */   {
/* 248:292 */     return !RuntimeException.class.isAssignableFrom(type);
/* 249:    */   }
/* 250:    */   
/* 251:    */   @VisibleForTesting
/* 252:    */   static void checkExceptionClassValidity(Class<? extends Exception> exceptionClass)
/* 253:    */   {
/* 254:297 */     Preconditions.checkArgument(isCheckedException(exceptionClass), "Futures.getChecked exception type (%s) must not be a RuntimeException", new Object[] { exceptionClass });
/* 255:    */     
/* 256:    */ 
/* 257:    */ 
/* 258:301 */     Preconditions.checkArgument(hasConstructorUsableByGetChecked(exceptionClass), "Futures.getChecked exception type (%s) must be an accessible class with an accessible constructor whose parameters (if any) must be of type String and/or Throwable", new Object[] { exceptionClass });
/* 259:    */   }
/* 260:    */   
/* 261:    */   @VisibleForTesting
/* 262:    */   static abstract interface GetCheckedTypeValidator
/* 263:    */   {
/* 264:    */     public abstract void validateClass(Class<? extends Exception> paramClass);
/* 265:    */   }
/* 266:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.FuturesGetChecked
 * JD-Core Version:    0.7.0.1
 */