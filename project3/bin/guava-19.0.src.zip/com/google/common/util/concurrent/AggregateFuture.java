/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.ImmutableCollection;
/*   7:    */ import java.util.Set;
/*   8:    */ import java.util.concurrent.ExecutionException;
/*   9:    */ import java.util.concurrent.Future;
/*  10:    */ import java.util.logging.Level;
/*  11:    */ import java.util.logging.Logger;
/*  12:    */ import javax.annotation.Nullable;
/*  13:    */ 
/*  14:    */ @GwtCompatible
/*  15:    */ abstract class AggregateFuture<InputT, OutputT>
/*  16:    */   extends AbstractFuture.TrustedFuture<OutputT>
/*  17:    */ {
/*  18: 45 */   private static final Logger logger = Logger.getLogger(AggregateFuture.class.getName());
/*  19:    */   private AggregateFuture<InputT, OutputT>.RunningState runningState;
/*  20:    */   
/*  21:    */   final void done()
/*  22:    */   {
/*  23: 51 */     super.done();
/*  24:    */     
/*  25:    */ 
/*  26: 54 */     this.runningState = null;
/*  27:    */   }
/*  28:    */   
/*  29:    */   public final boolean cancel(boolean mayInterruptIfRunning)
/*  30:    */   {
/*  31: 60 */     AggregateFuture<InputT, OutputT>.RunningState localRunningState = this.runningState;
/*  32: 61 */     ImmutableCollection<? extends ListenableFuture<? extends InputT>> futures = localRunningState != null ? localRunningState.futures : null;
/*  33:    */     
/*  34:    */ 
/*  35: 64 */     boolean cancelled = super.cancel(mayInterruptIfRunning);
/*  36: 66 */     if ((cancelled & futures != null)) {
/*  37: 67 */       for (ListenableFuture<?> future : futures) {
/*  38: 68 */         future.cancel(mayInterruptIfRunning);
/*  39:    */       }
/*  40:    */     }
/*  41: 71 */     return cancelled;
/*  42:    */   }
/*  43:    */   
/*  44:    */   @GwtIncompatible("Interruption not supported")
/*  45:    */   protected final void interruptTask()
/*  46:    */   {
/*  47: 76 */     AggregateFuture<InputT, OutputT>.RunningState localRunningState = this.runningState;
/*  48: 77 */     if (localRunningState != null) {
/*  49: 78 */       localRunningState.interruptTask();
/*  50:    */     }
/*  51:    */   }
/*  52:    */   
/*  53:    */   final void init(AggregateFuture<InputT, OutputT>.RunningState runningState)
/*  54:    */   {
/*  55: 86 */     this.runningState = runningState;
/*  56: 87 */     runningState.init();
/*  57:    */   }
/*  58:    */   
/*  59:    */   abstract class RunningState
/*  60:    */     extends AggregateFutureState
/*  61:    */     implements Runnable
/*  62:    */   {
/*  63:    */     private ImmutableCollection<? extends ListenableFuture<? extends InputT>> futures;
/*  64:    */     private final boolean allMustSucceed;
/*  65:    */     private final boolean collectsValues;
/*  66:    */     
/*  67:    */     RunningState(boolean futures, boolean allMustSucceed)
/*  68:    */     {
/*  69: 98 */       super();
/*  70: 99 */       this.futures = ((ImmutableCollection)Preconditions.checkNotNull(futures));
/*  71:100 */       this.allMustSucceed = allMustSucceed;
/*  72:101 */       this.collectsValues = collectsValues;
/*  73:    */     }
/*  74:    */     
/*  75:    */     public final void run()
/*  76:    */     {
/*  77:106 */       decrementCountAndMaybeComplete();
/*  78:    */     }
/*  79:    */     
/*  80:    */     private void init()
/*  81:    */     {
/*  82:117 */       if (this.futures.isEmpty())
/*  83:    */       {
/*  84:118 */         handleAllCompleted(); return;
/*  85:    */       }
/*  86:    */       int i;
/*  87:125 */       if (this.allMustSucceed)
/*  88:    */       {
/*  89:137 */         i = 0;
/*  90:138 */         for (final ListenableFuture<? extends InputT> listenable : this.futures)
/*  91:    */         {
/*  92:139 */           final int index = i++;
/*  93:140 */           listenable.addListener(new Runnable()
/*  94:    */           {
/*  95:    */             public void run()
/*  96:    */             {
/*  97:    */               try
/*  98:    */               {
/*  99:144 */                 AggregateFuture.RunningState.this.handleOneInputDone(index, listenable);
/* 100:    */               }
/* 101:    */               finally
/* 102:    */               {
/* 103:146 */                 AggregateFuture.RunningState.this.decrementCountAndMaybeComplete();
/* 104:    */               }
/* 105:    */             }
/* 106:146 */           }, MoreExecutors.directExecutor());
/* 107:    */         }
/* 108:    */       }
/* 109:    */       else
/* 110:    */       {
/* 111:154 */         for (ListenableFuture<? extends InputT> listenable : this.futures) {
/* 112:155 */           listenable.addListener(this, MoreExecutors.directExecutor());
/* 113:    */         }
/* 114:    */       }
/* 115:    */     }
/* 116:    */     
/* 117:    */     private void handleException(Throwable throwable)
/* 118:    */     {
/* 119:167 */       Preconditions.checkNotNull(throwable);
/* 120:    */       
/* 121:169 */       boolean completedWithFailure = false;
/* 122:170 */       boolean firstTimeSeeingThisException = true;
/* 123:171 */       if (this.allMustSucceed)
/* 124:    */       {
/* 125:174 */         completedWithFailure = AggregateFuture.this.setException(throwable);
/* 126:175 */         if (completedWithFailure) {
/* 127:176 */           releaseResourcesAfterFailure();
/* 128:    */         } else {
/* 129:180 */           firstTimeSeeingThisException = AggregateFuture.addCausalChain(getOrInitSeenExceptions(), throwable);
/* 130:    */         }
/* 131:    */       }
/* 132:185 */       if ((throwable instanceof Error | this.allMustSucceed & !completedWithFailure & firstTimeSeeingThisException))
/* 133:    */       {
/* 134:187 */         String message = (throwable instanceof Error) ? "Input Future failed with Error" : "Got more than one input Future failure. Logging failures after the first";
/* 135:    */         
/* 136:    */ 
/* 137:    */ 
/* 138:191 */         AggregateFuture.logger.log(Level.SEVERE, message, throwable);
/* 139:    */       }
/* 140:    */     }
/* 141:    */     
/* 142:    */     final void addInitialException(Set<Throwable> seen)
/* 143:    */     {
/* 144:197 */       if (!AggregateFuture.this.isCancelled()) {
/* 145:198 */         AggregateFuture.addCausalChain(seen, AggregateFuture.this.trustedGetException());
/* 146:    */       }
/* 147:    */     }
/* 148:    */     
/* 149:    */     private void handleOneInputDone(int index, Future<? extends InputT> future)
/* 150:    */     {
/* 151:209 */       Preconditions.checkState((this.allMustSucceed) || (!AggregateFuture.this.isDone()) || (AggregateFuture.this.isCancelled()), "Future was done before all dependencies completed");
/* 152:    */       try
/* 153:    */       {
/* 154:213 */         Preconditions.checkState(future.isDone(), "Tried to set value from future which is not done");
/* 155:215 */         if (this.allMustSucceed)
/* 156:    */         {
/* 157:216 */           if (future.isCancelled())
/* 158:    */           {
/* 159:220 */             AggregateFuture.this.cancel(false);
/* 160:    */           }
/* 161:    */           else
/* 162:    */           {
/* 163:223 */             InputT result = Uninterruptibles.getUninterruptibly(future);
/* 164:224 */             if (this.collectsValues) {
/* 165:225 */               collectOneValue(this.allMustSucceed, index, result);
/* 166:    */             }
/* 167:    */           }
/* 168:    */         }
/* 169:228 */         else if ((this.collectsValues) && (!future.isCancelled())) {
/* 170:229 */           collectOneValue(this.allMustSucceed, index, Uninterruptibles.getUninterruptibly(future));
/* 171:    */         }
/* 172:    */       }
/* 173:    */       catch (ExecutionException e)
/* 174:    */       {
/* 175:232 */         handleException(e.getCause());
/* 176:    */       }
/* 177:    */       catch (Throwable t)
/* 178:    */       {
/* 179:234 */         handleException(t);
/* 180:    */       }
/* 181:    */     }
/* 182:    */     
/* 183:    */     private void decrementCountAndMaybeComplete()
/* 184:    */     {
/* 185:239 */       int newRemaining = decrementRemainingAndGet();
/* 186:240 */       Preconditions.checkState(newRemaining >= 0, "Less than 0 remaining futures");
/* 187:241 */       if (newRemaining == 0) {
/* 188:242 */         processCompleted();
/* 189:    */       }
/* 190:    */     }
/* 191:    */     
/* 192:    */     private void processCompleted()
/* 193:    */     {
/* 194:    */       int i;
/* 195:249 */       if ((this.collectsValues & !this.allMustSucceed))
/* 196:    */       {
/* 197:250 */         i = 0;
/* 198:251 */         for (ListenableFuture<? extends InputT> listenable : this.futures) {
/* 199:252 */           handleOneInputDone(i++, listenable);
/* 200:    */         }
/* 201:    */       }
/* 202:255 */       handleAllCompleted();
/* 203:    */     }
/* 204:    */     
/* 205:    */     void releaseResourcesAfterFailure()
/* 206:    */     {
/* 207:268 */       this.futures = null;
/* 208:    */     }
/* 209:    */     
/* 210:    */     abstract void collectOneValue(boolean paramBoolean, int paramInt, @Nullable InputT paramInputT);
/* 211:    */     
/* 212:    */     abstract void handleAllCompleted();
/* 213:    */     
/* 214:    */     void interruptTask() {}
/* 215:    */   }
/* 216:    */   
/* 217:    */   private static boolean addCausalChain(Set<Throwable> seen, Throwable t)
/* 218:    */   {
/* 219:286 */     for (; t != null; t = t.getCause())
/* 220:    */     {
/* 221:287 */       boolean firstTimeSeen = seen.add(t);
/* 222:288 */       if (!firstTimeSeen) {
/* 223:295 */         return false;
/* 224:    */       }
/* 225:    */     }
/* 226:298 */     return true;
/* 227:    */   }
/* 228:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AggregateFuture
 * JD-Core Version:    0.7.0.1
 */