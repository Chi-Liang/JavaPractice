/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.collect.ForwardingQueue;
/*  4:   */ import java.util.Collection;
/*  5:   */ import java.util.concurrent.BlockingQueue;
/*  6:   */ import java.util.concurrent.TimeUnit;
/*  7:   */ 
/*  8:   */ public abstract class ForwardingBlockingQueue<E>
/*  9:   */   extends ForwardingQueue<E>
/* 10:   */   implements BlockingQueue<E>
/* 11:   */ {
/* 12:   */   protected abstract BlockingQueue<E> delegate();
/* 13:   */   
/* 14:   */   public int drainTo(Collection<? super E> c, int maxElements)
/* 15:   */   {
/* 16:46 */     return delegate().drainTo(c, maxElements);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public int drainTo(Collection<? super E> c)
/* 20:   */   {
/* 21:50 */     return delegate().drainTo(c);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public boolean offer(E e, long timeout, TimeUnit unit)
/* 25:   */     throws InterruptedException
/* 26:   */   {
/* 27:55 */     return delegate().offer(e, timeout, unit);
/* 28:   */   }
/* 29:   */   
/* 30:   */   public E poll(long timeout, TimeUnit unit)
/* 31:   */     throws InterruptedException
/* 32:   */   {
/* 33:60 */     return delegate().poll(timeout, unit);
/* 34:   */   }
/* 35:   */   
/* 36:   */   public void put(E e)
/* 37:   */     throws InterruptedException
/* 38:   */   {
/* 39:64 */     delegate().put(e);
/* 40:   */   }
/* 41:   */   
/* 42:   */   public int remainingCapacity()
/* 43:   */   {
/* 44:68 */     return delegate().remainingCapacity();
/* 45:   */   }
/* 46:   */   
/* 47:   */   public E take()
/* 48:   */     throws InterruptedException
/* 49:   */   {
/* 50:72 */     return delegate().take();
/* 51:   */   }
/* 52:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ForwardingBlockingQueue
 * JD-Core Version:    0.7.0.1
 */