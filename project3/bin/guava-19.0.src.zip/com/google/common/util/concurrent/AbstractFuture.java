/*    1:     */ package com.google.common.util.concurrent;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.base.Preconditions;
/*    6:     */ import com.google.common.base.Throwables;
/*    7:     */ import java.lang.reflect.Field;
/*    8:     */ import java.security.AccessController;
/*    9:     */ import java.security.PrivilegedActionException;
/*   10:     */ import java.security.PrivilegedExceptionAction;
/*   11:     */ import java.util.concurrent.CancellationException;
/*   12:     */ import java.util.concurrent.ExecutionException;
/*   13:     */ import java.util.concurrent.Executor;
/*   14:     */ import java.util.concurrent.Future;
/*   15:     */ import java.util.concurrent.TimeUnit;
/*   16:     */ import java.util.concurrent.TimeoutException;
/*   17:     */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*   18:     */ import java.util.concurrent.locks.LockSupport;
/*   19:     */ import java.util.logging.Level;
/*   20:     */ import java.util.logging.Logger;
/*   21:     */ import javax.annotation.Nullable;
/*   22:     */ import sun.misc.Unsafe;
/*   23:     */ 
/*   24:     */ @GwtCompatible(emulated=true)
/*   25:     */ public abstract class AbstractFuture<V>
/*   26:     */   implements ListenableFuture<V>
/*   27:     */ {
/*   28:  64 */   private static final boolean GENERATE_CANCELLATION_CAUSES = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));
/*   29:     */   
/*   30:     */   static abstract class TrustedFuture<V>
/*   31:     */     extends AbstractFuture<V>
/*   32:     */   {
/*   33:     */     public final V get()
/*   34:     */       throws InterruptedException, ExecutionException
/*   35:     */     {
/*   36:  79 */       return super.get();
/*   37:     */     }
/*   38:     */     
/*   39:     */     public final V get(long timeout, TimeUnit unit)
/*   40:     */       throws InterruptedException, ExecutionException, TimeoutException
/*   41:     */     {
/*   42:  84 */       return super.get(timeout, unit);
/*   43:     */     }
/*   44:     */     
/*   45:     */     public final boolean isDone()
/*   46:     */     {
/*   47:  88 */       return super.isDone();
/*   48:     */     }
/*   49:     */     
/*   50:     */     public final boolean isCancelled()
/*   51:     */     {
/*   52:  92 */       return super.isCancelled();
/*   53:     */     }
/*   54:     */     
/*   55:     */     public final void addListener(Runnable listener, Executor executor)
/*   56:     */     {
/*   57:  96 */       super.addListener(listener, executor);
/*   58:     */     }
/*   59:     */   }
/*   60:     */   
/*   61: 101 */   private static final Logger log = Logger.getLogger(AbstractFuture.class.getName());
/*   62:     */   private static final long SPIN_THRESHOLD_NANOS = 1000L;
/*   63:     */   private static final AtomicHelper ATOMIC_HELPER;
/*   64:     */   
/*   65:     */   static
/*   66:     */   {
/*   67:     */     AtomicHelper helper;
/*   68:     */     try
/*   69:     */     {
/*   70: 113 */       helper = new UnsafeAtomicHelper(null);
/*   71:     */     }
/*   72:     */     catch (Throwable unsafeFailure)
/*   73:     */     {
/*   74:     */       try
/*   75:     */       {
/*   76: 119 */         helper = new SafeAtomicHelper(AtomicReferenceFieldUpdater.newUpdater(Waiter.class, Thread.class, "thread"), AtomicReferenceFieldUpdater.newUpdater(Waiter.class, Waiter.class, "next"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, Waiter.class, "waiters"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, Listener.class, "listeners"), AtomicReferenceFieldUpdater.newUpdater(AbstractFuture.class, Object.class, "value"));
/*   77:     */       }
/*   78:     */       catch (Throwable atomicReferenceFieldUpdaterFailure)
/*   79:     */       {
/*   80: 130 */         log.log(Level.SEVERE, "UnsafeAtomicHelper is broken!", unsafeFailure);
/*   81: 131 */         log.log(Level.SEVERE, "SafeAtomicHelper is broken!", atomicReferenceFieldUpdaterFailure);
/*   82: 132 */         helper = new SynchronizedHelper(null);
/*   83:     */       }
/*   84:     */     }
/*   85: 135 */     ATOMIC_HELPER = helper;
/*   86:     */     
/*   87:     */ 
/*   88:     */ 
/*   89:     */ 
/*   90: 140 */     Class<?> ensureLoaded = LockSupport.class;
/*   91:     */   }
/*   92:     */   
/*   93:     */   private static final class Waiter
/*   94:     */   {
/*   95: 147 */     static final Waiter TOMBSTONE = new Waiter(false);
/*   96:     */     @Nullable
/*   97:     */     volatile Thread thread;
/*   98:     */     @Nullable
/*   99:     */     volatile Waiter next;
/*  100:     */     
/*  101:     */     Waiter(boolean unused) {}
/*  102:     */     
/*  103:     */     Waiter()
/*  104:     */     {
/*  105: 158 */       AbstractFuture.ATOMIC_HELPER.putThread(this, Thread.currentThread());
/*  106:     */     }
/*  107:     */     
/*  108:     */     void setNext(Waiter next)
/*  109:     */     {
/*  110: 164 */       AbstractFuture.ATOMIC_HELPER.putNext(this, next);
/*  111:     */     }
/*  112:     */     
/*  113:     */     void unpark()
/*  114:     */     {
/*  115: 171 */       Thread w = this.thread;
/*  116: 172 */       if (w != null)
/*  117:     */       {
/*  118: 173 */         this.thread = null;
/*  119: 174 */         LockSupport.unpark(w);
/*  120:     */       }
/*  121:     */     }
/*  122:     */   }
/*  123:     */   
/*  124:     */   private void removeWaiter(Waiter node)
/*  125:     */   {
/*  126: 190 */     node.thread = null;
/*  127:     */     
/*  128: 192 */     Waiter pred = null;
/*  129: 193 */     Waiter curr = this.waiters;
/*  130: 194 */     if (curr == Waiter.TOMBSTONE) {
/*  131:     */       return;
/*  132:     */     }
/*  133:     */     for (;;)
/*  134:     */     {
/*  135: 198 */       if (curr == null) {
/*  136:     */         return;
/*  137:     */       }
/*  138: 199 */       Waiter succ = curr.next;
/*  139: 200 */       if (curr.thread != null)
/*  140:     */       {
/*  141: 201 */         pred = curr;
/*  142:     */       }
/*  143:     */       else
/*  144:     */       {
/*  145: 202 */         if (pred != null)
/*  146:     */         {
/*  147: 203 */           pred.next = succ;
/*  148: 204 */           if (pred.thread != null) {
/*  149:     */             break label78;
/*  150:     */           }
/*  151: 205 */           break;
/*  152:     */         }
/*  153: 207 */         if (!ATOMIC_HELPER.casWaiters(this, curr, succ)) {
/*  154:     */           break;
/*  155:     */         }
/*  156:     */       }
/*  157:     */       label78:
/*  158: 210 */       curr = succ;
/*  159:     */     }
/*  160:     */   }
/*  161:     */   
/*  162:     */   private static final class Listener
/*  163:     */   {
/*  164: 218 */     static final Listener TOMBSTONE = new Listener(null, null);
/*  165:     */     final Runnable task;
/*  166:     */     final Executor executor;
/*  167:     */     @Nullable
/*  168:     */     Listener next;
/*  169:     */     
/*  170:     */     Listener(Runnable task, Executor executor)
/*  171:     */     {
/*  172: 226 */       this.task = task;
/*  173: 227 */       this.executor = executor;
/*  174:     */     }
/*  175:     */   }
/*  176:     */   
/*  177: 232 */   private static final Object NULL = new Object();
/*  178:     */   private volatile Object value;
/*  179:     */   private volatile Listener listeners;
/*  180:     */   private volatile Waiter waiters;
/*  181:     */   
/*  182:     */   private static final class Failure
/*  183:     */   {
/*  184: 236 */     static final Failure FALLBACK_INSTANCE = new Failure(new Throwable("Failure occurred while trying to finish a future.")
/*  185:     */     {
/*  186:     */       public synchronized Throwable fillInStackTrace()
/*  187:     */       {
/*  188: 239 */         return this;
/*  189:     */       }
/*  190: 236 */     });
/*  191:     */     final Throwable exception;
/*  192:     */     
/*  193:     */     Failure(Throwable exception)
/*  194:     */     {
/*  195: 245 */       this.exception = ((Throwable)Preconditions.checkNotNull(exception));
/*  196:     */     }
/*  197:     */   }
/*  198:     */   
/*  199:     */   private static final class Cancellation
/*  200:     */   {
/*  201:     */     final boolean wasInterrupted;
/*  202:     */     @Nullable
/*  203:     */     final Throwable cause;
/*  204:     */     
/*  205:     */     Cancellation(boolean wasInterrupted, @Nullable Throwable cause)
/*  206:     */     {
/*  207: 255 */       this.wasInterrupted = wasInterrupted;
/*  208: 256 */       this.cause = cause;
/*  209:     */     }
/*  210:     */   }
/*  211:     */   
/*  212:     */   private final class SetFuture
/*  213:     */     implements Runnable
/*  214:     */   {
/*  215:     */     final ListenableFuture<? extends V> future;
/*  216:     */     
/*  217:     */     SetFuture()
/*  218:     */     {
/*  219: 265 */       this.future = future;
/*  220:     */     }
/*  221:     */     
/*  222:     */     public void run()
/*  223:     */     {
/*  224: 269 */       if (AbstractFuture.this.value != this) {
/*  225: 271 */         return;
/*  226:     */       }
/*  227: 273 */       AbstractFuture.this.completeWithFuture(this.future, this);
/*  228:     */     }
/*  229:     */   }
/*  230:     */   
/*  231:     */   public V get(long timeout, TimeUnit unit)
/*  232:     */     throws InterruptedException, TimeoutException, ExecutionException
/*  233:     */   {
/*  234: 351 */     long remainingNanos = unit.toNanos(timeout);
/*  235: 352 */     if (Thread.interrupted()) {
/*  236: 353 */       throw new InterruptedException();
/*  237:     */     }
/*  238: 355 */     Object localValue = this.value;
/*  239: 356 */     if (((localValue != null ? 1 : 0) & (!(localValue instanceof SetFuture) ? 1 : 0)) != 0) {
/*  240: 357 */       return getDoneValue(localValue);
/*  241:     */     }
/*  242: 360 */     long endNanos = remainingNanos > 0L ? System.nanoTime() + remainingNanos : 0L;
/*  243: 361 */     if (remainingNanos >= 1000L)
/*  244:     */     {
/*  245: 362 */       Waiter oldHead = this.waiters;
/*  246: 363 */       if (oldHead != Waiter.TOMBSTONE)
/*  247:     */       {
/*  248: 364 */         Waiter node = new Waiter();
/*  249:     */         do
/*  250:     */         {
/*  251: 366 */           node.setNext(oldHead);
/*  252: 367 */           if (ATOMIC_HELPER.casWaiters(this, oldHead, node))
/*  253:     */           {
/*  254:     */             do
/*  255:     */             {
/*  256: 369 */               LockSupport.parkNanos(this, remainingNanos);
/*  257: 371 */               if (Thread.interrupted())
/*  258:     */               {
/*  259: 372 */                 removeWaiter(node);
/*  260: 373 */                 throw new InterruptedException();
/*  261:     */               }
/*  262: 378 */               localValue = this.value;
/*  263: 379 */               if (((localValue != null ? 1 : 0) & (!(localValue instanceof SetFuture) ? 1 : 0)) != 0) {
/*  264: 380 */                 return getDoneValue(localValue);
/*  265:     */               }
/*  266: 384 */               remainingNanos = endNanos - System.nanoTime();
/*  267: 385 */             } while (remainingNanos >= 1000L);
/*  268: 387 */             removeWaiter(node);
/*  269: 388 */             break;
/*  270:     */           }
/*  271: 392 */           oldHead = this.waiters;
/*  272: 393 */         } while (oldHead != Waiter.TOMBSTONE);
/*  273:     */       }
/*  274: 397 */       return getDoneValue(this.value);
/*  275:     */     }
/*  276: 401 */     while (remainingNanos > 0L)
/*  277:     */     {
/*  278: 402 */       localValue = this.value;
/*  279: 403 */       if (((localValue != null ? 1 : 0) & (!(localValue instanceof SetFuture) ? 1 : 0)) != 0) {
/*  280: 404 */         return getDoneValue(localValue);
/*  281:     */       }
/*  282: 406 */       if (Thread.interrupted()) {
/*  283: 407 */         throw new InterruptedException();
/*  284:     */       }
/*  285: 409 */       remainingNanos = endNanos - System.nanoTime();
/*  286:     */     }
/*  287: 411 */     throw new TimeoutException();
/*  288:     */   }
/*  289:     */   
/*  290:     */   public V get()
/*  291:     */     throws InterruptedException, ExecutionException
/*  292:     */   {
/*  293: 430 */     if (Thread.interrupted()) {
/*  294: 431 */       throw new InterruptedException();
/*  295:     */     }
/*  296: 433 */     Object localValue = this.value;
/*  297: 434 */     if (((localValue != null ? 1 : 0) & (!(localValue instanceof SetFuture) ? 1 : 0)) != 0) {
/*  298: 435 */       return getDoneValue(localValue);
/*  299:     */     }
/*  300: 437 */     Waiter oldHead = this.waiters;
/*  301: 438 */     if (oldHead != Waiter.TOMBSTONE)
/*  302:     */     {
/*  303: 439 */       Waiter node = new Waiter();
/*  304:     */       do
/*  305:     */       {
/*  306: 441 */         node.setNext(oldHead);
/*  307: 442 */         if (ATOMIC_HELPER.casWaiters(this, oldHead, node))
/*  308:     */         {
/*  309:     */           do
/*  310:     */           {
/*  311: 445 */             LockSupport.park(this);
/*  312: 447 */             if (Thread.interrupted())
/*  313:     */             {
/*  314: 448 */               removeWaiter(node);
/*  315: 449 */               throw new InterruptedException();
/*  316:     */             }
/*  317: 453 */             localValue = this.value;
/*  318: 454 */           } while (((localValue != null ? 1 : 0) & (!(localValue instanceof SetFuture) ? 1 : 0)) == 0);
/*  319: 455 */           return getDoneValue(localValue);
/*  320:     */         }
/*  321: 459 */         oldHead = this.waiters;
/*  322: 460 */       } while (oldHead != Waiter.TOMBSTONE);
/*  323:     */     }
/*  324: 464 */     return getDoneValue(this.value);
/*  325:     */   }
/*  326:     */   
/*  327:     */   private V getDoneValue(Object obj)
/*  328:     */     throws ExecutionException
/*  329:     */   {
/*  330: 473 */     if ((obj instanceof Cancellation)) {
/*  331: 474 */       throw cancellationExceptionWithCause("Task was cancelled.", ((Cancellation)obj).cause);
/*  332:     */     }
/*  333: 475 */     if ((obj instanceof Failure)) {
/*  334: 476 */       throw new ExecutionException(((Failure)obj).exception);
/*  335:     */     }
/*  336: 477 */     if (obj == NULL) {
/*  337: 478 */       return null;
/*  338:     */     }
/*  339: 481 */     V asV = obj;
/*  340: 482 */     return asV;
/*  341:     */   }
/*  342:     */   
/*  343:     */   public boolean isDone()
/*  344:     */   {
/*  345: 488 */     Object localValue = this.value;
/*  346: 489 */     return (localValue != null ? 1 : 0) & (!(localValue instanceof SetFuture) ? 1 : 0);
/*  347:     */   }
/*  348:     */   
/*  349:     */   public boolean isCancelled()
/*  350:     */   {
/*  351: 494 */     Object localValue = this.value;
/*  352: 495 */     return localValue instanceof Cancellation;
/*  353:     */   }
/*  354:     */   
/*  355:     */   public boolean cancel(boolean mayInterruptIfRunning)
/*  356:     */   {
/*  357: 507 */     Object localValue = this.value;
/*  358: 508 */     if ((localValue == null | localValue instanceof SetFuture))
/*  359:     */     {
/*  360: 513 */       Throwable cause = GENERATE_CANCELLATION_CAUSES ? newCancellationCause() : null;
/*  361: 514 */       Object valueToSet = new Cancellation(mayInterruptIfRunning, cause);
/*  362:     */       do
/*  363:     */       {
/*  364: 516 */         if (ATOMIC_HELPER.casValue(this, localValue, valueToSet))
/*  365:     */         {
/*  366: 519 */           if (mayInterruptIfRunning) {
/*  367: 520 */             interruptTask();
/*  368:     */           }
/*  369: 522 */           complete();
/*  370: 523 */           if ((localValue instanceof SetFuture)) {
/*  371: 526 */             ((SetFuture)localValue).future.cancel(mayInterruptIfRunning);
/*  372:     */           }
/*  373: 528 */           return true;
/*  374:     */         }
/*  375: 531 */         localValue = this.value;
/*  376: 534 */       } while ((localValue instanceof SetFuture));
/*  377:     */     }
/*  378: 536 */     return false;
/*  379:     */   }
/*  380:     */   
/*  381:     */   private Throwable newCancellationCause()
/*  382:     */   {
/*  383: 547 */     return new CancellationException("Future.cancel() was called.");
/*  384:     */   }
/*  385:     */   
/*  386:     */   protected final boolean wasInterrupted()
/*  387:     */   {
/*  388: 569 */     Object localValue = this.value;
/*  389: 570 */     return ((localValue instanceof Cancellation)) && (((Cancellation)localValue).wasInterrupted);
/*  390:     */   }
/*  391:     */   
/*  392:     */   public void addListener(Runnable listener, Executor executor)
/*  393:     */   {
/*  394: 580 */     Preconditions.checkNotNull(listener, "Runnable was null.");
/*  395: 581 */     Preconditions.checkNotNull(executor, "Executor was null.");
/*  396: 582 */     Listener oldHead = this.listeners;
/*  397: 583 */     if (oldHead != Listener.TOMBSTONE)
/*  398:     */     {
/*  399: 584 */       Listener newNode = new Listener(listener, executor);
/*  400:     */       do
/*  401:     */       {
/*  402: 586 */         newNode.next = oldHead;
/*  403: 587 */         if (ATOMIC_HELPER.casListeners(this, oldHead, newNode)) {
/*  404: 588 */           return;
/*  405:     */         }
/*  406: 590 */         oldHead = this.listeners;
/*  407: 591 */       } while (oldHead != Listener.TOMBSTONE);
/*  408:     */     }
/*  409: 595 */     executeListener(listener, executor);
/*  410:     */   }
/*  411:     */   
/*  412:     */   protected boolean set(@Nullable V value)
/*  413:     */   {
/*  414: 611 */     Object valueToSet = value == null ? NULL : value;
/*  415: 612 */     if (ATOMIC_HELPER.casValue(this, null, valueToSet))
/*  416:     */     {
/*  417: 613 */       complete();
/*  418: 614 */       return true;
/*  419:     */     }
/*  420: 616 */     return false;
/*  421:     */   }
/*  422:     */   
/*  423:     */   protected boolean setException(Throwable throwable)
/*  424:     */   {
/*  425: 632 */     Object valueToSet = new Failure((Throwable)Preconditions.checkNotNull(throwable));
/*  426: 633 */     if (ATOMIC_HELPER.casValue(this, null, valueToSet))
/*  427:     */     {
/*  428: 634 */       complete();
/*  429: 635 */       return true;
/*  430:     */     }
/*  431: 637 */     return false;
/*  432:     */   }
/*  433:     */   
/*  434:     */   @Beta
/*  435:     */   protected boolean setFuture(ListenableFuture<? extends V> future)
/*  436:     */   {
/*  437: 662 */     Preconditions.checkNotNull(future);
/*  438: 663 */     Object localValue = this.value;
/*  439: 664 */     if (localValue == null)
/*  440:     */     {
/*  441: 665 */       if (future.isDone()) {
/*  442: 666 */         return completeWithFuture(future, null);
/*  443:     */       }
/*  444: 668 */       AbstractFuture<V>.SetFuture valueToSet = new SetFuture(future);
/*  445: 669 */       if (ATOMIC_HELPER.casValue(this, null, valueToSet))
/*  446:     */       {
/*  447:     */         try
/*  448:     */         {
/*  449: 673 */           future.addListener(valueToSet, MoreExecutors.directExecutor());
/*  450:     */         }
/*  451:     */         catch (Throwable t)
/*  452:     */         {
/*  453:     */           Failure failure;
/*  454:     */           try
/*  455:     */           {
/*  456: 680 */             failure = new Failure(t);
/*  457:     */           }
/*  458:     */           catch (Throwable oomMostLikely)
/*  459:     */           {
/*  460: 682 */             failure = Failure.FALLBACK_INSTANCE;
/*  461:     */           }
/*  462: 685 */           ATOMIC_HELPER.casValue(this, valueToSet, failure);
/*  463:     */         }
/*  464: 687 */         return true;
/*  465:     */       }
/*  466: 689 */       localValue = this.value;
/*  467:     */     }
/*  468: 693 */     if ((localValue instanceof Cancellation)) {
/*  469: 695 */       future.cancel(((Cancellation)localValue).wasInterrupted);
/*  470:     */     }
/*  471: 697 */     return false;
/*  472:     */   }
/*  473:     */   
/*  474:     */   private boolean completeWithFuture(ListenableFuture<? extends V> future, Object expected)
/*  475:     */   {
/*  476:     */     Object valueToSet;
/*  477:     */     Object valueToSet;
/*  478: 708 */     if ((future instanceof TrustedFuture)) {
/*  479: 713 */       valueToSet = ((AbstractFuture)future).value;
/*  480:     */     } else {
/*  481:     */       try
/*  482:     */       {
/*  483: 717 */         V v = Uninterruptibles.getUninterruptibly(future);
/*  484: 718 */         valueToSet = v == null ? NULL : v;
/*  485:     */       }
/*  486:     */       catch (ExecutionException exception)
/*  487:     */       {
/*  488: 720 */         valueToSet = new Failure(exception.getCause());
/*  489:     */       }
/*  490:     */       catch (CancellationException cancellation)
/*  491:     */       {
/*  492: 722 */         valueToSet = new Cancellation(false, cancellation);
/*  493:     */       }
/*  494:     */       catch (Throwable t)
/*  495:     */       {
/*  496: 724 */         valueToSet = new Failure(t);
/*  497:     */       }
/*  498:     */     }
/*  499: 729 */     if (ATOMIC_HELPER.casValue(this, expected, valueToSet))
/*  500:     */     {
/*  501: 730 */       complete();
/*  502: 731 */       return true;
/*  503:     */     }
/*  504: 733 */     return false;
/*  505:     */   }
/*  506:     */   
/*  507:     */   private void complete()
/*  508:     */   {
/*  509: 738 */     for (Waiter currentWaiter = clearWaiters(); currentWaiter != null; currentWaiter = currentWaiter.next) {
/*  510: 741 */       currentWaiter.unpark();
/*  511:     */     }
/*  512: 744 */     Listener currentListener = clearListeners();
/*  513: 745 */     Listener reversedList = null;
/*  514: 746 */     while (currentListener != null)
/*  515:     */     {
/*  516: 747 */       Listener tmp = currentListener;
/*  517: 748 */       currentListener = currentListener.next;
/*  518: 749 */       tmp.next = reversedList;
/*  519: 750 */       reversedList = tmp;
/*  520:     */     }
/*  521: 752 */     for (; reversedList != null; reversedList = reversedList.next) {
/*  522: 753 */       executeListener(reversedList.task, reversedList.executor);
/*  523:     */     }
/*  524: 760 */     done();
/*  525:     */   }
/*  526:     */   
/*  527:     */   final Throwable trustedGetException()
/*  528:     */   {
/*  529: 777 */     return ((Failure)this.value).exception;
/*  530:     */   }
/*  531:     */   
/*  532:     */   final void maybePropagateCancellation(@Nullable Future<?> related)
/*  533:     */   {
/*  534: 788 */     if ((related != null & isCancelled())) {
/*  535: 789 */       related.cancel(wasInterrupted());
/*  536:     */     }
/*  537:     */   }
/*  538:     */   
/*  539:     */   private Waiter clearWaiters()
/*  540:     */   {
/*  541:     */     Waiter head;
/*  542:     */     do
/*  543:     */     {
/*  544: 797 */       head = this.waiters;
/*  545: 798 */     } while (!ATOMIC_HELPER.casWaiters(this, head, Waiter.TOMBSTONE));
/*  546: 799 */     return head;
/*  547:     */   }
/*  548:     */   
/*  549:     */   private Listener clearListeners()
/*  550:     */   {
/*  551:     */     Listener head;
/*  552:     */     do
/*  553:     */     {
/*  554: 806 */       head = this.listeners;
/*  555: 807 */     } while (!ATOMIC_HELPER.casListeners(this, head, Listener.TOMBSTONE));
/*  556: 808 */     return head;
/*  557:     */   }
/*  558:     */   
/*  559:     */   private static void executeListener(Runnable runnable, Executor executor)
/*  560:     */   {
/*  561:     */     try
/*  562:     */     {
/*  563: 817 */       executor.execute(runnable);
/*  564:     */     }
/*  565:     */     catch (RuntimeException e)
/*  566:     */     {
/*  567: 822 */       log.log(Level.SEVERE, "RuntimeException while executing runnable " + runnable + " with executor " + executor, e);
/*  568:     */     }
/*  569:     */   }
/*  570:     */   
/*  571:     */   static final CancellationException cancellationExceptionWithCause(@Nullable String message, @Nullable Throwable cause)
/*  572:     */   {
/*  573: 829 */     CancellationException exception = new CancellationException(message);
/*  574: 830 */     exception.initCause(cause);
/*  575: 831 */     return exception;
/*  576:     */   }
/*  577:     */   
/*  578:     */   protected void interruptTask() {}
/*  579:     */   
/*  580:     */   void done() {}
/*  581:     */   
/*  582:     */   private static abstract class AtomicHelper
/*  583:     */   {
/*  584:     */     abstract void putThread(AbstractFuture.Waiter paramWaiter, Thread paramThread);
/*  585:     */     
/*  586:     */     abstract void putNext(AbstractFuture.Waiter paramWaiter1, AbstractFuture.Waiter paramWaiter2);
/*  587:     */     
/*  588:     */     abstract boolean casWaiters(AbstractFuture<?> paramAbstractFuture, AbstractFuture.Waiter paramWaiter1, AbstractFuture.Waiter paramWaiter2);
/*  589:     */     
/*  590:     */     abstract boolean casListeners(AbstractFuture<?> paramAbstractFuture, AbstractFuture.Listener paramListener1, AbstractFuture.Listener paramListener2);
/*  591:     */     
/*  592:     */     abstract boolean casValue(AbstractFuture<?> paramAbstractFuture, Object paramObject1, Object paramObject2);
/*  593:     */   }
/*  594:     */   
/*  595:     */   private static final class UnsafeAtomicHelper
/*  596:     */     extends AbstractFuture.AtomicHelper
/*  597:     */   {
/*  598:     */     static final Unsafe UNSAFE;
/*  599:     */     static final long LISTENERS_OFFSET;
/*  600:     */     static final long WAITERS_OFFSET;
/*  601:     */     static final long VALUE_OFFSET;
/*  602:     */     static final long WAITER_THREAD_OFFSET;
/*  603:     */     static final long WAITER_NEXT_OFFSET;
/*  604:     */     
/*  605:     */     private UnsafeAtomicHelper()
/*  606:     */     {
/*  607: 857 */       super();
/*  608:     */     }
/*  609:     */     
/*  610:     */     static
/*  611:     */     {
/*  612: 866 */       Unsafe unsafe = null;
/*  613:     */       try
/*  614:     */       {
/*  615: 868 */         unsafe = Unsafe.getUnsafe();
/*  616:     */       }
/*  617:     */       catch (SecurityException tryReflectionInstead)
/*  618:     */       {
/*  619:     */         try
/*  620:     */         {
/*  621: 871 */           unsafe = (Unsafe)AccessController.doPrivileged(new PrivilegedExceptionAction()
/*  622:     */           {
/*  623:     */             public Unsafe run()
/*  624:     */               throws Exception
/*  625:     */             {
/*  626: 874 */               Class<Unsafe> k = Unsafe.class;
/*  627: 875 */               for (Field f : k.getDeclaredFields())
/*  628:     */               {
/*  629: 876 */                 f.setAccessible(true);
/*  630: 877 */                 Object x = f.get(null);
/*  631: 878 */                 if (k.isInstance(x)) {
/*  632: 879 */                   return (Unsafe)k.cast(x);
/*  633:     */                 }
/*  634:     */               }
/*  635: 882 */               throw new NoSuchFieldError("the Unsafe");
/*  636:     */             }
/*  637:     */           });
/*  638:     */         }
/*  639:     */         catch (PrivilegedActionException e)
/*  640:     */         {
/*  641: 886 */           throw new RuntimeException("Could not initialize intrinsics", e.getCause());
/*  642:     */         }
/*  643:     */       }
/*  644:     */       try
/*  645:     */       {
/*  646: 890 */         Class<?> abstractFuture = AbstractFuture.class;
/*  647: 891 */         WAITERS_OFFSET = unsafe.objectFieldOffset(abstractFuture.getDeclaredField("waiters"));
/*  648: 892 */         LISTENERS_OFFSET = unsafe.objectFieldOffset(abstractFuture.getDeclaredField("listeners"));
/*  649: 893 */         VALUE_OFFSET = unsafe.objectFieldOffset(abstractFuture.getDeclaredField("value"));
/*  650: 894 */         WAITER_THREAD_OFFSET = unsafe.objectFieldOffset(AbstractFuture.Waiter.class.getDeclaredField("thread"));
/*  651: 895 */         WAITER_NEXT_OFFSET = unsafe.objectFieldOffset(AbstractFuture.Waiter.class.getDeclaredField("next"));
/*  652: 896 */         UNSAFE = unsafe;
/*  653:     */       }
/*  654:     */       catch (Exception e)
/*  655:     */       {
/*  656: 898 */         throw Throwables.propagate(e);
/*  657:     */       }
/*  658:     */     }
/*  659:     */     
/*  660:     */     void putThread(AbstractFuture.Waiter waiter, Thread newValue)
/*  661:     */     {
/*  662: 904 */       UNSAFE.putObject(waiter, WAITER_THREAD_OFFSET, newValue);
/*  663:     */     }
/*  664:     */     
/*  665:     */     void putNext(AbstractFuture.Waiter waiter, AbstractFuture.Waiter newValue)
/*  666:     */     {
/*  667: 909 */       UNSAFE.putObject(waiter, WAITER_NEXT_OFFSET, newValue);
/*  668:     */     }
/*  669:     */     
/*  670:     */     boolean casWaiters(AbstractFuture<?> future, AbstractFuture.Waiter expect, AbstractFuture.Waiter update)
/*  671:     */     {
/*  672: 915 */       return UNSAFE.compareAndSwapObject(future, WAITERS_OFFSET, expect, update);
/*  673:     */     }
/*  674:     */     
/*  675:     */     boolean casListeners(AbstractFuture<?> future, AbstractFuture.Listener expect, AbstractFuture.Listener update)
/*  676:     */     {
/*  677: 921 */       return UNSAFE.compareAndSwapObject(future, LISTENERS_OFFSET, expect, update);
/*  678:     */     }
/*  679:     */     
/*  680:     */     boolean casValue(AbstractFuture<?> future, Object expect, Object update)
/*  681:     */     {
/*  682: 927 */       return UNSAFE.compareAndSwapObject(future, VALUE_OFFSET, expect, update);
/*  683:     */     }
/*  684:     */   }
/*  685:     */   
/*  686:     */   private static final class SafeAtomicHelper
/*  687:     */     extends AbstractFuture.AtomicHelper
/*  688:     */   {
/*  689:     */     final AtomicReferenceFieldUpdater<AbstractFuture.Waiter, Thread> waiterThreadUpdater;
/*  690:     */     final AtomicReferenceFieldUpdater<AbstractFuture.Waiter, AbstractFuture.Waiter> waiterNextUpdater;
/*  691:     */     final AtomicReferenceFieldUpdater<AbstractFuture, AbstractFuture.Waiter> waitersUpdater;
/*  692:     */     final AtomicReferenceFieldUpdater<AbstractFuture, AbstractFuture.Listener> listenersUpdater;
/*  693:     */     final AtomicReferenceFieldUpdater<AbstractFuture, Object> valueUpdater;
/*  694:     */     
/*  695:     */     SafeAtomicHelper(AtomicReferenceFieldUpdater<AbstractFuture.Waiter, Thread> waiterThreadUpdater, AtomicReferenceFieldUpdater<AbstractFuture.Waiter, AbstractFuture.Waiter> waiterNextUpdater, AtomicReferenceFieldUpdater<AbstractFuture, AbstractFuture.Waiter> waitersUpdater, AtomicReferenceFieldUpdater<AbstractFuture, AbstractFuture.Listener> listenersUpdater, AtomicReferenceFieldUpdater<AbstractFuture, Object> valueUpdater)
/*  696:     */     {
/*  697: 944 */       super();
/*  698: 945 */       this.waiterThreadUpdater = waiterThreadUpdater;
/*  699: 946 */       this.waiterNextUpdater = waiterNextUpdater;
/*  700: 947 */       this.waitersUpdater = waitersUpdater;
/*  701: 948 */       this.listenersUpdater = listenersUpdater;
/*  702: 949 */       this.valueUpdater = valueUpdater;
/*  703:     */     }
/*  704:     */     
/*  705:     */     void putThread(AbstractFuture.Waiter waiter, Thread newValue)
/*  706:     */     {
/*  707: 954 */       this.waiterThreadUpdater.lazySet(waiter, newValue);
/*  708:     */     }
/*  709:     */     
/*  710:     */     void putNext(AbstractFuture.Waiter waiter, AbstractFuture.Waiter newValue)
/*  711:     */     {
/*  712: 959 */       this.waiterNextUpdater.lazySet(waiter, newValue);
/*  713:     */     }
/*  714:     */     
/*  715:     */     boolean casWaiters(AbstractFuture<?> future, AbstractFuture.Waiter expect, AbstractFuture.Waiter update)
/*  716:     */     {
/*  717: 964 */       return this.waitersUpdater.compareAndSet(future, expect, update);
/*  718:     */     }
/*  719:     */     
/*  720:     */     boolean casListeners(AbstractFuture<?> future, AbstractFuture.Listener expect, AbstractFuture.Listener update)
/*  721:     */     {
/*  722: 969 */       return this.listenersUpdater.compareAndSet(future, expect, update);
/*  723:     */     }
/*  724:     */     
/*  725:     */     boolean casValue(AbstractFuture<?> future, Object expect, Object update)
/*  726:     */     {
/*  727: 974 */       return this.valueUpdater.compareAndSet(future, expect, update);
/*  728:     */     }
/*  729:     */   }
/*  730:     */   
/*  731:     */   private static final class SynchronizedHelper
/*  732:     */     extends AbstractFuture.AtomicHelper
/*  733:     */   {
/*  734:     */     private SynchronizedHelper()
/*  735:     */     {
/*  736: 984 */       super();
/*  737:     */     }
/*  738:     */     
/*  739:     */     void putThread(AbstractFuture.Waiter waiter, Thread newValue)
/*  740:     */     {
/*  741: 987 */       waiter.thread = newValue;
/*  742:     */     }
/*  743:     */     
/*  744:     */     void putNext(AbstractFuture.Waiter waiter, AbstractFuture.Waiter newValue)
/*  745:     */     {
/*  746: 992 */       waiter.next = newValue;
/*  747:     */     }
/*  748:     */     
/*  749:     */     boolean casWaiters(AbstractFuture<?> future, AbstractFuture.Waiter expect, AbstractFuture.Waiter update)
/*  750:     */     {
/*  751: 997 */       synchronized (future)
/*  752:     */       {
/*  753: 998 */         if (future.waiters == expect)
/*  754:     */         {
/*  755: 999 */           future.waiters = update;
/*  756:1000 */           return true;
/*  757:     */         }
/*  758:1002 */         return false;
/*  759:     */       }
/*  760:     */     }
/*  761:     */     
/*  762:     */     boolean casListeners(AbstractFuture<?> future, AbstractFuture.Listener expect, AbstractFuture.Listener update)
/*  763:     */     {
/*  764:1008 */       synchronized (future)
/*  765:     */       {
/*  766:1009 */         if (future.listeners == expect)
/*  767:     */         {
/*  768:1010 */           future.listeners = update;
/*  769:1011 */           return true;
/*  770:     */         }
/*  771:1013 */         return false;
/*  772:     */       }
/*  773:     */     }
/*  774:     */     
/*  775:     */     boolean casValue(AbstractFuture<?> future, Object expect, Object update)
/*  776:     */     {
/*  777:1019 */       synchronized (future)
/*  778:     */       {
/*  779:1020 */         if (future.value == expect)
/*  780:     */         {
/*  781:1021 */           future.value = update;
/*  782:1022 */           return true;
/*  783:     */         }
/*  784:1024 */         return false;
/*  785:     */       }
/*  786:     */     }
/*  787:     */   }
/*  788:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractFuture
 * JD-Core Version:    0.7.0.1
 */