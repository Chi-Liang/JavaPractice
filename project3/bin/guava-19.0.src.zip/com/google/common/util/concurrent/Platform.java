/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import javax.annotation.Nullable;
/*  5:   */ 
/*  6:   */ @GwtCompatible(emulated=true)
/*  7:   */ final class Platform
/*  8:   */ {
/*  9:   */   static boolean isInstanceOfThrowableClass(@Nullable Throwable t, Class<? extends Throwable> expectedClass)
/* 10:   */   {
/* 11:30 */     return expectedClass.isInstance(t);
/* 12:   */   }
/* 13:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.Platform
 * JD-Core Version:    0.7.0.1
 */