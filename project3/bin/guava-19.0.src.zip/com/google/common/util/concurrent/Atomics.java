/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import java.util.concurrent.atomic.AtomicReference;
/*  4:   */ import java.util.concurrent.atomic.AtomicReferenceArray;
/*  5:   */ import javax.annotation.Nullable;
/*  6:   */ 
/*  7:   */ public final class Atomics
/*  8:   */ {
/*  9:   */   public static <V> AtomicReference<V> newReference()
/* 10:   */   {
/* 11:40 */     return new AtomicReference();
/* 12:   */   }
/* 13:   */   
/* 14:   */   public static <V> AtomicReference<V> newReference(@Nullable V initialValue)
/* 15:   */   {
/* 16:50 */     return new AtomicReference(initialValue);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public static <E> AtomicReferenceArray<E> newReferenceArray(int length)
/* 20:   */   {
/* 21:60 */     return new AtomicReferenceArray(length);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public static <E> AtomicReferenceArray<E> newReferenceArray(E[] array)
/* 25:   */   {
/* 26:71 */     return new AtomicReferenceArray(array);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.Atomics
 * JD-Core Version:    0.7.0.1
 */