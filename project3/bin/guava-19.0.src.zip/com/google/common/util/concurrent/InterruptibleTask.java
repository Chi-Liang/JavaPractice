/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*  5:   */ 
/*  6:   */ @GwtCompatible(emulated=true)
/*  7:   */ abstract class InterruptibleTask
/*  8:   */   implements Runnable
/*  9:   */ {
/* 10:27 */   private static final AtomicReferenceFieldUpdater<InterruptibleTask, Thread> RUNNER = AtomicReferenceFieldUpdater.newUpdater(InterruptibleTask.class, Thread.class, "runner");
/* 11:   */   private volatile Thread runner;
/* 12:   */   private volatile boolean doneInterrupting;
/* 13:   */   
/* 14:   */   public final void run()
/* 15:   */   {
/* 16:37 */     if (!RUNNER.compareAndSet(this, null, Thread.currentThread())) {
/* 17:38 */       return;
/* 18:   */     }
/* 19:   */     try
/* 20:   */     {
/* 21:41 */       runInterruptibly(); return;
/* 22:   */     }
/* 23:   */     finally
/* 24:   */     {
/* 25:43 */       if (wasInterrupted()) {
/* 26:50 */         while (!this.doneInterrupting) {
/* 27:51 */           Thread.yield();
/* 28:   */         }
/* 29:   */       }
/* 30:   */     }
/* 31:   */   }
/* 32:   */   
/* 33:   */   abstract void runInterruptibly();
/* 34:   */   
/* 35:   */   abstract boolean wasInterrupted();
/* 36:   */   
/* 37:   */   final void interruptTask()
/* 38:   */   {
/* 39:65 */     Thread currentRunner = this.runner;
/* 40:66 */     if (currentRunner != null) {
/* 41:67 */       currentRunner.interrupt();
/* 42:   */     }
/* 43:69 */     this.doneInterrupting = true;
/* 44:   */   }
/* 45:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.InterruptibleTask
 * JD-Core Version:    0.7.0.1
 */