/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import javax.annotation.Nullable;
/*  4:   */ 
/*  5:   */ public class UncheckedTimeoutException
/*  6:   */   extends RuntimeException
/*  7:   */ {
/*  8:   */   private static final long serialVersionUID = 0L;
/*  9:   */   
/* 10:   */   public UncheckedTimeoutException() {}
/* 11:   */   
/* 12:   */   public UncheckedTimeoutException(@Nullable String message)
/* 13:   */   {
/* 14:31 */     super(message);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public UncheckedTimeoutException(@Nullable Throwable cause)
/* 18:   */   {
/* 19:35 */     super(cause);
/* 20:   */   }
/* 21:   */   
/* 22:   */   public UncheckedTimeoutException(@Nullable String message, @Nullable Throwable cause)
/* 23:   */   {
/* 24:39 */     super(message, cause);
/* 25:   */   }
/* 26:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.UncheckedTimeoutException
 * JD-Core Version:    0.7.0.1
 */