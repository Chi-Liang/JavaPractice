/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.ArrayList;
/*   6:    */ import java.util.Collections;
/*   7:    */ import java.util.List;
/*   8:    */ import java.util.concurrent.Executor;
/*   9:    */ import java.util.concurrent.TimeUnit;
/*  10:    */ import java.util.concurrent.TimeoutException;
/*  11:    */ import javax.annotation.Nullable;
/*  12:    */ import javax.annotation.concurrent.GuardedBy;
/*  13:    */ import javax.annotation.concurrent.Immutable;
/*  14:    */ 
/*  15:    */ @Beta
/*  16:    */ public abstract class AbstractService
/*  17:    */   implements Service
/*  18:    */ {
/*  19: 58 */   private static final ListenerCallQueue.Callback<Service.Listener> STARTING_CALLBACK = new ListenerCallQueue.Callback("starting()")
/*  20:    */   {
/*  21:    */     void call(Service.Listener listener)
/*  22:    */     {
/*  23: 61 */       listener.starting();
/*  24:    */     }
/*  25:    */   };
/*  26: 64 */   private static final ListenerCallQueue.Callback<Service.Listener> RUNNING_CALLBACK = new ListenerCallQueue.Callback("running()")
/*  27:    */   {
/*  28:    */     void call(Service.Listener listener)
/*  29:    */     {
/*  30: 67 */       listener.running();
/*  31:    */     }
/*  32:    */   };
/*  33: 70 */   private static final ListenerCallQueue.Callback<Service.Listener> STOPPING_FROM_STARTING_CALLBACK = stoppingCallback(Service.State.STARTING);
/*  34: 72 */   private static final ListenerCallQueue.Callback<Service.Listener> STOPPING_FROM_RUNNING_CALLBACK = stoppingCallback(Service.State.RUNNING);
/*  35: 75 */   private static final ListenerCallQueue.Callback<Service.Listener> TERMINATED_FROM_NEW_CALLBACK = terminatedCallback(Service.State.NEW);
/*  36: 77 */   private static final ListenerCallQueue.Callback<Service.Listener> TERMINATED_FROM_RUNNING_CALLBACK = terminatedCallback(Service.State.RUNNING);
/*  37: 79 */   private static final ListenerCallQueue.Callback<Service.Listener> TERMINATED_FROM_STOPPING_CALLBACK = terminatedCallback(Service.State.STOPPING);
/*  38:    */   
/*  39:    */   private static ListenerCallQueue.Callback<Service.Listener> terminatedCallback(final Service.State from)
/*  40:    */   {
/*  41: 83 */     new ListenerCallQueue.Callback("terminated({from = " + from + "})")
/*  42:    */     {
/*  43:    */       void call(Service.Listener listener)
/*  44:    */       {
/*  45: 85 */         listener.terminated(from);
/*  46:    */       }
/*  47:    */     };
/*  48:    */   }
/*  49:    */   
/*  50:    */   private static ListenerCallQueue.Callback<Service.Listener> stoppingCallback(final Service.State from)
/*  51:    */   {
/*  52: 91 */     new ListenerCallQueue.Callback("stopping({from = " + from + "})")
/*  53:    */     {
/*  54:    */       void call(Service.Listener listener)
/*  55:    */       {
/*  56: 93 */         listener.stopping(from);
/*  57:    */       }
/*  58:    */     };
/*  59:    */   }
/*  60:    */   
/*  61: 98 */   private final Monitor monitor = new Monitor();
/*  62:100 */   private final Monitor.Guard isStartable = new IsStartableGuard();
/*  63:    */   protected abstract void doStart();
/*  64:    */   
/*  65:    */   protected abstract void doStop();
/*  66:    */   
/*  67:    */   private final class IsStartableGuard
/*  68:    */     extends Monitor.Guard
/*  69:    */   {
/*  70:    */     IsStartableGuard()
/*  71:    */     {
/*  72:105 */       super();
/*  73:    */     }
/*  74:    */     
/*  75:    */     public boolean isSatisfied()
/*  76:    */     {
/*  77:109 */       return AbstractService.this.state() == Service.State.NEW;
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:113 */   private final Monitor.Guard isStoppable = new IsStoppableGuard();
/*  82:    */   
/*  83:    */   private final class IsStoppableGuard
/*  84:    */     extends Monitor.Guard
/*  85:    */   {
/*  86:    */     IsStoppableGuard()
/*  87:    */     {
/*  88:118 */       super();
/*  89:    */     }
/*  90:    */     
/*  91:    */     public boolean isSatisfied()
/*  92:    */     {
/*  93:122 */       return AbstractService.this.state().compareTo(Service.State.RUNNING) <= 0;
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:126 */   private final Monitor.Guard hasReachedRunning = new HasReachedRunningGuard();
/*  98:    */   
/*  99:    */   private final class HasReachedRunningGuard
/* 100:    */     extends Monitor.Guard
/* 101:    */   {
/* 102:    */     HasReachedRunningGuard()
/* 103:    */     {
/* 104:131 */       super();
/* 105:    */     }
/* 106:    */     
/* 107:    */     public boolean isSatisfied()
/* 108:    */     {
/* 109:135 */       return AbstractService.this.state().compareTo(Service.State.RUNNING) >= 0;
/* 110:    */     }
/* 111:    */   }
/* 112:    */   
/* 113:139 */   private final Monitor.Guard isStopped = new IsStoppedGuard();
/* 114:    */   
/* 115:    */   private final class IsStoppedGuard
/* 116:    */     extends Monitor.Guard
/* 117:    */   {
/* 118:    */     IsStoppedGuard()
/* 119:    */     {
/* 120:144 */       super();
/* 121:    */     }
/* 122:    */     
/* 123:    */     public boolean isSatisfied()
/* 124:    */     {
/* 125:148 */       return AbstractService.this.state().isTerminal();
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   @GuardedBy("monitor")
/* 130:155 */   private final List<ListenerCallQueue<Service.Listener>> listeners = Collections.synchronizedList(new ArrayList());
/* 131:    */   @GuardedBy("monitor")
/* 132:168 */   private volatile StateSnapshot snapshot = new StateSnapshot(Service.State.NEW);
/* 133:    */   
/* 134:    */   public final Service startAsync()
/* 135:    */   {
/* 136:199 */     if (this.monitor.enterIf(this.isStartable)) {
/* 137:    */       try
/* 138:    */       {
/* 139:201 */         this.snapshot = new StateSnapshot(Service.State.STARTING);
/* 140:202 */         starting();
/* 141:203 */         doStart();
/* 142:    */       }
/* 143:    */       catch (Throwable startupFailure)
/* 144:    */       {
/* 145:205 */         notifyFailed(startupFailure);
/* 146:    */       }
/* 147:    */       finally
/* 148:    */       {
/* 149:207 */         this.monitor.leave();
/* 150:208 */         executeListeners();
/* 151:    */       }
/* 152:    */     } else {
/* 153:211 */       throw new IllegalStateException("Service " + this + " has already been started");
/* 154:    */     }
/* 155:213 */     return this;
/* 156:    */   }
/* 157:    */   
/* 158:    */   public final Service stopAsync()
/* 159:    */   {
/* 160:217 */     if (this.monitor.enterIf(this.isStoppable)) {
/* 161:    */       try
/* 162:    */       {
/* 163:219 */         Service.State previous = state();
/* 164:220 */         switch (6.$SwitchMap$com$google$common$util$concurrent$Service$State[previous.ordinal()])
/* 165:    */         {
/* 166:    */         case 1: 
/* 167:222 */           this.snapshot = new StateSnapshot(Service.State.TERMINATED);
/* 168:223 */           terminated(Service.State.NEW);
/* 169:224 */           break;
/* 170:    */         case 2: 
/* 171:226 */           this.snapshot = new StateSnapshot(Service.State.STARTING, true, null);
/* 172:227 */           stopping(Service.State.STARTING);
/* 173:228 */           break;
/* 174:    */         case 3: 
/* 175:230 */           this.snapshot = new StateSnapshot(Service.State.STOPPING);
/* 176:231 */           stopping(Service.State.RUNNING);
/* 177:232 */           doStop();
/* 178:233 */           break;
/* 179:    */         case 4: 
/* 180:    */         case 5: 
/* 181:    */         case 6: 
/* 182:238 */           throw new AssertionError("isStoppable is incorrectly implemented, saw: " + previous);
/* 183:    */         default: 
/* 184:240 */           throw new AssertionError("Unexpected state: " + previous);
/* 185:    */         }
/* 186:    */       }
/* 187:    */       catch (Throwable shutdownFailure)
/* 188:    */       {
/* 189:243 */         notifyFailed(shutdownFailure);
/* 190:    */       }
/* 191:    */       finally
/* 192:    */       {
/* 193:245 */         this.monitor.leave();
/* 194:246 */         executeListeners();
/* 195:    */       }
/* 196:    */     }
/* 197:249 */     return this;
/* 198:    */   }
/* 199:    */   
/* 200:    */   public final void awaitRunning()
/* 201:    */   {
/* 202:253 */     this.monitor.enterWhenUninterruptibly(this.hasReachedRunning);
/* 203:    */     try
/* 204:    */     {
/* 205:255 */       checkCurrentState(Service.State.RUNNING);
/* 206:    */     }
/* 207:    */     finally
/* 208:    */     {
/* 209:257 */       this.monitor.leave();
/* 210:    */     }
/* 211:    */   }
/* 212:    */   
/* 213:    */   public final void awaitRunning(long timeout, TimeUnit unit)
/* 214:    */     throws TimeoutException
/* 215:    */   {
/* 216:262 */     if (this.monitor.enterWhenUninterruptibly(this.hasReachedRunning, timeout, unit)) {
/* 217:    */       try
/* 218:    */       {
/* 219:264 */         checkCurrentState(Service.State.RUNNING);
/* 220:    */       }
/* 221:    */       finally
/* 222:    */       {
/* 223:266 */         this.monitor.leave();
/* 224:    */       }
/* 225:    */     } else {
/* 226:273 */       throw new TimeoutException("Timed out waiting for " + this + " to reach the RUNNING state.");
/* 227:    */     }
/* 228:    */   }
/* 229:    */   
/* 230:    */   public final void awaitTerminated()
/* 231:    */   {
/* 232:278 */     this.monitor.enterWhenUninterruptibly(this.isStopped);
/* 233:    */     try
/* 234:    */     {
/* 235:280 */       checkCurrentState(Service.State.TERMINATED);
/* 236:    */     }
/* 237:    */     finally
/* 238:    */     {
/* 239:282 */       this.monitor.leave();
/* 240:    */     }
/* 241:    */   }
/* 242:    */   
/* 243:    */   public final void awaitTerminated(long timeout, TimeUnit unit)
/* 244:    */     throws TimeoutException
/* 245:    */   {
/* 246:287 */     if (this.monitor.enterWhenUninterruptibly(this.isStopped, timeout, unit)) {
/* 247:    */       try
/* 248:    */       {
/* 249:289 */         checkCurrentState(Service.State.TERMINATED);
/* 250:    */       }
/* 251:    */       finally
/* 252:    */       {
/* 253:291 */         this.monitor.leave();
/* 254:    */       }
/* 255:    */     } else {
/* 256:298 */       throw new TimeoutException("Timed out waiting for " + this + " to reach a terminal state. " + "Current state: " + state());
/* 257:    */     }
/* 258:    */   }
/* 259:    */   
/* 260:    */   @GuardedBy("monitor")
/* 261:    */   private void checkCurrentState(Service.State expected)
/* 262:    */   {
/* 263:306 */     Service.State actual = state();
/* 264:307 */     if (actual != expected)
/* 265:    */     {
/* 266:308 */       if (actual == Service.State.FAILED) {
/* 267:310 */         throw new IllegalStateException("Expected the service to be " + expected + ", but the service has FAILED", failureCause());
/* 268:    */       }
/* 269:313 */       throw new IllegalStateException("Expected the service to be " + expected + ", but was " + actual);
/* 270:    */     }
/* 271:    */   }
/* 272:    */   
/* 273:    */   protected final void notifyStarted()
/* 274:    */   {
/* 275:325 */     this.monitor.enter();
/* 276:    */     try
/* 277:    */     {
/* 278:329 */       if (this.snapshot.state != Service.State.STARTING)
/* 279:    */       {
/* 280:330 */         IllegalStateException failure = new IllegalStateException("Cannot notifyStarted() when the service is " + this.snapshot.state);
/* 281:    */         
/* 282:332 */         notifyFailed(failure);
/* 283:333 */         throw failure;
/* 284:    */       }
/* 285:336 */       if (this.snapshot.shutdownWhenStartupFinishes)
/* 286:    */       {
/* 287:337 */         this.snapshot = new StateSnapshot(Service.State.STOPPING);
/* 288:    */         
/* 289:    */ 
/* 290:340 */         doStop();
/* 291:    */       }
/* 292:    */       else
/* 293:    */       {
/* 294:342 */         this.snapshot = new StateSnapshot(Service.State.RUNNING);
/* 295:343 */         running();
/* 296:    */       }
/* 297:    */     }
/* 298:    */     finally
/* 299:    */     {
/* 300:346 */       this.monitor.leave();
/* 301:347 */       executeListeners();
/* 302:    */     }
/* 303:    */   }
/* 304:    */   
/* 305:    */   protected final void notifyStopped()
/* 306:    */   {
/* 307:359 */     this.monitor.enter();
/* 308:    */     try
/* 309:    */     {
/* 310:363 */       Service.State previous = this.snapshot.state;
/* 311:364 */       if ((previous != Service.State.STOPPING) && (previous != Service.State.RUNNING))
/* 312:    */       {
/* 313:365 */         IllegalStateException failure = new IllegalStateException("Cannot notifyStopped() when the service is " + previous);
/* 314:    */         
/* 315:367 */         notifyFailed(failure);
/* 316:368 */         throw failure;
/* 317:    */       }
/* 318:370 */       this.snapshot = new StateSnapshot(Service.State.TERMINATED);
/* 319:371 */       terminated(previous);
/* 320:    */     }
/* 321:    */     finally
/* 322:    */     {
/* 323:373 */       this.monitor.leave();
/* 324:374 */       executeListeners();
/* 325:    */     }
/* 326:    */   }
/* 327:    */   
/* 328:    */   protected final void notifyFailed(Throwable cause)
/* 329:    */   {
/* 330:384 */     Preconditions.checkNotNull(cause);
/* 331:    */     
/* 332:386 */     this.monitor.enter();
/* 333:    */     try
/* 334:    */     {
/* 335:388 */       Service.State previous = state();
/* 336:389 */       switch (6.$SwitchMap$com$google$common$util$concurrent$Service$State[previous.ordinal()])
/* 337:    */       {
/* 338:    */       case 1: 
/* 339:    */       case 5: 
/* 340:392 */         throw new IllegalStateException("Failed while in state:" + previous, cause);
/* 341:    */       case 2: 
/* 342:    */       case 3: 
/* 343:    */       case 4: 
/* 344:396 */         this.snapshot = new StateSnapshot(Service.State.FAILED, false, cause);
/* 345:397 */         failed(previous, cause);
/* 346:398 */         break;
/* 347:    */       case 6: 
/* 348:    */         break;
/* 349:    */       default: 
/* 350:403 */         throw new AssertionError("Unexpected state: " + previous);
/* 351:    */       }
/* 352:    */     }
/* 353:    */     finally
/* 354:    */     {
/* 355:406 */       this.monitor.leave();
/* 356:407 */       executeListeners();
/* 357:    */     }
/* 358:    */   }
/* 359:    */   
/* 360:    */   public final boolean isRunning()
/* 361:    */   {
/* 362:413 */     return state() == Service.State.RUNNING;
/* 363:    */   }
/* 364:    */   
/* 365:    */   public final Service.State state()
/* 366:    */   {
/* 367:418 */     return this.snapshot.externalState();
/* 368:    */   }
/* 369:    */   
/* 370:    */   public final Throwable failureCause()
/* 371:    */   {
/* 372:426 */     return this.snapshot.failureCause();
/* 373:    */   }
/* 374:    */   
/* 375:    */   public final void addListener(Service.Listener listener, Executor executor)
/* 376:    */   {
/* 377:434 */     Preconditions.checkNotNull(listener, "listener");
/* 378:435 */     Preconditions.checkNotNull(executor, "executor");
/* 379:436 */     this.monitor.enter();
/* 380:    */     try
/* 381:    */     {
/* 382:438 */       if (!state().isTerminal()) {
/* 383:439 */         this.listeners.add(new ListenerCallQueue(listener, executor));
/* 384:    */       }
/* 385:    */     }
/* 386:    */     finally
/* 387:    */     {
/* 388:442 */       this.monitor.leave();
/* 389:    */     }
/* 390:    */   }
/* 391:    */   
/* 392:    */   public String toString()
/* 393:    */   {
/* 394:447 */     return getClass().getSimpleName() + " [" + state() + "]";
/* 395:    */   }
/* 396:    */   
/* 397:    */   private void executeListeners()
/* 398:    */   {
/* 399:455 */     if (!this.monitor.isOccupiedByCurrentThread()) {
/* 400:457 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 401:458 */         ((ListenerCallQueue)this.listeners.get(i)).execute();
/* 402:    */       }
/* 403:    */     }
/* 404:    */   }
/* 405:    */   
/* 406:    */   @GuardedBy("monitor")
/* 407:    */   private void starting()
/* 408:    */   {
/* 409:465 */     STARTING_CALLBACK.enqueueOn(this.listeners);
/* 410:    */   }
/* 411:    */   
/* 412:    */   @GuardedBy("monitor")
/* 413:    */   private void running()
/* 414:    */   {
/* 415:470 */     RUNNING_CALLBACK.enqueueOn(this.listeners);
/* 416:    */   }
/* 417:    */   
/* 418:    */   @GuardedBy("monitor")
/* 419:    */   private void stopping(Service.State from)
/* 420:    */   {
/* 421:475 */     if (from == Service.State.STARTING) {
/* 422:476 */       STOPPING_FROM_STARTING_CALLBACK.enqueueOn(this.listeners);
/* 423:477 */     } else if (from == Service.State.RUNNING) {
/* 424:478 */       STOPPING_FROM_RUNNING_CALLBACK.enqueueOn(this.listeners);
/* 425:    */     } else {
/* 426:480 */       throw new AssertionError();
/* 427:    */     }
/* 428:    */   }
/* 429:    */   
/* 430:    */   @GuardedBy("monitor")
/* 431:    */   private void terminated(Service.State from)
/* 432:    */   {
/* 433:486 */     switch (6.$SwitchMap$com$google$common$util$concurrent$Service$State[from.ordinal()])
/* 434:    */     {
/* 435:    */     case 1: 
/* 436:488 */       TERMINATED_FROM_NEW_CALLBACK.enqueueOn(this.listeners);
/* 437:489 */       break;
/* 438:    */     case 3: 
/* 439:491 */       TERMINATED_FROM_RUNNING_CALLBACK.enqueueOn(this.listeners);
/* 440:492 */       break;
/* 441:    */     case 4: 
/* 442:494 */       TERMINATED_FROM_STOPPING_CALLBACK.enqueueOn(this.listeners);
/* 443:495 */       break;
/* 444:    */     case 2: 
/* 445:    */     case 5: 
/* 446:    */     case 6: 
/* 447:    */     default: 
/* 448:500 */       throw new AssertionError();
/* 449:    */     }
/* 450:    */   }
/* 451:    */   
/* 452:    */   @GuardedBy("monitor")
/* 453:    */   private void failed(final Service.State from, final Throwable cause)
/* 454:    */   {
/* 455:507 */     new ListenerCallQueue.Callback("failed({from = " + from + ", cause = " + cause + "})")
/* 456:    */     {
/* 457:    */       void call(Service.Listener listener)
/* 458:    */       {
/* 459:509 */         listener.failed(from, cause);
/* 460:    */       }
/* 461:509 */     }.enqueueOn(this.listeners);
/* 462:    */   }
/* 463:    */   
/* 464:    */   @Immutable
/* 465:    */   private static final class StateSnapshot
/* 466:    */   {
/* 467:    */     final Service.State state;
/* 468:    */     final boolean shutdownWhenStartupFinishes;
/* 469:    */     @Nullable
/* 470:    */     final Throwable failure;
/* 471:    */     
/* 472:    */     StateSnapshot(Service.State internalState)
/* 473:    */     {
/* 474:541 */       this(internalState, false, null);
/* 475:    */     }
/* 476:    */     
/* 477:    */     StateSnapshot(Service.State internalState, boolean shutdownWhenStartupFinishes, @Nullable Throwable failure)
/* 478:    */     {
/* 479:546 */       Preconditions.checkArgument((!shutdownWhenStartupFinishes) || (internalState == Service.State.STARTING), "shudownWhenStartupFinishes can only be set if state is STARTING. Got %s instead.", new Object[] { internalState });
/* 480:    */       
/* 481:    */ 
/* 482:549 */       Preconditions.checkArgument(((failure != null ? 1 : 0) ^ (internalState == Service.State.FAILED ? 1 : 0)) == 0, "A failure cause should be set if and only if the state is failed.  Got %s and %s instead.", new Object[] { internalState, failure });
/* 483:    */       
/* 484:    */ 
/* 485:552 */       this.state = internalState;
/* 486:553 */       this.shutdownWhenStartupFinishes = shutdownWhenStartupFinishes;
/* 487:554 */       this.failure = failure;
/* 488:    */     }
/* 489:    */     
/* 490:    */     Service.State externalState()
/* 491:    */     {
/* 492:559 */       if ((this.shutdownWhenStartupFinishes) && (this.state == Service.State.STARTING)) {
/* 493:560 */         return Service.State.STOPPING;
/* 494:    */       }
/* 495:562 */       return this.state;
/* 496:    */     }
/* 497:    */     
/* 498:    */     Throwable failureCause()
/* 499:    */     {
/* 500:568 */       Preconditions.checkState(this.state == Service.State.FAILED, "failureCause() is only valid if the service has failed, service is %s", new Object[] { this.state });
/* 501:    */       
/* 502:570 */       return this.failure;
/* 503:    */     }
/* 504:    */   }
/* 505:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractService
 * JD-Core Version:    0.7.0.1
 */