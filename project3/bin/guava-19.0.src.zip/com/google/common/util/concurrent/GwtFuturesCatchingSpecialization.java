package com.google.common.util.concurrent;

import com.google.common.annotations.GwtCompatible;

@GwtCompatible(emulated=true)
abstract class GwtFuturesCatchingSpecialization {}


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.GwtFuturesCatchingSpecialization
 * JD-Core Version:    0.7.0.1
 */