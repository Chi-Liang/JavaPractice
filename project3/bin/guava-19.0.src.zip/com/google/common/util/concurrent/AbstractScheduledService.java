/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import com.google.common.base.Supplier;
/*   6:    */ import java.util.concurrent.Callable;
/*   7:    */ import java.util.concurrent.Executor;
/*   8:    */ import java.util.concurrent.Executors;
/*   9:    */ import java.util.concurrent.Future;
/*  10:    */ import java.util.concurrent.ScheduledExecutorService;
/*  11:    */ import java.util.concurrent.ThreadFactory;
/*  12:    */ import java.util.concurrent.TimeUnit;
/*  13:    */ import java.util.concurrent.TimeoutException;
/*  14:    */ import java.util.concurrent.locks.ReentrantLock;
/*  15:    */ import java.util.logging.Level;
/*  16:    */ import java.util.logging.Logger;
/*  17:    */ import javax.annotation.concurrent.GuardedBy;
/*  18:    */ 
/*  19:    */ @Beta
/*  20:    */ public abstract class AbstractScheduledService
/*  21:    */   implements Service
/*  22:    */ {
/*  23: 98 */   private static final Logger logger = Logger.getLogger(AbstractScheduledService.class.getName());
/*  24:    */   protected abstract void runOneIteration()
/*  25:    */     throws Exception;
/*  26:    */   
/*  27:    */   protected void startUp()
/*  28:    */     throws Exception
/*  29:    */   {}
/*  30:    */   
/*  31:    */   protected void shutDown()
/*  32:    */     throws Exception
/*  33:    */   {}
/*  34:    */   
/*  35:    */   protected abstract Scheduler scheduler();
/*  36:    */   
/*  37:    */   public static abstract class Scheduler
/*  38:    */   {
/*  39:    */     public static Scheduler newFixedDelaySchedule(long initialDelay, long delay, final TimeUnit unit)
/*  40:    */     {
/*  41:124 */       Preconditions.checkNotNull(unit);
/*  42:125 */       Preconditions.checkArgument(delay > 0L, "delay must be > 0, found %s", new Object[] { Long.valueOf(delay) });
/*  43:126 */       new Scheduler(initialDelay)
/*  44:    */       {
/*  45:    */         public Future<?> schedule(AbstractService service, ScheduledExecutorService executor, Runnable task)
/*  46:    */         {
/*  47:130 */           return executor.scheduleWithFixedDelay(task, this.val$initialDelay, unit, this.val$unit);
/*  48:    */         }
/*  49:    */       };
/*  50:    */     }
/*  51:    */     
/*  52:    */     public static Scheduler newFixedRateSchedule(long initialDelay, long period, final TimeUnit unit)
/*  53:    */     {
/*  54:145 */       Preconditions.checkNotNull(unit);
/*  55:146 */       Preconditions.checkArgument(period > 0L, "period must be > 0, found %s", new Object[] { Long.valueOf(period) });
/*  56:147 */       new Scheduler(initialDelay)
/*  57:    */       {
/*  58:    */         public Future<?> schedule(AbstractService service, ScheduledExecutorService executor, Runnable task)
/*  59:    */         {
/*  60:151 */           return executor.scheduleAtFixedRate(task, this.val$initialDelay, unit, this.val$unit);
/*  61:    */         }
/*  62:    */       };
/*  63:    */     }
/*  64:    */     
/*  65:    */     abstract Future<?> schedule(AbstractService paramAbstractService, ScheduledExecutorService paramScheduledExecutorService, Runnable paramRunnable);
/*  66:    */   }
/*  67:    */   
/*  68:164 */   private final AbstractService delegate = new ServiceDelegate(null);
/*  69:    */   
/*  70:    */   private final class ServiceDelegate
/*  71:    */     extends AbstractService
/*  72:    */   {
/*  73:    */     private volatile Future<?> runningTask;
/*  74:    */     private volatile ScheduledExecutorService executorService;
/*  75:178 */     private final ReentrantLock lock = new ReentrantLock();
/*  76:    */     private ServiceDelegate() {}
/*  77:    */     
/*  78:    */     class Task
/*  79:    */       implements Runnable
/*  80:    */     {
/*  81:    */       Task() {}
/*  82:    */       
/*  83:    */       public void run()
/*  84:    */       {
/*  85:183 */         AbstractScheduledService.ServiceDelegate.this.lock.lock();
/*  86:    */         try
/*  87:    */         {
/*  88:185 */           if (AbstractScheduledService.ServiceDelegate.this.runningTask.isCancelled()) {
/*  89:    */             return;
/*  90:    */           }
/*  91:189 */           AbstractScheduledService.this.runOneIteration();
/*  92:    */         }
/*  93:    */         catch (Throwable t)
/*  94:    */         {
/*  95:    */           try
/*  96:    */           {
/*  97:192 */             AbstractScheduledService.this.shutDown();
/*  98:    */           }
/*  99:    */           catch (Exception ignored)
/* 100:    */           {
/* 101:194 */             AbstractScheduledService.logger.log(Level.WARNING, "Error while attempting to shut down the service after failure.", ignored);
/* 102:    */           }
/* 103:197 */           AbstractScheduledService.ServiceDelegate.this.notifyFailed(t);
/* 104:198 */           AbstractScheduledService.ServiceDelegate.this.runningTask.cancel(false);
/* 105:    */         }
/* 106:    */         finally
/* 107:    */         {
/* 108:200 */           AbstractScheduledService.ServiceDelegate.this.lock.unlock();
/* 109:    */         }
/* 110:    */       }
/* 111:    */     }
/* 112:    */     
/* 113:205 */     private final Runnable task = new Task();
/* 114:    */     
/* 115:    */     protected final void doStart()
/* 116:    */     {
/* 117:208 */       this.executorService = MoreExecutors.renamingDecorator(AbstractScheduledService.this.executor(), new Supplier()
/* 118:    */       {
/* 119:    */         public String get()
/* 120:    */         {
/* 121:210 */           return AbstractScheduledService.this.serviceName() + " " + AbstractScheduledService.ServiceDelegate.this.state();
/* 122:    */         }
/* 123:212 */       });
/* 124:213 */       this.executorService.execute(new Runnable()
/* 125:    */       {
/* 126:    */         public void run()
/* 127:    */         {
/* 128:215 */           AbstractScheduledService.ServiceDelegate.this.lock.lock();
/* 129:    */           try
/* 130:    */           {
/* 131:217 */             AbstractScheduledService.this.startUp();
/* 132:218 */             AbstractScheduledService.ServiceDelegate.this.runningTask = AbstractScheduledService.this.scheduler().schedule(AbstractScheduledService.this.delegate, AbstractScheduledService.ServiceDelegate.this.executorService, AbstractScheduledService.ServiceDelegate.this.task);
/* 133:219 */             AbstractScheduledService.ServiceDelegate.this.notifyStarted();
/* 134:    */           }
/* 135:    */           catch (Throwable t)
/* 136:    */           {
/* 137:221 */             AbstractScheduledService.ServiceDelegate.this.notifyFailed(t);
/* 138:222 */             if (AbstractScheduledService.ServiceDelegate.this.runningTask != null) {
/* 139:224 */               AbstractScheduledService.ServiceDelegate.this.runningTask.cancel(false);
/* 140:    */             }
/* 141:    */           }
/* 142:    */           finally
/* 143:    */           {
/* 144:227 */             AbstractScheduledService.ServiceDelegate.this.lock.unlock();
/* 145:    */           }
/* 146:    */         }
/* 147:    */       });
/* 148:    */     }
/* 149:    */     
/* 150:    */     protected final void doStop()
/* 151:    */     {
/* 152:234 */       this.runningTask.cancel(false);
/* 153:235 */       this.executorService.execute(new Runnable()
/* 154:    */       {
/* 155:    */         public void run()
/* 156:    */         {
/* 157:    */           try
/* 158:    */           {
/* 159:238 */             AbstractScheduledService.ServiceDelegate.this.lock.lock();
/* 160:    */             try
/* 161:    */             {
/* 162:240 */               if (AbstractScheduledService.ServiceDelegate.this.state() != Service.State.STOPPING) {
/* 163:    */                 return;
/* 164:    */               }
/* 165:247 */               AbstractScheduledService.this.shutDown();
/* 166:    */             }
/* 167:    */             finally
/* 168:    */             {
/* 169:249 */               AbstractScheduledService.ServiceDelegate.this.lock.unlock();
/* 170:    */             }
/* 171:251 */             AbstractScheduledService.ServiceDelegate.this.notifyStopped();
/* 172:    */           }
/* 173:    */           catch (Throwable t)
/* 174:    */           {
/* 175:253 */             AbstractScheduledService.ServiceDelegate.this.notifyFailed(t);
/* 176:    */           }
/* 177:    */         }
/* 178:    */       });
/* 179:    */     }
/* 180:    */     
/* 181:    */     public String toString()
/* 182:    */     {
/* 183:260 */       return AbstractScheduledService.this.toString();
/* 184:    */     }
/* 185:    */   }
/* 186:    */   
/* 187:    */   protected ScheduledExecutorService executor()
/* 188:    */   {
/* 189:315 */     final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor(new ThreadFactory()
/* 190:    */     {
/* 191:    */       public Thread newThread(Runnable runnable)
/* 192:    */       {
/* 193:312 */         return MoreExecutors.newThread(AbstractScheduledService.this.serviceName(), runnable);
/* 194:    */       }
/* 195:321 */     });
/* 196:322 */     addListener(new Service.Listener()
/* 197:    */     {
/* 198:    */       public void terminated(Service.State from)
/* 199:    */       {
/* 200:324 */         executor.shutdown();
/* 201:    */       }
/* 202:    */       
/* 203:    */       public void failed(Service.State from, Throwable failure)
/* 204:    */       {
/* 205:327 */         executor.shutdown();
/* 206:    */       }
/* 207:327 */     }, MoreExecutors.directExecutor());
/* 208:    */     
/* 209:    */ 
/* 210:330 */     return executor;
/* 211:    */   }
/* 212:    */   
/* 213:    */   protected String serviceName()
/* 214:    */   {
/* 215:340 */     return getClass().getSimpleName();
/* 216:    */   }
/* 217:    */   
/* 218:    */   public String toString()
/* 219:    */   {
/* 220:344 */     return serviceName() + " [" + state() + "]";
/* 221:    */   }
/* 222:    */   
/* 223:    */   public final boolean isRunning()
/* 224:    */   {
/* 225:348 */     return this.delegate.isRunning();
/* 226:    */   }
/* 227:    */   
/* 228:    */   public final Service.State state()
/* 229:    */   {
/* 230:352 */     return this.delegate.state();
/* 231:    */   }
/* 232:    */   
/* 233:    */   public final void addListener(Service.Listener listener, Executor executor)
/* 234:    */   {
/* 235:359 */     this.delegate.addListener(listener, executor);
/* 236:    */   }
/* 237:    */   
/* 238:    */   public final Throwable failureCause()
/* 239:    */   {
/* 240:366 */     return this.delegate.failureCause();
/* 241:    */   }
/* 242:    */   
/* 243:    */   public final Service startAsync()
/* 244:    */   {
/* 245:373 */     this.delegate.startAsync();
/* 246:374 */     return this;
/* 247:    */   }
/* 248:    */   
/* 249:    */   public final Service stopAsync()
/* 250:    */   {
/* 251:381 */     this.delegate.stopAsync();
/* 252:382 */     return this;
/* 253:    */   }
/* 254:    */   
/* 255:    */   public final void awaitRunning()
/* 256:    */   {
/* 257:389 */     this.delegate.awaitRunning();
/* 258:    */   }
/* 259:    */   
/* 260:    */   public final void awaitRunning(long timeout, TimeUnit unit)
/* 261:    */     throws TimeoutException
/* 262:    */   {
/* 263:396 */     this.delegate.awaitRunning(timeout, unit);
/* 264:    */   }
/* 265:    */   
/* 266:    */   public final void awaitTerminated()
/* 267:    */   {
/* 268:403 */     this.delegate.awaitTerminated();
/* 269:    */   }
/* 270:    */   
/* 271:    */   public final void awaitTerminated(long timeout, TimeUnit unit)
/* 272:    */     throws TimeoutException
/* 273:    */   {
/* 274:410 */     this.delegate.awaitTerminated(timeout, unit);
/* 275:    */   }
/* 276:    */   
/* 277:    */   @Beta
/* 278:    */   public static abstract class CustomScheduler
/* 279:    */     extends AbstractScheduledService.Scheduler
/* 280:    */   {
/* 281:    */     public CustomScheduler()
/* 282:    */     {
/* 283:422 */       super();
/* 284:    */     }
/* 285:    */     
/* 286:    */     private class ReschedulableCallable
/* 287:    */       extends ForwardingFuture<Void>
/* 288:    */       implements Callable<Void>
/* 289:    */     {
/* 290:    */       private final Runnable wrappedRunnable;
/* 291:    */       private final ScheduledExecutorService executor;
/* 292:    */       private final AbstractService service;
/* 293:446 */       private final ReentrantLock lock = new ReentrantLock();
/* 294:    */       @GuardedBy("lock")
/* 295:    */       private Future<Void> currentFuture;
/* 296:    */       
/* 297:    */       ReschedulableCallable(AbstractService service, ScheduledExecutorService executor, Runnable runnable)
/* 298:    */       {
/* 299:454 */         this.wrappedRunnable = runnable;
/* 300:455 */         this.executor = executor;
/* 301:456 */         this.service = service;
/* 302:    */       }
/* 303:    */       
/* 304:    */       public Void call()
/* 305:    */         throws Exception
/* 306:    */       {
/* 307:461 */         this.wrappedRunnable.run();
/* 308:462 */         reschedule();
/* 309:463 */         return null;
/* 310:    */       }
/* 311:    */       
/* 312:    */       public void reschedule()
/* 313:    */       {
/* 314:    */         AbstractScheduledService.CustomScheduler.Schedule schedule;
/* 315:    */         try
/* 316:    */         {
/* 317:473 */           schedule = AbstractScheduledService.CustomScheduler.this.getNextSchedule();
/* 318:    */         }
/* 319:    */         catch (Throwable t)
/* 320:    */         {
/* 321:475 */           this.service.notifyFailed(t);
/* 322:476 */           return;
/* 323:    */         }
/* 324:482 */         Throwable scheduleFailure = null;
/* 325:483 */         this.lock.lock();
/* 326:    */         try
/* 327:    */         {
/* 328:485 */           if ((this.currentFuture == null) || (!this.currentFuture.isCancelled())) {
/* 329:486 */             this.currentFuture = this.executor.schedule(this, schedule.delay, schedule.unit);
/* 330:    */           }
/* 331:    */         }
/* 332:    */         catch (Throwable e)
/* 333:    */         {
/* 334:497 */           scheduleFailure = e;
/* 335:    */         }
/* 336:    */         finally
/* 337:    */         {
/* 338:499 */           this.lock.unlock();
/* 339:    */         }
/* 340:502 */         if (scheduleFailure != null) {
/* 341:503 */           this.service.notifyFailed(scheduleFailure);
/* 342:    */         }
/* 343:    */       }
/* 344:    */       
/* 345:    */       public boolean cancel(boolean mayInterruptIfRunning)
/* 346:    */       {
/* 347:512 */         this.lock.lock();
/* 348:    */         try
/* 349:    */         {
/* 350:514 */           return this.currentFuture.cancel(mayInterruptIfRunning);
/* 351:    */         }
/* 352:    */         finally
/* 353:    */         {
/* 354:516 */           this.lock.unlock();
/* 355:    */         }
/* 356:    */       }
/* 357:    */       
/* 358:    */       public boolean isCancelled()
/* 359:    */       {
/* 360:522 */         this.lock.lock();
/* 361:    */         try
/* 362:    */         {
/* 363:524 */           return this.currentFuture.isCancelled();
/* 364:    */         }
/* 365:    */         finally
/* 366:    */         {
/* 367:526 */           this.lock.unlock();
/* 368:    */         }
/* 369:    */       }
/* 370:    */       
/* 371:    */       protected Future<Void> delegate()
/* 372:    */       {
/* 373:532 */         throw new UnsupportedOperationException("Only cancel and isCancelled is supported by this future");
/* 374:    */       }
/* 375:    */     }
/* 376:    */     
/* 377:    */     final Future<?> schedule(AbstractService service, ScheduledExecutorService executor, Runnable runnable)
/* 378:    */     {
/* 379:540 */       ReschedulableCallable task = new ReschedulableCallable(service, executor, runnable);
/* 380:541 */       task.reschedule();
/* 381:542 */       return task;
/* 382:    */     }
/* 383:    */     
/* 384:    */     protected abstract Schedule getNextSchedule()
/* 385:    */       throws Exception;
/* 386:    */     
/* 387:    */     @Beta
/* 388:    */     protected static final class Schedule
/* 389:    */     {
/* 390:    */       private final long delay;
/* 391:    */       private final TimeUnit unit;
/* 392:    */       
/* 393:    */       public Schedule(long delay, TimeUnit unit)
/* 394:    */       {
/* 395:562 */         this.delay = delay;
/* 396:563 */         this.unit = ((TimeUnit)Preconditions.checkNotNull(unit));
/* 397:    */       }
/* 398:    */     }
/* 399:    */   }
/* 400:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractScheduledService
 * JD-Core Version:    0.7.0.1
 */