/*    1:     */ package com.google.common.util.concurrent;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.base.Preconditions;
/*    5:     */ import com.google.common.base.Throwables;
/*    6:     */ import com.google.j2objc.annotations.Weak;
/*    7:     */ import java.util.concurrent.TimeUnit;
/*    8:     */ import java.util.concurrent.locks.Condition;
/*    9:     */ import java.util.concurrent.locks.ReentrantLock;
/*   10:     */ import javax.annotation.concurrent.GuardedBy;
/*   11:     */ 
/*   12:     */ @Beta
/*   13:     */ public final class Monitor
/*   14:     */ {
/*   15:     */   private final boolean fair;
/*   16:     */   private final ReentrantLock lock;
/*   17:     */   
/*   18:     */   @Beta
/*   19:     */   public static abstract class Guard
/*   20:     */   {
/*   21:     */     @Weak
/*   22:     */     final Monitor monitor;
/*   23:     */     final Condition condition;
/*   24:     */     @GuardedBy("monitor.lock")
/*   25: 310 */     int waiterCount = 0;
/*   26:     */     @GuardedBy("monitor.lock")
/*   27:     */     Guard next;
/*   28:     */     
/*   29:     */     protected Guard(Monitor monitor)
/*   30:     */     {
/*   31: 318 */       this.monitor = ((Monitor)Preconditions.checkNotNull(monitor, "monitor"));
/*   32: 319 */       this.condition = monitor.lock.newCondition();
/*   33:     */     }
/*   34:     */     
/*   35:     */     public abstract boolean isSatisfied();
/*   36:     */   }
/*   37:     */   
/*   38:     */   @GuardedBy("lock")
/*   39: 345 */   private Guard activeGuards = null;
/*   40:     */   
/*   41:     */   public Monitor()
/*   42:     */   {
/*   43: 353 */     this(false);
/*   44:     */   }
/*   45:     */   
/*   46:     */   public Monitor(boolean fair)
/*   47:     */   {
/*   48: 363 */     this.fair = fair;
/*   49: 364 */     this.lock = new ReentrantLock(fair);
/*   50:     */   }
/*   51:     */   
/*   52:     */   public void enter()
/*   53:     */   {
/*   54: 371 */     this.lock.lock();
/*   55:     */   }
/*   56:     */   
/*   57:     */   public void enterInterruptibly()
/*   58:     */     throws InterruptedException
/*   59:     */   {
/*   60: 380 */     this.lock.lockInterruptibly();
/*   61:     */   }
/*   62:     */   
/*   63:     */   /* Error */
/*   64:     */   public boolean enter(long time, TimeUnit unit)
/*   65:     */   {
/*   66:     */     // Byte code:
/*   67:     */     //   0: lload_1
/*   68:     */     //   1: aload_3
/*   69:     */     //   2: invokestatic 11	com/google/common/util/concurrent/Monitor:toSafeNanos	(JLjava/util/concurrent/TimeUnit;)J
/*   70:     */     //   5: lstore 4
/*   71:     */     //   7: aload_0
/*   72:     */     //   8: getfield 2	com/google/common/util/concurrent/Monitor:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*   73:     */     //   11: astore 6
/*   74:     */     //   13: aload_0
/*   75:     */     //   14: getfield 6	com/google/common/util/concurrent/Monitor:fair	Z
/*   76:     */     //   17: ifne +13 -> 30
/*   77:     */     //   20: aload 6
/*   78:     */     //   22: invokevirtual 12	java/util/concurrent/locks/ReentrantLock:tryLock	()Z
/*   79:     */     //   25: ifeq +5 -> 30
/*   80:     */     //   28: iconst_1
/*   81:     */     //   29: ireturn
/*   82:     */     //   30: invokestatic 13	java/lang/Thread:interrupted	()Z
/*   83:     */     //   33: istore 7
/*   84:     */     //   35: invokestatic 14	java/lang/System:nanoTime	()J
/*   85:     */     //   38: lstore 8
/*   86:     */     //   40: lload 4
/*   87:     */     //   42: lstore 10
/*   88:     */     //   44: aload 6
/*   89:     */     //   46: lload 10
/*   90:     */     //   48: getstatic 15	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/*   91:     */     //   51: invokevirtual 16	java/util/concurrent/locks/ReentrantLock:tryLock	(JLjava/util/concurrent/TimeUnit;)Z
/*   92:     */     //   54: istore 12
/*   93:     */     //   56: iload 7
/*   94:     */     //   58: ifeq +9 -> 67
/*   95:     */     //   61: invokestatic 17	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*   96:     */     //   64: invokevirtual 18	java/lang/Thread:interrupt	()V
/*   97:     */     //   67: iload 12
/*   98:     */     //   69: ireturn
/*   99:     */     //   70: astore 12
/*  100:     */     //   72: iconst_1
/*  101:     */     //   73: istore 7
/*  102:     */     //   75: lload 8
/*  103:     */     //   77: lload 4
/*  104:     */     //   79: invokestatic 20	com/google/common/util/concurrent/Monitor:remainingNanos	(JJ)J
/*  105:     */     //   82: lstore 10
/*  106:     */     //   84: goto -40 -> 44
/*  107:     */     //   87: astore 13
/*  108:     */     //   89: iload 7
/*  109:     */     //   91: ifeq +9 -> 100
/*  110:     */     //   94: invokestatic 17	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  111:     */     //   97: invokevirtual 18	java/lang/Thread:interrupt	()V
/*  112:     */     //   100: aload 13
/*  113:     */     //   102: athrow
/*  114:     */     // Line number table:
/*  115:     */     //   Java source line #389	-> byte code offset #0
/*  116:     */     //   Java source line #390	-> byte code offset #7
/*  117:     */     //   Java source line #391	-> byte code offset #13
/*  118:     */     //   Java source line #392	-> byte code offset #28
/*  119:     */     //   Java source line #394	-> byte code offset #30
/*  120:     */     //   Java source line #396	-> byte code offset #35
/*  121:     */     //   Java source line #397	-> byte code offset #40
/*  122:     */     //   Java source line #399	-> byte code offset #44
/*  123:     */     //   Java source line #406	-> byte code offset #56
/*  124:     */     //   Java source line #407	-> byte code offset #61
/*  125:     */     //   Java source line #400	-> byte code offset #70
/*  126:     */     //   Java source line #401	-> byte code offset #72
/*  127:     */     //   Java source line #402	-> byte code offset #75
/*  128:     */     //   Java source line #403	-> byte code offset #84
/*  129:     */     //   Java source line #406	-> byte code offset #87
/*  130:     */     //   Java source line #407	-> byte code offset #94
/*  131:     */     // Local variable table:
/*  132:     */     //   start	length	slot	name	signature
/*  133:     */     //   0	103	0	this	Monitor
/*  134:     */     //   0	103	1	time	long
/*  135:     */     //   0	103	3	unit	TimeUnit
/*  136:     */     //   5	73	4	timeoutNanos	long
/*  137:     */     //   11	34	6	lock	ReentrantLock
/*  138:     */     //   33	57	7	interrupted	boolean
/*  139:     */     //   38	38	8	startTime	long
/*  140:     */     //   42	41	10	remainingNanos	long
/*  141:     */     //   54	14	12	bool1	boolean
/*  142:     */     //   70	3	12	interrupt	InterruptedException
/*  143:     */     //   87	14	13	localObject	Object
/*  144:     */     // Exception table:
/*  145:     */     //   from	to	target	type
/*  146:     */     //   44	56	70	java/lang/InterruptedException
/*  147:     */     //   35	56	87	finally
/*  148:     */     //   70	89	87	finally
/*  149:     */   }
/*  150:     */   
/*  151:     */   public boolean enterInterruptibly(long time, TimeUnit unit)
/*  152:     */     throws InterruptedException
/*  153:     */   {
/*  154: 419 */     return this.lock.tryLock(time, unit);
/*  155:     */   }
/*  156:     */   
/*  157:     */   public boolean tryEnter()
/*  158:     */   {
/*  159: 430 */     return this.lock.tryLock();
/*  160:     */   }
/*  161:     */   
/*  162:     */   public void enterWhen(Guard guard)
/*  163:     */     throws InterruptedException
/*  164:     */   {
/*  165: 439 */     if (guard.monitor != this) {
/*  166: 440 */       throw new IllegalMonitorStateException();
/*  167:     */     }
/*  168: 442 */     ReentrantLock lock = this.lock;
/*  169: 443 */     boolean signalBeforeWaiting = lock.isHeldByCurrentThread();
/*  170: 444 */     lock.lockInterruptibly();
/*  171:     */     
/*  172: 446 */     boolean satisfied = false;
/*  173:     */     try
/*  174:     */     {
/*  175: 448 */       if (!guard.isSatisfied()) {
/*  176: 449 */         await(guard, signalBeforeWaiting);
/*  177:     */       }
/*  178: 451 */       satisfied = true;
/*  179:     */     }
/*  180:     */     finally
/*  181:     */     {
/*  182: 453 */       if (!satisfied) {
/*  183: 454 */         leave();
/*  184:     */       }
/*  185:     */     }
/*  186:     */   }
/*  187:     */   
/*  188:     */   public void enterWhenUninterruptibly(Guard guard)
/*  189:     */   {
/*  190: 463 */     if (guard.monitor != this) {
/*  191: 464 */       throw new IllegalMonitorStateException();
/*  192:     */     }
/*  193: 466 */     ReentrantLock lock = this.lock;
/*  194: 467 */     boolean signalBeforeWaiting = lock.isHeldByCurrentThread();
/*  195: 468 */     lock.lock();
/*  196:     */     
/*  197: 470 */     boolean satisfied = false;
/*  198:     */     try
/*  199:     */     {
/*  200: 472 */       if (!guard.isSatisfied()) {
/*  201: 473 */         awaitUninterruptibly(guard, signalBeforeWaiting);
/*  202:     */       }
/*  203: 475 */       satisfied = true;
/*  204:     */     }
/*  205:     */     finally
/*  206:     */     {
/*  207: 477 */       if (!satisfied) {
/*  208: 478 */         leave();
/*  209:     */       }
/*  210:     */     }
/*  211:     */   }
/*  212:     */   
/*  213:     */   public boolean enterWhen(Guard guard, long time, TimeUnit unit)
/*  214:     */     throws InterruptedException
/*  215:     */   {
/*  216: 492 */     long timeoutNanos = toSafeNanos(time, unit);
/*  217: 493 */     if (guard.monitor != this) {
/*  218: 494 */       throw new IllegalMonitorStateException();
/*  219:     */     }
/*  220: 496 */     ReentrantLock lock = this.lock;
/*  221: 497 */     boolean reentrant = lock.isHeldByCurrentThread();
/*  222: 498 */     long startTime = 0L;
/*  223: 501 */     if (!this.fair)
/*  224:     */     {
/*  225: 503 */       if (Thread.interrupted()) {
/*  226: 504 */         throw new InterruptedException();
/*  227:     */       }
/*  228: 506 */       if (lock.tryLock()) {}
/*  229:     */     }
/*  230:     */     else
/*  231:     */     {
/*  232: 510 */       startTime = initNanoTime(timeoutNanos);
/*  233: 511 */       if (!lock.tryLock(time, unit)) {
/*  234: 512 */         return false;
/*  235:     */       }
/*  236:     */     }
/*  237: 516 */     boolean satisfied = false;
/*  238: 517 */     boolean threw = true;
/*  239:     */     try
/*  240:     */     {
/*  241: 519 */       if (!guard.isSatisfied()) {}
/*  242: 519 */       satisfied = awaitNanos(guard, startTime == 0L ? timeoutNanos : remainingNanos(startTime, timeoutNanos), reentrant);
/*  243:     */       
/*  244:     */ 
/*  245:     */ 
/*  246:     */ 
/*  247:     */ 
/*  248: 525 */       threw = false;
/*  249: 526 */       return satisfied;
/*  250:     */     }
/*  251:     */     finally
/*  252:     */     {
/*  253: 528 */       if (!satisfied) {
/*  254:     */         try
/*  255:     */         {
/*  256: 531 */           if ((threw) && (!reentrant)) {
/*  257: 532 */             signalNextWaiter();
/*  258:     */           }
/*  259:     */         }
/*  260:     */         finally
/*  261:     */         {
/*  262: 535 */           lock.unlock();
/*  263:     */         }
/*  264:     */       }
/*  265:     */     }
/*  266:     */   }
/*  267:     */   
/*  268:     */   /* Error */
/*  269:     */   public boolean enterWhenUninterruptibly(Guard guard, long time, TimeUnit unit)
/*  270:     */   {
/*  271:     */     // Byte code:
/*  272:     */     //   0: lload_2
/*  273:     */     //   1: aload 4
/*  274:     */     //   3: invokestatic 11	com/google/common/util/concurrent/Monitor:toSafeNanos	(JLjava/util/concurrent/TimeUnit;)J
/*  275:     */     //   6: lstore 5
/*  276:     */     //   8: aload_1
/*  277:     */     //   9: getfield 21	com/google/common/util/concurrent/Monitor$Guard:monitor	Lcom/google/common/util/concurrent/Monitor;
/*  278:     */     //   12: aload_0
/*  279:     */     //   13: if_acmpeq +11 -> 24
/*  280:     */     //   16: new 22	java/lang/IllegalMonitorStateException
/*  281:     */     //   19: dup
/*  282:     */     //   20: invokespecial 23	java/lang/IllegalMonitorStateException:<init>	()V
/*  283:     */     //   23: athrow
/*  284:     */     //   24: aload_0
/*  285:     */     //   25: getfield 2	com/google/common/util/concurrent/Monitor:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*  286:     */     //   28: astore 7
/*  287:     */     //   30: lconst_0
/*  288:     */     //   31: lstore 8
/*  289:     */     //   33: aload 7
/*  290:     */     //   35: invokevirtual 24	java/util/concurrent/locks/ReentrantLock:isHeldByCurrentThread	()Z
/*  291:     */     //   38: istore 10
/*  292:     */     //   40: invokestatic 13	java/lang/Thread:interrupted	()Z
/*  293:     */     //   43: istore 11
/*  294:     */     //   45: aload_0
/*  295:     */     //   46: getfield 6	com/google/common/util/concurrent/Monitor:fair	Z
/*  296:     */     //   49: ifne +11 -> 60
/*  297:     */     //   52: aload 7
/*  298:     */     //   54: invokevirtual 12	java/util/concurrent/locks/ReentrantLock:tryLock	()Z
/*  299:     */     //   57: ifne +64 -> 121
/*  300:     */     //   60: lload 5
/*  301:     */     //   62: invokestatic 30	com/google/common/util/concurrent/Monitor:initNanoTime	(J)J
/*  302:     */     //   65: lstore 8
/*  303:     */     //   67: lload 5
/*  304:     */     //   69: lstore 12
/*  305:     */     //   71: aload 7
/*  306:     */     //   73: lload 12
/*  307:     */     //   75: getstatic 15	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/*  308:     */     //   78: invokevirtual 16	java/util/concurrent/locks/ReentrantLock:tryLock	(JLjava/util/concurrent/TimeUnit;)Z
/*  309:     */     //   81: ifeq +6 -> 87
/*  310:     */     //   84: goto +37 -> 121
/*  311:     */     //   87: iconst_0
/*  312:     */     //   88: istore 14
/*  313:     */     //   90: iload 11
/*  314:     */     //   92: ifeq +9 -> 101
/*  315:     */     //   95: invokestatic 17	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  316:     */     //   98: invokevirtual 18	java/lang/Thread:interrupt	()V
/*  317:     */     //   101: iload 14
/*  318:     */     //   103: ireturn
/*  319:     */     //   104: astore 14
/*  320:     */     //   106: iconst_1
/*  321:     */     //   107: istore 11
/*  322:     */     //   109: lload 8
/*  323:     */     //   111: lload 5
/*  324:     */     //   113: invokestatic 20	com/google/common/util/concurrent/Monitor:remainingNanos	(JJ)J
/*  325:     */     //   116: lstore 12
/*  326:     */     //   118: goto -47 -> 71
/*  327:     */     //   121: iconst_0
/*  328:     */     //   122: istore 12
/*  329:     */     //   124: aload_1
/*  330:     */     //   125: invokevirtual 25	com/google/common/util/concurrent/Monitor$Guard:isSatisfied	()Z
/*  331:     */     //   128: ifeq +9 -> 137
/*  332:     */     //   131: iconst_1
/*  333:     */     //   132: istore 12
/*  334:     */     //   134: goto +44 -> 178
/*  335:     */     //   137: lload 8
/*  336:     */     //   139: lconst_0
/*  337:     */     //   140: lcmp
/*  338:     */     //   141: ifne +17 -> 158
/*  339:     */     //   144: lload 5
/*  340:     */     //   146: invokestatic 30	com/google/common/util/concurrent/Monitor:initNanoTime	(J)J
/*  341:     */     //   149: lstore 8
/*  342:     */     //   151: lload 5
/*  343:     */     //   153: lstore 13
/*  344:     */     //   155: goto +12 -> 167
/*  345:     */     //   158: lload 8
/*  346:     */     //   160: lload 5
/*  347:     */     //   162: invokestatic 20	com/google/common/util/concurrent/Monitor:remainingNanos	(JJ)J
/*  348:     */     //   165: lstore 13
/*  349:     */     //   167: aload_0
/*  350:     */     //   168: aload_1
/*  351:     */     //   169: lload 13
/*  352:     */     //   171: iload 10
/*  353:     */     //   173: invokespecial 31	com/google/common/util/concurrent/Monitor:awaitNanos	(Lcom/google/common/util/concurrent/Monitor$Guard;JZ)Z
/*  354:     */     //   176: istore 12
/*  355:     */     //   178: iload 12
/*  356:     */     //   180: istore 13
/*  357:     */     //   182: iload 12
/*  358:     */     //   184: ifne +8 -> 192
/*  359:     */     //   187: aload 7
/*  360:     */     //   189: invokevirtual 33	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*  361:     */     //   192: iload 11
/*  362:     */     //   194: ifeq +9 -> 203
/*  363:     */     //   197: invokestatic 17	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  364:     */     //   200: invokevirtual 18	java/lang/Thread:interrupt	()V
/*  365:     */     //   203: iload 13
/*  366:     */     //   205: ireturn
/*  367:     */     //   206: astore 13
/*  368:     */     //   208: iconst_1
/*  369:     */     //   209: istore 11
/*  370:     */     //   211: iconst_0
/*  371:     */     //   212: istore 10
/*  372:     */     //   214: goto -90 -> 124
/*  373:     */     //   217: astore 15
/*  374:     */     //   219: iload 12
/*  375:     */     //   221: ifne +8 -> 229
/*  376:     */     //   224: aload 7
/*  377:     */     //   226: invokevirtual 33	java/util/concurrent/locks/ReentrantLock:unlock	()V
/*  378:     */     //   229: aload 15
/*  379:     */     //   231: athrow
/*  380:     */     //   232: astore 16
/*  381:     */     //   234: iload 11
/*  382:     */     //   236: ifeq +9 -> 245
/*  383:     */     //   239: invokestatic 17	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  384:     */     //   242: invokevirtual 18	java/lang/Thread:interrupt	()V
/*  385:     */     //   245: aload 16
/*  386:     */     //   247: athrow
/*  387:     */     // Line number table:
/*  388:     */     //   Java source line #548	-> byte code offset #0
/*  389:     */     //   Java source line #549	-> byte code offset #8
/*  390:     */     //   Java source line #550	-> byte code offset #16
/*  391:     */     //   Java source line #552	-> byte code offset #24
/*  392:     */     //   Java source line #553	-> byte code offset #30
/*  393:     */     //   Java source line #554	-> byte code offset #33
/*  394:     */     //   Java source line #555	-> byte code offset #40
/*  395:     */     //   Java source line #557	-> byte code offset #45
/*  396:     */     //   Java source line #558	-> byte code offset #60
/*  397:     */     //   Java source line #559	-> byte code offset #67
/*  398:     */     //   Java source line #561	-> byte code offset #71
/*  399:     */     //   Java source line #562	-> byte code offset #84
/*  400:     */     //   Java source line #564	-> byte code offset #87
/*  401:     */     //   Java source line #601	-> byte code offset #90
/*  402:     */     //   Java source line #602	-> byte code offset #95
/*  403:     */     //   Java source line #566	-> byte code offset #104
/*  404:     */     //   Java source line #567	-> byte code offset #106
/*  405:     */     //   Java source line #568	-> byte code offset #109
/*  406:     */     //   Java source line #569	-> byte code offset #118
/*  407:     */     //   Java source line #573	-> byte code offset #121
/*  408:     */     //   Java source line #577	-> byte code offset #124
/*  409:     */     //   Java source line #578	-> byte code offset #131
/*  410:     */     //   Java source line #581	-> byte code offset #137
/*  411:     */     //   Java source line #582	-> byte code offset #144
/*  412:     */     //   Java source line #583	-> byte code offset #151
/*  413:     */     //   Java source line #585	-> byte code offset #158
/*  414:     */     //   Java source line #587	-> byte code offset #167
/*  415:     */     //   Java source line #589	-> byte code offset #178
/*  416:     */     //   Java source line #596	-> byte code offset #182
/*  417:     */     //   Java source line #597	-> byte code offset #187
/*  418:     */     //   Java source line #601	-> byte code offset #192
/*  419:     */     //   Java source line #602	-> byte code offset #197
/*  420:     */     //   Java source line #590	-> byte code offset #206
/*  421:     */     //   Java source line #591	-> byte code offset #208
/*  422:     */     //   Java source line #592	-> byte code offset #211
/*  423:     */     //   Java source line #593	-> byte code offset #214
/*  424:     */     //   Java source line #596	-> byte code offset #217
/*  425:     */     //   Java source line #597	-> byte code offset #224
/*  426:     */     //   Java source line #601	-> byte code offset #232
/*  427:     */     //   Java source line #602	-> byte code offset #239
/*  428:     */     // Local variable table:
/*  429:     */     //   start	length	slot	name	signature
/*  430:     */     //   0	248	0	this	Monitor
/*  431:     */     //   0	248	1	guard	Guard
/*  432:     */     //   0	248	2	time	long
/*  433:     */     //   0	248	4	unit	TimeUnit
/*  434:     */     //   6	155	5	timeoutNanos	long
/*  435:     */     //   28	197	7	lock	ReentrantLock
/*  436:     */     //   31	128	8	startTime	long
/*  437:     */     //   38	175	10	signalBeforeWaiting	boolean
/*  438:     */     //   43	192	11	interrupted	boolean
/*  439:     */     //   69	48	12	remainingNanos	long
/*  440:     */     //   122	98	12	satisfied	boolean
/*  441:     */     //   153	3	13	remainingNanos	long
/*  442:     */     //   165	39	13	remainingNanos	long
/*  443:     */     //   206	3	13	interrupt	InterruptedException
/*  444:     */     //   88	14	14	bool1	boolean
/*  445:     */     //   104	3	14	interrupt	InterruptedException
/*  446:     */     //   217	13	15	localObject1	Object
/*  447:     */     //   232	14	16	localObject2	Object
/*  448:     */     // Exception table:
/*  449:     */     //   from	to	target	type
/*  450:     */     //   71	84	104	java/lang/InterruptedException
/*  451:     */     //   87	90	104	java/lang/InterruptedException
/*  452:     */     //   124	182	206	java/lang/InterruptedException
/*  453:     */     //   124	182	217	finally
/*  454:     */     //   206	219	217	finally
/*  455:     */     //   45	90	232	finally
/*  456:     */     //   104	192	232	finally
/*  457:     */     //   206	234	232	finally
/*  458:     */   }
/*  459:     */   
/*  460:     */   public boolean enterIf(Guard guard)
/*  461:     */   {
/*  462: 614 */     if (guard.monitor != this) {
/*  463: 615 */       throw new IllegalMonitorStateException();
/*  464:     */     }
/*  465: 617 */     ReentrantLock lock = this.lock;
/*  466: 618 */     lock.lock();
/*  467:     */     
/*  468: 620 */     boolean satisfied = false;
/*  469:     */     try
/*  470:     */     {
/*  471: 622 */       return satisfied = guard.isSatisfied();
/*  472:     */     }
/*  473:     */     finally
/*  474:     */     {
/*  475: 624 */       if (!satisfied) {
/*  476: 625 */         lock.unlock();
/*  477:     */       }
/*  478:     */     }
/*  479:     */   }
/*  480:     */   
/*  481:     */   public boolean enterIfInterruptibly(Guard guard)
/*  482:     */     throws InterruptedException
/*  483:     */   {
/*  484: 638 */     if (guard.monitor != this) {
/*  485: 639 */       throw new IllegalMonitorStateException();
/*  486:     */     }
/*  487: 641 */     ReentrantLock lock = this.lock;
/*  488: 642 */     lock.lockInterruptibly();
/*  489:     */     
/*  490: 644 */     boolean satisfied = false;
/*  491:     */     try
/*  492:     */     {
/*  493: 646 */       return satisfied = guard.isSatisfied();
/*  494:     */     }
/*  495:     */     finally
/*  496:     */     {
/*  497: 648 */       if (!satisfied) {
/*  498: 649 */         lock.unlock();
/*  499:     */       }
/*  500:     */     }
/*  501:     */   }
/*  502:     */   
/*  503:     */   public boolean enterIf(Guard guard, long time, TimeUnit unit)
/*  504:     */   {
/*  505: 661 */     if (guard.monitor != this) {
/*  506: 662 */       throw new IllegalMonitorStateException();
/*  507:     */     }
/*  508: 664 */     if (!enter(time, unit)) {
/*  509: 665 */       return false;
/*  510:     */     }
/*  511: 668 */     boolean satisfied = false;
/*  512:     */     try
/*  513:     */     {
/*  514: 670 */       return satisfied = guard.isSatisfied();
/*  515:     */     }
/*  516:     */     finally
/*  517:     */     {
/*  518: 672 */       if (!satisfied) {
/*  519: 673 */         this.lock.unlock();
/*  520:     */       }
/*  521:     */     }
/*  522:     */   }
/*  523:     */   
/*  524:     */   public boolean enterIfInterruptibly(Guard guard, long time, TimeUnit unit)
/*  525:     */     throws InterruptedException
/*  526:     */   {
/*  527: 686 */     if (guard.monitor != this) {
/*  528: 687 */       throw new IllegalMonitorStateException();
/*  529:     */     }
/*  530: 689 */     ReentrantLock lock = this.lock;
/*  531: 690 */     if (!lock.tryLock(time, unit)) {
/*  532: 691 */       return false;
/*  533:     */     }
/*  534: 694 */     boolean satisfied = false;
/*  535:     */     try
/*  536:     */     {
/*  537: 696 */       return satisfied = guard.isSatisfied();
/*  538:     */     }
/*  539:     */     finally
/*  540:     */     {
/*  541: 698 */       if (!satisfied) {
/*  542: 699 */         lock.unlock();
/*  543:     */       }
/*  544:     */     }
/*  545:     */   }
/*  546:     */   
/*  547:     */   public boolean tryEnterIf(Guard guard)
/*  548:     */   {
/*  549: 713 */     if (guard.monitor != this) {
/*  550: 714 */       throw new IllegalMonitorStateException();
/*  551:     */     }
/*  552: 716 */     ReentrantLock lock = this.lock;
/*  553: 717 */     if (!lock.tryLock()) {
/*  554: 718 */       return false;
/*  555:     */     }
/*  556: 721 */     boolean satisfied = false;
/*  557:     */     try
/*  558:     */     {
/*  559: 723 */       return satisfied = guard.isSatisfied();
/*  560:     */     }
/*  561:     */     finally
/*  562:     */     {
/*  563: 725 */       if (!satisfied) {
/*  564: 726 */         lock.unlock();
/*  565:     */       }
/*  566:     */     }
/*  567:     */   }
/*  568:     */   
/*  569:     */   public void waitFor(Guard guard)
/*  570:     */     throws InterruptedException
/*  571:     */   {
/*  572: 738 */     if (!(guard.monitor == this & this.lock.isHeldByCurrentThread())) {
/*  573: 739 */       throw new IllegalMonitorStateException();
/*  574:     */     }
/*  575: 741 */     if (!guard.isSatisfied()) {
/*  576: 742 */       await(guard, true);
/*  577:     */     }
/*  578:     */   }
/*  579:     */   
/*  580:     */   public void waitForUninterruptibly(Guard guard)
/*  581:     */   {
/*  582: 751 */     if (!(guard.monitor == this & this.lock.isHeldByCurrentThread())) {
/*  583: 752 */       throw new IllegalMonitorStateException();
/*  584:     */     }
/*  585: 754 */     if (!guard.isSatisfied()) {
/*  586: 755 */       awaitUninterruptibly(guard, true);
/*  587:     */     }
/*  588:     */   }
/*  589:     */   
/*  590:     */   public boolean waitFor(Guard guard, long time, TimeUnit unit)
/*  591:     */     throws InterruptedException
/*  592:     */   {
/*  593: 767 */     long timeoutNanos = toSafeNanos(time, unit);
/*  594: 768 */     if (!(guard.monitor == this & this.lock.isHeldByCurrentThread())) {
/*  595: 769 */       throw new IllegalMonitorStateException();
/*  596:     */     }
/*  597: 771 */     if (guard.isSatisfied()) {
/*  598: 772 */       return true;
/*  599:     */     }
/*  600: 774 */     if (Thread.interrupted()) {
/*  601: 775 */       throw new InterruptedException();
/*  602:     */     }
/*  603: 777 */     return awaitNanos(guard, timeoutNanos, true);
/*  604:     */   }
/*  605:     */   
/*  606:     */   /* Error */
/*  607:     */   public boolean waitForUninterruptibly(Guard guard, long time, TimeUnit unit)
/*  608:     */   {
/*  609:     */     // Byte code:
/*  610:     */     //   0: lload_2
/*  611:     */     //   1: aload 4
/*  612:     */     //   3: invokestatic 11	com/google/common/util/concurrent/Monitor:toSafeNanos	(JLjava/util/concurrent/TimeUnit;)J
/*  613:     */     //   6: lstore 5
/*  614:     */     //   8: aload_1
/*  615:     */     //   9: getfield 21	com/google/common/util/concurrent/Monitor$Guard:monitor	Lcom/google/common/util/concurrent/Monitor;
/*  616:     */     //   12: aload_0
/*  617:     */     //   13: if_acmpne +7 -> 20
/*  618:     */     //   16: iconst_1
/*  619:     */     //   17: goto +4 -> 21
/*  620:     */     //   20: iconst_0
/*  621:     */     //   21: aload_0
/*  622:     */     //   22: getfield 2	com/google/common/util/concurrent/Monitor:lock	Ljava/util/concurrent/locks/ReentrantLock;
/*  623:     */     //   25: invokevirtual 24	java/util/concurrent/locks/ReentrantLock:isHeldByCurrentThread	()Z
/*  624:     */     //   28: iand
/*  625:     */     //   29: ifne +11 -> 40
/*  626:     */     //   32: new 22	java/lang/IllegalMonitorStateException
/*  627:     */     //   35: dup
/*  628:     */     //   36: invokespecial 23	java/lang/IllegalMonitorStateException:<init>	()V
/*  629:     */     //   39: athrow
/*  630:     */     //   40: aload_1
/*  631:     */     //   41: invokevirtual 25	com/google/common/util/concurrent/Monitor$Guard:isSatisfied	()Z
/*  632:     */     //   44: ifeq +5 -> 49
/*  633:     */     //   47: iconst_1
/*  634:     */     //   48: ireturn
/*  635:     */     //   49: iconst_1
/*  636:     */     //   50: istore 7
/*  637:     */     //   52: lload 5
/*  638:     */     //   54: invokestatic 30	com/google/common/util/concurrent/Monitor:initNanoTime	(J)J
/*  639:     */     //   57: lstore 8
/*  640:     */     //   59: invokestatic 13	java/lang/Thread:interrupted	()Z
/*  641:     */     //   62: istore 10
/*  642:     */     //   64: lload 5
/*  643:     */     //   66: lstore 11
/*  644:     */     //   68: aload_0
/*  645:     */     //   69: aload_1
/*  646:     */     //   70: lload 11
/*  647:     */     //   72: iload 7
/*  648:     */     //   74: invokespecial 31	com/google/common/util/concurrent/Monitor:awaitNanos	(Lcom/google/common/util/concurrent/Monitor$Guard;JZ)Z
/*  649:     */     //   77: istore 13
/*  650:     */     //   79: iload 10
/*  651:     */     //   81: ifeq +9 -> 90
/*  652:     */     //   84: invokestatic 17	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  653:     */     //   87: invokevirtual 18	java/lang/Thread:interrupt	()V
/*  654:     */     //   90: iload 13
/*  655:     */     //   92: ireturn
/*  656:     */     //   93: astore 13
/*  657:     */     //   95: iconst_1
/*  658:     */     //   96: istore 10
/*  659:     */     //   98: aload_1
/*  660:     */     //   99: invokevirtual 25	com/google/common/util/concurrent/Monitor$Guard:isSatisfied	()Z
/*  661:     */     //   102: ifeq +20 -> 122
/*  662:     */     //   105: iconst_1
/*  663:     */     //   106: istore 14
/*  664:     */     //   108: iload 10
/*  665:     */     //   110: ifeq +9 -> 119
/*  666:     */     //   113: invokestatic 17	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  667:     */     //   116: invokevirtual 18	java/lang/Thread:interrupt	()V
/*  668:     */     //   119: iload 14
/*  669:     */     //   121: ireturn
/*  670:     */     //   122: iconst_0
/*  671:     */     //   123: istore 7
/*  672:     */     //   125: lload 8
/*  673:     */     //   127: lload 5
/*  674:     */     //   129: invokestatic 20	com/google/common/util/concurrent/Monitor:remainingNanos	(JJ)J
/*  675:     */     //   132: lstore 11
/*  676:     */     //   134: goto -66 -> 68
/*  677:     */     //   137: astore 15
/*  678:     */     //   139: iload 10
/*  679:     */     //   141: ifeq +9 -> 150
/*  680:     */     //   144: invokestatic 17	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  681:     */     //   147: invokevirtual 18	java/lang/Thread:interrupt	()V
/*  682:     */     //   150: aload 15
/*  683:     */     //   152: athrow
/*  684:     */     // Line number table:
/*  685:     */     //   Java source line #787	-> byte code offset #0
/*  686:     */     //   Java source line #788	-> byte code offset #8
/*  687:     */     //   Java source line #789	-> byte code offset #32
/*  688:     */     //   Java source line #791	-> byte code offset #40
/*  689:     */     //   Java source line #792	-> byte code offset #47
/*  690:     */     //   Java source line #794	-> byte code offset #49
/*  691:     */     //   Java source line #795	-> byte code offset #52
/*  692:     */     //   Java source line #796	-> byte code offset #59
/*  693:     */     //   Java source line #798	-> byte code offset #64
/*  694:     */     //   Java source line #800	-> byte code offset #68
/*  695:     */     //   Java source line #811	-> byte code offset #79
/*  696:     */     //   Java source line #812	-> byte code offset #84
/*  697:     */     //   Java source line #801	-> byte code offset #93
/*  698:     */     //   Java source line #802	-> byte code offset #95
/*  699:     */     //   Java source line #803	-> byte code offset #98
/*  700:     */     //   Java source line #804	-> byte code offset #105
/*  701:     */     //   Java source line #811	-> byte code offset #108
/*  702:     */     //   Java source line #812	-> byte code offset #113
/*  703:     */     //   Java source line #806	-> byte code offset #122
/*  704:     */     //   Java source line #807	-> byte code offset #125
/*  705:     */     //   Java source line #808	-> byte code offset #134
/*  706:     */     //   Java source line #811	-> byte code offset #137
/*  707:     */     //   Java source line #812	-> byte code offset #144
/*  708:     */     // Local variable table:
/*  709:     */     //   start	length	slot	name	signature
/*  710:     */     //   0	153	0	this	Monitor
/*  711:     */     //   0	153	1	guard	Guard
/*  712:     */     //   0	153	2	time	long
/*  713:     */     //   0	153	4	unit	TimeUnit
/*  714:     */     //   6	122	5	timeoutNanos	long
/*  715:     */     //   50	74	7	signalBeforeWaiting	boolean
/*  716:     */     //   57	69	8	startTime	long
/*  717:     */     //   62	78	10	interrupted	boolean
/*  718:     */     //   66	67	11	remainingNanos	long
/*  719:     */     //   77	14	13	bool1	boolean
/*  720:     */     //   93	3	13	interrupt	InterruptedException
/*  721:     */     //   106	14	14	bool2	boolean
/*  722:     */     //   137	14	15	localObject	Object
/*  723:     */     // Exception table:
/*  724:     */     //   from	to	target	type
/*  725:     */     //   68	79	93	java/lang/InterruptedException
/*  726:     */     //   64	79	137	finally
/*  727:     */     //   93	108	137	finally
/*  728:     */     //   122	139	137	finally
/*  729:     */   }
/*  730:     */   
/*  731:     */   public void leave()
/*  732:     */   {
/*  733: 821 */     ReentrantLock lock = this.lock;
/*  734:     */     try
/*  735:     */     {
/*  736: 824 */       if (lock.getHoldCount() == 1) {
/*  737: 825 */         signalNextWaiter();
/*  738:     */       }
/*  739:     */     }
/*  740:     */     finally
/*  741:     */     {
/*  742: 828 */       lock.unlock();
/*  743:     */     }
/*  744:     */   }
/*  745:     */   
/*  746:     */   public boolean isFair()
/*  747:     */   {
/*  748: 836 */     return this.fair;
/*  749:     */   }
/*  750:     */   
/*  751:     */   public boolean isOccupied()
/*  752:     */   {
/*  753: 844 */     return this.lock.isLocked();
/*  754:     */   }
/*  755:     */   
/*  756:     */   public boolean isOccupiedByCurrentThread()
/*  757:     */   {
/*  758: 852 */     return this.lock.isHeldByCurrentThread();
/*  759:     */   }
/*  760:     */   
/*  761:     */   public int getOccupiedDepth()
/*  762:     */   {
/*  763: 860 */     return this.lock.getHoldCount();
/*  764:     */   }
/*  765:     */   
/*  766:     */   public int getQueueLength()
/*  767:     */   {
/*  768: 870 */     return this.lock.getQueueLength();
/*  769:     */   }
/*  770:     */   
/*  771:     */   public boolean hasQueuedThreads()
/*  772:     */   {
/*  773: 880 */     return this.lock.hasQueuedThreads();
/*  774:     */   }
/*  775:     */   
/*  776:     */   public boolean hasQueuedThread(Thread thread)
/*  777:     */   {
/*  778: 890 */     return this.lock.hasQueuedThread(thread);
/*  779:     */   }
/*  780:     */   
/*  781:     */   public boolean hasWaiters(Guard guard)
/*  782:     */   {
/*  783: 900 */     return getWaitQueueLength(guard) > 0;
/*  784:     */   }
/*  785:     */   
/*  786:     */   public int getWaitQueueLength(Guard guard)
/*  787:     */   {
/*  788: 910 */     if (guard.monitor != this) {
/*  789: 911 */       throw new IllegalMonitorStateException();
/*  790:     */     }
/*  791: 913 */     this.lock.lock();
/*  792:     */     try
/*  793:     */     {
/*  794: 915 */       return guard.waiterCount;
/*  795:     */     }
/*  796:     */     finally
/*  797:     */     {
/*  798: 917 */       this.lock.unlock();
/*  799:     */     }
/*  800:     */   }
/*  801:     */   
/*  802:     */   private static long toSafeNanos(long time, TimeUnit unit)
/*  803:     */   {
/*  804: 927 */     long timeoutNanos = unit.toNanos(time);
/*  805: 928 */     return timeoutNanos > 6917529027641081853L ? 6917529027641081853L : timeoutNanos <= 0L ? 0L : timeoutNanos;
/*  806:     */   }
/*  807:     */   
/*  808:     */   private static long initNanoTime(long timeoutNanos)
/*  809:     */   {
/*  810: 938 */     if (timeoutNanos <= 0L) {
/*  811: 939 */       return 0L;
/*  812:     */     }
/*  813: 941 */     long startTime = System.nanoTime();
/*  814: 942 */     return startTime == 0L ? 1L : startTime;
/*  815:     */   }
/*  816:     */   
/*  817:     */   private static long remainingNanos(long startTime, long timeoutNanos)
/*  818:     */   {
/*  819: 958 */     return timeoutNanos <= 0L ? 0L : timeoutNanos - (System.nanoTime() - startTime);
/*  820:     */   }
/*  821:     */   
/*  822:     */   @GuardedBy("lock")
/*  823:     */   private void signalNextWaiter()
/*  824:     */   {
/*  825: 987 */     for (Guard guard = this.activeGuards; guard != null; guard = guard.next) {
/*  826: 988 */       if (isSatisfied(guard))
/*  827:     */       {
/*  828: 989 */         guard.condition.signal();
/*  829: 990 */         break;
/*  830:     */       }
/*  831:     */     }
/*  832:     */   }
/*  833:     */   
/*  834:     */   @GuardedBy("lock")
/*  835:     */   private boolean isSatisfied(Guard guard)
/*  836:     */   {
/*  837:     */     try
/*  838:     */     {
/*  839:1020 */       return guard.isSatisfied();
/*  840:     */     }
/*  841:     */     catch (Throwable throwable)
/*  842:     */     {
/*  843:1022 */       signalAllWaiters();
/*  844:1023 */       throw Throwables.propagate(throwable);
/*  845:     */     }
/*  846:     */   }
/*  847:     */   
/*  848:     */   @GuardedBy("lock")
/*  849:     */   private void signalAllWaiters()
/*  850:     */   {
/*  851:1032 */     for (Guard guard = this.activeGuards; guard != null; guard = guard.next) {
/*  852:1033 */       guard.condition.signalAll();
/*  853:     */     }
/*  854:     */   }
/*  855:     */   
/*  856:     */   @GuardedBy("lock")
/*  857:     */   private void beginWaitingFor(Guard guard)
/*  858:     */   {
/*  859:1042 */     int waiters = guard.waiterCount++;
/*  860:1043 */     if (waiters == 0)
/*  861:     */     {
/*  862:1045 */       guard.next = this.activeGuards;
/*  863:1046 */       this.activeGuards = guard;
/*  864:     */     }
/*  865:     */   }
/*  866:     */   
/*  867:     */   @GuardedBy("lock")
/*  868:     */   private void endWaitingFor(Guard guard)
/*  869:     */   {
/*  870:1055 */     int waiters = --guard.waiterCount;
/*  871:1056 */     if (waiters == 0)
/*  872:     */     {
/*  873:1058 */       Guard p = this.activeGuards;
/*  874:1058 */       for (Guard pred = null;; p = p.next)
/*  875:     */       {
/*  876:1059 */         if (p == guard)
/*  877:     */         {
/*  878:1060 */           if (pred == null) {
/*  879:1061 */             this.activeGuards = p.next;
/*  880:     */           } else {
/*  881:1063 */             pred.next = p.next;
/*  882:     */           }
/*  883:1065 */           p.next = null;
/*  884:1066 */           break;
/*  885:     */         }
/*  886:1058 */         pred = p;
/*  887:     */       }
/*  888:     */     }
/*  889:     */   }
/*  890:     */   
/*  891:     */   @GuardedBy("lock")
/*  892:     */   private void await(Guard guard, boolean signalBeforeWaiting)
/*  893:     */     throws InterruptedException
/*  894:     */   {
/*  895:1081 */     if (signalBeforeWaiting) {
/*  896:1082 */       signalNextWaiter();
/*  897:     */     }
/*  898:1084 */     beginWaitingFor(guard);
/*  899:     */     try
/*  900:     */     {
/*  901:     */       do
/*  902:     */       {
/*  903:1087 */         guard.condition.await();
/*  904:1088 */       } while (!guard.isSatisfied());
/*  905:     */     }
/*  906:     */     finally
/*  907:     */     {
/*  908:1090 */       endWaitingFor(guard);
/*  909:     */     }
/*  910:     */   }
/*  911:     */   
/*  912:     */   @GuardedBy("lock")
/*  913:     */   private void awaitUninterruptibly(Guard guard, boolean signalBeforeWaiting)
/*  914:     */   {
/*  915:1096 */     if (signalBeforeWaiting) {
/*  916:1097 */       signalNextWaiter();
/*  917:     */     }
/*  918:1099 */     beginWaitingFor(guard);
/*  919:     */     try
/*  920:     */     {
/*  921:     */       do
/*  922:     */       {
/*  923:1102 */         guard.condition.awaitUninterruptibly();
/*  924:1103 */       } while (!guard.isSatisfied());
/*  925:     */     }
/*  926:     */     finally
/*  927:     */     {
/*  928:1105 */       endWaitingFor(guard);
/*  929:     */     }
/*  930:     */   }
/*  931:     */   
/*  932:     */   @GuardedBy("lock")
/*  933:     */   private boolean awaitNanos(Guard guard, long nanos, boolean signalBeforeWaiting)
/*  934:     */     throws InterruptedException
/*  935:     */   {
/*  936:1115 */     boolean firstTime = true;
/*  937:     */     try
/*  938:     */     {
/*  939:     */       boolean bool1;
/*  940:     */       do
/*  941:     */       {
/*  942:1118 */         if (nanos <= 0L) {
/*  943:1119 */           return false;
/*  944:     */         }
/*  945:1121 */         if (firstTime)
/*  946:     */         {
/*  947:1122 */           if (signalBeforeWaiting) {
/*  948:1123 */             signalNextWaiter();
/*  949:     */           }
/*  950:1125 */           beginWaitingFor(guard);
/*  951:1126 */           firstTime = false;
/*  952:     */         }
/*  953:1128 */         nanos = guard.condition.awaitNanos(nanos);
/*  954:1129 */       } while (!guard.isSatisfied());
/*  955:1130 */       return true;
/*  956:     */     }
/*  957:     */     finally
/*  958:     */     {
/*  959:1132 */       if (!firstTime) {
/*  960:1133 */         endWaitingFor(guard);
/*  961:     */       }
/*  962:     */     }
/*  963:     */   }
/*  964:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.Monitor
 * JD-Core Version:    0.7.0.1
 */