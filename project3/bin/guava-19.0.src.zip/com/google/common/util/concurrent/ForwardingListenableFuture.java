/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import java.util.concurrent.Executor;
/*  5:   */ 
/*  6:   */ public abstract class ForwardingListenableFuture<V>
/*  7:   */   extends ForwardingFuture<V>
/*  8:   */   implements ListenableFuture<V>
/*  9:   */ {
/* 10:   */   protected abstract ListenableFuture<V> delegate();
/* 11:   */   
/* 12:   */   public void addListener(Runnable listener, Executor exec)
/* 13:   */   {
/* 14:47 */     delegate().addListener(listener, exec);
/* 15:   */   }
/* 16:   */   
/* 17:   */   public static abstract class SimpleForwardingListenableFuture<V>
/* 18:   */     extends ForwardingListenableFuture<V>
/* 19:   */   {
/* 20:   */     private final ListenableFuture<V> delegate;
/* 21:   */     
/* 22:   */     protected SimpleForwardingListenableFuture(ListenableFuture<V> delegate)
/* 23:   */     {
/* 24:66 */       this.delegate = ((ListenableFuture)Preconditions.checkNotNull(delegate));
/* 25:   */     }
/* 26:   */     
/* 27:   */     protected final ListenableFuture<V> delegate()
/* 28:   */     {
/* 29:71 */       return this.delegate;
/* 30:   */     }
/* 31:   */   }
/* 32:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ForwardingListenableFuture
 * JD-Core Version:    0.7.0.1
 */