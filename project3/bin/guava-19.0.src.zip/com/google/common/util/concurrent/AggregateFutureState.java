/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import com.google.common.collect.Sets;
/*  5:   */ import java.util.Set;
/*  6:   */ import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
/*  7:   */ import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
/*  8:   */ 
/*  9:   */ @GwtCompatible(emulated=true)
/* 10:   */ abstract class AggregateFutureState
/* 11:   */ {
/* 12:39 */   private static final AtomicReferenceFieldUpdater<AggregateFutureState, Set<Throwable>> SEEN_EXCEPTIONS_UDPATER = AtomicReferenceFieldUpdater.newUpdater(AggregateFutureState.class, Set.class, "seenExceptions");
/* 13:43 */   private static final AtomicIntegerFieldUpdater<AggregateFutureState> REMAINING_COUNT_UPDATER = AtomicIntegerFieldUpdater.newUpdater(AggregateFutureState.class, "remaining");
/* 14:47 */   private volatile Set<Throwable> seenExceptions = null;
/* 15:   */   private volatile int remaining;
/* 16:   */   
/* 17:   */   AggregateFutureState(int remainingFutures)
/* 18:   */   {
/* 19:51 */     this.remaining = remainingFutures;
/* 20:   */   }
/* 21:   */   
/* 22:   */   final Set<Throwable> getOrInitSeenExceptions()
/* 23:   */   {
/* 24:71 */     Set<Throwable> seenExceptionsLocal = this.seenExceptions;
/* 25:72 */     if (seenExceptionsLocal == null)
/* 26:   */     {
/* 27:73 */       seenExceptionsLocal = Sets.newConcurrentHashSet();
/* 28:   */       
/* 29:   */ 
/* 30:   */ 
/* 31:   */ 
/* 32:   */ 
/* 33:79 */       addInitialException(seenExceptionsLocal);
/* 34:   */       
/* 35:81 */       SEEN_EXCEPTIONS_UDPATER.compareAndSet(this, null, seenExceptionsLocal);
/* 36:   */       
/* 37:   */ 
/* 38:   */ 
/* 39:   */ 
/* 40:   */ 
/* 41:   */ 
/* 42:88 */       seenExceptionsLocal = this.seenExceptions;
/* 43:   */     }
/* 44:90 */     return seenExceptionsLocal;
/* 45:   */   }
/* 46:   */   
/* 47:   */   abstract void addInitialException(Set<Throwable> paramSet);
/* 48:   */   
/* 49:   */   final int decrementRemainingAndGet()
/* 50:   */   {
/* 51:97 */     return REMAINING_COUNT_UPDATER.decrementAndGet(this);
/* 52:   */   }
/* 53:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AggregateFutureState
 * JD-Core Version:    0.7.0.1
 */