/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import java.util.concurrent.CancellationException;
/*   5:    */ import java.util.concurrent.ExecutionException;
/*   6:    */ import java.util.concurrent.TimeUnit;
/*   7:    */ import java.util.concurrent.TimeoutException;
/*   8:    */ 
/*   9:    */ @Beta
/*  10:    */ public abstract class AbstractCheckedFuture<V, X extends Exception>
/*  11:    */   extends ForwardingListenableFuture.SimpleForwardingListenableFuture<V>
/*  12:    */   implements CheckedFuture<V, X>
/*  13:    */ {
/*  14:    */   protected AbstractCheckedFuture(ListenableFuture<V> delegate)
/*  15:    */   {
/*  16: 41 */     super(delegate);
/*  17:    */   }
/*  18:    */   
/*  19:    */   protected abstract X mapException(Exception paramException);
/*  20:    */   
/*  21:    */   public V checkedGet()
/*  22:    */     throws Exception
/*  23:    */   {
/*  24:    */     try
/*  25:    */     {
/*  26: 78 */       return get();
/*  27:    */     }
/*  28:    */     catch (InterruptedException e)
/*  29:    */     {
/*  30: 80 */       Thread.currentThread().interrupt();
/*  31: 81 */       throw mapException(e);
/*  32:    */     }
/*  33:    */     catch (CancellationException e)
/*  34:    */     {
/*  35: 83 */       throw mapException(e);
/*  36:    */     }
/*  37:    */     catch (ExecutionException e)
/*  38:    */     {
/*  39: 85 */       throw mapException(e);
/*  40:    */     }
/*  41:    */   }
/*  42:    */   
/*  43:    */   public V checkedGet(long timeout, TimeUnit unit)
/*  44:    */     throws TimeoutException, Exception
/*  45:    */   {
/*  46:    */     try
/*  47:    */     {
/*  48:107 */       return get(timeout, unit);
/*  49:    */     }
/*  50:    */     catch (InterruptedException e)
/*  51:    */     {
/*  52:109 */       Thread.currentThread().interrupt();
/*  53:110 */       throw mapException(e);
/*  54:    */     }
/*  55:    */     catch (CancellationException e)
/*  56:    */     {
/*  57:112 */       throw mapException(e);
/*  58:    */     }
/*  59:    */     catch (ExecutionException e)
/*  60:    */     {
/*  61:114 */       throw mapException(e);
/*  62:    */     }
/*  63:    */   }
/*  64:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractCheckedFuture
 * JD-Core Version:    0.7.0.1
 */