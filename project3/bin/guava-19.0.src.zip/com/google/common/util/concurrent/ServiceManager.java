/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.MoreObjects;
/*   6:    */ import com.google.common.base.MoreObjects.ToStringHelper;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Predicates;
/*   9:    */ import com.google.common.base.Stopwatch;
/*  10:    */ import com.google.common.collect.Collections2;
/*  11:    */ import com.google.common.collect.ImmutableCollection;
/*  12:    */ import com.google.common.collect.ImmutableList;
/*  13:    */ import com.google.common.collect.ImmutableMap;
/*  14:    */ import com.google.common.collect.ImmutableMultimap;
/*  15:    */ import com.google.common.collect.ImmutableSet;
/*  16:    */ import com.google.common.collect.ImmutableSetMultimap;
/*  17:    */ import com.google.common.collect.ImmutableSetMultimap.Builder;
/*  18:    */ import com.google.common.collect.Lists;
/*  19:    */ import com.google.common.collect.Maps;
/*  20:    */ import com.google.common.collect.MultimapBuilder;
/*  21:    */ import com.google.common.collect.MultimapBuilder.MultimapBuilderWithKeys;
/*  22:    */ import com.google.common.collect.MultimapBuilder.SetMultimapBuilder;
/*  23:    */ import com.google.common.collect.Multimaps;
/*  24:    */ import com.google.common.collect.Multiset;
/*  25:    */ import com.google.common.collect.Ordering;
/*  26:    */ import com.google.common.collect.SetMultimap;
/*  27:    */ import java.lang.ref.WeakReference;
/*  28:    */ import java.util.ArrayList;
/*  29:    */ import java.util.Collections;
/*  30:    */ import java.util.EnumSet;
/*  31:    */ import java.util.List;
/*  32:    */ import java.util.Map;
/*  33:    */ import java.util.Map.Entry;
/*  34:    */ import java.util.concurrent.Executor;
/*  35:    */ import java.util.concurrent.TimeUnit;
/*  36:    */ import java.util.concurrent.TimeoutException;
/*  37:    */ import java.util.logging.Level;
/*  38:    */ import java.util.logging.Logger;
/*  39:    */ import javax.annotation.concurrent.GuardedBy;
/*  40:    */ 
/*  41:    */ @Beta
/*  42:    */ public final class ServiceManager
/*  43:    */ {
/*  44:125 */   private static final Logger logger = Logger.getLogger(ServiceManager.class.getName());
/*  45:126 */   private static final ListenerCallQueue.Callback<Listener> HEALTHY_CALLBACK = new ListenerCallQueue.Callback("healthy()")
/*  46:    */   {
/*  47:    */     void call(ServiceManager.Listener listener)
/*  48:    */     {
/*  49:128 */       listener.healthy();
/*  50:    */     }
/*  51:    */   };
/*  52:131 */   private static final ListenerCallQueue.Callback<Listener> STOPPED_CALLBACK = new ListenerCallQueue.Callback("stopped()")
/*  53:    */   {
/*  54:    */     void call(ServiceManager.Listener listener)
/*  55:    */     {
/*  56:133 */       listener.stopped();
/*  57:    */     }
/*  58:    */   };
/*  59:    */   private final ServiceManagerState state;
/*  60:    */   private final ImmutableList<Service> services;
/*  61:    */   
/*  62:    */   public ServiceManager(Iterable<? extends Service> services)
/*  63:    */   {
/*  64:191 */     ImmutableList<Service> copy = ImmutableList.copyOf(services);
/*  65:192 */     if (copy.isEmpty())
/*  66:    */     {
/*  67:195 */       logger.log(Level.WARNING, "ServiceManager configured with no services.  Is your application configured properly?", new EmptyServiceManagerWarning(null));
/*  68:    */       
/*  69:    */ 
/*  70:198 */       copy = ImmutableList.of(new NoOpService(null));
/*  71:    */     }
/*  72:200 */     this.state = new ServiceManagerState(copy);
/*  73:201 */     this.services = copy;
/*  74:202 */     WeakReference<ServiceManagerState> stateReference = new WeakReference(this.state);
/*  75:204 */     for (Service service : copy)
/*  76:    */     {
/*  77:205 */       service.addListener(new ServiceListener(service, stateReference), MoreExecutors.directExecutor());
/*  78:    */       
/*  79:    */ 
/*  80:208 */       Preconditions.checkArgument(service.state() == Service.State.NEW, "Can only manage NEW services, %s", new Object[] { service });
/*  81:    */     }
/*  82:212 */     this.state.markReady();
/*  83:    */   }
/*  84:    */   
/*  85:    */   public void addListener(Listener listener, Executor executor)
/*  86:    */   {
/*  87:239 */     this.state.addListener(listener, executor);
/*  88:    */   }
/*  89:    */   
/*  90:    */   public void addListener(Listener listener)
/*  91:    */   {
/*  92:259 */     this.state.addListener(listener, MoreExecutors.directExecutor());
/*  93:    */   }
/*  94:    */   
/*  95:    */   public ServiceManager startAsync()
/*  96:    */   {
/*  97:271 */     for (Service service : this.services)
/*  98:    */     {
/*  99:272 */       Service.State state = service.state();
/* 100:273 */       Preconditions.checkState(state == Service.State.NEW, "Service %s is %s, cannot start it.", new Object[] { service, state });
/* 101:    */     }
/* 102:275 */     for (Service service : this.services) {
/* 103:    */       try
/* 104:    */       {
/* 105:277 */         this.state.tryStartTiming(service);
/* 106:278 */         service.startAsync();
/* 107:    */       }
/* 108:    */       catch (IllegalStateException e)
/* 109:    */       {
/* 110:284 */         logger.log(Level.WARNING, "Unable to start Service " + service, e);
/* 111:    */       }
/* 112:    */     }
/* 113:287 */     return this;
/* 114:    */   }
/* 115:    */   
/* 116:    */   public void awaitHealthy()
/* 117:    */   {
/* 118:299 */     this.state.awaitHealthy();
/* 119:    */   }
/* 120:    */   
/* 121:    */   public void awaitHealthy(long timeout, TimeUnit unit)
/* 122:    */     throws TimeoutException
/* 123:    */   {
/* 124:314 */     this.state.awaitHealthy(timeout, unit);
/* 125:    */   }
/* 126:    */   
/* 127:    */   public ServiceManager stopAsync()
/* 128:    */   {
/* 129:324 */     for (Service service : this.services) {
/* 130:325 */       service.stopAsync();
/* 131:    */     }
/* 132:327 */     return this;
/* 133:    */   }
/* 134:    */   
/* 135:    */   public void awaitStopped()
/* 136:    */   {
/* 137:336 */     this.state.awaitStopped();
/* 138:    */   }
/* 139:    */   
/* 140:    */   public void awaitStopped(long timeout, TimeUnit unit)
/* 141:    */     throws TimeoutException
/* 142:    */   {
/* 143:349 */     this.state.awaitStopped(timeout, unit);
/* 144:    */   }
/* 145:    */   
/* 146:    */   public boolean isHealthy()
/* 147:    */   {
/* 148:359 */     for (Service service : this.services) {
/* 149:360 */       if (!service.isRunning()) {
/* 150:361 */         return false;
/* 151:    */       }
/* 152:    */     }
/* 153:364 */     return true;
/* 154:    */   }
/* 155:    */   
/* 156:    */   public ImmutableMultimap<Service.State, Service> servicesByState()
/* 157:    */   {
/* 158:374 */     return this.state.servicesByState();
/* 159:    */   }
/* 160:    */   
/* 161:    */   public ImmutableMap<Service, Long> startupTimes()
/* 162:    */   {
/* 163:385 */     return this.state.startupTimes();
/* 164:    */   }
/* 165:    */   
/* 166:    */   public String toString()
/* 167:    */   {
/* 168:389 */     return MoreObjects.toStringHelper(ServiceManager.class).add("services", Collections2.filter(this.services, Predicates.not(Predicates.instanceOf(NoOpService.class)))).toString();
/* 169:    */   }
/* 170:    */   
/* 171:    */   @Beta
/* 172:    */   public static abstract class Listener
/* 173:    */   {
/* 174:    */     public void healthy() {}
/* 175:    */     
/* 176:    */     public void stopped() {}
/* 177:    */     
/* 178:    */     public void failure(Service service) {}
/* 179:    */   }
/* 180:    */   
/* 181:    */   private static final class ServiceManagerState
/* 182:    */   {
/* 183:399 */     final Monitor monitor = new Monitor();
/* 184:    */     @GuardedBy("monitor")
/* 185:401 */     final SetMultimap<Service.State, Service> servicesByState = MultimapBuilder.enumKeys(Service.State.class).linkedHashSetValues().build();
/* 186:    */     @GuardedBy("monitor")
/* 187:405 */     final Multiset<Service.State> states = this.servicesByState.keys();
/* 188:    */     @GuardedBy("monitor")
/* 189:408 */     final Map<Service, Stopwatch> startupTimers = Maps.newIdentityHashMap();
/* 190:    */     @GuardedBy("monitor")
/* 191:    */     boolean ready;
/* 192:    */     @GuardedBy("monitor")
/* 193:    */     boolean transitioned;
/* 194:    */     final int numberOfServices;
/* 195:434 */     final Monitor.Guard awaitHealthGuard = new AwaitHealthGuard();
/* 196:    */     
/* 197:    */     final class AwaitHealthGuard
/* 198:    */       extends Monitor.Guard
/* 199:    */     {
/* 200:    */       AwaitHealthGuard()
/* 201:    */       {
/* 202:439 */         super();
/* 203:    */       }
/* 204:    */       
/* 205:    */       public boolean isSatisfied()
/* 206:    */       {
/* 207:444 */         return (ServiceManager.ServiceManagerState.this.states.count(Service.State.RUNNING) == ServiceManager.ServiceManagerState.this.numberOfServices) || (ServiceManager.ServiceManagerState.this.states.contains(Service.State.STOPPING)) || (ServiceManager.ServiceManagerState.this.states.contains(Service.State.TERMINATED)) || (ServiceManager.ServiceManagerState.this.states.contains(Service.State.FAILED));
/* 208:    */       }
/* 209:    */     }
/* 210:    */     
/* 211:454 */     final Monitor.Guard stoppedGuard = new StoppedGuard();
/* 212:    */     
/* 213:    */     final class StoppedGuard
/* 214:    */       extends Monitor.Guard
/* 215:    */     {
/* 216:    */       StoppedGuard()
/* 217:    */       {
/* 218:459 */         super();
/* 219:    */       }
/* 220:    */       
/* 221:    */       public boolean isSatisfied()
/* 222:    */       {
/* 223:463 */         return ServiceManager.ServiceManagerState.this.states.count(Service.State.TERMINATED) + ServiceManager.ServiceManagerState.this.states.count(Service.State.FAILED) == ServiceManager.ServiceManagerState.this.numberOfServices;
/* 224:    */       }
/* 225:    */     }
/* 226:    */     
/* 227:    */     @GuardedBy("monitor")
/* 228:468 */     final List<ListenerCallQueue<ServiceManager.Listener>> listeners = Collections.synchronizedList(new ArrayList());
/* 229:    */     
/* 230:    */     ServiceManagerState(ImmutableCollection<Service> services)
/* 231:    */     {
/* 232:479 */       this.numberOfServices = services.size();
/* 233:480 */       this.servicesByState.putAll(Service.State.NEW, services);
/* 234:    */     }
/* 235:    */     
/* 236:    */     void tryStartTiming(Service service)
/* 237:    */     {
/* 238:488 */       this.monitor.enter();
/* 239:    */       try
/* 240:    */       {
/* 241:490 */         Stopwatch stopwatch = (Stopwatch)this.startupTimers.get(service);
/* 242:491 */         if (stopwatch == null) {
/* 243:492 */           this.startupTimers.put(service, Stopwatch.createStarted());
/* 244:    */         }
/* 245:    */       }
/* 246:    */       finally
/* 247:    */       {
/* 248:495 */         this.monitor.leave();
/* 249:    */       }
/* 250:    */     }
/* 251:    */     
/* 252:    */     void markReady()
/* 253:    */     {
/* 254:504 */       this.monitor.enter();
/* 255:    */       try
/* 256:    */       {
/* 257:506 */         if (!this.transitioned)
/* 258:    */         {
/* 259:508 */           this.ready = true;
/* 260:    */         }
/* 261:    */         else
/* 262:    */         {
/* 263:511 */           List<Service> servicesInBadStates = Lists.newArrayList();
/* 264:512 */           for (Service service : servicesByState().values()) {
/* 265:513 */             if (service.state() != Service.State.NEW) {
/* 266:514 */               servicesInBadStates.add(service);
/* 267:    */             }
/* 268:    */           }
/* 269:517 */           throw new IllegalArgumentException("Services started transitioning asynchronously before the ServiceManager was constructed: " + servicesInBadStates);
/* 270:    */         }
/* 271:    */       }
/* 272:    */       finally
/* 273:    */       {
/* 274:521 */         this.monitor.leave();
/* 275:    */       }
/* 276:    */     }
/* 277:    */     
/* 278:    */     void addListener(ServiceManager.Listener listener, Executor executor)
/* 279:    */     {
/* 280:526 */       Preconditions.checkNotNull(listener, "listener");
/* 281:527 */       Preconditions.checkNotNull(executor, "executor");
/* 282:528 */       this.monitor.enter();
/* 283:    */       try
/* 284:    */       {
/* 285:531 */         if (!this.stoppedGuard.isSatisfied()) {
/* 286:532 */           this.listeners.add(new ListenerCallQueue(listener, executor));
/* 287:    */         }
/* 288:    */       }
/* 289:    */       finally
/* 290:    */       {
/* 291:535 */         this.monitor.leave();
/* 292:    */       }
/* 293:    */     }
/* 294:    */     
/* 295:    */     void awaitHealthy()
/* 296:    */     {
/* 297:540 */       this.monitor.enterWhenUninterruptibly(this.awaitHealthGuard);
/* 298:    */       try
/* 299:    */       {
/* 300:542 */         checkHealthy();
/* 301:    */       }
/* 302:    */       finally
/* 303:    */       {
/* 304:544 */         this.monitor.leave();
/* 305:    */       }
/* 306:    */     }
/* 307:    */     
/* 308:    */     void awaitHealthy(long timeout, TimeUnit unit)
/* 309:    */       throws TimeoutException
/* 310:    */     {
/* 311:549 */       this.monitor.enter();
/* 312:    */       try
/* 313:    */       {
/* 314:551 */         if (!this.monitor.waitForUninterruptibly(this.awaitHealthGuard, timeout, unit)) {
/* 315:552 */           throw new TimeoutException("Timeout waiting for the services to become healthy. The following services have not started: " + Multimaps.filterKeys(this.servicesByState, Predicates.in(ImmutableSet.of(Service.State.NEW, Service.State.STARTING))));
/* 316:    */         }
/* 317:556 */         checkHealthy();
/* 318:    */       }
/* 319:    */       finally
/* 320:    */       {
/* 321:558 */         this.monitor.leave();
/* 322:    */       }
/* 323:    */     }
/* 324:    */     
/* 325:    */     void awaitStopped()
/* 326:    */     {
/* 327:563 */       this.monitor.enterWhenUninterruptibly(this.stoppedGuard);
/* 328:564 */       this.monitor.leave();
/* 329:    */     }
/* 330:    */     
/* 331:    */     void awaitStopped(long timeout, TimeUnit unit)
/* 332:    */       throws TimeoutException
/* 333:    */     {
/* 334:568 */       this.monitor.enter();
/* 335:    */       try
/* 336:    */       {
/* 337:570 */         if (!this.monitor.waitForUninterruptibly(this.stoppedGuard, timeout, unit)) {
/* 338:571 */           throw new TimeoutException("Timeout waiting for the services to stop. The following services have not stopped: " + Multimaps.filterKeys(this.servicesByState, Predicates.not(Predicates.in(EnumSet.of(Service.State.TERMINATED, Service.State.FAILED)))));
/* 339:    */         }
/* 340:    */       }
/* 341:    */       finally
/* 342:    */       {
/* 343:577 */         this.monitor.leave();
/* 344:    */       }
/* 345:    */     }
/* 346:    */     
/* 347:    */     ImmutableMultimap<Service.State, Service> servicesByState()
/* 348:    */     {
/* 349:582 */       ImmutableSetMultimap.Builder<Service.State, Service> builder = ImmutableSetMultimap.builder();
/* 350:583 */       this.monitor.enter();
/* 351:    */       try
/* 352:    */       {
/* 353:585 */         for (Map.Entry<Service.State, Service> entry : this.servicesByState.entries()) {
/* 354:586 */           if (!(entry.getValue() instanceof ServiceManager.NoOpService)) {
/* 355:587 */             builder.put(entry);
/* 356:    */           }
/* 357:    */         }
/* 358:    */       }
/* 359:    */       finally
/* 360:    */       {
/* 361:591 */         this.monitor.leave();
/* 362:    */       }
/* 363:593 */       return builder.build();
/* 364:    */     }
/* 365:    */     
/* 366:    */     ImmutableMap<Service, Long> startupTimes()
/* 367:    */     {
/* 368:598 */       this.monitor.enter();
/* 369:    */       List<Map.Entry<Service, Long>> loadTimes;
/* 370:    */       try
/* 371:    */       {
/* 372:600 */         loadTimes = Lists.newArrayListWithCapacity(this.startupTimers.size());
/* 373:602 */         for (Map.Entry<Service, Stopwatch> entry : this.startupTimers.entrySet())
/* 374:    */         {
/* 375:603 */           Service service = (Service)entry.getKey();
/* 376:604 */           Stopwatch stopWatch = (Stopwatch)entry.getValue();
/* 377:605 */           if ((!stopWatch.isRunning()) && (!(service instanceof ServiceManager.NoOpService))) {
/* 378:606 */             loadTimes.add(Maps.immutableEntry(service, Long.valueOf(stopWatch.elapsed(TimeUnit.MILLISECONDS))));
/* 379:    */           }
/* 380:    */         }
/* 381:    */       }
/* 382:    */       finally
/* 383:    */       {
/* 384:610 */         this.monitor.leave();
/* 385:    */       }
/* 386:612 */       Collections.sort(loadTimes, Ordering.natural().onResultOf(new Function()
/* 387:    */       {
/* 388:    */         public Long apply(Map.Entry<Service, Long> input)
/* 389:    */         {
/* 390:615 */           return (Long)input.getValue();
/* 391:    */         }
/* 392:617 */       }));
/* 393:618 */       return ImmutableMap.copyOf(loadTimes);
/* 394:    */     }
/* 395:    */     
/* 396:    */     void transitionService(Service service, Service.State from, Service.State to)
/* 397:    */     {
/* 398:633 */       Preconditions.checkNotNull(service);
/* 399:634 */       Preconditions.checkArgument(from != to);
/* 400:635 */       this.monitor.enter();
/* 401:    */       try
/* 402:    */       {
/* 403:637 */         this.transitioned = true;
/* 404:638 */         if (!this.ready) {
/* 405:    */           return;
/* 406:    */         }
/* 407:642 */         Preconditions.checkState(this.servicesByState.remove(from, service), "Service %s not at the expected location in the state map %s", new Object[] { service, from });
/* 408:    */         
/* 409:644 */         Preconditions.checkState(this.servicesByState.put(to, service), "Service %s in the state map unexpectedly at %s", new Object[] { service, to });
/* 410:    */         
/* 411:    */ 
/* 412:647 */         Stopwatch stopwatch = (Stopwatch)this.startupTimers.get(service);
/* 413:648 */         if (stopwatch == null)
/* 414:    */         {
/* 415:650 */           stopwatch = Stopwatch.createStarted();
/* 416:651 */           this.startupTimers.put(service, stopwatch);
/* 417:    */         }
/* 418:653 */         if ((to.compareTo(Service.State.RUNNING) >= 0) && (stopwatch.isRunning()))
/* 419:    */         {
/* 420:655 */           stopwatch.stop();
/* 421:656 */           if (!(service instanceof ServiceManager.NoOpService)) {
/* 422:657 */             ServiceManager.logger.log(Level.FINE, "Started {0} in {1}.", new Object[] { service, stopwatch });
/* 423:    */           }
/* 424:    */         }
/* 425:663 */         if (to == Service.State.FAILED) {
/* 426:664 */           fireFailedListeners(service);
/* 427:    */         }
/* 428:667 */         if (this.states.count(Service.State.RUNNING) == this.numberOfServices) {
/* 429:670 */           fireHealthyListeners();
/* 430:671 */         } else if (this.states.count(Service.State.TERMINATED) + this.states.count(Service.State.FAILED) == this.numberOfServices) {
/* 431:672 */           fireStoppedListeners();
/* 432:    */         }
/* 433:    */       }
/* 434:    */       finally
/* 435:    */       {
/* 436:675 */         this.monitor.leave();
/* 437:    */         
/* 438:677 */         executeListeners();
/* 439:    */       }
/* 440:    */     }
/* 441:    */     
/* 442:    */     @GuardedBy("monitor")
/* 443:    */     void fireStoppedListeners()
/* 444:    */     {
/* 445:683 */       ServiceManager.STOPPED_CALLBACK.enqueueOn(this.listeners);
/* 446:    */     }
/* 447:    */     
/* 448:    */     @GuardedBy("monitor")
/* 449:    */     void fireHealthyListeners()
/* 450:    */     {
/* 451:688 */       ServiceManager.HEALTHY_CALLBACK.enqueueOn(this.listeners);
/* 452:    */     }
/* 453:    */     
/* 454:    */     @GuardedBy("monitor")
/* 455:    */     void fireFailedListeners(final Service service)
/* 456:    */     {
/* 457:693 */       new ListenerCallQueue.Callback("failed({service=" + service + "})")
/* 458:    */       {
/* 459:    */         void call(ServiceManager.Listener listener)
/* 460:    */         {
/* 461:695 */           listener.failure(service);
/* 462:    */         }
/* 463:695 */       }.enqueueOn(this.listeners);
/* 464:    */     }
/* 465:    */     
/* 466:    */     void executeListeners()
/* 467:    */     {
/* 468:702 */       Preconditions.checkState(!this.monitor.isOccupiedByCurrentThread(), "It is incorrect to execute listeners with the monitor held.");
/* 469:705 */       for (int i = 0; i < this.listeners.size(); i++) {
/* 470:706 */         ((ListenerCallQueue)this.listeners.get(i)).execute();
/* 471:    */       }
/* 472:    */     }
/* 473:    */     
/* 474:    */     @GuardedBy("monitor")
/* 475:    */     void checkHealthy()
/* 476:    */     {
/* 477:712 */       if (this.states.count(Service.State.RUNNING) != this.numberOfServices)
/* 478:    */       {
/* 479:713 */         IllegalStateException exception = new IllegalStateException("Expected to be healthy after starting. The following services are not running: " + Multimaps.filterKeys(this.servicesByState, Predicates.not(Predicates.equalTo(Service.State.RUNNING))));
/* 480:    */         
/* 481:    */ 
/* 482:716 */         throw exception;
/* 483:    */       }
/* 484:    */     }
/* 485:    */   }
/* 486:    */   
/* 487:    */   private static final class ServiceListener
/* 488:    */     extends Service.Listener
/* 489:    */   {
/* 490:    */     final Service service;
/* 491:    */     final WeakReference<ServiceManager.ServiceManagerState> state;
/* 492:    */     
/* 493:    */     ServiceListener(Service service, WeakReference<ServiceManager.ServiceManagerState> state)
/* 494:    */     {
/* 495:733 */       this.service = service;
/* 496:734 */       this.state = state;
/* 497:    */     }
/* 498:    */     
/* 499:    */     public void starting()
/* 500:    */     {
/* 501:738 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 502:739 */       if (state != null)
/* 503:    */       {
/* 504:740 */         state.transitionService(this.service, Service.State.NEW, Service.State.STARTING);
/* 505:741 */         if (!(this.service instanceof ServiceManager.NoOpService)) {
/* 506:742 */           ServiceManager.logger.log(Level.FINE, "Starting {0}.", this.service);
/* 507:    */         }
/* 508:    */       }
/* 509:    */     }
/* 510:    */     
/* 511:    */     public void running()
/* 512:    */     {
/* 513:748 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 514:749 */       if (state != null) {
/* 515:750 */         state.transitionService(this.service, Service.State.STARTING, Service.State.RUNNING);
/* 516:    */       }
/* 517:    */     }
/* 518:    */     
/* 519:    */     public void stopping(Service.State from)
/* 520:    */     {
/* 521:755 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 522:756 */       if (state != null) {
/* 523:757 */         state.transitionService(this.service, from, Service.State.STOPPING);
/* 524:    */       }
/* 525:    */     }
/* 526:    */     
/* 527:    */     public void terminated(Service.State from)
/* 528:    */     {
/* 529:762 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 530:763 */       if (state != null)
/* 531:    */       {
/* 532:764 */         if (!(this.service instanceof ServiceManager.NoOpService)) {
/* 533:765 */           ServiceManager.logger.log(Level.FINE, "Service {0} has terminated. Previous state was: {1}", new Object[] { this.service, from });
/* 534:    */         }
/* 535:768 */         state.transitionService(this.service, from, Service.State.TERMINATED);
/* 536:    */       }
/* 537:    */     }
/* 538:    */     
/* 539:    */     public void failed(Service.State from, Throwable failure)
/* 540:    */     {
/* 541:773 */       ServiceManager.ServiceManagerState state = (ServiceManager.ServiceManagerState)this.state.get();
/* 542:774 */       if (state != null)
/* 543:    */       {
/* 544:777 */         if (!(this.service instanceof ServiceManager.NoOpService)) {
/* 545:778 */           ServiceManager.logger.log(Level.SEVERE, "Service " + this.service + " has failed in the " + from + " state.", failure);
/* 546:    */         }
/* 547:781 */         state.transitionService(this.service, from, Service.State.FAILED);
/* 548:    */       }
/* 549:    */     }
/* 550:    */   }
/* 551:    */   
/* 552:    */   private static final class NoOpService
/* 553:    */     extends AbstractService
/* 554:    */   {
/* 555:    */     protected void doStart()
/* 556:    */     {
/* 557:795 */       notifyStarted();
/* 558:    */     }
/* 559:    */     
/* 560:    */     protected void doStop()
/* 561:    */     {
/* 562:796 */       notifyStopped();
/* 563:    */     }
/* 564:    */   }
/* 565:    */   
/* 566:    */   private static final class EmptyServiceManagerWarning
/* 567:    */     extends Throwable
/* 568:    */   {}
/* 569:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ServiceManager
 * JD-Core Version:    0.7.0.1
 */