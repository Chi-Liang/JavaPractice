/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.util.Locale;
/*   5:    */ import java.util.concurrent.Executors;
/*   6:    */ import java.util.concurrent.ThreadFactory;
/*   7:    */ import java.util.concurrent.atomic.AtomicLong;
/*   8:    */ 
/*   9:    */ public final class ThreadFactoryBuilder
/*  10:    */ {
/*  11: 47 */   private String nameFormat = null;
/*  12: 48 */   private Boolean daemon = null;
/*  13: 49 */   private Integer priority = null;
/*  14: 50 */   private Thread.UncaughtExceptionHandler uncaughtExceptionHandler = null;
/*  15: 51 */   private ThreadFactory backingThreadFactory = null;
/*  16:    */   
/*  17:    */   public ThreadFactoryBuilder setNameFormat(String nameFormat)
/*  18:    */   {
/*  19: 71 */     String unused = format(nameFormat, new Object[] { Integer.valueOf(0) });
/*  20: 72 */     this.nameFormat = nameFormat;
/*  21: 73 */     return this;
/*  22:    */   }
/*  23:    */   
/*  24:    */   public ThreadFactoryBuilder setDaemon(boolean daemon)
/*  25:    */   {
/*  26: 84 */     this.daemon = Boolean.valueOf(daemon);
/*  27: 85 */     return this;
/*  28:    */   }
/*  29:    */   
/*  30:    */   public ThreadFactoryBuilder setPriority(int priority)
/*  31:    */   {
/*  32: 98 */     Preconditions.checkArgument(priority >= 1, "Thread priority (%s) must be >= %s", new Object[] { Integer.valueOf(priority), Integer.valueOf(1) });
/*  33:    */     
/*  34:100 */     Preconditions.checkArgument(priority <= 10, "Thread priority (%s) must be <= %s", new Object[] { Integer.valueOf(priority), Integer.valueOf(10) });
/*  35:    */     
/*  36:102 */     this.priority = Integer.valueOf(priority);
/*  37:103 */     return this;
/*  38:    */   }
/*  39:    */   
/*  40:    */   public ThreadFactoryBuilder setUncaughtExceptionHandler(Thread.UncaughtExceptionHandler uncaughtExceptionHandler)
/*  41:    */   {
/*  42:116 */     this.uncaughtExceptionHandler = ((Thread.UncaughtExceptionHandler)Preconditions.checkNotNull(uncaughtExceptionHandler));
/*  43:117 */     return this;
/*  44:    */   }
/*  45:    */   
/*  46:    */   public ThreadFactoryBuilder setThreadFactory(ThreadFactory backingThreadFactory)
/*  47:    */   {
/*  48:133 */     this.backingThreadFactory = ((ThreadFactory)Preconditions.checkNotNull(backingThreadFactory));
/*  49:134 */     return this;
/*  50:    */   }
/*  51:    */   
/*  52:    */   public ThreadFactory build()
/*  53:    */   {
/*  54:146 */     return build(this);
/*  55:    */   }
/*  56:    */   
/*  57:    */   private static ThreadFactory build(ThreadFactoryBuilder builder)
/*  58:    */   {
/*  59:150 */     final String nameFormat = builder.nameFormat;
/*  60:151 */     final Boolean daemon = builder.daemon;
/*  61:152 */     final Integer priority = builder.priority;
/*  62:153 */     final Thread.UncaughtExceptionHandler uncaughtExceptionHandler = builder.uncaughtExceptionHandler;
/*  63:    */     
/*  64:155 */     ThreadFactory backingThreadFactory = builder.backingThreadFactory != null ? builder.backingThreadFactory : Executors.defaultThreadFactory();
/*  65:    */     
/*  66:    */ 
/*  67:    */ 
/*  68:159 */     final AtomicLong count = nameFormat != null ? new AtomicLong(0L) : null;
/*  69:160 */     new ThreadFactory()
/*  70:    */     {
/*  71:    */       public Thread newThread(Runnable runnable)
/*  72:    */       {
/*  73:162 */         Thread thread = this.val$backingThreadFactory.newThread(runnable);
/*  74:163 */         if (nameFormat != null) {
/*  75:164 */           thread.setName(ThreadFactoryBuilder.format(nameFormat, new Object[] { Long.valueOf(count.getAndIncrement()) }));
/*  76:    */         }
/*  77:166 */         if (daemon != null) {
/*  78:167 */           thread.setDaemon(daemon.booleanValue());
/*  79:    */         }
/*  80:169 */         if (priority != null) {
/*  81:170 */           thread.setPriority(priority.intValue());
/*  82:    */         }
/*  83:172 */         if (uncaughtExceptionHandler != null) {
/*  84:173 */           thread.setUncaughtExceptionHandler(uncaughtExceptionHandler);
/*  85:    */         }
/*  86:175 */         return thread;
/*  87:    */       }
/*  88:    */     };
/*  89:    */   }
/*  90:    */   
/*  91:    */   private static String format(String format, Object... args)
/*  92:    */   {
/*  93:181 */     return String.format(Locale.ROOT, format, args);
/*  94:    */   }
/*  95:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ThreadFactoryBuilder
 * JD-Core Version:    0.7.0.1
 */