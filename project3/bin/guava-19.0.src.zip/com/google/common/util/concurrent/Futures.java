/*    1:     */ package com.google.common.util.concurrent;
/*    2:     */ 
/*    3:     */ import com.google.common.annotations.Beta;
/*    4:     */ import com.google.common.annotations.GwtCompatible;
/*    5:     */ import com.google.common.annotations.GwtIncompatible;
/*    6:     */ import com.google.common.base.Function;
/*    7:     */ import com.google.common.base.Optional;
/*    8:     */ import com.google.common.base.Preconditions;
/*    9:     */ import com.google.common.collect.ImmutableCollection;
/*   10:     */ import com.google.common.collect.ImmutableList;
/*   11:     */ import com.google.common.collect.ImmutableList.Builder;
/*   12:     */ import com.google.common.collect.Lists;
/*   13:     */ import com.google.common.collect.Queues;
/*   14:     */ import java.lang.reflect.UndeclaredThrowableException;
/*   15:     */ import java.util.Collections;
/*   16:     */ import java.util.List;
/*   17:     */ import java.util.concurrent.CancellationException;
/*   18:     */ import java.util.concurrent.ConcurrentLinkedQueue;
/*   19:     */ import java.util.concurrent.ExecutionException;
/*   20:     */ import java.util.concurrent.Executor;
/*   21:     */ import java.util.concurrent.Future;
/*   22:     */ import java.util.concurrent.RejectedExecutionException;
/*   23:     */ import java.util.concurrent.ScheduledExecutorService;
/*   24:     */ import java.util.concurrent.TimeUnit;
/*   25:     */ import java.util.concurrent.TimeoutException;
/*   26:     */ import java.util.logging.Level;
/*   27:     */ import java.util.logging.Logger;
/*   28:     */ import javax.annotation.CheckReturnValue;
/*   29:     */ import javax.annotation.Nullable;
/*   30:     */ 
/*   31:     */ @Beta
/*   32:     */ @GwtCompatible(emulated=true)
/*   33:     */ public final class Futures
/*   34:     */   extends GwtFuturesCatchingSpecialization
/*   35:     */ {
/*   36:     */   @CheckReturnValue
/*   37:     */   @GwtIncompatible("TODO")
/*   38:     */   public static <V, X extends Exception> CheckedFuture<V, X> makeChecked(ListenableFuture<V> future, Function<? super Exception, X> mapper)
/*   39:     */   {
/*   40: 139 */     return new MappingCheckedFuture((ListenableFuture)Preconditions.checkNotNull(future), mapper);
/*   41:     */   }
/*   42:     */   
/*   43:     */   private static abstract class ImmediateFuture<V>
/*   44:     */     implements ListenableFuture<V>
/*   45:     */   {
/*   46: 145 */     private static final Logger log = Logger.getLogger(ImmediateFuture.class.getName());
/*   47:     */     
/*   48:     */     public void addListener(Runnable listener, Executor executor)
/*   49:     */     {
/*   50: 150 */       Preconditions.checkNotNull(listener, "Runnable was null.");
/*   51: 151 */       Preconditions.checkNotNull(executor, "Executor was null.");
/*   52:     */       try
/*   53:     */       {
/*   54: 153 */         executor.execute(listener);
/*   55:     */       }
/*   56:     */       catch (RuntimeException e)
/*   57:     */       {
/*   58: 157 */         log.log(Level.SEVERE, "RuntimeException while executing runnable " + listener + " with executor " + executor, e);
/*   59:     */       }
/*   60:     */     }
/*   61:     */     
/*   62:     */     public boolean cancel(boolean mayInterruptIfRunning)
/*   63:     */     {
/*   64: 164 */       return false;
/*   65:     */     }
/*   66:     */     
/*   67:     */     public abstract V get()
/*   68:     */       throws ExecutionException;
/*   69:     */     
/*   70:     */     public V get(long timeout, TimeUnit unit)
/*   71:     */       throws ExecutionException
/*   72:     */     {
/*   73: 172 */       Preconditions.checkNotNull(unit);
/*   74: 173 */       return get();
/*   75:     */     }
/*   76:     */     
/*   77:     */     public boolean isCancelled()
/*   78:     */     {
/*   79: 178 */       return false;
/*   80:     */     }
/*   81:     */     
/*   82:     */     public boolean isDone()
/*   83:     */     {
/*   84: 183 */       return true;
/*   85:     */     }
/*   86:     */   }
/*   87:     */   
/*   88:     */   private static class ImmediateSuccessfulFuture<V>
/*   89:     */     extends Futures.ImmediateFuture<V>
/*   90:     */   {
/*   91: 188 */     static final ImmediateSuccessfulFuture<Object> NULL = new ImmediateSuccessfulFuture(null);
/*   92:     */     @Nullable
/*   93:     */     private final V value;
/*   94:     */     
/*   95:     */     ImmediateSuccessfulFuture(@Nullable V value)
/*   96:     */     {
/*   97: 193 */       super();
/*   98: 194 */       this.value = value;
/*   99:     */     }
/*  100:     */     
/*  101:     */     public V get()
/*  102:     */     {
/*  103: 199 */       return this.value;
/*  104:     */     }
/*  105:     */   }
/*  106:     */   
/*  107:     */   @GwtIncompatible("TODO")
/*  108:     */   private static class ImmediateSuccessfulCheckedFuture<V, X extends Exception>
/*  109:     */     extends Futures.ImmediateFuture<V>
/*  110:     */     implements CheckedFuture<V, X>
/*  111:     */   {
/*  112:     */     @Nullable
/*  113:     */     private final V value;
/*  114:     */     
/*  115:     */     ImmediateSuccessfulCheckedFuture(@Nullable V value)
/*  116:     */     {
/*  117: 209 */       super();
/*  118: 210 */       this.value = value;
/*  119:     */     }
/*  120:     */     
/*  121:     */     public V get()
/*  122:     */     {
/*  123: 215 */       return this.value;
/*  124:     */     }
/*  125:     */     
/*  126:     */     public V checkedGet()
/*  127:     */     {
/*  128: 220 */       return this.value;
/*  129:     */     }
/*  130:     */     
/*  131:     */     public V checkedGet(long timeout, TimeUnit unit)
/*  132:     */     {
/*  133: 225 */       Preconditions.checkNotNull(unit);
/*  134: 226 */       return this.value;
/*  135:     */     }
/*  136:     */   }
/*  137:     */   
/*  138:     */   private static class ImmediateFailedFuture<V>
/*  139:     */     extends Futures.ImmediateFuture<V>
/*  140:     */   {
/*  141:     */     private final Throwable thrown;
/*  142:     */     
/*  143:     */     ImmediateFailedFuture(Throwable thrown)
/*  144:     */     {
/*  145: 234 */       super();
/*  146: 235 */       this.thrown = thrown;
/*  147:     */     }
/*  148:     */     
/*  149:     */     public V get()
/*  150:     */       throws ExecutionException
/*  151:     */     {
/*  152: 240 */       throw new ExecutionException(this.thrown);
/*  153:     */     }
/*  154:     */   }
/*  155:     */   
/*  156:     */   @GwtIncompatible("TODO")
/*  157:     */   private static class ImmediateCancelledFuture<V>
/*  158:     */     extends Futures.ImmediateFuture<V>
/*  159:     */   {
/*  160:     */     private final CancellationException thrown;
/*  161:     */     
/*  162:     */     ImmediateCancelledFuture()
/*  163:     */     {
/*  164: 249 */       super();
/*  165: 250 */       this.thrown = new CancellationException("Immediate cancelled future.");
/*  166:     */     }
/*  167:     */     
/*  168:     */     public boolean isCancelled()
/*  169:     */     {
/*  170: 255 */       return true;
/*  171:     */     }
/*  172:     */     
/*  173:     */     public V get()
/*  174:     */     {
/*  175: 260 */       throw AbstractFuture.cancellationExceptionWithCause("Task was cancelled.", this.thrown);
/*  176:     */     }
/*  177:     */   }
/*  178:     */   
/*  179:     */   @GwtIncompatible("TODO")
/*  180:     */   private static class ImmediateFailedCheckedFuture<V, X extends Exception>
/*  181:     */     extends Futures.ImmediateFuture<V>
/*  182:     */     implements CheckedFuture<V, X>
/*  183:     */   {
/*  184:     */     private final X thrown;
/*  185:     */     
/*  186:     */     ImmediateFailedCheckedFuture(X thrown)
/*  187:     */     {
/*  188: 271 */       super();
/*  189: 272 */       this.thrown = thrown;
/*  190:     */     }
/*  191:     */     
/*  192:     */     public V get()
/*  193:     */       throws ExecutionException
/*  194:     */     {
/*  195: 277 */       throw new ExecutionException(this.thrown);
/*  196:     */     }
/*  197:     */     
/*  198:     */     public V checkedGet()
/*  199:     */       throws Exception
/*  200:     */     {
/*  201: 282 */       throw this.thrown;
/*  202:     */     }
/*  203:     */     
/*  204:     */     public V checkedGet(long timeout, TimeUnit unit)
/*  205:     */       throws Exception
/*  206:     */     {
/*  207: 287 */       Preconditions.checkNotNull(unit);
/*  208: 288 */       throw this.thrown;
/*  209:     */     }
/*  210:     */   }
/*  211:     */   
/*  212:     */   @CheckReturnValue
/*  213:     */   public static <V> ListenableFuture<V> immediateFuture(@Nullable V value)
/*  214:     */   {
/*  215: 300 */     if (value == null)
/*  216:     */     {
/*  217: 303 */       ListenableFuture<V> typedNull = ImmediateSuccessfulFuture.NULL;
/*  218: 304 */       return typedNull;
/*  219:     */     }
/*  220: 306 */     return new ImmediateSuccessfulFuture(value);
/*  221:     */   }
/*  222:     */   
/*  223:     */   @CheckReturnValue
/*  224:     */   @GwtIncompatible("TODO")
/*  225:     */   public static <V, X extends Exception> CheckedFuture<V, X> immediateCheckedFuture(@Nullable V value)
/*  226:     */   {
/*  227: 321 */     return new ImmediateSuccessfulCheckedFuture(value);
/*  228:     */   }
/*  229:     */   
/*  230:     */   @CheckReturnValue
/*  231:     */   public static <V> ListenableFuture<V> immediateFailedFuture(Throwable throwable)
/*  232:     */   {
/*  233: 336 */     Preconditions.checkNotNull(throwable);
/*  234: 337 */     return new ImmediateFailedFuture(throwable);
/*  235:     */   }
/*  236:     */   
/*  237:     */   @CheckReturnValue
/*  238:     */   @GwtIncompatible("TODO")
/*  239:     */   public static <V> ListenableFuture<V> immediateCancelledFuture()
/*  240:     */   {
/*  241: 349 */     return new ImmediateCancelledFuture();
/*  242:     */   }
/*  243:     */   
/*  244:     */   @CheckReturnValue
/*  245:     */   @GwtIncompatible("TODO")
/*  246:     */   public static <V, X extends Exception> CheckedFuture<V, X> immediateFailedCheckedFuture(X exception)
/*  247:     */   {
/*  248: 366 */     Preconditions.checkNotNull(exception);
/*  249: 367 */     return new ImmediateFailedCheckedFuture(exception);
/*  250:     */   }
/*  251:     */   
/*  252:     */   @Deprecated
/*  253:     */   @CheckReturnValue
/*  254:     */   public static <V> ListenableFuture<V> withFallback(ListenableFuture<? extends V> input, FutureFallback<? extends V> fallback)
/*  255:     */   {
/*  256: 436 */     return withFallback(input, fallback, MoreExecutors.directExecutor());
/*  257:     */   }
/*  258:     */   
/*  259:     */   @Deprecated
/*  260:     */   @CheckReturnValue
/*  261:     */   public static <V> ListenableFuture<V> withFallback(ListenableFuture<? extends V> input, FutureFallback<? extends V> fallback, Executor executor)
/*  262:     */   {
/*  263: 507 */     return catchingAsync(input, Throwable.class, asAsyncFunction(fallback), executor);
/*  264:     */   }
/*  265:     */   
/*  266:     */   @CheckReturnValue
/*  267:     */   @GwtIncompatible("AVAILABLE but requires exceptionType to be Throwable.class")
/*  268:     */   public static <V, X extends Throwable> ListenableFuture<V> catching(ListenableFuture<? extends V> input, Class<X> exceptionType, Function<? super X, ? extends V> fallback)
/*  269:     */   {
/*  270: 552 */     CatchingFuture<V, X> future = new CatchingFuture(input, exceptionType, fallback);
/*  271: 553 */     input.addListener(future, MoreExecutors.directExecutor());
/*  272: 554 */     return future;
/*  273:     */   }
/*  274:     */   
/*  275:     */   @CheckReturnValue
/*  276:     */   @GwtIncompatible("AVAILABLE but requires exceptionType to be Throwable.class")
/*  277:     */   public static <V, X extends Throwable> ListenableFuture<V> catching(ListenableFuture<? extends V> input, Class<X> exceptionType, Function<? super X, ? extends V> fallback, Executor executor)
/*  278:     */   {
/*  279: 599 */     CatchingFuture<V, X> future = new CatchingFuture(input, exceptionType, fallback);
/*  280: 600 */     input.addListener(future, rejectionPropagatingExecutor(executor, future));
/*  281: 601 */     return future;
/*  282:     */   }
/*  283:     */   
/*  284:     */   @GwtIncompatible("AVAILABLE but requires exceptionType to be Throwable.class")
/*  285:     */   public static <V, X extends Throwable> ListenableFuture<V> catchingAsync(ListenableFuture<? extends V> input, Class<X> exceptionType, AsyncFunction<? super X, ? extends V> fallback)
/*  286:     */   {
/*  287: 665 */     AsyncCatchingFuture<V, X> future = new AsyncCatchingFuture(input, exceptionType, fallback);
/*  288:     */     
/*  289: 667 */     input.addListener(future, MoreExecutors.directExecutor());
/*  290: 668 */     return future;
/*  291:     */   }
/*  292:     */   
/*  293:     */   @GwtIncompatible("AVAILABLE but requires exceptionType to be Throwable.class")
/*  294:     */   public static <V, X extends Throwable> ListenableFuture<V> catchingAsync(ListenableFuture<? extends V> input, Class<X> exceptionType, AsyncFunction<? super X, ? extends V> fallback, Executor executor)
/*  295:     */   {
/*  296: 733 */     AsyncCatchingFuture<V, X> future = new AsyncCatchingFuture(input, exceptionType, fallback);
/*  297:     */     
/*  298: 735 */     input.addListener(future, rejectionPropagatingExecutor(executor, future));
/*  299: 736 */     return future;
/*  300:     */   }
/*  301:     */   
/*  302:     */   @Deprecated
/*  303:     */   static <V> AsyncFunction<Throwable, V> asAsyncFunction(FutureFallback<V> fallback)
/*  304:     */   {
/*  305: 741 */     Preconditions.checkNotNull(fallback);
/*  306: 742 */     new AsyncFunction()
/*  307:     */     {
/*  308:     */       public ListenableFuture<V> apply(Throwable t)
/*  309:     */         throws Exception
/*  310:     */       {
/*  311: 745 */         return (ListenableFuture)Preconditions.checkNotNull(this.val$fallback.create(t), "FutureFallback.create returned null instead of a Future. Did you mean to return immediateFuture(null)?");
/*  312:     */       }
/*  313:     */     };
/*  314:     */   }
/*  315:     */   
/*  316:     */   private static abstract class AbstractCatchingFuture<V, X extends Throwable, F>
/*  317:     */     extends AbstractFuture.TrustedFuture<V>
/*  318:     */     implements Runnable
/*  319:     */   {
/*  320:     */     @Nullable
/*  321:     */     ListenableFuture<? extends V> inputFuture;
/*  322:     */     @Nullable
/*  323:     */     Class<X> exceptionType;
/*  324:     */     @Nullable
/*  325:     */     F fallback;
/*  326:     */     
/*  327:     */     AbstractCatchingFuture(ListenableFuture<? extends V> inputFuture, Class<X> exceptionType, F fallback)
/*  328:     */     {
/*  329: 759 */       this.inputFuture = ((ListenableFuture)Preconditions.checkNotNull(inputFuture));
/*  330: 760 */       this.exceptionType = ((Class)Preconditions.checkNotNull(exceptionType));
/*  331: 761 */       this.fallback = Preconditions.checkNotNull(fallback);
/*  332:     */     }
/*  333:     */     
/*  334:     */     public final void run()
/*  335:     */     {
/*  336: 765 */       ListenableFuture<? extends V> localInputFuture = this.inputFuture;
/*  337: 766 */       Class<X> localExceptionType = this.exceptionType;
/*  338: 767 */       F localFallback = this.fallback;
/*  339: 768 */       if (((localInputFuture == null ? 1 : 0) | (localExceptionType == null ? 1 : 0) | (localFallback == null ? 1 : 0) | isCancelled()) != 0) {
/*  340: 770 */         return;
/*  341:     */       }
/*  342: 772 */       this.inputFuture = null;
/*  343: 773 */       this.exceptionType = null;
/*  344: 774 */       this.fallback = null;
/*  345:     */       Throwable throwable;
/*  346:     */       try
/*  347:     */       {
/*  348: 778 */         set(Uninterruptibles.getUninterruptibly(localInputFuture));
/*  349: 779 */         return;
/*  350:     */       }
/*  351:     */       catch (ExecutionException e)
/*  352:     */       {
/*  353: 781 */         throwable = e.getCause();
/*  354:     */       }
/*  355:     */       catch (Throwable e)
/*  356:     */       {
/*  357: 783 */         throwable = e;
/*  358:     */       }
/*  359:     */       try
/*  360:     */       {
/*  361: 786 */         if (Platform.isInstanceOfThrowableClass(throwable, localExceptionType))
/*  362:     */         {
/*  363: 788 */           X castThrowable = throwable;
/*  364: 789 */           doFallback(localFallback, castThrowable);
/*  365:     */         }
/*  366:     */         else
/*  367:     */         {
/*  368: 791 */           setException(throwable);
/*  369:     */         }
/*  370:     */       }
/*  371:     */       catch (Throwable e)
/*  372:     */       {
/*  373: 794 */         setException(e);
/*  374:     */       }
/*  375:     */     }
/*  376:     */     
/*  377:     */     abstract void doFallback(F paramF, X paramX)
/*  378:     */       throws Exception;
/*  379:     */     
/*  380:     */     final void done()
/*  381:     */     {
/*  382: 802 */       maybePropagateCancellation(this.inputFuture);
/*  383: 803 */       this.inputFuture = null;
/*  384: 804 */       this.exceptionType = null;
/*  385: 805 */       this.fallback = null;
/*  386:     */     }
/*  387:     */   }
/*  388:     */   
/*  389:     */   static final class AsyncCatchingFuture<V, X extends Throwable>
/*  390:     */     extends Futures.AbstractCatchingFuture<V, X, AsyncFunction<? super X, ? extends V>>
/*  391:     */   {
/*  392:     */     AsyncCatchingFuture(ListenableFuture<? extends V> input, Class<X> exceptionType, AsyncFunction<? super X, ? extends V> fallback)
/*  393:     */     {
/*  394: 818 */       super(exceptionType, fallback);
/*  395:     */     }
/*  396:     */     
/*  397:     */     void doFallback(AsyncFunction<? super X, ? extends V> fallback, X cause)
/*  398:     */       throws Exception
/*  399:     */     {
/*  400: 823 */       ListenableFuture<? extends V> replacement = fallback.apply(cause);
/*  401: 824 */       Preconditions.checkNotNull(replacement, "AsyncFunction.apply returned null instead of a Future. Did you mean to return immediateFuture(null)?");
/*  402:     */       
/*  403: 826 */       setFuture(replacement);
/*  404:     */     }
/*  405:     */   }
/*  406:     */   
/*  407:     */   static final class CatchingFuture<V, X extends Throwable>
/*  408:     */     extends Futures.AbstractCatchingFuture<V, X, Function<? super X, ? extends V>>
/*  409:     */   {
/*  410:     */     CatchingFuture(ListenableFuture<? extends V> input, Class<X> exceptionType, Function<? super X, ? extends V> fallback)
/*  411:     */     {
/*  412: 838 */       super(exceptionType, fallback);
/*  413:     */     }
/*  414:     */     
/*  415:     */     void doFallback(Function<? super X, ? extends V> fallback, X cause)
/*  416:     */       throws Exception
/*  417:     */     {
/*  418: 842 */       V replacement = fallback.apply(cause);
/*  419: 843 */       set(replacement);
/*  420:     */     }
/*  421:     */   }
/*  422:     */   
/*  423:     */   @CheckReturnValue
/*  424:     */   @GwtIncompatible("java.util.concurrent.ScheduledExecutorService")
/*  425:     */   public static <V> ListenableFuture<V> withTimeout(ListenableFuture<V> delegate, long time, TimeUnit unit, ScheduledExecutorService scheduledExecutor)
/*  426:     */   {
/*  427: 865 */     TimeoutFuture<V> result = new TimeoutFuture(delegate);
/*  428: 866 */     Futures.TimeoutFuture.Fire<V> fire = new Futures.TimeoutFuture.Fire(result);
/*  429: 867 */     result.timer = scheduledExecutor.schedule(fire, time, unit);
/*  430: 868 */     delegate.addListener(fire, MoreExecutors.directExecutor());
/*  431: 869 */     return result;
/*  432:     */   }
/*  433:     */   
/*  434:     */   private static final class TimeoutFuture<V>
/*  435:     */     extends AbstractFuture.TrustedFuture<V>
/*  436:     */   {
/*  437:     */     @Nullable
/*  438:     */     ListenableFuture<V> delegateRef;
/*  439:     */     @Nullable
/*  440:     */     Future<?> timer;
/*  441:     */     
/*  442:     */     TimeoutFuture(ListenableFuture<V> delegate)
/*  443:     */     {
/*  444: 903 */       this.delegateRef = ((ListenableFuture)Preconditions.checkNotNull(delegate));
/*  445:     */     }
/*  446:     */     
/*  447:     */     private static final class Fire<V>
/*  448:     */       implements Runnable
/*  449:     */     {
/*  450:     */       @Nullable
/*  451:     */       Futures.TimeoutFuture<V> timeoutFutureRef;
/*  452:     */       
/*  453:     */       Fire(Futures.TimeoutFuture<V> timeoutFuture)
/*  454:     */       {
/*  455: 911 */         this.timeoutFutureRef = timeoutFuture;
/*  456:     */       }
/*  457:     */       
/*  458:     */       public void run()
/*  459:     */       {
/*  460: 917 */         Futures.TimeoutFuture<V> timeoutFuture = this.timeoutFutureRef;
/*  461: 918 */         if (timeoutFuture == null) {
/*  462: 919 */           return;
/*  463:     */         }
/*  464: 921 */         ListenableFuture<V> delegate = timeoutFuture.delegateRef;
/*  465: 922 */         if (delegate == null) {
/*  466: 923 */           return;
/*  467:     */         }
/*  468: 938 */         this.timeoutFutureRef = null;
/*  469: 939 */         if (delegate.isDone()) {
/*  470: 940 */           timeoutFuture.setFuture(delegate);
/*  471:     */         } else {
/*  472:     */           try
/*  473:     */           {
/*  474: 945 */             timeoutFuture.setException(new TimeoutException("Future timed out: " + delegate));
/*  475:     */           }
/*  476:     */           finally
/*  477:     */           {
/*  478: 947 */             delegate.cancel(true);
/*  479:     */           }
/*  480:     */         }
/*  481:     */       }
/*  482:     */     }
/*  483:     */     
/*  484:     */     void done()
/*  485:     */     {
/*  486: 954 */       maybePropagateCancellation(this.delegateRef);
/*  487:     */       
/*  488: 956 */       Future<?> localTimer = this.timer;
/*  489: 960 */       if (localTimer != null) {
/*  490: 961 */         localTimer.cancel(false);
/*  491:     */       }
/*  492: 964 */       this.delegateRef = null;
/*  493: 965 */       this.timer = null;
/*  494:     */     }
/*  495:     */   }
/*  496:     */   
/*  497:     */   @Deprecated
/*  498:     */   public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, AsyncFunction<? super I, ? extends O> function)
/*  499:     */   {
/*  500:1015 */     return transformAsync(input, function);
/*  501:     */   }
/*  502:     */   
/*  503:     */   @Deprecated
/*  504:     */   public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, AsyncFunction<? super I, ? extends O> function, Executor executor)
/*  505:     */   {
/*  506:1066 */     return transformAsync(input, function, executor);
/*  507:     */   }
/*  508:     */   
/*  509:     */   public static <I, O> ListenableFuture<O> transformAsync(ListenableFuture<I> input, AsyncFunction<? super I, ? extends O> function)
/*  510:     */   {
/*  511:1107 */     AsyncChainingFuture<I, O> output = new AsyncChainingFuture(input, function);
/*  512:1108 */     input.addListener(output, MoreExecutors.directExecutor());
/*  513:1109 */     return output;
/*  514:     */   }
/*  515:     */   
/*  516:     */   public static <I, O> ListenableFuture<O> transformAsync(ListenableFuture<I> input, AsyncFunction<? super I, ? extends O> function, Executor executor)
/*  517:     */   {
/*  518:1151 */     Preconditions.checkNotNull(executor);
/*  519:1152 */     AsyncChainingFuture<I, O> output = new AsyncChainingFuture(input, function);
/*  520:1153 */     input.addListener(output, rejectionPropagatingExecutor(executor, output));
/*  521:1154 */     return output;
/*  522:     */   }
/*  523:     */   
/*  524:     */   private static Executor rejectionPropagatingExecutor(Executor delegate, final AbstractFuture<?> future)
/*  525:     */   {
/*  526:1165 */     Preconditions.checkNotNull(delegate);
/*  527:1166 */     if (delegate == MoreExecutors.directExecutor()) {
/*  528:1168 */       return delegate;
/*  529:     */     }
/*  530:1170 */     new Executor()
/*  531:     */     {
/*  532:1171 */       volatile boolean thrownFromDelegate = true;
/*  533:     */       
/*  534:     */       public void execute(final Runnable command)
/*  535:     */       {
/*  536:     */         try
/*  537:     */         {
/*  538:1174 */           this.val$delegate.execute(new Runnable()
/*  539:     */           {
/*  540:     */             public void run()
/*  541:     */             {
/*  542:1176 */               Futures.2.this.thrownFromDelegate = false;
/*  543:1177 */               command.run();
/*  544:     */             }
/*  545:     */           });
/*  546:     */         }
/*  547:     */         catch (RejectedExecutionException e)
/*  548:     */         {
/*  549:1181 */           if (this.thrownFromDelegate) {
/*  550:1183 */             future.setException(e);
/*  551:     */           }
/*  552:     */         }
/*  553:     */       }
/*  554:     */     };
/*  555:     */   }
/*  556:     */   
/*  557:     */   public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, Function<? super I, ? extends O> function)
/*  558:     */   {
/*  559:1232 */     Preconditions.checkNotNull(function);
/*  560:1233 */     ChainingFuture<I, O> output = new ChainingFuture(input, function);
/*  561:1234 */     input.addListener(output, MoreExecutors.directExecutor());
/*  562:1235 */     return output;
/*  563:     */   }
/*  564:     */   
/*  565:     */   public static <I, O> ListenableFuture<O> transform(ListenableFuture<I> input, Function<? super I, ? extends O> function, Executor executor)
/*  566:     */   {
/*  567:1278 */     Preconditions.checkNotNull(function);
/*  568:1279 */     ChainingFuture<I, O> output = new ChainingFuture(input, function);
/*  569:1280 */     input.addListener(output, rejectionPropagatingExecutor(executor, output));
/*  570:1281 */     return output;
/*  571:     */   }
/*  572:     */   
/*  573:     */   @CheckReturnValue
/*  574:     */   @GwtIncompatible("TODO")
/*  575:     */   public static <I, O> Future<O> lazyTransform(Future<I> input, final Function<? super I, ? extends O> function)
/*  576:     */   {
/*  577:1311 */     Preconditions.checkNotNull(input);
/*  578:1312 */     Preconditions.checkNotNull(function);
/*  579:1313 */     new Future()
/*  580:     */     {
/*  581:     */       public boolean cancel(boolean mayInterruptIfRunning)
/*  582:     */       {
/*  583:1317 */         return this.val$input.cancel(mayInterruptIfRunning);
/*  584:     */       }
/*  585:     */       
/*  586:     */       public boolean isCancelled()
/*  587:     */       {
/*  588:1322 */         return this.val$input.isCancelled();
/*  589:     */       }
/*  590:     */       
/*  591:     */       public boolean isDone()
/*  592:     */       {
/*  593:1327 */         return this.val$input.isDone();
/*  594:     */       }
/*  595:     */       
/*  596:     */       public O get()
/*  597:     */         throws InterruptedException, ExecutionException
/*  598:     */       {
/*  599:1332 */         return applyTransformation(this.val$input.get());
/*  600:     */       }
/*  601:     */       
/*  602:     */       public O get(long timeout, TimeUnit unit)
/*  603:     */         throws InterruptedException, ExecutionException, TimeoutException
/*  604:     */       {
/*  605:1338 */         return applyTransformation(this.val$input.get(timeout, unit));
/*  606:     */       }
/*  607:     */       
/*  608:     */       private O applyTransformation(I input)
/*  609:     */         throws ExecutionException
/*  610:     */       {
/*  611:     */         try
/*  612:     */         {
/*  613:1343 */           return function.apply(input);
/*  614:     */         }
/*  615:     */         catch (Throwable t)
/*  616:     */         {
/*  617:1345 */           throw new ExecutionException(t);
/*  618:     */         }
/*  619:     */       }
/*  620:     */     };
/*  621:     */   }
/*  622:     */   
/*  623:     */   private static abstract class AbstractChainingFuture<I, O, F>
/*  624:     */     extends AbstractFuture.TrustedFuture<O>
/*  625:     */     implements Runnable
/*  626:     */   {
/*  627:     */     @Nullable
/*  628:     */     ListenableFuture<? extends I> inputFuture;
/*  629:     */     @Nullable
/*  630:     */     F function;
/*  631:     */     
/*  632:     */     AbstractChainingFuture(ListenableFuture<? extends I> inputFuture, F function)
/*  633:     */     {
/*  634:1379 */       this.inputFuture = ((ListenableFuture)Preconditions.checkNotNull(inputFuture));
/*  635:1380 */       this.function = Preconditions.checkNotNull(function);
/*  636:     */     }
/*  637:     */     
/*  638:     */     public final void run()
/*  639:     */     {
/*  640:     */       try
/*  641:     */       {
/*  642:1386 */         ListenableFuture<? extends I> localInputFuture = this.inputFuture;
/*  643:1387 */         F localFunction = this.function;
/*  644:1388 */         if ((isCancelled() | localInputFuture == null | localFunction == null)) {
/*  645:1389 */           return;
/*  646:     */         }
/*  647:1391 */         this.inputFuture = null;
/*  648:1392 */         this.function = null;
/*  649:     */         I sourceResult;
/*  650:     */         try
/*  651:     */         {
/*  652:1396 */           sourceResult = Uninterruptibles.getUninterruptibly(localInputFuture);
/*  653:     */         }
/*  654:     */         catch (CancellationException e)
/*  655:     */         {
/*  656:1401 */           cancel(false);
/*  657:1402 */           return;
/*  658:     */         }
/*  659:     */         catch (ExecutionException e)
/*  660:     */         {
/*  661:1405 */           setException(e.getCause());
/*  662:1406 */           return;
/*  663:     */         }
/*  664:1408 */         doTransform(localFunction, sourceResult);
/*  665:     */       }
/*  666:     */       catch (UndeclaredThrowableException e)
/*  667:     */       {
/*  668:1411 */         setException(e.getCause());
/*  669:     */       }
/*  670:     */       catch (Throwable t)
/*  671:     */       {
/*  672:1415 */         setException(t);
/*  673:     */       }
/*  674:     */     }
/*  675:     */     
/*  676:     */     abstract void doTransform(F paramF, I paramI)
/*  677:     */       throws Exception;
/*  678:     */     
/*  679:     */     final void done()
/*  680:     */     {
/*  681:1423 */       maybePropagateCancellation(this.inputFuture);
/*  682:1424 */       this.inputFuture = null;
/*  683:1425 */       this.function = null;
/*  684:     */     }
/*  685:     */   }
/*  686:     */   
/*  687:     */   private static final class AsyncChainingFuture<I, O>
/*  688:     */     extends Futures.AbstractChainingFuture<I, O, AsyncFunction<? super I, ? extends O>>
/*  689:     */   {
/*  690:     */     AsyncChainingFuture(ListenableFuture<? extends I> inputFuture, AsyncFunction<? super I, ? extends O> function)
/*  691:     */     {
/*  692:1437 */       super(function);
/*  693:     */     }
/*  694:     */     
/*  695:     */     void doTransform(AsyncFunction<? super I, ? extends O> function, I input)
/*  696:     */       throws Exception
/*  697:     */     {
/*  698:1442 */       ListenableFuture<? extends O> outputFuture = function.apply(input);
/*  699:1443 */       Preconditions.checkNotNull(outputFuture, "AsyncFunction.apply returned null instead of a Future. Did you mean to return immediateFuture(null)?");
/*  700:     */       
/*  701:1445 */       setFuture(outputFuture);
/*  702:     */     }
/*  703:     */   }
/*  704:     */   
/*  705:     */   private static final class ChainingFuture<I, O>
/*  706:     */     extends Futures.AbstractChainingFuture<I, O, Function<? super I, ? extends O>>
/*  707:     */   {
/*  708:     */     ChainingFuture(ListenableFuture<? extends I> inputFuture, Function<? super I, ? extends O> function)
/*  709:     */     {
/*  710:1458 */       super(function);
/*  711:     */     }
/*  712:     */     
/*  713:     */     void doTransform(Function<? super I, ? extends O> function, I input)
/*  714:     */     {
/*  715:1464 */       set(function.apply(input));
/*  716:     */     }
/*  717:     */   }
/*  718:     */   
/*  719:     */   @CheckReturnValue
/*  720:     */   public static <V> ListenableFuture<V> dereference(ListenableFuture<? extends ListenableFuture<? extends V>> nested)
/*  721:     */   {
/*  722:1493 */     return transformAsync(nested, DEREFERENCER);
/*  723:     */   }
/*  724:     */   
/*  725:1499 */   private static final AsyncFunction<ListenableFuture<Object>, Object> DEREFERENCER = new AsyncFunction()
/*  726:     */   {
/*  727:     */     public ListenableFuture<Object> apply(ListenableFuture<Object> input)
/*  728:     */     {
/*  729:1502 */       return input;
/*  730:     */     }
/*  731:     */   };
/*  732:     */   
/*  733:     */   @SafeVarargs
/*  734:     */   @CheckReturnValue
/*  735:     */   @Beta
/*  736:     */   public static <V> ListenableFuture<List<V>> allAsList(ListenableFuture<? extends V>... futures)
/*  737:     */   {
/*  738:1527 */     return new ListFuture(ImmutableList.copyOf(futures), true);
/*  739:     */   }
/*  740:     */   
/*  741:     */   @CheckReturnValue
/*  742:     */   @Beta
/*  743:     */   public static <V> ListenableFuture<List<V>> allAsList(Iterable<? extends ListenableFuture<? extends V>> futures)
/*  744:     */   {
/*  745:1550 */     return new ListFuture(ImmutableList.copyOf(futures), true);
/*  746:     */   }
/*  747:     */   
/*  748:     */   @CheckReturnValue
/*  749:     */   @GwtIncompatible("TODO")
/*  750:     */   public static <V> ListenableFuture<V> nonCancellationPropagating(ListenableFuture<V> future)
/*  751:     */   {
/*  752:1565 */     return new NonCancellationPropagatingFuture(future);
/*  753:     */   }
/*  754:     */   
/*  755:     */   @GwtIncompatible("TODO")
/*  756:     */   private static final class NonCancellationPropagatingFuture<V>
/*  757:     */     extends AbstractFuture.TrustedFuture<V>
/*  758:     */   {
/*  759:     */     NonCancellationPropagatingFuture(final ListenableFuture<V> delegate)
/*  760:     */     {
/*  761:1575 */       delegate.addListener(new Runnable()
/*  762:     */       {
/*  763:     */         public void run()
/*  764:     */         {
/*  765:1579 */           Futures.NonCancellationPropagatingFuture.this.setFuture(delegate);
/*  766:     */         }
/*  767:1579 */       }, MoreExecutors.directExecutor());
/*  768:     */     }
/*  769:     */   }
/*  770:     */   
/*  771:     */   @SafeVarargs
/*  772:     */   @CheckReturnValue
/*  773:     */   @Beta
/*  774:     */   public static <V> ListenableFuture<List<V>> successfulAsList(ListenableFuture<? extends V>... futures)
/*  775:     */   {
/*  776:1605 */     return new ListFuture(ImmutableList.copyOf(futures), false);
/*  777:     */   }
/*  778:     */   
/*  779:     */   @CheckReturnValue
/*  780:     */   @Beta
/*  781:     */   public static <V> ListenableFuture<List<V>> successfulAsList(Iterable<? extends ListenableFuture<? extends V>> futures)
/*  782:     */   {
/*  783:1627 */     return new ListFuture(ImmutableList.copyOf(futures), false);
/*  784:     */   }
/*  785:     */   
/*  786:     */   @CheckReturnValue
/*  787:     */   @Beta
/*  788:     */   @GwtIncompatible("TODO")
/*  789:     */   public static <T> ImmutableList<ListenableFuture<T>> inCompletionOrder(Iterable<? extends ListenableFuture<? extends T>> futures)
/*  790:     */   {
/*  791:1650 */     ConcurrentLinkedQueue<SettableFuture<T>> delegates = Queues.newConcurrentLinkedQueue();
/*  792:     */     
/*  793:1652 */     ImmutableList.Builder<ListenableFuture<T>> listBuilder = ImmutableList.builder();
/*  794:     */     
/*  795:     */ 
/*  796:     */ 
/*  797:     */ 
/*  798:     */ 
/*  799:     */ 
/*  800:     */ 
/*  801:     */ 
/*  802:     */ 
/*  803:     */ 
/*  804:1663 */     SerializingExecutor executor = new SerializingExecutor(MoreExecutors.directExecutor());
/*  805:1664 */     for (final ListenableFuture<? extends T> future : futures)
/*  806:     */     {
/*  807:1665 */       SettableFuture<T> delegate = SettableFuture.create();
/*  808:     */       
/*  809:1667 */       delegates.add(delegate);
/*  810:1668 */       future.addListener(new Runnable()
/*  811:     */       {
/*  812:     */         public void run()
/*  813:     */         {
/*  814:1670 */           ((SettableFuture)this.val$delegates.remove()).setFuture(future);
/*  815:     */         }
/*  816:1670 */       }, executor);
/*  817:     */       
/*  818:     */ 
/*  819:1673 */       listBuilder.add(delegate);
/*  820:     */     }
/*  821:1675 */     return listBuilder.build();
/*  822:     */   }
/*  823:     */   
/*  824:     */   public static <V> void addCallback(ListenableFuture<V> future, FutureCallback<? super V> callback)
/*  825:     */   {
/*  826:1713 */     addCallback(future, callback, MoreExecutors.directExecutor());
/*  827:     */   }
/*  828:     */   
/*  829:     */   public static <V> void addCallback(ListenableFuture<V> future, final FutureCallback<? super V> callback, Executor executor)
/*  830:     */   {
/*  831:1754 */     Preconditions.checkNotNull(callback);
/*  832:1755 */     Runnable callbackListener = new Runnable()
/*  833:     */     {
/*  834:     */       public void run()
/*  835:     */       {
/*  836:     */         V value;
/*  837:     */         try
/*  838:     */         {
/*  839:1762 */           value = Uninterruptibles.getUninterruptibly(this.val$future);
/*  840:     */         }
/*  841:     */         catch (ExecutionException e)
/*  842:     */         {
/*  843:1764 */           callback.onFailure(e.getCause());
/*  844:1765 */           return;
/*  845:     */         }
/*  846:     */         catch (RuntimeException e)
/*  847:     */         {
/*  848:1767 */           callback.onFailure(e);
/*  849:1768 */           return;
/*  850:     */         }
/*  851:     */         catch (Error e)
/*  852:     */         {
/*  853:1770 */           callback.onFailure(e);
/*  854:1771 */           return;
/*  855:     */         }
/*  856:1773 */         callback.onSuccess(value);
/*  857:     */       }
/*  858:1775 */     };
/*  859:1776 */     future.addListener(callbackListener, executor);
/*  860:     */   }
/*  861:     */   
/*  862:     */   @Deprecated
/*  863:     */   @GwtIncompatible("reflection")
/*  864:     */   public static <V, X extends Exception> V get(Future<V> future, Class<X> exceptionClass)
/*  865:     */     throws Exception
/*  866:     */   {
/*  867:1832 */     return getChecked(future, exceptionClass);
/*  868:     */   }
/*  869:     */   
/*  870:     */   @Deprecated
/*  871:     */   @GwtIncompatible("reflection")
/*  872:     */   public static <V, X extends Exception> V get(Future<V> future, long timeout, TimeUnit unit, Class<X> exceptionClass)
/*  873:     */     throws Exception
/*  874:     */   {
/*  875:1891 */     return getChecked(future, exceptionClass, timeout, unit);
/*  876:     */   }
/*  877:     */   
/*  878:     */   @GwtIncompatible("reflection")
/*  879:     */   public static <V, X extends Exception> V getChecked(Future<V> future, Class<X> exceptionClass)
/*  880:     */     throws Exception
/*  881:     */   {
/*  882:1944 */     return FuturesGetChecked.getChecked(future, exceptionClass);
/*  883:     */   }
/*  884:     */   
/*  885:     */   @GwtIncompatible("reflection")
/*  886:     */   public static <V, X extends Exception> V getChecked(Future<V> future, Class<X> exceptionClass, long timeout, TimeUnit unit)
/*  887:     */     throws Exception
/*  888:     */   {
/*  889:1999 */     return FuturesGetChecked.getChecked(future, exceptionClass, timeout, unit);
/*  890:     */   }
/*  891:     */   
/*  892:     */   @GwtIncompatible("TODO")
/*  893:     */   public static <V> V getUnchecked(Future<V> future)
/*  894:     */   {
/*  895:2041 */     Preconditions.checkNotNull(future);
/*  896:     */     try
/*  897:     */     {
/*  898:2043 */       return Uninterruptibles.getUninterruptibly(future);
/*  899:     */     }
/*  900:     */     catch (ExecutionException e)
/*  901:     */     {
/*  902:2045 */       wrapAndThrowUnchecked(e.getCause());
/*  903:2046 */       throw new AssertionError();
/*  904:     */     }
/*  905:     */   }
/*  906:     */   
/*  907:     */   @GwtIncompatible("TODO")
/*  908:     */   private static void wrapAndThrowUnchecked(Throwable cause)
/*  909:     */   {
/*  910:2052 */     if ((cause instanceof Error)) {
/*  911:2053 */       throw new ExecutionError((Error)cause);
/*  912:     */     }
/*  913:2060 */     throw new UncheckedExecutionException(cause);
/*  914:     */   }
/*  915:     */   
/*  916:     */   private static final class ListFuture<V>
/*  917:     */     extends CollectionFuture<V, List<V>>
/*  918:     */   {
/*  919:     */     ListFuture(ImmutableCollection<? extends ListenableFuture<? extends V>> futures, boolean allMustSucceed)
/*  920:     */     {
/*  921:2081 */       init(new ListFutureRunningState(futures, allMustSucceed));
/*  922:     */     }
/*  923:     */     
/*  924:     */     private final class ListFutureRunningState
/*  925:     */       extends CollectionFuture<V, List<V>>.CollectionFutureRunningState
/*  926:     */     {
/*  927:     */       ListFutureRunningState(boolean futures)
/*  928:     */       {
/*  929:2087 */         super(futures, allMustSucceed);
/*  930:     */       }
/*  931:     */       
/*  932:     */       public List<V> combine(List<Optional<V>> values)
/*  933:     */       {
/*  934:2092 */         List<V> result = Lists.newArrayList();
/*  935:2093 */         for (Optional<V> element : values) {
/*  936:2094 */           result.add(element != null ? element.orNull() : null);
/*  937:     */         }
/*  938:2096 */         return Collections.unmodifiableList(result);
/*  939:     */       }
/*  940:     */     }
/*  941:     */   }
/*  942:     */   
/*  943:     */   @GwtIncompatible("TODO")
/*  944:     */   private static class MappingCheckedFuture<V, X extends Exception>
/*  945:     */     extends AbstractCheckedFuture<V, X>
/*  946:     */   {
/*  947:     */     final Function<? super Exception, X> mapper;
/*  948:     */     
/*  949:     */     MappingCheckedFuture(ListenableFuture<V> delegate, Function<? super Exception, X> mapper)
/*  950:     */     {
/*  951:2113 */       super();
/*  952:     */       
/*  953:2115 */       this.mapper = ((Function)Preconditions.checkNotNull(mapper));
/*  954:     */     }
/*  955:     */     
/*  956:     */     protected X mapException(Exception e)
/*  957:     */     {
/*  958:2120 */       return (Exception)this.mapper.apply(e);
/*  959:     */     }
/*  960:     */   }
/*  961:     */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.Futures
 * JD-Core Version:    0.7.0.1
 */