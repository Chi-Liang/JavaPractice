/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.annotations.GwtCompatible;
/*  4:   */ import javax.annotation.Nullable;
/*  5:   */ 
/*  6:   */ @GwtCompatible
/*  7:   */ public class ExecutionError
/*  8:   */   extends Error
/*  9:   */ {
/* 10:   */   private static final long serialVersionUID = 0L;
/* 11:   */   
/* 12:   */   protected ExecutionError() {}
/* 13:   */   
/* 14:   */   protected ExecutionError(@Nullable String message)
/* 15:   */   {
/* 16:46 */     super(message);
/* 17:   */   }
/* 18:   */   
/* 19:   */   public ExecutionError(@Nullable String message, @Nullable Error cause)
/* 20:   */   {
/* 21:53 */     super(message, cause);
/* 22:   */   }
/* 23:   */   
/* 24:   */   public ExecutionError(@Nullable Error cause)
/* 25:   */   {
/* 26:60 */     super(cause);
/* 27:   */   }
/* 28:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ExecutionError
 * JD-Core Version:    0.7.0.1
 */