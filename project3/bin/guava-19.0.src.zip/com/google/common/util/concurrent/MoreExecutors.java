/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import com.google.common.annotations.VisibleForTesting;
/*   7:    */ import com.google.common.base.Preconditions;
/*   8:    */ import com.google.common.base.Supplier;
/*   9:    */ import com.google.common.base.Throwables;
/*  10:    */ import com.google.common.collect.Lists;
/*  11:    */ import com.google.common.collect.Queues;
/*  12:    */ import java.lang.reflect.InvocationTargetException;
/*  13:    */ import java.lang.reflect.Method;
/*  14:    */ import java.util.Collection;
/*  15:    */ import java.util.Collections;
/*  16:    */ import java.util.Iterator;
/*  17:    */ import java.util.List;
/*  18:    */ import java.util.concurrent.BlockingQueue;
/*  19:    */ import java.util.concurrent.Callable;
/*  20:    */ import java.util.concurrent.Delayed;
/*  21:    */ import java.util.concurrent.ExecutionException;
/*  22:    */ import java.util.concurrent.Executor;
/*  23:    */ import java.util.concurrent.ExecutorService;
/*  24:    */ import java.util.concurrent.Executors;
/*  25:    */ import java.util.concurrent.Future;
/*  26:    */ import java.util.concurrent.RejectedExecutionException;
/*  27:    */ import java.util.concurrent.ScheduledExecutorService;
/*  28:    */ import java.util.concurrent.ScheduledFuture;
/*  29:    */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*  30:    */ import java.util.concurrent.ThreadFactory;
/*  31:    */ import java.util.concurrent.ThreadPoolExecutor;
/*  32:    */ import java.util.concurrent.TimeUnit;
/*  33:    */ import java.util.concurrent.TimeoutException;
/*  34:    */ import javax.annotation.concurrent.GuardedBy;
/*  35:    */ 
/*  36:    */ @GwtCompatible(emulated=true)
/*  37:    */ public final class MoreExecutors
/*  38:    */ {
/*  39:    */   @Beta
/*  40:    */   @GwtIncompatible("TODO")
/*  41:    */   public static ExecutorService getExitingExecutorService(ThreadPoolExecutor executor, long terminationTimeout, TimeUnit timeUnit)
/*  42:    */   {
/*  43: 89 */     return new Application().getExitingExecutorService(executor, terminationTimeout, timeUnit);
/*  44:    */   }
/*  45:    */   
/*  46:    */   @Beta
/*  47:    */   @GwtIncompatible("TODO")
/*  48:    */   public static ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor, long terminationTimeout, TimeUnit timeUnit)
/*  49:    */   {
/*  50:113 */     return new Application().getExitingScheduledExecutorService(executor, terminationTimeout, timeUnit);
/*  51:    */   }
/*  52:    */   
/*  53:    */   @Beta
/*  54:    */   @GwtIncompatible("TODO")
/*  55:    */   public static void addDelayedShutdownHook(ExecutorService service, long terminationTimeout, TimeUnit timeUnit)
/*  56:    */   {
/*  57:132 */     new Application().addDelayedShutdownHook(service, terminationTimeout, timeUnit);
/*  58:    */   }
/*  59:    */   
/*  60:    */   @Beta
/*  61:    */   @GwtIncompatible("concurrency")
/*  62:    */   public static ExecutorService getExitingExecutorService(ThreadPoolExecutor executor)
/*  63:    */   {
/*  64:154 */     return new Application().getExitingExecutorService(executor);
/*  65:    */   }
/*  66:    */   
/*  67:    */   @Beta
/*  68:    */   @GwtIncompatible("TODO")
/*  69:    */   public static ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor)
/*  70:    */   {
/*  71:176 */     return new Application().getExitingScheduledExecutorService(executor);
/*  72:    */   }
/*  73:    */   
/*  74:    */   @GwtIncompatible("TODO")
/*  75:    */   @VisibleForTesting
/*  76:    */   static class Application
/*  77:    */   {
/*  78:    */     final ExecutorService getExitingExecutorService(ThreadPoolExecutor executor, long terminationTimeout, TimeUnit timeUnit)
/*  79:    */     {
/*  80:186 */       MoreExecutors.useDaemonThreadFactory(executor);
/*  81:187 */       ExecutorService service = Executors.unconfigurableExecutorService(executor);
/*  82:188 */       addDelayedShutdownHook(service, terminationTimeout, timeUnit);
/*  83:189 */       return service;
/*  84:    */     }
/*  85:    */     
/*  86:    */     final ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor, long terminationTimeout, TimeUnit timeUnit)
/*  87:    */     {
/*  88:194 */       MoreExecutors.useDaemonThreadFactory(executor);
/*  89:195 */       ScheduledExecutorService service = Executors.unconfigurableScheduledExecutorService(executor);
/*  90:196 */       addDelayedShutdownHook(service, terminationTimeout, timeUnit);
/*  91:197 */       return service;
/*  92:    */     }
/*  93:    */     
/*  94:    */     final void addDelayedShutdownHook(final ExecutorService service, final long terminationTimeout, TimeUnit timeUnit)
/*  95:    */     {
/*  96:202 */       Preconditions.checkNotNull(service);
/*  97:203 */       Preconditions.checkNotNull(timeUnit);
/*  98:204 */       addShutdownHook(MoreExecutors.newThread("DelayedShutdownHook-for-" + service, new Runnable()
/*  99:    */       {
/* 100:    */         public void run()
/* 101:    */         {
/* 102:    */           try
/* 103:    */           {
/* 104:213 */             service.shutdown();
/* 105:214 */             service.awaitTermination(terminationTimeout, this.val$timeUnit);
/* 106:    */           }
/* 107:    */           catch (InterruptedException ignored) {}
/* 108:    */         }
/* 109:    */       }));
/* 110:    */     }
/* 111:    */     
/* 112:    */     final ExecutorService getExitingExecutorService(ThreadPoolExecutor executor)
/* 113:    */     {
/* 114:223 */       return getExitingExecutorService(executor, 120L, TimeUnit.SECONDS);
/* 115:    */     }
/* 116:    */     
/* 117:    */     final ScheduledExecutorService getExitingScheduledExecutorService(ScheduledThreadPoolExecutor executor)
/* 118:    */     {
/* 119:228 */       return getExitingScheduledExecutorService(executor, 120L, TimeUnit.SECONDS);
/* 120:    */     }
/* 121:    */     
/* 122:    */     @VisibleForTesting
/* 123:    */     void addShutdownHook(Thread hook)
/* 124:    */     {
/* 125:232 */       Runtime.getRuntime().addShutdownHook(hook);
/* 126:    */     }
/* 127:    */   }
/* 128:    */   
/* 129:    */   @GwtIncompatible("TODO")
/* 130:    */   private static void useDaemonThreadFactory(ThreadPoolExecutor executor)
/* 131:    */   {
/* 132:238 */     executor.setThreadFactory(new ThreadFactoryBuilder().setDaemon(true).setThreadFactory(executor.getThreadFactory()).build());
/* 133:    */   }
/* 134:    */   
/* 135:    */   @Deprecated
/* 136:    */   @GwtIncompatible("TODO")
/* 137:    */   public static ListeningExecutorService sameThreadExecutor()
/* 138:    */   {
/* 139:283 */     return new DirectExecutorService(null);
/* 140:    */   }
/* 141:    */   
/* 142:    */   @GwtIncompatible("TODO")
/* 143:    */   private static final class DirectExecutorService
/* 144:    */     extends AbstractListeningExecutorService
/* 145:    */   {
/* 146:294 */     private final Object lock = new Object();
/* 147:    */     @GuardedBy("lock")
/* 148:303 */     private int runningTasks = 0;
/* 149:    */     @GuardedBy("lock")
/* 150:304 */     private boolean shutdown = false;
/* 151:    */     
/* 152:    */     public void execute(Runnable command)
/* 153:    */     {
/* 154:308 */       startTask();
/* 155:    */       try
/* 156:    */       {
/* 157:310 */         command.run();
/* 158:    */       }
/* 159:    */       finally
/* 160:    */       {
/* 161:312 */         endTask();
/* 162:    */       }
/* 163:    */     }
/* 164:    */     
/* 165:    */     public boolean isShutdown()
/* 166:    */     {
/* 167:318 */       synchronized (this.lock)
/* 168:    */       {
/* 169:319 */         return this.shutdown;
/* 170:    */       }
/* 171:    */     }
/* 172:    */     
/* 173:    */     public void shutdown()
/* 174:    */     {
/* 175:325 */       synchronized (this.lock)
/* 176:    */       {
/* 177:326 */         this.shutdown = true;
/* 178:327 */         if (this.runningTasks == 0) {
/* 179:328 */           this.lock.notifyAll();
/* 180:    */         }
/* 181:    */       }
/* 182:    */     }
/* 183:    */     
/* 184:    */     public List<Runnable> shutdownNow()
/* 185:    */     {
/* 186:336 */       shutdown();
/* 187:337 */       return Collections.emptyList();
/* 188:    */     }
/* 189:    */     
/* 190:    */     public boolean isTerminated()
/* 191:    */     {
/* 192:342 */       synchronized (this.lock)
/* 193:    */       {
/* 194:343 */         return (this.shutdown) && (this.runningTasks == 0);
/* 195:    */       }
/* 196:    */     }
/* 197:    */     
/* 198:    */     public boolean awaitTermination(long timeout, TimeUnit unit)
/* 199:    */       throws InterruptedException
/* 200:    */     {
/* 201:350 */       long nanos = unit.toNanos(timeout);
/* 202:351 */       synchronized (this.lock)
/* 203:    */       {
/* 204:353 */         if ((this.shutdown) && (this.runningTasks == 0)) {
/* 205:354 */           return true;
/* 206:    */         }
/* 207:355 */         if (nanos <= 0L) {
/* 208:356 */           return false;
/* 209:    */         }
/* 210:358 */         long now = System.nanoTime();
/* 211:359 */         TimeUnit.NANOSECONDS.timedWait(this.lock, nanos);
/* 212:360 */         nanos -= System.nanoTime() - now;
/* 213:    */       }
/* 214:    */     }
/* 215:    */     
/* 216:    */     private void startTask()
/* 217:    */     {
/* 218:374 */       synchronized (this.lock)
/* 219:    */       {
/* 220:375 */         if (this.shutdown) {
/* 221:376 */           throw new RejectedExecutionException("Executor already shutdown");
/* 222:    */         }
/* 223:378 */         this.runningTasks += 1;
/* 224:    */       }
/* 225:    */     }
/* 226:    */     
/* 227:    */     private void endTask()
/* 228:    */     {
/* 229:386 */       synchronized (this.lock)
/* 230:    */       {
/* 231:387 */         int numRunning = --this.runningTasks;
/* 232:388 */         if (numRunning == 0) {
/* 233:389 */           this.lock.notifyAll();
/* 234:    */         }
/* 235:    */       }
/* 236:    */     }
/* 237:    */   }
/* 238:    */   
/* 239:    */   @GwtIncompatible("TODO")
/* 240:    */   public static ListeningExecutorService newDirectExecutorService()
/* 241:    */   {
/* 242:429 */     return new DirectExecutorService(null);
/* 243:    */   }
/* 244:    */   
/* 245:    */   public static Executor directExecutor()
/* 246:    */   {
/* 247:449 */     return DirectExecutor.INSTANCE;
/* 248:    */   }
/* 249:    */   
/* 250:    */   private static enum DirectExecutor
/* 251:    */     implements Executor
/* 252:    */   {
/* 253:454 */     INSTANCE;
/* 254:    */     
/* 255:    */     private DirectExecutor() {}
/* 256:    */     
/* 257:    */     public void execute(Runnable command)
/* 258:    */     {
/* 259:456 */       command.run();
/* 260:    */     }
/* 261:    */     
/* 262:    */     public String toString()
/* 263:    */     {
/* 264:460 */       return "MoreExecutors.directExecutor()";
/* 265:    */     }
/* 266:    */   }
/* 267:    */   
/* 268:    */   @GwtIncompatible("TODO")
/* 269:    */   public static ListeningExecutorService listeningDecorator(ExecutorService delegate)
/* 270:    */   {
/* 271:485 */     return (delegate instanceof ScheduledExecutorService) ? new ScheduledListeningDecorator((ScheduledExecutorService)delegate) : (delegate instanceof ListeningExecutorService) ? (ListeningExecutorService)delegate : new ListeningDecorator(delegate);
/* 272:    */   }
/* 273:    */   
/* 274:    */   @GwtIncompatible("TODO")
/* 275:    */   public static ListeningScheduledExecutorService listeningDecorator(ScheduledExecutorService delegate)
/* 276:    */   {
/* 277:514 */     return (delegate instanceof ListeningScheduledExecutorService) ? (ListeningScheduledExecutorService)delegate : new ScheduledListeningDecorator(delegate);
/* 278:    */   }
/* 279:    */   
/* 280:    */   @GwtIncompatible("TODO")
/* 281:    */   private static class ListeningDecorator
/* 282:    */     extends AbstractListeningExecutorService
/* 283:    */   {
/* 284:    */     private final ExecutorService delegate;
/* 285:    */     
/* 286:    */     ListeningDecorator(ExecutorService delegate)
/* 287:    */     {
/* 288:525 */       this.delegate = ((ExecutorService)Preconditions.checkNotNull(delegate));
/* 289:    */     }
/* 290:    */     
/* 291:    */     public final boolean awaitTermination(long timeout, TimeUnit unit)
/* 292:    */       throws InterruptedException
/* 293:    */     {
/* 294:531 */       return this.delegate.awaitTermination(timeout, unit);
/* 295:    */     }
/* 296:    */     
/* 297:    */     public final boolean isShutdown()
/* 298:    */     {
/* 299:536 */       return this.delegate.isShutdown();
/* 300:    */     }
/* 301:    */     
/* 302:    */     public final boolean isTerminated()
/* 303:    */     {
/* 304:541 */       return this.delegate.isTerminated();
/* 305:    */     }
/* 306:    */     
/* 307:    */     public final void shutdown()
/* 308:    */     {
/* 309:546 */       this.delegate.shutdown();
/* 310:    */     }
/* 311:    */     
/* 312:    */     public final List<Runnable> shutdownNow()
/* 313:    */     {
/* 314:551 */       return this.delegate.shutdownNow();
/* 315:    */     }
/* 316:    */     
/* 317:    */     public final void execute(Runnable command)
/* 318:    */     {
/* 319:556 */       this.delegate.execute(command);
/* 320:    */     }
/* 321:    */   }
/* 322:    */   
/* 323:    */   @GwtIncompatible("TODO")
/* 324:    */   private static final class ScheduledListeningDecorator
/* 325:    */     extends MoreExecutors.ListeningDecorator
/* 326:    */     implements ListeningScheduledExecutorService
/* 327:    */   {
/* 328:    */     final ScheduledExecutorService delegate;
/* 329:    */     
/* 330:    */     ScheduledListeningDecorator(ScheduledExecutorService delegate)
/* 331:    */     {
/* 332:567 */       super();
/* 333:568 */       this.delegate = ((ScheduledExecutorService)Preconditions.checkNotNull(delegate));
/* 334:    */     }
/* 335:    */     
/* 336:    */     public ListenableScheduledFuture<?> schedule(Runnable command, long delay, TimeUnit unit)
/* 337:    */     {
/* 338:574 */       TrustedListenableFutureTask<Void> task = TrustedListenableFutureTask.create(command, null);
/* 339:    */       
/* 340:576 */       ScheduledFuture<?> scheduled = this.delegate.schedule(task, delay, unit);
/* 341:577 */       return new ListenableScheduledTask(task, scheduled);
/* 342:    */     }
/* 343:    */     
/* 344:    */     public <V> ListenableScheduledFuture<V> schedule(Callable<V> callable, long delay, TimeUnit unit)
/* 345:    */     {
/* 346:583 */       TrustedListenableFutureTask<V> task = TrustedListenableFutureTask.create(callable);
/* 347:584 */       ScheduledFuture<?> scheduled = this.delegate.schedule(task, delay, unit);
/* 348:585 */       return new ListenableScheduledTask(task, scheduled);
/* 349:    */     }
/* 350:    */     
/* 351:    */     public ListenableScheduledFuture<?> scheduleAtFixedRate(Runnable command, long initialDelay, long period, TimeUnit unit)
/* 352:    */     {
/* 353:591 */       NeverSuccessfulListenableFutureTask task = new NeverSuccessfulListenableFutureTask(command);
/* 354:    */       
/* 355:593 */       ScheduledFuture<?> scheduled = this.delegate.scheduleAtFixedRate(task, initialDelay, period, unit);
/* 356:    */       
/* 357:595 */       return new ListenableScheduledTask(task, scheduled);
/* 358:    */     }
/* 359:    */     
/* 360:    */     public ListenableScheduledFuture<?> scheduleWithFixedDelay(Runnable command, long initialDelay, long delay, TimeUnit unit)
/* 361:    */     {
/* 362:601 */       NeverSuccessfulListenableFutureTask task = new NeverSuccessfulListenableFutureTask(command);
/* 363:    */       
/* 364:603 */       ScheduledFuture<?> scheduled = this.delegate.scheduleWithFixedDelay(task, initialDelay, delay, unit);
/* 365:    */       
/* 366:605 */       return new ListenableScheduledTask(task, scheduled);
/* 367:    */     }
/* 368:    */     
/* 369:    */     private static final class ListenableScheduledTask<V>
/* 370:    */       extends ForwardingListenableFuture.SimpleForwardingListenableFuture<V>
/* 371:    */       implements ListenableScheduledFuture<V>
/* 372:    */     {
/* 373:    */       private final ScheduledFuture<?> scheduledDelegate;
/* 374:    */       
/* 375:    */       public ListenableScheduledTask(ListenableFuture<V> listenableDelegate, ScheduledFuture<?> scheduledDelegate)
/* 376:    */       {
/* 377:617 */         super();
/* 378:618 */         this.scheduledDelegate = scheduledDelegate;
/* 379:    */       }
/* 380:    */       
/* 381:    */       public boolean cancel(boolean mayInterruptIfRunning)
/* 382:    */       {
/* 383:623 */         boolean cancelled = super.cancel(mayInterruptIfRunning);
/* 384:624 */         if (cancelled) {
/* 385:626 */           this.scheduledDelegate.cancel(mayInterruptIfRunning);
/* 386:    */         }
/* 387:630 */         return cancelled;
/* 388:    */       }
/* 389:    */       
/* 390:    */       public long getDelay(TimeUnit unit)
/* 391:    */       {
/* 392:635 */         return this.scheduledDelegate.getDelay(unit);
/* 393:    */       }
/* 394:    */       
/* 395:    */       public int compareTo(Delayed other)
/* 396:    */       {
/* 397:640 */         return this.scheduledDelegate.compareTo(other);
/* 398:    */       }
/* 399:    */     }
/* 400:    */     
/* 401:    */     @GwtIncompatible("TODO")
/* 402:    */     private static final class NeverSuccessfulListenableFutureTask
/* 403:    */       extends AbstractFuture<Void>
/* 404:    */       implements Runnable
/* 405:    */     {
/* 406:    */       private final Runnable delegate;
/* 407:    */       
/* 408:    */       public NeverSuccessfulListenableFutureTask(Runnable delegate)
/* 409:    */       {
/* 410:651 */         this.delegate = ((Runnable)Preconditions.checkNotNull(delegate));
/* 411:    */       }
/* 412:    */       
/* 413:    */       public void run()
/* 414:    */       {
/* 415:    */         try
/* 416:    */         {
/* 417:656 */           this.delegate.run();
/* 418:    */         }
/* 419:    */         catch (Throwable t)
/* 420:    */         {
/* 421:658 */           setException(t);
/* 422:659 */           throw Throwables.propagate(t);
/* 423:    */         }
/* 424:    */       }
/* 425:    */     }
/* 426:    */   }
/* 427:    */   
/* 428:    */   static <T> T invokeAnyImpl(ListeningExecutorService executorService, Collection<? extends Callable<T>> tasks, boolean timed, long nanos)
/* 429:    */     throws InterruptedException, ExecutionException, TimeoutException
/* 430:    */   {
/* 431:683 */     Preconditions.checkNotNull(executorService);
/* 432:684 */     int ntasks = tasks.size();
/* 433:685 */     Preconditions.checkArgument(ntasks > 0);
/* 434:686 */     List<Future<T>> futures = Lists.newArrayListWithCapacity(ntasks);
/* 435:687 */     BlockingQueue<Future<T>> futureQueue = Queues.newLinkedBlockingQueue();
/* 436:    */     try
/* 437:    */     {
/* 438:698 */       ExecutionException ee = null;
/* 439:699 */       long lastTime = timed ? System.nanoTime() : 0L;
/* 440:700 */       Iterator<? extends Callable<T>> it = tasks.iterator();
/* 441:    */       
/* 442:702 */       futures.add(submitAndAddQueueListener(executorService, (Callable)it.next(), futureQueue));
/* 443:703 */       ntasks--;
/* 444:704 */       int active = 1;
/* 445:    */       for (;;)
/* 446:    */       {
/* 447:707 */         Future<T> f = (Future)futureQueue.poll();
/* 448:    */         long now;
/* 449:708 */         if (f == null) {
/* 450:709 */           if (ntasks > 0)
/* 451:    */           {
/* 452:710 */             ntasks--;
/* 453:711 */             futures.add(submitAndAddQueueListener(executorService, (Callable)it.next(), futureQueue));
/* 454:712 */             active++;
/* 455:    */           }
/* 456:    */           else
/* 457:    */           {
/* 458:713 */             if (active == 0) {
/* 459:    */               break;
/* 460:    */             }
/* 461:715 */             if (timed)
/* 462:    */             {
/* 463:716 */               f = (Future)futureQueue.poll(nanos, TimeUnit.NANOSECONDS);
/* 464:717 */               if (f == null) {
/* 465:718 */                 throw new TimeoutException();
/* 466:    */               }
/* 467:720 */               now = System.nanoTime();
/* 468:721 */               nanos -= now - lastTime;
/* 469:722 */               lastTime = now;
/* 470:    */             }
/* 471:    */             else
/* 472:    */             {
/* 473:724 */               f = (Future)futureQueue.take();
/* 474:    */             }
/* 475:    */           }
/* 476:    */         }
/* 477:727 */         if (f != null)
/* 478:    */         {
/* 479:728 */           active--;
/* 480:    */           try
/* 481:    */           {
/* 482:    */             Iterator i$;
/* 483:    */             Future<T> f;
/* 484:730 */             return f.get();
/* 485:    */           }
/* 486:    */           catch (ExecutionException eex)
/* 487:    */           {
/* 488:732 */             ee = eex;
/* 489:    */           }
/* 490:    */           catch (RuntimeException rex)
/* 491:    */           {
/* 492:734 */             ee = new ExecutionException(rex);
/* 493:    */           }
/* 494:    */         }
/* 495:    */       }
/* 496:739 */       if (ee == null) {
/* 497:740 */         ee = new ExecutionException(null);
/* 498:    */       }
/* 499:742 */       throw ee;
/* 500:    */     }
/* 501:    */     finally
/* 502:    */     {
/* 503:744 */       for (Future<T> f : futures) {
/* 504:745 */         f.cancel(true);
/* 505:    */       }
/* 506:    */     }
/* 507:    */   }
/* 508:    */   
/* 509:    */   @GwtIncompatible("TODO")
/* 510:    */   private static <T> ListenableFuture<T> submitAndAddQueueListener(ListeningExecutorService executorService, Callable<T> task, BlockingQueue<Future<T>> queue)
/* 511:    */   {
/* 512:757 */     final ListenableFuture<T> future = executorService.submit(task);
/* 513:758 */     future.addListener(new Runnable()
/* 514:    */     {
/* 515:    */       public void run()
/* 516:    */       {
/* 517:760 */         this.val$queue.add(future);
/* 518:    */       }
/* 519:760 */     }, directExecutor());
/* 520:    */     
/* 521:    */ 
/* 522:763 */     return future;
/* 523:    */   }
/* 524:    */   
/* 525:    */   @Beta
/* 526:    */   @GwtIncompatible("concurrency")
/* 527:    */   public static ThreadFactory platformThreadFactory()
/* 528:    */   {
/* 529:777 */     if (!isAppEngine()) {
/* 530:778 */       return Executors.defaultThreadFactory();
/* 531:    */     }
/* 532:    */     try
/* 533:    */     {
/* 534:781 */       return (ThreadFactory)Class.forName("com.google.appengine.api.ThreadManager").getMethod("currentRequestThreadFactory", new Class[0]).invoke(null, new Object[0]);
/* 535:    */     }
/* 536:    */     catch (IllegalAccessException e)
/* 537:    */     {
/* 538:785 */       throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", e);
/* 539:    */     }
/* 540:    */     catch (ClassNotFoundException e)
/* 541:    */     {
/* 542:787 */       throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", e);
/* 543:    */     }
/* 544:    */     catch (NoSuchMethodException e)
/* 545:    */     {
/* 546:789 */       throw new RuntimeException("Couldn't invoke ThreadManager.currentRequestThreadFactory", e);
/* 547:    */     }
/* 548:    */     catch (InvocationTargetException e)
/* 549:    */     {
/* 550:791 */       throw Throwables.propagate(e.getCause());
/* 551:    */     }
/* 552:    */   }
/* 553:    */   
/* 554:    */   @GwtIncompatible("TODO")
/* 555:    */   private static boolean isAppEngine()
/* 556:    */   {
/* 557:797 */     if (System.getProperty("com.google.appengine.runtime.environment") == null) {
/* 558:798 */       return false;
/* 559:    */     }
/* 560:    */     try
/* 561:    */     {
/* 562:802 */       return Class.forName("com.google.apphosting.api.ApiProxy").getMethod("getCurrentEnvironment", new Class[0]).invoke(null, new Object[0]) != null;
/* 563:    */     }
/* 564:    */     catch (ClassNotFoundException e)
/* 565:    */     {
/* 566:807 */       return false;
/* 567:    */     }
/* 568:    */     catch (InvocationTargetException e)
/* 569:    */     {
/* 570:810 */       return false;
/* 571:    */     }
/* 572:    */     catch (IllegalAccessException e)
/* 573:    */     {
/* 574:813 */       return false;
/* 575:    */     }
/* 576:    */     catch (NoSuchMethodException e) {}
/* 577:816 */     return false;
/* 578:    */   }
/* 579:    */   
/* 580:    */   @GwtIncompatible("concurrency")
/* 581:    */   static Thread newThread(String name, Runnable runnable)
/* 582:    */   {
/* 583:826 */     Preconditions.checkNotNull(name);
/* 584:827 */     Preconditions.checkNotNull(runnable);
/* 585:828 */     Thread result = platformThreadFactory().newThread(runnable);
/* 586:    */     try
/* 587:    */     {
/* 588:830 */       result.setName(name);
/* 589:    */     }
/* 590:    */     catch (SecurityException e) {}
/* 591:834 */     return result;
/* 592:    */   }
/* 593:    */   
/* 594:    */   @GwtIncompatible("concurrency")
/* 595:    */   static Executor renamingDecorator(Executor executor, final Supplier<String> nameSupplier)
/* 596:    */   {
/* 597:854 */     Preconditions.checkNotNull(executor);
/* 598:855 */     Preconditions.checkNotNull(nameSupplier);
/* 599:856 */     if (isAppEngine()) {
/* 600:858 */       return executor;
/* 601:    */     }
/* 602:860 */     new Executor()
/* 603:    */     {
/* 604:    */       public void execute(Runnable command)
/* 605:    */       {
/* 606:862 */         this.val$executor.execute(Callables.threadRenaming(command, nameSupplier));
/* 607:    */       }
/* 608:    */     };
/* 609:    */   }
/* 610:    */   
/* 611:    */   @GwtIncompatible("concurrency")
/* 612:    */   static ExecutorService renamingDecorator(ExecutorService service, final Supplier<String> nameSupplier)
/* 613:    */   {
/* 614:882 */     Preconditions.checkNotNull(service);
/* 615:883 */     Preconditions.checkNotNull(nameSupplier);
/* 616:884 */     if (isAppEngine()) {
/* 617:886 */       return service;
/* 618:    */     }
/* 619:888 */     new WrappingExecutorService(service)
/* 620:    */     {
/* 621:    */       protected <T> Callable<T> wrapTask(Callable<T> callable)
/* 622:    */       {
/* 623:890 */         return Callables.threadRenaming(callable, nameSupplier);
/* 624:    */       }
/* 625:    */       
/* 626:    */       protected Runnable wrapTask(Runnable command)
/* 627:    */       {
/* 628:893 */         return Callables.threadRenaming(command, nameSupplier);
/* 629:    */       }
/* 630:    */     };
/* 631:    */   }
/* 632:    */   
/* 633:    */   @GwtIncompatible("concurrency")
/* 634:    */   static ScheduledExecutorService renamingDecorator(ScheduledExecutorService service, final Supplier<String> nameSupplier)
/* 635:    */   {
/* 636:913 */     Preconditions.checkNotNull(service);
/* 637:914 */     Preconditions.checkNotNull(nameSupplier);
/* 638:915 */     if (isAppEngine()) {
/* 639:917 */       return service;
/* 640:    */     }
/* 641:919 */     new WrappingScheduledExecutorService(service)
/* 642:    */     {
/* 643:    */       protected <T> Callable<T> wrapTask(Callable<T> callable)
/* 644:    */       {
/* 645:921 */         return Callables.threadRenaming(callable, nameSupplier);
/* 646:    */       }
/* 647:    */       
/* 648:    */       protected Runnable wrapTask(Runnable command)
/* 649:    */       {
/* 650:924 */         return Callables.threadRenaming(command, nameSupplier);
/* 651:    */       }
/* 652:    */     };
/* 653:    */   }
/* 654:    */   
/* 655:    */   @Beta
/* 656:    */   @GwtIncompatible("concurrency")
/* 657:    */   public static boolean shutdownAndAwaitTermination(ExecutorService service, long timeout, TimeUnit unit)
/* 658:    */   {
/* 659:956 */     Preconditions.checkNotNull(unit);
/* 660:    */     
/* 661:958 */     service.shutdown();
/* 662:    */     try
/* 663:    */     {
/* 664:960 */       long halfTimeoutNanos = TimeUnit.NANOSECONDS.convert(timeout, unit) / 2L;
/* 665:962 */       if (!service.awaitTermination(halfTimeoutNanos, TimeUnit.NANOSECONDS))
/* 666:    */       {
/* 667:964 */         service.shutdownNow();
/* 668:    */         
/* 669:966 */         service.awaitTermination(halfTimeoutNanos, TimeUnit.NANOSECONDS);
/* 670:    */       }
/* 671:    */     }
/* 672:    */     catch (InterruptedException ie)
/* 673:    */     {
/* 674:970 */       Thread.currentThread().interrupt();
/* 675:    */       
/* 676:972 */       service.shutdownNow();
/* 677:    */     }
/* 678:974 */     return service.isTerminated();
/* 679:    */   }
/* 680:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.MoreExecutors
 * JD-Core Version:    0.7.0.1
 */