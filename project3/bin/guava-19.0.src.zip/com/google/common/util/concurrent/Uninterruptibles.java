/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.annotations.GwtCompatible;
/*   5:    */ import com.google.common.annotations.GwtIncompatible;
/*   6:    */ import java.util.concurrent.BlockingQueue;
/*   7:    */ import java.util.concurrent.CountDownLatch;
/*   8:    */ import java.util.concurrent.ExecutionException;
/*   9:    */ import java.util.concurrent.Future;
/*  10:    */ import java.util.concurrent.Semaphore;
/*  11:    */ import java.util.concurrent.TimeUnit;
/*  12:    */ 
/*  13:    */ @Beta
/*  14:    */ @GwtCompatible(emulated=true)
/*  15:    */ public final class Uninterruptibles
/*  16:    */ {
/*  17:    */   @GwtIncompatible("concurrency")
/*  18:    */   public static void awaitUninterruptibly(CountDownLatch latch)
/*  19:    */   {
/*  20: 57 */     boolean interrupted = false;
/*  21:    */     try
/*  22:    */     {
/*  23: 61 */       latch.await();
/*  24:    */     }
/*  25:    */     catch (InterruptedException e)
/*  26:    */     {
/*  27:    */       for (;;)
/*  28:    */       {
/*  29: 64 */         interrupted = true;
/*  30:    */       }
/*  31:    */     }
/*  32:    */     finally
/*  33:    */     {
/*  34: 68 */       if (interrupted) {
/*  35: 69 */         Thread.currentThread().interrupt();
/*  36:    */       }
/*  37:    */     }
/*  38:    */   }
/*  39:    */   
/*  40:    */   /* Error */
/*  41:    */   @GwtIncompatible("concurrency")
/*  42:    */   public static boolean awaitUninterruptibly(CountDownLatch latch, long timeout, TimeUnit unit)
/*  43:    */   {
/*  44:    */     // Byte code:
/*  45:    */     //   0: iconst_0
/*  46:    */     //   1: istore 4
/*  47:    */     //   3: aload_3
/*  48:    */     //   4: lload_1
/*  49:    */     //   5: invokevirtual 5	java/util/concurrent/TimeUnit:toNanos	(J)J
/*  50:    */     //   8: lstore 5
/*  51:    */     //   10: invokestatic 6	java/lang/System:nanoTime	()J
/*  52:    */     //   13: lload 5
/*  53:    */     //   15: ladd
/*  54:    */     //   16: lstore 7
/*  55:    */     //   18: aload_0
/*  56:    */     //   19: lload 5
/*  57:    */     //   21: getstatic 7	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/*  58:    */     //   24: invokevirtual 8	java/util/concurrent/CountDownLatch:await	(JLjava/util/concurrent/TimeUnit;)Z
/*  59:    */     //   27: istore 9
/*  60:    */     //   29: iload 4
/*  61:    */     //   31: ifeq +9 -> 40
/*  62:    */     //   34: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  63:    */     //   37: invokevirtual 3	java/lang/Thread:interrupt	()V
/*  64:    */     //   40: iload 9
/*  65:    */     //   42: ireturn
/*  66:    */     //   43: astore 9
/*  67:    */     //   45: iconst_1
/*  68:    */     //   46: istore 4
/*  69:    */     //   48: lload 7
/*  70:    */     //   50: invokestatic 6	java/lang/System:nanoTime	()J
/*  71:    */     //   53: lsub
/*  72:    */     //   54: lstore 5
/*  73:    */     //   56: goto -38 -> 18
/*  74:    */     //   59: astore 10
/*  75:    */     //   61: iload 4
/*  76:    */     //   63: ifeq +9 -> 72
/*  77:    */     //   66: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/*  78:    */     //   69: invokevirtual 3	java/lang/Thread:interrupt	()V
/*  79:    */     //   72: aload 10
/*  80:    */     //   74: athrow
/*  81:    */     // Line number table:
/*  82:    */     //   Java source line #82	-> byte code offset #0
/*  83:    */     //   Java source line #84	-> byte code offset #3
/*  84:    */     //   Java source line #85	-> byte code offset #10
/*  85:    */     //   Java source line #90	-> byte code offset #18
/*  86:    */     //   Java source line #97	-> byte code offset #29
/*  87:    */     //   Java source line #98	-> byte code offset #34
/*  88:    */     //   Java source line #91	-> byte code offset #43
/*  89:    */     //   Java source line #92	-> byte code offset #45
/*  90:    */     //   Java source line #93	-> byte code offset #48
/*  91:    */     //   Java source line #94	-> byte code offset #56
/*  92:    */     //   Java source line #97	-> byte code offset #59
/*  93:    */     //   Java source line #98	-> byte code offset #66
/*  94:    */     // Local variable table:
/*  95:    */     //   start	length	slot	name	signature
/*  96:    */     //   0	75	0	latch	CountDownLatch
/*  97:    */     //   0	75	1	timeout	long
/*  98:    */     //   0	75	3	unit	TimeUnit
/*  99:    */     //   1	61	4	interrupted	boolean
/* 100:    */     //   8	47	5	remainingNanos	long
/* 101:    */     //   16	33	7	end	long
/* 102:    */     //   27	14	9	bool1	boolean
/* 103:    */     //   43	3	9	e	InterruptedException
/* 104:    */     //   59	14	10	localObject	Object
/* 105:    */     // Exception table:
/* 106:    */     //   from	to	target	type
/* 107:    */     //   18	29	43	java/lang/InterruptedException
/* 108:    */     //   3	29	59	finally
/* 109:    */     //   43	61	59	finally
/* 110:    */   }
/* 111:    */   
/* 112:    */   @GwtIncompatible("concurrency")
/* 113:    */   public static void joinUninterruptibly(Thread toJoin)
/* 114:    */   {
/* 115:108 */     boolean interrupted = false;
/* 116:    */     try
/* 117:    */     {
/* 118:112 */       toJoin.join();
/* 119:    */     }
/* 120:    */     catch (InterruptedException e)
/* 121:    */     {
/* 122:    */       for (;;)
/* 123:    */       {
/* 124:115 */         interrupted = true;
/* 125:    */       }
/* 126:    */     }
/* 127:    */     finally
/* 128:    */     {
/* 129:119 */       if (interrupted) {
/* 130:120 */         Thread.currentThread().interrupt();
/* 131:    */       }
/* 132:    */     }
/* 133:    */   }
/* 134:    */   
/* 135:    */   public static <V> V getUninterruptibly(Future<V> future)
/* 136:    */     throws ExecutionException
/* 137:    */   {
/* 138:139 */     boolean interrupted = false;
/* 139:    */     try
/* 140:    */     {
/* 141:143 */       return future.get();
/* 142:    */     }
/* 143:    */     catch (InterruptedException e)
/* 144:    */     {
/* 145:    */       for (;;)
/* 146:    */       {
/* 147:145 */         interrupted = true;
/* 148:    */       }
/* 149:    */     }
/* 150:    */     finally
/* 151:    */     {
/* 152:149 */       if (interrupted) {
/* 153:150 */         Thread.currentThread().interrupt();
/* 154:    */       }
/* 155:    */     }
/* 156:    */   }
/* 157:    */   
/* 158:    */   /* Error */
/* 159:    */   @GwtIncompatible("TODO")
/* 160:    */   public static <V> V getUninterruptibly(Future<V> future, long timeout, TimeUnit unit)
/* 161:    */     throws ExecutionException, java.util.concurrent.TimeoutException
/* 162:    */   {
/* 163:    */     // Byte code:
/* 164:    */     //   0: iconst_0
/* 165:    */     //   1: istore 4
/* 166:    */     //   3: aload_3
/* 167:    */     //   4: lload_1
/* 168:    */     //   5: invokevirtual 5	java/util/concurrent/TimeUnit:toNanos	(J)J
/* 169:    */     //   8: lstore 5
/* 170:    */     //   10: invokestatic 6	java/lang/System:nanoTime	()J
/* 171:    */     //   13: lload 5
/* 172:    */     //   15: ladd
/* 173:    */     //   16: lstore 7
/* 174:    */     //   18: aload_0
/* 175:    */     //   19: lload 5
/* 176:    */     //   21: getstatic 7	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/* 177:    */     //   24: invokeinterface 11 4 0
/* 178:    */     //   29: astore 9
/* 179:    */     //   31: iload 4
/* 180:    */     //   33: ifeq +9 -> 42
/* 181:    */     //   36: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 182:    */     //   39: invokevirtual 3	java/lang/Thread:interrupt	()V
/* 183:    */     //   42: aload 9
/* 184:    */     //   44: areturn
/* 185:    */     //   45: astore 9
/* 186:    */     //   47: iconst_1
/* 187:    */     //   48: istore 4
/* 188:    */     //   50: lload 7
/* 189:    */     //   52: invokestatic 6	java/lang/System:nanoTime	()J
/* 190:    */     //   55: lsub
/* 191:    */     //   56: lstore 5
/* 192:    */     //   58: goto -40 -> 18
/* 193:    */     //   61: astore 10
/* 194:    */     //   63: iload 4
/* 195:    */     //   65: ifeq +9 -> 74
/* 196:    */     //   68: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 197:    */     //   71: invokevirtual 3	java/lang/Thread:interrupt	()V
/* 198:    */     //   74: aload 10
/* 199:    */     //   76: athrow
/* 200:    */     // Line number table:
/* 201:    */     //   Java source line #172	-> byte code offset #0
/* 202:    */     //   Java source line #174	-> byte code offset #3
/* 203:    */     //   Java source line #175	-> byte code offset #10
/* 204:    */     //   Java source line #180	-> byte code offset #18
/* 205:    */     //   Java source line #187	-> byte code offset #31
/* 206:    */     //   Java source line #188	-> byte code offset #36
/* 207:    */     //   Java source line #181	-> byte code offset #45
/* 208:    */     //   Java source line #182	-> byte code offset #47
/* 209:    */     //   Java source line #183	-> byte code offset #50
/* 210:    */     //   Java source line #184	-> byte code offset #58
/* 211:    */     //   Java source line #187	-> byte code offset #61
/* 212:    */     //   Java source line #188	-> byte code offset #68
/* 213:    */     // Local variable table:
/* 214:    */     //   start	length	slot	name	signature
/* 215:    */     //   0	77	0	future	Future<V>
/* 216:    */     //   0	77	1	timeout	long
/* 217:    */     //   0	77	3	unit	TimeUnit
/* 218:    */     //   1	63	4	interrupted	boolean
/* 219:    */     //   8	49	5	remainingNanos	long
/* 220:    */     //   16	35	7	end	long
/* 221:    */     //   29	14	9	localObject1	Object
/* 222:    */     //   45	3	9	e	InterruptedException
/* 223:    */     //   61	14	10	localObject2	Object
/* 224:    */     // Exception table:
/* 225:    */     //   from	to	target	type
/* 226:    */     //   18	31	45	java/lang/InterruptedException
/* 227:    */     //   3	31	61	finally
/* 228:    */     //   45	63	61	finally
/* 229:    */   }
/* 230:    */   
/* 231:    */   /* Error */
/* 232:    */   @GwtIncompatible("concurrency")
/* 233:    */   public static void joinUninterruptibly(Thread toJoin, long timeout, TimeUnit unit)
/* 234:    */   {
/* 235:    */     // Byte code:
/* 236:    */     //   0: aload_0
/* 237:    */     //   1: invokestatic 12	com/google/common/base/Preconditions:checkNotNull	(Ljava/lang/Object;)Ljava/lang/Object;
/* 238:    */     //   4: pop
/* 239:    */     //   5: iconst_0
/* 240:    */     //   6: istore 4
/* 241:    */     //   8: aload_3
/* 242:    */     //   9: lload_1
/* 243:    */     //   10: invokevirtual 5	java/util/concurrent/TimeUnit:toNanos	(J)J
/* 244:    */     //   13: lstore 5
/* 245:    */     //   15: invokestatic 6	java/lang/System:nanoTime	()J
/* 246:    */     //   18: lload 5
/* 247:    */     //   20: ladd
/* 248:    */     //   21: lstore 7
/* 249:    */     //   23: getstatic 7	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/* 250:    */     //   26: aload_0
/* 251:    */     //   27: lload 5
/* 252:    */     //   29: invokevirtual 13	java/util/concurrent/TimeUnit:timedJoin	(Ljava/lang/Thread;J)V
/* 253:    */     //   32: iload 4
/* 254:    */     //   34: ifeq +9 -> 43
/* 255:    */     //   37: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 256:    */     //   40: invokevirtual 3	java/lang/Thread:interrupt	()V
/* 257:    */     //   43: return
/* 258:    */     //   44: astore 9
/* 259:    */     //   46: iconst_1
/* 260:    */     //   47: istore 4
/* 261:    */     //   49: lload 7
/* 262:    */     //   51: invokestatic 6	java/lang/System:nanoTime	()J
/* 263:    */     //   54: lsub
/* 264:    */     //   55: lstore 5
/* 265:    */     //   57: goto -34 -> 23
/* 266:    */     //   60: astore 10
/* 267:    */     //   62: iload 4
/* 268:    */     //   64: ifeq +9 -> 73
/* 269:    */     //   67: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 270:    */     //   70: invokevirtual 3	java/lang/Thread:interrupt	()V
/* 271:    */     //   73: aload 10
/* 272:    */     //   75: athrow
/* 273:    */     // Line number table:
/* 274:    */     //   Java source line #201	-> byte code offset #0
/* 275:    */     //   Java source line #202	-> byte code offset #5
/* 276:    */     //   Java source line #204	-> byte code offset #8
/* 277:    */     //   Java source line #205	-> byte code offset #15
/* 278:    */     //   Java source line #209	-> byte code offset #23
/* 279:    */     //   Java source line #217	-> byte code offset #32
/* 280:    */     //   Java source line #218	-> byte code offset #37
/* 281:    */     //   Java source line #211	-> byte code offset #44
/* 282:    */     //   Java source line #212	-> byte code offset #46
/* 283:    */     //   Java source line #213	-> byte code offset #49
/* 284:    */     //   Java source line #214	-> byte code offset #57
/* 285:    */     //   Java source line #217	-> byte code offset #60
/* 286:    */     //   Java source line #218	-> byte code offset #67
/* 287:    */     // Local variable table:
/* 288:    */     //   start	length	slot	name	signature
/* 289:    */     //   0	76	0	toJoin	Thread
/* 290:    */     //   0	76	1	timeout	long
/* 291:    */     //   0	76	3	unit	TimeUnit
/* 292:    */     //   6	57	4	interrupted	boolean
/* 293:    */     //   13	43	5	remainingNanos	long
/* 294:    */     //   21	29	7	end	long
/* 295:    */     //   44	3	9	e	InterruptedException
/* 296:    */     //   60	14	10	localObject	Object
/* 297:    */     // Exception table:
/* 298:    */     //   from	to	target	type
/* 299:    */     //   23	32	44	java/lang/InterruptedException
/* 300:    */     //   8	32	60	finally
/* 301:    */     //   44	62	60	finally
/* 302:    */   }
/* 303:    */   
/* 304:    */   @GwtIncompatible("concurrency")
/* 305:    */   public static <E> E takeUninterruptibly(BlockingQueue<E> queue)
/* 306:    */   {
/* 307:228 */     boolean interrupted = false;
/* 308:    */     try
/* 309:    */     {
/* 310:232 */       return queue.take();
/* 311:    */     }
/* 312:    */     catch (InterruptedException e)
/* 313:    */     {
/* 314:    */       for (;;)
/* 315:    */       {
/* 316:234 */         interrupted = true;
/* 317:    */       }
/* 318:    */     }
/* 319:    */     finally
/* 320:    */     {
/* 321:238 */       if (interrupted) {
/* 322:239 */         Thread.currentThread().interrupt();
/* 323:    */       }
/* 324:    */     }
/* 325:    */   }
/* 326:    */   
/* 327:    */   @GwtIncompatible("concurrency")
/* 328:    */   public static <E> void putUninterruptibly(BlockingQueue<E> queue, E element)
/* 329:    */   {
/* 330:255 */     boolean interrupted = false;
/* 331:    */     try
/* 332:    */     {
/* 333:259 */       queue.put(element);
/* 334:    */     }
/* 335:    */     catch (InterruptedException e)
/* 336:    */     {
/* 337:    */       for (;;)
/* 338:    */       {
/* 339:262 */         interrupted = true;
/* 340:    */       }
/* 341:    */     }
/* 342:    */     finally
/* 343:    */     {
/* 344:266 */       if (interrupted) {
/* 345:267 */         Thread.currentThread().interrupt();
/* 346:    */       }
/* 347:    */     }
/* 348:    */   }
/* 349:    */   
/* 350:    */   /* Error */
/* 351:    */   @GwtIncompatible("concurrency")
/* 352:    */   public static void sleepUninterruptibly(long sleepFor, TimeUnit unit)
/* 353:    */   {
/* 354:    */     // Byte code:
/* 355:    */     //   0: iconst_0
/* 356:    */     //   1: istore_3
/* 357:    */     //   2: aload_2
/* 358:    */     //   3: lload_0
/* 359:    */     //   4: invokevirtual 5	java/util/concurrent/TimeUnit:toNanos	(J)J
/* 360:    */     //   7: lstore 4
/* 361:    */     //   9: invokestatic 6	java/lang/System:nanoTime	()J
/* 362:    */     //   12: lload 4
/* 363:    */     //   14: ladd
/* 364:    */     //   15: lstore 6
/* 365:    */     //   17: getstatic 7	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/* 366:    */     //   20: lload 4
/* 367:    */     //   22: invokevirtual 16	java/util/concurrent/TimeUnit:sleep	(J)V
/* 368:    */     //   25: iload_3
/* 369:    */     //   26: ifeq +9 -> 35
/* 370:    */     //   29: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 371:    */     //   32: invokevirtual 3	java/lang/Thread:interrupt	()V
/* 372:    */     //   35: return
/* 373:    */     //   36: astore 8
/* 374:    */     //   38: iconst_1
/* 375:    */     //   39: istore_3
/* 376:    */     //   40: lload 6
/* 377:    */     //   42: invokestatic 6	java/lang/System:nanoTime	()J
/* 378:    */     //   45: lsub
/* 379:    */     //   46: lstore 4
/* 380:    */     //   48: goto -31 -> 17
/* 381:    */     //   51: astore 9
/* 382:    */     //   53: iload_3
/* 383:    */     //   54: ifeq +9 -> 63
/* 384:    */     //   57: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 385:    */     //   60: invokevirtual 3	java/lang/Thread:interrupt	()V
/* 386:    */     //   63: aload 9
/* 387:    */     //   65: athrow
/* 388:    */     // Line number table:
/* 389:    */     //   Java source line #279	-> byte code offset #0
/* 390:    */     //   Java source line #281	-> byte code offset #2
/* 391:    */     //   Java source line #282	-> byte code offset #9
/* 392:    */     //   Java source line #286	-> byte code offset #17
/* 393:    */     //   Java source line #294	-> byte code offset #25
/* 394:    */     //   Java source line #295	-> byte code offset #29
/* 395:    */     //   Java source line #288	-> byte code offset #36
/* 396:    */     //   Java source line #289	-> byte code offset #38
/* 397:    */     //   Java source line #290	-> byte code offset #40
/* 398:    */     //   Java source line #291	-> byte code offset #48
/* 399:    */     //   Java source line #294	-> byte code offset #51
/* 400:    */     //   Java source line #295	-> byte code offset #57
/* 401:    */     // Local variable table:
/* 402:    */     //   start	length	slot	name	signature
/* 403:    */     //   0	66	0	sleepFor	long
/* 404:    */     //   0	66	2	unit	TimeUnit
/* 405:    */     //   1	53	3	interrupted	boolean
/* 406:    */     //   7	40	4	remainingNanos	long
/* 407:    */     //   15	26	6	end	long
/* 408:    */     //   36	3	8	e	InterruptedException
/* 409:    */     //   51	13	9	localObject	Object
/* 410:    */     // Exception table:
/* 411:    */     //   from	to	target	type
/* 412:    */     //   17	25	36	java/lang/InterruptedException
/* 413:    */     //   2	25	51	finally
/* 414:    */     //   36	53	51	finally
/* 415:    */   }
/* 416:    */   
/* 417:    */   @GwtIncompatible("concurrency")
/* 418:    */   public static boolean tryAcquireUninterruptibly(Semaphore semaphore, long timeout, TimeUnit unit)
/* 419:    */   {
/* 420:309 */     return tryAcquireUninterruptibly(semaphore, 1, timeout, unit);
/* 421:    */   }
/* 422:    */   
/* 423:    */   /* Error */
/* 424:    */   @GwtIncompatible("concurrency")
/* 425:    */   public static boolean tryAcquireUninterruptibly(Semaphore semaphore, int permits, long timeout, TimeUnit unit)
/* 426:    */   {
/* 427:    */     // Byte code:
/* 428:    */     //   0: iconst_0
/* 429:    */     //   1: istore 5
/* 430:    */     //   3: aload 4
/* 431:    */     //   5: lload_2
/* 432:    */     //   6: invokevirtual 5	java/util/concurrent/TimeUnit:toNanos	(J)J
/* 433:    */     //   9: lstore 6
/* 434:    */     //   11: invokestatic 6	java/lang/System:nanoTime	()J
/* 435:    */     //   14: lload 6
/* 436:    */     //   16: ladd
/* 437:    */     //   17: lstore 8
/* 438:    */     //   19: aload_0
/* 439:    */     //   20: iload_1
/* 440:    */     //   21: lload 6
/* 441:    */     //   23: getstatic 7	java/util/concurrent/TimeUnit:NANOSECONDS	Ljava/util/concurrent/TimeUnit;
/* 442:    */     //   26: invokevirtual 18	java/util/concurrent/Semaphore:tryAcquire	(IJLjava/util/concurrent/TimeUnit;)Z
/* 443:    */     //   29: istore 10
/* 444:    */     //   31: iload 5
/* 445:    */     //   33: ifeq +9 -> 42
/* 446:    */     //   36: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 447:    */     //   39: invokevirtual 3	java/lang/Thread:interrupt	()V
/* 448:    */     //   42: iload 10
/* 449:    */     //   44: ireturn
/* 450:    */     //   45: astore 10
/* 451:    */     //   47: iconst_1
/* 452:    */     //   48: istore 5
/* 453:    */     //   50: lload 8
/* 454:    */     //   52: invokestatic 6	java/lang/System:nanoTime	()J
/* 455:    */     //   55: lsub
/* 456:    */     //   56: lstore 6
/* 457:    */     //   58: goto -39 -> 19
/* 458:    */     //   61: astore 11
/* 459:    */     //   63: iload 5
/* 460:    */     //   65: ifeq +9 -> 74
/* 461:    */     //   68: invokestatic 2	java/lang/Thread:currentThread	()Ljava/lang/Thread;
/* 462:    */     //   71: invokevirtual 3	java/lang/Thread:interrupt	()V
/* 463:    */     //   74: aload 11
/* 464:    */     //   76: athrow
/* 465:    */     // Line number table:
/* 466:    */     //   Java source line #321	-> byte code offset #0
/* 467:    */     //   Java source line #323	-> byte code offset #3
/* 468:    */     //   Java source line #324	-> byte code offset #11
/* 469:    */     //   Java source line #329	-> byte code offset #19
/* 470:    */     //   Java source line #336	-> byte code offset #31
/* 471:    */     //   Java source line #337	-> byte code offset #36
/* 472:    */     //   Java source line #330	-> byte code offset #45
/* 473:    */     //   Java source line #331	-> byte code offset #47
/* 474:    */     //   Java source line #332	-> byte code offset #50
/* 475:    */     //   Java source line #333	-> byte code offset #58
/* 476:    */     //   Java source line #336	-> byte code offset #61
/* 477:    */     //   Java source line #337	-> byte code offset #68
/* 478:    */     // Local variable table:
/* 479:    */     //   start	length	slot	name	signature
/* 480:    */     //   0	77	0	semaphore	Semaphore
/* 481:    */     //   0	77	1	permits	int
/* 482:    */     //   0	77	2	timeout	long
/* 483:    */     //   0	77	4	unit	TimeUnit
/* 484:    */     //   1	63	5	interrupted	boolean
/* 485:    */     //   9	48	6	remainingNanos	long
/* 486:    */     //   17	34	8	end	long
/* 487:    */     //   29	14	10	bool1	boolean
/* 488:    */     //   45	3	10	e	InterruptedException
/* 489:    */     //   61	14	11	localObject	Object
/* 490:    */     // Exception table:
/* 491:    */     //   from	to	target	type
/* 492:    */     //   19	31	45	java/lang/InterruptedException
/* 493:    */     //   3	31	61	finally
/* 494:    */     //   45	63	61	finally
/* 495:    */   }
/* 496:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.Uninterruptibles
 * JD-Core Version:    0.7.0.1
 */