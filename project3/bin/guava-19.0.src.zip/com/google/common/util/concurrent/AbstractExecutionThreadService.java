/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Supplier;
/*   5:    */ import java.util.concurrent.Executor;
/*   6:    */ import java.util.concurrent.TimeUnit;
/*   7:    */ import java.util.concurrent.TimeoutException;
/*   8:    */ import java.util.logging.Level;
/*   9:    */ import java.util.logging.Logger;
/*  10:    */ 
/*  11:    */ @Beta
/*  12:    */ public abstract class AbstractExecutionThreadService
/*  13:    */   implements Service
/*  14:    */ {
/*  15: 39 */   private static final Logger logger = Logger.getLogger(AbstractExecutionThreadService.class.getName());
/*  16: 43 */   private final Service delegate = new AbstractService()
/*  17:    */   {
/*  18:    */     protected final void doStart()
/*  19:    */     {
/*  20: 45 */       Executor executor = MoreExecutors.renamingDecorator(AbstractExecutionThreadService.this.executor(), new Supplier()
/*  21:    */       {
/*  22:    */         public String get()
/*  23:    */         {
/*  24: 47 */           return AbstractExecutionThreadService.this.serviceName();
/*  25:    */         }
/*  26: 49 */       });
/*  27: 50 */       executor.execute(new Runnable()
/*  28:    */       {
/*  29:    */         public void run()
/*  30:    */         {
/*  31:    */           try
/*  32:    */           {
/*  33: 54 */             AbstractExecutionThreadService.this.startUp();
/*  34: 55 */             AbstractExecutionThreadService.1.this.notifyStarted();
/*  35: 58 */             if (AbstractExecutionThreadService.1.this.isRunning()) {
/*  36:    */               try
/*  37:    */               {
/*  38: 60 */                 AbstractExecutionThreadService.this.run();
/*  39:    */               }
/*  40:    */               catch (Throwable t)
/*  41:    */               {
/*  42:    */                 try
/*  43:    */                 {
/*  44: 63 */                   AbstractExecutionThreadService.this.shutDown();
/*  45:    */                 }
/*  46:    */                 catch (Exception ignored)
/*  47:    */                 {
/*  48: 67 */                   AbstractExecutionThreadService.logger.log(Level.WARNING, "Error while attempting to shut down the service after failure.", ignored);
/*  49:    */                 }
/*  50: 71 */                 AbstractExecutionThreadService.1.this.notifyFailed(t);
/*  51: 72 */                 return;
/*  52:    */               }
/*  53:    */             }
/*  54: 76 */             AbstractExecutionThreadService.this.shutDown();
/*  55: 77 */             AbstractExecutionThreadService.1.this.notifyStopped();
/*  56:    */           }
/*  57:    */           catch (Throwable t)
/*  58:    */           {
/*  59: 79 */             AbstractExecutionThreadService.1.this.notifyFailed(t);
/*  60:    */           }
/*  61:    */         }
/*  62:    */       });
/*  63:    */     }
/*  64:    */     
/*  65:    */     protected void doStop()
/*  66:    */     {
/*  67: 86 */       AbstractExecutionThreadService.this.triggerShutdown();
/*  68:    */     }
/*  69:    */     
/*  70:    */     public String toString()
/*  71:    */     {
/*  72: 90 */       return AbstractExecutionThreadService.this.toString();
/*  73:    */     }
/*  74:    */   };
/*  75:    */   
/*  76:    */   protected void startUp()
/*  77:    */     throws Exception
/*  78:    */   {}
/*  79:    */   
/*  80:    */   protected abstract void run()
/*  81:    */     throws Exception;
/*  82:    */   
/*  83:    */   protected void shutDown()
/*  84:    */     throws Exception
/*  85:    */   {}
/*  86:    */   
/*  87:    */   protected void triggerShutdown() {}
/*  88:    */   
/*  89:    */   protected Executor executor()
/*  90:    */   {
/*  91:149 */     new Executor()
/*  92:    */     {
/*  93:    */       public void execute(Runnable command)
/*  94:    */       {
/*  95:152 */         MoreExecutors.newThread(AbstractExecutionThreadService.this.serviceName(), command).start();
/*  96:    */       }
/*  97:    */     };
/*  98:    */   }
/*  99:    */   
/* 100:    */   public String toString()
/* 101:    */   {
/* 102:158 */     return serviceName() + " [" + state() + "]";
/* 103:    */   }
/* 104:    */   
/* 105:    */   public final boolean isRunning()
/* 106:    */   {
/* 107:162 */     return this.delegate.isRunning();
/* 108:    */   }
/* 109:    */   
/* 110:    */   public final Service.State state()
/* 111:    */   {
/* 112:166 */     return this.delegate.state();
/* 113:    */   }
/* 114:    */   
/* 115:    */   public final void addListener(Service.Listener listener, Executor executor)
/* 116:    */   {
/* 117:173 */     this.delegate.addListener(listener, executor);
/* 118:    */   }
/* 119:    */   
/* 120:    */   public final Throwable failureCause()
/* 121:    */   {
/* 122:180 */     return this.delegate.failureCause();
/* 123:    */   }
/* 124:    */   
/* 125:    */   public final Service startAsync()
/* 126:    */   {
/* 127:187 */     this.delegate.startAsync();
/* 128:188 */     return this;
/* 129:    */   }
/* 130:    */   
/* 131:    */   public final Service stopAsync()
/* 132:    */   {
/* 133:195 */     this.delegate.stopAsync();
/* 134:196 */     return this;
/* 135:    */   }
/* 136:    */   
/* 137:    */   public final void awaitRunning()
/* 138:    */   {
/* 139:203 */     this.delegate.awaitRunning();
/* 140:    */   }
/* 141:    */   
/* 142:    */   public final void awaitRunning(long timeout, TimeUnit unit)
/* 143:    */     throws TimeoutException
/* 144:    */   {
/* 145:210 */     this.delegate.awaitRunning(timeout, unit);
/* 146:    */   }
/* 147:    */   
/* 148:    */   public final void awaitTerminated()
/* 149:    */   {
/* 150:217 */     this.delegate.awaitTerminated();
/* 151:    */   }
/* 152:    */   
/* 153:    */   public final void awaitTerminated(long timeout, TimeUnit unit)
/* 154:    */     throws TimeoutException
/* 155:    */   {
/* 156:224 */     this.delegate.awaitTerminated(timeout, unit);
/* 157:    */   }
/* 158:    */   
/* 159:    */   protected String serviceName()
/* 160:    */   {
/* 161:236 */     return getClass().getSimpleName();
/* 162:    */   }
/* 163:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AbstractExecutionThreadService
 * JD-Core Version:    0.7.0.1
 */