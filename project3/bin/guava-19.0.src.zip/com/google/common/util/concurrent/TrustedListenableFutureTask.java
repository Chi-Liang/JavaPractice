/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.annotations.GwtIncompatible;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import java.util.concurrent.Callable;
/*   7:    */ import java.util.concurrent.Executors;
/*   8:    */ import java.util.concurrent.RunnableFuture;
/*   9:    */ import javax.annotation.Nullable;
/*  10:    */ 
/*  11:    */ @GwtCompatible
/*  12:    */ class TrustedListenableFutureTask<V>
/*  13:    */   extends AbstractFuture.TrustedFuture<V>
/*  14:    */   implements RunnableFuture<V>
/*  15:    */ {
/*  16:    */   private TrustedListenableFutureTask<V>.TrustedFutureInterruptibleTask task;
/*  17:    */   
/*  18:    */   static <V> TrustedListenableFutureTask<V> create(Callable<V> callable)
/*  19:    */   {
/*  20: 49 */     return new TrustedListenableFutureTask(callable);
/*  21:    */   }
/*  22:    */   
/*  23:    */   static <V> TrustedListenableFutureTask<V> create(Runnable runnable, @Nullable V result)
/*  24:    */   {
/*  25: 65 */     return new TrustedListenableFutureTask(Executors.callable(runnable, result));
/*  26:    */   }
/*  27:    */   
/*  28:    */   TrustedListenableFutureTask(Callable<V> callable)
/*  29:    */   {
/*  30: 71 */     this.task = new TrustedFutureInterruptibleTask(callable);
/*  31:    */   }
/*  32:    */   
/*  33:    */   public void run()
/*  34:    */   {
/*  35: 75 */     TrustedListenableFutureTask<V>.TrustedFutureInterruptibleTask localTask = this.task;
/*  36: 76 */     if (localTask != null) {
/*  37: 77 */       localTask.run();
/*  38:    */     }
/*  39:    */   }
/*  40:    */   
/*  41:    */   final void done()
/*  42:    */   {
/*  43: 82 */     super.done();
/*  44:    */     
/*  45:    */ 
/*  46: 85 */     this.task = null;
/*  47:    */   }
/*  48:    */   
/*  49:    */   @GwtIncompatible("Interruption not supported")
/*  50:    */   protected final void interruptTask()
/*  51:    */   {
/*  52: 90 */     TrustedListenableFutureTask<V>.TrustedFutureInterruptibleTask localTask = this.task;
/*  53: 91 */     if (localTask != null) {
/*  54: 92 */       localTask.interruptTask();
/*  55:    */     }
/*  56:    */   }
/*  57:    */   
/*  58:    */   private final class TrustedFutureInterruptibleTask
/*  59:    */     extends InterruptibleTask
/*  60:    */   {
/*  61:    */     private final Callable<V> callable;
/*  62:    */     
/*  63:    */     TrustedFutureInterruptibleTask()
/*  64:    */     {
/*  65:101 */       this.callable = ((Callable)Preconditions.checkNotNull(callable));
/*  66:    */     }
/*  67:    */     
/*  68:    */     void runInterruptibly()
/*  69:    */     {
/*  70:106 */       if (!TrustedListenableFutureTask.this.isDone()) {
/*  71:    */         try
/*  72:    */         {
/*  73:108 */           TrustedListenableFutureTask.this.set(this.callable.call());
/*  74:    */         }
/*  75:    */         catch (Throwable t)
/*  76:    */         {
/*  77:110 */           TrustedListenableFutureTask.this.setException(t);
/*  78:    */         }
/*  79:    */       }
/*  80:    */     }
/*  81:    */     
/*  82:    */     boolean wasInterrupted()
/*  83:    */     {
/*  84:116 */       return TrustedListenableFutureTask.this.wasInterrupted();
/*  85:    */     }
/*  86:    */   }
/*  87:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.TrustedListenableFutureTask
 * JD-Core Version:    0.7.0.1
 */