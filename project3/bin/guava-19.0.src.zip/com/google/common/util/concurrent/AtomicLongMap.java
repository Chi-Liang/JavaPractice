/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.GwtCompatible;
/*   4:    */ import com.google.common.base.Function;
/*   5:    */ import com.google.common.base.Preconditions;
/*   6:    */ import com.google.common.collect.Maps;
/*   7:    */ import java.util.Collections;
/*   8:    */ import java.util.Iterator;
/*   9:    */ import java.util.Map;
/*  10:    */ import java.util.Map.Entry;
/*  11:    */ import java.util.Set;
/*  12:    */ import java.util.concurrent.ConcurrentHashMap;
/*  13:    */ import java.util.concurrent.atomic.AtomicLong;
/*  14:    */ 
/*  15:    */ @GwtCompatible
/*  16:    */ public final class AtomicLongMap<K>
/*  17:    */ {
/*  18:    */   private final ConcurrentHashMap<K, AtomicLong> map;
/*  19:    */   private transient Map<K, Long> asMap;
/*  20:    */   
/*  21:    */   private AtomicLongMap(ConcurrentHashMap<K, AtomicLong> map)
/*  22:    */   {
/*  23: 59 */     this.map = ((ConcurrentHashMap)Preconditions.checkNotNull(map));
/*  24:    */   }
/*  25:    */   
/*  26:    */   public static <K> AtomicLongMap<K> create()
/*  27:    */   {
/*  28: 66 */     return new AtomicLongMap(new ConcurrentHashMap());
/*  29:    */   }
/*  30:    */   
/*  31:    */   public static <K> AtomicLongMap<K> create(Map<? extends K, ? extends Long> m)
/*  32:    */   {
/*  33: 73 */     AtomicLongMap<K> result = create();
/*  34: 74 */     result.putAll(m);
/*  35: 75 */     return result;
/*  36:    */   }
/*  37:    */   
/*  38:    */   public long get(K key)
/*  39:    */   {
/*  40: 83 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/*  41: 84 */     return atomic == null ? 0L : atomic.get();
/*  42:    */   }
/*  43:    */   
/*  44:    */   public long incrementAndGet(K key)
/*  45:    */   {
/*  46: 91 */     return addAndGet(key, 1L);
/*  47:    */   }
/*  48:    */   
/*  49:    */   public long decrementAndGet(K key)
/*  50:    */   {
/*  51: 98 */     return addAndGet(key, -1L);
/*  52:    */   }
/*  53:    */   
/*  54:    */   public long addAndGet(K key, long delta)
/*  55:    */   {
/*  56:107 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/*  57:108 */     if (atomic == null)
/*  58:    */     {
/*  59:109 */       atomic = (AtomicLong)this.map.putIfAbsent(key, new AtomicLong(delta));
/*  60:110 */       if (atomic == null) {
/*  61:111 */         return delta;
/*  62:    */       }
/*  63:    */     }
/*  64:    */     for (;;)
/*  65:    */     {
/*  66:117 */       long oldValue = atomic.get();
/*  67:118 */       if (oldValue == 0L)
/*  68:    */       {
/*  69:120 */         if (!this.map.replace(key, atomic, new AtomicLong(delta))) {
/*  70:    */           break;
/*  71:    */         }
/*  72:121 */         return delta;
/*  73:    */       }
/*  74:127 */       long newValue = oldValue + delta;
/*  75:128 */       if (atomic.compareAndSet(oldValue, newValue)) {
/*  76:129 */         return newValue;
/*  77:    */       }
/*  78:    */     }
/*  79:    */   }
/*  80:    */   
/*  81:    */   public long getAndIncrement(K key)
/*  82:    */   {
/*  83:140 */     return getAndAdd(key, 1L);
/*  84:    */   }
/*  85:    */   
/*  86:    */   public long getAndDecrement(K key)
/*  87:    */   {
/*  88:147 */     return getAndAdd(key, -1L);
/*  89:    */   }
/*  90:    */   
/*  91:    */   public long getAndAdd(K key, long delta)
/*  92:    */   {
/*  93:156 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/*  94:157 */     if (atomic == null)
/*  95:    */     {
/*  96:158 */       atomic = (AtomicLong)this.map.putIfAbsent(key, new AtomicLong(delta));
/*  97:159 */       if (atomic == null) {
/*  98:160 */         return 0L;
/*  99:    */       }
/* 100:    */     }
/* 101:    */     for (;;)
/* 102:    */     {
/* 103:166 */       long oldValue = atomic.get();
/* 104:167 */       if (oldValue == 0L)
/* 105:    */       {
/* 106:169 */         if (!this.map.replace(key, atomic, new AtomicLong(delta))) {
/* 107:    */           break;
/* 108:    */         }
/* 109:170 */         return 0L;
/* 110:    */       }
/* 111:176 */       long newValue = oldValue + delta;
/* 112:177 */       if (atomic.compareAndSet(oldValue, newValue)) {
/* 113:178 */         return oldValue;
/* 114:    */       }
/* 115:    */     }
/* 116:    */   }
/* 117:    */   
/* 118:    */   public long put(K key, long newValue)
/* 119:    */   {
/* 120:191 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 121:192 */     if (atomic == null)
/* 122:    */     {
/* 123:193 */       atomic = (AtomicLong)this.map.putIfAbsent(key, new AtomicLong(newValue));
/* 124:194 */       if (atomic == null) {
/* 125:195 */         return 0L;
/* 126:    */       }
/* 127:    */     }
/* 128:    */     for (;;)
/* 129:    */     {
/* 130:201 */       long oldValue = atomic.get();
/* 131:202 */       if (oldValue == 0L)
/* 132:    */       {
/* 133:204 */         if (!this.map.replace(key, atomic, new AtomicLong(newValue))) {
/* 134:    */           break;
/* 135:    */         }
/* 136:205 */         return 0L;
/* 137:    */       }
/* 138:211 */       if (atomic.compareAndSet(oldValue, newValue)) {
/* 139:212 */         return oldValue;
/* 140:    */       }
/* 141:    */     }
/* 142:    */   }
/* 143:    */   
/* 144:    */   public void putAll(Map<? extends K, ? extends Long> m)
/* 145:    */   {
/* 146:226 */     for (Map.Entry<? extends K, ? extends Long> entry : m.entrySet()) {
/* 147:227 */       put(entry.getKey(), ((Long)entry.getValue()).longValue());
/* 148:    */     }
/* 149:    */   }
/* 150:    */   
/* 151:    */   public long remove(K key)
/* 152:    */   {
/* 153:236 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 154:237 */     if (atomic == null) {
/* 155:238 */       return 0L;
/* 156:    */     }
/* 157:    */     for (;;)
/* 158:    */     {
/* 159:242 */       long oldValue = atomic.get();
/* 160:243 */       if ((oldValue == 0L) || (atomic.compareAndSet(oldValue, 0L)))
/* 161:    */       {
/* 162:245 */         this.map.remove(key, atomic);
/* 163:    */         
/* 164:247 */         return oldValue;
/* 165:    */       }
/* 166:    */     }
/* 167:    */   }
/* 168:    */   
/* 169:    */   public void removeAllZeros()
/* 170:    */   {
/* 171:259 */     Iterator<Map.Entry<K, AtomicLong>> entryIterator = this.map.entrySet().iterator();
/* 172:260 */     while (entryIterator.hasNext())
/* 173:    */     {
/* 174:261 */       Map.Entry<K, AtomicLong> entry = (Map.Entry)entryIterator.next();
/* 175:262 */       AtomicLong atomic = (AtomicLong)entry.getValue();
/* 176:263 */       if ((atomic != null) && (atomic.get() == 0L)) {
/* 177:264 */         entryIterator.remove();
/* 178:    */       }
/* 179:    */     }
/* 180:    */   }
/* 181:    */   
/* 182:    */   public long sum()
/* 183:    */   {
/* 184:275 */     long sum = 0L;
/* 185:276 */     for (AtomicLong value : this.map.values()) {
/* 186:277 */       sum += value.get();
/* 187:    */     }
/* 188:279 */     return sum;
/* 189:    */   }
/* 190:    */   
/* 191:    */   public Map<K, Long> asMap()
/* 192:    */   {
/* 193:288 */     Map<K, Long> result = this.asMap;
/* 194:289 */     return result == null ? (this.asMap = createAsMap()) : result;
/* 195:    */   }
/* 196:    */   
/* 197:    */   private Map<K, Long> createAsMap()
/* 198:    */   {
/* 199:293 */     Collections.unmodifiableMap(Maps.transformValues(this.map, new Function()
/* 200:    */     {
/* 201:    */       public Long apply(AtomicLong atomic)
/* 202:    */       {
/* 203:297 */         return Long.valueOf(atomic.get());
/* 204:    */       }
/* 205:    */     }));
/* 206:    */   }
/* 207:    */   
/* 208:    */   public boolean containsKey(Object key)
/* 209:    */   {
/* 210:306 */     return this.map.containsKey(key);
/* 211:    */   }
/* 212:    */   
/* 213:    */   public int size()
/* 214:    */   {
/* 215:314 */     return this.map.size();
/* 216:    */   }
/* 217:    */   
/* 218:    */   public boolean isEmpty()
/* 219:    */   {
/* 220:321 */     return this.map.isEmpty();
/* 221:    */   }
/* 222:    */   
/* 223:    */   public void clear()
/* 224:    */   {
/* 225:331 */     this.map.clear();
/* 226:    */   }
/* 227:    */   
/* 228:    */   public String toString()
/* 229:    */   {
/* 230:336 */     return this.map.toString();
/* 231:    */   }
/* 232:    */   
/* 233:    */   long putIfAbsent(K key, long newValue)
/* 234:    */   {
/* 235:    */     AtomicLong atomic;
/* 236:    */     long oldValue;
/* 237:    */     do
/* 238:    */     {
/* 239:369 */       atomic = (AtomicLong)this.map.get(key);
/* 240:370 */       if (atomic == null)
/* 241:    */       {
/* 242:371 */         atomic = (AtomicLong)this.map.putIfAbsent(key, new AtomicLong(newValue));
/* 243:372 */         if (atomic == null) {
/* 244:373 */           return 0L;
/* 245:    */         }
/* 246:    */       }
/* 247:378 */       oldValue = atomic.get();
/* 248:379 */       if (oldValue != 0L) {
/* 249:    */         break;
/* 250:    */       }
/* 251:381 */     } while (!this.map.replace(key, atomic, new AtomicLong(newValue)));
/* 252:382 */     return 0L;
/* 253:    */     
/* 254:    */ 
/* 255:    */ 
/* 256:    */ 
/* 257:    */ 
/* 258:388 */     return oldValue;
/* 259:    */   }
/* 260:    */   
/* 261:    */   boolean replace(K key, long expectedOldValue, long newValue)
/* 262:    */   {
/* 263:401 */     if (expectedOldValue == 0L) {
/* 264:402 */       return putIfAbsent(key, newValue) == 0L;
/* 265:    */     }
/* 266:404 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 267:405 */     return atomic == null ? false : atomic.compareAndSet(expectedOldValue, newValue);
/* 268:    */   }
/* 269:    */   
/* 270:    */   boolean remove(K key, long value)
/* 271:    */   {
/* 272:414 */     AtomicLong atomic = (AtomicLong)this.map.get(key);
/* 273:415 */     if (atomic == null) {
/* 274:416 */       return false;
/* 275:    */     }
/* 276:419 */     long oldValue = atomic.get();
/* 277:420 */     if (oldValue != value) {
/* 278:421 */       return false;
/* 279:    */     }
/* 280:424 */     if ((oldValue == 0L) || (atomic.compareAndSet(oldValue, 0L)))
/* 281:    */     {
/* 282:426 */       this.map.remove(key, atomic);
/* 283:    */       
/* 284:428 */       return true;
/* 285:    */     }
/* 286:432 */     return false;
/* 287:    */   }
/* 288:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.AtomicLongMap
 * JD-Core Version:    0.7.0.1
 */