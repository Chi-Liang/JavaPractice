/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import java.util.ArrayDeque;
/*   5:    */ import java.util.Deque;
/*   6:    */ import java.util.concurrent.Executor;
/*   7:    */ import java.util.logging.Level;
/*   8:    */ import java.util.logging.Logger;
/*   9:    */ import javax.annotation.concurrent.GuardedBy;
/*  10:    */ 
/*  11:    */ final class SerializingExecutor
/*  12:    */   implements Executor
/*  13:    */ {
/*  14: 50 */   private static final Logger log = Logger.getLogger(SerializingExecutor.class.getName());
/*  15:    */   private final Executor executor;
/*  16:    */   @GuardedBy("internalLock")
/*  17: 56 */   private final Deque<Runnable> queue = new ArrayDeque();
/*  18:    */   @GuardedBy("internalLock")
/*  19: 58 */   private boolean isWorkerRunning = false;
/*  20:    */   @GuardedBy("internalLock")
/*  21: 60 */   private int suspensions = 0;
/*  22: 63 */   private final Object internalLock = new Object();
/*  23:    */   
/*  24:    */   public SerializingExecutor(Executor executor)
/*  25:    */   {
/*  26: 66 */     this.executor = ((Executor)Preconditions.checkNotNull(executor));
/*  27:    */   }
/*  28:    */   
/*  29:    */   public void execute(Runnable task)
/*  30:    */   {
/*  31: 78 */     synchronized (this.internalLock)
/*  32:    */     {
/*  33: 79 */       this.queue.add(task);
/*  34:    */     }
/*  35: 81 */     startQueueWorker();
/*  36:    */   }
/*  37:    */   
/*  38:    */   public void executeFirst(Runnable task)
/*  39:    */   {
/*  40: 89 */     synchronized (this.internalLock)
/*  41:    */     {
/*  42: 90 */       this.queue.addFirst(task);
/*  43:    */     }
/*  44: 92 */     startQueueWorker();
/*  45:    */   }
/*  46:    */   
/*  47:    */   public void suspend()
/*  48:    */   {
/*  49:104 */     synchronized (this.internalLock)
/*  50:    */     {
/*  51:105 */       this.suspensions += 1;
/*  52:    */     }
/*  53:    */   }
/*  54:    */   
/*  55:    */   public void resume()
/*  56:    */   {
/*  57:121 */     synchronized (this.internalLock)
/*  58:    */     {
/*  59:122 */       Preconditions.checkState(this.suspensions > 0);
/*  60:123 */       this.suspensions -= 1;
/*  61:    */     }
/*  62:125 */     startQueueWorker();
/*  63:    */   }
/*  64:    */   
/*  65:    */   private void startQueueWorker()
/*  66:    */   {
/*  67:129 */     synchronized (this.internalLock)
/*  68:    */     {
/*  69:131 */       if (this.queue.peek() == null) {
/*  70:132 */         return;
/*  71:    */       }
/*  72:134 */       if (this.suspensions > 0) {
/*  73:135 */         return;
/*  74:    */       }
/*  75:137 */       if (this.isWorkerRunning) {
/*  76:138 */         return;
/*  77:    */       }
/*  78:140 */       this.isWorkerRunning = true;
/*  79:    */     }
/*  80:142 */     boolean executionRejected = true;
/*  81:    */     try
/*  82:    */     {
/*  83:144 */       this.executor.execute(new QueueWorker(null));
/*  84:145 */       executionRejected = false;
/*  85:    */     }
/*  86:    */     finally
/*  87:    */     {
/*  88:147 */       if (executionRejected) {
/*  89:150 */         synchronized (this.internalLock)
/*  90:    */         {
/*  91:151 */           this.isWorkerRunning = false;
/*  92:    */         }
/*  93:    */       }
/*  94:    */     }
/*  95:    */   }
/*  96:    */   
/*  97:    */   private final class QueueWorker
/*  98:    */     implements Runnable
/*  99:    */   {
/* 100:    */     private QueueWorker() {}
/* 101:    */     
/* 102:    */     public void run()
/* 103:    */     {
/* 104:    */       try
/* 105:    */       {
/* 106:164 */         workOnQueue();
/* 107:    */       }
/* 108:    */       catch (Error e)
/* 109:    */       {
/* 110:166 */         synchronized (SerializingExecutor.this.internalLock)
/* 111:    */         {
/* 112:167 */           SerializingExecutor.this.isWorkerRunning = false;
/* 113:    */         }
/* 114:169 */         throw e;
/* 115:    */       }
/* 116:    */     }
/* 117:    */     
/* 118:    */     private void workOnQueue()
/* 119:    */     {
/* 120:    */       for (;;)
/* 121:    */       {
/* 122:178 */         Runnable task = null;
/* 123:179 */         synchronized (SerializingExecutor.this.internalLock)
/* 124:    */         {
/* 125:181 */           if (SerializingExecutor.this.suspensions == 0) {
/* 126:182 */             task = (Runnable)SerializingExecutor.this.queue.poll();
/* 127:    */           }
/* 128:184 */           if (task == null)
/* 129:    */           {
/* 130:185 */             SerializingExecutor.this.isWorkerRunning = false;
/* 131:186 */             return;
/* 132:    */           }
/* 133:    */         }
/* 134:    */         try
/* 135:    */         {
/* 136:190 */           task.run();
/* 137:    */         }
/* 138:    */         catch (RuntimeException e)
/* 139:    */         {
/* 140:192 */           SerializingExecutor.log.log(Level.SEVERE, "Exception while executing runnable " + task, e);
/* 141:    */         }
/* 142:    */       }
/* 143:    */     }
/* 144:    */   }
/* 145:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.SerializingExecutor
 * JD-Core Version:    0.7.0.1
 */