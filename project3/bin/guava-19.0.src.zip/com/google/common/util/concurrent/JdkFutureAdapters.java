/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.Beta;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.concurrent.Executor;
/*   6:    */ import java.util.concurrent.Executors;
/*   7:    */ import java.util.concurrent.Future;
/*   8:    */ import java.util.concurrent.ThreadFactory;
/*   9:    */ import java.util.concurrent.atomic.AtomicBoolean;
/*  10:    */ 
/*  11:    */ @Beta
/*  12:    */ public final class JdkFutureAdapters
/*  13:    */ {
/*  14:    */   public static <V> ListenableFuture<V> listenInPoolThread(Future<V> future)
/*  15:    */   {
/*  16: 60 */     if ((future instanceof ListenableFuture)) {
/*  17: 61 */       return (ListenableFuture)future;
/*  18:    */     }
/*  19: 63 */     return new ListenableFutureAdapter(future);
/*  20:    */   }
/*  21:    */   
/*  22:    */   public static <V> ListenableFuture<V> listenInPoolThread(Future<V> future, Executor executor)
/*  23:    */   {
/*  24: 92 */     Preconditions.checkNotNull(executor);
/*  25: 93 */     if ((future instanceof ListenableFuture)) {
/*  26: 94 */       return (ListenableFuture)future;
/*  27:    */     }
/*  28: 96 */     return new ListenableFutureAdapter(future, executor);
/*  29:    */   }
/*  30:    */   
/*  31:    */   private static class ListenableFutureAdapter<V>
/*  32:    */     extends ForwardingFuture<V>
/*  33:    */     implements ListenableFuture<V>
/*  34:    */   {
/*  35:112 */     private static final ThreadFactory threadFactory = new ThreadFactoryBuilder().setDaemon(true).setNameFormat("ListenableFutureAdapter-thread-%d").build();
/*  36:117 */     private static final Executor defaultAdapterExecutor = Executors.newCachedThreadPool(threadFactory);
/*  37:    */     private final Executor adapterExecutor;
/*  38:123 */     private final ExecutionList executionList = new ExecutionList();
/*  39:127 */     private final AtomicBoolean hasListeners = new AtomicBoolean(false);
/*  40:    */     private final Future<V> delegate;
/*  41:    */     
/*  42:    */     ListenableFutureAdapter(Future<V> delegate)
/*  43:    */     {
/*  44:133 */       this(delegate, defaultAdapterExecutor);
/*  45:    */     }
/*  46:    */     
/*  47:    */     ListenableFutureAdapter(Future<V> delegate, Executor adapterExecutor)
/*  48:    */     {
/*  49:137 */       this.delegate = ((Future)Preconditions.checkNotNull(delegate));
/*  50:138 */       this.adapterExecutor = ((Executor)Preconditions.checkNotNull(adapterExecutor));
/*  51:    */     }
/*  52:    */     
/*  53:    */     protected Future<V> delegate()
/*  54:    */     {
/*  55:143 */       return this.delegate;
/*  56:    */     }
/*  57:    */     
/*  58:    */     public void addListener(Runnable listener, Executor exec)
/*  59:    */     {
/*  60:148 */       this.executionList.add(listener, exec);
/*  61:152 */       if (this.hasListeners.compareAndSet(false, true))
/*  62:    */       {
/*  63:153 */         if (this.delegate.isDone())
/*  64:    */         {
/*  65:156 */           this.executionList.execute();
/*  66:157 */           return;
/*  67:    */         }
/*  68:161 */         this.adapterExecutor.execute(new Runnable()
/*  69:    */         {
/*  70:    */           public void run()
/*  71:    */           {
/*  72:    */             try
/*  73:    */             {
/*  74:171 */               Uninterruptibles.getUninterruptibly(JdkFutureAdapters.ListenableFutureAdapter.this.delegate);
/*  75:    */             }
/*  76:    */             catch (Throwable e) {}
/*  77:176 */             JdkFutureAdapters.ListenableFutureAdapter.this.executionList.execute();
/*  78:    */           }
/*  79:    */         });
/*  80:    */       }
/*  81:    */     }
/*  82:    */   }
/*  83:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.JdkFutureAdapters
 * JD-Core Version:    0.7.0.1
 */