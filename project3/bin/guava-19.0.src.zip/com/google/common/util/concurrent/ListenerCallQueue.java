/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.base.Preconditions;
/*   4:    */ import com.google.common.collect.Queues;
/*   5:    */ import java.util.Queue;
/*   6:    */ import java.util.concurrent.Executor;
/*   7:    */ import java.util.logging.Level;
/*   8:    */ import java.util.logging.Logger;
/*   9:    */ import javax.annotation.concurrent.GuardedBy;
/*  10:    */ 
/*  11:    */ final class ListenerCallQueue<L>
/*  12:    */   implements Runnable
/*  13:    */ {
/*  14: 40 */   private static final Logger logger = Logger.getLogger(ListenerCallQueue.class.getName());
/*  15:    */   private final L listener;
/*  16:    */   private final Executor executor;
/*  17:    */   
/*  18:    */   static abstract class Callback<L>
/*  19:    */   {
/*  20:    */     private final String methodCall;
/*  21:    */     
/*  22:    */     Callback(String methodCall)
/*  23:    */     {
/*  24: 46 */       this.methodCall = methodCall;
/*  25:    */     }
/*  26:    */     
/*  27:    */     abstract void call(L paramL);
/*  28:    */     
/*  29:    */     void enqueueOn(Iterable<ListenerCallQueue<L>> queues)
/*  30:    */     {
/*  31: 53 */       for (ListenerCallQueue<L> queue : queues) {
/*  32: 54 */         queue.add(this);
/*  33:    */       }
/*  34:    */     }
/*  35:    */   }
/*  36:    */   
/*  37:    */   @GuardedBy("this")
/*  38: 62 */   private final Queue<Callback<L>> waitQueue = Queues.newArrayDeque();
/*  39:    */   @GuardedBy("this")
/*  40:    */   private boolean isThreadScheduled;
/*  41:    */   
/*  42:    */   ListenerCallQueue(L listener, Executor executor)
/*  43:    */   {
/*  44: 66 */     this.listener = Preconditions.checkNotNull(listener);
/*  45: 67 */     this.executor = ((Executor)Preconditions.checkNotNull(executor));
/*  46:    */   }
/*  47:    */   
/*  48:    */   synchronized void add(Callback<L> callback)
/*  49:    */   {
/*  50: 72 */     this.waitQueue.add(callback);
/*  51:    */   }
/*  52:    */   
/*  53:    */   void execute()
/*  54:    */   {
/*  55: 77 */     boolean scheduleTaskRunner = false;
/*  56: 78 */     synchronized (this)
/*  57:    */     {
/*  58: 79 */       if (!this.isThreadScheduled)
/*  59:    */       {
/*  60: 80 */         this.isThreadScheduled = true;
/*  61: 81 */         scheduleTaskRunner = true;
/*  62:    */       }
/*  63:    */     }
/*  64: 84 */     if (scheduleTaskRunner) {
/*  65:    */       try
/*  66:    */       {
/*  67: 86 */         this.executor.execute(this);
/*  68:    */       }
/*  69:    */       catch (RuntimeException e)
/*  70:    */       {
/*  71: 89 */         synchronized (this)
/*  72:    */         {
/*  73: 90 */           this.isThreadScheduled = false;
/*  74:    */         }
/*  75: 93 */         logger.log(Level.SEVERE, "Exception while running callbacks for " + this.listener + " on " + this.executor, e);
/*  76:    */         
/*  77:    */ 
/*  78: 96 */         throw e;
/*  79:    */       }
/*  80:    */     }
/*  81:    */   }
/*  82:    */   
/*  83:    */   public void run()
/*  84:    */   {
/*  85:102 */     boolean stillRunning = true;
/*  86:    */     try
/*  87:    */     {
/*  88:    */       for (;;)
/*  89:    */       {
/*  90:    */         Callback<L> nextToRun;
/*  91:106 */         synchronized (this)
/*  92:    */         {
/*  93:107 */           Preconditions.checkState(this.isThreadScheduled);
/*  94:108 */           nextToRun = (Callback)this.waitQueue.poll();
/*  95:109 */           if (nextToRun == null)
/*  96:    */           {
/*  97:110 */             this.isThreadScheduled = false;
/*  98:111 */             stillRunning = false;
/*  99:112 */             break;
/* 100:    */           }
/* 101:    */         }
/* 102:    */         try
/* 103:    */         {
/* 104:118 */           nextToRun.call(this.listener);
/* 105:    */         }
/* 106:    */         catch (RuntimeException e)
/* 107:    */         {
/* 108:121 */           logger.log(Level.SEVERE, "Exception while executing callback: " + this.listener + "." + nextToRun.methodCall, e);
/* 109:    */         }
/* 110:    */       }
/* 111:    */     }
/* 112:    */     finally
/* 113:    */     {
/* 114:127 */       if (stillRunning) {
/* 115:131 */         synchronized (this)
/* 116:    */         {
/* 117:132 */           this.isThreadScheduled = false;
/* 118:    */         }
/* 119:    */       }
/* 120:    */     }
/* 121:    */   }
/* 122:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ListenerCallQueue
 * JD-Core Version:    0.7.0.1
 */