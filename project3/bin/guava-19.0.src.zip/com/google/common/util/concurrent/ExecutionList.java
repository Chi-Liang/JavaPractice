/*   1:    */ package com.google.common.util.concurrent;
/*   2:    */ 
/*   3:    */ import com.google.common.annotations.VisibleForTesting;
/*   4:    */ import com.google.common.base.Preconditions;
/*   5:    */ import java.util.concurrent.Executor;
/*   6:    */ import java.util.logging.Level;
/*   7:    */ import java.util.logging.Logger;
/*   8:    */ import javax.annotation.Nullable;
/*   9:    */ import javax.annotation.concurrent.GuardedBy;
/*  10:    */ 
/*  11:    */ public final class ExecutionList
/*  12:    */ {
/*  13:    */   @VisibleForTesting
/*  14: 48 */   static final Logger log = Logger.getLogger(ExecutionList.class.getName());
/*  15:    */   @GuardedBy("this")
/*  16:    */   private RunnableExecutorPair runnables;
/*  17:    */   @GuardedBy("this")
/*  18:    */   private boolean executed;
/*  19:    */   
/*  20:    */   public void add(Runnable runnable, Executor executor)
/*  21:    */   {
/*  22: 73 */     Preconditions.checkNotNull(runnable, "Runnable was null.");
/*  23: 74 */     Preconditions.checkNotNull(executor, "Executor was null.");
/*  24: 79 */     synchronized (this)
/*  25:    */     {
/*  26: 80 */       if (!this.executed)
/*  27:    */       {
/*  28: 81 */         this.runnables = new RunnableExecutorPair(runnable, executor, this.runnables);
/*  29: 82 */         return;
/*  30:    */       }
/*  31:    */     }
/*  32: 89 */     executeListener(runnable, executor);
/*  33:    */   }
/*  34:    */   
/*  35:    */   public void execute()
/*  36:    */   {
/*  37:    */     RunnableExecutorPair list;
/*  38:107 */     synchronized (this)
/*  39:    */     {
/*  40:108 */       if (this.executed) {
/*  41:109 */         return;
/*  42:    */       }
/*  43:111 */       this.executed = true;
/*  44:112 */       list = this.runnables;
/*  45:113 */       this.runnables = null;
/*  46:    */     }
/*  47:124 */     RunnableExecutorPair reversedList = null;
/*  48:125 */     while (list != null)
/*  49:    */     {
/*  50:126 */       RunnableExecutorPair tmp = list;
/*  51:127 */       list = list.next;
/*  52:128 */       tmp.next = reversedList;
/*  53:129 */       reversedList = tmp;
/*  54:    */     }
/*  55:131 */     while (reversedList != null)
/*  56:    */     {
/*  57:132 */       executeListener(reversedList.runnable, reversedList.executor);
/*  58:133 */       reversedList = reversedList.next;
/*  59:    */     }
/*  60:    */   }
/*  61:    */   
/*  62:    */   private static void executeListener(Runnable runnable, Executor executor)
/*  63:    */   {
/*  64:    */     try
/*  65:    */     {
/*  66:143 */       executor.execute(runnable);
/*  67:    */     }
/*  68:    */     catch (RuntimeException e)
/*  69:    */     {
/*  70:148 */       log.log(Level.SEVERE, "RuntimeException while executing runnable " + runnable + " with executor " + executor, e);
/*  71:    */     }
/*  72:    */   }
/*  73:    */   
/*  74:    */   private static final class RunnableExecutorPair
/*  75:    */   {
/*  76:    */     final Runnable runnable;
/*  77:    */     final Executor executor;
/*  78:    */     @Nullable
/*  79:    */     RunnableExecutorPair next;
/*  80:    */     
/*  81:    */     RunnableExecutorPair(Runnable runnable, Executor executor, RunnableExecutorPair next)
/*  82:    */     {
/*  83:159 */       this.runnable = runnable;
/*  84:160 */       this.executor = executor;
/*  85:161 */       this.next = next;
/*  86:    */     }
/*  87:    */   }
/*  88:    */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ExecutionList
 * JD-Core Version:    0.7.0.1
 */