/*  1:   */ package com.google.common.util.concurrent;
/*  2:   */ 
/*  3:   */ import com.google.common.base.Preconditions;
/*  4:   */ import com.google.common.collect.ForwardingObject;
/*  5:   */ import java.util.concurrent.ExecutionException;
/*  6:   */ import java.util.concurrent.Future;
/*  7:   */ import java.util.concurrent.TimeUnit;
/*  8:   */ import java.util.concurrent.TimeoutException;
/*  9:   */ 
/* 10:   */ public abstract class ForwardingFuture<V>
/* 11:   */   extends ForwardingObject
/* 12:   */   implements Future<V>
/* 13:   */ {
/* 14:   */   protected abstract Future<V> delegate();
/* 15:   */   
/* 16:   */   public boolean cancel(boolean mayInterruptIfRunning)
/* 17:   */   {
/* 18:48 */     return delegate().cancel(mayInterruptIfRunning);
/* 19:   */   }
/* 20:   */   
/* 21:   */   public boolean isCancelled()
/* 22:   */   {
/* 23:53 */     return delegate().isCancelled();
/* 24:   */   }
/* 25:   */   
/* 26:   */   public boolean isDone()
/* 27:   */   {
/* 28:58 */     return delegate().isDone();
/* 29:   */   }
/* 30:   */   
/* 31:   */   public V get()
/* 32:   */     throws InterruptedException, ExecutionException
/* 33:   */   {
/* 34:63 */     return delegate().get();
/* 35:   */   }
/* 36:   */   
/* 37:   */   public V get(long timeout, TimeUnit unit)
/* 38:   */     throws InterruptedException, ExecutionException, TimeoutException
/* 39:   */   {
/* 40:69 */     return delegate().get(timeout, unit);
/* 41:   */   }
/* 42:   */   
/* 43:   */   public static abstract class SimpleForwardingFuture<V>
/* 44:   */     extends ForwardingFuture<V>
/* 45:   */   {
/* 46:   */     private final Future<V> delegate;
/* 47:   */     
/* 48:   */     protected SimpleForwardingFuture(Future<V> delegate)
/* 49:   */     {
/* 50:87 */       this.delegate = ((Future)Preconditions.checkNotNull(delegate));
/* 51:   */     }
/* 52:   */     
/* 53:   */     protected final Future<V> delegate()
/* 54:   */     {
/* 55:92 */       return this.delegate;
/* 56:   */     }
/* 57:   */   }
/* 58:   */ }


/* Location:           C:\Users\user\Desktop\guava-19.0.jar
 * Qualified Name:     com.google.common.util.concurrent.ForwardingFuture
 * JD-Core Version:    0.7.0.1
 */